<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('Fifu_Attachment_Update_Service', false)) {
    require_once __DIR__ . '/../../includes/meta/class-fifu-attachment-update-service.php';
}
if (!class_exists('Fifu_Attachment_Factory', false)) {
    require_once __DIR__ . '/../../includes/meta/class-fifu-attachment-factory.php';
}
if (!class_exists('Fifu_Default_Image_Service', false)) {
    require_once __DIR__ . '/../../includes/meta/class-fifu-default-image-service.php';
}

final class Fifu_Admin_Menu
{
    /**
     * Settings page action slug kept for backwards compatibility.
     */
    public const ACTION_SETTINGS = '/wp-admin/admin.php?page=fifu-premium';

    /**
     * Cloud page action slug kept for backwards compatibility.
     */
    public const ACTION_CLOUD = '/wp-admin/admin.php?page=fifu-cloud';

    public static function register_hooks(): void
    {
        add_action('admin_menu', [self::class, 'add_admin_menu']);
        if (is_multisite()) {
            add_action('network_admin_menu', [self::class, 'add_network_admin_menu']);
        }
        add_action(
            'wp_ajax_fifu_check_status_server',
            [Fifu_Admin_Support_Data_Page::class, 'ajax_check_status_server']
        );
        add_action(
            'wp_ajax_fifu_vimeo_access_token_scopes_status',
            [self::class, 'ajax_vimeo_access_token_scopes_status']
        );
        add_action('admin_enqueue_scripts', [self::class, 'maybe_enqueue_assets']);
    }

    public static function add_admin_menu(): void
    {
        self::insert_menu_common('manage_options', false);
    }

    public static function add_network_admin_menu(): void
    {
        if (!is_multisite()) {
            return;
        }

        Fifu_Network_Utils::with_main_site(static function () {
            self::insert_menu_common('manage_network_options', true);
        });
    }

    private static function insert_menu_common(string $capability, bool $is_network): void
    {
        $fifu = Fifu_Admin_Strings::get_settings_strings();

        // Assets enqueued separately via admin_enqueue_scripts for better control.

        $menu_callback = $is_network ? [ 'Fifu_Network_Utils', 'get_network_menu_html' ] : [ self::class, 'render_menu_page' ];
        $license_callback = $is_network ? [ 'Fifu_Network_Utils', 'license_key' ] : [ Fifu_Admin_License_Page::class, 'render' ];
        $cloud_callback = $is_network ? [ 'Fifu_Network_Utils', 'cloud' ] : [ Fifu_Admin_Cloud_Page::class, 'render' ];
        $status_callback = $is_network ? [ 'Fifu_Network_Utils', 'support_data' ] : [ Fifu_Admin_Support_Data_Page::class, 'render' ];

        add_menu_page('Featured Image from URL', 'FIFU', $capability, FIFU_SLUG, $menu_callback, 'dashicons-camera', 57);
        add_submenu_page(FIFU_SLUG, 'FIFU Settings', $fifu['options']['settings'](), $capability, FIFU_SLUG, $menu_callback);
        add_submenu_page(FIFU_SLUG, 'FIFU License key', $fifu['options']['key'](), $capability, 'fifu-license-key', $license_callback);

        if (!$is_network) {
            add_submenu_page(FIFU_SLUG, 'FIFU Cloud', $fifu['options']['cloud'](), $capability, 'fifu-cloud', $cloud_callback);
            add_submenu_page(FIFU_SLUG, 'FIFU Status', $fifu['options']['status'](), $capability, 'fifu-support-data', $status_callback);
        }

        add_action('admin_init', [ 'Fifu_Settings_Manager', 'register_menu_settings' ]);
    }

    public static function render_menu_page(): void
    {
        flush();

        $fifu = Fifu_Admin_Strings::get_settings_strings();
        $fifucloud = Fifu_Cloud_Strings::get_strings();

        wp_enqueue_style('fifu-base-ui-css', plugins_url('/admin/html/css/base-ui.css', FIFU_PLUGIN_FILE), [], Fifu_Plugin_Info::get_enqueue_version());
        wp_enqueue_style('fifu-menu-css', plugins_url('/admin/html/css/menu.css', FIFU_PLUGIN_FILE), [], Fifu_Plugin_Info::get_enqueue_version());
        wp_enqueue_script('fifu-menu-js', plugins_url('/admin/html/js/menu.js', FIFU_PLUGIN_FILE), ['jquery', 'jquery-ui'], Fifu_Plugin_Info::get_enqueue_version());
        wp_enqueue_style('fifu-auto-share-css', plugins_url('/admin/html/css/auto-share.css', FIFU_PLUGIN_FILE), [], Fifu_Plugin_Info::get_enqueue_version());
        wp_enqueue_script('fifu-auto-share-js', plugins_url('/admin/html/js/auto-share.js', FIFU_PLUGIN_FILE), ['jquery', 'fifu-menu-js'], Fifu_Plugin_Info::get_enqueue_version());

        wp_localize_script('fifu-menu-js', 'fifuScriptVars', [
            'restUrl' => esc_url_raw(rest_url()),
            'adminAjaxUrl' => admin_url('admin-ajax.php'),
            'brokenLinksNonce' => wp_create_nonce('fifu_broken_links'),
            'noBrokenImageUrls' => __('No Broken Links', FIFU_SLUG),
            'homeUrl' => esc_url_raw(home_url()),
            'nonce' => wp_create_nonce('wp_rest'),
            'wait' => $fifu['php']['message']['wait'](),
            'wait1' => $fifu['php']['message']['wait1'](),
            'lock' => get_option('fifu_lock'),
            'emptyKey' => empty(get_option('fifu_key')),
            'expired' => get_option('fifu_expired'),
            'keyText' => $fifu['options']['key'](),
            'saving' => $fifu['word']['saving'](),
            'saved' => $fifu['word']['saved'](),
            'error' => $fifu['word']['error'](),
            'reset' => $fifu['word']['reset'](),
            'save' => $fifu['word']['save'](),
            'connect' => $fifu['share']['window']['connect'](),
            'shareInfo' => [
                'title' => $fifu['share']['info']['requirements'](),
                'facebook' => [
                    'page' => $fifu['share']['info']['facebook']['page'](),
                    'published' => $fifu['share']['info']['facebook']['published'](),
                ],
                'instagram' => [
                    'professional' => $fifu['share']['info']['instagram']['professional'](),
                    'public' => $fifu['share']['info']['instagram']['public'](),
                ],
                'x' => [
                    'developer' => $fifu['share']['info']['x']['developer'](),
                    'permissions' => $fifu['share']['info']['x']['permissions'](),
                    'type' => $fifu['share']['info']['x']['type'](),
                    'callback' => $fifu['share']['info']['x']['callback'](),
                    'client' => $fifu['share']['info']['x']['client'](),
                ],
            ],
            'pluginUrl' => plugins_url() . '/' . FIFU_SLUG,
            'networkAdmin' => is_network_admin(),
        ]);

        $enable_block = get_option('fifu_block');
        $enable_popup = get_option('fifu_popup');
        $enable_redirection = get_option('fifu_redirection');
        $enable_auto_share = get_option('fifu_auto_share');
        $enable_auto_share_facebook = get_option('fifu_auto_share_facebook');
        $enable_auto_share_instagram = get_option('fifu_auto_share_instagram');
        $enable_auto_share_x = get_option('fifu_auto_share_x');
        $enable_auto_set = get_option('fifu_auto_set');
        $max_auto_set_width = get_option('fifu_auto_set_width');
        $max_auto_set_height = get_option('fifu_auto_set_height');
        $auto_set_blocklist = esc_textarea(get_option('fifu_auto_set_blocklist'));
        $auto_set_cpt = esc_attr(get_option('fifu_auto_set_cpt'));
        $auto_set_source = esc_attr(get_option('fifu_auto_set_source'));
        $auto_set_layout = esc_attr(get_option('fifu_auto_set_layout'));
        $html_media = esc_attr(get_option('fifu_html_media'));
        $upload_domain = esc_attr(get_option('fifu_upload_domain'));
        $skip = esc_attr(get_option('fifu_skip'));
        $html_cpt = esc_attr(get_option('fifu_html_cpt'));
        $enable_asin = get_option('fifu_asin');
        $asin_custom_field = esc_attr(get_option('fifu_asin_custom_field'));
        $asin_credentials_partner = esc_attr(get_option('fifu_asin_credentials_partner'));
        $asin_credentials_access = esc_attr(get_option('fifu_asin_credentials_access'));
        $asin_credentials_secret = esc_attr(get_option('fifu_asin_credentials_secret'));
        $asin_credentials_locale = esc_attr(get_option('fifu_asin_credentials_locale'));
        $auto_share_x_clientid = esc_attr(get_option('fifu_auto_share_x_clientid'));
        $square_mobile = esc_attr(get_option('fifu_square_mobile'));
        $square_desktop = esc_attr(get_option('fifu_square_desktop'));
        $screenshot_custom_field = esc_attr(get_option('fifu_screenshot_custom_field'));
        $screenshot_size = esc_attr(get_option('fifu_screenshot_size'));
        $enable_customfield = get_option('fifu_customfield');
        $customfield_custom_field = esc_attr(get_option('fifu_customfield_custom_field'));
        $finder_custom_field = esc_attr(get_option('fifu_finder_custom_field'));
        $enable_finder = get_option('fifu_finder');
        $enable_video_finder = get_option('fifu_video_finder');
        $enable_amazon_finder = get_option('fifu_amazon_finder');
        $enable_screenshot = get_option('fifu_screenshot');
        $enable_debug = get_option('fifu_debug');
        $enable_photon = get_option('fifu_photon');
        $enable_otfcdn = get_option('fifu_otfcdn');
        $enable_own_domain = get_option('fifu_own_domain');
        $enable_cdn_content = get_option('fifu_cdn_content');
        $enable_reset = get_option('fifu_reset');
        $enable_fake = get_option('fifu_fake');
        $enable_order_email = get_option('fifu_order_email');
        $enable_gallery = get_option('fifu_gallery');
        $enable_adaptive_height = get_option('fifu_adaptive_height');
        $enable_videos_before = get_option('fifu_videos_before');
        $vimeo_access_token_scopes = esc_attr(get_option('fifu_vimeo_access_token_scopes'));
        $enable_variations_merge = get_option('fifu_variations_merge');
        $enable_buy = get_option('fifu_buy');
        $error_url = esc_url(get_option('fifu_error_url'));
        $default_url = esc_url(get_option('fifu_default_url'));
        $enable_validate_featured_image_urls = get_option('fifu_validate_featured_image_urls') === 'toggleon'
            ? 'toggleon'
            : 'toggleoff';
        $default_cpt = esc_attr(get_option('fifu_default_cpt'));
        $pcontent_types = esc_attr(get_option('fifu_pcontent_types'));
        $hide_format = esc_attr(get_option('fifu_hide_format'));
        $hide_type = esc_attr(get_option('fifu_hide_type'));
        $enable_default_url = get_option('fifu_enable_default_url');
        $enable_cron_metadata = get_option('fifu_cron_metadata');
        $min_video_width = get_option('fifu_video_min_width');
        $video_color = esc_attr(get_option('fifu_video_color'));
        $video_zindex = esc_attr(get_option('fifu_video_zindex'));
        $video_size = get_option('fifu_video_size');
        $enable_slider = get_option('fifu_slider');
        $enable_slider_auto = get_option('fifu_slider_auto');
        $enable_slider_gallery = get_option('fifu_slider_gallery');
        $enable_slider_thumb = get_option('fifu_slider_thumb');
        $enable_slider_counter = get_option('fifu_slider_counter');
        $enable_slider_crop = get_option('fifu_slider_crop');
        $enable_slider_single = get_option('fifu_slider_single');
        $enable_slider_vertical = get_option('fifu_slider_vertical');
        $enable_slider_ctrl = get_option('fifu_slider_ctrl');
        $enable_slider_stop = get_option('fifu_slider_stop');
        $slider_speed = get_option('fifu_slider_speed');
        $slider_pause = get_option('fifu_slider_pause');
        $enable_wc_lbox = get_option('fifu_wc_lbox');
        $enable_wc_zoom = get_option('fifu_wc_zoom');
        $enable_hide = get_option('fifu_hide');
        $enable_pcontent_add = get_option('fifu_pcontent_add');
        $enable_pcontent_remove = get_option('fifu_pcontent_remove');
        $enable_get_first = get_option('fifu_get_first');
        $enable_ovw_first = get_option('fifu_ovw_first');
        $enable_update_all = 'toggleoff';
        $enable_run_delete_all = get_option('fifu_run_delete_all');
        $enable_run_delete_all_time = get_option('fifu_run_delete_all_time');
        $enable_autoplay = get_option('fifu_autoplay');
        $enable_autoplay_front = get_option('fifu_autoplay_front');
        $enable_autoplay_front_all = get_option('fifu_autoplay_front_all');
        $enable_autoplay_elsewhere = get_option('fifu_autoplay_elsewhere');
        $enable_video_mute = get_option('fifu_video_mute');
        $enable_video_mute_mobile = get_option('fifu_video_mute_mobile');
        $enable_video_background = get_option('fifu_video_background');
        $enable_video_background_single = get_option('fifu_video_background_single');
        $enable_video_privacy = get_option('fifu_video_privacy');
        $vimeo_access_token = esc_attr(get_option('fifu_vimeo_access_token'));
        $vimeo_access_token_scopes = esc_attr(get_option('fifu_vimeo_access_token_scopes'));
        $vimeo_mp4_rendition = get_option('fifu_vimeo_mp4_rendition', '540p');
        if (!in_array($vimeo_mp4_rendition, array('1080p', '720p', '540p', '360p', '240p'), true)) {
            $vimeo_mp4_rendition = '540p';
        }
        $vimeo_mp4_rendition = esc_attr($vimeo_mp4_rendition);
        $vimeo_access_token_scopes_ok = self::vimeo_access_token_scopes_ok($vimeo_access_token_scopes);
        $enable_video_later = get_option('fifu_video_later');
        $enable_video_later_left = get_option('fifu_video_later_left');
        $enable_loop = get_option('fifu_loop');
        $enable_mouse_video = get_option('fifu_mouse_video');
        $enable_video = get_option('fifu_video');
        $enable_video_thumb = get_option('fifu_video_thumb');
        $enable_video_thumb_page = get_option('fifu_video_thumb_page');
        $enable_video_thumb_post = get_option('fifu_video_thumb_post');
        $enable_video_thumb_cpt = get_option('fifu_video_thumb_cpt');
        $enable_video_play_button = get_option('fifu_video_play_button');
        $enable_video_play_hide_grid = get_option('fifu_video_play_hide_grid');
        $enable_video_play_hide_grid_wc = get_option('fifu_video_play_hide_grid_wc');
        $enable_video_controls = get_option('fifu_video_controls');
        $enable_auto_category = get_option('fifu_auto_category');
        $enable_taxonomy = get_option('fifu_taxonomy');
        $enable_data_clean = 'toggleoff';
        $play_type_option = get_option('fifu_play_type');
        $enable_upload_show = get_option('fifu_upload_show');
        $enable_upload_proxy = get_option('fifu_upload_proxy');
        $enable_upload_job = get_option('fifu_upload_job');
        $upload_private_proxy = esc_attr(get_option('fifu_upload_private_proxy'));
        $slider_left = esc_url(get_option('fifu_slider_left'));
        $slider_right = esc_url(get_option('fifu_slider_right'));
        $buy_text = get_option('fifu_buy_text');
        $buy_disclaimer = get_option('fifu_buy_disclaimer');
        $buy_cf = get_option('fifu_buy_cf');
        $enable_bbpress_fields = get_option('fifu_bbpress_fields');

        include FIFU_ADMIN_DIR . '/html/menu.html';

        $arr = Fifu_Settings_Manager::update_from_request();

        if (Fifu_Options_Utils::is_on('fifu_auto_category')) {
            if (!get_option('fifu_auto_category_created')) {
                Fifu_Auto_Category_Image_Service::run();
                update_option('fifu_auto_category_created', true, 'no');
            }
        } else {
            update_option('fifu_auto_category_created', false, 'no');
        }

        if (!$arr['fifu_default_cpt']) {
            $default_url = $arr['fifu_default_url'];
            if (!empty($default_url) && Fifu_Options_Utils::is_on('fifu_enable_default_url') && Fifu_Options_Utils::is_on('fifu_fake')) {
                $att_id = (int) get_option('fifu_default_attach_id');
                $current_url = $att_id ? Fifu_Attachment_Update_Service::get_attachment_remote_url($att_id) : '';
                if (!$att_id || !$current_url) {
                    $attachment_factory = new Fifu_Attachment_Factory();
                    $att_id = $attachment_factory->create_attachment_for_url($default_url);
                    if ($att_id > 0) {
                        Fifu_Attachment_Update_Service::initialize_remote_attachment($att_id, $default_url, null);
                        update_option('fifu_default_attach_id', $att_id, 'no');
                    }
                    Fifu_Default_Image_Service::apply_default_to_all_missing_thumbnails();
                } else {
                    Fifu_Default_Image_Service::update_default_url($default_url);
                }
            }
        }

        if (Fifu_Options_Utils::is_on('fifu_reset')) {
            Fifu_Settings_Manager::reset_settings();
            update_option('fifu_reset', 'toggleoff', 'no');
        }
    }

    public static function maybe_enqueue_assets($hook): void
    {
        $page = $_GET['page'] ?? '';

        if (is_array($page)) {
            return;
        }

        $page = sanitize_key(wp_unslash((string) $page));

        $allowed_pages = [
            FIFU_SLUG,
            'fifu-license-key',
            'fifu-cloud',
            'fifu-support-data',
        ];

        if (!in_array($page, $allowed_pages, true)) {
            return;
        }

        $fifu = Fifu_Admin_Strings::get_settings_strings();
        self::enqueue_assets_if_needed($fifu);
    }

    private static function enqueue_assets_if_needed(array $fifu): void
    {
        wp_enqueue_script('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.0/js/all.min.js');
        wp_enqueue_style('jquery-ui-style1', 'https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css');
        wp_enqueue_style('jquery-ui-style2', 'https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.structure.min.css');
        wp_enqueue_style('jquery-ui-style3', 'https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.theme.min.css');

        wp_enqueue_script('jquery-ui', 'https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js');
        wp_enqueue_script('jquery-block-ui', 'https://cdnjs.cloudflare.com/ajax/libs/jquery.blockUI/2.70/jquery.blockUI.min.js');

        wp_enqueue_style('fancy-box-css', 'https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.css');
        wp_enqueue_script('fancy-box-js', 'https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js');

        wp_enqueue_style('datatable-css', '//cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css');
        wp_enqueue_style('datatable-select-css', '//cdn.datatables.net/select/1.3.3/css/select.dataTables.min.css');
        wp_enqueue_style('datatable-buttons-css', '//cdn.datatables.net/buttons/2.0.1/css/buttons.dataTables.min.css');
        wp_enqueue_script('datatable-js', '//cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js');
        wp_enqueue_script('datatable-select', '//cdn.datatables.net/select/1.3.3/js/dataTables.select.min.js');
        wp_enqueue_script('datatable-buttons', '//cdn.datatables.net/buttons/2.0.1/js/dataTables.buttons.min.js');

        wp_enqueue_script(
            'fifu-rest-route-js',
            plugins_url('/admin/html/js/rest-route.js', FIFU_PLUGIN_FILE),
            ['jquery'],
            Fifu_Plugin_Info::get_enqueue_version()
        );

        wp_localize_script('fifu-rest-route-js', 'fifuScriptVars', [
        'restUrl' => esc_url_raw(rest_url()),
        'homeUrl' => esc_url_raw(home_url()),
        'nonce' => wp_create_nonce('wp_rest'),
        'networkAdmin' => is_network_admin(),
        ]);

        wp_enqueue_script(
            'fifu-async',
            plugins_url('/admin/html/js/async.js', FIFU_PLUGIN_FILE),
            ['jquery'],
            Fifu_Plugin_Info::get_enqueue_version()
        );
        wp_localize_script('fifu-async', 'fifuAsyncVars', [
            'restUrl' => esc_url_raw(rest_url()),
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wp_rest'),
            'server_ok' => $fifu['server']['success'](),
            'server_nok' => $fifu['server']['fail'](),
            'key_success' => $fifu['key']['success']['main'](),
            'key_expired' => $fifu['key']['expired']['main'](),
            'key_invalid' => $fifu['key']['invalid']['main'](),
            'key_success_details' => $fifu['key']['success']['details'](),
            'key_expired_details' => $fifu['key']['expired']['details'](),
            'key_invalid_details' => $fifu['key']['invalid']['details'](),
            'expiredText' => $fifu['options']['expired'](),
            'networkAdmin' => is_network_admin(),
        ]);
    }

    /**
     * Indicates whether the SU private key has been stored.
     */
    public static function is_su_sign_up_complete(): bool
    {
        $privkey_option = get_option('fifu_su_privkey');
        return isset($privkey_option[0]) ? true : false;
    }

    /**
     * Returns the stored SU email after decoding it.
     */
    public static function get_su_email(): string
    {
        $su_email_option = get_option('fifu_su_email');
        return base64_decode($su_email_option[0] ?? '');
    }

    /**
     * Retrieves a short summary of the latest entries for a given meta key.
     */
    public static function get_last_meta_entries_summary(string $meta_key, int $limit = 3): string
    {
        $list = '';
        $rows = Fifu_Meta_Stats_Utils::get_last_meta_entries((string) $meta_key, $limit);

        foreach ($rows as $row) {
            $aux = $row->meta_value . "\n → " . get_permalink($row->id);
            $list .= "\n - " . $aux;
        }

        return $list;
    }

    /**
     * Retrieves a recent DB2-aware media summary, with legacy postmeta fallback.
     */
    public static function get_last_media_entries_summary(string $type, string $legacy_meta_key, int $limit = 3): string
    {
        $list = '';
        $rows = Fifu_Meta_Stats_Utils::get_last_media_entries($type, $legacy_meta_key, $limit);

        foreach ($rows as $row) {
            $aux = $row->meta_value . "\n → " . get_permalink($row->id);
            $list .= "\n - " . $aux;
        }

        return $list;
    }

    /**
     * Returns a formatted summary describing all detected image sizes.
     */
    public static function get_registered_sizes_summary(): string
    {
        $options = new Fifu_Options_Query_Utils();
        $raw_sizes = $options->select_by_prefix('fifu_detected_size_');
        $formatted_list = '';

        if ($raw_sizes && is_array($raw_sizes)) {
            foreach ($raw_sizes as $size) {
                $name = str_replace('fifu_detected_size_', '', $size->option_name);
                $data = maybe_unserialize($size->option_value);

                if (
                    is_array($data)
                    && isset($data['w'])
                    && isset($data['h'])
                    && isset($data['c'])
                ) {
                    $crop_value = $data['c'] ? '1' : '0';
                    $formatted_list .= "\n - "
                        . $name
                        . ': '
                        . $data['w']
                        . 'x'
                        . $data['h']
                        . 'x'
                        . $crop_value;
                }
            }
        }

        return $formatted_list ?: "\n - No registered sizes found";
    }

    /**
     * Updates the license key, optionally running in network-wide context.
     */
    public static function update_license_key(string $key, bool $network = false): bool
    {
        update_option('fifu_key', trim($key));
        if (is_multisite() && $network) {
            Fifu_Multisite_License::propagate_key(true);
        }
        return (bool) Fifu_License_Server::check_key((bool) $network);
    }

    private static function vimeo_access_token_scopes_ok(string $scopes): bool
    {
        $required = ['public', 'private', 'video_files'];
        $found = array_values(array_filter(array_map('trim', explode(',', $scopes)), static fn(string $scope): bool => $scope !== ''));

        return empty(array_diff($required, $found));
    }

    public static function ajax_vimeo_access_token_scopes_status(): void
    {
        check_ajax_referer('wp_rest', 'security');

        if (!current_user_can('manage_options')) {
            wp_send_json_error();
        }

        $scopes = trim((string) get_option('fifu_vimeo_access_token_scopes', ''));
        $ok = self::vimeo_access_token_scopes_ok($scopes);

        wp_send_json_success([
            'ok' => $ok,
            'classToAdd' => $ok ? 'fifu-vimeo-token-scopes-ok' : 'fifu-vimeo-token-scopes-missing',
            'classToRemove' => $ok ? 'fifu-vimeo-token-scopes-missing' : 'fifu-vimeo-token-scopes-ok',
        ]);
    }
}
