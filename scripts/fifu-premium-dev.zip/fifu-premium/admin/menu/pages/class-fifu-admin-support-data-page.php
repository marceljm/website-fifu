<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

final class Fifu_Admin_Support_Data_Page
{
    public static function render(): void
    {
        $fifu = Fifu_Admin_Strings::get_settings_strings();

        wp_enqueue_style('fifu-base-ui-css', plugins_url('/admin/html/css/base-ui.css', FIFU_PLUGIN_FILE), [], Fifu_Plugin_Info::get_enqueue_version());
        wp_enqueue_style('fifu-menu-css', plugins_url('/admin/html/css/menu.css', FIFU_PLUGIN_FILE), [], Fifu_Plugin_Info::get_enqueue_version());

        wp_enqueue_script('fifu-support-data-js', plugins_url('/admin/html/js/support-data.js', FIFU_PLUGIN_FILE), ['jquery', 'jquery-ui'], Fifu_Plugin_Info::get_enqueue_version());

        wp_enqueue_script('fifu-async', plugins_url('/admin/html/js/async.js', FIFU_PLUGIN_FILE), ['jquery'], Fifu_Plugin_Info::get_enqueue_version());
        wp_localize_script('fifu-async', 'fifuAsyncVars', [
            'restUrl' => esc_url_raw(rest_url()),
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wp_rest'),
            'server_ok' => $fifu['server']['success'](),
            'server_nok' => $fifu['server']['fail'](),
        ]);

        $status_server = get_option('fifu_status_server') ? 'success' : 'fail';
        $enable_block = get_option('fifu_block');
        $enable_popup = get_option('fifu_popup');
        $enable_redirection = get_option('fifu_redirection');
        $enable_auto_share = get_option('fifu_auto_share');
        $enable_auto_share_facebook = get_option('fifu_auto_share_facebook');
        $enable_auto_share_instagram = get_option('fifu_auto_share_instagram');
        $enable_auto_share_x = get_option('fifu_auto_share_x');
        $enable_auto_set = get_option('fifu_auto_set');
        $max_auto_set_width = get_option('fifu_auto_set_width');
        $max_auto_set_height = get_option('fifu_auto_set_height');
        $auto_set_blocklist = self::opt_string('fifu_auto_set_blocklist');
        $auto_set_cpt = self::opt_string('fifu_auto_set_cpt');
        $auto_set_source = self::opt_string('fifu_auto_set_source');
        $auto_set_layout = self::opt_string('fifu_auto_set_layout');
        $html_media = self::opt_string('fifu_html_media');
        $upload_domain = self::opt_string('fifu_upload_domain');
        $skip = self::opt_string('fifu_skip');
        $html_cpt = self::opt_string('fifu_html_cpt');
        $enable_asin = get_option('fifu_asin');
        $asin_custom_field = self::opt_string('fifu_asin_custom_field');
        $asin_credentials_partner = self::opt_string('fifu_asin_credentials_partner');
        $asin_credentials_access = self::opt_string('fifu_asin_credentials_access');
        $asin_credentials_secret = self::opt_string('fifu_asin_credentials_secret');
        $asin_credentials_locale = self::opt_string('fifu_asin_credentials_locale');
        $auto_share_x_clientid = self::opt_string('fifu_auto_share_x_clientid');
        $square_mobile = self::opt_string('fifu_square_mobile');
        $square_desktop = self::opt_string('fifu_square_desktop');
        $screenshot_custom_field = self::opt_string('fifu_screenshot_custom_field');
        $screenshot_size = self::opt_string('fifu_screenshot_size');
        $enable_customfield = get_option('fifu_customfield');
        $customfield_custom_field = self::opt_string('fifu_customfield_custom_field');
        $finder_custom_field = self::opt_string('fifu_finder_custom_field');
        $enable_finder = get_option('fifu_finder');
        $enable_video_finder = get_option('fifu_video_finder');
        $enable_amazon_finder = get_option('fifu_amazon_finder');
        $enable_screenshot = get_option('fifu_screenshot');
        $enable_debug = get_option('fifu_debug');
        $enable_photon = get_option('fifu_photon');
        $enable_validate_featured_image_urls = get_option('fifu_validate_featured_image_urls');
        $enable_otfcdn = get_option('fifu_otfcdn');
        $enable_own_domain = get_option('fifu_own_domain');
        $enable_cloud_hotlink = get_option('fifu_cloud_hotlink');
        $enable_cloud_delete_auto = get_option('fifu_cloud_delete_auto');
        $enable_cloud_upload_auto = get_option('fifu_cloud_upload_auto');
        $enable_cdn_content = get_option('fifu_cdn_content');
        $enable_reset = get_option('fifu_reset');
        $enable_fake = get_option('fifu_fake');
        $enable_order_email = get_option('fifu_order_email');
        $enable_gallery = get_option('fifu_gallery');
        $enable_adaptive_height = get_option('fifu_adaptive_height');
        $enable_videos_before = get_option('fifu_videos_before');
        $vimeo_access_token = self::mask_vimeo_access_token(self::opt_string('fifu_vimeo_access_token'));
        $vimeo_access_token_scopes = self::opt_string('fifu_vimeo_access_token_scopes');
        $vimeo_mp4_rendition = self::opt_string('fifu_vimeo_mp4_rendition');
        $enable_variations_merge = get_option('fifu_variations_merge');
        $enable_buy = get_option('fifu_buy');
        $license_key = get_option('fifu_key');
        $email = self::opt_string('fifu_email');
        $error_url = self::opt_string('fifu_error_url');
        $default_url = self::opt_string('fifu_default_url');
        $default_cpt = self::opt_string('fifu_default_cpt');
        $pcontent_types = self::opt_string('fifu_pcontent_types');
        $hide_format = self::opt_string('fifu_hide_format');
        $hide_type = self::opt_string('fifu_hide_type');
        $enable_default_url = get_option('fifu_enable_default_url');
        $enable_cron_metadata = get_option('fifu_cron_metadata');
        $min_video_width = get_option('fifu_video_min_width');
        $video_color = self::opt_string('fifu_video_color');
        $video_zindex = esc_attr(self::opt_string('fifu_video_zindex'));
        $video_size = get_option('fifu_video_size');
        $enable_slider = get_option('fifu_slider');
        $enable_slider_auto = get_option('fifu_slider_auto');
        $enable_slider_gallery = get_option('fifu_slider_gallery');
        $enable_slider_thumb = get_option('fifu_slider_thumb');
        $enable_slider_counter = get_option('fifu_slider_counter');
        $enable_slider_crop = get_option('fifu_slider_crop');
        $enable_slider_single = get_option('fifu_slider_single');
        $enable_slider_vertical = get_option('fifu_slider_vertical');
        $enable_slider_ctrl = get_option('fifu_slider_ctrl');
        $enable_slider_stop = get_option('fifu_slider_stop');
        $slider_speed = get_option('fifu_slider_speed');
        $slider_pause = get_option('fifu_slider_pause');
        $enable_wc_lbox = get_option('fifu_wc_lbox');
        $enable_wc_zoom = get_option('fifu_wc_zoom');
        $enable_hide = get_option('fifu_hide');
        $enable_pcontent_add = get_option('fifu_pcontent_add');
        $enable_pcontent_remove = get_option('fifu_pcontent_remove');
        $enable_get_first = get_option('fifu_get_first');
        $enable_ovw_first = get_option('fifu_ovw_first');
        $enable_update_all = 'toggleoff';
        $enable_run_delete_all = get_option('fifu_run_delete_all');
        $enable_run_delete_all_time = get_option('fifu_run_delete_all_time');
        $enable_autoplay = get_option('fifu_autoplay');
        $enable_autoplay_front = get_option('fifu_autoplay_front');
        $enable_autoplay_front_all = get_option(
            'fifu_autoplay_front_all'
        );
        $enable_autoplay_elsewhere = get_option(
            'fifu_autoplay_elsewhere'
        );
        $enable_video_mute = get_option('fifu_video_mute');
        $enable_video_mute_mobile = get_option('fifu_video_mute_mobile');
        $enable_video_background = get_option('fifu_video_background');
        $enable_video_background_single = get_option('fifu_video_background_single');
        $enable_video_privacy = get_option('fifu_video_privacy');
        $enable_video_later = get_option('fifu_video_later');
        $enable_video_later_left = get_option('fifu_video_later_left');
        $enable_loop = get_option('fifu_loop');
        $enable_mouse_video = get_option('fifu_mouse_video');
        $enable_video = get_option('fifu_video');
        $enable_video_thumb = get_option('fifu_video_thumb');
        $enable_video_thumb_page = get_option('fifu_video_thumb_page');
        $enable_video_thumb_post = get_option('fifu_video_thumb_post');
        $enable_video_thumb_cpt = get_option('fifu_video_thumb_cpt');
        $enable_video_play_button = get_option('fifu_video_play_button');
        $enable_video_play_hide_grid = get_option('fifu_video_play_hide_grid');
        $enable_video_play_hide_grid_wc = get_option('fifu_video_play_hide_grid_wc');
        $enable_video_controls = get_option('fifu_video_controls');
        $enable_auto_category = get_option('fifu_auto_category');
        $enable_taxonomy = get_option('fifu_taxonomy');
        $enable_data_clean = 'toggleoff';
        $play_type_option = get_option('fifu_play_type');
        $enable_upload_show = get_option('fifu_upload_show');
        $enable_upload_proxy = get_option('fifu_upload_proxy');
        $enable_upload_job = get_option('fifu_upload_job');
        $upload_private_proxy = self::opt_string('fifu_upload_private_proxy');
        $slider_left = self::opt_string('fifu_slider_left');
        $slider_right = self::opt_string('fifu_slider_right');
        $buy_text = get_option('fifu_buy_text');
        $buy_disclaimer = get_option('fifu_buy_disclaimer');
        $buy_cf = get_option('fifu_buy_cf');
        $enable_bbpress_fields = get_option('fifu_bbpress_fields');

        $license_key_masked = self::mask_tail(self::opt_string('fifu_key'), 6);
        $asin_partner_masked = self::mask_tail(self::opt_string('fifu_asin_credentials_partner'), 10);
        $asin_access_masked = self::mask_tail(self::opt_string('fifu_asin_credentials_access'), 15);
        $asin_secret_masked = self::mask_tail(self::opt_string('fifu_asin_credentials_secret'), 30);
        $woo_version = '';
        if (\function_exists('WC')) {
            $wc = WC();
            if (\is_object($wc) && isset($wc->version)) {
                $woo_version = self::opt_string_value($wc->version);
            }
        }
        $fifu_stats = new Fifu_Migration_Stats();

        $product_count = 0;
        if (\post_type_exists('product')) {
            $product_posts = \wp_count_posts('product');
            $product_count = (int) ($product_posts->publish ?? 0);
        }

        ob_start();
        include FIFU_ADMIN_DIR . '/html/support-data-content.php';
        $support_data = (string) ob_get_clean();

        include FIFU_ADMIN_DIR . '/html/support-data.html';
    }

    private static function opt_string(string $key): string
    {
        $value = get_option($key);
        return self::opt_string_value($value);
    }

    /**
     * @param mixed $value
     */
    private static function opt_string_value($value): string
    {
        if (is_string($value)) {
            return $value;
        }
        if (is_scalar($value)) {
            return (string) $value;
        }
        return '';
    }

    private static function mask_tail(string $value, int $count, string $maskChar = '*'): string
    {
        $length = strlen($value);
        if ($length <= $count) {
            return $value;
        }
        return substr($value, 0, $length - $count) . str_repeat($maskChar, $count);
    }

    private static function mask_vimeo_access_token(string $token): string
    {
        if ($token === '') {
            return '';
        }

        $visible = substr($token, 0, 3);

        return $visible . str_repeat('*', max(0, strlen($token) - 3));
    }

    public static function ajax_check_status_server(): void
    {
        check_ajax_referer('wp_rest', 'security');

        $option_value = get_option('fifu_status_server');
        if ($option_value !== false) {
            wp_send_json_success([ 'option_value' => $option_value ]);
        } else {
            wp_send_json_error();
        }
    }
}
