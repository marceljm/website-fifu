<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

final class Fifu_Admin_License_Page
{
    public static function render(): void
    {
        flush();

        $fifu = Fifu_Admin_Strings::get_settings_strings();

        wp_enqueue_style('fifu-base-ui-css', plugins_url('/admin/html/css/base-ui.css', FIFU_PLUGIN_FILE), [], Fifu_Plugin_Info::get_enqueue_version());
        wp_enqueue_style('fifu-menu-css', plugins_url('/admin/html/css/menu.css', FIFU_PLUGIN_FILE), [], Fifu_Plugin_Info::get_enqueue_version());
        wp_enqueue_script('fifu-menu-js', plugins_url('/admin/html/js/menu.js', FIFU_PLUGIN_FILE), ['jquery', 'jquery-ui'], Fifu_Plugin_Info::get_enqueue_version());

        wp_localize_script('fifu-menu-js', 'fifuScriptVars', [
            'restUrl' => esc_url_raw(rest_url()),
            'homeUrl' => esc_url_raw(home_url()),
            'nonce' => wp_create_nonce('wp_rest'),
            'wait' => $fifu['php']['message']['wait'](),
            'lock' => get_option('fifu_lock'),
            'emptyKey' => empty(get_option('fifu_key')),
            'expired' => get_option('fifu_expired'),
            'keyText' => $fifu['options']['key'](),
            'networkAdmin' => is_network_admin(),
        ]);

        $license_key = get_option('fifu_key');
        $email = get_option('fifu_email');

        include FIFU_ADMIN_DIR . '/html/license-key.html';

        if (Fifu_Settings_Manager::is_valid_nonce('nonce_fifu_form_key')) {
            // Fifu_Settings_Manager::update_single_option('fifu_input_key', 'fifu_key');
        }
    }
}
