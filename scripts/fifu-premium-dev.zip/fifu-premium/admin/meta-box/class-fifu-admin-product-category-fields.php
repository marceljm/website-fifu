<?php
declare(strict_types=1);

defined('ABSPATH') || exit;

/**
 * Admin UI for WooCommerce product category image and video fields.
 */
class Fifu_Admin_Product_Category_Fields
{

    /**
     * Register admin hooks for product category fields.
     */
    public static function register_hooks(): void
    {
        // UI.
        add_action('product_cat_edit_form_fields', [self::class, 'render_featured_media_edit_fields']);
        add_action('product_cat_add_form_fields', [self::class, 'render_featured_media_add_fields']);

        // Persistence (image and video) for WooCommerce product categories.
        add_action('created_product_cat', [self::class, 'save_image_meta'], 10, 1);
        add_action('edited_product_cat',  [self::class, 'save_image_meta'], 10, 1);

        add_action('created_product_cat', [self::class, 'save_video_meta'], 10, 1);
        add_action('edited_product_cat',  [self::class, 'save_video_meta'], 10, 1);
    }

    /**
     * Enqueue styles for product category edit/add forms.
     */
    private static function enqueue_assets(): void
    {
        $cssUrl = plugins_url('../html/css/category.css', __FILE__);
        wp_enqueue_style('fifu-category-css', $cssUrl, [], Fifu_Plugin_Info::get_enqueue_version());
    }

    public static function render_featured_media_add_fields(): void
    {
        self::render_featured_media(null);
    }

    public static function render_featured_media_edit_fields($term): void
    {
        self::render_featured_media($term);
    }

    private static function render_featured_media($term): void
    {
        self::enqueue_assets();
        $strings = Fifu_Meta_Box_Php_Strings::get_strings();
        $video_enabled = Fifu_Options_Utils::is_on('fifu_video');
        $selected = 'image';
        if ($video_enabled && is_object($term) && isset($term->term_id)) {
            $term_id = (int) $term->term_id;
            $video_url = (string) (Fifu_Term_Video_Read_Service::get_video_url($term_id) ?? '');
            if ($video_url === '' && class_exists('Fifu_Term_Custom_Video_Read_Service')) {
                $video_url = (string) (Fifu_Term_Custom_Video_Read_Service::get_custom_video_url($term_id) ?? '');
            }
            if ($video_url !== '') {
                $selected = 'video';
            }
        }

        echo '<tr class="fifu-category-featured-media-row"><td colspan="2">';
        echo '<div id="fifu-category-featured-media" class="fifu-featured-media-content">';
        echo '<div class="fifu-category-featured-media-header">'
            . '<span class="dashicons dashicons-camera" aria-hidden="true"></span> FIFU</div>';
        echo '<div class="fifu-featured-media-selector">';
        echo '<select id="fifu-category-featured-media-type" class="widefat" aria-label="'
            . esc_attr($strings['common']['media_type']()) . '" autocomplete="off">';
        echo '<option value="image"' . ($selected === 'image' ? ' selected="selected"' : '') . '>'
            . esc_html($strings['title']['post']['image']()) . '</option>';
        if ($video_enabled) {
            echo '<option value="video"' . ($selected === 'video' ? ' selected="selected"' : '') . '>'
                . esc_html($strings['title']['post']['video']()) . '</option>';
        }
        echo '</select></div>';

        $fifu_category_unified = true;
        $image_panel_style = $selected === 'image' ? '' : 'display:none;';
        echo '<div class="fifu-featured-media-panel" data-fifu-media-type="image" style="' . esc_attr($image_panel_style) . '">';
        self::render_image_fields($term);
        echo '</div>';
        if ($video_enabled) {
            $video_panel_style = $selected === 'video' ? '' : 'display:none;';
            echo '<div class="fifu-featured-media-panel" data-fifu-media-type="video" style="' . esc_attr($video_panel_style) . '">';
            self::render_video_fields($term);
            echo '</div>';
        }
        echo '</div></td></tr>';
    }

    private static function render_image_fields($term): void
    {
        if (is_object($term) && isset($term->term_id)) {
            self::render_image_edit_fields($term, true);
        } else {
            self::render_image_add_fields(true);
        }
    }

    private static function render_video_fields($term): void
    {
        if (is_object($term) && isset($term->term_id)) {
            self::render_video_edit_fields($term, true);
        } else {
            self::render_video_add_fields(true);
        }
    }

    /**
     * Render image fields on product category edit form.
     *
     * @param WP_Term $term
     */
    public static function render_image_edit_fields($term, bool $fifu_category_unified = false): void
    {
        self::enqueue_assets();

        $margin = 'margin-top:10px;';
        $width = 'width:100%;';
        $height = 'height:200px;';
        $align = 'text-align:left;';
        $url = $alt = null;

        if (is_object($term) && isset($term->term_id)) {
            $url = Fifu_Term_Image_Url_Read_Service::get_image_url((int) $term->term_id);
            $alt = Fifu_Term_Image_Alt_Read_Service::get_image_alt((int) $term->term_id);
        }

        if ($url) {
            $show_button = 'display:none;';
            $show_alt = $show_image = $show_link = '';
        } else {
            $show_button = '';
            $show_alt = $show_image = $show_link = 'display:none;';
        }

        $show_upload = Fifu_Options_Utils::is_on('fifu_upload_show') ? '' : 'display:none';
        $show_screenshot = Fifu_Options_Utils::is_on('fifu_screenshot') ? '' : 'display:none;';

        $fifu = Fifu_Meta_Box_Strings::get_featured_image_box_strings();
        include FIFU_ADMIN_DIR . '/html/category.html';
    }

    /**
     * Render image fields on product category add form.
     */
    public static function render_image_add_fields(bool $fifu_category_unified = false): void
    {
        self::enqueue_assets();

        $margin = 'margin-top:10px;';
        $width = 'width:100%;';
        $height = 'height:200px;';
        $align = 'text-align:left;';

        $show_button = $url = $alt = '';
        $show_alt = $show_image = $show_link = 'display:none;';
        $show_upload = Fifu_Options_Utils::is_on('fifu_upload_show') ? '' : 'display:none';
        $show_screenshot = Fifu_Options_Utils::is_on('fifu_screenshot') ? '' : 'display:none;';

        $fifu = Fifu_Meta_Box_Strings::get_featured_image_box_strings();
        include FIFU_ADMIN_DIR . '/html/category.html';
    }

    /**
     * Render video fields on product category edit form.
     *
     * @param WP_Term $term
     */
    public static function render_video_edit_fields($term, bool $fifu_category_unified = false): void
    {
        if (Fifu_Options_Utils::is_off('fifu_video')) {
            return;
        }

        $margin = 'margin-top:10px;';
        $width = 'width:100%;';
        $height = 'height:200px;';
        $align = 'text-align:left;';
        $show_video_local = 'display:none;';
        $show_video_custom = 'display:none;';
        $show_thumbnail = 'display:none;';
        $custom_thumbnail = '';

        $url = '';
        if (is_object($term) && isset($term->term_id)) {
            $term_id = (int) $term->term_id;
            $url = (string) (Fifu_Term_Video_Read_Service::get_video_url($term_id) ?? '');
            if ($url === '' && class_exists('Fifu_Term_Custom_Video_Read_Service')) {
                $url = (string) (Fifu_Term_Custom_Video_Read_Service::get_custom_video_url($term_id) ?? '');
            }
        }

        if ($url) {
            $show_button = 'display:none;';
            $show_video = $show_link = '';

            if (Fifu_Video_Helper::is_local_video($url)) {
                $show_video_local = '';
                $show_video = $show_video_custom = 'display:none;';
            } elseif (Fifu_Video_Helper::is_custom_video($url)) {
                $show_video_custom = '';
                $show_video = $show_video_local = 'display:none;';
                $show_thumbnail = '';

                if (class_exists('Fifu_Video_Oembed_Service')) {
                    $oembed = Fifu_Video_Oembed_Service::instance();
                    if (is_object($oembed) && method_exists($oembed, 'get_repository')) {
                        $repository = $oembed->get_repository();
                        if (is_object($repository) && method_exists($repository, 'get_image_url_by_video_url')) {
                            $custom_thumbnail = esc_url((string) ($repository->get_image_url_by_video_url($url) ?? ''));
                        }
                    }
                }
            }
        } else {
            $show_button = '';
            $show_video = $show_link = 'display:none;';
        }

        $fifu = Fifu_Meta_Box_Strings::get_featured_image_box_strings();
        include FIFU_ADMIN_DIR . '/html/category-video.html';
    }

    /**
     * Render video fields on product category add form.
     */
    public static function render_video_add_fields(bool $fifu_category_unified = false): void
    {
        if (Fifu_Options_Utils::is_off('fifu_video')) {
            return;
        }

        $margin = 'margin-top:10px;';
        $width = 'width:100%;';
        $height = 'height:200px;';
        $align = 'text-align:left;';

        $show_button = $url = '';
        $show_video = $show_video_local = $show_video_custom = $show_link = 'display:none;';
        $show_thumbnail = 'display:none;';
        $custom_thumbnail = '';

        $fifu = Fifu_Meta_Box_Strings::get_featured_image_box_strings();
        include FIFU_ADMIN_DIR . '/html/category-video.html';
    }

    /**
     * Persist image URL and ALT from the product category form into term meta.
     *
     * This mirrors the legacy behavior of fifu_ctgr_save_properties() but
     * uses the new FIFU_Term_Meta_Updater and attachment sync service.
     *
     * @param int $term_id The term ID.
     * @return void
     */
    public static function save_image_meta($term_id): void
    {
        $term_id = is_numeric($term_id) ? (int) $term_id : 0;
        if ($term_id <= 0) {
            return;
        }

        // Only handle WooCommerce product categories.
        if (!isset($_POST['taxonomy']) || $_POST['taxonomy'] !== 'product_cat') {
            return;
        }

        if (!class_exists('FIFU_Term_Meta_Updater')) {
            return;
        }

        $updater = FIFU_Term_Meta_Updater::instance();
        $hasImageAltPayload = isset($_POST['fifu_input_alt']);
        $hasImageUrlPayload = isset($_POST['fifu_input_url']);
        $hasExplicitVideoPayload = !Fifu_Options_Utils::is_off('fifu_video')
            && isset($_POST['fifu_video_input_url'])
            && trim((string) wp_unslash($_POST['fifu_video_input_url'])) !== '';
        $expectedImageAlt = null;
        $expectedImageUrl = null;

        if ($hasExplicitVideoPayload) {
            return;
        }

        // ALT.
        if ($hasImageAltPayload) {
            $alt_raw = wp_unslash((string) ($_POST['fifu_input_alt'] ?? ''));
            $alt     = sanitize_text_field($alt_raw);
            $expectedImageAlt = $alt === '' ? null : $alt;

            if ($alt === '') {
                $updater->delete($term_id, 'fifu_image_alt');
            } else {
                $updater->update_or_delete_term($term_id, 'fifu_image_alt', $alt);
            }
        }

        // URL.
        if ($hasImageUrlPayload) {
            $url_raw = wp_unslash((string) ($_POST['fifu_input_url'] ?? ''));
            $url     = esc_url_raw(rtrim($url_raw));
            $expectedImageUrl = $url === '' ? null : self::normalize_term_scalar(
                function_exists('fifu_convert') ? fifu_convert($url) : $url
            );

            if ($url === '') {
                $updater->update_or_delete_term($term_id, 'fifu_image_url', null);

                if (Fifu_Options_Utils::is_on('fifu_auto_category')) {
                    update_option('fifu_auto_category_created', false, 'no');

                    if (class_exists('Fifu_Auto_Category_Image_Service')) {
                        Fifu_Auto_Category_Image_Service::run();
                        update_option('fifu_auto_category_created', true, 'no');
                    }

                    if ((string) Fifu_Term_Image_Url_Read_Service::get_image_url($term_id) === '') {
                        $fallbackUrl = self::resolve_auto_category_image_url($term_id);
                        if ($fallbackUrl !== null && $fallbackUrl !== '') {
                            $updater->update_or_delete_term($term_id, 'fifu_image_url', $fallbackUrl);
                        }
                    }

                    if (class_exists('Fifu_Post_Attachment_Sync_Service')) {
                        Fifu_Post_Attachment_Sync_Service::sync_category_attachment($term_id);
                    }

                    return;
                } else {
                    update_option('fifu_auto_category_created', false, 'no');

        if (class_exists('Fifu_Post_Attachment_Sync_Service')) {
            Fifu_Post_Attachment_Sync_Service::sync_category_attachment($term_id);
        }

        return;
    }
            } else {
                // Passing null deletes the meta, non-empty URL is converted if needed.
                $updater->update_or_delete_term(
                    $term_id,
                    'fifu_image_url',
                    $url
                );
            }
        }

        // Keep the fake attachment in sync with the new term meta values.
        if (class_exists('Fifu_Post_Attachment_Sync_Service')) {
            Fifu_Post_Attachment_Sync_Service::sync_category_attachment($term_id);
            Fifu_Post_Attachment_Sync_Service::sync_theme_property_images($term_id);
        }

        self::cleanup_legacy_image_meta_after_db2_sync(
            $term_id,
            $expectedImageUrl,
            $hasImageUrlPayload,
            $expectedImageAlt,
            $hasImageAltPayload
        );
    }

    /**
     * Persist video URL from the product category form into term meta.
     *
     * This mirrors the legacy behavior of fifu_video_ctgr_save_properties()
     * while relying on the new term meta updater and attachment sync service.
     *
     * @param int $term_id The term ID.
     * @return void
     */
    public static function save_video_meta($term_id): void
    {
        $term_id = is_numeric($term_id) ? (int) $term_id : 0;
        if ($term_id <= 0) {
            return;
        }

        if (!isset($_POST['taxonomy']) || $_POST['taxonomy'] !== 'product_cat') {
            return;
        }

        if (Fifu_Options_Utils::is_off('fifu_video')) {
            return;
        }

        if (!isset($_POST['fifu_video_input_url'])) {
            return;
        }

        $url_raw = wp_unslash((string) ($_POST['fifu_video_input_url'] ?? ''));
        $url     = esc_url_raw(rtrim($url_raw));
        $expectedVideoUrl = $url === '' ? null : self::normalize_term_scalar($url);
        $posterRaw = isset($_POST['fifu_input_url']) ? wp_unslash((string) $_POST['fifu_input_url']) : '';
        $posterUrl = esc_url_raw(rtrim($posterRaw));
        $isCustomCategoryVideo = $posterUrl !== ''
            && (
                Fifu_Video_Helper::is_local_video($url)
                || Fifu_Video_Helper::is_custom_video($url)
            );

        if (class_exists('FIFU_Term_Meta_Updater')) {
            $updater = FIFU_Term_Meta_Updater::instance();
            if ($url === '') {
                $updater->update_or_delete_term($term_id, 'fifu_video_url', null);
                $updater->update_or_delete_term($term_id, 'fifu_custom_video_url', null);
                self::cleanup_category_video_legacy_meta($term_id);
            } elseif ($isCustomCategoryVideo) {
                if (!class_exists('Fifu_Developer_Media_Service')) {
                    require_once dirname(__DIR__, 2) . '/includes/api/class-fifu-developer-media-service.php';
                }
                $saved = Fifu_Developer_Media_Service::set_category_custom_video_with_poster($term_id, $url, $posterUrl, true);
                if (!$saved) {
                    return;
                }
            } else {
                if (!class_exists('Fifu_Developer_Media_Service')) {
                    require_once dirname(__DIR__, 2) . '/includes/api/class-fifu-developer-media-service.php';
                }
                $saved = Fifu_Developer_Media_Service::set_category_video($term_id, $url, true);
                if (!$saved) {
                    return;
                }
            }
        }

        if ($url === '' && class_exists('Fifu_Post_Attachment_Sync_Service')) {
            Fifu_Post_Attachment_Sync_Service::sync_category_attachment($term_id);
            Fifu_Post_Attachment_Sync_Service::sync_theme_property_images($term_id);
        }

        $expectedKeyType = $isCustomCategoryVideo ? 'custom_video' : 'video';
        self::cleanup_legacy_video_meta_after_db2_sync($term_id, $expectedVideoUrl, $expectedKeyType);
    }

    private static function cleanup_legacy_image_meta_after_db2_sync(
        int $termId,
        ?string $expectedImageUrl,
        bool $hasImageUrlPayload,
        ?string $expectedImageAlt,
        bool $hasImageAltPayload
    ): void {
        if (!function_exists('fifu_db2_manager')) {
            return;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return;
        }

        if ($hasImageUrlPayload) {
            $mapping = $manager->getTermMapping($termId, 'image');
            $db2ImageUrl = self::normalize_term_scalar(
                is_array($mapping) ? (string) ($mapping['url'] ?? '') : null
            );

            if ($db2ImageUrl === $expectedImageUrl) {
                delete_term_meta($termId, 'fifu_image_url');
            }
        }

        if ($hasImageAltPayload) {
            $mapping = $manager->getTermAltMapping($termId, 'image');
            $db2ImageAlt = self::normalize_term_scalar(
                is_array($mapping) ? (string) (($mapping['alt'] ?? $mapping['value'] ?? '')) : null
            );

            if ($db2ImageAlt === $expectedImageAlt) {
                delete_term_meta($termId, 'fifu_image_alt');
            }
        }
    }

    private static function cleanup_legacy_video_meta_after_db2_sync(int $termId, ?string $expectedVideoUrl, string $expectedKeyType = 'video'): void
    {
        if (!function_exists('fifu_db2_manager')) {
            return;
        }

        if (!in_array($expectedKeyType, ['video', 'custom_video'], true)) {
            return;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return;
        }

        $mapping = $manager->getTermMapping($termId, $expectedKeyType);
        $db2VideoUrl = self::normalize_term_scalar(
            is_array($mapping) ? (string) ($mapping['url'] ?? '') : null
        );

        if ($expectedVideoUrl === null) {
            if ($db2VideoUrl !== null) {
                return;
            }

            if ($expectedKeyType === 'video') {
                self::delete_term_meta_if_exists($termId, 'fifu_video_url');
            } else {
                self::delete_term_meta_if_exists($termId, 'fifu_custom_video_url');
                self::delete_term_meta_if_exists($termId, 'fifu_video_url');
            }

            return;
        }

        if ($db2VideoUrl === $expectedVideoUrl) {
            if ($expectedKeyType === 'video') {
                self::delete_term_meta_if_exists($termId, 'fifu_video_url');
            } else {
                self::delete_term_meta_if_exists($termId, 'fifu_custom_video_url');
                self::delete_term_meta_if_exists($termId, 'fifu_video_url');
            }
        }
    }

    private static function term_meta_exists(int $termId, string $key): bool
    {
        if (function_exists('metadata_exists')) {
            return metadata_exists('term', $termId, $key);
        }

        return trim((string) get_term_meta($termId, $key, true)) !== '';
    }

    private static function delete_term_meta_if_exists(int $termId, string $key): void
    {
        if (self::term_meta_exists($termId, $key)) {
            delete_term_meta($termId, $key);
        }
    }

    private static function cleanup_category_video_legacy_meta(int $termId): void
    {
        FIFU_Term_Meta_Updater::instance()->delete($termId, 'fifu_video_url');
        FIFU_Term_Meta_Updater::instance()->delete($termId, 'fifu_custom_video_url');
    }

    private static function normalize_term_scalar(?string $value): ?string
    {
        if ($value === null) {
            return null;
        }

        $value = trim($value);
        return $value === '' ? null : $value;
    }

    private static function resolve_auto_category_image_url(int $termId): ?string
    {
        global $wpdb;

        if ($termId <= 0) {
            return null;
        }

        $termTaxonomyId = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT term_taxonomy_id FROM {$wpdb->term_taxonomy} WHERE term_id = %d AND taxonomy = 'product_cat' LIMIT 1",
            $termId
        ));

        if ($termTaxonomyId <= 0) {
            return null;
        }

        $url = $wpdb->get_var($wpdb->prepare(
            "
            SELECT pm.meta_value
            FROM {$wpdb->term_relationships} tr
            INNER JOIN {$wpdb->posts} p ON p.ID = tr.object_id AND p.post_status <> 'trash'
            INNER JOIN {$wpdb->postmeta} pm
                ON pm.post_id = tr.object_id
               AND pm.meta_key = 'fifu_image_url'
               AND pm.meta_value IS NOT NULL
               AND pm.meta_value <> ''
            WHERE tr.term_taxonomy_id = %d
            ORDER BY tr.object_id ASC
            LIMIT 1
            ",
            $termTaxonomyId
        ));

        $url = self::normalize_term_scalar(is_string($url) ? $url : null);
        return $url;
    }
}
