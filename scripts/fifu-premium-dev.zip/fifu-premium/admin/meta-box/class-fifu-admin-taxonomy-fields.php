<?php
declare(strict_types=1);

defined('ABSPATH') || exit;

final class Fifu_Admin_Taxonomy_Fields
{
    public static function register_hooks(): void
    {
        if (Fifu_Options_Utils::is_off('fifu_taxonomy')) {
            return;
        }

        $taxonomies = get_taxonomies();
        foreach ($taxonomies as $taxonomy) {
            if ($taxonomy === 'product_cat') {
                continue;
            }

            add_action("{$taxonomy}_add_form_fields", [self::class, 'add_form_fields']);
            add_action("{$taxonomy}_edit_form_fields", [self::class, 'edit_form_fields']);
            add_action("created_{$taxonomy}", [self::class, 'save_taxonomy_meta'], 10, 2);
            add_action("edited_{$taxonomy}", [self::class, 'save_taxonomy_meta'], 10, 2);
        }
    }

    public static function add_form_fields($taxonomy): void
    {
        if (!is_string($taxonomy)) {
            return;
        }

        if (!class_exists('Fifu_Admin_Product_Category_Fields')) {
            return;
        }

        Fifu_Admin_Product_Category_Fields::render_image_add_fields();
        Fifu_Admin_Product_Category_Fields::render_video_add_fields();
    }

    public static function edit_form_fields($term): void
    {
        if (!class_exists('Fifu_Admin_Product_Category_Fields')) {
            return;
        }

        Fifu_Admin_Product_Category_Fields::render_image_edit_fields($term);
        Fifu_Admin_Product_Category_Fields::render_video_edit_fields($term);
    }

    public static function save_taxonomy_meta($termId, $ttId): void
    {
        unset($ttId);

        $termId = is_numeric($termId) ? (int) $termId : 0;

        if ($termId <= 0) {
            return;
        }

        if (isset($_POST['taxonomy']) && $_POST['taxonomy'] === 'product_cat') {
            return;
        }

        $hasImageAltPayload = isset($_POST['fifu_input_alt']);
        $hasImageUrlPayload = isset($_POST['fifu_input_url']);
        $expectedImageAlt = null;
        $expectedImageUrl = null;
        $urlRaw = $hasImageUrlPayload ? wp_unslash((string) ($_POST['fifu_input_url'] ?? '')) : '';
        $url = $hasImageUrlPayload ? esc_url_raw(rtrim($urlRaw)) : '';

        if (class_exists('FIFU_Term_Meta_Updater')) {
            $updater = FIFU_Term_Meta_Updater::instance();

            if ($hasImageAltPayload && (!$hasImageUrlPayload || trim($urlRaw) !== '')) {
                $altRaw = wp_unslash((string) ($_POST['fifu_input_alt'] ?? ''));
                $alt = sanitize_text_field($altRaw);
                $expectedImageAlt = $alt === '' ? null : $alt;

                if ($alt === '') {
                    $updater->delete($termId, 'fifu_image_alt');
                } else {
                    $updater->update_or_delete_term($termId, 'fifu_image_alt', $alt);
                }
            }

            if ($hasImageUrlPayload) {
                $normalizedUrl = $url === '' ? null : (function_exists('fifu_convert') ? fifu_convert($url) : $url);
                $expectedImageUrl = self::normalize_term_scalar(is_string($normalizedUrl) ? $normalizedUrl : null);

                $updater->update_or_delete_term($termId, 'fifu_image_url', $url === '' ? null : $url);
            }
        }

        if (class_exists('Fifu_Post_Attachment_Sync_Service')) {
            Fifu_Post_Attachment_Sync_Service::sync_category_attachment($termId);
            Fifu_Post_Attachment_Sync_Service::sync_theme_property_images($termId);
        }

        self::cleanup_legacy_image_meta_after_db2_sync(
            $termId,
            $expectedImageUrl,
            $hasImageUrlPayload,
            $expectedImageAlt,
            $hasImageAltPayload
        );
    }

    private static function cleanup_legacy_image_meta_after_db2_sync(
        int $termId,
        ?string $expectedImageUrl,
        bool $hasImageUrlPayload,
        ?string $expectedImageAlt,
        bool $hasImageAltPayload
    ): void {
        if (!function_exists('fifu_db2_manager')) {
            return;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return;
        }

        if ($hasImageUrlPayload) {
            $mapping = $manager->getTermMapping($termId, 'image');
            $db2ImageUrl = self::normalize_term_scalar(
                is_array($mapping) ? (string) ($mapping['url'] ?? '') : null
            );

            if ($db2ImageUrl === $expectedImageUrl) {
                delete_term_meta($termId, 'fifu_image_url');
            }
        }

        if ($hasImageAltPayload) {
            $mapping = $manager->getTermAltMapping($termId, 'image');
            $db2ImageAlt = self::normalize_term_scalar(
                is_array($mapping) ? (string) (($mapping['alt'] ?? $mapping['value'] ?? '')) : null
            );

            if ($db2ImageAlt === $expectedImageAlt) {
                delete_term_meta($termId, 'fifu_image_alt');
            }
        }
    }

    private static function normalize_term_scalar(?string $value): ?string
    {
        if ($value === null) {
            return null;
        }

        $value = trim($value);
        return $value === '' ? null : $value;
    }
}
