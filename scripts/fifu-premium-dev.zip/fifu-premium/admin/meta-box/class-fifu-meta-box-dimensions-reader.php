<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

final class Fifu_Meta_Box_Dimensions_Reader
{
    /**
     * Reads the main image width stored in the submitted request.
     */
    public static function get_main_image_width(array $request): ?int
    {
        if (isset($request['fifu_input_url'], $request['fifu_input_image_width']) && $request['fifu_input_url']) {
            return self::sanitize_numeric_dimension($request['fifu_input_image_width']);
        }

        if (isset($request['fifu_video_input_url'], $request['fifu_video_input_image_width']) && $request['fifu_video_input_url']) {
            return self::sanitize_numeric_dimension($request['fifu_video_input_image_width']);
        }

        return null;
    }

    /**
     * Reads the main image height stored in the submitted request.
     */
    public static function get_main_image_height(array $request): ?int
    {
        if (isset($request['fifu_input_url'], $request['fifu_input_image_height']) && $request['fifu_input_url']) {
            return self::sanitize_numeric_dimension($request['fifu_input_image_height']);
        }

        if (isset($request['fifu_video_input_url'], $request['fifu_video_input_image_height']) && $request['fifu_video_input_url']) {
            return self::sanitize_numeric_dimension($request['fifu_video_input_image_height']);
        }

        return null;
    }

    /**
     * Reads slider dimension metadata from the request payload.
     */
    public static function get_slider_dimensions(array $request, string $dimension): array
    {
        return self::collect_dimension_values($request, 'inputHiddenSliderListIds', 'fifu_slider_input_', $dimension);
    }

    /**
     * Reads image gallery dimension metadata from the request payload.
     */
    public static function get_image_gallery_dimensions(array $request, string $dimension): array
    {
        return self::collect_dimension_values($request, 'inputHiddenImageListIds', 'fifu_input_', $dimension);
    }

    /**
     * Reads video gallery dimension metadata from the request payload.
     */
    public static function get_video_gallery_dimensions(array $request, string $dimension): array
    {
        return self::collect_dimension_values($request, 'inputHiddenVideoListIds', 'fifu_video_input_', $dimension);
    }

    /**
     * Sanitizes a numeric dimension value, returning null when it is empty.
     */
    private static function sanitize_numeric_dimension($value): ?int
    {
        $value = wp_strip_all_tags($value);
        if ($value === '') {
            return null;
        }
        return (int) $value;
    }

    /**
     * Collects dimension inputs from the provided request.
     */
    private static function collect_dimension_values(array $request, string $list_key, string $input_prefix, string $dimension): array
    {
        if (!isset($request[$list_key])) {
            return [];
        }

        $list = $request[$list_key];
        if (!$list && $list != '0') {
            return [];
        }

        $indexes = explode('|', $list);
        $values = [];
        foreach ($indexes as $index) {
            $input_key = $input_prefix . $dimension . '_' . $index;
            if (isset($request[$input_key])) {
                $values[] = wp_strip_all_tags($request[$input_key]);
            }
        }

        return $values;
    }
}
