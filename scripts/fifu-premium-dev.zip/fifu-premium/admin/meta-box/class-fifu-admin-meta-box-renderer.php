<?php

if (!defined('ABSPATH')) {
    exit;
}

class Fifu_Admin_Meta_Box_Renderer {

    private static function get_attachment_alt(int $attachment_id): string {
        $alt = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
        return is_string($alt) ? $alt : '';
    }

    /**
     * Returns ordered gallery URLs without depending on contiguous indexes.
     *
     * @param int $post_id
     * @return array<int,string>
     */
    private static function get_gallery_urls(int $post_id): array {
        $gallery_repo = new Fifu_Product_Gallery_Repository();
        $rows = $gallery_repo->get_image_gallery_urls($post_id);

        $urls = [];
        foreach ($rows as $row) {
            $url = trim((string) ($row->url ?? $row->meta_value ?? ''));
            if ($url === '') {
                continue;
            }

            $urls[] = $url;
        }

        if ($urls !== []) {
            return $urls;
        }

        $legacy_meta = get_post_meta($post_id);
        $legacy_rows = [];
        foreach ($legacy_meta as $meta_key => $values) {
            if (!preg_match('/^fifu_image_url_(\d+)$/', (string) $meta_key, $matches)) {
                continue;
            }

            $value = $values[0] ?? '';
            if (!is_string($value) || trim($value) === '') {
                continue;
            }

            $legacy_rows[(int) $matches[1]] = $value;
        }

        ksort($legacy_rows, SORT_NUMERIC);
        foreach ($legacy_rows as $value) {
            $urls[] = $value;
        }

        return $urls;
    }

    /**
     * Returns ordered gallery ALTs without depending on contiguous indexes.
     *
     * @param int $post_id
     * @return array<int,string>
     */
    private static function get_gallery_alts(int $post_id): array {
        $gallery_repo = new Fifu_Product_Gallery_Repository();
        $rows = $gallery_repo->get_gallery_alts($post_id);

        $alts = [];
        foreach ($rows as $row) {
            $alt = trim((string) ($row->alt ?? $row->meta_value ?? ''));
            $alts[] = $alt;
        }

        if ($alts !== []) {
            return $alts;
        }

        $legacy_meta = get_post_meta($post_id);
        $legacy_rows = [];
        foreach ($legacy_meta as $meta_key => $values) {
            if (!preg_match('/^fifu_image_url_(\d+)$/', (string) $meta_key, $matches)) {
                continue;
            }

            $url = $values[0] ?? '';
            if (!is_string($url) || trim($url) === '') {
                continue;
            }

            $legacy_index = (int) $matches[1];
            $alt_values = $legacy_meta['fifu_image_alt_' . $legacy_index] ?? [''];
            $legacy_rows[$legacy_index] = is_string($alt_values[0] ?? '') ? (string) $alt_values[0] : '';
        }

        ksort($legacy_rows, SORT_NUMERIC);
        foreach ($legacy_rows as $value) {
            $alts[] = $value;
        }

        return $alts;
    }

    public static function render_featured_media_box($post): void {
        if (!($post instanceof WP_Post)) {
            return;
        }

        $available_types = self::get_available_featured_media_types();
        $selected_type = self::get_initial_featured_media_type((int) $post->ID);
        if (!in_array($selected_type, $available_types, true)) {
            $selected_type = $available_types[0];
        }

        $php_strings = Fifu_Meta_Box_Php_Strings::get_strings();
        $meta_box_strings = Fifu_Meta_Box_Strings::get_featured_image_box_strings();
        $labels = [
            'image' => $php_strings['title']['post']['image'](),
            'video' => $php_strings['title']['post']['video'](),
            'slider' => $php_strings['title']['post']['slider'](),
            'audio' => $php_strings['title']['post']['audio'](),
        ];

        echo '<div class="fifu-featured-media-content">';
        if (Fifu_Options_Utils::is_on('fifu_debug') && isset($post->ID)) {
            echo '<button id="fifu-copy-debug-data-editor-button"'
                . ' class="fifu-quick-button fifu-copy-debug-data-button"'
                . ' type="button"'
                . ' onclick="fifu_copy_quick_edit_debug_data('
                . (int) $post->ID
                . ', this, false)">'
                . '<span class="dashicons dashicons-clipboard fifu-copy-debug-data-icon" aria-hidden="true"></span>'
                . '<span class="fifu-copy-debug-data-label">'
                . esc_html($meta_box_strings['common']['copy_debug_data']())
                . '</span>'
                . '</button>';
        }
        echo '<div class="fifu-featured-media-selector">';
        echo '<select id="fifu-featured-media-type"'
            . ' class="widefat"'
            . ' aria-label="' . esc_attr($php_strings['common']['media_type']()) . '"'
            . ' autocomplete="off">';

        foreach ($available_types as $type) {
            echo '<option value="' . esc_attr($type) . '"'
                . ($selected_type === $type ? ' selected="selected"' : '')
                . '>'
                . esc_html($labels[$type])
                . '</option>';
        }

        echo '</select>';
        echo '</div>';

        foreach ($available_types as $type) {
            $style = $selected_type === $type ? '' : 'display:none;';
            echo '<div class="fifu-featured-media-panel" data-fifu-media-type="'
                . esc_attr($type)
                . '" style="'
                . esc_attr($style)
                . '">';

            if ($type === 'image') {
                self::render_featured_image_box($post);
            } elseif ($type === 'video') {
                self::render_video_box($post);
            } elseif ($type === 'slider') {
                self::render_slider_box($post);
            } elseif ($type === 'audio') {
                self::render_audio_box($post);
            }

            echo '</div>';
        }

        if (($post->post_type ?? '') === 'product') {
            $gallery_style = in_array($selected_type, ['image', 'video'], true)
                ? ''
                : 'display:none;';

            echo '<div class="fifu-featured-media-galleries" style="'
                . esc_attr($gallery_style)
                . '">';
            echo '<section class="fifu-featured-media-mixed-gallery">';
            echo '<div class="fifu-featured-media-gallery-divider">'
                . '<span>'
                . esc_html($php_strings['title']['product']['gallery']())
                . '</span>'
                . '</div>';
            self::render_woo_mixed_gallery_box($post, $selected_type);
            echo '</section>';

            echo '</div>';
        }

        echo '</div>';
    }

    /**
     * Resolve the editor's initial type from current FIFU media state.
     *
     * This method is editor-only. It does not persist or change frontend state.
     */
    public static function get_initial_featured_media_type(int $post_id): string {
        if (!class_exists('Fifu_Post_Featured_Media_State_Resolver', false)) {
            $resolver_file = dirname(__DIR__, 2)
                . '/includes/meta/class-fifu-post-featured-media-state-resolver.php';

            if (is_file($resolver_file)) {
                require_once $resolver_file;
            }
        }

        if (class_exists('Fifu_Post_Featured_Media_State_Resolver', false)) {
            return Fifu_Post_Featured_Media_State_Resolver::resolve_editor_type($post_id);
        }

        return 'image';
    }

    /**
     * @return string[]
     */
    private static function get_available_featured_media_types(): array {
        $types = ['image'];

        if (Fifu_Options_Utils::is_on('fifu_video')) {
            $types[] = 'video';
            $types[] = 'audio';
        }

        if (Fifu_Options_Utils::is_on('fifu_slider')) {
            $types[] = 'slider';
        }

        return $types;
    }

    public static function render_featured_image_box( $post ): void {
        if (!($post instanceof WP_Post)) {
            return;
        }
        $margin = 'margin-top:5px;margin-left:3px;';
        $width = 'width:100%;';
        $height = 'height:150px;';
        $align = 'text-align:left;';

        $url = esc_url(Fifu_Post_Image_Url_Read_Service::get_image_url((int) $post->ID) ?? '');
        $alt = esc_attr(Fifu_Post_Image_Alt_Read_Service::get_image_alt((int) $post->ID));
        $display_url = $url;
        $display_input_url = $url;
        $display_alt = $alt;
        $is_native_preview_only = false;
        $native_preview_url = '';
        $native_preview_alt = '';

        if ($url) {
            $show_button = 'display:none;';
            $show_alt = $show_image = $show_link = '';
        } else {
            $show_alt = $show_link = 'display:none;';
            $show_image = 'display:none;';
            $show_button = '';
        }

        $show_upload = Fifu_Options_Utils::is_on('fifu_upload_show') ? '' : 'display:none';
        $show_screenshot = Fifu_Options_Utils::is_on('fifu_screenshot') ? '' : 'display:none;';
        $fifu = Fifu_Meta_Box_Strings::get_featured_image_box_strings();
        include FIFU_ADMIN_DIR . '/html/meta-box.html';
    }


    public static function render_asin_box( $post ): void {
        if (!($post instanceof WP_Post)) {
            return;
        }
        $fifu = Fifu_Meta_Box_Strings::get_featured_image_box_strings();
        $input_style = 'width:100%;font-size:13px;';
        $asin = esc_attr(Fifu_Post_Identifier_Read_Service::get_asin((int) $post->ID));
        $show_asin = $asin ? '' : 'display:none;';
        include FIFU_ADMIN_DIR . '/html/meta-box-asin.html';
    }

    public static function render_finder_box( $post ): void {
        if (!($post instanceof WP_Post)) {
            return;
        }
        $fifu = Fifu_Meta_Box_Strings::get_featured_image_box_strings();
        $input_style = 'width:100%;font-size:13px;';
        $finder = esc_url((string) (Fifu_Post_Finder_Read_Service::get_finder_url((int) $post->ID) ?? ''));
        $show_finder = $finder ? '' : 'display:none;';
        include FIFU_ADMIN_DIR . '/html/meta-box-finder.html';
    }

    public static function render_audio_box( $post ): void {
        if (!($post instanceof WP_Post)) {
            return;
        }
        $fifu = Fifu_Meta_Box_Strings::get_featured_image_box_strings();
        $input_style = 'width:100%;font-size:13px;';
        $audio = esc_url((string) (Fifu_Post_Audio_Read_Service::get_audio_url((int) $post->ID) ?? ''));
        $thumbnail = esc_url(
            (string) (Fifu_Post_Image_Url_Read_Service::get_image_url((int) $post->ID) ?? '')
        );
        $show_audio = $audio ? '' : 'display:none;';
        $show_audio_button = $audio ? 'display:none;' : '';
        include FIFU_ADMIN_DIR . '/html/meta-box-audio.html';
    }

    public static function render_redirection_box( $post ): void {
        if (!($post instanceof WP_Post)) {
            return;
        }
        $fifu = Fifu_Meta_Box_Strings::get_featured_image_box_strings();
        $input_style = 'width:100%;font-size:13px;';
        $redirection = esc_url((string) (Fifu_Post_Redirection_Read_Service::get_redirection_url((int) $post->ID) ?? ''));
        $show_redirection = $redirection ? '' : 'display:none;';
        include FIFU_ADMIN_DIR . '/html/meta-box-redirection.html';
    }

    public static function render_popup_box( $post ): void {
        if (!($post instanceof WP_Post)) {
            return;
        }
        $fifu = Fifu_Meta_Box_Strings::get_featured_image_box_strings();
        $input_style = 'width:100%;font-size:13px;';
        $popup = get_post_meta($post->ID, 'fifu_popup_html', true);
        $show_popup = $popup ? '' : 'display:none;';
        include FIFU_ADMIN_DIR . '/html/meta-box-popup.html';
    }

    public static function render_video_box( $post ): void {
        if (!($post instanceof WP_Post)) {
            return;
        }
        $margin = 'margin-top:10px;';
        $width = 'width:100%;';
        $height = 'height:150px;';
        $align = 'text-align:left;';

        $url = esc_url((string) (Fifu_Post_Video_Read_Service::get_video_url((int) $post->ID) ?? ''));
        if (!$url) {
        $url = esc_url((string) (Fifu_Post_Custom_Video_Read_Service::get_custom_video_url((int) $post->ID) ?? ''));
        }

        $is_custom_video = $url && Fifu_Video_Helper::is_custom_video($url);
        $show_thumbnail = $is_custom_video ? '' : 'display:none;';

        if ($url) {
            $show_button = 'display:none;';
            $show_video = $show_link = '';
            if (Fifu_Video_Helper::is_local_video($url)) {
                $show_video_local = '';
                $show_video = $show_video_custom = 'display:none;';
            } else if (Fifu_Video_Helper::is_custom_video($url) || strpos($url, 'm3u8') !== false) {
                $show_video_custom = '';
                $show_video = $show_video_local = 'display:none;';
            } else {
                $show_video = '';
                $show_video_local = $show_video_custom = 'display:none;';
            }
        } else {
            $show_video = $show_video_local = $show_video_custom = $show_link = 'display:none;';
            $show_button = '';
        }

        $custom_thumbnail = '';
        if ($is_custom_video) {
            $poster_url = Fifu_Video_Oembed_Service::instance()
                ->get_repository()
                ->get_image_url_by_video_url((string) $url);
            if (!is_string($poster_url) || trim($poster_url) === '') {
                $poster_url = Fifu_Post_Image_Url_Read_Service::get_image_url((int) $post->ID);
            }
            $custom_thumbnail = esc_url((string) ($poster_url ?? ''));
        }

        $fifu = Fifu_Meta_Box_Strings::get_featured_image_box_strings();
        include FIFU_ADMIN_DIR . '/html/meta-box-video.html';
    }

    public static function render_woo_gallery_box( $post ): void {
        if (!($post instanceof WP_Post)) {
            return;
        }
        $fifu = Fifu_Meta_Box_Strings::get_featured_image_box_strings();

        $urls = [];
        $alts = [];
        $ifms = [];
        $native_urls = [];
        $native_ids = [];
        $native_alts = [];
        $native_ifms = [];
        $gallery_urls = array_values(self::get_gallery_urls((int) $post->ID));
        $gallery_alts = array_values(self::get_gallery_alts((int) $post->ID));

        foreach ($gallery_urls as $gallery_index => $url) {
            $urls[$gallery_index] = esc_url($url);
            $alts[$gallery_index] = esc_attr($gallery_alts[$gallery_index] ?? '');
            $ifms[$gallery_index] = (string) Fifu_Post_Image_Ifm_Read_Service::get_image_ifm_url(
                (int) $post->ID,
                (int) $gallery_index
            );
        }

        wp_enqueue_script('woo-meta-box-js', plugins_url('/admin/html/js/woo-meta-box.js', FIFU_PLUGIN_FILE), array('jquery', 'fifu-shared-js'), Fifu_Plugin_Info::get_enqueue_version());
        wp_localize_script('woo-meta-box-js', 'fifuBoxImageVars', [
            'urls' => $urls,
            'alts' => $alts,
            'ifms' => $ifms,
            'nativeIds' => $native_ids,
            'nativeUrls' => $native_urls,
            'nativeAlts' => $native_alts,
            'nativeIfms' => $native_ifms,
            'hasRealFifuGallery' => $urls !== [],
            'hasNativePreviewGallery' => $native_urls !== [],
            'text_url' => $fifu['image']['url'](),
            'text_alt' => $fifu['image']['alt'](),
            'text_ifm' => $fifu['image']['ifm'](),
            'text_ok' => $fifu['image']['ok'](),
            'text_remove_image' => $fifu['image']['remove'](),
            'text_remove_video' => $fifu['video']['remove'](),
        ]);

        include FIFU_ADMIN_DIR . '/html/woo-meta-box.html';
    }

    public static function render_woo_video_gallery_box( $post ): void {
        if (!($post instanceof WP_Post)) {
            return;
        }
        $fifu = Fifu_Meta_Box_Strings::get_featured_image_box_strings();

        $video_urls = array();
        $image_urls = array();

        $i = 0;
        while (true) {
            $video_url = Fifu_Post_Video_Gallery_Read_Service::get_video_url(
                (int) $post->ID,
                (int) $i
            );
            if (!$video_url) {
                break;
            }

            $image_url = Fifu_Video_Helper::get_thumbnail_large($video_url);

            $video_urls[$i] = esc_url($video_url);
            $image_urls[$i] = esc_url($image_url ?? '');
            $i++;
        }

        wp_enqueue_script('woo-video-meta-box-js', plugins_url('/admin/html/js/woo-video-meta-box.js', FIFU_PLUGIN_FILE), array('jquery'), Fifu_Plugin_Info::get_enqueue_version());
        wp_localize_script('woo-video-meta-box-js', 'fifuVideoVars', [
            'restUrl' => esc_url_raw(rest_url()),
            'homeUrl' => esc_url_raw(home_url()),
            'nonce' => wp_create_nonce('wp_rest'),
            'videoUrls' => $video_urls,
            'imageUrls' => $image_urls,
            'text_url' => $fifu['video']['url'](),
            'text_ok' => $fifu['video']['ok'](),
        ]);

        include FIFU_ADMIN_DIR . '/html/woo-meta-box-video.html';
    }

    /**
     * Renders the product-editor-only mixed gallery.
     *
     * The image and video arrays remain independent. The JavaScript controller
     * only combines them for display and serializes the existing field names.
     */
    public static function render_woo_mixed_gallery_box($post, ?string $selectedType = null): void
    {
        if (!($post instanceof WP_Post)) {
            return;
        }

        $postId = (int) $post->ID;
        $videoEnabled = Fifu_Options_Utils::is_on('fifu_video');
        $images = self::get_mixed_product_image_items($postId);
        $videos = $videoEnabled ? self::get_mixed_product_video_items($postId) : [];
        $selectedType = $selectedType ?? self::get_initial_featured_media_type($postId);
        if (!in_array($selectedType, ['image', 'video'], true)) {
            $selectedType = 'image';
        }

        $fifu = Fifu_Meta_Box_Strings::get_featured_image_box_strings();
        wp_enqueue_script(
            'woo-mixed-meta-box-js',
            plugins_url('/admin/html/js/woo-mixed-meta-box.js', FIFU_PLUGIN_FILE),
            ['jquery', 'jquery-ui-sortable', 'fifu-video-util-js', 'fifu-convert-url-js', 'fifu-shared-js'],
            Fifu_Plugin_Info::get_enqueue_version()
        );
        wp_localize_script('woo-mixed-meta-box-js', 'fifuMixedGalleryVars', [
            'restUrl' => esc_url_raw(rest_url()),
            'homeUrl' => esc_url_raw(home_url()),
            'nonce' => wp_create_nonce('wp_rest'),
            'images' => $images,
            'videos' => $videos,
            'selectedType' => $selectedType,
            'videoEnabled' => $videoEnabled,
            'text_image_video_url' => $fifu['placeholder']['image-video'](),
            'text_image_url' => $fifu['image']['url'](),
            'text_video_url' => $fifu['video']['url'](),
            'text_alt' => $fifu['image']['alt'](),
            'text_ifm' => $fifu['image']['ifm'](),
            'text_ok' => $fifu['image']['ok'](),
        ]);

        include FIFU_ADMIN_DIR . '/html/woo-meta-box-mixed.html';
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private static function get_mixed_product_image_items(int $postId): array
    {
        $galleryRepo = new Fifu_Product_Gallery_Repository();
        $imageRows = method_exists($galleryRepo, 'get_image_gallery_urls')
            ? $galleryRepo->get_image_gallery_urls($postId)
            : [];
        $altRows = method_exists($galleryRepo, 'get_gallery_alts')
            ? $galleryRepo->get_gallery_alts($postId)
            : [];

        $alts = [];
        $nextAltIndex = 0;
        foreach ($altRows as $row) {
            $alt = trim((string) ($row->alt ?? $row->meta_value ?? ''));
            $rowIndex = null;
            if (isset($row->index) && is_numeric($row->index)) {
                $rowIndex = (int) $row->index;
                if ($rowIndex > 0) {
                    $rowIndex--;
                }
            } elseif (preg_match('/fifu_image_alt_(\d+)$/', (string) ($row->meta_key ?? ''), $matches)) {
                $rowIndex = (int) $matches[1];
            }

            if ($rowIndex === null) {
                $rowIndex = $nextAltIndex;
            }
            $alts[$rowIndex] = $alt;
            $nextAltIndex = max($nextAltIndex, $rowIndex + 1);
        }

        $items = [];
        $seenUrls = [];
        $nativeGallery = (string) get_post_meta($postId, '_product_image_gallery', true);
        $nativeIds = preg_split('/\s*,\s*/', trim($nativeGallery), -1, PREG_SPLIT_NO_EMPTY);
        if (is_array($nativeIds)) {
            foreach ($nativeIds as $nativeId) {
                $nativeId = (int) $nativeId;
                if ($nativeId <= 0 || self::is_fifu_owned_attachment($nativeId)) {
                    continue;
                }

                $nativeUrl = trim((string) wp_get_attachment_url($nativeId));
                if ($nativeUrl === '' || isset($seenUrls[$nativeUrl])) {
                    continue;
                }

                $seenUrls[$nativeUrl] = true;
                $items[] = [
                    'id' => 'native-image-' . $nativeId,
                    'slot' => count($items),
                    'type' => 'image',
                    'url' => '',
                    'alt' => self::get_attachment_alt($nativeId),
                    'ifm' => '',
                    'width' => '',
                    'height' => '',
                    'imageSrc' => '',
                    'source' => 'native-preview',
                    'nativeAttachmentId' => $nativeId,
                    'nativePreviewUrl' => $nativeUrl,
                    'nativePreviewAlt' => self::get_attachment_alt($nativeId),
                    'nativePreviewIfm' => '',
                ];
            }
        }

        $imageIndex = 0;
        foreach ($imageRows as $row) {
            $url = trim((string) ($row->url ?? $row->meta_value ?? ''));
            if ($url === '' || isset($seenUrls[$url])) {
                continue;
            }

            $seenUrls[$url] = true;
            $items[] = [
                'id' => 'image-' . $imageIndex,
                'slot' => count($items),
                'type' => 'image',
                'url' => esc_url($url),
                'alt' => esc_attr($alts[$imageIndex] ?? ''),
                'ifm' => (string) Fifu_Post_Image_Ifm_Read_Service::get_image_ifm_url($postId, $imageIndex),
                'width' => '',
                'height' => '',
                'imageSrc' => '',
                'source' => 'fifu',
                'nativeAttachmentId' => 0,
                'nativePreviewUrl' => '',
                'nativePreviewAlt' => '',
                'nativePreviewIfm' => '',
            ];
            $imageIndex++;
        }

        return $items;
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private static function get_mixed_product_video_items(int $postId): array
    {
        $galleryRepo = new Fifu_Product_Gallery_Repository();
        $rows = method_exists($galleryRepo, 'get_gallery_urls')
            ? $galleryRepo->get_gallery_urls($postId)
            : [];
        $items = [];
        $videoIndex = 0;

        foreach ($rows as $row) {
            $type = trim((string) ($row->type ?? $row->scope ?? ''));
            $metaKey = (string) ($row->meta_key ?? '');
            if ($type === '' && preg_match('/^fifu_video_url_(\d+)$/', $metaKey)) {
                $type = 'video';
            }
            if ($type !== 'video') {
                continue;
            }
            if (isset($row->index) && is_numeric($row->index) && (int) $row->index <= 0) {
                continue;
            }

            $url = trim((string) ($row->url ?? $row->meta_value ?? ''));
            if ($url === '') {
                continue;
            }

            $items[] = [
                'id' => 'video-' . $videoIndex,
                'slot' => $videoIndex,
                'type' => 'video',
                'url' => esc_url($url),
                'alt' => '',
                'ifm' => '',
                'width' => '',
                'height' => '',
                'imageSrc' => esc_url((string) (Fifu_Video_Helper::get_thumbnail_large($url) ?? '')),
                'source' => 'fifu',
                'nativeAttachmentId' => 0,
                'nativePreviewUrl' => '',
                'nativePreviewAlt' => '',
                'nativePreviewIfm' => '',
            ];
            $videoIndex++;
        }

        return $items;
    }

    private static function is_fifu_owned_attachment(int $attachmentId): bool
    {
        if (function_exists('fifu_is_fifu_attachment')) {
            return (bool) fifu_is_fifu_attachment($attachmentId);
        }

        if (function_exists('fifu_attachment_repository')) {
            $repository = fifu_attachment_repository();
            if (is_object($repository) && method_exists($repository, 'is_fifu_attachment')) {
                return (bool) $repository->is_fifu_attachment($attachmentId);
            }
        }

        return false;
    }

    /**
     * Entry point that renders both gallery and video controls for WooCommerce products.
     */
    public static function render_wc_elements($post): void
    {
        if (!$post instanceof WP_Post) {
            $post = get_post($post);
        }
        if (!$post instanceof WP_Post) {
            return;
        }

        self::render_woo_gallery_box($post);
        self::render_woo_video_gallery_box($post);
    }

    public static function render_slider_box( $post ): void {
        if (!($post instanceof WP_Post)) {
            return;
        }
        $ratio = esc_attr(get_post_meta($post->ID, 'fifu_slider_ratio', true));
        $is_product = ($post->post_type ?? '') === 'product';

        $fifu = Fifu_Meta_Box_Strings::get_featured_image_box_strings();
        $show_slider_upload_button = Fifu_Options_Utils::is_on('fifu_upload_show') && $is_product;

        $urls = array();
        $alts = array();

        $i = 0;
        while (true) {
            $url = Fifu_Post_Slider_Image_Url_Read_Service::get_slider_image_url(
                (int) $post->ID,
                (int) $i
            );
            $alt = Fifu_Post_Slider_Image_Alt_Read_Service::get_slider_image_alt(
                (int) $post->ID,
                (int) $i
            );
            if (!$url) {
                break;
            }

            $urls[$i] = esc_url($url);
            $alts[$i] = esc_attr($alt);
            $i++;
        }

        $slider_upload_style = ($show_slider_upload_button && !empty($urls)) ? '' : 'display:none;';

        wp_enqueue_script(
            'slider-meta-box-js',
            plugins_url('/admin/html/js/slider-meta-box.js', FIFU_PLUGIN_FILE),
            array('jquery', 'fifu-meta-box-js', 'fifu-video-util-js'),
            Fifu_Plugin_Info::get_enqueue_version()
        );
        wp_localize_script('slider-meta-box-js', 'fifuSliderVars', [
            'restUrl' => esc_url_raw(rest_url()),
            'homeUrl' => esc_url_raw(home_url()),
            'nonce' => wp_create_nonce('wp_rest'),
            'urls' => $urls,
            'alts' => $alts,
            'is_product' => $is_product,
            'enable_upload' => $show_slider_upload_button,
            'text_image_video_url' => $fifu['placeholder']['image-video'](),
            'text_alt' => $fifu['image']['alt'](),
            'text_ok' => $fifu['image']['ok'](),
            'text_remove_slider_item' => $fifu['slider']['remove'](),
        ]);

        include FIFU_ADMIN_DIR . '/html/meta-box-slider.html';
    }
}
