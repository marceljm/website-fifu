<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

final class Fifu_Admin_Variation_Meta_Box
{
    public static function register_hooks(): void
    {
        // Comments must be in English.
        add_action(
            'woocommerce_product_after_variable_attributes',
            [self::class, 'render_fields'],
            10,
            3
        );

        add_action(
            'woocommerce_save_product_variation',
            [self::class, 'save_fields'],
            10,
            2
        );
    }

    public static function render_fields($loop, $variation_data, $variation): void
    {
        $fifu = Fifu_Meta_Box_Php_Strings::get_strings();
        $vid = isset($variation->ID) ? $variation->ID : $loop;
        $grid_id = 'gridDemoImage-' . $vid;
        $hidden_div_id = 'inputVarHiddenImages-' . $vid;
        $list_ids_id = 'inputVarHiddenImageListIds-' . $vid;
        $list_ids_name = 'inputVarHiddenImageListIds[' . $vid . ']';
        $length_id = 'inputVarHiddenImageLength-' . $vid;
        $length_name = 'inputVarHiddenImageLength[' . $vid . ']';

        $images = self::load_variation_images((int) $variation->ID);
        $image_list = $images['image_list'];
        $thumbnail_id = $images['thumbnail_id'];
        $gallery_ids = $images['gallery_ids'];

        echo '<span class="dashicons dashicons-camera"></span>';
        echo '<label style="padding-bottom:5px;display:inline-block;">' . $fifu['variation']['new']['images']() . '</label>';
        echo '<span id="fifu_help_alt" class="dashicons dashicons-editor-help" style="font-size:20px;cursor:help;float:right" title="' . $fifu['variation']['new']['help']() . '"></span>';
        echo '<div id="' . esc_attr($grid_id) . '"></div>';
        echo '<div id="' . esc_attr($hidden_div_id) . '">';
        self::print_hidden_fields($vid, $images);
        echo '</div>';

        $list_ids_value = '';
        if (count($image_list) > 0) {
            $list_ids_value = implode('|', range(0, count($image_list) - 1));
        }
        echo '<input type="hidden" id="' . esc_attr($list_ids_id) . '" name="' . esc_attr($list_ids_name) . '" value="' . esc_attr($list_ids_value) . '"/>';
        echo '<input type="hidden" id="' . esc_attr($length_id) . '" name="' . esc_attr($length_name) . '" value="' . esc_attr(count($image_list)) . '"/>';

        echo '<input type="hidden" id="fifu_wc_thumbnail_id_' . $vid . '" name="fifu_wc_thumbnail_id_' . $vid . '" value="' . esc_attr($thumbnail_id) . '"/>';
        echo '<input type="hidden" id="fifu_wc_gallery_ids_' . $vid . '" name="fifu_wc_gallery_ids_' . $vid . '" value="' . esc_attr($gallery_ids) . '"/>';

        woocommerce_wp_hidden_input([
            'id' => 'fifu_test_input_' . $vid,
            'name' => 'fifu_test_input_' . $vid,
            'value' => '',
        ]);

        if (Fifu_Options_Utils::is_on('fifu_upload_show')) {
            echo '<input type="checkbox" id="fifu_upload_cb" name="fifu_upload_cb" value="yes" style="margin-left:8px;">';
            echo '<label for="fifu_upload_cb" style="margin-left:4px;">' . $fifu['variation']['new']['upload']() . '</label>';
        }
    }

    public static function save_fields($variation_id, $loop): void
    {
        $variation_id = is_numeric($variation_id) ? (int) $variation_id : 0;
        $loop = is_numeric($loop) ? (int) $loop : -1;

        if ($variation_id <= 0 || $loop < 0) {
            return;
        }

        $vid = $variation_id;
        $list_raw = $_POST['inputVarHiddenImageListIds'][$vid] ?? '';
        $list_raw = is_string($list_raw) ? $list_raw : '';
        $indices = $list_raw === '' ? [] : array_values(array_filter(explode('|', $list_raw), 'strlen'));
        $expected_image_urls = [];
        $expected_image_alts = [];
        $expected_image_alts_by_index = [];
        $has_image_payload = array_key_exists($vid, $_POST['inputVarHiddenImageListIds'] ?? []);
        $has_alt_payload = false;

        $attachment_repository = fifu_attachment_repository();

        if (!empty($indices)) {
            $first_idx = $indices[0];
            $featured_url = $_POST['fifu_var_input_url_' . $first_idx . '-' . $vid] ?? null;
            $featured_url = $featured_url ? esc_url_raw(rtrim($featured_url)) : null;
            fifu_update_or_delete($variation_id, 'fifu_image_url', $featured_url);
            if ($featured_url !== null && $featured_url !== '') {
                $expected_image_urls[] = $featured_url;
            }

            $featured_alt = $_POST['fifu_var_input_alt_' . $first_idx . '-' . $vid] ?? null;
            $featured_alt = $featured_alt ? sanitize_text_field($featured_alt) : null;
            fifu_update_or_delete_value($variation_id, 'fifu_image_alt', $featured_alt);
            $featured_alt_key = 'fifu_var_input_alt_' . $first_idx . '-' . $vid;
            $has_alt_payload = array_key_exists($featured_alt_key, $_POST);
            if ($featured_alt !== null && $featured_alt !== '') {
                $expected_image_alts[] = $featured_alt;
            }
            if ($has_alt_payload) {
                $expected_image_alts_by_index[0] = $featured_alt;
            }

            $g_i = 0;
            foreach ($indices as $pos => $idx) {
                if ($pos === 0) {
                    continue;
                }
                $gal_url = $_POST['fifu_var_input_url_' . $idx . '-' . $vid] ?? null;
                $gal_url = $gal_url ? esc_url_raw(rtrim($gal_url)) : null;
                fifu_update_or_delete($variation_id, 'fifu_image_url_' . $g_i, $gal_url);
                if ($gal_url !== null && $gal_url !== '') {
                    $expected_image_urls[] = $gal_url;
                }

                $gal_alt = $_POST['fifu_var_input_alt_' . $idx . '-' . $vid] ?? null;
                $gal_alt = $gal_alt ? sanitize_text_field($gal_alt) : null;
                fifu_update_or_delete_value($variation_id, 'fifu_image_alt_' . $g_i, $gal_alt);
                $gal_alt_key = 'fifu_var_input_alt_' . $idx . '-' . $vid;
                $has_alt_payload = $has_alt_payload || array_key_exists($gal_alt_key, $_POST);
                if ($gal_alt !== null && $gal_alt !== '') {
                    $expected_image_alts[] = $gal_alt;
                }
                if (array_key_exists($gal_alt_key, $_POST)) {
                    $expected_image_alts_by_index[$g_i + 1] = $gal_alt;
                }

                $g_i++;
            }

            self::delete_stale_gallery_image_meta($variation_id, $g_i);

            $width = $_POST['fifu_var_input_width_' . $first_idx . '-' . $vid] ?? null;
            $height = $_POST['fifu_var_input_height_' . $first_idx . '-' . $vid] ?? null;
            $att_id = get_post_thumbnail_id($variation_id);
            if ($att_id && $width && $height) {
                Fifu_Attachment_Dimensions_Service::update_dimensions($att_id, (int) $width, (int) $height);
            }

            $g_i = 0;
            foreach ($indices as $pos => $idx) {
                if ($pos === 0) {
                    continue;
                }
                $w = $_POST['fifu_var_input_width_' . $idx . '-' . $vid] ?? null;
                $h = $_POST['fifu_var_input_height_' . $idx . '-' . $vid] ?? null;
                $gal_url_post = $_POST['fifu_var_input_url_' . $idx . '-' . $vid] ?? '';
                $gal_url = $gal_url_post ? esc_url_raw(rtrim($gal_url_post)) : '';
                $att_id = $attachment_repository->find_attachment_id($variation_id, $gal_url, false) ?? 0;
                if ($att_id && $w && $h) {
                    Fifu_Attachment_Dimensions_Service::update_dimensions($att_id, (int) $w, (int) $h);
                }
                $g_i++;
            }
        } else {
            if (isset($_POST['fifu_image_url'][$loop])) {
                $url = $_POST['fifu_image_url'][$loop];
                $url = $url ? esc_url_raw(rtrim($url)) : null;
                fifu_update_or_delete($variation_id, 'fifu_image_url', $url);
                $has_image_payload = true;
                if ($url !== null && $url !== '') {
                    $expected_image_urls[] = $url;
                }
            }

            $legacy_gallery_urls = [];
            foreach ($_POST as $key => $value) {
                if (strpos($key, 'fifu_image_url_') === 0) {
                    $i = substr($key, strlen('fifu_image_url_'));
                    $gurl = is_array($value) ? ($value[$loop] ?? null) : ($_POST[$key][$loop] ?? null);
                    $gurl = $gurl ? esc_url_raw(rtrim($gurl)) : null;
                    fifu_update_or_delete($variation_id, 'fifu_image_url_' . $i, $gurl);
                    $has_image_payload = true;
                    if (is_numeric((string) $i)) {
                        $legacy_gallery_urls[(int) $i] = $gurl;
                    }
                }
            }
            if ($legacy_gallery_urls) {
                ksort($legacy_gallery_urls);
                foreach ($legacy_gallery_urls as $legacy_gallery_url) {
                    if ($legacy_gallery_url !== null && $legacy_gallery_url !== '') {
                        $expected_image_urls[] = $legacy_gallery_url;
                    }
                }
            }

            $width = $_POST['fifu_var_input_width'][$loop] ?? null;
            $height = $_POST['fifu_var_input_height'][$loop] ?? null;
            $att_id = get_post_thumbnail_id($variation_id);
            if ($att_id && $width && $height) {
                Fifu_Attachment_Dimensions_Service::update_dimensions($att_id, (int) $width, (int) $height);
            }

            foreach ($_POST as $key => $value) {
                if (strpos($key, 'fifu_var_input_width_') === 0) {
                    $i = substr($key, strlen('fifu_var_input_width_'));
                    $width = is_array($value) ? ($value[$loop] ?? null) : ($_POST[$key][$loop] ?? null);
                    $height = $_POST['fifu_var_input_height_' . $i][$loop] ?? null;
                    $att_id = $attachment_repository->find_attachment_id($variation_id, esc_url_raw(rtrim($_POST['fifu_image_url_' . $i][$loop] ?? '')), false) ?? 0;
                    if ($att_id && $width && $height) {
                        Fifu_Attachment_Dimensions_Service::update_dimensions($att_id, (int) $width, (int) $height);
                    }
                }
            }
        }

        if (!empty($indices) && $has_image_payload) {
            $db2_replaced = self::replace_db2_variation_image_state_from_payload(
                $variation_id,
                $expected_image_urls,
                $expected_image_alts_by_index,
                $has_alt_payload
            );

            if ($db2_replaced) {
                self::delete_legacy_variation_image_meta_direct($variation_id);
            }
        }

        Fifu_Post_Attachment_Sync_Service::sync_featured_attachment($variation_id);
        Fifu_Post_Attachment_Sync_Service::sync_gallery_attachments($variation_id);
        Fifu_Post_Attachment_Sync_Service::sync_theme_property_images($variation_id);

        if ( $has_image_payload ) {
            Fifu_Slider_Meta_Service::clear_slider_state_only( $variation_id );
        }

        self::cleanup_legacy_variation_image_meta_after_db2_sync(
            $variation_id,
            self::implode_expected_list($expected_image_urls),
            $has_alt_payload ? self::implode_expected_list($expected_image_alts) : null,
            $expected_image_alts_by_index,
            $has_image_payload,
            $has_alt_payload
        );

        $fifu_upload_cb = $_POST['fifu_upload_cb'] ?? '';
        if ($fifu_upload_cb === 'yes') {
            $post_id = $variation_id;
            $url = Fifu_Post_Image_Url_Read_Service::get_image_url((int) $post_id);
            $alt = (string) (Fifu_Post_Image_Alt_Read_Service::get_image_alt((int) $post_id) ?? '');
            if (!$url) {
                return;
            }
            $gallery = [];
            $att_id = 0;
            try {
                $att_id = Fifu_Media_Image_Service::upload_remote_image($post_id, $url, $alt, false);
                if (!$att_id) {
                    throw new \Exception('UPLOAD ERROR: ' . $url);
                }
                if ($alt) {
                    update_post_meta($att_id, '_wp_attachment_image_alt', $alt);
                }
                wp_update_post(['ID' => $att_id, 'post_content' => $url]);

                $i = 0;
                $gallery_repo = new Fifu_Product_Gallery_Repository();
                $gallery = $gallery_repo->get_gallery_urls((int) $post_id);
                $att_ids = '';
                foreach ($gallery as $item) {
                    if (!is_object($item)) {
                        continue;
                    }

                    $gal_url = self::get_gallery_row_url($item);
                    if ($gal_url === '') {
                        continue;
                    }

                    $db2_index = self::get_gallery_row_index($item);
                    $legacy_gallery_index = $db2_index !== null && $db2_index > 0 ? $db2_index : 1;

                    $gal_alt = (string) (Fifu_Post_Image_List_Alt_Read_Service::get_image_alt(
                        (int) $post_id,
                        (int) $legacy_gallery_index
                    ) ?? '');
                    $gal_att_id = Fifu_Media_Image_Service::upload_remote_image($post_id, $gal_url, $gal_alt, false);
                    if (!$gal_att_id) {
                        throw new Exception('UPLOAD ERROR: ' . $gal_url);
                    }
                    if ($gal_alt) {
                        update_post_meta($gal_att_id, '_wp_attachment_image_alt', $gal_alt);
                    }
                    wp_update_post(['ID' => $gal_att_id, 'post_content' => $gal_url]);
                    $att_ids .= ($i++ === 0) ? $gal_att_id : ',' . $gal_att_id;
                }
            } catch (\Exception $e) {
                error_log($e->getMessage());
                error_log('ERROR: Fifu_Media_Image_Service::upload_remote_image(' . $post_id . ')');
            }

            set_post_thumbnail($post_id, $att_id);
            self::clear_remote_variation_image_state_after_upload($post_id);
            Fifu_Post_Attachment_Sync_Service::sync_featured_attachment($post_id);

            if (!empty($gallery)) {
                update_post_meta($post_id, '_product_image_gallery', $att_ids);
                update_post_meta($post_id, '_wc_additional_variation_images', $att_ids);
            }
        }
    }

    private static function delete_stale_gallery_image_meta(int $variation_id, int $current_gallery_count): void
    {
        $all_meta = get_post_meta($variation_id);
        if (!is_array($all_meta) || !$all_meta) {
            return;
        }

        foreach (array_keys($all_meta) as $meta_key) {
            if (!preg_match('/^fifu_image_url_(\d+)$/', (string) $meta_key, $matches)) {
                continue;
            }

            $index = (int) $matches[1];
            if ($index < $current_gallery_count) {
                continue;
            }

            fifu_delete_post_meta($variation_id, 'fifu_image_url_' . $index);
            fifu_delete_post_meta($variation_id, 'fifu_image_alt_' . $index);
        }
    }

    private static function replace_db2_variation_image_state_from_payload(
        int $variation_id,
        array $urls,
        array $alts_by_index,
        bool $has_alt_payload
    ): bool {
        if (!function_exists('fifu_db2_write_service')) {
            return false;
        }

        $write_service = fifu_db2_write_service();
        if (!$write_service instanceof \Fifu_Db2_Write_Service) {
            return false;
        }

        $write_service->delete_post_image($variation_id, null);
        if ($has_alt_payload) {
            $write_service->delete_post_image_alt($variation_id, null);
        }

        $ok = true;

        foreach (array_values($urls) as $index => $url) {
            $url = trim((string) $url);
            if ($url === '') {
                continue;
            }

            if (!$write_service->save_post_image_at_index($variation_id, (int) $index, $url)) {
                $ok = false;
            }
        }

        if ($has_alt_payload) {
            foreach ($alts_by_index as $index => $alt) {
                $alt = trim((string) $alt);
                if ($alt === '') {
                    $write_service->delete_post_image_alt($variation_id, (int) $index);
                    continue;
                }

                if (!$write_service->save_post_image_alt_at_index($variation_id, (int) $index, $alt)) {
                    $ok = false;
                }
            }
        }

        return $ok;
    }

    private static function delete_legacy_post_meta_direct(int $post_id, string $meta_key): void
    {
        delete_post_meta($post_id, $meta_key);
        clean_post_cache($post_id);
        wp_cache_delete($post_id, 'post_meta');
    }

    private static function delete_legacy_post_meta_matching(int $post_id, string $pattern): void
    {
        $all_meta = get_post_meta($post_id);
        if (!is_array($all_meta) || !$all_meta) {
            return;
        }

        foreach (array_keys($all_meta) as $meta_key) {
            if (preg_match($pattern, (string) $meta_key) !== 1) {
                continue;
            }

            self::delete_legacy_post_meta_direct($post_id, (string) $meta_key);
        }
    }

    private static function delete_legacy_variation_image_meta_direct(int $post_id): void
    {
        foreach ([
            'fifu_image_url',
            'fifu_image_alt',
            'fifu_list_url',
            'fifu_list_alt',
        ] as $meta_key) {
            self::delete_legacy_post_meta_direct($post_id, $meta_key);
        }

        self::delete_legacy_post_meta_matching($post_id, '/^fifu_image_url_\d+$/');
        self::delete_legacy_post_meta_matching($post_id, '/^fifu_image_alt_\d+$/');
    }

    private static function clear_remote_variation_image_state_after_upload(int $post_id): void
    {
        if (function_exists('fifu_db2_write_service')) {
            $write_service = fifu_db2_write_service();
            if ($write_service instanceof \Fifu_Db2_Write_Service) {
                $write_service->delete_post_image($post_id, null);
                $write_service->delete_post_image_alt($post_id, null);
            }
        }

        self::delete_legacy_variation_image_meta_direct($post_id);
    }

    private static function get_gallery_row_url(object $row): string
    {
        return trim((string) ($row->url ?? $row->meta_value ?? ''));
    }

    private static function get_gallery_row_index(object $row): ?int
    {
        if (isset($row->index)) {
            return (int) $row->index;
        }

        $meta_key = (string) ($row->meta_key ?? '');
        if (preg_match('/^fifu_image_url_(\d+)$/', $meta_key, $matches) === 1) {
            return ((int) $matches[1]) + 1;
        }

        return null;
    }

    private static function cleanup_legacy_variation_image_meta_after_db2_sync(
        int $variation_id,
        ?string $expected_urls,
        ?string $expected_alts,
        array $expected_alts_by_index,
        bool $has_image_payload,
        bool $has_alt_payload
    ): void {
        if ($has_image_payload) {
            $normalized_expected_urls = self::normalize_pipe_list($expected_urls);
            $db2_urls = self::normalize_pipe_list(self::get_db2_variation_image_list_url($variation_id));
            if ($db2_urls === $normalized_expected_urls) {
                delete_post_meta($variation_id, 'fifu_list_url');
            }
        }

        if (!$has_alt_payload) {
            return;
        }

        $normalized_expected_alts = self::normalize_pipe_list($expected_alts);
        $db2_alts = self::normalize_pipe_list(self::get_db2_variation_image_alt_list($variation_id));
        if ($db2_alts === $normalized_expected_alts) {
            delete_post_meta($variation_id, 'fifu_list_alt');
        }

        $db2_main_alt = self::normalize_text_value(self::get_db2_variation_image_alt($variation_id, 0));
        $expected_main_alt = self::normalize_text_value($expected_alts_by_index[0] ?? null);
        if ($db2_main_alt === $expected_main_alt) {
            delete_post_meta($variation_id, 'fifu_image_alt');
        }

        $all_meta = get_post_meta($variation_id);
        if (!is_array($all_meta) || !$all_meta) {
            return;
        }

        foreach (array_keys($all_meta) as $meta_key) {
            if (!preg_match('/^fifu_image_alt_(\d+)$/', (string) $meta_key, $matches)) {
                continue;
            }

            $legacy_index = (int) $matches[1];
            $db2_index = $legacy_index + 1;
            $expected_alt = $expected_alts_by_index[$db2_index] ?? null;
            $db2_alt = self::get_db2_variation_image_alt($variation_id, $db2_index);
            if (self::normalize_text_value($db2_alt) === self::normalize_text_value($expected_alt)) {
                delete_post_meta($variation_id, $meta_key);
            }
        }
    }

    private static function get_db2_variation_image_list_url(int $variation_id): ?string
    {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return null;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getPostMappings')) {
            return null;
        }

        $mappings = $manager->getPostMappings($variation_id, 'image');
        if (!is_array($mappings) || !$mappings) {
            return null;
        }

        usort(
            $mappings,
            static fn(array $a, array $b): int => ($a['key_index'] ?? 0) <=> ($b['key_index'] ?? 0)
        );

        $urls = [];
        foreach ($mappings as $mapping) {
            $url = trim((string) ($mapping['url'] ?? ''));
            if ($url === '') {
                continue;
            }

            $urls[] = $url;
        }

        return self::implode_expected_list($urls);
    }

    private static function get_db2_variation_image_alt_list(int $variation_id): ?string
    {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return null;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getPostAltMappings')) {
            return null;
        }

        $mappings = $manager->getPostAltMappings($variation_id, 'image');
        if (!is_array($mappings) || !$mappings) {
            return null;
        }

        usort(
            $mappings,
            static fn(array $a, array $b): int => ($a['key_index'] ?? 0) <=> ($b['key_index'] ?? 0)
        );

        $alts = [];
        foreach ($mappings as $mapping) {
            $alt = trim((string) ($mapping['alt'] ?? $mapping['value'] ?? ''));
            if ($alt === '') {
                continue;
            }

            $alts[] = $alt;
        }

        return self::implode_expected_list($alts);
    }

    private static function get_db2_variation_image_alt(int $variation_id, int $key_index): ?string
    {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return null;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getPostAltMapping')) {
            return null;
        }

        $mapping = $manager->getPostAltMapping($variation_id, 'image', $key_index);
        if (!is_array($mapping)) {
            return null;
        }

        $alt = trim((string) ($mapping['alt'] ?? $mapping['value'] ?? ''));
        return $alt === '' ? null : $alt;
    }

    private static function implode_expected_list(array $items): ?string
    {
        if (!$items) {
            return null;
        }

        return implode('|', $items);
    }

    private static function normalize_pipe_list(?string $value): ?string
    {
        if ($value === null) {
            return null;
        }

        $items = array_values(
            array_filter(
                array_map(
                    static fn(string $item): string => trim($item),
                    explode('|', $value)
                ),
                static fn(string $item): bool => $item !== ''
            )
        );

        if (!$items) {
            return null;
        }

        return implode('|', $items);
    }

    private static function normalize_text_value(?string $value): ?string
    {
        if ($value === null) {
            return null;
        }

        $value = trim($value);
        return $value === '' ? null : $value;
    }

    private static function load_variation_images(int $variation_id): array
    {
        $image_list = [];
        $image_alt_list = [];
        $image_width_list = [];
        $image_height_list = [];
        $image_ifm_list = [];

        $featured_url = Fifu_Post_Image_Url_Read_Service::get_image_url((int) $variation_id);
        $featured_alt = Fifu_Post_Image_Alt_Read_Service::get_image_alt((int) $variation_id);
        $featured_width = get_post_meta($variation_id, 'fifu_var_input_width_0-' . $variation_id, true);
        $featured_height = get_post_meta($variation_id, 'fifu_var_input_height_0-' . $variation_id, true);
        $featured_ifm = get_post_meta($variation_id, 'fifu_var_input_ifm_0-' . $variation_id, true);

        if ($featured_url) {
            $image_list[] = $featured_url;
            $image_alt_list[] = $featured_alt;
            $image_width_list[] = $featured_width;
            $image_height_list[] = $featured_height;
            $image_ifm_list[] = $featured_ifm;
        }

        $gallery_repo = new Fifu_Product_Gallery_Repository();
        $gallery_rows = $gallery_repo->get_image_gallery_urls($variation_id);
        $gallery_alt_rows = $gallery_repo->get_gallery_alts($variation_id);
        $gallery_alts = [];
        $gallery_alts_by_db2_index = [];

        foreach ($gallery_alt_rows as $row) {
            if (!is_object($row)) {
                continue;
            }

            $alt = (string) ($row->alt ?? $row->value ?? $row->meta_value ?? '');

            if (isset($row->index) && (int) $row->index > 0) {
                $db2_index = (int) $row->index;
                $gallery_alts_by_db2_index[$db2_index] = $alt;
                $gallery_alts[$db2_index - 1] = $alt;
                continue;
            }

            $gallery_alts[] = $alt;
        }

        ksort($gallery_alts, SORT_NUMERIC);

        if ($gallery_rows === []) {
            $legacy_meta = get_post_meta($variation_id);
            $legacy_rows = [];
            foreach ($legacy_meta as $meta_key => $values) {
                if (!preg_match('/^fifu_image_url_(\d+)$/', (string) $meta_key, $matches)) {
                    continue;
                }

                $legacy_url = $values[0] ?? '';
                if (!is_string($legacy_url) || trim($legacy_url) === '') {
                    continue;
                }

                $legacy_index = (int) $matches[1];
                $legacy_rows[$legacy_index] = (object) [
                    'meta_key' => 'fifu_image_url_' . $legacy_index,
                    'meta_value' => $legacy_url,
                ];

                if (!array_key_exists($legacy_index, $gallery_alts)) {
                    $legacy_alt_values = $legacy_meta['fifu_image_alt_' . $legacy_index] ?? [''];
                    $gallery_alts[$legacy_index] = is_string($legacy_alt_values[0] ?? '') ? (string) $legacy_alt_values[0] : '';
                }
            }

            ksort($legacy_rows, SORT_NUMERIC);
            $gallery_rows = array_values($legacy_rows);
            ksort($gallery_alts, SORT_NUMERIC);
            $gallery_alts = array_values($gallery_alts);
        }

        foreach ($gallery_rows as $gallery_index => $row) {
            if (!is_object($row)) {
                continue;
            }

            $url = trim((string) ($row->url ?? $row->meta_value ?? ''));
            if ($url === '') {
                continue;
            }

            $db2_index = isset($row->index) ? (int) $row->index : null;
            $alt = (
                $db2_index !== null
                && $db2_index > 0
                && array_key_exists($db2_index, $gallery_alts_by_db2_index)
            )
                ? $gallery_alts_by_db2_index[$db2_index]
                : ($gallery_alts[$gallery_index] ?? '');
            $width = get_post_meta($variation_id, 'fifu_var_input_width_' . ($gallery_index + 1) . '-' . $variation_id, true);
            $height = get_post_meta($variation_id, 'fifu_var_input_height_' . ($gallery_index + 1) . '-' . $variation_id, true);
            $ifm = get_post_meta($variation_id, 'fifu_var_input_ifm_' . ($gallery_index + 1) . '-' . $variation_id, true);
            $image_list[] = $url;
            $image_alt_list[] = $alt;
            $image_width_list[] = $width;
            $image_height_list[] = $height;
            $image_ifm_list[] = $ifm;
        }

        return [
            'image_list' => $image_list,
            'image_alt_list' => $image_alt_list,
            'image_width_list' => $image_width_list,
            'image_height_list' => $image_height_list,
            'image_ifm_list' => $image_ifm_list,
            'thumbnail_id' => get_post_meta($variation_id, '_thumbnail_id', true),
            'gallery_ids' => get_post_meta($variation_id, '_product_image_gallery', true),
        ];
    }

    private static function print_hidden_fields(int $vid, array $images): void
    {
        $image_list = $images['image_list'];
        $image_alt_list = $images['image_alt_list'];
        $image_width_list = $images['image_width_list'];
        $image_height_list = $images['image_height_list'];
        $image_ifm_list = $images['image_ifm_list'];

        foreach ($image_list as $idx => $url) {
            $alt = $image_alt_list[$idx] ?? '';
            $width = $image_width_list[$idx] ?? '';
            $height = $image_height_list[$idx] ?? '';
            $ifm = $image_ifm_list[$idx] ?? '';
            echo '<input type="hidden" id="fifu_var_input_url_' . $idx . '-' . $vid . '" name="fifu_var_input_url_' . $idx . '-' . $vid . '" value="' . esc_attr($url) . '"/>';
            echo '<input type="hidden" id="fifu_var_input_alt_' . $idx . '-' . $vid . '" name="fifu_var_input_alt_' . $idx . '-' . $vid . '" value="' . esc_attr($alt) . '"/>';
            echo '<input type="hidden" id="fifu_var_input_width_' . $idx . '-' . $vid . '" name="fifu_var_input_width_' . $idx . '-' . $vid . '" value="' . esc_attr($width) . '"/>';
            echo '<input type="hidden" id="fifu_var_input_height_' . $idx . '-' . $vid . '" name="fifu_var_input_height_' . $idx . '-' . $vid . '" value="' . esc_attr($height) . '"/>';
            echo '<input type="hidden" id="fifu_var_input_ifm_' . $idx . '-' . $vid . '" name="fifu_var_input_ifm_' . $idx . '-' . $vid . '" value="' . esc_attr($ifm) . '"/>';
        }
    }
}
