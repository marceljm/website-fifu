<?php

if (!defined('ABSPATH')) {
    exit;
}

class Fifu_Admin_Meta_Box_Manager {

    public static function get_current_editor_post_id(): int {
        if (isset($_REQUEST['post'])) {
            return absint($_REQUEST['post']);
        }

        if (isset($_REQUEST['post_ID'])) {
            return absint($_REQUEST['post_ID']);
        }

        return 0;
    }

    public static function should_hide_native_featured_image_for_post(int $post_id): bool {
        if ($post_id <= 0) {
            return false;
        }

        $url = Fifu_Post_Image_Url_Read_Service::get_image_url($post_id);
        $video_url = Fifu_Post_Video_Read_Service::get_video_url($post_id);
        $slider_url = Fifu_Post_Slider_Image_Url_Read_Service::get_slider_image_url($post_id, 0);
        $has_native_thumbnail = (int) get_post_thumbnail_id($post_id) > 0;
        $post_type = get_post_type($post_id);

        $has_remote_image = (bool) $url;
        $has_remote_slider = (bool) $slider_url;
        $has_remote_video = (bool) $video_url;
        $has_remote_video_to_hide = $post_type === 'product'
            ? $has_remote_video
            : (bool) ($has_remote_video && !$has_native_thumbnail);

        if (!$has_remote_image && !$has_remote_slider && !$has_remote_video_to_hide) {
            return false;
        }

        $rank_math_active = class_exists('Fifu_Plugin_Detector') && Fifu_Plugin_Detector::is_rank_math_seo_active();
        if ($rank_math_active) {
            return false;
        }

        return true;
    }

    public static function should_hide_native_product_gallery_for_post(int $post_id): bool {
        if ($post_id <= 0) {
            return false;
        }

        $gallery_repo = new Fifu_Product_Gallery_Repository();
        $gallery_urls = method_exists($gallery_repo, 'get_gallery_urls')
            ? $gallery_repo->get_gallery_urls($post_id)
            : $gallery_repo->get_image_gallery_urls($post_id);

        $slider_url = Fifu_Post_Slider_Image_Url_Read_Service::get_slider_image_url($post_id, 0);

        return (bool) ($gallery_urls || $slider_url);
    }

    public static function register_meta_boxes(): void {
        if (Fifu_Web_Stories_Integration::is_web_story() || Fifu_Search_Filter_Pro_Integration::is_search_filter_pro()) {
            return;
        }

        if (get_option('fifu_lock')) {
            return;
        }

        $fifu = Fifu_Meta_Box_Php_Strings::get_strings();
        $featured_media_title =
            '<span class="dashicons dashicons-camera" aria-hidden="true"></span> FIFU';
        $post_types = Fifu_Post_Type_Utils::get_post_types();

        foreach ($post_types as $post_type) {
            if ($post_type == 'product') {
                add_meta_box(
                    'featuredMediaMetaBox',
                    $featured_media_title,
                    [ Fifu_Admin_Meta_Box_Renderer::class, 'render_featured_media_box' ],
                    $post_type,
                    'side',
                    'default'
                );

                if (Fifu_Options_Utils::is_on('fifu_asin')) {
                    add_meta_box(
                        'asinMetaBox',
                        $fifu['title']['post']['asin'](),
                        [ Fifu_Admin_Meta_Box_Renderer::class, 'render_asin_box' ],
                        $post_type,
                        'side',
                        'default'
                    );
                }

                if (Fifu_Options_Utils::is_on('fifu_finder')) {
                    add_meta_box(
                        'finderMetaBox',
                        $fifu['title']['post']['finder'](),
                        [ Fifu_Admin_Meta_Box_Renderer::class, 'render_finder_box' ],
                        $post_type,
                        'side',
                        'default'
                    );
                }

            } else {
                if ($post_type) {
                    add_meta_box(
                        'featuredMediaMetaBox',
                        $featured_media_title,
                        [ Fifu_Admin_Meta_Box_Renderer::class, 'render_featured_media_box' ],
                        $post_type,
                        'side',
                        'default'
                    );

                    if (Fifu_Options_Utils::is_on('fifu_asin')) {
                        add_meta_box(
                            'asinMetaBox',
                            $fifu['title']['post']['asin'](),
                            [ Fifu_Admin_Meta_Box_Renderer::class, 'render_asin_box' ],
                            $post_type,
                            'side',
                            'default'
                        );
                    }

                    if (Fifu_Options_Utils::is_on('fifu_finder')) {
                        add_meta_box(
                            'finderMetaBox',
                            $fifu['title']['post']['finder'](),
                            [ Fifu_Admin_Meta_Box_Renderer::class, 'render_finder_box' ],
                            $post_type,
                            'side',
                            'default'
                        );
                    }

                    if (Fifu_Options_Utils::is_on('fifu_redirection')) {
                        add_meta_box(
                            'redirectionMetaBox',
                            $fifu['title']['post']['redirection'](),
                            [ Fifu_Admin_Meta_Box_Renderer::class, 'render_redirection_box' ],
                            $post_type,
                            'side',
                            'default'
                        );
                    }

                    if (Fifu_Options_Utils::is_on('fifu_popup')) {
                        add_meta_box(
                            'popupMetaBox',
                            $fifu['title']['post']['popup'](),
                            [ Fifu_Admin_Meta_Box_Renderer::class, 'render_popup_box' ],
                            $post_type,
                            'side',
                            'default'
                        );
                    }
                }
            }
        }
    }

    public static function remove_native_metaboxes(): void {
        global $post;

        if (!$post) {
            return;
        }

        $post_id = (int) $post->ID;
        $post_type = get_post_type($post_id);

        if (self::should_hide_native_featured_image_for_post($post_id)) {
            $should_remove_featured_metabox = Fifu_Wp_Context::is_gutenberg_screen();

            if (!$should_remove_featured_metabox) {
                $slider_url = Fifu_Post_Slider_Image_Url_Read_Service::get_slider_image_url($post_id, 0);
                $should_remove_featured_metabox = (bool) $slider_url;
            }

            if ($should_remove_featured_metabox) {
                remove_meta_box('postimagediv', $post_type, 'side');
            }
        }

        if ($post_type === 'product' && self::should_hide_native_product_gallery_for_post($post_id)) {
            remove_meta_box('woocommerce-product-images', 'product', 'side');
        }
    }

    public static function filter_admin_body_class($classes) {
        if (!is_string($classes)) {
            return $classes;
        }
        if (!Fifu_Wp_Context::is_gutenberg_screen()) {
            return $classes;
        }

        $post_id = self::get_current_editor_post_id();
        if ($post_id <= 0) {
            return $classes;
        }

        if (!self::should_hide_native_featured_image_for_post($post_id)) {
            return $classes;
        }

        if (strpos($classes, 'fifu-hide-native-featured-image') === false) {
            $classes = trim($classes . ' fifu-hide-native-featured-image');
        }

        return $classes;
    }

    public static function enqueue_block_editor_assets(): void {
        if (!Fifu_Wp_Context::is_gutenberg_screen()) {
            return;
        }

        wp_register_style(
            'fifu-block-editor-featured-image',
            plugins_url('/admin/html/css/block-editor-featured-image.css', FIFU_PLUGIN_FILE),
            array(),
            Fifu_Plugin_Info::get_enqueue_version()
        );
        wp_enqueue_style('fifu-block-editor-featured-image');
    }

    public static function enqueue_assets(): void {
        // for edition
        if (isset($_REQUEST['post'])) {
            $blocked_list = array('wppb-rf-cpt', 'wppb-epf-cpt');
            $post_id = $_REQUEST['post'];
            $post_type = get_post_type($post_id);
            if (in_array($post_type, $blocked_list)) {
                return;
            }
        }
        // for new posts
        if (isset($_REQUEST['post_type'])) {
            $blocked_list = array('wppb-rf-cpt', 'wppb-epf-cpt');
            $post_type = $_REQUEST['post_type'];
            if (in_array($post_type, $blocked_list)) {
                return;
            }
        }

        $fifu = Fifu_Meta_Box_Php_Strings::get_strings();
        $fifu_help = Fifu_Help_Strings::get_strings();

        wp_enqueue_script('fifu-cookie', 'https://cdnjs.cloudflare.com/ajax/libs/js-cookie/latest/js.cookie.min.js');

        wp_enqueue_script('jquery-block-ui', 'https://cdnjs.cloudflare.com/ajax/libs/jquery.blockUI/2.70/jquery.blockUI.min.js');
        wp_enqueue_style('fancy-box-css', 'https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.css');
        wp_enqueue_script('fancy-box-js', 'https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js');

        // Safely get current screen
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;

        if (($screen && ($screen->taxonomy ?? null) != 'product_cat') && (Fifu_Options_Utils::is_on('fifu_slider') || (class_exists('WooCommerce') && (($screen->post_type ?? '') === 'product')))) {
            wp_register_style('jquery-sortablejs-css', plugins_url('/admin/html/css/sortable.css', FIFU_PLUGIN_FILE), array(), Fifu_Plugin_Info::get_enqueue_version());
            wp_enqueue_style('jquery-sortablejs-css');
        }

        wp_enqueue_script('fifu-rest-route-js', plugins_url('/admin/html/js/rest-route.js', FIFU_PLUGIN_FILE), array('jquery'), Fifu_Plugin_Info::get_enqueue_version());
        wp_enqueue_script(
            'fifu-shared-js',
            plugins_url('/admin/html/js/fifu-shared.js', FIFU_PLUGIN_FILE),
            array(),
            Fifu_Plugin_Info::get_enqueue_version()
        );
        $is_post_block_editor = Fifu_Wp_Context::is_gutenberg_screen()
            && $screen
            && ($screen->base ?? null) === 'post';

        $meta_script_dependencies = $is_post_block_editor
            ? array('jquery', 'wp-edit-post', 'fifu-video-util-js', 'fifu-shared-js')
            : array('jquery', 'fifu-video-util-js', 'fifu-shared-js');
        wp_enqueue_script(
            'fifu-meta-box-js',
            plugins_url('/admin/html/js/meta-box.js', FIFU_PLUGIN_FILE),
            array_merge($meta_script_dependencies, array('fifu-search-lightbox-js')),
            Fifu_Plugin_Info::get_enqueue_version()
        );
        wp_enqueue_script('fifu-video-util-js', plugins_url('/admin/html/js/video-util.js', FIFU_PLUGIN_FILE), array('jquery'), Fifu_Plugin_Info::get_enqueue_version());
        wp_enqueue_script('fifu-video-meta-box-js', plugins_url('/admin/html/js/video-meta-box.js', FIFU_PLUGIN_FILE), array('jquery', 'fifu-video-util-js', 'fifu-shared-js'), Fifu_Plugin_Info::get_enqueue_version());
        wp_enqueue_script('fifu-convert-url-js', plugins_url('/admin/html/js/convert-url.js', FIFU_PLUGIN_FILE), array('jquery'), Fifu_Plugin_Info::get_enqueue_version());

        wp_register_style('fifu-search-lightbox-css', plugins_url('/admin/html/css/search-lightbox.css', FIFU_PLUGIN_FILE), array(), Fifu_Plugin_Info::get_enqueue_version());
        wp_enqueue_style('fifu-search-lightbox-css');
        wp_enqueue_script('fifu-search-lightbox-js', plugins_url('/admin/html/js/search-lightbox.js', FIFU_PLUGIN_FILE), array('jquery'), Fifu_Plugin_Info::get_enqueue_version());

        wp_localize_script('fifu-video-util-js', 'fifuVideoUtilVars', [
            'uploadDir' => Fifu_Upload_Dir_Utils::get_upload_dir(),
        ]);

        // register custom variables for the AJAX script
        wp_localize_script('fifu-rest-route-js', 'fifuScriptVars', [
            'restUrl' => esc_url_raw(rest_url()),
            'nonce' => wp_create_nonce('wp_rest'),
        ]);

        if (Fifu_Plugin_Detector::is_sirv_active()) {
            wp_enqueue_script('fifu-sirv-js', 'https://scripts.sirv.com/sirv.js');
        }

        $termId = isset($_GET['tag_ID']) ? absint(wp_unslash($_GET['tag_ID'])) : 0;

        $current_post_type = '';
        if ($screen && !empty($screen->post_type)) {
            $current_post_type = (string) $screen->post_type;
        } else {
            $current_post_id = self::get_current_editor_post_id();
            if ($current_post_id > 0) {
                $current_post_type = (string) get_post_type($current_post_id);
            }
        }

        wp_localize_script('fifu-meta-box-js', 'fifuMetaBoxVars', [
            'get_the_ID' => get_the_ID(),
            'term_id' => $termId,
            'restUrl' => esc_url_raw(rest_url()),
            'nonce' => wp_create_nonce('wp_rest'),
            'is_sirv_active' => Fifu_Plugin_Detector::is_sirv_active(),
            'wait' => $fifu['common']['wait'](),
            'updating_featured_image' => $fifu['common']['updating_featured_image'](),
            'is_taxonomy' => $screen->taxonomy ?? null,
            'is_product' => $current_post_type === 'product',
            'is_gutenberg' => Fifu_Wp_Context::is_gutenberg_screen(),
            'is_classic_editor' => is_plugin_active('classic-editor/classic-editor.php'),
            'enable_upload' => Fifu_Options_Utils::is_on('fifu_upload_show'),
            'isAutoSetEnabled' => Fifu_Options_Utils::is_on('fifu_auto_set'),
            'txt_title_examples' => $fifu_help['title']['examples'](),
            'txt_title_keywords' => $fifu_help['title']['keywords'](),
            'txt_title_more' => $fifu_help['title']['more'](),
            'txt_title_url' => $fifu_help['title']['url'](),
            'txt_title_empty' => $fifu_help['title']['empty'](),
            'txt_desc_more' => $fifu_help['desc']['more'](),
            'txt_desc_url' => $fifu_help['desc']['url'](),
            'txt_desc_keywords' => $fifu_help['desc']['keywords'](),
            'txt_desc_empty' => $fifu_help['desc']['empty'](),
            'txt_loading' => $fifu_help['search']['loading'](),
            'alt_text_label' => $fifu['common']['alt'](),
        ]);

        wp_localize_script('fifu-video-meta-box-js', 'fifuVideoMetaBoxVars', [
            'restUrl' => esc_url_raw(rest_url()),
            'nonce' => wp_create_nonce('wp_rest'),
        ]);

        wp_localize_script('fifu-convert-url-js', 'fifuConvertUrlVars', [
            'restUrl' => esc_url_raw(rest_url()),
            'homeUrl' => esc_url_raw(home_url()),
            'nonce' => wp_create_nonce('wp_rest'),
            'partialKey' => Fifu_Options_Utils::partial_key(),
        ]);

        // Hide native Woo variation image picker when FIFU fields are used
        if (class_exists('WooCommerce') && (($screen->post_type ?? '') === 'product')) {
            wp_register_style('woo-meta-box-variation-css', plugins_url('/admin/html/css/woo-meta-box-variation.css', FIFU_PLUGIN_FILE), array(), Fifu_Plugin_Info::get_enqueue_version());
            wp_enqueue_style('woo-meta-box-variation-css');

            wp_enqueue_script(
                'fifu-woo-meta-box-variation-js',
                plugins_url('/admin/html/js/woo-meta-box-variation.js', FIFU_PLUGIN_FILE),
                array('jquery', 'fifu-shared-js'),
                Fifu_Plugin_Info::get_enqueue_version()
            );
        }
    }

    public static function enqueue_editor_styles(): void {
        wp_register_style('fifu-editor', plugins_url('/admin/html/css/editor.css', FIFU_PLUGIN_FILE), array(), Fifu_Plugin_Info::get_enqueue_version());
        wp_enqueue_style('fifu-editor');
        wp_enqueue_style('fifu-slider-popup-css', plugins_url('/admin/html/css/slider-popup.css', FIFU_PLUGIN_FILE), array(), Fifu_Plugin_Info::get_enqueue_version());
    }
}
