var isDraggingSlider = false;
var fifuSliderRestoreQuickSaveFocus = false;

function fifu_slider_prepare_quick_editor_save_focus(which) {
    if (which === 13) {
        fifuSliderRestoreQuickSaveFocus = true;
    } else if (which === 27) {
        fifuSliderRestoreQuickSaveFocus = false;
    }
}

function fifu_slider_restore_quick_editor_save_focus() {
    const shouldRestoreFocus = fifuSliderRestoreQuickSaveFocus;
    fifuSliderRestoreQuickSaveFocus = false;

    if (!shouldRestoreFocus) {
        return;
    }

    if (typeof fifuQuickEditorOpen === 'undefined' || !fifuQuickEditorOpen) {
        return;
    }

    setTimeout(function () {
        if (typeof fifuQuickEditorOpen === 'undefined' || !fifuQuickEditorOpen) {
            return;
        }

        const $saveButton = jQuery('#fifu-save-button');
        if ($saveButton.length) {
            $saveButton.focus();
        }
    }, 0);
}

function fifu_normalize_slider_alt(alt) {
    return (alt === undefined || alt === null || alt === 'null' || alt === 'undefined') ? '' : alt;
}

function fifu_normalize_slider_alt_input_value(alt) {
    return (!alt || alt === 'undefined' || alt === 'null' || alt === null) ? '' : alt;
}

function fifu_get_slider_input_value(inputId) {
    const $input = jQuery('#' + inputId);
    if (!$input.length) {
        return '';
    }

    const currentValue = $input.val();
    if (currentValue !== undefined && currentValue !== null && currentValue !== 'undefined') {
        return String(currentValue).trim();
    }

    const attrValue = $input.attr('value');
    if (attrValue !== undefined && attrValue !== null && attrValue !== 'undefined') {
        return String(attrValue).trim();
    }

    return '';
}

function fifu_parse_slider_media(value) {
    const sliderValue = (value === undefined || value === null) ? '' : String(value).trim();
    const thumbnailPosition = sliderValue.indexOf('#http');
    const mediaUrl = thumbnailPosition === -1
        ? sliderValue
        : sliderValue.substring(0, thumbnailPosition).trim();
    const thumbnailUrl = thumbnailPosition === -1
        ? ''
        : sliderValue.substring(thumbnailPosition + 1).trim();

    return {
        type: typeof fifu_is_video === 'function' && fifu_is_video(mediaUrl) ? 'video' : 'image',
        mediaUrl: mediaUrl,
        thumbnailUrl: thumbnailUrl
    };
}

function fifu_normalize_slider_thumbnail_url(value) {
    const normalizedUrl = String(value || '').trim();
    return normalizedUrl === 'undefined' || normalizedUrl === 'null' ? '' : normalizedUrl;
}

function fifu_set_slider_video_thumbnail(index, mediaUrl, thumbnailUrl) {
    const normalizedMediaUrl = String(mediaUrl || '').trim();
    const normalizedThumbnailUrl = fifu_normalize_slider_thumbnail_url(thumbnailUrl);
    if (!normalizedMediaUrl || !normalizedThumbnailUrl) {
        return '';
    }

    const canonicalUrl = `${normalizedMediaUrl}#${normalizedThumbnailUrl}`;
    jQuery(`#fifu_slider_input_url_${index}`).val(canonicalUrl);

    if (typeof fifuSliderVars !== 'undefined' && Array.isArray(fifuSliderVars.urls)) {
        fifuSliderVars.urls[index] = canonicalUrl;
    }

    if (
        typeof currentLightbox !== 'undefined'
        && currentLightbox !== null
        && typeof fifuQuickEditVars !== 'undefined'
        && fifuQuickEditVars.posts
        && fifuQuickEditVars.posts[currentLightbox]
    ) {
        const payload = fifuQuickEditVars.posts[currentLightbox];
        if (!Array.isArray(payload.fifu_slider_image_urls)) {
            payload.fifu_slider_image_urls = [];
        }
        payload.fifu_slider_image_urls[index] = canonicalUrl;
    }

    const $slot = jQuery(`#fifu-slider-${index}`);
    if ($slot.length) {
        $slot.css('background', `url("${normalizedThumbnailUrl}") center center / cover no-repeat`);
        $slot.css('opacity', '1');
    }

    if (
        typeof fifu_get_quick_selected_media_type === 'function'
        && typeof fifu_update_quick_featured_media_preview === 'function'
        && fifu_get_quick_selected_media_type() === 'slider'
    ) {
        fifu_update_quick_featured_media_preview('slider');
    }

    return canonicalUrl;
}

async function fifu_ensure_slider_video_thumbnail(index, mediaUrl, existingThumbnailUrl) {
    const normalizedMediaUrl = String(mediaUrl || '').trim();
    if (!normalizedMediaUrl) {
        return '';
    }

    const storedThumbnailUrl = fifu_normalize_slider_thumbnail_url(existingThumbnailUrl);
    if (storedThumbnailUrl) {
        fifu_set_slider_video_thumbnail(index, normalizedMediaUrl, storedThumbnailUrl);
        return storedThumbnailUrl;
    }

    if (typeof fifu_video_image_thumbnail !== 'function') {
        return '';
    }

    let thumbnailUrl = '';
    try {
        thumbnailUrl = await fifu_video_image_thumbnail(normalizedMediaUrl, fifuSliderVars);
    } catch (error) {
        return '';
    }

    const currentMedia = fifu_parse_slider_media(
        fifu_get_slider_input_value(`fifu_slider_input_url_${index}`)
    );
    if (currentMedia.mediaUrl !== normalizedMediaUrl) {
        return '';
    }

    thumbnailUrl = fifu_normalize_slider_thumbnail_url(thumbnailUrl);
    if (!thumbnailUrl) {
        return '';
    }

    fifu_set_slider_video_thumbnail(index, normalizedMediaUrl, thumbnailUrl);
    return thumbnailUrl;
}

function fifu_get_slider_media_url(url) {
    return fifu_parse_slider_media(url).mediaUrl;
}

function fifu_slider_supports_alt(url) {
    const mediaUrl = fifu_get_slider_media_url(url);
    return !!mediaUrl && typeof fifu_is_video === 'function' && !fifu_is_video(mediaUrl);
}

function fifu_get_slider_input_count(numberUrls) {
    const COLUMNS = 4;
    const MIN = COLUMNS - 1;
    if (numberUrls <= MIN) {
        return MIN;
    }

    return Math.ceil((numberUrls + 1) / COLUMNS) * COLUMNS - 1;
}

function fifu_append_slider_placeholder(index) {
    const $grid = jQuery('#gridDemoSlider');
    const placeholder = `<div id="fifu-slider-${index}" class="grid-square image"></div>`;
    const $addButton = jQuery('#fifu-add-slider');

    if ($addButton.length) {
        $addButton.before(placeholder);
    } else {
        $grid.append(placeholder);
    }

    jQuery('#inputHiddenSliders').append(`
        <input type="hidden" id="fifu_slider_input_width_${index}" name="fifu_slider_input_width_${index}" value="" >
        <input type="hidden" id="fifu_slider_input_height_${index}" name="fifu_slider_input_height_${index}" value="" >
        <input type="hidden" id="fifu_slider_input_url_${index}" name="fifu_slider_input_url_${index}" value="">
        <input type="hidden" id="fifu_slider_input_alt_${index}" name="fifu_slider_input_alt_${index}" value="">
    `);
}

function fifu_update_slider_remove_control(index) {
    const $slot = jQuery(`#fifu-slider-${index}`);
    if (!$slot.length) {
        return;
    }

    const url = fifu_get_slider_input_value(`fifu_slider_input_url_${index}`);
    const $remove = $slot.find('.fifu-featured-media-remove');
    if (!url || !url.startsWith('http')) {
        $remove.remove();
        return;
    }

    if ($remove.length) {
        return;
    }

    const label = typeof fifuSliderVars !== 'undefined'
        ? String(fifuSliderVars.text_remove_slider_item || '')
        : '';
    const escapedLabel = typeof fifu_escape_html === 'function'
        ? fifu_escape_html(label)
        : label;
    $slot.append(`<button type="button" class="fifu-featured-media-remove" data-slider-index="${index}" aria-label="${escapedLabel}" title="${escapedLabel}"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></button>`);
}

function fifu_clear_slider_slot(index) {
    [
        `#fifu_slider_input_url_${index}`,
        `#fifu_slider_input_alt_${index}`,
        `#fifu_slider_input_width_${index}`,
        `#fifu_slider_input_height_${index}`,
        `#fifu_slider_input_image_src_${index}`
    ].forEach(function (selector) {
        jQuery(selector).val('');
    });

    jQuery(`#fifu-slider-${index}`).css('background', '').css('opacity', '');
    fifu_update_slider_remove_control(index);
    updateSliderList();
}

function fifu_bind_slider_remove_control() {
    jQuery(document)
        .off('click.fifuSliderRemove', '#gridDemoSlider .fifu-featured-media-remove')
        .on('click.fifuSliderRemove', '#gridDemoSlider .fifu-featured-media-remove', function (evt) {
            evt.preventDefault();
            evt.stopPropagation();
            evt.stopImmediatePropagation();

            const $slot = jQuery(this).closest('div[id^="fifu-slider-"]');
            if (!$slot.length) {
                return;
            }

            const slotId = $slot.attr('id') || '';
            fifu_clear_slider_slot(slotId.split('-')[2]);
        });
}

function fifu_ensure_slider_capacity(numberUrls, nextIndex) {
    const $grid = jQuery('#gridDemoSlider');
    const requiredCount = fifu_get_slider_input_count(numberUrls);
    let currentCount = $grid.children('div[id^="fifu-slider-"]').length;
    let index = nextIndex;

    while (currentCount < requiredCount) {
        fifu_append_slider_placeholder(index);
        maxSlider = index;
        index++;
        currentCount++;
    }

    return requiredCount;
}

function fifu_get_slider_upload_payload() {
    let featuredUrl = '';
    let featuredAlt = '';
    let galleryUrls = [];
    let galleryAlts = [];
    let hasSliderPayload = false;
    let sliderIds = (jQuery('#inputHiddenSliderListIds').val() || '').split('|');

    sliderIds.forEach(function (index) {
        if (index === '') {
            return;
        }

        let url = fifu_get_slider_input_value(`fifu_slider_input_url_${index}`);
        if (!url) {
            return;
        }

        let alt = fifu_normalize_slider_alt_input_value(fifu_get_slider_input_value(`fifu_slider_input_alt_${index}`));
        if (!hasSliderPayload) {
            featuredUrl = url;
            featuredAlt = alt;
            hasSliderPayload = true;
            return;
        }

        galleryUrls.push(url);
        galleryAlts.push(alt);
    });

    return {
        featuredUrl: featuredUrl,
        featuredAlt: featuredAlt,
        galleryUrls: galleryUrls,
        galleryAlts: galleryAlts,
        hasSliderPayload: hasSliderPayload
    };
}

function fifu_slider_has_valid_payload() {
    return fifu_get_slider_upload_payload().hasSliderPayload;
}

function fifu_update_slider_upload_visibility() {
    const $uploadButton = jQuery('#fifu_slider_upload');
    if (!$uploadButton.length) {
        return;
    }

    const uploadEnabled = typeof fifuSliderVars !== 'undefined' && !!fifuSliderVars.enable_upload;
    const shouldShow = !!(fifuSliderVars.is_product && uploadEnabled && fifu_slider_has_valid_payload());
    $uploadButton.css('display', shouldShow ? '' : 'none');
}

function fifu_slider_has_image() {
    return jQuery('input[id^="fifu_slider_input_url_"]').filter(function () {
        let url = jQuery(this).val();
        if (url === undefined || url === null || url === 'undefined') {
            return false;
        }

        url = String(url).trim();
        const isRemoteUrl = /^(?:https?:\/\/|\/\/)[^\s/]+(?:[/?#][^\s]*)?$/i.test(url);
        return isRemoteUrl && fifu_slider_supports_alt(url);
    }).length > 0;
}

function fifu_update_slider_ratio_visibility() {
    const $ratio = jQuery('#fifu_slider_ratio');
    const $quickRatio = jQuery('#fifu-quick-slider-ratio');
    if (!$ratio.length && !$quickRatio.length) {
        return;
    }

    const display = fifu_slider_has_image() ? '' : 'none';
    if ($ratio.length) {
        $ratio.css('display', display);
    }
    if ($quickRatio.length) {
        $quickRatio.css('display', display);
    }
}

function fifu_clear_slider_after_local_upload() {
    jQuery('#fifu_slider_input_ratio').val('');
    jQuery('#fifu-quick-slider-input-ratio').val('');
    jQuery('input[id^="fifu_slider_input_url_"]').val('');
    jQuery('input[id^="fifu_slider_input_alt_"]').val('');
    jQuery('input[id^="fifu_slider_input_width_"]').val('');
    jQuery('input[id^="fifu_slider_input_height_"]').val('');
    jQuery('input[id^="fifu_slider_input_image_src_"]').val('');
    jQuery('[id^="fifu-slider-"]').css('background', '').css('opacity', '');
    jQuery('#inputHiddenSliderListIds').val('');
    updateSliderList();
}

function fifu_persist_slider_popup(divId) {
    const index = divId.split('-')[2];
    const inputValue = fifu_get_slider_input_value('input-' + divId);
    const sliderMedia = fifu_parse_slider_media(inputValue);
    const existingMedia = fifu_parse_slider_media(
        fifu_get_slider_input_value('fifu_slider_input_url_' + index)
    );
    let url = sliderMedia.mediaUrl;

    url = url && url.startsWith('http') ? url : '';
    if (url && sliderMedia.type === 'video') {
        const thumbnailUrl = sliderMedia.thumbnailUrl
            || (existingMedia.type === 'video' && existingMedia.mediaUrl === sliderMedia.mediaUrl
                ? existingMedia.thumbnailUrl
                : '');
        if (thumbnailUrl) {
            url += '#' + thumbnailUrl;
        }
    }

    jQuery('#fifu_slider_input_url_' + index).val(url);

    let alt = '';
    if (fifu_slider_supports_alt(url)) {
        alt = fifu_normalize_slider_alt_input_value(
            jQuery('#alt-input-' + divId).val()
        );
    }
    jQuery('#fifu_slider_input_alt_' + index).val(alt);

    updateSliderList();
}

function fifu_update_slider_alt_visibility(divId) {
    const $alt = jQuery(`#alt-span-${divId}`);
    if (!$alt.length) {
        return;
    }

    const url = fifu_get_slider_input_value(`input-${divId}`);
    const index = divId.split('-')[2];
    const clearAlt = function () {
        jQuery(`#alt-input-${divId}`).val('');
        jQuery(`#fifu_slider_input_alt_${index}`).val('');
    };

    if (!fifu_slider_supports_alt(url)) {
        $alt.hide();
        clearAlt();
        return;
    }

    const image = document.getElementById('img-fifu-slider');
    const notFoundUrl = typeof FIFU_IMAGE_NOT_FOUND_URL !== 'undefined'
        ? String(FIFU_IMAGE_NOT_FOUND_URL)
        : '';
    const imageIsValid = image && image.src && (!notFoundUrl
        || (image.src !== notFoundUrl && image.src.indexOf(notFoundUrl) === -1));

    if (imageIsValid) {
        $alt.show();
    } else {
        $alt.hide();
        clearAlt();
    }
}

// add meta box icon
jQuery(document).ready(function () {
    let text = jQuery("div#wooSliderImageUrlMetaBox").find('h2').text();
    jQuery("div#wooSliderImageUrlMetaBox").find('h2.hndle').text('');
    jQuery("div#wooSliderImageUrlMetaBox").find('h2').append('<h4 style="left:-10px;position:relative;font-size:13px;font-weight:normal"><span class="dashicons dashicons-images-alt2"></span> ' + text + '</h4>');
    jQuery("div#wooSliderImageUrlMetaBox").find('button.handle-order-higher').remove();
    jQuery("div#wooSliderImageUrlMetaBox").find('button.handle-order-lower').remove();

    text = jQuery("div#sliderImageUrlMetaBox").find('h2').text();
    jQuery("div#sliderImageUrlMetaBox").find('h2.hndle').text('');
    jQuery("div#sliderImageUrlMetaBox").find('h2').append('<h4 style="left:-10px;position:relative;font-size:13px;font-weight:normal"><span class="dashicons dashicons-images-alt2"></span> ' + text + '</h4>');
    jQuery("div#sliderImageUrlMetaBox").find('button.handle-order-higher').remove();
    jQuery("div#sliderImageUrlMetaBox").find('button.handle-order-lower').remove();

});

// sizes
function fifu_slider_get_sizes(i) {
    const sliderMedia = fifu_parse_slider_media(
        jQuery('input[id^=fifu_slider_input_url_' + i + ']').val()
    );
    const imageUrl = sliderMedia.type === 'video'
        ? sliderMedia.thumbnailUrl
        : sliderMedia.mediaUrl;
    if (!imageUrl) {
        return;
    }

    fifu_slider_get_image(imageUrl, i);
}

function fifu_slider_get_image(url, i) {
    var image = new Image();
    jQuery(image).attr('onload', 'fifu_slider_store_sizes(this,' + i + ');');
    jQuery(image).attr('src', url);
}

function fifu_slider_store_sizes($, i) {
    jQuery("#fifu_slider_input_width_" + i).val($.naturalWidth);
    jQuery("#fifu_slider_input_height_" + i).val($.naturalHeight);
}

// video sizes

async function fifu_slider_video_get_sizes(i) {
    const sliderMedia = fifu_parse_slider_media(
        jQuery('input[id^=fifu_slider_input_url_' + i + ']').val()
    );
    const videoUrl = sliderMedia.mediaUrl;
    if (!videoUrl || (!videoUrl.startsWith("http") && !videoUrl.startsWith("//")))
        return;

    const thumbnailUrl = await fifu_ensure_slider_video_thumbnail(
        i,
        videoUrl,
        sliderMedia.thumbnailUrl
    );
    if (!thumbnailUrl) {
        return;
    }

    fifu_slider_video_get_image(thumbnailUrl, i);
}

function fifu_slider_video_get_image(url, i) {
    var image = new Image();
    jQuery(image).attr('onload', 'fifu_slider_video_store_sizes(this,' + i + ');');
    jQuery(image).attr('src', url);
}

function fifu_slider_video_store_sizes($, i) {
    let src = fifu_normalize_slider_thumbnail_url($.src);
    jQuery("#fifu_slider_input_width_" + i).val($.naturalWidth);
    jQuery("#fifu_slider_input_height_" + i).val($.naturalHeight);
    if ($.naturalWidth == 120 && $.naturalHeight == 90)
        jQuery("#fifu_slider_input_image_src_" + i).val(src.replace('maxresdefault', 'mqdefault'));
    else
        jQuery("#fifu_slider_input_image_src_" + i).val(src);

    // load thumbnail gallery
    if (!src) {
        src = fifu_normalize_slider_thumbnail_url(jQuery("#fifu_slider_input_image_src_" + i).val());
    }
    if (!src) {
        return;
    }

    const sliderMedia = fifu_parse_slider_media(
        jQuery(`#fifu_slider_input_url_${i}`).val()
    );
    fifu_set_slider_video_thumbnail(i, sliderMedia.mediaUrl, src);
}

var maxSlider = 0;

function fifu_create_slider_sortable_helper(event, item) {
    const source = item && item[0];
    if (!source || typeof source.cloneNode !== 'function') {
        return source;
    }

    const rect = typeof source.getBoundingClientRect === 'function'
        ? source.getBoundingClientRect()
        : {};
    const width = Math.round(rect.width || source.offsetWidth || 0);
    const height = Math.round(rect.height || source.offsetHeight || 0);
    const helper = source.cloneNode(true);
    if (typeof helper.removeAttribute === 'function') {
        helper.removeAttribute('id');
    }
    if (!width || !height || !helper.style || typeof helper.style.setProperty !== 'function') {
        return helper;
    }

    helper.style.setProperty('width', `${width}px`, 'important');
    helper.style.setProperty('max-width', `${width}px`, 'important');
    helper.style.setProperty('height', `${height}px`, 'important');
    return helper;
}

function fifu_lock_slider_sortable_placeholder(ui) {
    const helper = ui && ui.helper && ui.helper[0];
    const placeholder = ui && ui.placeholder && ui.placeholder[0];
    if (!helper || !placeholder || !placeholder.style || typeof placeholder.style.setProperty !== 'function') {
        return;
    }

    const width = helper.style && helper.style.width;
    const height = helper.style && helper.style.height;
    if (!width || !height) {
        return;
    }

    placeholder.style.setProperty('width', width, 'important');
    placeholder.style.setProperty('max-width', width, 'important');
    placeholder.style.setProperty('height', height, 'important');
}

function fifu_clear_slider_sortable_dimensions(ui) {
    [ui && ui.helper, ui && ui.placeholder].forEach(function (target) {
        const element = target && target[0];
        if (!element || !element.style || typeof element.style.removeProperty !== 'function') {
            return;
        }
        element.style.removeProperty('width');
        element.style.removeProperty('max-width');
        element.style.removeProperty('height');
    });
}

// run once
jQuery(document).ready(function () {
    fifu_slider_box_init();
});

function fifu_slider_box_init() {
    const $grid = jQuery('#gridDemoSlider');
    if (!$grid.length || $grid.data('fifu-slider-initialized')) {
        return;
    }
    $grid.data('fifu-slider-initialized', true);

    // quick edit
    if (currentLightbox)
        fifu_slider_info(currentLightbox);

    numberUrls = fifuSliderVars.urls ? fifuSliderVars.urls.length : 0;
    numberInputs = fifu_ensure_slider_capacity(numberUrls, 0);

    // add plus button
    jQuery('#gridDemoSlider').append(`<div id="fifu-add-slider" class="grid-square image-add"></div>`);

    // add images
    const videoThumbnailPromises = [];
    for (i = 0; i < numberInputs; i++) {
        url = fifuSliderVars.urls[i];
        alt = fifuSliderVars.alts[i];

        const sliderMedia = fifu_parse_slider_media(url);
        const image_url = sliderMedia.type === 'video'
            ? sliderMedia.thumbnailUrl
            : sliderMedia.mediaUrl;

        alt = fifu_normalize_slider_alt(alt);

        if (image_url) {
            selector = `#fifu-slider-${i}`;
            jQuery(selector).css('background', `url("${image_url}") center center / cover no-repeat`);
            jQuery(selector).css('opacity', '1');
        }

        jQuery(`#fifu_slider_input_url_${i}`).val(url);
        jQuery(`#fifu_slider_input_alt_${i}`).val(alt);

        // get sizes
        if (url) {
            if (sliderMedia.type === 'video') {
                videoThumbnailPromises.push(fifu_slider_video_get_sizes(i));
            } else {
                fifu_slider_get_sizes(i);
            }
        }
    }

    // start lists
    updateSliderList(true);

    /////////////////////////////////////////////////

    // init sortable
    if (jQuery('#gridDemoSlider').length) {
        jQuery('#gridDemoSlider').sortable({
            items: '> .grid-square.image',
            cancel: '.fifu-featured-media-remove',
            helper: fifu_create_slider_sortable_helper,
            start: function (event, ui) {
                isDraggingSlider = false; // Reset the flag
                fifu_lock_slider_sortable_placeholder(ui);
            },
            stop: function (event, ui) {
                isDraggingSlider = true; // Set the flag to indicate dragging occurred
                fifu_clear_slider_sortable_dimensions(ui);
                updateSliderList();
            }
        });
    }

    // prepare fancy boxes
    fifu_bind_slider_remove_control();
    addFancyBoxSlider();

    // add new image: onclick event
    jQuery(document).off('click.fifuSliderAdd', '#fifu-add-slider').on('click.fifuSliderAdd', '#fifu-add-slider', function (evt) {
        if (isDraggingSlider) {
            isDraggingSlider = false;
            return;
        }

        evt.stopImmediatePropagation();
        const currentSlotCount = jQuery('#gridDemoSlider').children('div[id^="fifu-slider-"]').length;
        fifu_ensure_slider_capacity(currentSlotCount + 1, maxSlider + 1);
        addFancyBoxSlider();
    });

    fifu_check_slider_grid_images();
    return Promise.all(videoThumbnailPromises);
}

// prepare fancy boxes
function addFancyBoxSlider() {
    jQuery(document).off('click.fifuSliderItem', 'div[id^="fifu-slider-"]').on('click.fifuSliderItem', 'div[id^="fifu-slider-"]', function (evt) {
        if (isDraggingSlider) {
            isDraggingSlider = false;
            return;
        }

        if (jQuery(evt.target).closest('.fifu-featured-media-remove').length) {
            return;
        }

        evt.stopImmediatePropagation();
        let divId = jQuery(this).attr('id');
        let index = divId.split('-')[2];

        const storedValue = jQuery(`#fifu_slider_input_url_${index}`).val();
        const sliderMedia = fifu_parse_slider_media(storedValue);
        const url = sliderMedia.mediaUrl;
        let alt = jQuery(`#fifu_slider_input_alt_${index}`).val();
        alt = fifu_normalize_slider_alt_input_value(alt);

        let imgTag = '';
        let iframeTag = '';
        if (url) {
            if (fifu_is_video(url)) {
                iframeTag = `<iframe id="iframe-fifu-slider" src="${srcVideo(url)}" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen frameborder="0"></iframe>`;
            } else {
                imgTag = `<img loading="lazy" id="img-fifu-slider" src="${url}"
                    onload="fifuToggleAltField('${divId}')"
                    onerror="this.onerror=null;this.src='${FIFU_IMAGE_NOT_FOUND_URL}'; setTimeout(function(){fifuToggleAltField('${divId}')}, 10);"
                >`;
            }
        }

        fifuSliderRestoreQuickSaveFocus = false;
        jQuery.fancybox.open(`
            <div class="fifu-featured-media-slider-popup">
                <div class="fifu-featured-media-icon-input fifu-featured-media-slider-input">
                    <span
                        class="dashicons dashicons-admin-media"
                        aria-hidden="true"></span>
                    <input id="input-${divId}" placeholder="${fifuSliderVars.text_image_video_url}" value="${url}">
                </div>
                <span id="span-img-fifu-slider">${imgTag}</span>
                <span id="span-iframe-fifu-slider">${iframeTag}</span>
                <div id="alt-span-${divId}" class="fifu-featured-media-icon-input fifu-featured-media-slider-input" style="display:none;">
                    <span
                        class="dashicons dashicons-media-text"
                        aria-hidden="true"></span>
                    <input id="alt-input-${divId}" placeholder="${fifuSliderVars.text_alt}" value="${alt}">
                </div>
            </div>
        `, {
            beforeClose: function () {
                fifu_persist_slider_popup(divId);
            },
            afterClose: function () {
                fifu_slider_restore_quick_editor_save_focus();
            }
        });
        if (!fifu_slider_supports_alt(url)) {
            fifu_update_slider_alt_visibility(divId);
        }
        jQuery(`#input-${divId}`).focus();
        jQuery(`#input-${divId}`).select();
    });
}

// change URL (single field for image or video)
async function fifu_handle_slider_url_keyup(evt) {
    evt.stopImmediatePropagation();

    let inputId = jQuery(this).attr('id');
    let divId = inputId.replace('input-', '');
    let index = divId.split('-')[2];

    let url = jQuery(`#${inputId}`).val();
    url = url && url.startsWith('http') ? url : '';

    // Only update if value actually changed, or Enter/Esc is pressed
    let prevUrl = jQuery(this).data('prev-url');
    if (url === prevUrl && evt.which !== 13 && evt.which !== 27) {
        return;
    }
    jQuery(this).data('prev-url', url);

    // Always update the hidden input
    jQuery(`#fifu_slider_input_url_${index}`).val(url);

    // Clear previews
    jQuery(`#span-img-fifu-slider`).empty();
    jQuery(`#span-iframe-fifu-slider`).empty();

        if (url) {
            if (fifu_is_video(url)) {
                fifu_update_slider_alt_visibility(divId);
                url = fifu_convert_video(url);
                // Show video preview
            jQuery(`#span-iframe-fifu-slider`).append(
                    `<iframe id="iframe-fifu-slider" src="${srcVideo(url)}" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen frameborder="0"></iframe>`
                    );
            await fifu_slider_video_get_sizes(index);
        } else {
            url = fifu_convert(url);
            // Show image preview
            jQuery(`#span-img-fifu-slider`).append(
                    `<img loading="lazy" id="img-fifu-slider" src="${url}"
                    onload="fifuToggleAltField('${divId}')"
                    onerror="this.onerror=null;this.src='${FIFU_IMAGE_NOT_FOUND_URL}'; setTimeout(function(){fifuToggleAltField('${divId}')}, 10);">`
                    );
            let img = new window.Image();
            img.onload = function () {
                jQuery(`#${divId}`).css('background', `url("${url}") center center / cover no-repeat`);
                jQuery(`#${divId}`).css('opacity', '1');
                fifu_slider_get_sizes(index);
            };
            img.onerror = function () {
                jQuery(`#${divId}`).css('background', `url("${FIFU_IMAGE_NOT_FOUND_URL}") center center / cover no-repeat`);
                jQuery(`#${divId}`).css('opacity', '1');
            };
            img.src = url;
        }
        } else {
        // If the field is empty, show nothing and clear alt value
        jQuery(`#span-img-fifu-slider`).empty();
        fifu_update_slider_alt_visibility(divId);
        jQuery(`#${divId}`).attr('style', '');
    }

    updateSliderList();

    if (evt.which === 13 || evt.which === 27) {
        fifu_slider_prepare_quick_editor_save_focus(evt.which);
        jQuery.fancybox.close();
    }
}

jQuery(document).on('keyup', 'input[id^="input-fifu-slider"]', fifu_handle_slider_url_keyup);

// Helper function to toggle alt field based on image src
function fifuToggleAltField(divId) {
    return fifu_update_slider_alt_visibility(divId);
}

// change ALT
function fifu_handle_slider_alt_keyup(evt) {
    evt.stopImmediatePropagation();
    let inputId = jQuery(this).attr('id');
    let divId = inputId.replace('alt-input-', '');
    let index = divId.split('-')[2];

    let alt = jQuery(`#${inputId}`).val();
    jQuery(`#fifu_slider_input_alt_${index}`).val(alt);

    updateSliderList();

    if (evt.which === 13 || evt.which === 27) {
        fifu_slider_prepare_quick_editor_save_focus(evt.which);
        jQuery.fancybox.close();
    }
}

jQuery(document).on('keyup', 'input[id^="alt-input-fifu"]', fifu_handle_slider_alt_keyup);

// update the list of urls
function updateSliderList(skipQuickSliderActivation) {
    const previousSliderListIds = String(jQuery('#inputHiddenSliderListIds').val() || '');
    let sliderListIds = "";
    let i = 0;
    jQuery('div[id^="fifu-slider-"]').each(function () {
        const slotId = jQuery(this).attr('id') || '';
        fifu_update_slider_remove_control(slotId.split('-')[2]);
    });
    jQuery('div[id^="fifu-slider"]').each(function (index) {
        let divId = jQuery(this).attr('id');
        let idx = divId.split('-')[2];
        let url = jQuery(`#fifu_slider_input_url_${idx}`).val();
        if (url && url.startsWith('http')) {
            sliderListIds += (i == 0) ? '' : '|';
            sliderListIds += idx;
            i++;
        }
    });
    jQuery('#inputHiddenSliderListIds').val(sliderListIds);
    jQuery('#inputHiddenSliderLength').val(jQuery('div[id^="fifu-slider"]').length);

    if (
        !skipQuickSliderActivation
        && previousSliderListIds === ''
        && sliderListIds !== ''
        && typeof fifuQuickEditorOpen !== 'undefined'
        && fifuQuickEditorOpen
        && typeof fifuColumnVars !== 'undefined'
        && fifuColumnVars.onProductsPage
    ) {
        if (typeof fifu_activate_quick_slider_competing_state === 'function') {
            fifu_activate_quick_slider_competing_state();
        }
    }

    fifu_check_slider_grid_images();
    fifu_update_slider_ratio_visibility();

    fifu_update_wp_image_and_gallery_by_slider();
    fifu_update_slider_upload_visibility();

    if (typeof fifu_update_quick_upload_button_visibility === 'function') {
        fifu_update_quick_upload_button_visibility();
    }

    if (
        typeof fifu_get_quick_selected_media_type === 'function'
        && typeof fifu_update_quick_featured_media_preview === 'function'
        && fifu_get_quick_selected_media_type() === 'slider'
    ) {
        fifu_update_quick_featured_media_preview('slider');
    }
}

// quick edit

function fifu_slider_info(post_id) {
    const payload = fifuQuickEditVars.posts[post_id] || {};
    fifuSliderVars.urls = payload['fifu_slider_image_urls'] || [];
    fifuSliderVars.alts = payload['fifu_slider_image_alts'] || [];

    const $quickRatio = jQuery('#fifu-quick-slider-input-ratio');
    if ($quickRatio.length) {
        const ratio = payload['fifu_slider_ratio'] || '';
        $quickRatio.val(ratio).attr('data-fifu-slider-ratio-initial-value', ratio);
    }
}

function fifu_check_slider_grid_images() {
    jQuery('div.grid-square').each(function () {
        let $div = jQuery(this);
        let bg = $div.css('background');
        let match = bg && bg.match(/url\(["']?([^"')]+)["']?\)/);
        let imageUrl = match ? match[1] : null;

        // If the slot is empty or undefined, clear the background and opacity
        if (!imageUrl || imageUrl === 'undefined' || imageUrl === '') {
            $div.css('background', '');
            $div.css('opacity', '');
            return;
        }

        // Ignore local images (relative or root-relative paths)
        if (
                imageUrl.startsWith('/') ||
                imageUrl.startsWith('./') ||
                imageUrl.startsWith('../')
                ) {
            return;
        }

        // If the slot already has the not found image, just set opacity
        if (window.FIFU_IMAGE_NOT_FOUND_URL && imageUrl === window.FIFU_IMAGE_NOT_FOUND_URL) {
            $div.css('opacity', '1');
            return;
        }

        // Only check and possibly replace if it's a real URL
        let img = new Image();
        img.onload = function () {
            // Image loaded successfully, ensure opacity is set
            $div.css('opacity', '1');
        };
        img.onerror = function () {
            // Image failed to load, set to not found image
            if (window.FIFU_IMAGE_NOT_FOUND_URL) {
                $div.css('background', 'url("' + window.FIFU_IMAGE_NOT_FOUND_URL + '") center center / cover no-repeat');
                $div.css('opacity', '1');
            } else {
                $div.css('background', '');
                $div.css('opacity', '');
            }
        };
        img.src = imageUrl;
    });
}

function fifu_update_wp_image_and_gallery_by_slider() {
    var $postImageDiv = jQuery('#postimagediv');
    var $postImageToggle = $postImageDiv.find('.handlediv');
    var $galleryBox = jQuery('#woocommerce-product-images');
    var $galleryToggle = $galleryBox.find('.handlediv');
    var $urlMetaBox = jQuery('#urlMetaBox');
    var $urlMetaToggle = $urlMetaBox.find('.handlediv');
    var $wooVideoUrlMetaBox = jQuery('#wooVideoUrlMetaBox');
    var $wooVideoUrlToggle = $wooVideoUrlMetaBox.find('.handlediv');
    var $audioMetaBox = jQuery('#audioMetaBox');
    var $audioMetaToggle = $audioMetaBox.find('.handlediv');

    // Check if any slider hidden input has a real URL
    var hasSliderImage = jQuery('input[id^="fifu_slider_input_url_"]').filter(function () {
        var url = jQuery(this).val();
        return url && url !== 'undefined' && url.startsWith('http');
    }).length > 0;

    if (typeof fifu_set_native_featured_image_visibility === 'function') {
        fifu_set_native_featured_image_visibility(!hasSliderImage);
    }

    if (hasSliderImage) {
        $postImageDiv.addClass('closed');
        $postImageToggle.attr('aria-expanded', 'false').prop('disabled', true);
        $galleryBox.addClass('closed');
        $galleryToggle.attr('aria-expanded', 'false').prop('disabled', true);
        $urlMetaBox.addClass('closed');
        $urlMetaToggle.attr('aria-expanded', 'false').prop('disabled', true);
        $wooVideoUrlMetaBox.addClass('closed');
        $wooVideoUrlToggle.attr('aria-expanded', 'false').prop('disabled', true);
        $audioMetaBox.addClass('closed');
        $audioMetaToggle.attr('aria-expanded', 'false').prop('disabled', true);
    } else {
        $postImageDiv.removeClass('closed');
        $postImageToggle.attr('aria-expanded', 'true').prop('disabled', false);
        $galleryBox.removeClass('closed');
        $galleryToggle.attr('aria-expanded', 'true').prop('disabled', false);
        $urlMetaBox.removeClass('closed');
        $urlMetaToggle.attr('aria-expanded', 'true').prop('disabled', false);
        $wooVideoUrlMetaBox.removeClass('closed');
        $wooVideoUrlToggle.attr('aria-expanded', 'true').prop('disabled', false);
        $audioMetaBox.removeClass('closed');
        $audioMetaToggle.attr('aria-expanded', 'true').prop('disabled', false);
    }
}
