var metaIntervalId = null;
var contentIntervalId = null;
var fifuMetainLoopRunning = false;
var fifuMetainStopRequested = false;
var fifuMetaoutLoopRunning = false;

jQuery(document).ready(function () {
    var $startAccordion = jQuery('#fifu-start-accordion');
    if ($startAccordion.length) {
        $startAccordion.accordion({
            active: 0,
            collapsible: true,
            heightStyle: 'content',
            icons: false
        });
    }

    jQuery('link[href*="jquery-ui.css"]').attr("disabled", "true");
    jQuery('div.wrap div.header-box div.notice').hide();
    jQuery('div.wrap div.header-box div#message').hide();
    jQuery('div.wrap div.header-box div.updated').remove();
});

var restUrl = fifuScriptVars.restUrl;

function invert(id) {
    if (jQuery("#fifu_toggle_" + id).attr("class") == "toggleon") {
        jQuery("#fifu_toggle_" + id).attr("class", "toggleoff");
        jQuery("#fifu_input_" + id).val('off');
    } else {
        jQuery("#fifu_toggle_" + id).attr("class", "toggleon");
        jQuery("#fifu_input_" + id).val('on');
    }
}

function fifu_sync_autoplay_front_all_visibility() {
    const parentClass =
        jQuery('#fifu_toggle_autoplay_front').attr('class') || '';

    if (parentClass.split(/\s+/).includes('toggleon')) {
        jQuery('#fifu_autoplay_front_all_row').show();
    } else {
        jQuery('#fifu_autoplay_front_all_row').hide();
    }
}

jQuery(function () {
    var url = window.location.href;

    jQuery("#tabs-top").tabs();
    jQuery("#fifu_input_slider_speed").spinner({min: 0});
    jQuery("#fifu_input_slider_pause").spinner({min: 0});
    jQuery("#fifu_input_auto_set_width").spinner({min: 0});
    jQuery("#fifu_input_auto_set_height").spinner({min: 0});
    jQuery("#tabsApi").addClass("ui-tabs-vertical ui-helper-clearfix");
    jQuery("#tabsApi li").removeClass("ui-corner-top").addClass("ui-corner-left");
    jQuery("#tabsApi").tabs();
    jQuery("#tabsMedia").tabs();
    jQuery("#tabsPremium").tabs();
    jQuery("#tabsWooImport").tabs();
    jQuery("#tabsWpAllImport").tabs();
    jQuery("#tabsDefault").tabs();
    jQuery("#tabsHide").tabs();
    jQuery("#tabsPcontent").tabs();
    jQuery("#tabsJetpack").tabs();
    jQuery("#tabsJetpackSizes").tabs();
    jQuery("#tabsShortcode").tabs();
    jQuery("#tabsFifuShortcode").tabs();
    jQuery("#tabsAutoSet").tabs();
    jQuery("#tabsAutoSetSub").tabs();
    jQuery("#tabsAutoShare").tabs();
    jQuery("#tabsAutoShareSub").tabs();
    jQuery("#tabsTags").tabs();
    jQuery("#tabsScreenshot").tabs();
    jQuery("#tabsAsin").tabs();
    jQuery("#tabsCustomfield").tabs();
    jQuery("#tabsFinder").tabs();
    jQuery("#tabsVideo").tabs();
    jQuery("#tabsVimeoOptions").tabs();
    jQuery("#tabsVimeoMp4Options").tabs();
    jQuery("#tabsContent").tabs();
    jQuery("#tabsCli").tabs();
    jQuery("#tabsKey").tabs();
    jQuery("#tabsGallery").tabs();
    var brokenLinksTableLoading = false;
    jQuery("#tabsLinkChecker").tabs({
        activate: function (event, ui) {
            if (ui.newPanel.attr('id') !== 'tabsLinkChecker-broken-links') {
                return;
            }

            var table = jQuery('#fifu_broken_links_table');
            if (jQuery.fn.DataTable && jQuery.fn.DataTable.isDataTable(table[0])) {
                table.DataTable().columns.adjust();
                return;
            }

            if (brokenLinksTableLoading) {
                return;
            }

            brokenLinksTableLoading = true;
            table.DataTable({
                language: {emptyTable: fifuScriptVars.noBrokenImageUrls},
                autoWidth: false,
                ajax: {
                    url: fifuScriptVars.adminAjaxUrl,
                    type: 'POST',
                    data: {
                        action: 'fifu_broken_links',
                        nonce: fifuScriptVars.brokenLinksNonce
                    },
                    dataSrc: 'data'
                },
                columns: [
                    {data: 0},
                    {data: 1}
                ],
                initComplete: function () {
                    brokenLinksTableLoading = false;
                }
            });
        }
    });
    fifu_sync_autoplay_front_all_visibility();

    //forms with id started by...
    jQuery("form[id^=fifu_form]").each(function (i, el) {
        if (
            el &&
            (el.id === 'fifu_form_auto_share_test' || el.id === 'fifu_form_otfcdn')
        ) {
            return true;
        }
        jQuery(this).find("input[type=text]").on("change", function () {
            save(this);
        });

        //onchange
        jQuery(this).change(function () {
            save(this);
        });
        if (isClickable(el.id)) {
            let timer;
            //onclick
            jQuery(this).click(function () {
                clearTimeout(timer);
                timer = setTimeout(() => {
                    save(this);
                }, 500);
            });
        } else {
            //onsubmit
            jQuery(this).submit(function () {
                save(this);
            });
        }
    });

    // show settings
    window.scrollTo(0, 0);
    if (fifuScriptVars.lock || fifuScriptVars.emptyKey) {
        let currentUrl = new URL(window.location.href);
        if (currentUrl.searchParams.get('page') !== 'fifu-license-key') {
            currentUrl.searchParams.set('page', 'fifu-license-key');
            window.location.href = currentUrl.toString();
        }
    }
    jQuery('.wrap').css('opacity', 1);
    fifu_resume_manual_metadata_operations().catch(function () {
        return null;
    });
});

function isClickable(id) {
    return id.match("fifu_form_slider_speed") || id.match("fifu_form_slider_pause") || id.match("fifu_form_auto_set_dimensions") || id.match("fifu_form_spinner");
}

function save(formName, url) {
    var frm = jQuery(formName);
    showMessage('Processing...', fifuScriptVars.saving + '...', 'processing');
    jQuery.ajax({
        type: frm.attr('method'),
        url: url,
        data: frm.serialize(),
        success: function (data) {
            updateMessage('Success', fifuScriptVars.saved, 'success');
            if (frm.attr('id') === 'fifu_form_vimeo_access_token') {
                refreshVimeoAccessTokenScopesIcon();
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            updateMessage('Error', fifuScriptVars.error + ' ' + errorThrown, 'error');
        }
    });
}

function refreshVimeoAccessTokenScopesIcon() {
    jQuery.ajax({
        url: typeof ajaxurl !== 'undefined' ? ajaxurl : fifuAsyncVars.ajaxUrl,
        method: 'POST',
        data: {
            action: 'fifu_vimeo_access_token_scopes_status',
            security: fifuScriptVars.nonce
        },
        success: function (response) {
            if (!response || !response.success || !response.data) {
                return;
            }

            const $icon = jQuery('#fifu-vimeo-access-token-scopes-icon');
            $icon
                .removeClass('fifu-vimeo-token-scopes-ok fifu-vimeo-token-scopes-missing')
                .addClass(response.data.classToAdd)
                .css('color', response.data.ok ? 'rgb(90, 180, 100)' : 'rgb(163, 60, 46)');
        }
    });
}

function showMessage(title, message, state) {
    var dialog = jQuery("#dialog-message");
    jQuery("#dialog-message-content").text(message);

    // Add class based on state
    if (state === 'success') {
        dialog.removeClass('custom-dialog-error custom-dialog-processing').addClass('custom-dialog-success');
    } else if (state === 'error') {
        dialog.removeClass('custom-dialog-success custom-dialog-processing').addClass('custom-dialog-error');
    } else {
        dialog.removeClass('custom-dialog-success custom-dialog-error').addClass('custom-dialog-processing');
    }

    dialog.css({
        display: 'block'
    }).fadeIn(300);
}

function updateMessage(title, message, state) {
    var dialog = jQuery("#dialog-message");
    jQuery("#dialog-message-content").text(message);

    // Add class based on state
    if (state === 'success') {
        dialog.removeClass('custom-dialog-error custom-dialog-processing').addClass('custom-dialog-success');
    } else if (state === 'error') {
        dialog.removeClass('custom-dialog-success custom-dialog-processing').addClass('custom-dialog-error');
    }

    dialog.delay(2000).fadeOut(300);
}

function refresh() {
    setInterval(function () {
        jQuery('div[id^=fifu_ajax]').load('admin.php?page=fifu-premium div[id^=fifu_ajax]');
    }, 1000)
}

function fifu_default_js() {
    jQuery('#tabs-top').block({message: fifuScriptVars.wait, css: {backgroundColor: 'none', border: 'none', color: 'white'}});

    let toggle = jQuery("#fifu_toggle_enable_default_url").attr('class');
    switch (toggle) {
        case "toggleoff":
            option = "disable_default_api";
            break;
        default:
            let url = jQuery("#fifu_input_default_url").val();
            option = url ? "none_default_api" : "disable_default_api";
    }
    jQuery.ajax({
        method: "POST",
        url: restUrl + 'fifu-premium/v2/' + option + '/',
        async: true,
        beforeSend: function (xhr) {
            xhr.setRequestHeader('X-WP-Nonce', fifuScriptVars.nonce);
        },
        success: function (data) {
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(jqXHR);
            console.log(textStatus);
            console.log(errorThrown);
        },
        complete: function () {
            setTimeout(function () {
                jQuery('#tabs-top').unblock();
            }, 1000);
        },
        timeout: 0
    });
}

function fifu_sizes_js() {
    jQuery('#tabs-top').block({message: fifuScriptVars.wait, css: {backgroundColor: 'none', border: 'none', color: 'white'}});

    jQuery.ajax({
        method: "POST",
        url: restUrl + 'fifu-premium/v2/load-sizes-api/',
        async: true,
        beforeSend: function (xhr) {
            xhr.setRequestHeader('X-WP-Nonce', fifuScriptVars.nonce);
        },
        success: function (data) {
            const table = jQuery('#fifu-sizes-table');

            // Clear existing rows and footer
            table.find('tr:not(:first)').remove();
            jQuery('.fifu-sizes-footer').remove();

            // Build new rows
            jQuery.each(data, function (sizeName, sizeData) {
                const row = jQuery('<tr class="color">');

                // Format size name for display
                let displayName = sizeName;
                if (sizeName === 'empty') {
                    displayName = '(empty)';
                } else if (sizeName.match(/^\d+x\d+x\d+$/)) {
                    displayName = sizeName.replace(/^(\d+x\d+)x\d+$/, '($1)');
                }

                // Size Name
                row.append(jQuery('<td>').text(displayName));

                // Width Input
                row.append(jQuery('<td>').append(
                        jQuery('<input>')
                        .attr('type', 'number')
                        .attr('min', '0')
                        .attr('pattern', '[0-9]*')
                        .attr('onkeypress', 'return event.charCode >= 48 && event.charCode <= 57')
                        .attr('name', `fifu_size_${sizeName}_width`)
                        .attr('id', `fifu_size_${sizeName}_width`)
                        .attr('data-size', sizeName)
                        .attr('data-dimension', 'width')
                        .addClass('fifu-size-input')
                        .val(sizeData.w > 0 ? sizeData.w : '')
                        ));

                // Height Input
                row.append(jQuery('<td>').append(
                        jQuery('<input>')
                        .attr('type', 'number')
                        .attr('min', '0')
                        .attr('pattern', '[0-9]*')
                        .attr('onkeypress', 'return event.charCode >= 48 && event.charCode <= 57')
                        .attr('name', `fifu_size_${sizeName}_height`)
                        .attr('id', `fifu_size_${sizeName}_height`)
                        .attr('data-size', sizeName)
                        .attr('data-dimension', 'height')
                        .addClass('fifu-size-input')
                        .val(sizeData.h > 0 ? sizeData.h : '')
                        ));

                // Cropped Checkbox
                row.append(jQuery('<td>').append(
                        jQuery('<input>')
                        .attr('type', 'checkbox')
                        .attr('name', `fifu_size_${sizeName}_crop`)
                        .attr('id', `fifu_size_${sizeName}_crop`)
                        .attr('data-size', sizeName)
                        .attr('data-dimension', 'crop')
                        .addClass('fifu-crop-checkbox')
                        .prop('checked', sizeData.c)
                        ));

                // Pages
                row.append(jQuery('<td>').text(
                        sizeData.pages.join(', ')
                        ));

                table.append(row);
            });

            // Add footer with buttons
            const footer = jQuery('<div class="fifu-sizes-footer"></div>');

            // Style for the footer - align to right side
            footer.css({
                'padding-top': '5px',
                'display': 'flex',
                'justify-content': 'flex-end', // Right alignment
                'gap': '5px'
            });

            // Create buttons with appropriate names and icons
            const resetButton = jQuery('<button id="fifu-sizes-reset" class="button fifu-action-button">' +
                    '<i class="fa-solid fa-arrows-rotate"></i> ' + fifuScriptVars.reset + '</button>');
            const saveButton = jQuery('<button id="fifu-sizes-save" class="button fifu-action-button">' +
                    '<i class="fa-solid fa-floppy-disk"></i> ' + fifuScriptVars.save + '</button>');

            // Apply shared styles to buttons
            [resetButton, saveButton].forEach(button => {
                button.css({
                    'width': '10%',
                    'height': '28px',
                    'display': 'flex',
                    'align-items': 'center',
                    'justify-content': 'center',
                    'gap': '5px',
                    'color': '#333333',
                    'border-color': '#333333',
                });
            });

            // Enable/disable based on table content
            const hasRows = table.find('tr').length > 1;
            resetButton.prop('disabled', !hasRows);
            saveButton.prop('disabled', !hasRows);

            // Add click handlers with appropriate functions
            resetButton.on('click', fifu_reset_sizes);
            saveButton.on('click', fifu_save_sizes);

            footer.append(resetButton);
            footer.append(saveButton);
            table.after(footer);

            // Add shared button styles (only if not already added)
            if (!jQuery('#fifu-buttons-style').length) {
                jQuery('<style id="fifu-buttons-style">')
                        .text(`
                        .fifu-action-button {
                            background-color: #f0f0f1;
                            border: 1px solid #2271b1;
                            border-radius: 3px;
                            color: #2271b1;
                            cursor: pointer;
                            transition: all 0.3s ease;
                        }
                        .fifu-action-button:hover {
                            background-color: #2271b1;
                            color: #fff;
                        }
                        .fifu-action-button:disabled {
                            opacity: 0.6;
                            cursor: not-allowed;
                        }
                        .fifu-action-button svg {
                            width: 14px;
                            height: 14px;
                            margin-right: 5px;
                        }`)
                        .appendTo('head');
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(jqXHR);
            console.log(textStatus);
            console.log(errorThrown);
        },
        complete: function () {
            setTimeout(function () {
                jQuery('#tabs-top').unblock();
            }, 1000);
        },
        timeout: 0
    });
}

function fifu_reset_sizes() {
    jQuery('#tabs-top').block({message: fifuScriptVars.wait, css: {backgroundColor: 'none', border: 'none', color: 'white'}});

    jQuery.ajax({
        method: "POST",
        url: restUrl + 'fifu-premium/v2/reset-sizes-api/',
        async: true,
        beforeSend: function (xhr) {
            xhr.setRequestHeader('X-WP-Nonce', fifuScriptVars.nonce);
        },
        success: function (data) {
            fifu_sizes_js();
            save(null, null)
        },
        complete: function () {
            setTimeout(function () {
                jQuery('#tabs-top').unblock();
            }, 1000);
        },
        timeout: 0
    });
}

function fifu_save_sizes() {
    jQuery('#tabs-top').block({message: fifuScriptVars.wait, css: {backgroundColor: 'none', border: 'none', color: 'white'}});

    const sizeData = {};
    jQuery('#fifu-sizes-table tr:not(:first)').each(function () {
        const row = jQuery(this);
        const sizeName = row.find('.fifu-size-input').first().data('size');
        sizeData[sizeName] = {
            width: parseInt(row.find('[data-dimension="width"]').val()) || 0,
            height: parseInt(row.find('[data-dimension="height"]').val()) || 0,
            crop: row.find('[data-dimension="crop"]').prop('checked')
        };
    });

    jQuery.ajax({
        method: "POST",
        url: restUrl + 'fifu-premium/v2/save-sizes-api/',
        data: JSON.stringify(sizeData),
        contentType: 'application/json',
        beforeSend: function (xhr) {
            xhr.setRequestHeader('X-WP-Nonce', fifuScriptVars.nonce);
        },
        success: function (response) {
            save(null, null);
        },
        complete: function () {
            setTimeout(function () {
                jQuery('#tabs-top').unblock();
            }, 1000);
        },
    });
}

function fifu_refresh_rest_nonce() {
    return new Promise(function (resolve, reject) {
        jQuery.ajax({
            method: 'POST',
            url: typeof ajaxurl !== 'undefined' ? ajaxurl : fifuAsyncVars.ajaxUrl,
            data: {action: 'rest-nonce'},
            success: function (response) {
                var nonce = String(response == null ? '' : response).trim();
                if (!nonce || nonce === '0' || nonce === '-1') {
                    var expired = new Error('WordPress session expired; login required');
                    expired.code = 'session_expired';
                    reject(expired);
                    return;
                }
                fifuScriptVars.nonce = nonce;
                resolve(nonce);
            },
            error: function () {
                var expired = new Error('WordPress session expired; login required');
                expired.code = 'session_expired';
                reject(expired);
            }
        });
    });
}

function fifu_metain_request(endpoint, allowNonceRefresh = true) {
    return new Promise(function (resolve, reject) {
        jQuery.ajax({
            method: 'POST',
            url: restUrl + 'fifu-premium/v2/' + endpoint + '/',
            async: true,
            timeout: 0,
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-WP-Nonce', fifuScriptVars.nonce);
            },
            success: resolve,
            error: function (jqXHR) {
                var httpStatus = jqXHR && jqXHR.status;
                if (allowNonceRefresh && (httpStatus === 401 || httpStatus === 403)) {
                    fifu_refresh_rest_nonce()
                        .then(function () {
                            return fifu_metain_request(endpoint, false);
                        })
                        .then(resolve)
                        .catch(reject);
                    return;
                }
                var error = new Error(httpStatus ? 'Manual metadata request failed: ' + httpStatus : 'Manual metadata request interrupted');
                error.status = httpStatus || 0;
                reject(error);
            }
        });
    });
}

function fifu_metaout_request(endpoint, allowNonceRefresh = true) {
    return new Promise(function (resolve, reject) {
        jQuery.ajax({
            method: 'POST',
            url: restUrl + 'fifu-premium/v2/' + endpoint + '/',
            async: true,
            timeout: 0,
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-WP-Nonce', fifuScriptVars.nonce);
            },
            success: resolve,
            error: function (jqXHR) {
                var httpStatus = jqXHR && jqXHR.status;
                if (allowNonceRefresh && (httpStatus === 401 || httpStatus === 403)) {
                    fifu_refresh_rest_nonce()
                        .then(function () {
                            return fifu_metaout_request(endpoint, false);
                        })
                        .then(resolve)
                        .catch(reject);
                    return;
                }
                var error = new Error(httpStatus ? 'Manual metadata request failed: ' + httpStatus : 'Manual metadata request interrupted');
                error.status = httpStatus || 0;
                if (jqXHR && jqXHR.responseJSON && jqXHR.responseJSON.code) {
                    error.code = jqXHR.responseJSON.code;
                }
                reject(error);
            }
        });
    });
}

function fifu_render_metain_progress(status) {
    status = status || {};
    var state = status.state || 'idle';
    var percent = Math.max(0, Math.min(100, parseInt(status.percent, 10) || 0));
    jQuery('#fifu_image_metadata_progress').val(percent);
    jQuery('#fifu_image_metadata_progress_percent').text(percent + '%');
    if (state === 'idle' || state === 'complete') {
        jQuery('#fifu_image_metadata_progress_wrap').hide();
    } else {
        jQuery('#fifu_image_metadata_progress_wrap').show();
    }
}

function fifu_is_transient_metain_error(error) {
    if (error && error.code === 'session_expired') {
        return false;
    }

    var status = Number(error && error.status) || 0;

    return status === 0
        || status === 408
        || status === 429
        || status === 500
        || status === 502
        || status === 503
        || status === 504;
}

async function fifu_run_manual_metain_loop() {
    if (fifuMetainLoopRunning) {
        return;
    }
    fifuMetainLoopRunning = true;
    try {
        var transientRetries = 0;
        var maxTransientRetries = 3;

        while (!fifuMetainStopRequested) {
            var status;

            try {
                status = await fifu_metain_request('metain_batch_api');
                transientRetries = 0;
            } catch (error) {
                if (!fifu_is_transient_metain_error(error) || transientRetries >= maxTransientRetries) {
                    throw error;
                }

                transientRetries++;

                await new Promise(function (resolve) {
                    setTimeout(resolve, transientRetries * 1000);
                });

                continue;
            }

            if (fifuMetainStopRequested) {
                break;
            }
            fifu_render_metain_progress(status);
            if (!status || status.done || status.state !== 'running' || !status.running) {
                break;
            }
        }
    } catch (error) {
    } finally {
        fifuMetainLoopRunning = false;
        jQuery('#tabs-top').unblock();
    }
}

async function fifu_resume_manual_metain() {
    try {
        var status = await fifu_metain_request('metain_status_api');
        fifu_render_metain_progress(status);
        if (status && status.state === 'running' && status.running && !status.done) {
            fifuMetainStopRequested = false;
            await fifu_run_manual_metain_loop();
        }
    } catch (error) {
    }
}

function fifu_metaout_render(status) {
    status = status || {};
    var state = status.state || 'idle';
    var total = Math.max(0, Number(status.total) || 0);
    var processed = Math.max(0, Number(status.processed) || 0);
    var percent = Math.max(0, Math.min(100, parseInt(status.percent, 10) || 0));
    var wrap = jQuery('#fifu_clear_metadata_progress_wrap');
    var progress = jQuery('#fifu_clear_metadata_progress');
    var percentElement = jQuery('#fifu_clear_metadata_progress_percent');
    if (state === 'idle' || state === 'complete') {
        wrap.hide();
    } else {
        wrap.show();
    }
    progress.prop('max', Math.max(1, total));
    progress.val(processed);
    percentElement.text(percent + '%');
}

async function fifu_run_manual_metaout_loop(initialStatus) {
    if (fifuMetaoutLoopRunning) {
        return initialStatus;
    }
    fifuMetaoutLoopRunning = true;
    var status = initialStatus;
    try {
        fifu_metaout_render(status);
        while (status && status.state === 'running' && status.done !== true) {
            status = await fifu_metaout_request('metaout_batch_api');
            fifu_metaout_render(status);
        }
        return status;
    } finally {
        fifuMetaoutLoopRunning = false;
        jQuery('#tabs-top').unblock();
    }
}

async function fifu_resume_manual_metaout() {
    var status = await fifu_metaout_request('metaout_status_api');
    fifu_metaout_render(status);
    if (status && status.state === 'running' && status.done !== true) {
        return fifu_run_manual_metaout_loop(status);
    }
    return status;
}

async function fifu_resume_manual_metadata_operations() {
    var metaoutStatus = await fifu_resume_manual_metaout();
    if (metaoutStatus && metaoutStatus.state === 'running' && metaoutStatus.done !== true) {
        return metaoutStatus;
    }
    return fifu_resume_manual_metain();
}

async function fifu_fake_js() {
    var toggle = jQuery('#fifu_toggle_fake').attr('class');
    if (toggle !== 'toggleon' && toggle !== 'toggleoff') {
        jQuery('#tabs-top').unblock();
        return;
    }
    jQuery('#tabs-top').block({message: fifuScriptVars.wait, css: {backgroundColor: 'none', border: 'none', color: 'white'}});
    try {
        fifuMetainStopRequested = toggle === 'toggleoff';
        var status = await fifu_metain_request(toggle === 'toggleon' ? 'enable_fake_api' : 'disable_fake_api');
        fifu_render_metain_progress(status);
        if (toggle === 'toggleon') {
            jQuery('#fifu_toggle_cron_metadata').attr('class', 'toggleoff');
            if (status && status.state === 'running' && status.running && !status.done) {
                await fifu_run_manual_metain_loop();
            } else {
                jQuery('#tabs-top').unblock();
            }
        } else {
            jQuery('#tabs-top').unblock();
        }
    } catch (error) {
        jQuery('#tabs-top').unblock();
    }
}

function fifu_clean_js() {
    if (jQuery("#fifu_toggle_data_clean").attr('class') != 'toggleon')
        return Promise.resolve(null);

    return fifu_run_clean_js().catch(function () {
        return null;
    });
}

async function fifu_run_clean_js() {
    jQuery('#tabs-top').block({message: fifuScriptVars.wait, css: {backgroundColor: 'none', border: 'none', color: 'white'}});
    try {
        var status = await fifu_metaout_request('data_clean_api');
        fifu_metaout_render(status);
        if (status && status.state === 'running' && status.done !== true) {
            status = await fifu_run_manual_metaout_loop(status);
        }
        jQuery("#fifu_toggle_data_clean").attr('class', 'toggleoff');
        jQuery("#fifu_toggle_fake").attr('class', 'toggleoff');
        jQuery("#fifu_toggle_cron_metadata").attr('class', 'toggleoff');
        return status;
    } catch (error) {
        fifu_metaout_render({state: error && error.code === 'fifu_manual_metaout_busy' ? 'busy' : 'error'});
        throw error;
    } finally {
        jQuery('#tabs-top').unblock();
    }
}

function fifu_update_all_js() {
    if (jQuery("#fifu_toggle_update_all").attr('class') != 'toggleon')
        return;

    jQuery('#tabs-top').block({message: fifuScriptVars.wait, css: {backgroundColor: 'none', border: 'none', color: 'white'}});

    jQuery.ajax({
        method: "POST",
        url: restUrl + 'fifu-premium/v2/update_all_api/',
        async: true,
        beforeSend: function (xhr) {
            xhr.setRequestHeader('X-WP-Nonce', fifuScriptVars.nonce);
        },
        success: function (data) {
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(jqXHR);
            console.log(textStatus);
            console.log(errorThrown);
        },
        complete: function () {
            setTimeout(function () {
                jQuery("#fifu_toggle_update_all").attr('class', 'toggleoff');
                updateContentCounter(false);
                contentIntervalId = setInterval(updateContentCounter.bind(null, true), 3000);
            }, 1000);
        },
        timeout: 0
    });
}

async function fifu_run_delete_all_js() {
    if (jQuery("#fifu_toggle_run_delete_all").attr('class') != 'toggleon')
        return null;

    var cleanupStatus;
    try {
        cleanupStatus = await fifu_run_clean_js();
    } catch (error) {
        return null;
    }
    if (!cleanupStatus || cleanupStatus.state !== 'complete' || cleanupStatus.done !== true) {
        return cleanupStatus || null;
    }

    jQuery('#tabs-top').block({message: fifuScriptVars.wait, css: {backgroundColor: 'none', border: 'none', color: 'white'}});
    try {
        return await new Promise(function (resolve, reject) {
            jQuery.ajax({
                method: "POST",
                url: restUrl + 'fifu-premium/v2/run_delete_all_api/',
                async: true,
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('X-WP-Nonce', fifuScriptVars.nonce);
                },
                success: resolve,
                error: function (jqXHR) {
                    reject(new Error('Delete All request failed: ' + ((jqXHR && jqXHR.status) || 0)));
                },
                timeout: 0
            });
        });
    } finally {
        jQuery("#fifu_toggle_run_delete_all").attr('class', 'toggleoff');
        jQuery('#tabs-top').unblock();
    }
}

function fifu_api_cron(toggleId) {
    jQuery('#tabs-top').block({message: fifuScriptVars.wait, css: {backgroundColor: 'none', border: 'none', color: 'white'}});

    let toggle = jQuery(`#${toggleId}`).attr('class');
    switch (toggle) {
        case "toggleon":
            option = "cron-add";
            break;
        case "toggleoff":
            option = "cron-delete";
            break;
        default:
            return;
    }

    jQuery.ajax({
        method: "POST",
        url: `${restUrl}fifu-premium/v2/${option}/`,
        data: {
            "toggle": toggleId,
        },
        async: true,
        beforeSend: function (xhr) {
            xhr.setRequestHeader('X-WP-Nonce', fifuScriptVars.nonce);
        },
        success: function (data) {
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(jqXHR);
            console.log(textStatus);
            console.log(errorThrown);
        },
        complete: function () {
            setTimeout(function () {
                jQuery('#tabs-top').unblock();
            }, 1000);
        },
        timeout: 0
    });
}

function updateMetadataCounter(transient) {
    jQuery.ajax({
        url: `${restUrl}fifu-premium/v2/metadata_counter_api/`,
        data: {
            "transient": transient,
        },
        method: 'POST',
        async: false,
        beforeSend: function (xhr) {
            xhr.setRequestHeader('X-WP-Nonce', fifuScriptVars.nonce);
        },
        success: function (response) {
            jQuery('#image_metadata_counter').text(response);

            let metadataCounterValue = parseInt(jQuery('#image_metadata_counter').text().trim());
            if ((metadataCounterValue === 0 && jQuery('#fifu_toggle_data_clean').hasClass('toggleoff'))) {
                if (typeof metaIntervalId !== 'undefined')
                    clearInterval(metaIntervalId);
                jQuery('#tabs-top').unblock();
            }
        },
        error: function (xhr, status, error) {
            console.error('Error updating metadata counter:', error);
        },
        timeout: 60000
    });
}

function updateContentCounter(transient) {
    jQuery.ajax({
        url: `${restUrl}fifu-premium/v2/content_counter_api/`,
        data: {
            "transient": transient,
        },
        method: 'POST',
        async: false,
        beforeSend: function (xhr) {
            xhr.setRequestHeader('X-WP-Nonce', fifuScriptVars.nonce);
        },
        success: function (response) {
            jQuery('#image_content_counter').text(response);

            let contentCounterValue = parseInt(jQuery('#image_content_counter').text().trim());
            if ((contentCounterValue === 0 && jQuery('#fifu_toggle_update_all').hasClass('toggleoff'))) {
                if (typeof contentIntervalId !== 'undefined')
                    clearInterval(contentIntervalId);
                jQuery('#tabs-top').unblock();
            }
        },
        error: function (xhr, status, error) {
            console.error('Error updating metadata counter:', error);
        },
        timeout: 60000
    });
}

function fifu_check_for_updates() {
    const rawLicenseKey = jQuery('#fifu_input_key').val();
    const licenseKey = typeof rawLicenseKey === 'string' ? rawLicenseKey.trim() : '';
    const $btn = jQuery('#fifu_form_key input[type=submit]');

    $btn.prop('disabled', true);
    let redirected = false;

    jQuery.ajax({
        method: 'POST',
        url: restUrl + 'fifu-premium/v2/check_for_updates_api/',
        beforeSend: function (xhr) {
            xhr.setRequestHeader('X-WP-Nonce', fifuScriptVars.nonce);
        },
        data: {
            key: licenseKey,
            network: fifuScriptVars?.networkAdmin ? 1 : 0,
        },
        timeout: 60000,
        success: function (data) {
            if (data && data.status) {
                redirected = true;
                setTimeout(function () {
                    const currentUrl = new URL(window.location.href);
                    currentUrl.searchParams.set('page', 'fifu-premium');
                    window.location.href = currentUrl.toString();
                }, 1000);
            } else {
                jQuery('#tabs-top').unblock();
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(jqXHR, textStatus, errorThrown);
            jQuery('#tabs-top').unblock();
        },
        complete: function () {
            if (!redirected)
                $btn.prop('disabled', false);
        }
    });
}

function fifu_otfcdn_js() {
    jQuery('#tabs-top').block({message: fifuScriptVars.wait1, css: {backgroundColor: 'none', border: 'none', color: 'white'}});

    let toggle = jQuery("#fifu_toggle_otfcdn").attr('class');

    jQuery.ajax({
        method: "POST",
        url: restUrl + 'fifu-premium/v2/otfcdn-api/',
        async: true,
        beforeSend: function (xhr) {
            xhr.setRequestHeader('X-WP-Nonce', fifuScriptVars.nonce);
        },
        data: {
            toggle: toggle
        },
        success: function (data) {
            if (!data || data.success !== true) {
                invert('otfcdn');
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            invert('otfcdn');
            console.log(jqXHR);
            console.log(textStatus);
            console.log(errorThrown);
        },
        complete: function () {
            jQuery('#tabs-top').unblock();
        },
        timeout: 0
    });
}

jQuery(document).ready(function ($) {
    // Function to load JSON data into a container
    function loadJsonContent(containerId, jsonUrl, height) {
        const $container = $('#' + containerId);

        if ($container.data('loaded'))
            return;

        $container.html('<p>Loading JSON content...</p>');

        $.ajax({
            url: jsonUrl,
            dataType: 'json',
            success(data) {
                // Escapa HTML
                let jsonString = JSON.stringify(data, null, 2)
                        .replace(/&/g, '&amp;')
                        .replace(/</g, '&lt;')
                        .replace(/>/g, '&gt;');

                // Blue
                jsonString = jsonString.replace(
                        /"([^"]+)"(\s*:\s*)/g,
                        '"<span style="color:#0066B3">$1</span>"$2'
                        );

                // Green
                jsonString = jsonString.replace(
                        /(:\s*|\[\s*|,\s*)"(?!(?:&lt;|<))([^"]*)"/g,
                        '$1"<span style="color:#008000">$2</span>"'
                        );

                // Red for pipe |
                jsonString = jsonString.replace(
                        /\|/g,
                        '<span style="color:#d60000">|</span>'
                        );

                $container.html('<pre style="margin:0">' + jsonString + '</pre>');
                $container.data('loaded', true);
            },
            error(_, __, err) {
                $container.html('<p style="color:red">Error loading JSON content: ' + err + '</p>');
                console.error('Error loading JSON:', err);
            }
        });
    }

    // Add click handler to the developer tab
    $('a[href="#tabs-q"]').on('click', function () {
        // Load all JSON files in the developer tab when clicked
        loadJsonContent('product-json', fifuScriptVars.pluginUrl + '/admin/html/txt/product.json', 275);
        loadJsonContent('product-variation-json', fifuScriptVars.pluginUrl + '/admin/html/txt/product-variation.json', 450);
        loadJsonContent('post-json', fifuScriptVars.pluginUrl + '/admin/html/txt/post.json', 175);
        loadJsonContent('product-category-json', fifuScriptVars.pluginUrl + '/admin/html/txt/product-category.json', 250);
        loadJsonContent('product-variable-json', fifuScriptVars.pluginUrl + '/admin/html/txt/product-variable.json', 590);
        loadJsonContent('batch-product-json', fifuScriptVars.pluginUrl + '/admin/html/txt/batch-product.json', 535);
        loadJsonContent('batch-category-json', fifuScriptVars.pluginUrl + '/admin/html/txt/batch-category.json', 535);
    });
});
