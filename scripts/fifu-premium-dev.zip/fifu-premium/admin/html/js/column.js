var FIFU_IMAGE_NOT_FOUND_URL = 'https://storage.googleapis.com/featuredimagefromurl/image-not-found-a.jpg';
var FIFU_VIDEO_NOT_FOUND_URL = 'https://storage.googleapis.com/featuredimagefromurl/video-not-found-a.jpg';
var WC_PLACEHOLDER_IMAGE_URL = window.location.origin + '/wp-content/uploads/woocommerce-placeholder.webp';

jQuery(document).ready(function () {
    fifu_open_quick_lightbox();
    fifu_register_help_quick_edit();

    // Check all .fifu-quick thumbnails for invalid images or unsupported videos
    fifu_check_image_validity();
});

// Extract the image validity checking into a separate function
function fifu_check_image_validity() {
    jQuery('div.fifu-quick').each(function () {
        var $div = jQuery(this);
        var imageUrl = fifu_cdn_adjust($div.attr('image-url'));
        var videoUrl = $div.attr('video-url');
        var postId = $div.attr('post-id');

        // Skip if already processed
        if ($div.data('fifu-processed')) {
            return;
        }
        $div.data('fifu-processed', true);

        // VIDEO NOT FOUND: set background only, do NOT set placeholder for <img>
        if (videoUrl && typeof fifu_is_video === 'function' && !fifu_is_video(videoUrl)) {
            $div.css('background-image', 'url("' + FIFU_VIDEO_NOT_FOUND_URL + '")');
            // Update category thumbnail <img>
            jQuery(`tr#tag-${postId} td.thumb.column-thumb img[alt="Thumbnail"]`).each(function () {
                if (!jQuery(this).attr('src').includes('woocommerce-placeholder')) {
                    this.src = WC_PLACEHOLDER_IMAGE_URL;
                    this.removeAttribute('srcset');
                    this.removeAttribute('sizes');
                }
            });
            // Update product thumbnail <img>
            jQuery(`td.thumb.column-thumb a[href*="post=${postId}"] img`).each(function () {
                if (!jQuery(this).attr('src').includes('woocommerce-placeholder')) {
                    this.src = WC_PLACEHOLDER_IMAGE_URL;
                    this.removeAttribute('srcset');
                    this.removeAttribute('sizes');
                }
            });
            return;
        }

        // IMAGE NOT FOUND: set background only, do NOT set placeholder for <img>
        if (imageUrl) {
            var img = new Image();
            img.onerror = function () {
                $div.css('background-image', 'url("' + FIFU_IMAGE_NOT_FOUND_URL + '")');
                // Update category thumbnail <img>
                jQuery(`tr#tag-${postId} td.thumb.column-thumb img[alt="Thumbnail"]`).each(function () {
                    if (!jQuery(this).attr('src').includes('woocommerce-placeholder')) {
                        this.src = WC_PLACEHOLDER_IMAGE_URL;
                    }
                });
                // Update product thumbnail <img>
                jQuery(`td.thumb.column-thumb a[href*="post=${postId}"] img`).each(function () {
                    if (!jQuery(this).attr('src').includes('woocommerce-placeholder')) {
                        this.src = WC_PLACEHOLDER_IMAGE_URL;
                    }
                });
            };
            img.src = imageUrl;
        }
    });
}

// Add a mutation observer to detect new .fifu-quick elements
var observer = new MutationObserver(function (mutations) {
    mutations.forEach(function (mutation) {
        if (mutation.type === 'childList') {
            mutation.addedNodes.forEach(function (node) {
                if (node.nodeType === 1) { // Element node
                    // Check if the added node is a .fifu-quick element
                    if (jQuery(node).hasClass('fifu-quick')) {
                        setTimeout(fifu_check_image_validity, 100);
                    }
                    // Check if the added node contains .fifu-quick elements
                    if (jQuery(node).find('.fifu-quick').length > 0) {
                        setTimeout(fifu_check_image_validity, 100);
                    }
                }
            });
        }
    });
});

// Start observing
if (document.body) {
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
}

var currentLightbox = null;
var fifuPreviousInputs = [];
var fifuQuickUploadInFlight = false;
var fifuQuickUploadButtonLabel = null;
var fifuVariableProductCache = {};
var fifuVariableProductInFlight = {};
var fifuQuickEditItemCache = {};
var fifuQuickEditItemInFlight = {};
var fifuActiveQuickEditContext = null;
var fifuQuickEditClearRequested = false;
var fifuQuickEditClearedMediaTypes = {
    image: false,
    video: false,
    slider: false,
    audio: false
};
var fifuQuickEditorSaving = false;
var fifuQuickEditorOpen = false;
var fifuQuickEditorInitialFocusApplied = false;
var fifuQuickFeaturedImagePreviewedUrl = '';
var fifuQuickFeaturedMediaPreviewedUrls = {video: '', audio: ''};
var fifuQuickFeaturedMediaPreviewedThumbnailUrls = {audio: ''};
var fifuQuickFeaturedSliderPreviewKey = '';

function fifu_get_quick_hidden_input_value(inputId) {
    const $input = jQuery('#' + inputId);
    if (!$input.length) {
        return '';
    }

    const currentValue = $input.val();
    if (currentValue !== undefined && currentValue !== null && currentValue !== 'undefined') {
        return String(currentValue).trim();
    }

    const attrValue = $input.attr('value');
    if (attrValue !== undefined && attrValue !== null && attrValue !== 'undefined') {
        return String(attrValue).trim();
    }

    return '';
}

function fifu_set_quick_editor_saving_state(isSaving) {
    const $saveButton = jQuery('#fifu-save-button');
    const $clearButton = jQuery('#fifu-clean-button');
    if (!$saveButton.length) {
        return;
    }

    if (isSaving) {
        $saveButton
            .prop('disabled', true)
            .attr('aria-busy', 'true')
            .addClass('is-busy');
        if (!$saveButton.find('.fifu-quick-save-spinner').length) {
            $saveButton.prepend('<span class="fifu-quick-save-spinner" aria-hidden="true"></span>');
        }
        if ($clearButton.length) {
            $clearButton.prop('disabled', true);
        }
        return;
    }

    $saveButton
        .prop('disabled', false)
        .removeAttr('aria-busy')
        .removeClass('is-busy');
    $saveButton.find('.fifu-quick-save-spinner').remove();
    if ($clearButton.length) {
        $clearButton.prop('disabled', false);
    }
}

function fifu_set_copy_debug_button_state($button, label, cssClass, disabled) {
    if (!$button || !$button.length) {
        return;
    }

    $button.find('.fifu-copy-debug-data-label').text(label);
    $button.prop('disabled', !!disabled);
    $button.toggleClass('fifu-copy-debug-data-button--copied', cssClass === 'fifu-copy-debug-data-button--copied');
    $button.toggleClass('fifu-copy-debug-data-button--failed', cssClass === 'fifu-copy-debug-data-button--failed');
}

function fifu_escape_html(value) {
    return String(value === undefined || value === null ? '' : value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function fifu_load_variable_product(parentId) {
    const key = String(parentId);

    if (fifuVariableProductCache[key]) {
        return Promise.resolve(fifuVariableProductCache[key]);
    }

    if (fifuVariableProductInFlight[key]) {
        return fifuVariableProductInFlight[key];
    }

    fifuVariableProductInFlight[key] = new Promise(function (resolve, reject) {
        jQuery.ajax({
            method: 'GET',
            url: fifuColumnVars.restUrl + 'fifu-premium/v2/' + 'quick_edit_variations_api/',
            data: { parent_id: parentId },
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-WP-Nonce', fifuColumnVars.nonce);
            },
            success: function (response) {
                fifuVariableProductCache[key] = response;
                resolve(response);
            },
            error: function (xhr) {
                reject(xhr);
            },
            complete: function () {
                delete fifuVariableProductInFlight[key];
            }
        });
    });

    return fifuVariableProductInFlight[key];
}

function fifu_load_quick_edit_item(postId) {
    const key = String(postId);

    if (fifuQuickEditItemCache[key]) {
        return Promise.resolve(fifuQuickEditItemCache[key]);
    }

    if (fifuQuickEditItemInFlight[key]) {
        return fifuQuickEditItemInFlight[key];
    }

    fifuQuickEditItemInFlight[key] = new Promise(function (resolve, reject) {
        jQuery.ajax({
            method: 'GET',
            url: fifuColumnVars.restUrl + 'fifu-premium/v2/' + 'quick_edit_item_api/',
            data: { post_id: postId },
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-WP-Nonce', fifuColumnVars.nonce);
            },
            success: function (response) {
                fifuQuickEditItemCache[key] = response;
                resolve(response);
            },
            error: function (xhr) {
                reject(xhr);
            },
            complete: function () {
                delete fifuQuickEditItemInFlight[key];
            }
        });
    });

    return fifuQuickEditItemInFlight[key];
}

function fifu_invalidate_quick_edit_cache(postId, parentId) {
    delete fifuQuickEditItemCache[String(postId)];

    const normalizedParentId = parseInt(parentId, 10) || 0;

    if (normalizedParentId > 0) {
        delete fifuVariableProductCache[String(normalizedParentId)];
    }
}

function fifu_render_variable_product_selector(data) {
    const variations = Array.isArray(data && data.variations) ? data.variations : [];
    const parentDisplay = data && data.parent_display ? data.parent_display : {};
    const parentId = fifu_escape_html(data && data.parent_id ? data.parent_id : '');
    const title = fifu_escape_html(data && data.title ? data.title : '');
    const parentHeight = fifu_escape_html(parentDisplay.height || parentDisplay['height'] || 40);
    const parentWidth = fifu_escape_html(parentDisplay.width || parentDisplay['width'] || 40);
    const parentBorder = fifu_escape_html(parentDisplay.border || parentDisplay['border'] || '');
    const parentImageUrl = fifu_escape_html(parentDisplay.image_url || parentDisplay['image-url'] || '');
    const parentVideoUrl = fifu_escape_html(parentDisplay.video_url || parentDisplay['video-url'] || '');
    const parentVideoSrc = fifu_escape_html(parentDisplay.video_src || parentDisplay['video-src'] || '');
    const columnLayout = '<colgroup><col style="width:64px"><col><col style="width:40px"></colgroup>';
    let html = '<div id="fifu-variable-selector-content" class="fifu-variable-selector-content" data-variable-product="1" style="background:white; padding:10px; border-radius:1em;">';

    html += '<div style="background-color:#32373c; text-align:center; width:100%; color:white; padding:6px; border-radius:5px;">' + fifu_escape_html(fifuColumnVars.labelVariable) + '</div>';
    html += '<table style="text-align:left; width:100%">' + columnLayout + '<tbody>';
    html += '<tr class="color"><th>ID</th><th>' + fifu_escape_html(fifuColumnVars.labelName) + '</th><th><center><span class="dashicons dashicons-camera" style="font-size:20px;"></span></center></th></tr>';
    html += '<tr class="color">';
    html += '<th style="font-weight:unset">' + parentId + '</th>';
    html += '<th style="font-weight:unset">' + title + '</th>';
    html += '<th style="font-weight:unset"><div class="fifu-quick" post-id="' + parentId + '" video-url="' + parentVideoUrl + '" video-src="' + parentVideoSrc + '" is-ctgr="' + fifu_escape_html(parentDisplay.is_ctgr || parentDisplay['is-ctgr'] || '') + '" image-url="' + parentImageUrl + '" is-variable="" data-fifu-lazy-item="1" data-parent-id="' + parentId + '" style="height: ' + parentHeight + 'px; width: ' + parentWidth + 'px; background:url(\'' + parentImageUrl + '\') no-repeat center center; background-size:cover; ' + parentBorder + ' cursor:pointer;"></div></th>';
    html += '</tr>';
    html += '</tbody></table><br>';
    html += '<div style="background-color:#32373c; text-align:center; width:100%; color:white; padding:6px; border-radius:5px;">' + fifu_escape_html(fifuColumnVars.labelVariation) + '</div>';
    html += '<table style="text-align:left; width:100%">' + columnLayout + '<tbody>';

    variations.forEach(function (variation) {
        const display = variation && variation.display ? variation.display : {};
        const attrs = variation && variation.attributes ? variation.attributes : {};
        const vid = fifu_escape_html(variation && variation.post_id ? variation.post_id : '');
        const vheight = fifu_escape_html(display.height || 40);
        const vwidth = fifu_escape_html(display.width || 40);
        const vborder = fifu_escape_html(display.border || '');
        const vimage = fifu_escape_html(display.image_url || '');
        const vvideo = fifu_escape_html(display.video_url || '');
        const vsrc = fifu_escape_html(display.video_src || '');
        const label = Object.values(attrs).filter(Boolean).join(' / ');

        html += '<tr class="color">';
        html += '<th style="font-weight:unset">' + vid + '</th>';
        html += '<th style="font-weight:unset">' + fifu_escape_html(label) + '</th>';
        html += '<th style="font-weight:unset"><div class="fifu-quick" post-id="' + vid + '" video-url="' + vvideo + '" video-src="' + vsrc + '" image-url="' + vimage + '" is-variable="" data-fifu-lazy-item="1" data-parent-id="' + parentId + '" style="height: ' + vheight + 'px; width: ' + vwidth + 'px; background:url(\'' + vimage + '\') no-repeat center center; background-size:cover; ' + vborder + ' cursor:pointer;"></div></th>';
        html += '</tr>';
    });

    html += '</tbody></table>';
    html += fifuColumnVars.isDebugEnabled ? '<button id="fifu-copy-debug-data-button" class="fifu-quick-button fifu-copy-debug-data-button" type="button" onclick="fifu_copy_quick_edit_debug_data(' + parentId + ', this, false)"><span class="dashicons dashicons-clipboard fifu-copy-debug-data-icon" aria-hidden="true"></span><span class="fifu-copy-debug-data-label">' + fifu_escape_html(fifuColumnVars.buttonCopyDebugData) + '</span></button>' : '';
    html += '</div>';

    return html;
}

function fifu_get_quick_slider_debug_runtime_data(postId) {
    const readInput = function (inputId) {
        const $input = jQuery('#' + inputId);
        const present = !!($input && $input.length);
        const value = present ? $input.val() : '';

        return {
            value: value === undefined || value === null ? '' : String(value),
            present: present
        };
    };

    let activeQuickEditContext = null;
    if (typeof fifuActiveQuickEditContext !== 'undefined' && fifuActiveQuickEditContext) {
        activeQuickEditContext = {
            postId: fifuActiveQuickEditContext.postId === undefined
                ? null
                : fifuActiveQuickEditContext.postId,
            parentId: fifuActiveQuickEditContext.parentId === undefined
                ? null
                : fifuActiveQuickEditContext.parentId
        };
    }

    const slots = [];
    const hidden = {};
    const $slots = jQuery('#gridDemoSlider > div[id^="fifu-slider-"]');
    $slots.each(function (domOrder) {
        const $slot = jQuery(this);
        const id = String($slot.attr('id') || '');
        const index = id.indexOf('fifu-slider-') === 0
            ? id.substring('fifu-slider-'.length)
            : '';
        const url = readInput('fifu_slider_input_url_' + index);
        const alt = readInput('fifu_slider_input_alt_' + index);
        const width = readInput('fifu_slider_input_width_' + index);
        const height = readInput('fifu_slider_input_height_' + index);
        const imageSrc = readInput('fifu_slider_input_image_src_' + index);

        hidden[index] = {
            url: url.value,
            alt: alt.value,
            width: width.value,
            height: height.value,
            imageSrc: imageSrc.value,
            present: {
                url: url.present,
                alt: alt.present,
                width: width.present,
                height: height.present,
                imageSrc: imageSrc.present
            }
        };

        slots.push({
            domOrder: domOrder,
            id: id,
            index: index,
            background: String($slot.css('background') || ''),
            removeButtonCount: $slot.find('.fifu-featured-media-remove').length
        });
    });

    let activePopup = null;
    const $popupInputs = jQuery('input[id^="input-fifu-slider-"]');
    if ($popupInputs.length) {
        const $input = $popupInputs.eq(0);
        const inputId = String($input.attr('id') || '');
        const divId = inputId.indexOf('input-') === 0
            ? inputId.substring('input-'.length)
            : inputId;

        activePopup = {
            inputId: inputId,
            divId: divId,
            index: divId.split('-')[2] || '',
            value: String($input.val() || '')
        };
    }

    return {
        postId: String(postId || ''),
        selectedMediaType: typeof fifu_get_quick_selected_media_type === 'function'
            ? fifu_get_quick_selected_media_type()
            : '',
        fifuQuickEditorOpen: typeof fifuQuickEditorOpen !== 'undefined'
            ? !!fifuQuickEditorOpen
            : null,
        currentLightbox: typeof currentLightbox !== 'undefined'
            ? currentLightbox
            : null,
        activeQuickEditContext: activeQuickEditContext,
        slider: {
            slots: slots,
            hidden: hidden,
            inputHiddenSliderListIds: String(jQuery('#inputHiddenSliderListIds').val() || ''),
            inputHiddenSliderLength: String(jQuery('#inputHiddenSliderLength').val() || ''),
            activePopup: activePopup,
            requestProjection: typeof fifu_get_quick_slider_request_data === 'function'
                ? fifu_get_quick_slider_request_data()
                : null,
            globals: {
                numberUrls: typeof numberUrls !== 'undefined' ? numberUrls : null,
                numberInputs: typeof numberInputs !== 'undefined' ? numberInputs : null,
                maxSlider: typeof maxSlider !== 'undefined' ? maxSlider : null,
                currentSlotCount: slots.length
            }
        }
    };
}

function fifu_copy_quick_edit_debug_data(postId, button, isCtgr) {
    if (!fifuColumnVars.isDebugEnabled) {
        return;
    }

    const isCategory = isCtgr === true || isCtgr === '1' || isCtgr === 'true' || isCtgr === 1;
    const $button = jQuery(button);
    const originalLabel = $button.find('.fifu-copy-debug-data-label').text();
    let restored = false;

    const restoreButton = function () {
        if (restored) {
            return;
        }
        restored = true;
        setTimeout(function () {
            fifu_set_copy_debug_button_state($button, originalLabel, '', false);
        }, 1500);
    };

    fifu_set_copy_debug_button_state($button, 'Copying...', '', true);

    jQuery.ajax({
        method: 'GET',
        url: fifuColumnVars.restUrl + 'fifu-premium/v2/quick_edit_debug_data_api/',
        data: {
            post_id: postId,
            is_ctgr: isCategory ? 1 : 0,
            taxonomy: fifuColumnVars.taxonomy || ''
        },
        beforeSend: function (xhr) {
            xhr.setRequestHeader('X-WP-Nonce', fifuColumnVars.nonce);
        },
        success: async function (data) {
            try {
                const debugPayload = data && typeof data === 'object' && !Array.isArray(data)
                    ? Object.assign({}, data)
                    : {server_debug_data: data};
                debugPayload.quick_editor_runtime = fifu_get_quick_slider_debug_runtime_data(postId);
                const json = JSON.stringify(debugPayload, null, 2);

                if (navigator.clipboard && navigator.clipboard.writeText) {
                    await navigator.clipboard.writeText(json);
                } else {
                    const $textarea = jQuery('<textarea readonly></textarea>').css({position: 'fixed', left: '-9999px', top: '0'}).val(json);
                    jQuery('body').append($textarea);
                    $textarea[0].select();
                    document.execCommand('copy');
                    $textarea.remove();
                }

                fifu_set_copy_debug_button_state($button, 'Copied!', 'fifu-copy-debug-data-button--copied', true);
                restoreButton();
            } catch (error) {
                fifu_set_copy_debug_button_state($button, 'Copy failed', 'fifu-copy-debug-data-button--failed', true);
                restoreButton();
            }
        },
        error: function () {
            fifu_set_copy_debug_button_state($button, 'Copy failed', 'fifu-copy-debug-data-button--failed', true);
            restoreButton();
        }
    });
}

function fifu_get_quick_slider_upload_payload() {
    if (fifuColumnVars.onCategoriesPage || !fifuColumnVars.onProductsPage) {
        return {
            featuredUrl: '',
            featuredAlt: '',
            galleryUrls: [],
            galleryAlts: [],
            hasSliderPayload: false
        };
    }

    if (typeof fifu_get_slider_upload_payload === 'function') {
        return fifu_get_slider_upload_payload();
    }

    let featuredUrl = '';
    let featuredAlt = '';
    let galleryUrls = [];
    let galleryAlts = [];
    let hasSliderPayload = false;
    let sliderIds = (jQuery('#inputHiddenSliderListIds').val() || '').split('|');

    sliderIds.forEach(function (index) {
        if (index === '') {
            return;
        }

        let url = fifu_get_quick_hidden_input_value(`fifu_slider_input_url_${index}`);
        if (!url) {
            return;
        }

        let alt = fifu_get_quick_hidden_input_value(`fifu_slider_input_alt_${index}`);
        if (!hasSliderPayload) {
            featuredUrl = url;
            featuredAlt = alt;
            hasSliderPayload = true;
            return;
        }

        galleryUrls.push(url);
        galleryAlts.push(alt);
    });

    return {
        featuredUrl: featuredUrl,
        featuredAlt: featuredAlt,
        galleryUrls: galleryUrls,
        galleryAlts: galleryAlts,
        hasSliderPayload: hasSliderPayload
    };
}

function fifu_get_quick_slider_preview_payload() {
    if (typeof fifu_get_slider_upload_payload === 'function') {
        return fifu_get_slider_upload_payload();
    }

    return fifu_get_quick_slider_upload_payload();
}

function fifu_is_quick_edit_category(is_ctgr) {
    return is_ctgr === true || is_ctgr === '1' || is_ctgr === 'true' || is_ctgr === 1;
}

function fifu_get_quick_edit_payload(post_id, is_ctgr) {
    const isCategory = fifu_is_quick_edit_category(is_ctgr);
    if (isCategory && typeof fifuQuickEditCtgrVars !== 'undefined' && fifuQuickEditCtgrVars.terms) {
        return fifuQuickEditCtgrVars.terms[post_id] || {};
    }

    if (typeof fifuQuickEditVars !== 'undefined' && fifuQuickEditVars.posts) {
        return fifuQuickEditVars.posts[post_id] || {};
    }

    return {};
}

function fifu_get_quick_mixed_gallery_payload(payload) {
    const source = payload || {};
    const imageUrls = Array.isArray(source.fifu_image_urls) ? source.fifu_image_urls : [];
    const imageAlts = Array.isArray(source.fifu_image_alts) ? source.fifu_image_alts : [];
    const imageIfms = Array.isArray(source.fifu_image_ifms) ? source.fifu_image_ifms : [];
    const videoUrls = Array.isArray(source.fifu_video_urls) ? source.fifu_video_urls : [];
    const videoThumbs = Array.isArray(source.fifu_thumb_urls) ? source.fifu_thumb_urls : [];
    const images = [];
    const videos = [];

    imageUrls.forEach(function (url, index) {
        const normalizedUrl = String(url || '').trim();
        if (!normalizedUrl) {
            return;
        }

        images.push({
            id: `image-${index}`,
            slot: index,
            type: 'image',
            url: normalizedUrl,
            alt: String(imageAlts[index] || '').trim(),
            ifm: String(imageIfms[index] || '').trim(),
            source: 'fifu',
        });
    });

    videoUrls.forEach(function (url, index) {
        const normalizedUrl = String(url || '').trim();
        if (!normalizedUrl) {
            return;
        }

        videos.push({
            id: `video-${index}`,
            slot: index,
            type: 'video',
            url: normalizedUrl,
            imageSrc: String(videoThumbs[index] || '').trim(),
            source: 'fifu',
        });
    });

    return {images, videos};
}

function fifu_get_quick_featured_media_types(isVariableProduct, isCategory, currentType, videoUrl, audioUrl) {
    const types = ['image'];
    const hasSlider = !isCategory
        && !isVariableProduct
        && (fifuColumnVars.isSliderEnabled || currentType === 'slider');
    const hasAudio = !isCategory && fifuColumnVars.isVideoEnabled;

    if (fifuColumnVars.isVideoEnabled) {
        types.push('video');
    }
    if (hasSlider) {
        types.push('slider');
    }
    if (hasAudio) {
        types.push('audio');
    }

    return types;
}

function fifu_resolve_quick_featured_media_type(initialType, availableTypes) {
    if (availableTypes.indexOf(initialType) !== -1) {
        return initialType;
    }

    return availableTypes[0] || 'image';
}

function fifu_get_quick_selected_media_type() {
    const selectedType = jQuery('#fifu-quick-featured-media-type').val();
    return selectedType || 'image';
}

function fifu_is_quick_image_previewed(imageUrl) {
    const normalizedUrl = String(imageUrl || '').trim();
    return !!normalizedUrl && String(fifuQuickFeaturedImagePreviewedUrl || '').trim() === normalizedUrl;
}

function fifu_set_quick_image_previewed_url(imageUrl) {
    fifuQuickFeaturedImagePreviewedUrl = String(imageUrl || '').trim();
}

function fifu_update_quick_image_alt_visibility(mediaType) {
    const $altState = jQuery('#fifu-quick-image-alt-state');
    if (!$altState.length) {
        return;
    }

    const imageValue = String(jQuery('#fifu-quick-input-url').val() || '').trim();
    const isVisible = mediaType === 'image'
        && fifu_is_quick_direct_image_url(imageValue)
        && fifu_is_quick_image_previewed(imageValue);

    if (isVisible) {
        $altState.show();
    } else {
        $altState.hide();
    }
}

function fifu_set_quick_image_preview_state(previewed) {
    const $previewButton = jQuery('#fifu-quick-image-preview-button');
    if ($previewButton.length) {
        if (previewed) {
            $previewButton.hide();
        } else {
            $previewButton.show();
        }
    }

    const $removeButton = jQuery('#fifu-quick-image-remove');
    if ($removeButton.length) {
        if (previewed) {
            $removeButton.show();
        } else {
            $removeButton.hide();
        }
    }

    fifu_update_quick_image_alt_visibility('image');
}

function fifu_focus_quick_featured_media_primary_input(mediaType) {
    let selectedMediaType = mediaType;
    if (typeof fifu_get_quick_selected_media_type === 'function') {
        selectedMediaType = fifu_get_quick_selected_media_type() || mediaType;
    }

    if (selectedMediaType === 'slider') {
        const $saveButton = jQuery('#fifu-save-button');
        if (!$saveButton.length) {
            return;
        }
        if (typeof $saveButton.is === 'function' && !$saveButton.is(':visible')) {
            return;
        }
        $saveButton.focus();
        return;
    }

    const inputSelectors = {
        image: '#fifu-quick-input-url',
        video: '#fifu-quick-video-input-url',
        audio: '#fifu-quick-audio-input-url'
    };
    const inputSelector = inputSelectors[selectedMediaType];
    if (!inputSelector) {
        return;
    }

    const $input = jQuery(inputSelector);
    if (!$input.length) {
        return;
    }
    if (typeof $input.is === 'function' && !$input.is(':visible')) {
        return;
    }

    if (typeof $input.focus === 'function') {
        $input.focus();
    }

    const input = $input[0];
    if (input && input.value && typeof input.select === 'function') {
        input.select();
    }
}

function fifu_normalize_quick_featured_media_url(mediaType, mediaUrl) {
    return String(mediaUrl || '').trim();
}

function fifu_is_quick_featured_media_previewed(mediaType, mediaUrl) {
    const normalizedUrl = fifu_normalize_quick_featured_media_url(mediaType, mediaUrl);
    if (!normalizedUrl || typeof fifuQuickFeaturedMediaPreviewedUrls === 'undefined') {
        return false;
    }

    const previewedUrl = fifu_normalize_quick_featured_media_url(
        mediaType,
        fifuQuickFeaturedMediaPreviewedUrls[mediaType]
    );

    return previewedUrl === normalizedUrl;
}

function fifu_is_quick_audio_previewed(audioUrl, thumbnailUrl) {
    const normalizedAudioUrl = fifu_normalize_quick_featured_media_url('audio', audioUrl);
    const normalizedThumbnailUrl = fifu_normalize_quick_featured_media_url('audio', thumbnailUrl);
    if (
        !normalizedAudioUrl
        || !normalizedThumbnailUrl
        || !fifu_is_quick_featured_media_previewed('audio', normalizedAudioUrl)
        || typeof fifuQuickFeaturedMediaPreviewedThumbnailUrls === 'undefined'
    ) {
        return false;
    }

    const previewedThumbnailUrl = fifu_normalize_quick_featured_media_url(
        'audio',
        fifuQuickFeaturedMediaPreviewedThumbnailUrls.audio
    );

    return previewedThumbnailUrl === normalizedThumbnailUrl;
}

function fifu_set_quick_audio_previewed_state(audioUrl, thumbnailUrl) {
    fifu_set_quick_featured_media_previewed_url('audio', audioUrl);
    if (typeof fifuQuickFeaturedMediaPreviewedThumbnailUrls === 'undefined') {
        fifuQuickFeaturedMediaPreviewedThumbnailUrls = {};
    }

    fifuQuickFeaturedMediaPreviewedThumbnailUrls.audio = fifu_normalize_quick_featured_media_url(
        'audio',
        thumbnailUrl
    );
}

function fifu_set_quick_featured_media_previewed_url(mediaType, mediaUrl) {
    if (typeof fifuQuickFeaturedMediaPreviewedUrls === 'undefined') {
        fifuQuickFeaturedMediaPreviewedUrls = {};
    }

    const normalizedMediaUrl = fifu_normalize_quick_featured_media_url(mediaType, mediaUrl);
    fifuQuickFeaturedMediaPreviewedUrls[mediaType] = normalizedMediaUrl;
    if (mediaType === 'audio' && !normalizedMediaUrl) {
        if (typeof fifuQuickFeaturedMediaPreviewedThumbnailUrls === 'undefined') {
            fifuQuickFeaturedMediaPreviewedThumbnailUrls = {};
        }
        fifuQuickFeaturedMediaPreviewedThumbnailUrls.audio = '';
    }
}

function fifu_invalidate_quick_featured_media_preview_if_stale(mediaType, mediaUrl) {
    const normalizedUrl = fifu_normalize_quick_featured_media_url(mediaType, mediaUrl);
    const previewedUrl = typeof fifuQuickFeaturedMediaPreviewedUrls === 'undefined'
        ? ''
        : fifu_normalize_quick_featured_media_url(mediaType, fifuQuickFeaturedMediaPreviewedUrls[mediaType]);

    if (normalizedUrl === previewedUrl) {
        return false;
    }

    fifu_set_quick_featured_media_previewed_url(mediaType, '');
    return true;
}

function fifu_update_quick_audio_ui_state() {
    const audioUrl = String(jQuery('#fifu-quick-audio-input-url').val() || '').trim();
    const thumbnailUrl = String(jQuery('#fifu-quick-input-url').val() || '').trim();
    const previewIsOpen = fifu_is_quick_audio_previewed(audioUrl, thumbnailUrl);
    const $state = jQuery('#fifu-quick-featured-image-state');
    const $previewButton = jQuery('#fifu-quick-audio-preview-button');

    if ($state.length) {
        if (audioUrl) {
            $state.show();
        } else {
            $state.hide();
        }
    }

    if ($previewButton.length) {
        if (audioUrl && !previewIsOpen) {
            $previewButton.show();
        } else {
            $previewButton.hide();
        }
    }
}

function fifu_update_quick_featured_image_input_mode(mediaType) {
    const isVideo = mediaType === 'video';
    const isAudio = mediaType === 'audio';
    const isThumbnail = isVideo;
    const $image = jQuery('#fifu-quick-input-url');
    const $state = jQuery('#fifu-quick-featured-image-state');
    const $help = jQuery('#fifu-quick-image-help');
    const $videoIcon = jQuery('#fifu-quick-video-thumbnail-icon');
    const $imagePreview = jQuery('#fifu-quick-image-preview-button');
    const imageValue = String($image.val() || '').trim();
    const mediaUrl = isVideo
        ? String(jQuery('#fifu-quick-video-input-url').val() || '').trim()
        : (isAudio ? String(jQuery('#fifu-quick-audio-input-url').val() || '').trim() : '');
    const canUseCustomThumbnail = !isVideo
        || (
            typeof isCustomVideoUrl === 'function'
            && isCustomVideoUrl(mediaUrl)
        );

    if (mediaType === 'slider') {
        $state.hide();
        fifu_update_quick_image_alt_visibility(mediaType);
        return;
    }

    if ($image.length) {
        $image.attr(
            'placeholder',
            isVideo
                ? fifuColumnVars.thumbnailOptional
                : (isAudio ? fifuColumnVars.thumbnailAudio : fifuColumnVars.urlImage)
        );
    }

    if (isAudio) {
        $help.hide();
        $imagePreview.hide();
        if (mediaUrl) {
            $videoIcon.show();
        } else {
            $videoIcon.hide();
        }
        fifu_update_quick_audio_ui_state();
        fifu_update_quick_image_alt_visibility(mediaType);
        return;
    }

    if (isThumbnail) {
        $help.hide();
        $imagePreview.hide();
        if (isVideo && !canUseCustomThumbnail) {
            $state.hide();
            $videoIcon.hide();
            fifu_update_quick_image_alt_visibility(mediaType);
            return;
        }

        if (!fifu_is_quick_featured_media_previewed(mediaType, mediaUrl)) {
            $state.hide();
            return;
        }

        $state.show();
        $videoIcon.show();
    } else {
        $state.show();
        $help.show();
        $videoIcon.hide();
        $imagePreview.show();
    }

    fifu_update_quick_image_alt_visibility(mediaType);
}

function fifu_is_quick_direct_image_url(value) {
    const normalizedValue = String(value || '').trim();
    return normalizedValue.startsWith('http') || normalizedValue.startsWith('//');
}

function fifu_get_quick_image_save_value() {
    const $image = jQuery('#fifu-quick-input-url');
    const value = String($image.val() || '').trim();
    if (value === '') {
        return '';
    }

    if (fifu_is_quick_direct_image_url(value)) {
        return value;
    }

    const initialValue = String($image.attr('data-fifu-image-initial-value') || '').trim();
    return fifu_is_quick_direct_image_url(initialValue) ? initialValue : '';
}

function fifu_get_quick_media_request_data() {
    const requestData = {};

    if (fifuQuickEditClearRequested) {
        requestData.image_url = '';
        requestData.video_url = '';
        return requestData;
    }

    const mediaType = fifu_get_quick_selected_media_type();
    const imageValue = String(jQuery('#fifu-quick-input-url').val() || '').trim();
    const videoUrl = String(jQuery('#fifu-quick-video-input-url').val() || '').trim();

    let imageInitialValue = String(
        jQuery('#fifu-quick-input-url')
            .attr('data-fifu-image-initial-value')
        || ''
    ).trim();

    if (
        mediaType === 'video'
        && typeof isCustomVideoUrl === 'function'
        && isCustomVideoUrl(videoUrl)
    ) {
        imageInitialValue = String(
            jQuery('#fifu-quick-input-url')
                .attr(
                    'data-fifu-video-thumbnail-initial-value'
                )
            || ''
        ).trim();
    } else if (mediaType === 'audio') {
        imageInitialValue = String(
            jQuery('#fifu-quick-input-url')
                .attr(
                    'data-fifu-audio-artwork-initial-value'
                )
            || ''
        ).trim();
    }

    const imageChanged =
        imageValue !== imageInitialValue;

    if (mediaType === 'image') {
        requestData.image_url = fifu_get_quick_image_save_value();
        const $imageAlt = jQuery('#fifu-quick-image-alt');
        if ($imageAlt.length) {
            requestData.image_alt = String($imageAlt.val() || '').trim();
        }
    } else if (mediaType === 'video') {
        requestData.video_url = videoUrl;

        if (imageChanged && fifu_is_quick_direct_image_url(imageValue)) {
            requestData.image_url = imageValue;
        }

        if (videoUrl) {
            const videoThumbUrl = typeof isCustomVideoUrl === 'function' && isCustomVideoUrl(videoUrl)
                ? imageValue
                : (String(jQuery('#fifu-quick-video-input-image-src').val() || '').trim()
                    || (imageChanged ? imageValue : ''));
            if (videoThumbUrl) {
                requestData.video_thumb_url = videoThumbUrl;
            }
        }
    } else if (mediaType === 'audio' && imageChanged && fifu_is_quick_direct_image_url(imageValue)) {
        requestData.image_url = imageValue;
    }

    if (
        typeof fifuQuickEditClearedMediaTypes !== 'undefined'
        && fifuQuickEditClearedMediaTypes.image
        && !(
            fifu_is_quick_direct_image_url(imageValue)
            && (
                mediaType === 'image'
                || mediaType === 'audio'
                || (
                    mediaType === 'video'
                    && typeof isCustomVideoUrl === 'function'
                    && isCustomVideoUrl(videoUrl)
                )
            )
        )
    ) {
        requestData.image_url = '';
    }
    if (
        typeof fifuQuickEditClearedMediaTypes !== 'undefined'
        && fifuQuickEditClearedMediaTypes.video
        && (mediaType !== 'video' || !videoUrl)
    ) {
        requestData.video_url = '';
    }

    return requestData;
}

function fifu_get_quick_audio_request_value() {
    const $audio = jQuery('#fifu-quick-audio-input-url');
    if (!$audio.length) {
        return {include: false, value: ''};
    }

    const stateAvailable = $audio.attr('data-fifu-audio-state-available') === '1';
    const initialValue = String($audio.attr('data-fifu-audio-initial-value') || '').trim();
    const value = String($audio.val() || '').trim();
    const dirty = $audio.data('fifu-audio-dirty') === true;

    if (
        typeof fifuQuickEditClearedMediaTypes !== 'undefined'
        && fifuQuickEditClearedMediaTypes.audio
        && (
            typeof fifu_get_quick_selected_media_type !== 'function'
            || fifu_get_quick_selected_media_type() !== 'audio'
            || !value
        )
    ) {
        return {include: true, value: ''};
    }

    return {
        include: stateAvailable || dirty || value !== initialValue,
        value: value
    };
}

function fifu_add_quick_audio_request_param(data) {
    const audioRequest = fifu_get_quick_audio_request_value();
    if (audioRequest.include) {
        data.audio_url = audioRequest.value;
    }

    return data;
}

function fifu_update_quick_edit_audio_cache(post_id, audioRequest) {
    if (
        fifuColumnVars.onCategoriesPage
        || !audioRequest
        || !audioRequest.include
        || typeof fifuQuickEditVars === 'undefined'
        || !fifuQuickEditVars.posts
        || !fifuQuickEditVars.posts[post_id]
    ) {
        return;
    }

    fifuQuickEditVars.posts[post_id]['fifu_audio_url'] = audioRequest.value;
}

function fifu_get_quick_slider_media_parts(value) {
    return fifu_parse_slider_media(value);
}

function fifu_render_quick_image_preview(imageUrl, postId, includeRemoveControl) {
    const normalizedImageUrl = String(imageUrl || '').trim();
    if (!normalizedImageUrl) {
        return '';
    }

    let preview = '<div id="fifu-quick-image-preview-wrapper" class="fifu-quick-image-preview-wrapper">';
    preview += '<div class="fifu-quick-image-preview-media">';
    preview += `<img loading="lazy" id="fifu-quick-preview" src="${fifu_escape_html(fifu_cdn_adjust(normalizedImageUrl))}" post-id="${fifu_escape_html(postId)}" onerror="this.onerror=null;fifu_update_quick_upload_button_visibility();this.src='${FIFU_IMAGE_NOT_FOUND_URL}';">`;

    if (includeRemoveControl) {
        const imageRemoveLabel = typeof fifuColumnVars !== 'undefined'
            ? String(fifuColumnVars.buttonRemoveImage || '')
            : '';
        const escapedImageRemoveLabel = typeof fifu_escape_html === 'function'
            ? fifu_escape_html(imageRemoveLabel)
            : imageRemoveLabel;
        preview += `<button id="fifu-quick-image-remove" class="fifu-featured-media-remove" type="button" aria-label="${escapedImageRemoveLabel}" title="${escapedImageRemoveLabel}"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></button>`;
    }

    return `${preview}</div></div>`;
}

function fifu_get_quick_video_remove_control() {
    const videoRemoveLabel = typeof fifuColumnVars !== 'undefined'
        ? String(
            fifuColumnVars.buttonRemoveVideo
            || fifuColumnVars.buttonRemoveImage
            || fifuColumnVars.buttonRemoveAudio
            || 'Remove video'
        )
        : 'Remove video';
    const escapedVideoRemoveLabel = typeof fifu_escape_html === 'function'
        ? fifu_escape_html(videoRemoveLabel)
        : videoRemoveLabel;

    return `<button id="fifu-quick-video-remove" class="fifu-featured-media-remove" type="button" aria-label="${escapedVideoRemoveLabel}" title="${escapedVideoRemoveLabel}"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></button>`;
}

function fifu_render_quick_video_preview(videoUrl, imageUrl, postId, includeHiddenPoster, includeRemoveControl) {
    const normalizedVideoUrl = String(videoUrl || '').trim();
    const normalizedImageUrl = String(imageUrl || '').trim();
    if (!normalizedVideoUrl) {
        return {markup: '', shouldSetupHls: false, hlsUrl: '', isValid: false, previewKey: ''};
    }

    if (typeof fifu_is_video === 'function' && !fifu_is_video(normalizedVideoUrl)) {
        let invalidMarkup = '<div class="fifu-quick-video-preview-wrapper">';
        if (includeRemoveControl) {
            invalidMarkup += fifu_get_quick_video_remove_control();
        }
        invalidMarkup += `<img id="fifu-quick-preview" class="fifu-quick-video-placeholder" src="${FIFU_VIDEO_NOT_FOUND_URL}" post-id="${fifu_escape_html(postId)}"></div>`;
        return {
            markup: invalidMarkup,
            shouldSetupHls: false,
            hlsUrl: '',
            isValid: false,
            previewKey: `video:invalid:${normalizedVideoUrl}`
        };
    }

    if (
        (typeof isLocalVideoUrl === 'function' && isLocalVideoUrl(normalizedVideoUrl))
        || (typeof isCustomVideoUrl === 'function' && isCustomVideoUrl(normalizedVideoUrl))
    ) {
        let markup = '<div class="fifu-quick-video-preview-wrapper">';
        if (includeRemoveControl) {
            markup += fifu_get_quick_video_remove_control();
        }
        markup += `<video id="fifu-quick-preview" class="fifu-quick-video-native" post-id="${fifu_escape_html(postId)}" controls><source src="${fifu_escape_html(normalizedVideoUrl)}" type=""></video></div>`;
        if (includeHiddenPoster && normalizedImageUrl) {
            markup += `<img loading="lazy" id="fifu-quick-preview-hidden-img" src="${fifu_escape_html(normalizedImageUrl)}" post-id="${fifu_escape_html(postId)}" style="max-height:600px; width:0%;">`;
        }

        return {
            markup: markup,
            shouldSetupHls: normalizedVideoUrl.includes('.m3u8'),
            hlsUrl: normalizedVideoUrl.includes('.m3u8') ? normalizedVideoUrl : '',
            isValid: true,
            previewKey: `video:native:${normalizedVideoUrl}`
        };
    }

    let videoSrc = '';
    if (typeof srcVideo === 'function') {
        videoSrc = srcVideo(normalizedVideoUrl) || '';
    }
    if (!videoSrc) {
        videoSrc = jQuery('.fifu-quick[post-id="' + postId + '"]').attr('video-src') || '#';
    }

    let providerMarkup = '<div class="fifu-quick-video-preview-wrapper">';
    if (includeRemoveControl) {
        providerMarkup += fifu_get_quick_video_remove_control();
    }
    providerMarkup += videoSrc === '#'
        ? `<img id="fifu-quick-preview" class="fifu-quick-video-placeholder" src="${FIFU_VIDEO_NOT_FOUND_URL}" post-id="${fifu_escape_html(postId)}">`
        : `<div class="fifu-quick-video-embed"><iframe id="fifu-quick-preview" src="${fifu_escape_html(videoSrc)}" post-id="${fifu_escape_html(postId)}" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen frameborder="0"></iframe></div>`;
    providerMarkup += '</div>';

    return {
        markup: providerMarkup,
        shouldSetupHls: false,
        hlsUrl: '',
        isValid: videoSrc !== '#',
        previewKey: `video:provider:${normalizedVideoUrl}`
    };
}

function fifu_update_quick_featured_media_preview(mediaType, forcePreview) {
    const $left = jQuery('#fifu-left-column');
    if (!$left.length) {
        return false;
    }

    if (typeof fifuQuickFeaturedSliderPreviewKey === 'undefined') {
        fifuQuickFeaturedSliderPreviewKey = '';
    }
    if (mediaType !== 'slider') {
        fifuQuickFeaturedSliderPreviewKey = '';
    }

    const postId = jQuery('#fifu-save-button').attr('post-id') || '';
    const imageValue = String(jQuery('#fifu-quick-input-url').val() || '').trim();
    const imageUrl = fifu_is_quick_direct_image_url(imageValue) ? imageValue : '';
    const videoUrl = String(jQuery('#fifu-quick-video-input-url').val() || '').trim();
    const audioUrl = String(jQuery('#fifu-quick-audio-input-url').val() || '').trim();
    let preview = '';
    let shouldSetupHls = false;
    let hlsUrl = '';
    let previewIsValid = false;
    let previewKey = '';

    if (!forcePreview && (mediaType === 'video' || mediaType === 'audio')) {
        const mediaUrl = mediaType === 'video' ? videoUrl : audioUrl;
        const previewIsCurrent = mediaType === 'audio'
            ? fifu_is_quick_audio_previewed(audioUrl, imageValue)
            : fifu_is_quick_featured_media_previewed(mediaType, mediaUrl);
        if (!previewIsCurrent) {
            $left.empty().css('display', 'none');
            if (typeof fifu_update_quick_preview_layout === 'function') {
                fifu_update_quick_preview_layout(false);
            }
            return false;
        }
    }

    if (mediaType === 'video' && videoUrl) {
        const renderedVideo = fifu_render_quick_video_preview(videoUrl, imageUrl, postId, true, true);
        preview = renderedVideo.markup;
        shouldSetupHls = renderedVideo.shouldSetupHls;
        hlsUrl = renderedVideo.hlsUrl;
        previewIsValid = renderedVideo.isValid;
    } else if (mediaType === 'slider') {
        const sliderPayload = fifu_get_quick_slider_preview_payload();
        if (sliderPayload.featuredUrl) {
            const sliderMedia = fifu_get_quick_slider_media_parts(sliderPayload.featuredUrl);
            if (typeof fifu_is_video === 'function' && fifu_is_video(sliderMedia.mediaUrl)) {
                const renderedVideo = fifu_render_quick_video_preview(
                    sliderMedia.mediaUrl,
                    sliderMedia.thumbnailUrl,
                    postId,
                    false,
                    false
                );
                preview = renderedVideo.markup;
                shouldSetupHls = renderedVideo.shouldSetupHls;
                hlsUrl = renderedVideo.hlsUrl;
                previewKey = renderedVideo.previewKey ? `slider:${renderedVideo.previewKey}` : '';
            } else {
                preview = fifu_render_quick_image_preview(sliderMedia.mediaUrl, postId, false);
                previewKey = sliderMedia.mediaUrl ? `slider:image:${sliderMedia.mediaUrl}` : '';
            }
        }
    } else if (mediaType === 'audio' && audioUrl && imageUrl) {
        const audioRemoveLabel = typeof fifuColumnVars !== 'undefined'
            ? String(fifuColumnVars.buttonRemoveAudio || '')
            : '';
        const escapedAudioRemoveLabel = typeof fifu_escape_html === 'function'
            ? fifu_escape_html(audioRemoveLabel)
            : audioRemoveLabel;
        preview = '<div id="fifu-quick-audio-preview-wrapper" class="fifu-quick-audio-preview-wrapper">';
        preview += `<button id="fifu-quick-audio-remove" class="fifu-featured-media-remove" type="button" aria-label="${escapedAudioRemoveLabel}" title="${escapedAudioRemoveLabel}"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></button>`;
        if (imageUrl) {
            preview += `<img loading="lazy" id="fifu-quick-preview" class="fifu-quick-audio-artwork" src="${fifu_escape_html(fifu_cdn_adjust(imageUrl))}" post-id="${fifu_escape_html(postId)}" onerror="this.onerror=null;fifu_update_quick_upload_button_visibility();this.src='${FIFU_IMAGE_NOT_FOUND_URL}';">`;
        }
        preview += '<div class="fifu-quick-audio-player-wrapper">';
        preview += `<audio id="fifu-quick-preview-audio" controls preload="metadata" src="${fifu_escape_html(audioUrl)}" style="width:100%;"></audio>`;
        preview += '</div></div>';
        previewIsValid = true;
    } else if (mediaType === 'image' && imageUrl && fifu_is_quick_image_previewed(imageValue)) {
        preview = fifu_render_quick_image_preview(imageUrl, postId, true);
    }

    if (
        mediaType === 'slider'
        && preview
        && previewKey
        && fifuQuickFeaturedSliderPreviewKey === previewKey
        && typeof $left.find === 'function'
        && $left.find('#fifu-quick-preview').length
    ) {
        return true;
    }

    $left.empty();
    if (preview) {
        $left.append(preview).css('display', 'table-cell');
        if (typeof fifu_update_quick_preview_layout === 'function') {
            fifu_update_quick_preview_layout(true, mediaType);
        }
        if (shouldSetupHls && typeof setupHlsPlayer === 'function') {
            setupHlsPlayer(hlsUrl || videoUrl, 'fifu-quick-preview');
        }
    } else {
        $left.css('display', 'none');
        if (typeof fifu_update_quick_preview_layout === 'function') {
            fifu_update_quick_preview_layout(false);
        }
    }

    if (mediaType === 'slider') {
        fifuQuickFeaturedSliderPreviewKey = preview ? previewKey : '';
    }

    if (mediaType === 'image') {
        fifu_set_quick_image_preview_state(!!(imageUrl && fifu_is_quick_image_previewed(imageValue)));
    }
    if (mediaType === 'video' && typeof fifu_set_quick_video_preview_state === 'function') {
        fifu_set_quick_video_preview_state(
            !!(videoUrl && fifu_is_quick_featured_media_previewed('video', videoUrl))
        );
    }

    return mediaType === 'video' || mediaType === 'audio' ? previewIsValid : !!preview;
}

function fifu_get_quick_editor_fancybox_instance() {
    if (
        typeof jQuery === 'undefined'
        || !jQuery.fancybox
        || typeof jQuery.fancybox.getInstance !== 'function'
    ) {
        return null;
    }

    const instance = jQuery.fancybox.getInstance();
    if (!instance || !instance.current || !instance.current.$content) {
        return null;
    }

    const $content = instance.current.$content;
    if (typeof $content.find !== 'function' || !$content.find('#fifu-save-button').length) {
        return null;
    }

    return instance;
}

function fifu_is_quick_editor_open() {
    return fifuQuickEditorOpen || !!fifu_get_quick_editor_fancybox_instance();
}

function fifu_update_quick_preview_layout(isVisible, mediaType) {
    const $left = jQuery('#fifu-left-column');
    if (!$left.length) {
        return;
    }

    const $layout = $left.closest('.fifu-quick-editor-layout');
    if ($layout.length) {
        $layout.toggleClass('fifu-quick-editor-layout--preview', !!isVisible);
        $layout.toggleClass(
            'fifu-quick-editor-layout--image-preview',
            !!isVisible && mediaType === 'image'
        );
        $layout.toggleClass(
            'fifu-quick-editor-layout--video-preview',
            !!isVisible && mediaType === 'video'
        );
        $layout.toggleClass(
            'fifu-quick-editor-layout--slider-preview',
            !!isVisible && mediaType === 'slider'
        );
        $layout.toggleClass(
            'fifu-quick-editor-layout--audio-preview',
            !!isVisible && mediaType === 'audio'
        );
    }

    const bindPreviewResize = function (selector, eventName) {
        const $media = $left.find(selector);
        if (!$media.length) {
            return false;
        }

        $media.off(eventName).on(eventName, function () {
            const $currentPreview = jQuery('#fifu-left-column').find('#fifu-quick-preview');
            if (!$currentPreview.length || $currentPreview[0] !== this) {
                return;
            }

            const currentInstance = fifu_get_quick_editor_fancybox_instance();
            if (currentInstance && typeof currentInstance.update === 'function') {
                currentInstance.update();
            }
        });
        return true;
    };

    if (isVisible && mediaType === 'image') {
        bindPreviewResize('img#fifu-quick-preview', 'load.fifuQuickImageLayout');
    } else if (isVisible && mediaType === 'video') {
        bindPreviewResize('video#fifu-quick-preview', 'loadedmetadata.fifuQuickVideoLayout');
    } else if (isVisible && mediaType === 'slider') {
        if (!bindPreviewResize('img#fifu-quick-preview', 'load.fifuQuickSliderLayout')) {
            bindPreviewResize('video#fifu-quick-preview', 'loadedmetadata.fifuQuickSliderLayout');
        }
    } else if (isVisible && mediaType === 'audio') {
        bindPreviewResize('img#fifu-quick-preview', 'load.fifuQuickAudioLayout');
    }

    const instance = fifu_get_quick_editor_fancybox_instance();
    if (instance && typeof instance.update === 'function') {
        instance.update();
    }
}

function fifu_set_quick_video_preview_state(previewed) {
    const $previewButton = jQuery('#fifu-quick-video-preview-button');
    if ($previewButton.length) {
        if (previewed) {
            $previewButton.hide();
        } else {
            $previewButton.show();
        }
    }
}

function fifu_get_quick_shared_image_draft(mediaType, videoUrl) {
    const $image = jQuery('#fifu-quick-input-url');
    if (!$image.length) {
        return '';
    }

    if (
        mediaType === 'video'
        && typeof isCustomVideoUrl === 'function'
        && isCustomVideoUrl(String(videoUrl || '').trim())
    ) {
        return String(
            $image.data('fifu-video-thumbnail-draft') || ''
        ).trim();
    }

    if (mediaType === 'audio') {
        return String(
            $image.data('fifu-audio-artwork-draft') || ''
        ).trim();
    }

    return String(
        $image.data('fifu-image-draft') || ''
    ).trim();
}

function fifu_initialize_quick_shared_image_drafts(
    mediaType,
    imageValue,
    videoUrl
) {
    const $image = jQuery('#fifu-quick-input-url');
    if (!$image.length) {
        return;
    }

    const normalizedImageValue =
        String(imageValue || '').trim();

    const normalizedVideoUrl =
        String(videoUrl || '').trim();

    const isCustomVideo =
        mediaType === 'video'
        && typeof isCustomVideoUrl === 'function'
        && isCustomVideoUrl(normalizedVideoUrl);

    $image.data(
        'fifu-image-draft',
        isCustomVideo ? '' : normalizedImageValue
    );

    $image.data(
        'fifu-video-thumbnail-draft',
        isCustomVideo ? normalizedImageValue : ''
    );

    // Preserve current Audio initialization semantics while keeping
    // future Audio edits independent from Image and Video Thumbnail.
    $image.data(
        'fifu-audio-artwork-draft',
        normalizedImageValue
    );

    $image.data(
        'fifu-shared-image-mode',
        mediaType || 'image'
    );

    $image.data(
        'fifu-shared-image-drafts-ready',
        true
    );

    $image.attr(
        'data-fifu-image-initial-value',
        isCustomVideo ? '' : normalizedImageValue
    );

    $image.attr(
        'data-fifu-video-thumbnail-initial-value',
        isCustomVideo ? normalizedImageValue : ''
    );

    $image.attr(
        'data-fifu-audio-artwork-initial-value',
        normalizedImageValue
    );

    $image.val(
        fifu_get_quick_shared_image_draft(
            mediaType,
            normalizedVideoUrl
        )
    );
}

function fifu_sync_quick_shared_image_drafts(mediaType) {
    const $image = jQuery('#fifu-quick-input-url');
    if (!$image.length) {
        return;
    }

    if (
        $image.data('fifu-shared-image-drafts-ready')
        !== true
    ) {
        $image.data(
            'fifu-shared-image-mode',
            mediaType || 'image'
        );
        return;
    }

    const previousType = String(
        $image.data('fifu-shared-image-mode')
        || 'image'
    );

    const currentValue =
        String($image.val() || '').trim();

    const videoUrl =
        String(
            jQuery('#fifu-quick-video-input-url').val()
            || ''
        ).trim();

    if (previousType === 'image') {
        $image.data(
            'fifu-image-draft',
            currentValue
        );
    } else if (previousType === 'audio') {
        $image.data(
            'fifu-audio-artwork-draft',
            currentValue
        );
    } else if (previousType === 'video') {
        if (
            typeof isCustomVideoUrl === 'function'
            && isCustomVideoUrl(videoUrl)
        ) {
            $image.data(
                'fifu-video-thumbnail-draft',
                currentValue
            );
        } else {
            // Provider Video keeps the real Featured Image internally.
            $image.data(
                'fifu-image-draft',
                currentValue
            );
        }
    }

    if (mediaType !== 'slider') {
        $image.val(
            fifu_get_quick_shared_image_draft(
                mediaType,
                videoUrl
            )
        );
    }

    $image.data(
        'fifu-shared-image-mode',
        mediaType || 'image'
    );
}

function fifu_reset_quick_shared_image_drafts() {
    const $image = jQuery('#fifu-quick-input-url');
    if (!$image.length) {
        return;
    }

    $image.data('fifu-image-draft', '');
    $image.data('fifu-video-thumbnail-draft', '');
    $image.data('fifu-audio-artwork-draft', '');
    $image.data(
        'fifu-shared-image-mode',
        fifu_get_quick_selected_media_type()
    );
    $image.data(
        'fifu-shared-image-drafts-ready',
        true
    );

    $image.attr(
        'data-fifu-image-initial-value',
        ''
    );
    $image.attr(
        'data-fifu-video-thumbnail-initial-value',
        ''
    );
    $image.attr(
        'data-fifu-audio-artwork-initial-value',
        ''
    );
}

function fifu_clear_quick_competing_media_state(mediaType) {
    const selectedType = mediaType || 'image';
    const $image = jQuery('#fifu-quick-input-url');
    const $video = jQuery('#fifu-quick-video-input-url');
    const $audio = jQuery('#fifu-quick-audio-input-url');
    const videoUrl = String($video.val() || '').trim();
    const audioUrl = String($audio.val() || '').trim();
    const previousType = $image.length
        ? String($image.data('fifu-shared-image-mode') || '')
        : '';
    const wasCleared = fifuQuickEditClearedMediaTypes[selectedType] === true;
    let sharedImageValue = '';

    if (!wasCleared && selectedType === 'image' && previousType === 'image') {
        sharedImageValue = fifu_get_quick_shared_image_draft('image', videoUrl);
    } else if (
        !wasCleared
        && selectedType === 'video'
        && videoUrl
        && typeof isCustomVideoUrl === 'function'
        && isCustomVideoUrl(videoUrl)
    ) {
        sharedImageValue = fifu_get_quick_shared_image_draft('video', videoUrl);
    } else if (!wasCleared && selectedType === 'audio' && audioUrl) {
        sharedImageValue = fifu_get_quick_shared_image_draft('audio', videoUrl);
    }

    Object.keys(fifuQuickEditClearedMediaTypes).forEach(function (type) {
        if (type !== selectedType) {
            fifuQuickEditClearedMediaTypes[type] = true;
        }
    });

    if ($image.length) {
        $image.data('fifu-image-draft', selectedType === 'image' ? sharedImageValue : '');
        $image.data('fifu-video-thumbnail-draft', selectedType === 'video' ? sharedImageValue : '');
        $image.data('fifu-audio-artwork-draft', selectedType === 'audio' ? sharedImageValue : '');
    }

    if (selectedType !== 'image') {
        jQuery('#fifu-quick-image-alt').val('');
        fifu_set_quick_image_previewed_url('');
    }
    if (selectedType !== 'video') {
        $video.val('');
        $video.attr('data-fifu-video-initial-value', '');
        jQuery('#fifu-quick-video-input-image-src').val('');
        jQuery('#fifu-quick-video-input-image-width').val('');
        jQuery('#fifu-quick-video-input-image-height').val('');
        fifu_set_quick_featured_media_previewed_url('video', '');
        if (typeof fifu_set_quick_video_preview_state === 'function') {
            fifu_set_quick_video_preview_state(false);
        }
    }
    if (selectedType !== 'audio') {
        $audio.val('');
        $audio.attr('data-fifu-audio-initial-value', '');
        $audio.data('fifu-audio-dirty', true);
        fifu_set_quick_featured_media_previewed_url('audio', '');
    }
    if (selectedType !== 'slider') {
        jQuery('#fifu-quick-slider-input-ratio').val('');
        jQuery('input[id^=fifu_slider_input_url_]').val('');
        jQuery('input[id^=fifu_slider_input_alt_]').val('');
        jQuery('input[id^=fifu_slider_input_width_]').val('');
        jQuery('input[id^=fifu_slider_input_height_]').val('');
        jQuery('input[id^=fifu_slider_input_image_src_]').val('');
        jQuery('#inputHiddenSliderListIds').val('');
        jQuery('#inputHiddenSliderLength').val('0');
    }

    if ($image.length) {
        $image.val(selectedType === 'slider' ? '' : sharedImageValue);
        $image.attr(
            'data-fifu-image-initial-value',
            selectedType === 'image' ? sharedImageValue : ''
        );
        $image.attr(
            'data-fifu-video-thumbnail-initial-value',
            selectedType === 'video' ? sharedImageValue : ''
        );
        $image.attr(
            'data-fifu-audio-artwork-initial-value',
            selectedType === 'audio' ? sharedImageValue : ''
        );
        $image.data('fifu-shared-image-mode', selectedType);
    }
}

function fifu_activate_quick_slider_competing_state() {
    fifu_clear_quick_competing_media_state('slider');

    if (
        typeof fifuColumnVars !== 'undefined'
        && fifuColumnVars.onProductsPage
        && typeof window !== 'undefined'
        && window.FifuWooMixedGallery
        && typeof window.FifuWooMixedGallery.clear === 'function'
    ) {
        window.FifuWooMixedGallery.clear();
    }
}

function fifu_show_quick_featured_media_type(mediaType, isUserTransition) {
    if (isUserTransition) {
        if (mediaType === 'slider') {
            const sliderListIds = String(
                jQuery('#inputHiddenSliderListIds').val() || ''
            );
            if (
                sliderListIds !== ''
                && typeof fifu_activate_quick_slider_competing_state === 'function'
            ) {
                fifu_activate_quick_slider_competing_state();
            }
        } else {
            fifu_clear_quick_competing_media_state(mediaType);
        }
    } else {
        fifu_sync_quick_shared_image_drafts(mediaType);
    }
    fifu_move_quick_featured_image_state(mediaType);
    jQuery('.fifu-quick-featured-media-panel').each(function () {
        const $panel = jQuery(this);
        const isSelected = $panel.attr('data-fifu-media-type') === mediaType;
        if (isSelected) {
            $panel.show();
        } else {
            $panel.hide();
        }
    });

    const $galleries = jQuery('.fifu-quick-featured-media-galleries');
    if (mediaType === 'image' || mediaType === 'video') {
        $galleries.show();
    } else {
        $galleries.hide();
    }

    if (typeof window !== 'undefined' && typeof window.fifuMixedGallerySetPriority === 'function') {
        window.fifuMixedGallerySetPriority(mediaType);
    }

    fifu_update_quick_featured_image_input_mode(mediaType);
    fifu_update_quick_featured_media_preview(mediaType);
    fifu_update_quick_upload_button_visibility();
}

function fifu_move_quick_featured_image_state(mediaType) {
    if (mediaType === 'slider') {
        return;
    }

    const $state = jQuery('#fifu-quick-featured-image-state');
    if (!$state.length) {
        return;
    }

    jQuery('.fifu-quick-featured-media-panel').each(function () {
        const $panel = jQuery(this);
        if ($panel.attr('data-fifu-media-type') === mediaType) {
            if (mediaType === 'video') {
                const $videoPreviewStack = jQuery('#fifu-quick-video-preview-stack');
                if ($videoPreviewStack.length && typeof $videoPreviewStack.after === 'function') {
                    $videoPreviewStack.after($state);
                    return;
                }
            }
            if (mediaType === 'audio') {
                const $audioPreviewStack = jQuery('#fifu-quick-audio-preview-stack');
                if ($audioPreviewStack.length && typeof $audioPreviewStack.find === 'function') {
                    const $audioPreviewButton = $audioPreviewStack.find('#fifu-quick-audio-preview-button');
                    if ($audioPreviewButton.length && typeof $audioPreviewButton.before === 'function') {
                        $audioPreviewButton.before($state);
                        return;
                    }
                }
            }
            $panel.prepend($state);
        }
    });
}

function fifu_init_quick_featured_media_selector(initialType, availableTypes) {
    const $selector = jQuery('#fifu-quick-featured-media-type');
    if (!$selector.length) {
        return;
    }

    const selectedType = fifu_resolve_quick_featured_media_type(initialType, availableTypes);
    $selector.val(selectedType);
    $selector.off('change.fifuQuickFeaturedMedia').on('change.fifuQuickFeaturedMedia', function () {
        fifu_show_quick_featured_media_type(jQuery(this).val(), true);
    });
    fifu_show_quick_featured_media_type(selectedType);
}

function fifu_should_show_quick_upload_button() {
    if (!fifuColumnVars.isUploadEnabled) {
        return false;
    }

    if (fifu_is_quick_direct_image_url(jQuery('#fifu-quick-input-url').val())) {
        return true;
    }

    return fifu_get_quick_slider_upload_payload().hasSliderPayload;
}

function fifu_preview_quick_image(is_ctgr, post_id) {
    const imageValue = String(jQuery('#fifu-quick-input-url').val() || '').trim();
    if (!imageValue) {
        fifu_set_quick_image_previewed_url('');
        fifu_update_quick_featured_media_preview('image');
        return;
    }

    if (fifu_is_quick_direct_image_url(imageValue)) {
        fifu_set_quick_image_previewed_url(imageValue);
        fifu_update_quick_featured_media_preview('image');
        return;
    }

    fifu_set_quick_image_previewed_url('');
    fifu_update_quick_featured_media_preview('image');
    const keywords = imageValue;
    const source = 'unsplash';
    fifu_start_lightbox(keywords, post_id, is_ctgr, 'quick-edit', source);
}

function fifu_preview_quick_video() {
    const $video = jQuery('#fifu-quick-video-input-url');
    let videoUrl = String($video.val() || '').trim();

    if (typeof fifu_convert_video === 'function') {
        const convertedUrl = fifu_convert_video(videoUrl);
        if (convertedUrl !== videoUrl) {
            videoUrl = convertedUrl || '';
            $video.val(videoUrl);
        }
    }

    const previewIsValid = fifu_update_quick_featured_media_preview('video', true);
    const previewedInputUrl = String($video.val() || '').trim();
    fifu_set_quick_featured_media_previewed_url('video', previewIsValid ? previewedInputUrl : '');
    if (typeof fifu_set_quick_video_preview_state === 'function') {
        fifu_set_quick_video_preview_state(!!(previewIsValid && videoUrl));
    }
    fifu_update_quick_featured_image_input_mode('video');
}

function fifu_preview_quick_audio() {
    const audioUrl = String(jQuery('#fifu-quick-audio-input-url').val() || '').trim();
    const thumbnailUrl = String(jQuery('#fifu-quick-input-url').val() || '').trim();
    if (!audioUrl || !thumbnailUrl) {
        fifu_set_quick_featured_media_previewed_url('audio', '');
        fifu_reset_quick_audio_preview();
        fifu_update_quick_featured_image_input_mode('audio');
        return false;
    }

    const previewIsValid = fifu_update_quick_featured_media_preview('audio', true);
    if (previewIsValid) {
        fifu_set_quick_audio_previewed_state(audioUrl, thumbnailUrl);
    } else {
        fifu_set_quick_featured_media_previewed_url('audio', '');
    }
    fifu_update_quick_featured_image_input_mode('audio');
    return previewIsValid;
}

function fifu_quick_video_preview_event() {
    jQuery('#fifu-quick-video-preview-button').on('click', function () {
        fifu_preview_quick_video();
    });
    jQuery('#fifu-quick-video-input-url').on('paste', function () {
        setTimeout(function () {
            fifu_preview_quick_video();
        }, 0);
    });
    if (typeof document !== 'undefined') {
        jQuery(document)
            .off('click.fifuQuickVideoRemove', '#fifu-quick-video-remove')
            .on('click.fifuQuickVideoRemove', '#fifu-quick-video-remove', function (evt) {
                fifu_remove_quick_video(evt);
            });
    }
}

function fifu_remove_quick_video(evt) {
    if (evt) {
        evt.preventDefault();
        evt.stopPropagation();
        if (typeof evt.stopImmediatePropagation === 'function') {
            evt.stopImmediatePropagation();
        }
    }

    const $video = jQuery('#fifu-quick-video-input-url');
    const $image = jQuery('#fifu-quick-input-url');
    const videoUrl = String($video.val() || '').trim();
    const sharedImageMode = $image.length
        ? String($image.data('fifu-shared-image-mode') || '')
        : '';
    const hasVideoThumbnailDraft = $image.length
        ? String($image.data('fifu-video-thumbnail-draft') || '').trim() !== ''
        : false;
    const isCustomVideo = !!(
        videoUrl
        && typeof isCustomVideoUrl === 'function'
        && isCustomVideoUrl(videoUrl)
    );
    const ownsVideoPoster = isCustomVideo && (
        sharedImageMode === 'video'
        || hasVideoThumbnailDraft
    );

    if ($video.length) {
        $video.val('');
        $video.attr('data-fifu-video-initial-value', '');
    }

    jQuery('#fifu-quick-video-input-image-src').val('');
    jQuery('#fifu-quick-video-input-image-width').val('');
    jQuery('#fifu-quick-video-input-image-height').val('');

    if (ownsVideoPoster && $image.length) {
        $image.val('');
        $image.data('fifu-video-thumbnail-draft', '');
        $image.attr('data-fifu-video-thumbnail-initial-value', '');
    }

    if (typeof fifuQuickEditClearedMediaTypes !== 'undefined') {
        fifuQuickEditClearedMediaTypes.video = true;
        if (ownsVideoPoster) {
            fifuQuickEditClearedMediaTypes.image = true;
        }
    }

    fifu_set_quick_featured_media_previewed_url('video', '');
    fifu_update_quick_featured_media_preview('video');
    fifu_update_quick_featured_image_input_mode('video');
}

function fifu_quick_audio_preview_event() {
    jQuery('#fifu-quick-audio-preview-button').on('click', function () {
        fifu_preview_quick_audio();
    });
    jQuery(document)
        .off('click.fifuQuickAudioRemove', '#fifu-quick-audio-remove')
        .on('click.fifuQuickAudioRemove', '#fifu-quick-audio-remove', function (evt) {
            fifu_remove_quick_audio(evt);
        });
}

function fifu_remove_quick_audio(evt) {
    if (evt) {
        evt.preventDefault();
        evt.stopPropagation();
        evt.stopImmediatePropagation();
    }

    const $audio = jQuery('#fifu-quick-audio-input-url');
    const $thumbnail = jQuery('#fifu-quick-input-url');
    if ($audio.length) {
        $audio.val('');
        $audio.data('fifu-audio-dirty', true);
    }
    if ($thumbnail.length) {
        $thumbnail.val('');
    }
    if (typeof fifuQuickEditClearedMediaTypes !== 'undefined') {
        fifuQuickEditClearedMediaTypes.audio = true;
        fifuQuickEditClearedMediaTypes.image = true;
    }

    fifu_set_quick_featured_media_previewed_url('audio', '');
    fifu_reset_quick_audio_preview();
    fifu_update_quick_featured_image_input_mode('audio');
}

function fifu_reset_quick_audio_preview() {
    const $left = jQuery('#fifu-left-column');
    if ($left.length) {
        $left.empty().css('display', 'none');
        if (typeof fifu_update_quick_preview_layout === 'function') {
            fifu_update_quick_preview_layout(false);
        }
    }
}

function fifu_remove_quick_image(evt) {
    if (evt) {
        evt.preventDefault();
        evt.stopPropagation();
        if (typeof evt.stopImmediatePropagation === 'function') {
            evt.stopImmediatePropagation();
        }
    }

    const $image = jQuery('#fifu-quick-input-url');
    if (!$image.length) {
        return;
    }

    $image.val('');
    jQuery('#fifu-quick-image-alt').val('');
    fifu_set_quick_image_previewed_url('');
    fifu_update_quick_featured_media_preview('image');
}

function fifu_quick_image_preview_event(is_ctgr, post_id) {
    jQuery('#fifu-quick-image-preview-button').on('click', function () {
        fifu_preview_quick_image(is_ctgr, post_id);
    });
    jQuery('#fifu-quick-input-url').on('paste', function () {
        setTimeout(function () {
            if (fifu_get_quick_selected_media_type() !== 'image') {
                return;
            }

            fifu_preview_quick_image(is_ctgr, post_id);
        }, 0);
    });
    if (typeof document !== 'undefined') {
        jQuery(document)
            .off('click.fifuQuickImageRemove', '#fifu-quick-image-remove')
            .on('click.fifuQuickImageRemove', '#fifu-quick-image-remove', function (evt) {
                fifu_remove_quick_image(evt);
            });
    }
}

function fifu_update_quick_upload_button_visibility() {
    const $button = jQuery('#fifu-upload-button');
    if (!$button.length) {
        return;
    }

    $button.css('display', fifu_should_show_quick_upload_button() ? '' : 'none');
}

function fifu_set_quick_upload_processing_state(isProcessing) {
    const $button = jQuery('#fifu-upload-button');
    if (!$button.length) {
        return;
    }

    if (isProcessing) {
        if (fifuQuickUploadButtonLabel === null) {
            fifuQuickUploadButtonLabel = $button.text();
        }

        $button.prop('disabled', true);
        $button.css('pointer-events', 'none');
        $button.css('opacity', '0.6');
        $button.text(fifuColumnVars.buttonUploading || fifuQuickUploadButtonLabel || '');

        const $container = jQuery('.fancybox-container.fancybox-is-open');
        if ($container.length && typeof $container.block === 'function') {
            $container.block({message: '', css: {backgroundColor: 'none', border: 'none', color: 'white'}});
        }

        return;
    }

    $button.prop('disabled', false);
    $button.css('pointer-events', '');
    $button.css('opacity', '');
    $button.text(fifuQuickUploadButtonLabel !== null ? fifuQuickUploadButtonLabel : $button.text());

    const $container = jQuery('.fancybox-container.fancybox-is-open');
    if ($container.length && typeof $container.unblock === 'function') {
        $container.unblock();
    }
}

function fifu_open_quick_lightbox() {
    // Use delegated event binding to support dynamic elements
    jQuery(document)
        .off('click.fifuQuickEditorOpen', 'div.fifu-quick')
        .on('click.fifuQuickEditorOpen', 'div.fifu-quick', function (evt) {
        evt.stopImmediatePropagation();
        const $clicked = jQuery(this);
        let post_id = $clicked.attr('post-id');
        let video_url = $clicked.attr('video-url');
        let image_url = $clicked.attr('image-url');
        let video_src = $clicked.attr('video-src');
        let is_ctgr = $clicked.attr('is-ctgr');
        let is_variable = $clicked.attr('is-variable');
        const parentIdAttribute = $clicked.attr('data-parent-id');
        const isLazyItem = $clicked.attr('data-fifu-lazy-item') === '1';

        if (fifu_is_quick_editor_open()) {
            return;
        }

        if (parentIdAttribute !== undefined && parentIdAttribute !== null && parentIdAttribute !== '') {
            fifuActiveQuickEditContext = {
                postId: parseInt(post_id, 10) || 0,
                parentId: parseInt(parentIdAttribute, 10) || 0
            };
        } else {
            fifuActiveQuickEditContext = null;
        }

        if (isLazyItem) {
            if ($clicked.data('fifu-loading-item')) {
                return;
            }

            $clicked.data('fifu-loading-item', true);

            fifu_load_quick_edit_item(post_id).then(function (response) {
                window.fifuQuickEditVars = window.fifuQuickEditVars || {};
                fifuQuickEditVars.posts = fifuQuickEditVars.posts || {};
                fifuQuickEditVars.posts[post_id] = response.payload || {};
                if (response.display) {
                    $clicked.attr('video-url', response.display.video_url || '');
                    $clicked.attr('video-src', response.display.video_src || '');
                    $clicked.attr('image-url', response.display.image_url || '');
                }
                $clicked.removeAttr('data-fifu-lazy-item');
                $clicked.data('fifu-loading-item', false);
                $clicked.trigger('click');
            }).catch(function () {
                $clicked.data('fifu-loading-item', false);
                jQuery.fancybox.open('<div>Unable to load item.</div>', { touch: false });
            });

            return;
        }

        if (is_variable) {
            fifu_load_variable_product(post_id)
                .then(function (response) {
                    response.parent_display = (window.fifuQuickEditVars && fifuQuickEditVars.parent && fifuQuickEditVars.parent[post_id]) ? fifuQuickEditVars.parent[post_id] : {};
                    jQuery.fancybox.open(fifu_render_variable_product_selector(response), {
                        touch: false,
                    });
                })
                .catch(function (xhr) {
                    const responseMessage =
                        xhr
                        && xhr.responseJSON
                        && typeof xhr.responseJSON.message === 'string'
                            ? xhr.responseJSON.message.trim()
                            : '';

                    const message = responseMessage || 'Unable to load variations.';

                    jQuery.fancybox.open('<div class="fifu-variable-selector-error">' + fifu_escape_html(message) + '</div>', {
                        touch: false,
                    });
                });
            return;
        }

        currentLightbox = post_id;
        fifuQuickEditClearRequested = false;
        fifuQuickEditClearedMediaTypes = {
            image: false,
            video: false,
            slider: false,
            audio: false
        };

        // Detect if this click originated inside the variable modal as well
        const inVariableContext = jQuery(this).closest('[data-variable-product="1"]').length > 0;
        const isVariableProduct = !!is_variable || inVariableContext;

        const quickPayload = fifu_get_quick_edit_payload(post_id, is_ctgr);
        const isCategory = fifu_is_quick_edit_category(is_ctgr);
        const payloadVideoUrl = Object.prototype.hasOwnProperty.call(quickPayload, 'fifu_video_url')
            ? quickPayload.fifu_video_url
            : video_url;
        const payloadImageUrl = Object.prototype.hasOwnProperty.call(quickPayload, 'fifu_image_url')
            ? quickPayload.fifu_image_url
            : image_url;
        const audioUrl = String(quickPayload.fifu_audio_url || '').trim();
        const hasAudioState = Object.prototype.hasOwnProperty.call(quickPayload, 'fifu_audio_url');
        fifuQuickFeaturedSliderPreviewKey = '';
        const currentType = quickPayload.fifu_featured_media_type
            || (payloadVideoUrl ? 'video' : (audioUrl ? 'audio' : 'image'));
        const availableTypes = fifu_get_quick_featured_media_types(
            isVariableProduct,
            isCategory,
            currentType,
            payloadVideoUrl,
            audioUrl
        );
        const initialType = fifu_resolve_quick_featured_media_type(currentType, availableTypes);
        const typeLabels = {
            image: fifuColumnVars.labelImage,
            video: fifuColumnVars.labelVideo,
            slider: fifuColumnVars.labelSlider,
            audio: fifuColumnVars.labelAudio
        };
        const mediaTypeOptions = availableTypes.map(function (type) {
            return `<option value="${type}">${fifu_escape_html(typeLabels[type] || type)}</option>`;
        }).join('');
        const showMixedGallery = fifuColumnVars.onProductsPage
            && (initialType === 'image' || (initialType === 'video' && fifuColumnVars.isVideoEnabled))
            ? ''
            : 'display:none';
        const showUploadButton = fifuColumnVars.isUploadEnabled ? '' : 'display:none';
        const hasSliderState = availableTypes.indexOf('slider') !== -1;
        const sliderRatio = String(quickPayload.fifu_slider_ratio || '').trim();
        const imageValue = payloadImageUrl === 'about:invalid' ? '' : (payloadImageUrl || '');
        const hasPersistedAudioPreview = initialType === 'audio'
            && audioUrl !== ''
            && fifu_is_quick_direct_image_url(imageValue);
        fifuQuickFeaturedMediaPreviewedUrls = {
            video: String(payloadVideoUrl || '').trim(),
            audio: hasPersistedAudioPreview ? audioUrl : ''
        };
        fifuQuickFeaturedMediaPreviewedThumbnailUrls = {
            audio: hasPersistedAudioPreview ? String(imageValue || '').trim() : ''
        };
        const imageAlt = String(quickPayload.fifu_image_alt || '').trim();
        fifuQuickFeaturedImagePreviewedUrl = String(imageValue).trim();
        const box = `
            <table class="fifu-quick-editor-layout">
                <tr>
                    <td id="fifu-left-column" class="fifu-quick-editor-preview-column" style="display:none"></td>
                    <td id="fifu-right-column" class="fifu-quick-editor-controls" style="vertical-align:top; padding: 10px; background-color:#f6f7f7; width:250px; border-radius: 8px;">
                        <div>
                            ${fifuColumnVars.isDebugEnabled ? `<button id="fifu-copy-debug-data-button" class="fifu-quick-button fifu-copy-debug-data-button" type="button" onclick="fifu_copy_quick_edit_debug_data(${post_id}, this, '${is_ctgr}')"><span class="dashicons dashicons-clipboard fifu-copy-debug-data-icon" aria-hidden="true"></span><span class="fifu-copy-debug-data-label">${fifuColumnVars.buttonCopyDebugData}</span></button>` : ''}
                            <div class="fifu-quick-featured-media-selector">
                            <select id="fifu-quick-featured-media-type" class="fifu-quick-featured-media-selector-control">
                                ${mediaTypeOptions}
                            </select>
                        </div>

                            <div class="fifu-quick-featured-media-panel" data-fifu-media-type="image" style="display:none">
                                <div id="fifu-quick-featured-image-state" class="fifu-quick-featured-image-state fifu-quick-preview-stack">
                                    <div class="fifu-featured-media-icon-input fifu-quick-featured-media-icon-input">
                                        <button id="fifu-quick-image-help" class="fifu-quick-image-help" type="button" title="${fifu_escape_html(fifuColumnVars.txt_title_examples)}" aria-label="${fifu_escape_html(fifuColumnVars.txt_title_examples)}">
                                            <span class="dashicons dashicons-format-image" aria-hidden="true"></span>
                                        </button>
                                        <span id="fifu-quick-video-thumbnail-icon" class="dashicons dashicons-format-image" aria-hidden="true" style="display:none"></span>
                                        <input id="fifu-quick-input-url" type="text" placeholder="${fifuColumnVars.urlImage}" value="${fifu_escape_html(imageValue)}" data-fifu-image-initial-value="${fifu_escape_html(imageValue)}"/>
                                    </div>
                                    <div id="fifu-quick-image-alt-state" class="fifu-featured-media-icon-input fifu-quick-featured-media-icon-input" style="display:none">
                                        <span id="fifu-quick-image-alt-help" class="dashicons dashicons-media-text" title="${fifu_escape_html(fifuColumnVars.imageAltHelp)}" aria-hidden="true"></span>
                                        <input id="fifu-quick-image-alt" type="text" placeholder="${fifuColumnVars.imageAlt}" value="${fifu_escape_html(imageAlt)}"/>
                                    </div>
                                    <button id="fifu-quick-image-preview-button" class="button fifu-quick-image-preview-button" type="button">${fifuColumnVars.buttonPreview}</button>
                                </div>
                                <br><br>
                            </div>

                            ${availableTypes.indexOf('video') !== -1 ? `
                            <div class="fifu-quick-featured-media-panel" data-fifu-media-type="video" style="display:none">
                                <div id="fifu-quick-video-preview-stack" class="fifu-quick-preview-stack">
                                    <div class="fifu-featured-media-icon-input fifu-quick-featured-media-icon-input">
                                        <span class="dashicons dashicons-format-video" aria-hidden="true"></span>
                                        <input id="fifu-quick-video-input-url" type="text" placeholder="${fifuColumnVars.urlVideo}" value="${fifu_escape_html(payloadVideoUrl || '')}" data-fifu-video-initial-value="${fifu_escape_html(payloadVideoUrl || '')}"/>
                                    </div>
                                    <button id="fifu-quick-video-preview-button" class="button fifu-quick-video-preview-button" type="button">${fifuColumnVars.buttonPreview}</button>
                                </div>
                                <br><br>
                            </div>
                            ` : ''}

                            ${availableTypes.indexOf('slider') !== -1 ? `
                            <div class="fifu-quick-featured-media-panel" data-fifu-media-type="slider" style="display:none">
                                <div id="gridDemoSlider" data-fifu-slider-state-available="${hasSliderState ? '1' : '0'}"></div>
                                <div id="fifu-quick-slider-ratio" class="fifu-quick-slider-ratio" style="display:none" data-fifu-slider-state-available="${hasSliderState ? '1' : '0'}">
                                    <div class="fifu-featured-media-icon-input fifu-quick-featured-media-icon-input">
                                        <span class="dashicons dashicons-image-crop fifu-quick-slider-ratio-help" title="${fifu_escape_html(fifuColumnVars.sliderRatioExample)}" aria-hidden="true"></span>
                                        <input id="fifu-quick-slider-input-ratio" type="text" placeholder="${fifu_escape_html(fifuColumnVars.sliderRatio)}" value="${fifu_escape_html(sliderRatio)}" data-fifu-slider-ratio-initial-value="${fifu_escape_html(sliderRatio)}"/>
                                    </div>
                                </div>
                                <div id="inputHiddenSliders"></div>
                                <input type="hidden" id="inputHiddenSliderListIds" name="inputHiddenSliderListIds" val=""/>
                                <input type="hidden" id="inputHiddenSliderLength" name="inputHiddenSliderLength" val=""/>
                                <br>
                            </div>
                            ` : ''}

                            ${availableTypes.indexOf('audio') !== -1 ? `
                            <div class="fifu-quick-featured-media-panel" data-fifu-media-type="audio" style="display:none">
                                <div id="fifu-quick-audio-preview-stack" class="fifu-quick-preview-stack">
                                    <div class="fifu-featured-media-icon-input fifu-quick-featured-media-icon-input">
                                        <span class="dashicons dashicons-controls-volumeon" aria-hidden="true"></span>
                                        <input id="fifu-quick-audio-input-url" type="text" placeholder="${fifuColumnVars.urlAudio}" value="${fifu_escape_html(audioUrl)}" data-fifu-audio-state-available="${hasAudioState ? '1' : '0'}" data-fifu-audio-initial-value="${fifu_escape_html(audioUrl)}"/>
                                    </div>
                                    <button id="fifu-quick-audio-preview-button" class="button fifu-quick-audio-preview-button" type="button">${fifuColumnVars.buttonPreview}</button>
                                </div>
                                <br><br>
                            </div>
                            ` : ''}
                        </div>
                        ${fifuColumnVars.onProductsPage ? `
                        <div class="fifu-featured-media-galleries fifu-quick-featured-media-galleries" style="${showMixedGallery}">
                            <section class="fifu-featured-media-mixed-gallery">
                                <div class="fifu-featured-media-gallery-divider"><span>${fifuColumnVars.labelImageVideoGallery}</span></div>
                                <div id="fifuMixedGallery" class="fifu-mixed-gallery-grid" aria-label="${fifuColumnVars.labelImageVideoGallery}"></div>
                                <div id="inputHiddenMixedImages"></div>
                                <div id="inputHiddenMixedVideos"></div>
                                <input type="hidden" id="inputHiddenImageListIds" name="inputHiddenImageListIds" value="" />
                                <input type="hidden" id="inputHiddenImageLength" name="inputHiddenImageLength" value="" />
                                <input type="hidden" id="inputHiddenVideoListIds" name="inputHiddenVideoListIds" value="" />
                                <input type="hidden" id="inputHiddenVideoLength" name="inputHiddenVideoLength" value="" />
                            </section>
                        </div>
                        ` : ''}
                        <div style="width:100%">
                            <button id="fifu-clean-button" class="fifu-quick-button" type="button" style="background-color: #e7e7e7; color: black;">${fifuColumnVars.buttonClean}</button>
                            <button id="fifu-save-button" post-id="${post_id}" is-ctgr="${is_ctgr}" class="fifu-quick-button fifu-quick-save-button" type="button">${fifuColumnVars.buttonSave}</button>
                            <br>
                            <div style="${showUploadButton}">
                                <button id="fifu-upload-button" post-id="${post_id}" is-ctgr="${is_ctgr}" onclick="fifu_upload_images_quick_api()" class="fifu-quick-button" style="background-color: #3c434a; width:97.5%; position:relative; top:2px" type="button">${fifuColumnVars.buttonUpload}</button>
                            </div>
                        </div>
                    </td>
                </tr>
            </table>                           
        `;
        fifu_include_input_hidden(post_id);
        fifuQuickEditorSaving = false;
        fifuQuickEditorInitialFocusApplied = false;
        fifuQuickEditorOpen = true;
        jQuery.fancybox.open(box, {
            touch: false,
            autoFocus: false,
            afterShow: async function () {
                if (currentLightbox) {
                    fifu_get_image_info(currentLightbox);
                    fifu_get_video_info(currentLightbox);
                    fifu_get_audio_info(currentLightbox);
                }

                if (
                    fifuColumnVars.onProductsPage
                    && window.FifuWooMixedGallery
                    && typeof window.FifuWooMixedGallery.initialize === 'function'
                ) {
                    const mixedGalleryPayload = fifu_get_quick_mixed_gallery_payload(quickPayload);
                    const mixedGalleryVars = Object.assign(
                        {},
                        window.fifuMixedGalleryVars || {},
                        mixedGalleryPayload,
                        {
                            selectedType: initialType,
                            videoEnabled: !!fifuColumnVars.isVideoEnabled,
                        }
                    );
                    window.FifuWooMixedGallery.initialize({
                        vars: mixedGalleryVars,
                        grid: document.getElementById('fifuMixedGallery'),
                        form: false,
                        sortableAppendTo: document.body,
                        sortableZIndex: 1000000,
                    });
                }

                if (!fifuColumnVars.onCategoriesPage && availableTypes.indexOf('slider') !== -1) {
                    fifu_slider_box_init();
                    fifu_get_image_info(currentLightbox);
                }

                fifu_init_quick_featured_media_selector(initialType, availableTypes);
                fifu_update_quick_upload_button_visibility();
                if (!fifuQuickEditorInitialFocusApplied) {
                    fifuQuickEditorInitialFocusApplied = true;
                    setTimeout(function () {
                        if (fifuQuickEditorOpen) {
                            fifu_focus_quick_featured_media_primary_input(initialType);
                        }
                    }, 0);
                }
            },
            beforeClose: function () {
                if (
                    typeof fifuColumnVars !== 'undefined'
                    && fifuColumnVars.onProductsPage
                    && typeof window !== 'undefined'
                    && window.FifuWooMixedGallery
                    && typeof window.FifuWooMixedGallery.destroy === 'function'
                ) {
                    window.FifuWooMixedGallery.destroy();
                }
            },
            afterClose: function () {
                fifuQuickEditorSaving = false;
                fifu_set_quick_editor_saving_state(false);
                fifuQuickEditorOpen = false;
                fifuQuickEditorInitialFocusApplied = false;
                jQuery('input[id^=fifu-quick-video-input]').remove();
            },
        }
        );
        fifu_change_image_event();
        fifu_save_event();
        fifu_keypress_event();
        fifu_quick_image_preview_event(is_ctgr, post_id);
        fifu_quick_video_preview_event();
        fifu_quick_audio_preview_event();
        });
}

function fifu_change_image_event() {
    jQuery('#fifu-quick-input-url').on('input change', function () {
        const imageUrl = String(jQuery(this).val() || '').trim();
        const videoUrl = String(jQuery('#fifu-quick-video-input-url').val() || '').trim();
        const mediaType = fifu_get_quick_selected_media_type();

        if (mediaType === 'audio') {
            const audioUrl = String(jQuery('#fifu-quick-audio-input-url').val() || '').trim();
            const audioPreviewIsCurrent = fifu_is_quick_audio_previewed(audioUrl, imageUrl);
            if (!audioPreviewIsCurrent) {
                fifu_set_quick_featured_media_previewed_url('audio', '');
                fifu_reset_quick_audio_preview();
            }
            fifu_update_quick_featured_image_input_mode('audio');
        } else if (mediaType === 'image') {
            const previewedImageUrl = String(fifuQuickFeaturedImagePreviewedUrl || '').trim();
            if (imageUrl !== previewedImageUrl) {
                fifu_set_quick_image_previewed_url('');
                fifu_update_quick_featured_media_preview('image');
            }
        } else if (
            mediaType === 'video'
            && typeof isCustomVideoUrl === 'function'
            && isCustomVideoUrl(videoUrl)
            && fifu_is_quick_featured_media_previewed('video', videoUrl)
        ) {
            fifu_update_quick_featured_media_preview('video');
            fifu_update_quick_featured_image_input_mode('video');
        }

        fifu_update_quick_upload_button_visibility();
    });

    jQuery('#fifu-quick-input-url')
        .off('paste.fifuQuickAudioThumbnail')
        .on('paste.fifuQuickAudioThumbnail', function () {
            setTimeout(function () {
                if (fifu_get_quick_selected_media_type() !== 'audio') {
                    return;
                }

                const audioUrl = String(jQuery('#fifu-quick-audio-input-url').val() || '').trim();
                const thumbnailUrl = String(jQuery('#fifu-quick-input-url').val() || '').trim();
                if (!audioUrl || !thumbnailUrl) {
                    return;
                }

                fifu_preview_quick_audio();
            }, 0);
        });

    jQuery('#fifu-quick-video-input-url').on('input change', function () {
        const videoUrl = String(jQuery(this).val() || '').trim();
        const postId = jQuery('#fifu-save-button').attr('post-id');
        let videoSrc = '';
        const videoPreviewIsStale = fifu_invalidate_quick_featured_media_preview_if_stale('video', videoUrl);

        if (videoPreviewIsStale && typeof fifu_set_quick_video_preview_state === 'function') {
            fifu_set_quick_video_preview_state(false);
        }

        if (typeof srcVideo === 'function') {
            videoSrc = srcVideo(videoUrl) || '';
        }
        jQuery('.fifu-quick[post-id="' + postId + '"]')
            .attr('video-url', videoUrl)
            .attr('video-src', videoSrc);

        if (videoUrl && typeof fifu_format_previous_input === 'function' && typeof fifu_video_image_thumbnail === 'function') {
            const normalizedVideoUrl = fifu_format_previous_input(videoUrl);
            if (normalizedVideoUrl !== fifuPreviousInputs['fifu-quick-video-input-url']) {
                const videoThumbUrl = fifu_video_image_thumbnail(videoUrl, fifuColumnVars);
                if (videoThumbUrl !== undefined) {
                    if (!isCustomVideoUrl(videoUrl)) {
                        fifu_quick_video_get_image(videoThumbUrl);
                    }
                }
                fifuPreviousInputs['fifu-quick-video-input-url'] = normalizedVideoUrl;
            }
        }

        fifu_update_quick_featured_image_input_mode(fifu_get_quick_selected_media_type());
        if (videoPreviewIsStale && fifu_get_quick_selected_media_type() === 'video') {
            fifu_update_quick_featured_media_preview('video');
        }
    });

    jQuery('#fifu-quick-audio-input-url').on('input change', function () {
        jQuery(this).data('fifu-audio-dirty', true);
        const audioUrl = String(jQuery(this).val() || '').trim();
        const audioPreviewIsStale = fifu_invalidate_quick_featured_media_preview_if_stale('audio', audioUrl);
        if ((audioPreviewIsStale || !audioUrl) && fifu_get_quick_selected_media_type() === 'audio') {
            fifu_reset_quick_audio_preview();
        }
        if (fifu_get_quick_selected_media_type() === 'audio') {
            fifu_update_quick_featured_image_input_mode('audio');
        }
    });

    jQuery('#fifu-clean-button').on('click', fifu_clear_quick_edit_media_state);
}

function fifu_clear_quick_edit_media_state() {
        fifu_reset_quick_shared_image_drafts();
        fifuQuickEditClearRequested = true;
        if (
            typeof fifuColumnVars !== 'undefined'
            && fifuColumnVars.onProductsPage
            && typeof window !== 'undefined'
            && window.FifuWooMixedGallery
            && typeof window.FifuWooMixedGallery.clear === 'function'
        ) {
            window.FifuWooMixedGallery.clear();
        }
        jQuery('#fifu-left-column').empty().css('display', 'none');
        if (typeof fifu_update_quick_preview_layout === 'function') {
            fifu_update_quick_preview_layout(false);
        }
        jQuery('#fifu-quick-input-url').val('');
        jQuery('#fifu-quick-image-alt').val('');
        fifu_set_quick_image_previewed_url('');
        jQuery('#fifu-quick-video-input-url').val('');
        jQuery('#fifu-quick-audio-input-url').val('');
        jQuery('#fifu-quick-audio-input-url').data('fifu-audio-dirty', true);

        const $sliderGrid = jQuery('#gridDemoSlider');
        if ($sliderGrid.length && $sliderGrid.attr('data-fifu-slider-state-available') === '1') {
            jQuery('#fifu-quick-slider-input-ratio').val('');
        }

        jQuery('[id^=fifu_input_], [id^=fifu_video_input_], [id^=fifu_slider_input_]').each(function () {
            jQuery(this).val('');
        });
        jQuery('[id^=fifu-image-], [id^=fifu-video-], [id^=fifu-slider-]').each(function () {
            jQuery(this).css('background', '');
            jQuery(this).css('opacity', '');
        });

        if (typeof updateSliderList === 'function' && jQuery('#gridDemoSlider').length) {
            updateSliderList();
        } else {
            fifu_update_quick_upload_button_visibility();
        }
        fifu_update_quick_featured_image_input_mode(fifu_get_quick_selected_media_type());
        fifu_update_quick_featured_media_preview(fifu_get_quick_selected_media_type());
}

function fifu_get_quick_gallery_request_data() {
    const requestData = {};

    if (!fifuColumnVars.onProductsPage) {
        return requestData;
    }

    const $mixedGallery = jQuery('#fifuMixedGallery');
    if ($mixedGallery.length) {
        const galleryIds = String(jQuery('#inputHiddenImageListIds').val() || '');
        const galleryUrls = [];
        const galleryAlts = [];
        const galleryIfms = [];
        const galleryLength = parseInt(jQuery('#inputHiddenImageLength').val(), 10);

        if (galleryIds !== '') {
            for (const index of galleryIds.split('|')) {
                if (index === '') {
                    continue;
                }

                galleryUrls.push(jQuery(`#fifu_input_url_${index}`).val() || '');
                galleryAlts.push(jQuery(`#fifu_input_alt_${index}`).val() || '');
                galleryIfms.push(jQuery(`#fifu_input_ifm_${index}`).val() || '');
            }
        }

        requestData.gallery_length = Number.isNaN(galleryLength) ? 0 : galleryLength;
        requestData.gallery_urls = galleryUrls;
        requestData.gallery_alts = galleryAlts;
        requestData.gallery_ifms = galleryIfms;
        if (fifuColumnVars.isVideoEnabled) {
            const galleryVideoIds = String(jQuery('#inputHiddenVideoListIds').val() || '');
            const galleryVideoUrls = [];
            const galleryThumbUrls = [];
            const galleryVideoLength = parseInt(jQuery('#inputHiddenVideoLength').val(), 10);

            if (galleryVideoIds !== '') {
                for (const index of galleryVideoIds.split('|')) {
                    if (index === '') {
                        continue;
                    }

                    galleryVideoUrls.push(jQuery(`#fifu_video_input_url_${index}`).val() || '');
                    galleryThumbUrls.push(jQuery(`#fifu_video_input_image_src_${index}`).val() || '');
                }
            }

            requestData.gallery_video_length = Number.isNaN(galleryVideoLength) ? 0 : galleryVideoLength;
            requestData.gallery_video_urls = galleryVideoUrls;
            requestData.gallery_thumb_urls = galleryThumbUrls;
        }
    }

    return requestData;
}

function fifu_get_quick_slider_request_data() {
    const $sliderGrid = jQuery('#gridDemoSlider');
    if (!$sliderGrid.length || $sliderGrid.attr('data-fifu-slider-state-available') !== '1') {
        return null;
    }

    const sliderLengthValue = jQuery('#inputHiddenSliderLength').val();
    const parsedSliderLength = parseInt(sliderLengthValue, 10);
    const sliderIds = String(jQuery('#inputHiddenSliderListIds').val() || '');
    const sliderUrls = [];
    const sliderAlts = [];

    if (sliderIds !== '') {
        for (const index of sliderIds.split('|')) {
            if (index === '') {
                continue;
            }

            sliderUrls.push(jQuery(`#fifu_slider_input_url_${index}`).val() || '');
            sliderAlts.push(jQuery(`#fifu_slider_input_alt_${index}`).val() || '');
        }
    }

    const selectedType = typeof fifu_get_quick_selected_media_type === 'function'
        ? fifu_get_quick_selected_media_type()
        : '';
    const sliderRatio = String(jQuery('#fifu-quick-slider-input-ratio').val() || '').trim();
    if (
        typeof fifuQuickEditClearedMediaTypes !== 'undefined'
        && fifuQuickEditClearedMediaTypes.slider
        && (
            selectedType !== 'slider'
            || (sliderUrls.length === 0 && sliderRatio === '')
        )
    ) {
        return {
            slider_length: 0,
            slider_urls: [],
            slider_alts: [],
            fifu_slider_input_ratio: ''
        };
    }

    return {
        slider_length: Number.isNaN(parsedSliderLength) ? 0 : parsedSliderLength,
        slider_urls: sliderUrls,
        slider_alts: sliderAlts,
        fifu_slider_input_ratio: sliderRatio
    };
}

function fifu_save_event() {
    jQuery('#fifu-save-button').on('click', function () {
        if (fifuQuickEditorSaving) {
            return;
        }

        fifuQuickEditorSaving = true;
        fifu_set_quick_editor_saving_state(true);

        post_id = jQuery(this).attr('post-id');
        is_ctgr = jQuery(this).attr('is-ctgr');

        const mediaRequest = fifu_get_quick_media_request_data();
        const image_url = mediaRequest.image_url || '';
        const image_alt = Object.prototype.hasOwnProperty.call(mediaRequest, 'image_alt')
            ? mediaRequest.image_alt
            : '';
        const video_url = mediaRequest.video_url || '';
        const audioRequest = fifu_get_quick_audio_request_value();
        const video_src = jQuery("iframe#fifu-quick-preview").attr('src');

        img = jQuery("img[post-id=" + post_id + "]")[0];
        iframe = jQuery("iframe[post-id=" + post_id + "]")[0];

        width = height = video_thumb_url = null;

        const galleryRequest = fifu_get_quick_gallery_request_data();
        const galleryUrls = galleryRequest.gallery_urls || [];
        const galleryAlts = galleryRequest.gallery_alts || [];
        const galleryIfms = galleryRequest.gallery_ifms || [];
        const galleryVideoUrls = galleryRequest.gallery_video_urls || [];
        const galleryThumbUrls = galleryRequest.gallery_thumb_urls || [];
        const requestGallery = Object.assign({}, galleryRequest);
        delete requestGallery.gallery_thumb_urls;

        if (image_url && video_url && isCustomVideoUrl(video_url)) {
            img = jQuery("img#fifu-quick-preview-hidden-img[post-id=" + post_id + "]")[0]
                || jQuery("img#fifu-quick-preview")[0];
            if (img) {
                width = img.naturalWidth;
                height = img.naturalHeight;
            }
            video_thumb_url = image_url;
        } else if (image_url) {
            // Fix: Use the correct selector for the preview image
            img = jQuery("img#fifu-quick-preview")[0];
            if (img) {
                width = img.naturalWidth;
                height = img.naturalHeight;
            }
        } else if (video_url) {
            width = jQuery("#fifu-quick-video-input-image-width")[0].value;
            height = jQuery("#fifu-quick-video-input-image-height")[0].value;
            video_thumb_url = jQuery("#fifu-quick-video-input-image-src")[0].value;
        }

        const sliderRequest = fifu_get_quick_slider_request_data();
        const requestData = {
            "post_id": post_id,
            "is_ctgr": is_ctgr,
            "width": width,
            "height": height,
        };
        Object.assign(requestData, mediaRequest);
        Object.assign(requestData, requestGallery);
        if (sliderRequest) {
            Object.assign(requestData, sliderRequest);
        }
        fifu_add_quick_audio_request_param(requestData);
        if (fifuQuickEditClearRequested) {
            requestData.fifu_quick_edit_clear_all_media = '1';
        }

        jQuery.ajax({
            method: "POST",
            url: fifuColumnVars.restUrl + 'fifu-premium/v2/quick_edit_save_api/',
            data: requestData,
            async: true,
            beforeSend: function (xhr) {
                xhr.setRequestHeader("X-WP-Nonce", fifuColumnVars.nonce);
            },
            success: function (data) {
                const cacheParentId = fifuActiveQuickEditContext && String(fifuActiveQuickEditContext.postId) === String(post_id)
                    ? fifuActiveQuickEditContext.parentId
                    : 0;
                fifu_invalidate_quick_edit_cache(post_id, cacheParentId);

                // featured image
                if (Object.prototype.hasOwnProperty.call(mediaRequest, 'image_url')) {
                    if (fifuColumnVars.onCategoriesPage) {
                        fifuQuickEditCtgrVars.terms[post_id]['fifu_image_url'] = image_url;
                        if (Object.prototype.hasOwnProperty.call(mediaRequest, 'image_alt')) {
                            fifuQuickEditCtgrVars.terms[post_id]['fifu_image_alt'] = image_alt;
                        }
                    } else {
                        fifuQuickEditVars.posts[post_id]['fifu_image_url'] = image_url;
                        if (Object.prototype.hasOwnProperty.call(mediaRequest, 'image_alt')) {
                            fifuQuickEditVars.posts[post_id]['fifu_image_alt'] = image_alt;
                        }

                        if (fifuQuickEditVars.parent && fifuQuickEditVars.parent[post_id])
                            fifuQuickEditVars.parent[post_id]['image-url'] = image_url;
                    }
                }

                fifu_update_quick_edit_audio_cache(post_id, audioRequest);

                // featured video
                if (Object.prototype.hasOwnProperty.call(mediaRequest, 'video_url')) {
                    if (fifuColumnVars.onCategoriesPage) {
                        fifuQuickEditCtgrVars.terms[post_id]['fifu_video_url'] = video_url;
                        fifuQuickEditCtgrVars.terms[post_id]['fifu_video_src'] = video_src;
                    } else {
                        fifuQuickEditVars.posts[post_id]['fifu_video_url'] = video_url;
                        fifuQuickEditVars.posts[post_id]['fifu_video_src'] = video_src;

                        if (fifuQuickEditVars.parent && fifuQuickEditVars.parent[post_id]) {
                            fifuQuickEditVars.parent[post_id]['video-url'] = video_url;
                            fifuQuickEditVars.parent[post_id]['video-src'] = video_src;
                        }
                    }
                }

                if (!fifuColumnVars.onCategoriesPage) {
                    // featured slider
                    if (sliderRequest) {
                        fifuQuickEditVars.posts[post_id]['fifu_slider_image_urls'] = sliderRequest.slider_urls;
                        fifuQuickEditVars.posts[post_id]['fifu_slider_image_alts'] = sliderRequest.slider_alts;
                        fifuQuickEditVars.posts[post_id]['fifu_slider_ratio'] = sliderRequest.fifu_slider_input_ratio;
                    }

                    // image gallery
                    if (Object.prototype.hasOwnProperty.call(galleryRequest, 'gallery_length')) {
                        fifuQuickEditVars.posts[post_id]['fifu_image_urls'] = galleryUrls;
                        fifuQuickEditVars.posts[post_id]['fifu_image_alts'] = galleryAlts;
                        fifuQuickEditVars.posts[post_id]['fifu_image_ifms'] = galleryIfms;
                    }

                    // video gallery
                    if (Object.prototype.hasOwnProperty.call(galleryRequest, 'gallery_video_length')) {
                        fifuQuickEditVars.posts[post_id]['fifu_video_urls'] = galleryVideoUrls;
                        fifuQuickEditVars.posts[post_id]['fifu_thumb_urls'] = galleryThumbUrls;
                    }
                }

                fifuQuickEditClearRequested = false;

                const responseJson = typeof data === 'string' ? JSON.parse(data) : data;
                const savedMediaType = responseJson && responseJson.fifu_featured_media_type
                    ? responseJson.fifu_featured_media_type
                    : fifu_get_quick_selected_media_type();
                if (fifuColumnVars.onCategoriesPage) {
                    fifuQuickEditCtgrVars.terms[post_id]['fifu_featured_media_type'] = savedMediaType;
                } else {
                    fifuQuickEditVars.posts[post_id]['fifu_featured_media_type'] = savedMediaType;
                }
                let url = responseJson && typeof responseJson === 'object' ? responseJson['thumb_url'] ?? '' : '';
                url = url ? url : '';

                // If url contains #http, use the part after # as the image URL
                if (url && url.includes('#http')) {
                    url = url.substring(url.indexOf('#http') + 1);
                }

                if (!fifuColumnVars.onCategoriesPage) {
                    if (fifuQuickEditVars.parent && fifuQuickEditVars.parent[post_id]) {
                        fifuQuickEditVars.parent[post_id]['image-url'] = url;
                    }
                }

                const thumbs = jQuery('div.fifu-quick[post-id=' + post_id + ']');
                for (let i = 0; i < thumbs.length; i++) {
                    const thumb = thumbs[i];
                    jQuery(thumb).attr('image-url', url);

                    // Check for invalid video URL and set fallback if needed
                    const videoUrl = jQuery(thumb).attr('video-url');
                    if (videoUrl && typeof fifu_is_video === 'function' && !fifu_is_video(videoUrl)) {
                        jQuery(thumb).css('background-image', 'url("' + FIFU_VIDEO_NOT_FOUND_URL + '")');
                        jQuery(thumb).css('border', 'none');

                        // Update category thumbnail <img> in the table cell (categories)
                        jQuery(`tr#tag-${post_id} td.thumb.column-thumb img[alt="Thumbnail"]`).each(function () {
                            this.src = WC_PLACEHOLDER_IMAGE_URL;
                            this.removeAttribute('srcset');
                            this.removeAttribute('sizes');
                        });

                        continue;
                    }

                    let adjustedUrl = fifu_cdn_adjust(url);
                    jQuery(thumb).css('background-image', 'url("' + adjustedUrl + '")');
                    url ? jQuery(thumb).css('border', 'none') : jQuery(thumb).css('color', '#ca4a1f').css('border', '2px').css('border-style', 'dotted').css('border-radius', '8px');

                    // Minimal addition: check if image loads, set fallback if not
                    if (url) {
                        let img = new window.Image();
                        img.onerror = function () {
                            jQuery(thumb).css('background-image', 'url("' + FIFU_IMAGE_NOT_FOUND_URL + '")');
                        };
                        img.src = adjustedUrl;
                    }
                }

                thumb = jQuery('div.fifu-quick[post-id=' + post_id + ']')[0];
                jQuery(thumb).attr('image-url', url);

                // Only set background if not an invalid video

                const videoUrl = jQuery(thumb).attr('video-url');
                if (!(videoUrl && typeof fifu_is_video === 'function' && !fifu_is_video(videoUrl))) {
                    jQuery(thumb).css('background-image', 'url("' + fifu_cdn_adjust(url) + '")');
                    url ? jQuery(thumb).css('border', 'none') : jQuery(thumb).css('color', '#ca4a1f').css('border', '2px').css('border-style', 'dotted').css('border-radius', '8px');
                }

                // Also update the thumbnail <img> in the table cell to the new image URL (or placeholder if empty)
                const thumbImg = jQuery(`td.thumb.column-thumb a[href*="post=${post_id}"] img`);
                if (thumbImg.length) {
                    // Check if the video is invalid
                    if (videoUrl && typeof fifu_is_video === 'function' && !fifu_is_video(videoUrl)) {
                        // Set to video not found image
                        thumbImg
                                .attr('src', WC_PLACEHOLDER_IMAGE_URL)
                                .removeAttr('srcset')
                                .removeAttr('sizes');
                    } else {
                        // Set the src to the new image URL or placeholder
                        thumbImg
                                .attr('src', url ? url : WC_PLACEHOLDER_IMAGE_URL)
                                .removeAttr('srcset')
                                .removeAttr('sizes');
                        // Add error handler to set fallback if image fails to load
                        thumbImg.off('error.fifu').on('error.fifu', function () {
                            jQuery(this).attr('src', WC_PLACEHOLDER_IMAGE_URL);
                        });
                    }
                }

                if (fifuColumnVars.onCategoriesPage) {
                    // Update the category thumbnail <img> in the table cell
                    const catThumbImg = jQuery(`tr#tag-${post_id} td.thumb.column-thumb img[alt="Thumbnail"]`);

                    // Check if the video is invalid
                    const thumbDiv = jQuery('div.fifu-quick[post-id="' + post_id + '"]');
                    const videoUrl = thumbDiv.attr('video-url');
                    if (catThumbImg.length) {
                        if (videoUrl && typeof fifu_is_video === 'function' && !fifu_is_video(videoUrl)) {
                            // Set to video not found image
                            catThumbImg
                                    .attr('src', WC_PLACEHOLDER_IMAGE_URL)
                                    .removeAttr('srcset')
                                    .removeAttr('sizes');
                        } else {
                            // Set to real image or placeholder
                            catThumbImg
                                    .attr('src', url ? url : WC_PLACEHOLDER_IMAGE_URL)
                                    .off('error.fifu')
                                    .on('error.fifu', function () {
                                        jQuery(this).attr('src', WC_PLACEHOLDER_IMAGE_URL);
                                    });
                        }
                    }
                }

                jQuery.fancybox.close();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                fifuQuickEditorSaving = false;
                fifu_set_quick_editor_saving_state(false);

                const response = jqXHR && jqXHR.responseJSON ? jqXHR.responseJSON : {};
                const message = response.message || errorThrown || textStatus || 'FIFU Quick Edit could not save the media.';

                console.log(jqXHR);
                console.log(textStatus);
                console.log(errorThrown);

                alert(message);
            },
        });
    });
}

function fifu_keypress_event() {
    jQuery('div.fancybox-container.fancybox-is-open').keyup(function (e) {
        switch (e.which) {
            case 13:
                jQuery(this).blur();
                // enter (save)
                jQuery('#fifu-save-button').focus().click();
                break;
            case 27:
                // esc
                jQuery.fancybox.close();
                break;
            default:
                break;
        }
    });
}

function fifu_quick_video_get_image(url) {
    var image = new Image();
    jQuery(image).attr('onload', 'fifu_quick_video_store_sizes(this);');
    jQuery(image).attr('src', url);
}

function fifu_quick_video_store_sizes($) {
    jQuery("#fifu-quick-video-input-image-width").val($.naturalWidth);
    jQuery("#fifu-quick-video-input-image-height").val($.naturalHeight);
    if ($.naturalWidth == 120 && $.naturalHeight == 90)
        jQuery("#fifu-quick-video-input-image-src").val($.src.replace('maxresdefault', 'mqdefault'));
    else
        jQuery("#fifu-quick-video-input-image-src").val($.src);
}

function fifu_include_input_hidden(post_id) {
    hidden_input = `
        <input 
            post-id="${post_id}"
            type="hidden" 
            id="fifu-quick-video-input-image-width" 
            name="fifu-quick-video-input-image-width" 
            value="" >

        <input
            post-id="${post_id}"
            type="hidden" 
            id="fifu-quick-video-input-image-height" 
            name="fifu-quick-video-input-image-height" 
            value="" >

        <input 
            post-id="${post_id}"
            type="hidden" 
            id="fifu-quick-video-input-image-src" 
            name="fifu-quick-video-input-image-src" 
            value="" >
    `;
    jQuery("div.fifu-quick").after(hidden_input);
}

function fifu_get_image_info(post_id) {
    // Fix: Initialize category data if missing (new category case)
    if (fifuColumnVars.onCategoriesPage) {
        if (!fifuQuickEditCtgrVars.terms[post_id]) {
            // Try to get from DOM
            let $div = jQuery('.fifu-quick[post-id="' + post_id + '"]');
            let videoSrc = $div.attr('video-src') || '';
            fifuQuickEditCtgrVars.terms[post_id] = {
                fifu_image_url: videoSrc ? '' : ($div.attr('image-url') || ''),
                fifu_image_alt: '',
                fifu_video_url: $div.attr('video-url') || '',
                fifu_video_src: videoSrc
            };
        }
    }

    const payload = fifu_get_quick_edit_payload(post_id, fifuColumnVars.onCategoriesPage);
    const imageUrl = payload.fifu_image_url || '';
    const imageAlt = payload.fifu_image_alt || '';
    const normalizedImageUrl = imageUrl === 'about:invalid' ? '' : imageUrl;
    const mediaType = payload.fifu_featured_media_type
        || fifu_get_quick_selected_media_type();
    const videoUrl = payload.fifu_video_url || '';

    fifu_initialize_quick_shared_image_drafts(
        mediaType,
        normalizedImageUrl,
        videoUrl
    );

    jQuery('#fifu-quick-image-alt').val(imageAlt);

    fifu_update_quick_upload_button_visibility();
}

function fifu_get_video_info(post_id) {
    const payload = fifu_get_quick_edit_payload(post_id, fifuColumnVars.onCategoriesPage);
    const videoUrl = payload.fifu_video_url || '';
    const $video = jQuery('#fifu-quick-video-input-url');
    $video.val(videoUrl);
    if ($video.length) {
        $video.attr('data-fifu-video-initial-value', videoUrl);
    }
    if (videoUrl && typeof fifu_format_previous_input === 'function') {
        fifuPreviousInputs['fifu-quick-video-input-url'] = fifu_format_previous_input(videoUrl);
    }
}

function fifu_get_audio_info(post_id) {
    const payload = fifu_get_quick_edit_payload(post_id, fifuColumnVars.onCategoriesPage);
    const audioUrl = payload.fifu_audio_url || '';
    const $audio = jQuery('#fifu-quick-audio-input-url');
    $audio.val(audioUrl);
    if ($audio.length) {
        $audio.attr('data-fifu-audio-state-available', Object.prototype.hasOwnProperty.call(payload, 'fifu_audio_url') ? '1' : '0');
        $audio.attr('data-fifu-audio-initial-value', audioUrl);
        $audio.data('fifu-audio-dirty', false);
    }
}

function fifu_upload_images_quick_api(postId) {
    setTimeout(function () {
        if (fifuQuickUploadInFlight) {
            return;
        }

        // Resolve the post ID from arg, currentLightbox, or the button attribute
        const pid = postId || currentLightbox || jQuery('#fifu-upload-button').attr('post-id');

        let url = jQuery("#fifu-quick-input-url").val();
        let alt = '';
        let urls = '';
        let alts = '';
        let fromSlider = false;
        if (fifuColumnVars.onProductsPage) {
            const galleryRequest = fifu_get_quick_gallery_request_data();
            const galleryUrls = Array.isArray(galleryRequest.gallery_urls)
                ? galleryRequest.gallery_urls
                : [];
            const galleryAlts = Array.isArray(galleryRequest.gallery_alts)
                ? galleryRequest.gallery_alts
                : [];
            const uploadGalleryUrls = [];
            const uploadGalleryAlts = [];

            galleryUrls.forEach(function (galleryUrl, index) {
                if (!galleryUrl) {
                    return;
                }

                uploadGalleryUrls.push(galleryUrl);
                uploadGalleryAlts.push(galleryAlts[index] || '');
            });

            urls = uploadGalleryUrls.join('|');
            alts = uploadGalleryAlts.join('|');
        }

        if (!url && !urls && fifuColumnVars.onProductsPage) {
            const sliderPayload = fifu_get_quick_slider_upload_payload();
            if (sliderPayload.hasSliderPayload) {
                url = sliderPayload.featuredUrl;
                alt = sliderPayload.featuredAlt;
                urls = sliderPayload.galleryUrls.join('|');
                alts = sliderPayload.galleryAlts.join('|');
                fromSlider = true;
            }
        }

        if (!url && !urls) {
            return;
        }

        fifuQuickUploadInFlight = true;
        fifu_set_quick_upload_processing_state(true);

        jQuery.ajax({
            method: "POST",
            url: fifuColumnVars.restUrl + 'fifu-premium/v2/upload_images/',
            data: {
                "url": url,
                "alt": alt,
                "urls": urls,
                "alts": alts,
                "post_id": pid, // was currentLightbox; use resolved pid
                "meta_box": false,
                "taxonomy": fifuColumnVars.taxonomy,
                "from_slider": fromSlider,
            },
            async: true,
            beforeSend: function (xhr) {
                xhr.setRequestHeader("X-WP-Nonce", fifuColumnVars.nonce);
            },
            success: function (data) {
                if (data == null)
                    return;

                // clean preview
                const quickResponse = typeof data === 'string' ? JSON.parse(data) : data;
                const url = quickResponse && typeof quickResponse === 'object' ? quickResponse['local_url'] ?? '' : '';
                const dottedBorder = 'border-color: #ca4a1f !important; border: 2px; border-style: dotted; border-radius: 8px;';

                if (!fifuColumnVars.onCategoriesPage) {
                    if (fifuQuickEditVars.parent && fifuQuickEditVars.parent[pid]) {
                        fifuQuickEditVars.parent[pid]['image-url'] = url;
                        fifuQuickEditVars.parent[pid]['border'] = dottedBorder;
                    }
                }

                const thumbs = jQuery('div.fifu-quick[post-id="' + pid + '"]');
                thumbs.each(function () {
                    jQuery(this).attr('image-url', url);
                    jQuery(this).css('background-image', 'url("' + url + '")');
                    jQuery(this).css('color', '#ca4a1f');
                    jQuery(this).css('border', '2px');
                    jQuery(this).css('border-style', 'dotted');
                    jQuery(this).css('border-radius', '8px');
                });

                // clean lightbox
                jQuery('#fifu-quick-input-url').val('');
                jQuery('[id^=fifu_input_]').each(function () {
                    jQuery(this).val('');
                });
                jQuery('[id^=fifu-image-]').each(function () {
                    jQuery(this).css('background', '');
                    jQuery(this).css('opacity', '');
                });

                if (fromSlider && typeof fifu_clear_slider_after_local_upload === 'function') {
                    fifu_clear_slider_after_local_upload();
                }

                // clean json
                if (fifuColumnVars.onCategoriesPage) {
                    fifuQuickEditCtgrVars.terms[pid]['fifu_image_url'] = '';
                } else {
                    fifuQuickEditVars.posts[pid]['fifu_image_url'] = '';
                    fifuQuickEditVars.posts[pid]['fifu_image_urls'] = [];
                    fifuQuickEditVars.posts[pid]['fifu_image_alts'] = [];
                    if (fromSlider) {
                        fifuQuickEditVars.posts[pid]['fifu_slider_image_urls'] = [];
                        fifuQuickEditVars.posts[pid]['fifu_slider_image_alts'] = [];
                    }
                }

                fifu_update_quick_upload_button_visibility();
                jQuery.fancybox.close();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                const response = jqXHR && jqXHR.responseJSON ? jqXHR.responseJSON : {};
                const message = response.message || errorThrown || textStatus || 'FIFU Quick Edit could not save the media.';

                console.log(jqXHR);
                console.log(textStatus);
                console.log(errorThrown);

                alert(message);
            },
            complete: function (data) {
                fifuQuickUploadInFlight = false;
                fifu_set_quick_upload_processing_state(false);
            }
        });
    }, 100);
}

function fifu_register_help_quick_edit() {
    jQuery(document).on('click', '#fifu-quick-image-help', function () {
        jQuery.fancybox.open(`
            <div style="color:#1e1e1e;width:50%">
                <h1 style="background-color:whitesmoke;padding:20px;padding-left:0">${fifuColumnVars.txt_title_examples}</h1>                
                <h3>${fifuColumnVars.txt_title_keywords}</h3>
                <p style="background-color:#1e1e1e;color:white;padding:10px;border-radius:5px">sea,sun</p>
                <p>${fifuColumnVars.txt_desc_keywords}</p>
                <h3>${fifuColumnVars.txt_title_empty}</h3>
                <p style="background-color:#1e1e1e;color:white;padding:10px;border-radius:5px;height:40px"></p>
                <p>${fifuColumnVars.txt_desc_empty}</p>
            </div>`
                );
    });
}

// Function to dynamically load a script
function loadScriptWithJQuery(url, callback) {
    var script = jQuery('<script>', {type: 'text/javascript', src: url});
    script.on('load', callback);
    jQuery('head').append(script);
}

// Function to dynamically load a stylesheet
function loadStylesheetWithJQuery(url) {
    var link = jQuery('<link>', {rel: 'stylesheet', type: 'text/css', href: url});
    jQuery('head').append(link);
}

// Load resources when fancyBox is opened
jQuery(document).on('beforeShow.fb', function () {
    loadScriptWithJQuery(fifuColumnVars.convertUrlJs, function () {});
    loadStylesheetWithJQuery(fifuColumnVars.sortableCssUrl);
});
