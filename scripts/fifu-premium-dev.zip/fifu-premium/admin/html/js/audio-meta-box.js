function resetAudioPreview() {
    var $player = jQuery("#fifu_audio_player");
    $player.attr("src", "");
    if ($player.length && $player[0] && typeof $player[0].load === 'function') {
        $player[0].load();
    }

    jQuery("#fifu_audio_thumbnail_field").hide();
    jQuery("#fifu_audio_preview_wrapper").hide();
    jQuery("#fifu_audio_remove").hide();
    jQuery("#fifu_audio_button").show();
}

function removeAudio() {
    jQuery("#fifu_input_audio").val("");
    resetAudioPreview();
}

function previewAudio() {
    var $url = (jQuery("#fifu_input_audio").val() || '').trim();
    if (!$url) {
        resetAudioPreview();
        return;
    }

    var $player = jQuery("#fifu_audio_player");
    $player.attr("src", $url);
    if ($player.length && $player[0] && typeof $player[0].load === 'function') {
        $player[0].load();
    }

    jQuery("#fifu_audio_thumbnail_field").show();
    jQuery("#fifu_audio_preview_wrapper").show();
    jQuery("#fifu_audio_remove").show();
    jQuery("#fifu_audio_button").hide();
}

jQuery(document).ready(function () {
    jQuery("#fifu_input_audio").on('input', function () {
        resetAudioPreview();
    });

    jQuery("#fifu_input_audio").on('paste', function () {
        setTimeout(function () {
            previewAudio();
        }, 0);
    });

    let text = jQuery("div#audioMetaBox").find('h2').text();
    jQuery("div#audioMetaBox").find('h2.hndle').text('');
    jQuery("div#audioMetaBox").find('h2').append('<h4 style="left:-10px;position:relative;font-size:13px;font-weight:normal"><span class="dashicons dashicons-controls-volumeon"></span> ' + text + '</h4>');
    jQuery("div#audioMetaBox").find('button.handle-order-higher').remove();
    jQuery("div#audioMetaBox").find('button.handle-order-lower').remove();
});
