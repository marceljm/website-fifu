(function (root, factory) {
    const api = factory(root);
    root.FifuWooMixedGallery = api;
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = api;
    }
})(typeof window !== 'undefined' ? window : globalThis, function (root) {
    'use strict';

    function copyItem(item) {
        return Object.assign({
            id: '',
            slot: 0,
            type: 'image',
            url: '',
            alt: '',
            ifm: '',
            width: '',
            height: '',
            imageSrc: '',
            source: 'empty',
            nativeAttachmentId: 0,
            nativePreviewUrl: '',
            nativePreviewAlt: '',
            nativePreviewIfm: '',
        }, item || {});
    }

    function createEmptyItem(type, id) {
        return copyItem({
            id,
            type,
            source: 'empty',
            url: '',
        });
    }

    function isPopulatedGalleryItem(item) {
        const current = copyItem(item);
        const url = String(current.url || '').trim();
        if (current.type === 'video') return url !== '';
        if (current.type !== 'image') return false;
        if (current.source === 'native-preview') {
            return String(current.nativePreviewUrl || '').trim() !== ''
                || Number(current.nativeAttachmentId || 0) > 0;
        }
        return current.source === 'fifu' && url !== '';
    }

    function normalizeVisualSlotCapacity(capacity) {
        const numeric = Number(capacity);
        if (!Number.isFinite(numeric) || numeric < 3) return 3;
        return Math.max(3, Math.ceil((numeric + 1) / 4) * 4 - 1);
    }

    function getMinimumVisualSlotCapacity(itemsOrCount) {
        const count = Array.isArray(itemsOrCount)
            ? itemsOrCount.filter(isPopulatedGalleryItem).length
            : Math.max(0, Number(itemsOrCount) || 0);
        return Math.max(3, Math.ceil((count + 1) / 4) * 4 - 1);
    }

    function ensureVisualGridCapacity(items, slotCapacity, emptyType = 'image') {
        const source = Array.isArray(items) ? items.slice() : [];
        const minimum = getMinimumVisualSlotCapacity(source);
        const existing = normalizeVisualSlotCapacity(source.length);
        const requested = normalizeVisualSlotCapacity(slotCapacity);
        const capacity = Math.max(minimum, existing, requested);
        while (source.length < capacity) {
            source.push(createEmptyItem(emptyType, `mixed-empty-${source.length}`));
        }
        return {items: source, slotCapacity: capacity};
    }

    function expandVisualGridCapacity(items, slotCapacity, type, nextId) {
        const ensured = ensureVisualGridCapacity(items, slotCapacity, type);
        const id = `${type}-new-${nextId}`;
        const expanded = ensured.items.slice();
        expanded.push(createEmptyItem(type, id));
        for (let index = 0; index < 3; index += 1) {
            expanded.push(createEmptyItem(type, `${type}-empty-${nextId}-${index}`));
        }
        return {
            items: expanded,
            slotCapacity: ensured.slotCapacity + 4,
            newItemId: id,
        };
    }

    function normalize(items, selectedType, videoEnabled = true) {
        const source = [];
        (Array.isArray(items) ? items : []).forEach(item => {
            const copy = copyItem(item);
            if (copy.type === 'video') {
                if (videoEnabled) source.push(copy);
            } else {
                copy.type = 'image';
                source.push(copy);
            }
        });

        const populatedIndexes = source
            .map((item, index) => isPopulatedGalleryItem(item) ? index : -1)
            .filter(index => index >= 0);
        const populatedItems = populatedIndexes.map(index => source[index]);
        const imageItems = populatedItems.filter(item => item.type === 'image');
        const videoItems = populatedItems.filter(item => item.type === 'video');
        const prioritized = selectedType === 'video'
            ? videoItems.concat(imageItems)
            : imageItems.concat(videoItems);

        populatedIndexes.forEach((index, position) => {
            source[index] = prioritized[position];
        });
        return source;
    }

    function createInitialState(images, videos, selectedType, videoEnabled = true) {
        const imageItems = (Array.isArray(images) ? images : []).map((item, index) => copyItem(Object.assign({
            id: `image-${index}`,
            type: 'image',
            slot: index,
        }, item)));
        const videoItems = (Array.isArray(videos) ? videos : []).map((item, index) => copyItem(Object.assign({
            id: `video-${index}`,
            type: 'video',
            slot: index,
        }, item)));
        return {
            selectedType: selectedType === 'video' && videoEnabled ? 'video' : 'image',
            videoEnabled: !!videoEnabled,
            items: normalize(imageItems.concat(videoItems), selectedType, videoEnabled),
        };
    }

    function setPriority(items, selectedType, videoEnabled = true) {
        return normalize(items, selectedType, videoEnabled);
    }

    function isGalleryVisible(selectedType) {
        return selectedType === 'image' || selectedType === 'video';
    }

    function detectUrl(url, videoEnabled, functions) {
        const helpers = functions || {};
        const raw = String(url || '').trim();
        if (!raw) {
            return {accepted: true, type: 'empty', url: ''};
        }

        const isVideo = typeof helpers.isVideo === 'function'
            ? !!helpers.isVideo(raw)
            : false;
        if (isVideo) {
            if (!videoEnabled) {
                return {accepted: false, type: 'video', url: ''};
            }
            return {
                accepted: true,
                type: 'video',
                url: typeof helpers.convertVideo === 'function' ? helpers.convertVideo(raw) : raw,
            };
        }

        return {
            accepted: true,
            type: 'image',
            url: typeof helpers.convert === 'function' ? helpers.convert(raw) : raw,
        };
    }

    function changeItemType(item, url, videoEnabled, functions) {
        const result = detectUrl(url, videoEnabled, functions);
        if (!result.accepted) {
            return {accepted: false, item: copyItem(item), type: result.type};
        }

        if (
            result.type === 'image'
            && item
            && item.source === 'native-preview'
            && item.nativePreviewUrl
            && result.url === item.nativePreviewUrl
        ) {
            return {accepted: true, item: copyItem(item), type: 'image'};
        }

        const next = copyItem(item);
        if (result.type === 'empty') {
            next.url = '';
            if (next.source !== 'native-preview') {
                next.source = 'empty';
                next.alt = '';
                next.ifm = '';
                next.imageSrc = '';
            }
            return {accepted: true, item: next, type: next.type};
        }
        next.type = result.type;
        next.url = result.url;
        next.source = 'fifu';
        next.nativeAttachmentId = 0;
        next.nativePreviewUrl = '';
        next.nativePreviewAlt = '';
        next.nativePreviewIfm = '';
        if (result.type === 'video') {
            next.alt = '';
            next.ifm = '';
            next.width = '';
            next.height = '';
            next.imageSrc = '';
        } else {
            if (item && item.type !== 'image') {
                next.alt = '';
                next.ifm = '';
            }
            next.imageSrc = '';
            next.width = '';
            next.height = '';
        }
        return {accepted: true, item: next, type: result.type};
    }

    function persistPopup(item, values, videoEnabled, functions) {
        const fields = values || {};
        const result = changeItemType(item, fields.url, videoEnabled, functions);
        if (!result.accepted) {
            return result;
        }

        const hasUrl = String(fields.url || '').trim() !== '';
        if (result.item.type === 'image' && (hasUrl || result.item.source === 'native-preview')) {
            result.item.alt = fields.alt || '';
            result.item.ifm = fields.ifm || '';
        }

        return result;
    }

    function reorderWithinType(items, type, orderedIds) {
        const source = Array.isArray(items) ? items.slice() : [];
        const requested = Array.isArray(orderedIds) ? orderedIds : [];
        const matching = source.filter(item => item.type === type);
        const byId = new Map(matching.map(item => [item.id, item]));
        const reordered = [];
        requested.forEach(id => {
            if (byId.has(id)) {
                reordered.push(byId.get(id));
                byId.delete(id);
            }
        });
        matching.forEach(item => {
            if (byId.has(item.id)) reordered.push(item);
        });

        let index = 0;
        return source.map(item => item.type === type ? reordered[index++] : item);
    }

    function serialize(items, cleanupLengths) {
        const source = Array.isArray(items) ? items : [];
        const compactItems = type => source
            .filter(item => item.type === type && isPopulatedGalleryItem(item))
            .map((item, index) => Object.assign(copyItem(item), {slot: index}));
        const imageItems = compactItems('image');
        const videoItems = compactItems('video');
        const cleanup = cleanupLengths || {};
        const listIds = collection => collection
            .filter(item => item.source === 'fifu' && String(item.url || '').trim() !== '')
            .map(item => String(item.slot));

        return {
            images: imageItems,
            videos: videoItems,
            imageListIds: listIds(imageItems, 'image'),
            videoListIds: listIds(videoItems, 'video'),
            imageLength: Math.max(imageItems.length, Number(cleanup.image || 0)),
            videoLength: Math.max(videoItems.length, Number(cleanup.video || 0)),
        };
    }

    function escapeAttribute(value) {
        return String(value || '').replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }

    function adjustPreviewUrl(url) {
        if (!url) return '';
        return typeof root.fifu_cdn_adjust === 'function'
            ? root.fifu_cdn_adjust(url)
            : url;
    }

    function getTilePreviewUrl(item) {
        const current = copyItem(item);
        if (current.type === 'video') {
            return current.imageSrc || '';
        }
        return current.source === 'native-preview'
            ? current.nativePreviewUrl || ''
            : current.url || '';
    }

    function getTileVisualType(item) {
        const current = copyItem(item);
        if (current.type === 'video' && isPopulatedGalleryItem(current)) {
            return 'video';
        }
        return getTilePreviewUrl(current) ? current.type : 'image';
    }

    function getTileRenderState(item) {
        const preview = adjustPreviewUrl(getTilePreviewUrl(item));
        return {
            preview,
            background: preview ? `url("${preview}") center center / cover no-repeat` : '',
            opacity: preview ? '1' : '',
        };
    }

    const videoThumbnailStates = new WeakMap();

    function loadVideoThumbnail(item, requestThumbnail, onResolved) {
        if (!item || typeof item !== 'object' || item.type !== 'video' || !item.url) return null;
        if (item.imageSrc) {
            videoThumbnailStates.set(item, 'loaded');
            return null;
        }

        const state = videoThumbnailStates.get(item);
        if (state === 'pending' || state === 'loaded' || state === 'failed') return null;
        if (typeof requestThumbnail !== 'function') {
            videoThumbnailStates.set(item, 'failed');
            return null;
        }

        videoThumbnailStates.set(item, 'pending');
        const resolve = function (url) {
            const thumbnail = String(url || '').trim();
            if (!thumbnail) {
                videoThumbnailStates.set(item, 'failed');
                return '';
            }
            item.imageSrc = thumbnail;
            videoThumbnailStates.set(item, 'loaded');
            if (typeof onResolved === 'function') onResolved(item);
            return thumbnail;
        };
        const reject = function () {
            videoThumbnailStates.set(item, 'failed');
            return '';
        };

        let result;
        try {
            result = requestThumbnail(item);
        } catch (error) {
            reject();
            return null;
        }
        if (result && typeof result.then === 'function') {
            return result.then(resolve, reject);
        }
        resolve(result);
        return null;
    }

    function hasPopupValue(values, key) {
        return !!values && Object.prototype.hasOwnProperty.call(values, key);
    }

    function getPopupState(item, values, videoEnabled = true, functions) {
        const current = copyItem(item);
        const fields = values || {};
        const hasUrl = hasPopupValue(values, 'url');
        const inputUrl = hasUrl
            ? String(fields.url || '').trim()
            : String(current.source === 'native-preview' ? current.nativePreviewUrl : current.url || '').trim();
        const fallbackState = {
            accepted: true,
            type: inputUrl ? (current.type === 'video' ? 'video' : 'image') : 'empty',
            item: current,
            url: inputUrl,
            alt: hasPopupValue(values, 'alt') ? fields.alt || '' : current.alt || current.nativePreviewAlt || '',
            ifm: hasPopupValue(values, 'ifm') ? fields.ifm || '' : current.ifm || current.nativePreviewIfm || '',
        };

        if (!inputUrl) {
            return fallbackState;
        }

        if (!functions || typeof functions.isVideo !== 'function') {
            return fallbackState;
        }

        const result = changeItemType(current, inputUrl, videoEnabled, functions);
        if (!result.accepted) {
            return {
                accepted: false,
                type: 'empty',
                item: current,
                url: inputUrl,
                alt: '',
                ifm: '',
            };
        }

        return {
            accepted: true,
            type: result.item.type,
            item: result.item,
            url: inputUrl,
            alt: hasPopupValue(values, 'alt') ? fields.alt || '' : result.item.alt || result.item.nativePreviewAlt || '',
            ifm: hasPopupValue(values, 'ifm') ? fields.ifm || '' : result.item.ifm || result.item.nativePreviewIfm || '',
        };
    }

    function createPopupThumbnailPreview(item, options) {
        const config = options || {};
        const currentItem = copyItem(item);
        const videoEnabled = config.videoEnabled !== false;
        const functions = config.functions || {};
        const requestThumbnail = config.requestThumbnail;
        const onTileUpdate = typeof config.onTileUpdate === 'function'
            ? config.onTileUpdate
            : function () {};
        const thumbnails = new Map();
        const pendingRequests = new Map();
        let currentState = null;
        let pendingUrl = '';
        let generation = 0;

        if (currentItem.type === 'video' && currentItem.url && currentItem.imageSrc) {
            thumbnails.set(currentItem.url, currentItem.imageSrc);
        }

        function renderPreview(state, thumbnail) {
            let previewItem;
            if (state && state.type === 'empty') {
                previewItem = changeItemType(currentItem, '', videoEnabled, functions).item;
            } else {
                previewItem = copyItem(state && state.item);
                if (state && state.type === 'video') previewItem.imageSrc = thumbnail || '';
            }
            onTileUpdate(previewItem);
            return previewItem;
        }

        function isCurrentRequest(token, url) {
            return token === generation
                && currentState
                && currentState.type === 'video'
                && currentState.item.url === url;
        }

        function attachPendingRequest(request, url, token) {
            request.then(function (thumbnail) {
                const resolved = String(thumbnail || '').trim();
                if (resolved) thumbnails.set(url, resolved);
                if (!isCurrentRequest(token, url)) return;
                pendingUrl = '';
                if (resolved) renderPreview(currentState, resolved);
            }, function () {
                if (isCurrentRequest(token, url)) pendingUrl = '';
            });
        }

        function refresh(values) {
            const state = getPopupState(currentItem, values, videoEnabled, functions);
            const videoUrl = state.type === 'video' ? state.item.url : '';
            const samePendingRequest = state.type === 'video'
                && pendingUrl === videoUrl
                && currentState
                && currentState.type === 'video'
                && currentState.item.url === videoUrl;

            if (!samePendingRequest) generation += 1;
            currentState = state;

            if (state.type !== 'video') {
                pendingUrl = '';
                renderPreview(state, '');
                return state;
            }

            if (thumbnails.has(videoUrl)) {
                pendingUrl = '';
                renderPreview(state, thumbnails.get(videoUrl));
                return state;
            }

            if (pendingUrl === videoUrl) {
                renderPreview(state, '');
                return state;
            }

            pendingUrl = videoUrl;
            renderPreview(state, '');
            const token = generation;
            const pendingRequest = pendingRequests.get(videoUrl);
            if (pendingRequest) {
                attachPendingRequest(pendingRequest, videoUrl, token);
                return state;
            }

            let request;
            try {
                request = Promise.resolve(
                    typeof requestThumbnail === 'function' ? requestThumbnail(videoUrl) : ''
                );
            } catch (error) {
                request = Promise.reject(error);
            }
            pendingRequests.set(videoUrl, request);
            request.then(function () {
                if (pendingRequests.get(videoUrl) === request) pendingRequests.delete(videoUrl);
            }, function () {
                if (pendingRequests.get(videoUrl) === request) pendingRequests.delete(videoUrl);
            });
            attachPendingRequest(request, videoUrl, token);

            return state;
        }

        return {
            refresh,
            getResolvedThumbnail: function (url) {
                return thumbnails.get(String(url || '').trim()) || '';
            },
        };
    }

    function createPopupSections(state, labels) {
        const current = copyItem(state && state.item);
        const text = labels || {};
        let preview = '';
        let imageFields = '';

        if (state && state.type === 'video' && current.url) {
            const videoSource = typeof root.srcVideo === 'function'
                ? root.srcVideo(current.url)
                : current.url;
            if (videoSource) {
                preview = `<span id="fifu-mixed-video-preview"><iframe class="fifu-featured-media-mixed-preview-video" width="100%" height="155" src="${escapeAttribute(videoSource)}" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen frameborder="0"></iframe></span>`;
            }
        }

        if (state && state.type === 'image') {
            const imagePreviewUrl = current.source === 'native-preview'
                ? current.nativePreviewUrl
                : current.url;
            if (imagePreviewUrl) {
                preview = `<span id="fifu-mixed-image-preview"><img class="fifu-featured-media-mixed-preview-image" loading="lazy" src="${escapeAttribute(adjustPreviewUrl(imagePreviewUrl))}" alt=""></span>`;
            }
            imageFields = `
                <div class="fifu-featured-media-icon-input fifu-featured-media-slider-input fifu-featured-media-mixed-input">
                    <span class="dashicons dashicons-media-text" aria-hidden="true"></span>
                    <input class="fifu-featured-media-mixed-field" id="fifu-mixed-alt" placeholder="${escapeAttribute(text.text_alt || 'Alternative text')}" value="${escapeAttribute(state.alt || '')}">
                </div>
                <div class="fifu-featured-media-icon-input fifu-featured-media-slider-input fifu-featured-media-mixed-input">
                    <span class="dashicons dashicons-editor-code" aria-hidden="true"></span>
                    <input class="fifu-featured-media-mixed-field" id="fifu-mixed-ifm" placeholder="${escapeAttribute(text.text_ifm || 'Iframe URL')}" value="${escapeAttribute(state.ifm || '')}">
                </div>`;
        }

        return {preview, imageFields};
    }

    function createPopupMarkup(item, labels, options) {
        const config = options || {};
        const current = copyItem(item);
        const text = labels || {};
        const state = getPopupState(
            current,
            config.values,
            config.videoEnabled !== false,
            config.functions
        );
        const sections = createPopupSections(state, text);
        const url = hasPopupValue(config.values, 'url')
            ? config.values.url || ''
            : current.source === 'native-preview' ? '' : current.url || '';
        const label = text.text_image_video_url
            || 'Image/Video URL';

        return `
            <div class="fifu-featured-media-slider-popup fifu-featured-media-mixed-popup">
                <div class="fifu-featured-media-icon-input fifu-featured-media-slider-input fifu-featured-media-mixed-input">
                    <span class="dashicons dashicons-admin-media" aria-hidden="true"></span>
                    <input class="fifu-featured-media-mixed-field" id="fifu-mixed-url" placeholder="${escapeAttribute(label)}" value="${escapeAttribute(url)}">
                </div>
                <div id="fifu-mixed-preview-region">${sections.preview}</div>
                <div id="fifu-mixed-image-fields">${sections.imageFields}</div>
            </div>`;
    }

    const api = {
        normalize,
        createInitialState,
        setPriority,
        isPopulatedGalleryItem,
        isGalleryVisible,
        detectUrl,
        changeItemType,
        persistPopup,
        getPopupState,
        createPopupSections,
        createPopupMarkup,
        createPopupThumbnailPreview,
        getTilePreviewUrl,
        getTileVisualType,
        getTileRenderState,
        loadVideoThumbnail,
        getMinimumVisualSlotCapacity,
        ensureVisualGridCapacity,
        expandVisualGridCapacity,
        reorderWithinType,
        serialize,
        removeItem: function () { return false; },
        initialize: function () { return false; },
        destroy: function () {},
        clear: function () {},
    };

    if (typeof root.jQuery === 'undefined' || typeof root.document === 'undefined') {
        return api;
    }

    let controllerState = null;
    let pendingPriority = null;
    let controllerGrid = null;
    let controllerSubmitTarget = null;
    let controllerVars = null;
    let controllerSortableInitialized = false;

    function helperFunctions() {
        return {
            isVideo: typeof root.fifu_is_video === 'function' ? root.fifu_is_video : null,
            convert: typeof root.fifu_convert === 'function' ? root.fifu_convert : null,
            convertVideo: typeof root.fifu_convert_video === 'function' ? root.fifu_convert_video : null,
        };
    }

    function setItemSlots() {
        const counters = {image: 0, video: 0};
        controllerState.items.forEach(item => {
            item.slot = counters[item.type]++;
        });
    }

    function setInput(container, name, value) {
        const input = root.document.createElement('input');
        input.type = 'hidden';
        input.id = name;
        input.name = name;
        input.value = value === undefined || value === null ? '' : String(value);
        container.appendChild(input);
    }

    function updateSerializedFields() {
        if (!controllerState) return;
        setItemSlots();
        renderHiddenFields(serialize(controllerState.items, controllerState.cleanupLengths));
    }

    function loadImageDimensions(item, imageUrl) {
        if (!imageUrl || typeof root.Image !== 'function') return;
        const image = new root.Image();
        image.onload = function () {
            item.width = image.naturalWidth || image.width || '';
            item.height = image.naturalHeight || image.height || '';
            updateSerializedFields();
        };
        image.src = imageUrl;
    }

    function loadVideoDimensions(item) {
        if (!item.url) return;
        if (item.imageSrc) {
            loadImageDimensions(item, item.imageSrc);
            return;
        }
        if (typeof root.fifu_video_image_thumbnail !== 'function') return;
        loadVideoThumbnail(
            item,
            current => root.fifu_video_image_thumbnail(current.url, controllerVars || root.fifuMixedGalleryVars || {}),
            function (updatedItem) {
                refreshTileForItem(updatedItem);
                loadImageDimensions(updatedItem, updatedItem.imageSrc);
                updateSerializedFields();
            }
        );
    }

    function renderHiddenFields(serialized) {
        const imageContainer = root.document.getElementById('inputHiddenMixedImages');
        const videoContainer = root.document.getElementById('inputHiddenMixedVideos');
        if (!imageContainer || !videoContainer) return;
        imageContainer.innerHTML = '';
        videoContainer.innerHTML = '';

        serialized.images.forEach(item => {
            const index = item.slot;
            setInput(imageContainer, `fifu_input_width_${index}`, item.width);
            setInput(imageContainer, `fifu_input_height_${index}`, item.height);
            setInput(imageContainer, `fifu_input_url_${index}`, item.url);
            setInput(imageContainer, `fifu_input_alt_${index}`, item.source === 'native-preview' ? item.nativePreviewAlt : item.alt);
            setInput(imageContainer, `fifu_input_ifm_${index}`, item.source === 'native-preview' ? item.nativePreviewIfm : item.ifm);
            setInput(imageContainer, `fifu_input_source_${index}`, item.source);
            setInput(imageContainer, `fifu_input_native_attachment_id_${index}`, item.source === 'native-preview' ? item.nativeAttachmentId : 0);
        });
        serialized.videos.forEach(item => {
            const index = item.slot;
            setInput(videoContainer, `fifu_video_input_width_${index}`, item.width);
            setInput(videoContainer, `fifu_video_input_height_${index}`, item.height);
            setInput(videoContainer, `fifu_video_input_url_${index}`, item.url);
            setInput(videoContainer, `fifu_video_input_image_src_${index}`, item.imageSrc);
        });

        const imageList = root.document.getElementById('inputHiddenImageListIds');
        const imageLength = root.document.getElementById('inputHiddenImageLength');
        const videoList = root.document.getElementById('inputHiddenVideoListIds');
        const videoLength = root.document.getElementById('inputHiddenVideoLength');
        if (imageList) imageList.value = serialized.imageListIds.join('|');
        if (imageLength) imageLength.value = serialized.imageLength;
        if (videoList) videoList.value = serialized.videoListIds.join('|');
        if (videoLength) videoLength.value = serialized.videoLength;
    }

    function renderTile(tile, item) {
        tile.id = item.id;
        tile.className = `fifu-mixed-gallery-tile grid-square ${getTileVisualType(item)}`;
        tile.dataset.fifuSource = item.source || 'empty';
        tile.dataset.fifuType = item.type;
        tile.dataset.fifuItemId = item.id;
        const tileState = getTileRenderState(item);
        tile.style.background = tileState.background;
        tile.style.opacity = tileState.opacity;
        tile.setAttribute('aria-label', item.type === 'video' ? 'Video' : 'Image');

        if (item.source === 'fifu' && isPopulatedGalleryItem(item)) {
            const labels = controllerVars || root.fifuMixedGalleryVars || {};
            const label = item.type === 'video'
                ? String(labels.text_remove_video || labels.text_remove_slider_item || '')
                : String(labels.text_remove_image || '');
            const remove = root.document.createElement('button');
            remove.type = 'button';
            remove.className = 'fifu-featured-media-remove';
            remove.setAttribute('aria-label', label);
            remove.setAttribute('title', label);
            remove.innerHTML = '<span class="dashicons dashicons-no-alt" aria-hidden="true"></span>';
            remove.addEventListener('click', function (event) {
                event.preventDefault();
                event.stopPropagation();
                event.stopImmediatePropagation();
                removeItem(item.id);
            });
            tile.appendChild(remove);
        }
    }

    function removeItem(itemId) {
        if (!controllerState) return false;
        const index = controllerState.items.findIndex(item => item.id === itemId);
        if (index < 0) return false;
        const current = controllerState.items[index];
        if (current.source !== 'fifu' || !isPopulatedGalleryItem(current)) return false;

        controllerState.items[index] = createEmptyItem(current.type, current.id);
        controllerState.dragging = false;
        render();
        return true;
    }

    function refreshTileForItem(item) {
        if (!controllerState) return;
        const grid = controllerGrid || root.document.getElementById('fifuMixedGallery');
        if (!grid) return;
        const tile = Array.from(grid.children).find(candidate => (
            candidate.dataset && candidate.dataset.fifuItemId === item.id
        ));
        if (tile) renderTile(tile, item);
    }

    function openItemEditor(item) {
        if (!root.jQuery.fancybox || typeof root.jQuery.fancybox.open !== 'function') return;
        const labels = controllerVars || root.fifuMixedGalleryVars || {};
        const options = {
            videoEnabled: controllerState.videoEnabled,
            functions: helperFunctions(),
        };
        const popupValues = {
            url: item.source === 'native-preview' ? '' : item.url || '',
            alt: item.alt || item.nativePreviewAlt || '',
            ifm: item.ifm || item.nativePreviewIfm || '',
        };
        const popupThumbnail = createPopupThumbnailPreview(item, {
            videoEnabled: options.videoEnabled,
            functions: options.functions,
            requestThumbnail: typeof root.fifu_video_image_thumbnail === 'function'
                ? url => root.fifu_video_image_thumbnail(url, controllerVars || root.fifuMixedGalleryVars || {})
                : null,
            onTileUpdate: refreshTileForItem,
        });
        const capturePopupValues = function () {
            const url = root.jQuery('#fifu-mixed-url');
            const alt = root.jQuery('#fifu-mixed-alt');
            const ifm = root.jQuery('#fifu-mixed-ifm');
            if (url.length) popupValues.url = url.val() || '';
            if (alt.length) popupValues.alt = alt.val() || '';
            if (ifm.length) popupValues.ifm = ifm.val() || '';
        };
        const refreshPopup = function () {
            capturePopupValues();
            const state = popupThumbnail.refresh(popupValues);
            const sections = createPopupSections(state, labels);
            root.jQuery('#fifu-mixed-preview-region').html(sections.preview);
            root.jQuery('#fifu-mixed-image-fields').html(sections.imageFields);
        };

        root.jQuery.fancybox.open(createPopupMarkup(item, labels, options), {
            beforeClose: function () {
                capturePopupValues();
                return fifu_persist_mixed_popup(item, popupValues, popupThumbnail);
            },
        });
        root.jQuery('#fifu-mixed-url')
            .on('input.fifuMixedPopup', refreshPopup)
            .on('keydown.fifuMixedPopup', function (event) {
                if (event.key !== 'Enter' && event.keyCode !== 13 && event.which !== 13) return;
                event.preventDefault();
                root.jQuery.fancybox.close();
            });
        root.jQuery('#fifu-mixed-url').focus();
        root.jQuery('#fifu-mixed-url').select();
    }

    function fifu_persist_mixed_popup(item, values, popupThumbnail) {
        if (!controllerState) return true;

        const result = persistPopup(item, values || {
            url: root.jQuery('#fifu-mixed-url').val(),
            alt: root.jQuery('#fifu-mixed-alt').val(),
            ifm: root.jQuery('#fifu-mixed-ifm').val(),
        }, controllerState.videoEnabled, helperFunctions());
        if (!result.accepted) {
            if (typeof root.alert === 'function') root.alert('This video cannot be added while video support is disabled.');
            return false;
        }

        if (result.item.type === 'video' && popupThumbnail) {
            const thumbnail = popupThumbnail.getResolvedThumbnail(result.item.url);
            if (thumbnail) result.item.imageSrc = thumbnail;
        }

        const itemIndex = controllerState.items.findIndex(candidate => candidate.id === item.id);
        if (itemIndex >= 0) controllerState.items[itemIndex] = result.item;
        controllerState.items = setPriority(
            controllerState.items,
            controllerState.selectedType,
            controllerState.videoEnabled
        );
        render();
        return true;
    }

    function render() {
        if (!controllerState) return;
        const grid = controllerGrid || root.document.getElementById('fifuMixedGallery');
        if (!grid) return;
        const ensured = ensureVisualGridCapacity(
            controllerState.items,
            controllerState.slotCapacity,
            controllerState.selectedType
        );
        controllerState.items = ensured.items;
        controllerState.slotCapacity = ensured.slotCapacity;
        setItemSlots();
        grid.innerHTML = '';
        controllerState.items.forEach(item => {
            const tile = root.document.createElement('div');
            renderTile(tile, item);
            tile.addEventListener('click', function (event) {
                event.stopPropagation();
                if (controllerState.dragging) {
                    controllerState.dragging = false;
                    return;
                }
                openItemEditor(item);
            });
            grid.appendChild(tile);
        });

        const add = root.document.createElement('div');
        add.id = 'fifu-mixed-add-media';
        add.className = 'grid-square image-add fifu-mixed-gallery-add';
        add.setAttribute('role', 'button');
        add.setAttribute('tabindex', '0');
        add.setAttribute('aria-label', 'Add Media');
        add.addEventListener('click', function (event) {
            event.stopPropagation();
            const type = controllerState.selectedType === 'video' && controllerState.videoEnabled
                ? 'video'
                : 'image';
            const expanded = expandVisualGridCapacity(
                controllerState.items,
                controllerState.slotCapacity,
                type,
                controllerState.nextId++
            );
            const id = expanded.newItemId;
            controllerState.items = expanded.items;
            controllerState.slotCapacity = expanded.slotCapacity;
            controllerState.items = setPriority(controllerState.items, controllerState.selectedType, controllerState.videoEnabled);
            render();
            const added = controllerState.items.find(item => item.id === id);
            if (added) openItemEditor(added);
        });
        grid.appendChild(add);

        const serialized = serialize(controllerState.items, controllerState.cleanupLengths);
        renderHiddenFields(serialized);
        controllerState.items.forEach(item => {
            if (item.source !== 'fifu' || !item.url) return;
            if (item.type === 'video') {
                loadVideoDimensions(item);
            } else {
                loadImageDimensions(item, item.url);
            }
        });
        refreshSortableAfterRender(grid);
    }

    function reorderAfterSort() {
        if (!controllerState) return;
        const grid = controllerGrid || root.document.getElementById('fifuMixedGallery');
        if (!grid) return;
        const byId = new Map(controllerState.items.map(item => [item.id, item]));
        const ordered = Array.from(grid.children)
            .map(tile => byId.get(tile.dataset.fifuItemId))
            .filter(Boolean);
        controllerState.items = setPriority(ordered, controllerState.selectedType, controllerState.videoEnabled);
        controllerState.dragging = true;
        render();
    }

    function destroy() {
        if (controllerSortableInitialized && controllerGrid) {
            root.jQuery(controllerGrid).sortable('destroy');
        }
        if (controllerSubmitTarget) {
            root.jQuery(controllerSubmitTarget).off('submit.fifuMixedGallery');
        }
        controllerState = null;
        controllerGrid = null;
        controllerSubmitTarget = null;
        controllerVars = null;
        controllerSortableInitialized = false;
        pendingPriority = null;
    }

    function clear() {
        if (!controllerState) return false;
        controllerState.items = [];
        controllerState.slotCapacity = 0;
        controllerState.nextId = 0;
        controllerState.dragging = false;
        render();
        return true;
    }

    function createSortableTileHelper(event, item) {
        const source = item && item[0];
        if (!source || typeof source.cloneNode !== 'function') {
            return source;
        }

        const rect = typeof source.getBoundingClientRect === 'function'
            ? source.getBoundingClientRect()
            : {};
        const width = Math.round(rect.width || source.offsetWidth || 0);
        const height = Math.round(rect.height || source.offsetHeight || 0);
        const helper = source.cloneNode(true);
        if (helper.classList && typeof helper.classList.add === 'function') {
            helper.classList.add('fifu-mixed-gallery-sortable-helper');
        }
        if (typeof helper.removeAttribute === 'function') {
            helper.removeAttribute('id');
        }
        if (!width || !height || !helper.style || typeof helper.style.setProperty !== 'function') {
            return helper;
        }

        helper.style.setProperty('width', `${width}px`, 'important');
        helper.style.setProperty('max-width', `${width}px`, 'important');
        helper.style.setProperty('height', `${height}px`, 'important');
        return helper;
    }

    function lockSortablePlaceholder(ui) {
        const helper = ui && ui.helper && ui.helper[0];
        const placeholder = ui && ui.placeholder && ui.placeholder[0];
        if (!helper || !placeholder || !placeholder.style || typeof placeholder.style.setProperty !== 'function') {
            return;
        }

        const width = helper.style && helper.style.width;
        const height = helper.style && helper.style.height;
        if (!width || !height) {
            return;
        }

        placeholder.style.setProperty('width', width, 'important');
        placeholder.style.setProperty('max-width', width, 'important');
        placeholder.style.setProperty('height', height, 'important');
    }

    function clearSortableTileDimensions(ui) {
        [ui && ui.helper, ui && ui.placeholder, ui && ui.item].forEach(function (target) {
            const element = target && target[0];
            if (!element || !element.style || typeof element.style.removeProperty !== 'function') {
                return;
            }
            element.style.removeProperty('width');
            element.style.removeProperty('max-width');
            element.style.removeProperty('height');
        });
    }

    function refreshSortableAfterRender(grid) {
        if (
            !grid
            || !controllerSortableInitialized
            || !grid.classList
            || !grid.classList.contains('ui-sortable')
        ) {
            return;
        }

        root.jQuery(grid).sortable('refresh');
    }

    function refreshSortable() {
        refreshSortableAfterRender(
            controllerGrid || root.document.getElementById('fifuMixedGallery')
        );
    }

    function initialize(options) {
        const config = options || {};
        const vars = config.vars || root.fifuMixedGalleryVars || {};
        const grid = config.grid || root.document.getElementById('fifuMixedGallery');
        if (!grid) return false;

        const selectedType = pendingPriority || vars.selectedType || 'image';
        destroy();
        controllerVars = vars;
        controllerGrid = grid;
        const initial = createInitialState(vars.images || [], vars.videos || [], selectedType, vars.videoEnabled !== false);
        const populatedItems = initial.items.filter(isPopulatedGalleryItem);
        const counts = {
            image: populatedItems.filter(item => item.type === 'image').length,
            video: populatedItems.filter(item => item.type === 'video').length,
        };
        const initialGrid = ensureVisualGridCapacity(
            setPriority(populatedItems, initial.selectedType, initial.videoEnabled),
            0,
            initial.selectedType
        );
        controllerState = {
            items: initialGrid.items,
            slotCapacity: initialGrid.slotCapacity,
            selectedType: initial.selectedType,
            videoEnabled: initial.videoEnabled,
            cleanupLengths: {
                image: counts.image,
                video: counts.video,
            },
            nextId: 0,
            dragging: false,
        };
        pendingPriority = null;
        root.fifuMixedGallerySetPriority(controllerState.selectedType);
        const sortableOptions = {
            items: '> .fifu-mixed-gallery-tile',
            cancel: '.fifu-featured-media-remove',
            helper: createSortableTileHelper,
            start: function (event, ui) {
                controllerState.dragging = false;
                lockSortablePlaceholder(ui);
            },
            stop: function (event, ui) {
                clearSortableTileDimensions(ui);
                reorderAfterSort();
            },
        };
        if (config.sortableAppendTo) {
            sortableOptions.appendTo = config.sortableAppendTo;
        }
        if (config.sortableZIndex != null) {
            sortableOptions.zIndex = config.sortableZIndex;
        }
        root.jQuery(grid).sortable(sortableOptions);
        controllerSortableInitialized = true;
        const submitTarget = config.form === false
            ? null
            : (config.form || root.document.getElementById('post'));
        if (submitTarget) {
            controllerSubmitTarget = submitTarget;
            root.jQuery(submitTarget).off('submit.fifuMixedGallery').on('submit.fifuMixedGallery', render);
        }
        render();
        return true;
    }

    api.initialize = initialize;
    api.destroy = destroy;
    api.clear = clear;
    api.removeItem = removeItem;
    api.refreshSortable = refreshSortable;

    root.fifuMixedGallerySetPriority = function (selectedType) {
        const priority = selectedType === 'video' && (!controllerState || controllerState.videoEnabled)
            ? 'video'
            : 'image';
        if (!controllerState) {
            pendingPriority = priority;
            return;
        }
        controllerState.selectedType = priority;
        controllerState.items = setPriority(controllerState.items, priority, controllerState.videoEnabled);
        render();
    };

    root.jQuery(root.document).ready(initialize);
    return api;
});
