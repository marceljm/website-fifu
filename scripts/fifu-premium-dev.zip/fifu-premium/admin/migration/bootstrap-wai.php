<?php

if (!defined('ABSPATH')) {
    exit;
}

$service_file = FIFU_INCLUDES_DIR . '/meta/class-fifu-wai-meta-service.php';

if (file_exists($service_file)) {
    require_once $service_file;
}

if (class_exists('Fifu_Wai_Meta_Service')) {
    add_action(
        'pmxi_before_xml_import',
        [ Fifu_Wai_Meta_Service::class, 'handle_before_xml_import' ],
        10,
        1
    );
}
