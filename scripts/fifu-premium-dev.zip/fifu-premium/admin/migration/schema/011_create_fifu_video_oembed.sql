CREATE TABLE IF NOT EXISTS {PREFIX}fifu_video_oembed (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    video_url VARCHAR(255) NOT NULL,
    image_url VARCHAR(255) NOT NULL,
    embed_url VARCHAR(255) NOT NULL,
    UNIQUE KEY video_url (video_url),
    INDEX index_fifu_video_oembed_image_url (image_url) USING HASH,
    INDEX index_fifu_video_oembed_embed_url (embed_url) USING HASH
) ENGINE=InnoDB {CHARSET_COLLATE};
