<?php
declare( strict_types=1 );

/**
 * Handles migration of the legacy FIFU video URL metadata.
 */
class Fifu_Mig_Video implements Fifu_Migration_Task_Interface {

    /** @var wpdb */
    protected $wpdb;

    /** @var Fifu_Migration_State */
    protected $state;

    /** @var Fifu_Migration_Logger */
    protected $logger;

    /** @var string */
    protected $meta_key = 'fifu_video_url';

    /** @var string */
    protected $table_postmeta;

    /** @var string */
    protected $table_fifu_url;

    /** @var string */
    protected $table_fifu_key;

    /** @var string */
    protected $table_fifu_map;

    /** @var int|null */
    protected $video_key_id = null;

    /**
     * @param wpdb|null                 $wpdb
     * @param Fifu_Migration_State|null $state
     * @param Fifu_Migration_Logger|null $logger
     */
    public function __construct( ?wpdb $wpdb = null, ?Fifu_Migration_State $state = null, ?Fifu_Migration_Logger $logger = null ) {
        if ( null === $wpdb ) {
            global $wpdb; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
            $this->wpdb = $wpdb;
        } else {
            $this->wpdb = $wpdb;
        }

        $this->state  = $state  ?? new Fifu_Migration_State();
        $this->logger = $logger ?? new Fifu_Migration_Logger();

        $this->table_postmeta = $this->wpdb->postmeta;
        $this->table_fifu_url = $this->wpdb->prefix . 'fifu_url';
        $this->table_fifu_key = $this->wpdb->prefix . 'fifu_key';
        $this->table_fifu_map = $this->wpdb->prefix . 'fifu_map';
    }

    /**
     * {@inheritdoc}
     */
    public function get_name(): string {
        return 'video';
    }

    /**
     * {@inheritdoc}
     */
    public function get_label(): string {
        return 'Video URL migration';
    }

    /**
     * {@inheritdoc}
     */
    public function run_batch( int $limit, int $time_limit_seconds ): void {
        $limit              = max( 100, $limit );
        $time_limit_seconds = max( 10, $time_limit_seconds );

        $state   = $this->state->get_task_state( $this->get_name() );
        $last_id = isset( $state['last_id'] ) ? (int) $state['last_id'] : 0;

        $this->logger->info( 'Starting video batch.', array(
            'limit'      => $limit,
            'time_limit' => $time_limit_seconds,
            'last_id'    => $last_id,
        ) );

        $this->video_key_id = $this->get_video_key_id();
        if ( null === $this->video_key_id ) {
            $this->logger->error( 'Missing "video" key, cannot proceed with video migration.' );
            return;
        }

        $query = $this->wpdb->prepare(
            "SELECT meta_id, post_id, meta_value AS url FROM {$this->table_postmeta} WHERE meta_id > %d AND meta_key = %s ORDER BY meta_id ASC LIMIT %d",
            $last_id,
            $this->meta_key,
            $limit
        );

        $rows = $this->wpdb->get_results( $query, ARRAY_A );
        if ( false === $rows ) {
            $this->logger->error( 'Failed to fetch legacy video meta rows.' );
            return;
        }

        if ( empty( $rows ) ) {
            $this->logger->info( 'No legacy video URLs found, marking task as finished.' );
            $this->state->update_task_state( $this->get_name(), array( 'status' => 'finished' ) );
            return;
        }

        $processed_in_batch     = 0;
        $error_count_in_batch   = 0;
        $last_meta_id_in_batch  = $last_id;
        $start_time             = microtime( true );
        $rows_count             = count( $rows );

        foreach ( $rows as $row ) {
            if ( microtime( true ) - $start_time >= $time_limit_seconds ) {
                break;
            }

            $meta_id = isset( $row['meta_id'] ) ? (int) $row['meta_id'] : 0;
            $post_id = isset( $row['post_id'] ) ? (int) $row['post_id'] : 0;
            $url = Fifu_Db2_Normalizer::normalize_url( isset( $row['url'] ) ? (string) $row['url'] : null );

            if ( null === $url ) {
                $last_meta_id_in_batch = $meta_id;
                continue;
            }

            $hash = md5( $url );

            if ( ! $this->insert_url_if_not_exists( $hash, $url ) ) {
                $error_count_in_batch++;
                $last_meta_id_in_batch = $meta_id;
                continue;
            }

            if ( ! $this->upsert_map( $post_id, $this->video_key_id, 0, $hash ) ) {
                $error_count_in_batch++;
                $last_meta_id_in_batch = $meta_id;
                continue;
            }

            $this->delete_legacy_postmeta_row( $meta_id );

            $processed_in_batch++;
            $last_meta_id_in_batch = $meta_id;
        }

        $current_state   = $this->state->get_task_state( $this->get_name() );
        $total_processed = (int) ( $current_state['processed_count'] ?? 0 ) + $processed_in_batch;
        $total_errors    = (int) ( $current_state['error_count'] ?? 0 ) + $error_count_in_batch;
        $status          = 'running';

        if ( 0 === $processed_in_batch && $rows_count < $limit ) {
            $status = 'finished';
        }

        $this->state->update_task_state( $this->get_name(), array(
            'status'          => $status,
            'processed_count' => $total_processed,
            'error_count'     => $total_errors,
            'last_id'         => $last_meta_id_in_batch,
        ) );

        $this->logger->info( 'Finished video batch.', array(
            'processed' => $processed_in_batch,
            'errors'    => $error_count_in_batch,
            'last_id'   => $last_meta_id_in_batch,
            'status'    => $status,
        ) );
    }

    /**
     * {@inheritdoc}
     */
    public function is_finished(): bool {
        $state = $this->state->get_task_state( $this->get_name() );

        return isset( $state['status'] ) && 'finished' === $state['status'];
    }

    /**
     * Retrieves the video key ID from the schema table.
     */
    protected function get_video_key_id(): ?int {
        $query = $this->wpdb->prepare(
            "SELECT key_id FROM {$this->table_fifu_key} WHERE key_type = %s LIMIT 1",
            'video'
        );

        $key_id = $this->wpdb->get_var( $query );

        if ( null === $key_id ) {
            return null;
        }

        return (int) $key_id;
    }

    /**
     * Inserts a URL record only if it does not already exist.
     */
    protected function insert_url_if_not_exists( string $hash, string $url ): bool {
        $query = $this->wpdb->prepare(
            "INSERT IGNORE INTO {$this->table_fifu_url} (hash, url) VALUES (%s, %s)",
            $hash,
            $url
        );

        $result = $this->wpdb->query( $query );

        if ( false === $result ) {
            $this->logger->error( 'Failed to insert URL record.', array( 'hash' => $hash ) );
            return false;
        }

        return true;
    }

    /**
     * Inserts or updates the mapping between post/key and URL.
     */
    protected function upsert_map( int $post_id, int $key_id, int $key_index, string $hash ): bool {
        $query = $this->wpdb->prepare(
            "INSERT INTO {$this->table_fifu_map} (post_id, key_id, key_index, hash) VALUES (%d, %d, %d, %s) ON DUPLICATE KEY UPDATE hash = VALUES(hash)",
            $post_id,
            $key_id,
            $key_index,
            $hash
        );

        $result = $this->wpdb->query( $query );

        if ( false === $result ) {
            $this->logger->error( 'Failed to upsert video map.', array(
                'post_id' => $post_id,
                'hash'    => $hash,
            ) );
            return false;
        }

        return true;
    }

    /**
     * @param int $meta_id
     * @return void
     */
    protected function delete_legacy_postmeta_row( int $meta_id ): void {
        if ( $meta_id <= 0 ) {
            return;
        }

        $this->wpdb->query(
            $this->wpdb->prepare(
                "DELETE FROM {$this->table_postmeta} WHERE meta_id = %d",
                $meta_id
            )
        );
    }
}
