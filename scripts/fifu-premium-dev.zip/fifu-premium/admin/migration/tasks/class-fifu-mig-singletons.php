<?php
declare( strict_types=1 );

/**
 * Handles migration of legacy FIFU singleton metadata (finder/redirection/audio).
 */
class Fifu_Mig_Singletons implements Fifu_Migration_Task_Interface {
    private const META_KEY_TO_DB2_KEY_TYPE = array(
        'fifu_finder_url'      => 'finder',
        'fifu_redirection_url' => 'redirect',
        'fifu_audio_url'       => 'audio',
    );

    /** @var wpdb */
    protected $wpdb;

    /** @var Fifu_Migration_State */
    protected $state;

    /** @var Fifu_Migration_Logger */
    protected $logger;

    /** @var string */
    protected $table_postmeta;

    /** @var array<string> */
    protected $meta_keys = array(
        'fifu_finder_url',
        'fifu_redirection_url',
        'fifu_audio_url',
    );

    /**
     * @param wpdb|null                $wpdb
     * @param Fifu_Migration_State|null $state
     * @param Fifu_Migration_Logger|null $logger
     */
    public function __construct( ?wpdb $wpdb = null, ?Fifu_Migration_State $state = null, ?Fifu_Migration_Logger $logger = null ) {
        if ( $wpdb === null ) {
            global $wpdb; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
            $this->wpdb = $wpdb;
        } else {
            $this->wpdb = $wpdb;
        }

        $this->state  = $state  ?? new Fifu_Migration_State();
        $this->logger = $logger ?? new Fifu_Migration_Logger();

        $this->table_postmeta = $this->wpdb->postmeta;
    }

    /**
     * {@inheritdoc}
     */
    public function get_name(): string {
        return 'singletons';
    }

    /**
     * {@inheritdoc}
     */
    public function get_label(): string {
        return 'Finder/Redirect/Audio migration';
    }

    /**
     * {@inheritdoc}
     */
    public function run_batch( int $limit, int $time_limit_seconds ): void {
        $limit              = max( 1, $limit );
        $time_limit_seconds = max( 1, $time_limit_seconds );

        $state   = $this->state->get_task_state( $this->get_name() );
        $last_id = isset( $state['last_id'] ) ? (int) $state['last_id'] : 0;

        $this->logger->info( 'Starting singleton metadata batch.', array(
            'limit'      => $limit,
            'time_limit' => $time_limit_seconds,
            'last_id'    => $last_id,
        ) );

        $bridge = $this->get_legacy_bridge();
        if ( $bridge === null ) {
            $this->logger->error( 'Missing DB2 legacy write bridge, cannot migrate singleton metadata.' );
            return;
        }

        $placeholders = implode( ', ', array_fill( 0, count( $this->meta_keys ), '%s' ) );
        $args = array_merge(
            array( $last_id ),
            $this->meta_keys,
            array( $limit )
        );

        $query = $this->wpdb->prepare(
            "SELECT meta_id, post_id, meta_key, meta_value AS value FROM {$this->table_postmeta} WHERE meta_id > %d AND meta_key IN ({$placeholders}) ORDER BY meta_id ASC LIMIT %d",
            ...$args
        );

        $rows = $this->wpdb->get_results( $query, ARRAY_A );
        if ( $rows === false ) {
            $this->logger->error( 'Failed to fetch legacy singleton meta rows.' );
            return;
        }

        if ( empty( $rows ) ) {
            $this->logger->info( 'No legacy singleton rows found, marking task as finished.' );
            $this->state->update_task_state( $this->get_name(), array( 'status' => 'finished' ) );
            return;
        }

        $processed_in_batch    = 0;
        $error_count_in_batch  = 0;
        $last_meta_id_in_batch = $last_id;
        $start_time            = microtime( true );
        $rows_count            = count( $rows );

        foreach ( $rows as $row ) {
            if ( microtime( true ) - $start_time >= $time_limit_seconds ) {
                break;
            }

            $meta_id = isset( $row['meta_id'] ) ? (int) $row['meta_id'] : 0;
            $post_id = isset( $row['post_id'] ) ? (int) $row['post_id'] : 0;
            $meta_key = isset( $row['meta_key'] ) ? (string) $row['meta_key'] : '';
            $value    = isset( $row['value'] ) ? trim( (string) $row['value'] ) : '';

            if ( $value === '' || $post_id === 0 || $meta_key === '' ) {
                $last_meta_id_in_batch = $meta_id;
                continue;
            }

            $required_key_type = $this->get_db2_key_type_for_meta_key( $meta_key );
            if ( $required_key_type === null || ! $this->db2_key_type_exists( $required_key_type ) ) {
                $this->logger->error( 'Missing DB2 key for singleton migration row.', array(
                    'post_id'   => $post_id,
                    'meta_id'   => $meta_id,
                    'meta_key'  => $meta_key,
                    'key_type'  => $required_key_type,
                ) );
                $error_count_in_batch++;
                $last_meta_id_in_batch = $meta_id;
                continue;
            }

            $ok = $this->run_db2_write_atomically( function () use ( $bridge, $post_id, $meta_key, $value ): bool {
                return $bridge->handle_post_meta_change( $post_id, $meta_key, $value );
            } );
            if ( ! $ok ) {
                $error_count_in_batch++;
                $last_meta_id_in_batch = $meta_id;
                continue;
            }

            $this->delete_legacy_postmeta_row( $meta_id );

            $processed_in_batch++;
            $last_meta_id_in_batch = $meta_id;
        }

        $current_state   = $this->state->get_task_state( $this->get_name() );
        $total_processed = (int) ( $current_state['processed_count'] ?? 0 ) + $processed_in_batch;
        $total_errors    = (int) ( $current_state['error_count'] ?? 0 ) + $error_count_in_batch;
        $status          = 'running';

        if ( 0 === $processed_in_batch && $rows_count < $limit ) {
            $status = 'finished';
        }

        $this->state->update_task_state( $this->get_name(), array(
            'status'          => $status,
            'processed_count' => $total_processed,
            'error_count'     => $total_errors,
            'last_id'         => $last_meta_id_in_batch,
        ) );

        $this->logger->info( 'Finished singleton batch.', array(
            'processed' => $processed_in_batch,
            'errors'    => $error_count_in_batch,
            'last_id'   => $last_meta_id_in_batch,
            'status'    => $status,
        ) );
    }

    /**
     * {@inheritdoc}
     */
    public function is_finished(): bool {
        $state = $this->state->get_task_state( $this->get_name() );

        return isset( $state['status'] ) && 'finished' === $state['status'];
    }

    /**
     * @return Fifu_Db2_Legacy_Write_Bridge|null
     */
    protected function get_legacy_bridge(): ?Fifu_Db2_Legacy_Write_Bridge {
        if ( ! function_exists( 'fifu_db2_legacy_write_bridge' ) ) {
            return null;
        }

        $bridge = fifu_db2_legacy_write_bridge();
        if ( ! $bridge instanceof Fifu_Db2_Legacy_Write_Bridge ) {
            return null;
        }

        return $bridge;
    }

    /**
     * Deletes a legacy postmeta row by meta_id.
     *
     * @param int $meta_id
     * @return void
     */
    protected function delete_legacy_postmeta_row( int $meta_id ): void {
        $this->wpdb->delete(
            $this->table_postmeta,
            array( 'meta_id' => $meta_id ),
            array( '%d' )
        );
    }

    private function run_db2_write_atomically( callable $callback ): bool {
        $started = $this->wpdb->query( 'START TRANSACTION' );
        if ( false === $started ) {
            return (bool) $callback();
        }

        try {
            $ok = (bool) $callback();
            $this->wpdb->query( $ok ? 'COMMIT' : 'ROLLBACK' );
            return $ok;
        } catch ( Throwable $exception ) {
            $this->wpdb->query( 'ROLLBACK' );
            $this->logger->error( 'DB2 write failed during singleton migration.', array(
                'message' => $exception->getMessage(),
            ) );
            return false;
        }
    }

    protected function get_db2_key_type_for_meta_key( string $meta_key ): ?string {
        return self::META_KEY_TO_DB2_KEY_TYPE[ $meta_key ] ?? null;
    }

    protected function db2_key_type_exists( string $key_type ): bool {
        $key_type = trim( $key_type );
        if ( '' === $key_type ) {
            return false;
        }

        $table = $this->wpdb->prefix . 'fifu_key';
        $query = $this->wpdb->prepare(
            "SELECT key_id FROM {$table} WHERE key_type = %s LIMIT 1",
            $key_type
        );
        $key_id = $this->wpdb->get_var( $query );

        return $key_id !== null && $key_id !== false;
    }
}
