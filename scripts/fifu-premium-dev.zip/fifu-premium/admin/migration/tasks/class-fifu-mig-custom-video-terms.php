<?php
declare( strict_types=1 );

/**
 * Handles migration of legacy term custom video URL metadata.
 */
class Fifu_Mig_Custom_Video_Terms implements Fifu_Migration_Task_Interface {

    /** @var wpdb */
    protected $wpdb;

    /** @var Fifu_Migration_State */
    protected $state;

    /** @var Fifu_Migration_Logger */
    protected $logger;

    /** @var string */
    protected $meta_key = 'fifu_custom_video_url';

    /** @var string */
    protected $table_termmeta;

    /** @var Fifu_Db2_Write_Service|null */
    protected $write_service = null;

    /**
     * @param wpdb|null                 $wpdb
     * @param Fifu_Migration_State|null $state
     * @param Fifu_Migration_Logger|null $logger
     */
    public function __construct( ?wpdb $wpdb = null, ?Fifu_Migration_State $state = null, ?Fifu_Migration_Logger $logger = null ) {
        if ( null === $wpdb ) {
            global $wpdb; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
            $this->wpdb = $wpdb;
        } else {
            $this->wpdb = $wpdb;
        }

        $this->state  = $state  ?? new Fifu_Migration_State();
        $this->logger = $logger ?? new Fifu_Migration_Logger();

        $this->table_termmeta = $this->wpdb->termmeta;
    }

    /**
     * {@inheritdoc}
     */
    public function get_name(): string {
        return 'custom_video_terms';
    }

    /**
     * {@inheritdoc}
     */
    public function get_label(): string {
        return 'Term custom video URL migration';
    }

    /**
     * {@inheritdoc}
     */
    public function run_batch( int $limit, int $time_limit_seconds ): void {
        $limit              = max( 100, $limit );
        $time_limit_seconds = max( 10, $time_limit_seconds );

        $state   = $this->state->get_task_state( $this->get_name() );
        $last_id = isset( $state['last_id'] ) ? (int) $state['last_id'] : 0;

        $this->logger->info( 'Starting custom video terms batch.', array(
            'limit'      => $limit,
            'time_limit' => $time_limit_seconds,
            'last_id'    => $last_id,
        ) );

        $write_service = $this->get_write_service();
        if ( null === $write_service ) {
            $this->logger->error( 'The db2 write service is not available, aborting custom video terms migration.' );
            return;
        }

        $query = $this->wpdb->prepare(
            "SELECT meta_id, term_id, meta_value AS url FROM {$this->table_termmeta} WHERE meta_id > %d AND meta_key = %s ORDER BY meta_id ASC LIMIT %d",
            $last_id,
            $this->meta_key,
            $limit
        );

        $rows = $this->wpdb->get_results( $query, ARRAY_A );
        if ( false === $rows ) {
            $this->logger->error( 'Failed to fetch legacy term custom video meta rows.' );
            return;
        }

        if ( empty( $rows ) ) {
            $this->logger->info( 'No legacy term custom video URLs found, marking task as finished.' );
            $this->state->update_task_state( $this->get_name(), array( 'status' => 'finished' ) );
            return;
        }

        $processed_in_batch     = 0;
        $error_count_in_batch   = 0;
        $last_meta_id_in_batch  = $last_id;
        $start_time             = microtime( true );
        $rows_count             = count( $rows );

        foreach ( $rows as $row ) {
            if ( microtime( true ) - $start_time >= $time_limit_seconds ) {
                break;
            }

            $meta_id = isset( $row['meta_id'] ) ? (int) $row['meta_id'] : 0;
            $term_id = isset( $row['term_id'] ) ? (int) $row['term_id'] : 0;
            $url     = isset( $row['url'] ) ? trim( (string) $row['url'] ) : '';

            if ( '' === $url || 0 === $term_id ) {
                $last_meta_id_in_batch = $meta_id;
                continue;
            }

            if ( ! $write_service->save_term_custom_video( $term_id, $url ) ) {
                $error_count_in_batch++;
                $last_meta_id_in_batch = $meta_id;
                continue;
            }

            $this->delete_legacy_termmeta_row( $meta_id );

            $processed_in_batch++;
            $last_meta_id_in_batch = $meta_id;
        }

        $current_state   = $this->state->get_task_state( $this->get_name() );
        $total_processed = (int) ( $current_state['processed_count'] ?? 0 ) + $processed_in_batch;
        $total_errors    = (int) ( $current_state['error_count'] ?? 0 ) + $error_count_in_batch;
        $status          = 'running';
        $last_id_for_state = $last_meta_id_in_batch > 0 ? $last_meta_id_in_batch : $last_id;

        if ( 0 === $processed_in_batch && $rows_count < $limit ) {
            $status = 'finished';
        }

        $this->state->update_task_state( $this->get_name(), array(
            'status'          => $status,
            'processed_count' => $total_processed,
            'error_count'     => $total_errors,
            'last_id'         => $last_id_for_state,
        ) );

        $this->logger->info( 'Finished custom video terms batch.', array(
            'processed' => $processed_in_batch,
            'errors'    => $error_count_in_batch,
            'last_id'   => $last_meta_id_in_batch,
            'status'    => $status,
        ) );
    }

    /**
     * {@inheritdoc}
     */
    public function is_finished(): bool {
        $state = $this->state->get_task_state( $this->get_name() );

        return isset( $state['status'] ) && 'finished' === $state['status'];
    }

    /**
     * Returns the write service instance if available.
     *
     * @return Fifu_Db2_Write_Service|null
     */
    private function get_write_service(): ?Fifu_Db2_Write_Service {
        if ( $this->write_service instanceof Fifu_Db2_Write_Service ) {
            return $this->write_service;
        }

        if ( ! function_exists( 'fifu_db2_write_service' ) ) {
            return null;
        }

        $service = fifu_db2_write_service();
        if ( ! $service instanceof Fifu_Db2_Write_Service ) {
            return null;
        }

        $this->write_service = $service;
        return $service;
    }

    /**
     * @param int $meta_id
     * @return void
     */
    private function delete_legacy_termmeta_row( int $meta_id ): void {
        if ( $meta_id <= 0 ) {
            return;
        }

        $this->wpdb->query(
            $this->wpdb->prepare(
                "DELETE FROM {$this->table_termmeta} WHERE meta_id = %d",
                $meta_id
            )
        );
    }
}
