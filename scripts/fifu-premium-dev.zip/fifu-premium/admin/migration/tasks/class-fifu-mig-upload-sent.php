<?php
declare( strict_types=1 );

/**
 * Migrates the legacy upload sent flags into the DB2 sent tables.
 */
class Fifu_Mig_Upload_Sent implements Fifu_Migration_Task_Interface {

    private const META_KEY_POST = 'fifu_uploadpost_sent';
    private const META_KEY_TERM = 'fifu_uploadterm_sent';
    private const PHASE_POST = 'post';
    private const PHASE_TERM = 'term';

    /** @var wpdb */
    protected $wpdb;

    /** @var Fifu_Migration_State */
    protected $state;

    /** @var Fifu_Migration_Logger */
    protected $logger;

    /**
     * @param wpdb|null                 $wpdb
     * @param Fifu_Migration_State|null $state
     * @param Fifu_Migration_Logger|null $logger
     */
    public function __construct( ?wpdb $wpdb = null, ?Fifu_Migration_State $state = null, ?Fifu_Migration_Logger $logger = null ) {
        if ( $wpdb === null ) {
            global $wpdb; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
            $this->wpdb = $wpdb;
        } else {
            $this->wpdb = $wpdb;
        }

        $this->state = $state ?? new Fifu_Migration_State();
        $this->logger = $logger ?? new Fifu_Migration_Logger();
    }

    /**
     * @inheritDoc
     */
    public function get_name(): string {
        return 'upload_sent';
    }

    /**
     * @inheritDoc
     */
    public function get_label(): string {
        return 'Upload sent flags migration';
    }

    /**
     * @inheritDoc
     */
    public function run_batch( int $limit, int $time_limit_seconds ): void {
        $limit = max( 1, $limit );
        $time_limit_seconds = max( 1, $time_limit_seconds );

        $state = $this->state->get_task_state( $this->get_name() );
        $phase = isset( $state['phase'] ) ? (string) $state['phase'] : self::PHASE_POST;
        $last_id = isset( $state['last_id'] ) ? (int) $state['last_id'] : 0;

        $this->logger->info( 'Starting upload sent migration batch.', array(
            'phase'      => $phase,
            'last_id'    => $last_id,
            'limit'      => $limit,
            'time_limit' => $time_limit_seconds,
        ) );

        $sent_service = $this->resolve_sent_service();
        if ( $sent_service === null ) {
            $this->logger->error( 'DB2 sent service is unavailable, cannot migrate upload sent flags.' );
            return;
        }

        $processed_in_batch = 0;
        $error_count_in_batch = 0;
        $last_meta_id = $last_id;
        $status = 'running';
        $start_time = microtime( true );

        if ( $phase === self::PHASE_POST ) {
            $rows = $this->fetch_post_sent_rows( $last_id, $limit );

            if ( $rows === false ) {
                $this->logger->error( 'Failed to fetch legacy post upload sent rows.' );
                $error_count_in_batch++;
            } elseif ( empty( $rows ) ) {
                $phase = self::PHASE_TERM;
                $last_meta_id = 0;
            } else {
                foreach ( $rows as $row ) {
                    if ( microtime( true ) - $start_time >= $time_limit_seconds ) {
                        break;
                    }

                    $meta_id = isset( $row['meta_id'] ) ? (int) $row['meta_id'] : 0;
                    $post_id = isset( $row['post_id'] ) ? (int) $row['post_id'] : 0;
                    $last_meta_id = max( $last_meta_id, $meta_id );

                    if ( $meta_id <= 0 || $post_id <= 0 ) {
                        continue;
                    }

                    $sent = (int) ( $row['meta_value'] ?? 0 ) === 1;
                    if ( ! $sent ) {
                        continue;
                    }

                    if ( ! $sent_service->set_sent_post_upload( $post_id, true ) ) {
                        $error_count_in_batch++;
                        continue;
                    }

                    if ( ! $this->delete_postmeta_row( $meta_id, $post_id ) ) {
                        $error_count_in_batch++;
                        continue;
                    }

                    $processed_in_batch++;
                }
            }
        } elseif ( $phase === self::PHASE_TERM ) {
            $rows = $this->fetch_term_sent_rows( $last_id, $limit );

            if ( $rows === false ) {
                $this->logger->error( 'Failed to fetch legacy term upload sent rows.' );
                $error_count_in_batch++;
            } elseif ( empty( $rows ) ) {
                $status = 'finished';
            } else {
                foreach ( $rows as $row ) {
                    if ( microtime( true ) - $start_time >= $time_limit_seconds ) {
                        break;
                    }

                    $meta_id = isset( $row['meta_id'] ) ? (int) $row['meta_id'] : 0;
                    $term_id = isset( $row['term_id'] ) ? (int) $row['term_id'] : 0;
                    $last_meta_id = max( $last_meta_id, $meta_id );

                    if ( $meta_id <= 0 || $term_id <= 0 ) {
                        continue;
                    }

                    $sent = (int) ( $row['meta_value'] ?? 0 ) === 1;
                    if ( ! $sent ) {
                        continue;
                    }

                    if ( ! $sent_service->set_sent_term_upload( $term_id, true ) ) {
                        $error_count_in_batch++;
                        continue;
                    }

                    if ( ! $this->delete_termmeta_row( $meta_id, $term_id ) ) {
                        $error_count_in_batch++;
                        continue;
                    }

                    $processed_in_batch++;
                }
            }
        }

        $current_state = $this->state->get_task_state( $this->get_name() );
        $total_processed = (int) ( $current_state['processed_count'] ?? 0 ) + $processed_in_batch;
        $total_errors = (int) ( $current_state['error_count'] ?? 0 ) + $error_count_in_batch;

        $this->state->update_task_state( $this->get_name(), array(
            'status'          => $status,
            'phase'           => $phase,
            'last_id'         => $last_meta_id,
            'processed_count' => $total_processed,
            'error_count'     => $total_errors,
        ) );

        $this->logger->info( 'Finished upload sent migration batch.', array(
            'phase'     => $phase,
            'processed' => $processed_in_batch,
            'errors'    => $error_count_in_batch,
            'last_id'   => $last_meta_id,
            'status'    => $status,
        ) );
    }

    /**
     * @inheritDoc
     */
    public function is_finished(): bool {
        $state = $this->state->get_task_state( $this->get_name() );
        return isset( $state['status'] ) && $state['status'] === 'finished';
    }

    private function resolve_sent_service(): ?Fifu_Db2_Sent_Service {
        if ( ! function_exists( 'fifu_db2_sent_service' ) ) {
            return null;
        }

        $service = fifu_db2_sent_service();
        if ( ! $service instanceof Fifu_Db2_Sent_Service ) {
            return null;
        }

        return $service;
    }

    /**
     * @return array|false
     */
    private function fetch_post_sent_rows( int $last_id, int $limit ) {
        $sql = $this->wpdb->prepare(
            "SELECT meta_id, post_id, meta_value
             FROM {$this->wpdb->postmeta}
             WHERE meta_id > %d
               AND meta_key = %s
             ORDER BY meta_id ASC
             LIMIT %d",
            $last_id,
            self::META_KEY_POST,
            $limit
        );

        return $this->wpdb->get_results( $sql, ARRAY_A );
    }

    /**
     * @return array|false
     */
    private function fetch_term_sent_rows( int $last_id, int $limit ) {
        $sql = $this->wpdb->prepare(
            "SELECT meta_id, term_id, meta_value
             FROM {$this->wpdb->termmeta}
             WHERE meta_id > %d
               AND meta_key = %s
             ORDER BY meta_id ASC
             LIMIT %d",
            $last_id,
            self::META_KEY_TERM,
            $limit
        );

        return $this->wpdb->get_results( $sql, ARRAY_A );
    }

    private function delete_postmeta_row( int $meta_id, int $post_id ): bool {
        $result = $this->wpdb->delete(
            $this->wpdb->postmeta,
            array( 'meta_id' => $meta_id ),
            array( '%d' )
        );

        if ( $result === false ) {
            return false;
        }

        clean_post_cache( $post_id );
        wp_cache_delete( $post_id, 'post_meta' );

        return true;
    }

    private function delete_termmeta_row( int $meta_id, int $term_id ): bool {
        $result = $this->wpdb->delete(
            $this->wpdb->termmeta,
            array( 'meta_id' => $meta_id ),
            array( '%d' )
        );

        if ( $result === false ) {
            return false;
        }

        clean_term_cache( $term_id );
        wp_cache_delete( $term_id, 'term_meta' );

        return true;
    }
}
