<?php
declare( strict_types=1 );

/**
 * Migrates the legacy finder counter rows into the DB2 sent tables.
 */
class Fifu_Mig_Finder_Not_Found implements Fifu_Migration_Task_Interface {

    private const META_KEY = 'fifu_finder_counter';

    /** @var wpdb */
    protected $wpdb;

    /** @var Fifu_Migration_State */
    protected $state;

    /** @var Fifu_Migration_Logger */
    protected $logger;

    /**
     * @param wpdb|null                 $wpdb
     * @param Fifu_Migration_State|null $state
     * @param Fifu_Migration_Logger|null $logger
     */
    public function __construct( ?wpdb $wpdb = null, ?Fifu_Migration_State $state = null, ?Fifu_Migration_Logger $logger = null ) {
        if ( $wpdb === null ) {
            global $wpdb; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
            $this->wpdb = $wpdb;
        } else {
            $this->wpdb = $wpdb;
        }

        $this->state = $state ?? new Fifu_Migration_State();
        $this->logger = $logger ?? new Fifu_Migration_Logger();
    }

    /**
     * @inheritDoc
     */
    public function get_name(): string {
        return 'finder_not_found';
    }

    /**
     * @inheritDoc
     */
    public function get_label(): string {
        return 'Finder not found counters migration';
    }

    /**
     * @inheritDoc
     */
    public function run_batch( int $limit, int $time_limit_seconds ): void {
        $limit = max( 1, $limit );
        $time_limit_seconds = max( 1, $time_limit_seconds );

        $state = $this->state->get_task_state( $this->get_name() );
        $last_id = isset( $state['last_id'] ) ? (int) $state['last_id'] : 0;

        $this->logger->info( 'Starting finder_not_found migration batch.', array(
            'last_id'    => $last_id,
            'limit'      => $limit,
            'time_limit' => $time_limit_seconds,
        ) );

        $sent_service = $this->resolve_sent_service();
        if ( $sent_service === null ) {
            $this->logger->error( 'DB2 sent service is unavailable, cannot migrate finder_not_found counters.' );
            return;
        }

        $processed_in_batch = 0;
        $error_count_in_batch = 0;
        $status = 'running';
        $last_meta_id = $last_id;
        $start_time = microtime( true );

        $rows = $this->fetch_rows( $last_id, $limit );
        if ( $rows === false ) {
            $this->logger->error( 'Failed to fetch legacy finder counter rows.' );
            $error_count_in_batch++;
        } elseif ( empty( $rows ) ) {
            $status = 'finished';
        } else {
            foreach ( $rows as $row ) {
                if ( microtime( true ) - $start_time >= $time_limit_seconds ) {
                    break;
                }

                $meta_id = isset( $row['meta_id'] ) ? (int) $row['meta_id'] : 0;
                $post_id = isset( $row['post_id'] ) ? (int) $row['post_id'] : 0;
                $last_meta_id = max( $last_meta_id, $meta_id );

                if ( $meta_id <= 0 || $post_id <= 0 ) {
                    continue;
                }

                $attempts = max( 0, (int) ( $row['meta_value'] ?? 0 ) );

                if ( ! $sent_service->mark_sent_ok_with_attempts( 'post', $post_id, 'finder_not_found', $attempts ) ) {
                    $error_count_in_batch++;
                    continue;
                }

                if ( ! $this->delete_postmeta_row( $meta_id, $post_id ) ) {
                    $error_count_in_batch++;
                    continue;
                }

                $processed_in_batch++;
            }
        }

        $current_state = $this->state->get_task_state( $this->get_name() );
        $total_processed = (int) ( $current_state['processed_count'] ?? 0 ) + $processed_in_batch;
        $total_errors = (int) ( $current_state['error_count'] ?? 0 ) + $error_count_in_batch;

        $this->state->update_task_state( $this->get_name(), array(
            'status'          => $status,
            'last_id'         => $last_meta_id,
            'processed_count' => $total_processed,
            'error_count'     => $total_errors,
        ) );

        $this->logger->info( 'Finished finder_not_found migration batch.', array(
            'processed' => $processed_in_batch,
            'errors'    => $error_count_in_batch,
            'last_id'   => $last_meta_id,
            'status'    => $status,
        ) );
    }

    /**
     * @inheritDoc
     */
    public function is_finished(): bool {
        $state = $this->state->get_task_state( $this->get_name() );
        return isset( $state['status'] ) && $state['status'] === 'finished';
    }

    private function resolve_sent_service(): ?Fifu_Db2_Sent_Service {
        if ( ! function_exists( 'fifu_db2_sent_service' ) ) {
            return null;
        }

        $service = fifu_db2_sent_service();
        if ( ! $service instanceof Fifu_Db2_Sent_Service ) {
            return null;
        }

        return $service;
    }

    private function fetch_rows( int $last_id, int $limit ) {
        $sql = $this->wpdb->prepare(
            "SELECT meta_id, post_id, meta_value
             FROM {$this->wpdb->postmeta}
             WHERE meta_id > %d
               AND meta_key = %s
             ORDER BY meta_id ASC
             LIMIT %d",
            $last_id,
            self::META_KEY,
            $limit
        );

        return $this->wpdb->get_results( $sql, ARRAY_A );
    }

    private function delete_postmeta_row( int $meta_id, int $post_id ): bool {
        $result = $this->wpdb->delete(
            $this->wpdb->postmeta,
            array( 'meta_id' => $meta_id ),
            array( '%d' )
        );

        if ( $result === false ) {
            return false;
        }

        clean_post_cache( $post_id );
        wp_cache_delete( $post_id, 'post_meta' );

        return true;
    }
}
