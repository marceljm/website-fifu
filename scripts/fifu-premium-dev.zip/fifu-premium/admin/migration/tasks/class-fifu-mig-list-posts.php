<?php
declare( strict_types=1 );

/**
 * Handles migration of legacy FIFU list metadata for posts.
 */
class Fifu_Mig_List_Posts implements Fifu_Migration_Task_Interface {

    /** @var wpdb */
    protected $wpdb;

    /** @var Fifu_Migration_State */
    protected $state;

    /** @var Fifu_Migration_Logger */
    protected $logger;

    /** @var string */
    protected $table_postmeta;

    /** @var array<string> */
    protected $meta_keys = array(
        'fifu_list_url',
        'fifu_list_alt',
        'fifu_list_video_url',
        'fifu_list_iframe_url',
        'fifu_slider_list_url',
        'fifu_slider_list_alt',
        'fifu_tmp_product_image_gallery',
    );

    /**
     * @param wpdb|null                $wpdb
     * @param Fifu_Migration_State|null $state
     * @param Fifu_Migration_Logger|null $logger
     */
    public function __construct( ?wpdb $wpdb = null, ?Fifu_Migration_State $state = null, ?Fifu_Migration_Logger $logger = null ) {
        if ( $wpdb === null ) {
            global $wpdb; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
            $this->wpdb = $wpdb;
        } else {
            $this->wpdb = $wpdb;
        }

        $this->state  = $state  ?? new Fifu_Migration_State();
        $this->logger = $logger ?? new Fifu_Migration_Logger();

        $this->table_postmeta = $this->wpdb->postmeta;
    }

    /**
     * {@inheritdoc}
     */
    public function get_name(): string {
        return 'list_posts';
    }

    /**
     * {@inheritdoc}
     */
    public function get_label(): string {
        return 'List metadata migration (posts)';
    }

    /**
     * {@inheritdoc}
     */
    public function run_batch( int $limit, int $time_limit_seconds ): void {
        $limit              = max( 1, $limit );
        $time_limit_seconds = max( 1, $time_limit_seconds );

        $state   = $this->state->get_task_state( $this->get_name() );
        $last_id = isset( $state['last_id'] ) ? (int) $state['last_id'] : 0;

        $this->logger->info( 'Starting list posts batch.', array(
            'limit'      => $limit,
            'time_limit' => $time_limit_seconds,
            'last_id'    => $last_id,
        ) );

        $bridge = $this->get_legacy_bridge();
        if ( $bridge === null ) {
            $this->logger->error( 'Missing DB2 legacy write bridge, cannot migrate list post meta.' );
            return;
        }

        $placeholders = implode( ', ', array_fill( 0, count( $this->meta_keys ), '%s' ) );
        $args = array_merge(
            array( $last_id ),
            $this->meta_keys,
            array( $limit )
        );

        $query = $this->wpdb->prepare(
            "SELECT meta_id, post_id, meta_key, meta_value AS value FROM {$this->table_postmeta} WHERE meta_id > %d AND meta_key IN ({$placeholders}) ORDER BY meta_id ASC LIMIT %d",
            ...$args
        );

        $rows = $this->wpdb->get_results( $query, ARRAY_A );
        if ( $rows === false ) {
            $this->logger->error( 'Failed to fetch legacy list post meta rows.' );
            return;
        }

        if ( empty( $rows ) ) {
            $this->logger->info( 'No legacy post list meta rows found, marking task as finished.' );
            $this->state->update_task_state( $this->get_name(), array( 'status' => 'finished' ) );
            return;
        }

        $processed_in_batch    = 0;
        $error_count_in_batch  = 0;
        $last_meta_id_in_batch = $last_id;
        $start_time            = microtime( true );
        $rows_count            = count( $rows );
        $posts_to_flush        = array();

        foreach ( $rows as $row ) {
            if ( microtime( true ) - $start_time >= $time_limit_seconds ) {
                break;
            }

            $meta_id  = isset( $row['meta_id'] ) ? (int) $row['meta_id'] : 0;
            $post_id  = isset( $row['post_id'] ) ? (int) $row['post_id'] : 0;
            $meta_key = isset( $row['meta_key'] ) ? (string) $row['meta_key'] : '';
            $value    = isset( $row['value'] ) ? trim( (string) $row['value'] ) : '';

            if ( $post_id === 0 || $meta_key === '' ) {
                $last_meta_id_in_batch = $meta_id;
                continue;
            }

            if ( $this->is_cleanup_only_meta_key( $meta_key ) ) {
                if ( ! $this->delete_legacy_postmeta_row( $meta_id, $post_id, $meta_key ) ) {
                    $error_count_in_batch++;
                    $last_meta_id_in_batch = $meta_id;
                    continue;
                }

                clean_post_cache( $post_id );
                wp_cache_delete( $post_id, 'post_meta' );

                $processed_in_batch++;
                $last_meta_id_in_batch = $meta_id;
                continue;
            }

            if ( $value === '' ) {
                $last_meta_id_in_batch = $meta_id;
                continue;
            }

            $this->clear_db2_key_cache();
            $bridge_ok     = $bridge->handle_post_meta_change( $post_id, $meta_key, $value );
            $this->clear_db2_key_cache();
            $db2_confirmed  = $this->db2_state_matches_legacy_row( $post_id, $meta_key, $value );
            if ( true !== $bridge_ok && ! $db2_confirmed ) {
                $this->clear_db2_key_cache();
                $db2_confirmed = $this->db2_state_matches_legacy_row( $post_id, $meta_key, $value );
            }

            if ( true !== $bridge_ok && ! $db2_confirmed ) {
                $error_count_in_batch++;
                wp_cache_delete( $post_id, 'post_meta' );
                $last_meta_id_in_batch = $meta_id;
                continue;
            }

            if ( ! $this->delete_legacy_postmeta_row( $meta_id, $post_id, $meta_key ) ) {
                $error_count_in_batch++;
                $last_meta_id_in_batch = $meta_id;
                continue;
            }

            clean_post_cache( $post_id );
            wp_cache_delete( $post_id, 'post_meta' );

            $processed_in_batch++;
            $last_meta_id_in_batch = $meta_id;
        }

        $current_state   = $this->state->get_task_state( $this->get_name() );
        $total_processed = (int) ( $current_state['processed_count'] ?? 0 ) + $processed_in_batch;
        $total_errors    = (int) ( $current_state['error_count'] ?? 0 ) + $error_count_in_batch;
        $status          = 'running';

        if ( 0 === $processed_in_batch && $rows_count < $limit ) {
            $status = 'finished';
        }

        $this->state->update_task_state( $this->get_name(), array(
            'status'          => $status,
            'processed_count' => $total_processed,
            'error_count'     => $total_errors,
            'last_id'         => $last_meta_id_in_batch,
        ) );

        $this->logger->info( 'Finished list posts batch.', array(
            'processed' => $processed_in_batch,
            'errors'    => $error_count_in_batch,
            'last_id'   => $last_meta_id_in_batch,
            'status'    => $status,
        ) );
    }

    /**
     * Clears the DB2 key cache when the manager is available.
     *
     * @return void
     */
    private function clear_db2_key_cache(): void {
        try {
            if ( ! function_exists( 'fifu_db2_manager' ) ) {
                return;
            }

            $db2_manager = fifu_db2_manager();
            if ( $db2_manager instanceof Fifu_Db2_Manager && method_exists( $db2_manager, 'clearKeyCache' ) ) {
                $db2_manager->clearKeyCache();
            }
        } catch ( Throwable $e ) {
            // Best-effort cache invalidation only.
        }
    }

    /**
     * {@inheritdoc}
     */
    public function is_finished(): bool {
        $state = $this->state->get_task_state( $this->get_name() );

        return isset( $state['status'] ) && 'finished' === $state['status'];
    }

    /**
     * Deletes a legacy postmeta row by meta_id and invalidates the post cache.
     *
     * @param int $meta_id
     * @param int $post_id
     * @param string $meta_key
     * @return void
     */
    protected function delete_legacy_postmeta_row( int $meta_id, int $post_id, string $meta_key = '' ): bool {
        if ( function_exists( 'delete_metadata_by_mid' ) ) {
            delete_metadata_by_mid( 'post', $meta_id );
        }

        $exists = (int) $this->wpdb->get_var( $this->wpdb->prepare(
            "SELECT meta_id FROM {$this->table_postmeta} WHERE meta_id = %d LIMIT 1",
            $meta_id
        ) );

        if ( $exists > 0 ) {
            $this->wpdb->delete(
                $this->table_postmeta,
                array( 'meta_id' => $meta_id ),
                array( '%d' )
            );
        }

        $exists = (int) $this->wpdb->get_var( $this->wpdb->prepare(
            "SELECT meta_id FROM {$this->table_postmeta} WHERE meta_id = %d LIMIT 1",
            $meta_id
        ) );

        if ( $exists > 0 ) {
            $this->logger->error( 'Failed to delete legacy list post meta row.', array(
                'meta_id'   => $meta_id,
                'post_id'   => $post_id,
                'meta_key'  => $meta_key,
            ) );
            return false;
        }

        clean_post_cache( $post_id );
        wp_cache_delete( $post_id, 'post_meta' );

        return true;
    }

    /**
     * Returns whether a legacy list-post meta key is cleanup-only.
     *
     * Cleanup-only keys are discovered and deleted by the migration task, but
     * must not be written to DB2 because they are temporary snapshots, not
     * canonical FIFU media state.
     *
     * @param string $meta_key
     * @return bool
     */
    private function is_cleanup_only_meta_key( string $meta_key ): bool {
        return in_array(
            $meta_key,
            array(
                'fifu_tmp_product_image_gallery',
            ),
            true
        );
    }

    /**
     * Confirms whether DB2 matches the legacy row exactly.
     *
     * @param int    $post_id
     * @param string $meta_key
     * @param string $value
     * @return bool
     */
    private function db2_state_matches_legacy_row( int $post_id, string $meta_key, string $value ): bool {
        if ( in_array( $meta_key, array( 'fifu_list_url', 'fifu_slider_list_url', 'fifu_list_iframe_url' ), true ) ) {
            $key_type = 'fifu_list_url' === $meta_key ? 'image' : ( 'fifu_slider_list_url' === $meta_key ? 'slider' : 'iframe' );
            return $this->db2_url_list_matches_legacy_row( $post_id, $key_type, $value );
        }

        if ( in_array( $meta_key, array( 'fifu_list_alt', 'fifu_slider_list_alt' ), true ) ) {
            $key_type = 'fifu_list_alt' === $meta_key ? 'image' : 'slider';
            return $this->db2_alt_list_matches_legacy_row( $post_id, $key_type, $value );
        }

        if ( 'fifu_list_video_url' === $meta_key ) {
            return $this->db2_video_list_matches_legacy_row( $post_id, $value );
        }

        return false;
    }

    /**
     * @param int    $post_id
     * @param string $key_type
     * @param string $value
     * @return bool
     */
    private function db2_url_list_matches_legacy_row( int $post_id, string $key_type, string $value ): bool {
        $expected_urls = $this->normalize_legacy_pipe_entries( $value );
        if ( empty( $expected_urls ) ) {
            return false;
        }

        if ( ! $this->db2_has_singular_mapping_method( 'getPostMapping' ) ) {
            return false;
        }

        foreach ( $expected_urls as $index => $url ) {
            $normalized = $this->normalize_db2_url_for_compare( $url );
            if ( null === $normalized ) {
                return false;
            }

            $mapping = $this->get_db2_mapping_at_index( $post_id, $key_type, $index, false );
            if ( null === $mapping || $normalized !== trim( (string) ( $mapping['url'] ?? '' ) ) ) {
                return false;
            }
        }

        return null === $this->get_db2_mapping_at_index( $post_id, $key_type, count( $expected_urls ), false );
    }

    /**
     * @param int    $post_id
     * @param string $key_type
     * @param string $value
     * @return bool
     */
    private function db2_alt_list_matches_legacy_row( int $post_id, string $key_type, string $value ): bool {
        $expected_alts = $this->normalize_legacy_pipe_entries_preserve_indexes( $value );
        if ( empty( $expected_alts ) ) {
            return false;
        }

        if ( ! $this->db2_has_singular_mapping_method( 'getPostAltMapping' ) ) {
            return false;
        }

        foreach ( $expected_alts as $index => $alt ) {
            $mapping = $this->get_db2_mapping_at_index( $post_id, $key_type, $index, true );
            if ( null === $mapping || trim( (string) ( $mapping['alt'] ?? '' ) ) !== $alt ) {
                return false;
            }
        }

        return null === $this->get_db2_mapping_at_index( $post_id, $key_type, max( array_keys( $expected_alts ) ) + 1, true );
    }

    /**
     * @param int    $post_id
     * @param string $value
     * @return bool
     */
    private function db2_video_list_matches_legacy_row( int $post_id, string $value ): bool {
        $entries = $this->normalize_legacy_pipe_entries( $value );
        if ( empty( $entries ) ) {
            return false;
        }

        $expected_video = array();
        $expected_custom_video = array();

        foreach ( $entries as $entry ) {
            $parts = array_map( 'trim', explode( '\\', $entry, 2 ) );
            if ( 2 === count( $parts ) && '' !== $parts[0] && '' !== $parts[1] ) {
                $video = $this->normalize_db2_url_for_compare( $parts[0] );
                $poster = $this->normalize_db2_url_for_compare( $parts[1] );
                if ( null === $video || null === $poster ) {
                    return false;
                }

                $expected_custom_video[] = $video;
                continue;
            }

            $video = $this->normalize_db2_url_for_compare( $entry );
            if ( null === $video ) {
                return false;
            }

            $expected_video[] = $video;
        }

        if ( ! $this->db2_has_singular_mapping_method( 'getPostMapping' ) ) {
            return false;
        }

        foreach ( $expected_video as $index => $url ) {
            $mapping = $this->get_db2_mapping_at_index( $post_id, 'video', $index, false );
            if ( null === $mapping || $this->normalize_db2_url_for_compare( (string) ( $mapping['url'] ?? '' ) ) !== $url ) {
                return false;
            }
        }

        foreach ( $expected_custom_video as $index => $url ) {
            $mapping = $this->get_db2_mapping_at_index( $post_id, 'custom_video', $index, false );
            if ( null === $mapping || $this->normalize_db2_url_for_compare( (string) ( $mapping['url'] ?? '' ) ) !== $url ) {
                return false;
            }
        }

        return null === $this->get_db2_mapping_at_index( $post_id, 'video', count( $expected_video ), false )
            && null === $this->get_db2_mapping_at_index( $post_id, 'custom_video', count( $expected_custom_video ), false );
    }

    /**
     * @param array<int, mixed>|mixed $rows
     * @param string $value_key
     * @return array<int, string>|null
     */
    private function normalize_db2_rows_by_index( $rows, string $value_key ): ?array {
        if ( ! is_array( $rows ) ) {
            return null;
        }

        $actual_by_index = array();
        foreach ( $rows as $row ) {
            if ( ! is_array( $row ) ) {
                return null;
            }

            $index = isset( $row['key_index'] ) ? (int) $row['key_index'] : -1;
            $value = trim( (string) ( $row[ $value_key ] ?? '' ) );
            if ( $index < 0 || '' === $value ) {
                return null;
            }

            if ( isset( $actual_by_index[ $index ] ) ) {
                return null;
            }

            if ( 'url' === $value_key ) {
                $value = $this->normalize_db2_url_for_compare( $value );
                if ( null === $value ) {
                    return null;
                }
            }

            $actual_by_index[ $index ] = $value;
        }

        if ( empty( $actual_by_index ) ) {
            return null;
        }

        ksort( $actual_by_index );

        $expected_indexes = array_keys( $actual_by_index );
        for ( $i = 0, $count = count( $expected_indexes ); $i < $count; $i++ ) {
            if ( $expected_indexes[ $i ] !== $i ) {
                return null;
            }
        }

        return $actual_by_index;
    }

    /**
     * @param string $value
     * @return array<int, string>
     */
    private function normalize_legacy_pipe_entries( string $value ): array {
        $entries = array();
        foreach ( explode( '|', $value ) as $entry ) {
            $entry = trim( $entry );
            if ( '' !== $entry ) {
                $entries[] = $entry;
            }
        }

        return $entries;
    }

    /**
     * @param string $value
     * @return array<int, string>
     */
    private function normalize_legacy_pipe_entries_preserve_indexes( string $value ): array {
        $entries = array();
        foreach ( explode( '|', $value ) as $index => $entry ) {
            $entry = trim( $entry );
            if ( '' !== $entry ) {
                $entries[ $index ] = $entry;
            }
        }

        return $entries;
    }

    /**
     * @param string $method
     * @return bool
     */
    private function db2_has_singular_mapping_method( string $method ): bool {
        if ( ! function_exists( 'fifu_db2_manager' ) ) {
            return false;
        }

        $manager = fifu_db2_manager();
        return $manager instanceof Fifu_Db2_Manager && method_exists( $manager, $method );
    }

    /**
     * @param int    $post_id
     * @param string $key_type
     * @param int    $key_index
     * @param bool    $alt
     * @return array<string, mixed>|null
     */
    private function get_db2_mapping_at_index( int $post_id, string $key_type, int $key_index, bool $alt ): ?array {
        if ( ! function_exists( 'fifu_db2_manager' ) ) {
            return null;
        }

        $manager = fifu_db2_manager();
        if ( ! $manager instanceof Fifu_Db2_Manager ) {
            return null;
        }

        $method = $alt ? 'getPostAltMapping' : 'getPostMapping';
        if ( ! method_exists( $manager, $method ) ) {
            return null;
        }

        try {
            $mapping = $manager->{$method}( $post_id, $key_type, $key_index );
        } catch ( \Throwable $e ) {
            return null;
        }

        return is_array( $mapping ) ? $mapping : null;
    }

    /**
     * @param int    $post_id
     * @param string $key_type
     * @param string $method
     * @return array<int, mixed>|false
     */
    private function get_db2_rows_for_compare( int $post_id, string $key_type, string $method ) {
        if ( ! function_exists( 'fifu_db2_manager' ) ) {
            return false;
        }

        $manager = fifu_db2_manager();
        if ( ! $manager instanceof Fifu_Db2_Manager || ! method_exists( $manager, $method ) ) {
            return false;
        }

        try {
            return $manager->{$method}( $post_id, $key_type );
        } catch ( \Throwable $e ) {
            return false;
        }
    }

    /**
     * Normalize a DB2 URL for comparison.
     *
     * @param string $url URL to normalize.
     * @return string|null
     */
    private function normalize_db2_url_for_compare( string $url ): ?string {
        $url = trim( $url );
        if ( '' === $url ) {
            return null;
        }

        if ( class_exists( 'Fifu_Db2_Normalizer', false ) && method_exists( 'Fifu_Db2_Normalizer', 'normalize_url' ) ) {
            $normalized = Fifu_Db2_Normalizer::normalize_url( $url );
            return null === $normalized ? null : trim( (string) $normalized );
        }

        return $url;
    }

    /**
     * @return Fifu_Db2_Legacy_Write_Bridge|null
     */
    protected function get_legacy_bridge(): ?Fifu_Db2_Legacy_Write_Bridge {
        if ( ! function_exists( 'fifu_db2_legacy_write_bridge' ) ) {
            return null;
        }

        $bridge = fifu_db2_legacy_write_bridge();
        if ( ! $bridge instanceof Fifu_Db2_Legacy_Write_Bridge ) {
            return null;
        }

        return $bridge;
    }
}
