<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Fifu_Legacy_Tables_Manager {

	/** @var wpdb */
	private $wpdb;

	private $table_import;
	private $table_invalid_media_su;
	private $table_md5;
	private $table_video_oembed;
	private $table_content;
	private $table_meta_in;
	private $table_meta_out;
	private $schema_dir;

	/**
	 * @param wpdb|null $wpdb_instance
	 */
	public function __construct( ?wpdb $wpdb_instance = null ) {
		if ( null === $wpdb_instance ) { // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
			global $wpdb;
			$wpdb_instance = $wpdb;
		}

		$this->wpdb = $wpdb_instance;
		$prefix = $this->wpdb->prefix;

		$this->table_import = $prefix . 'fifu_import';
		$this->table_invalid_media_su = $prefix . 'fifu_invalid_media_su';
		$this->table_md5 = $prefix . 'fifu_md5';
		$this->table_video_oembed = $prefix . 'fifu_video_oembed';
		$this->table_content = $prefix . 'fifu_content';
		$this->table_meta_in = $prefix . 'fifu_meta_in';
		$this->table_meta_out = $prefix . 'fifu_meta_out';

		$schema_dir = __DIR__ . '/../schema';
		$resolved = realpath( $schema_dir );
		$this->schema_dir = false === $resolved ? rtrim( $schema_dir, '/\\' ) : $resolved;
	}

	/**
	 * @return void
	 */
	public function ensure_all_tables(): void {
		$this->create_import_table();
		$this->create_invalid_media_su_table();
		$this->create_md5_table();
		$this->create_video_oembed_table();
		$this->create_content_table();
		$this->create_meta_in_table();
		$this->create_meta_out_table();
	}

	/**
	 * @return void
	 */
	public function create_import_table(): void {
		$this->run_schema_file( '008_create_fifu_import.sql' );
		$this->ensure_import_constraints();
	}

	/**
	 * @return void
	 */
	public function create_invalid_media_su_table(): void {
		$this->run_schema_file( '009_create_fifu_invalid_media_su.sql' );
	}

	/**
	 * @return void
	 */
	public function create_md5_table(): void {
		$this->run_schema_file( '010_create_fifu_md5.sql' );
	}

	/**
	 * @return void
	 */
	public function create_video_oembed_table(): void {
		$this->run_schema_file( '011_create_fifu_video_oembed.sql' );
	}

	/**
	 * @return void
	 */
	public function create_content_table(): void {
		$this->run_schema_file( '012_create_fifu_content.sql' );
	}

	/**
	 * @return void
	 */
	public function create_meta_in_table(): void {
		$this->run_schema_file( '013_create_fifu_meta_in.sql' );
	}

	/**
	 * @return void
	 */
	public function create_meta_out_table(): void {
		$this->run_schema_file( '014_create_fifu_meta_out.sql' );
	}

	/**
	 * @param string $filename
	 * @return void
	 */
	protected function run_schema_file( string $filename ): void {
		$path = $this->schema_dir . '/' . $filename;
		if ( ! is_file( $path ) ) {
			return;
		}

		$content = file_get_contents( $path );
		if ( false === $content ) {
			return;
		}

		$sql = str_replace(
			[ '{PREFIX}', '{CHARSET_COLLATE}' ],
			[ $this->wpdb->prefix, $this->wpdb->get_charset_collate() ],
			$content
		);

		$statements = array_filter(
			array_map( 'trim', explode( ';', $sql ) )
		);

		foreach ( $statements as $statement ) {
			if ( '' === $statement ) {
				continue;
			}

			$this->wpdb->query( $statement );
		}
	}

	/**
	 * @return void
	 */
	private function ensure_import_constraints(): void {
		$column_exists = $this->wpdb->get_results(
			$this->wpdb->prepare(
				"SHOW COLUMNS FROM {$this->table_import} LIKE %s",
				'category'
			)
		);
		if ( empty( $column_exists ) ) {
			$this->wpdb->query(
				"ALTER TABLE {$this->table_import} ADD category TINYINT(1) NOT NULL DEFAULT 0"
			);
		}

		$index_exists = $this->wpdb->get_results(
			$this->wpdb->prepare(
				"SHOW INDEX FROM {$this->table_import} WHERE Key_name = %s",
				'post_id'
			)
		);
		if ( empty( $index_exists ) ) {
			$this->wpdb->query( "ALTER TABLE {$this->table_import} ADD UNIQUE (post_id)" );
		}
	}
}
