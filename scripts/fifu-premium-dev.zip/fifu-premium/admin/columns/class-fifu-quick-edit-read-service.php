<?php

defined('ABSPATH') || exit;

if (!class_exists('Fifu_Post_Featured_Media_State_Resolver', false)) {
    require_once dirname(__DIR__, 2) . '/includes/meta/class-fifu-post-featured-media-state-resolver.php';
}

final class Fifu_Quick_Edit_Read_Service
{
    public static function get_display(int $post_id): array
    {
        $border = '';
        $height = 40;
        $width = $height * 1.0;
        $video_url = '';
        $video_src = '';
        $image_url = '';
        $url = '';

        $video = Fifu_Post_Video_Read_Service::get_video_url($post_id);
        $video = $video ?: Fifu_Post_Custom_Video_Read_Service::get_custom_video_url($post_id);

        if ($video === '' || $video === null) {
            $image_url = Fifu_Post_Main_Image_Resolver::get_main_image_url($post_id, true);
            if ($image_url === '' || $image_url === null) {
                $image_url = wp_get_attachment_url(get_post_thumbnail_id($post_id));
                if ($image_url === false) {
                    $image_url = '';
                }
                $border = 'border-color: #ca4a1f !important; border: 2px; border-style: dotted; border-radius: 8px;';
            }

            $url = Fifu_Cdn_Thumbnail_Resolver::get_optimized_thumbnail_url(
                (string) $image_url,
                get_post_thumbnail_id($post_id),
                150,
                1
            );
        } else {
            $video_url = (string) $video;
            $video_src = Fifu_Video_Helper::get_embed_url($video_url);
            $image_url = Fifu_Video_Helper::get_thumbnail_small($video_url);
            $image_url = $image_url ? $image_url : Fifu_Post_Main_Image_Resolver::get_main_image_url($post_id, true);
            $url = Fifu_Cdn_Thumbnail_Resolver::get_optimized_thumbnail_url(
                (string) $image_url,
                get_post_thumbnail_id($post_id),
                150,
                1
            );
        }

        return [
            'border' => $border,
            'height' => $height,
            'width' => $width,
            'video_url' => $video_url,
            'video_src' => $video_src,
            'image_url' => $image_url,
            'url' => $url,
        ];
    }

    public static function get_payload(int $post_id): array
    {
        $payload = [];
        $payload['fifu_image_url'] = Fifu_Post_Image_Url_Read_Service::get_image_url($post_id);
        $payload['fifu_image_alt'] = Fifu_Post_Image_Alt_Read_Service::get_image_alt($post_id);

        [$urls, $alts, $ifms] = self::get_product_gallery_real_payload($post_id);
        $payload['fifu_image_urls'] = $urls;
        $payload['fifu_image_alts'] = $alts;
        $payload['fifu_image_ifms'] = $ifms;
        $payload['fifu_native_image_ids'] = [];
        $payload['fifu_native_image_urls'] = [];
        $payload['fifu_native_image_alts'] = [];
        $payload['fifu_native_image_ifms'] = [];
        $payload['fifu_audio_url'] = Fifu_Post_Audio_Read_Service::get_audio_url($post_id) ?: '';
        $payload['fifu_featured_media_type'] = Fifu_Post_Featured_Media_State_Resolver::resolve_editor_type($post_id);
        $payload['fifu_slider_ratio'] = (string) get_post_meta($post_id, 'fifu_slider_ratio', true);

        if (self::should_hydrate_slider_payload($post_id)) {
            [$sliderUrls, $sliderAlts] = self::get_slider_payload($post_id);
            $payload['fifu_slider_image_urls'] = $sliderUrls;
            $payload['fifu_slider_image_alts'] = $sliderAlts;
        } else {
            $payload['fifu_slider_image_urls'] = [];
            $payload['fifu_slider_image_alts'] = [];
        }

        $video_url = Fifu_Post_Video_Read_Service::get_video_url($post_id);
        $custom_video_url = Fifu_Post_Custom_Video_Read_Service::get_custom_video_url($post_id);
        $is_custom_video = !$video_url && $custom_video_url;

        if ($is_custom_video) {
            $video_url = $custom_video_url;
        }

        if ($video_url) {
            $payload['fifu_video_url'] = $video_url;
            $payload['fifu_video_src'] = Fifu_Video_Helper::get_embed_url($video_url);
        }

        if ($is_custom_video) {
            $poster_url = Fifu_Video_Oembed_Service::instance()
                ->get_repository()
                ->get_image_url_by_video_url((string) $custom_video_url);

            if (is_string($poster_url) && trim($poster_url) !== '') {
                $payload['fifu_image_url'] = trim($poster_url);
            }
        }

        $video_urls = [];
        $video_srcs = [];
        $thumb_urls = [];
        $i = 0;
        while (true) {
            $gallery_video_url = Fifu_Post_Video_Gallery_Read_Service::get_video_url($post_id, $i);
            if (!$gallery_video_url) {
                break;
            }

            $video_urls[] = $gallery_video_url;
            $video_srcs[] = Fifu_Video_Helper::get_embed_url($gallery_video_url);
            $thumb_urls[] = Fifu_Video_Helper::get_thumbnail_large($gallery_video_url);
            $i++;
        }

        $payload['fifu_video_urls'] = $video_urls;
        $payload['fifu_video_srcs'] = $video_srcs;
        $payload['fifu_thumb_urls'] = $thumb_urls;

        $payload['fifu_variable_table'] = null;

        return $payload;
    }

    public static function get_item_response(int $post_id): array
    {
        return [
            'post_id' => $post_id,
            'parent_id' => (int) wp_get_post_parent_id($post_id),
            'display' => self::get_display($post_id),
            'payload' => self::get_payload($post_id),
        ];
    }

    private static function get_product_gallery_real_payload(int $post_id): array
    {
        $db2_urls_by_index = self::get_db2_post_media_urls_by_key_type($post_id, 'image', true);
        if ($db2_urls_by_index !== []) {
            $db2_alts_by_index = self::get_db2_post_media_alts_by_key_type($post_id, 'image');
            $db2_ifms_by_index = self::get_db2_post_media_ifms_by_key_type($post_id, 'image');

            $urls = [];
            $alts = [];
            $ifms = [];
            foreach ($db2_urls_by_index as $index => $url) {
                if ((int) $index < 1) {
                    continue;
                }

                $urls[] = $url;
                $alts[] = $db2_alts_by_index[$index] ?? '';
                $ifms[] = $db2_ifms_by_index[$index] ?? '';
            }

            if ($urls !== []) {
                return [$urls, $alts, $ifms];
            }
        }

        $legacy_payload = self::get_legacy_image_gallery_payload($post_id);
        if ($legacy_payload !== null) {
            return $legacy_payload;
        }

        return [[], [], []];
    }

    private static function get_slider_payload(int $post_id): array
    {
        $urlsByIndex = self::get_db2_post_media_urls_by_key_type($post_id, 'slider', false);
        $altsByIndex = self::get_db2_post_media_alts_by_key_type($post_id, 'slider');

        if ($urlsByIndex === []) {
            $repository = new Fifu_Product_Gallery_Repository();
            $slider_rows = $repository->get_slider_urls($post_id);
            foreach ($slider_rows as $row) {
                if (!is_object($row)) {
                    continue;
                }

                $index = isset($row->index) ? (int) $row->index : (isset($row->key_index) ? (int) $row->key_index : -1);
                $url = trim((string) ($row->url ?? ''));
                if ($index < 0 || $url === '') {
                    continue;
                }

                $urlsByIndex[$index] = $url;
                $altsByIndex[$index] = '';
            }

            if ($urlsByIndex === []) {
                $i = 0;
                while (true) {
                    $slider_url = Fifu_Post_Slider_Image_Url_Read_Service::get_slider_image_url($post_id, $i);
                    if (!$slider_url) {
                        break;
                    }

                    $urlsByIndex[$i] = $slider_url;
                    $altsByIndex[$i] = Fifu_Post_Slider_Image_Alt_Read_Service::get_slider_image_alt($post_id, $i) ?? '';
                    $i++;
                }
            }
        }

        ksort($urlsByIndex);
        ksort($altsByIndex);

        $urls = [];
        $alts = [];
        foreach ($urlsByIndex as $index => $url) {
            $urls[] = $url;
            $alts[] = $altsByIndex[$index] ?? '';
        }

        return [$urls, $alts];
    }

    private static function get_legacy_image_gallery_payload(int $post_id): ?array
    {
        $indexed_urls = [];

        foreach (get_post_meta($post_id) as $meta_key => $values) {
            if (preg_match('/^fifu_image_url_(\d+)$/', (string) $meta_key, $matches) !== 1) {
                continue;
            }

            $index = (int) $matches[1];
            $value = is_array($values) ? reset($values) : $values;
            $url = trim((string) $value);

            if ($url !== '') {
                $indexed_urls[$index] = $url;
            }
        }

        if ($indexed_urls !== []) {
            ksort($indexed_urls, SORT_NUMERIC);

            $urls = [];
            $alts = [];
            $ifms = [];

            foreach ($indexed_urls as $index => $url) {
                $urls[] = $url;
                $alts[] = trim((string) get_post_meta($post_id, 'fifu_image_alt_' . $index, true));
                $ifms[] = trim((string) get_post_meta($post_id, 'fifu_image_ifm_' . $index, true));
            }

            return [$urls, $alts, $ifms];
        }

        $list_urls = self::split_legacy_pipe_list(get_post_meta($post_id, 'fifu_list_url', true));
        if (count($list_urls) <= 1) {
            return null;
        }

        array_shift($list_urls);

        $list_alts = self::split_legacy_pipe_list(get_post_meta($post_id, 'fifu_list_alt', true));
        if ($list_alts !== []) {
            array_shift($list_alts);
        }

        $urls = array_values($list_urls);
        if ($urls === []) {
            return null;
        }

        $alts = [];
        $ifms = [];
        foreach ($urls as $index => $url) {
            $alts[] = $list_alts[$index] ?? '';
            $ifms[] = '';
        }

        return [$urls, $alts, $ifms];
    }

    private static function split_legacy_pipe_list($value): array
    {
        if (!is_string($value) || trim($value) === '') {
            return [];
        }

        return array_values(array_filter(
            array_map(
                static fn($item): string => trim((string) $item),
                explode('|', $value)
            ),
            static fn(string $item): bool => $item !== ''
        ));
    }

    private static function get_db2_post_media_urls_by_key_type(int $post_id, string $key_type, bool $skip_featured_index): array
    {
        if (!function_exists('fifu_db2_manager')) {
            return [];
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return [];
        }

        $mappings = $manager->getPostMappings($post_id, $key_type);
        if (!$mappings) {
            return [];
        }

        usort($mappings, static function (array $left, array $right): int {
            return ((int) ($left['key_index'] ?? 0)) <=> ((int) ($right['key_index'] ?? 0));
        });

        $urls = [];

        foreach ($mappings as $mapping) {
            $index = (int) ($mapping['key_index'] ?? 0);
            if ($skip_featured_index && $index < 1) {
                continue;
            }
            if ($index < 0) {
                continue;
            }

            $url = trim((string) ($mapping['url'] ?? ''));
            if ($url === '') {
                continue;
            }

            $urls[$index] = $url;
        }

        ksort($urls);
        return $urls;
    }

    private static function get_db2_post_media_alts_by_key_type(int $post_id, string $key_type): array
    {
        if (!function_exists('fifu_db2_manager')) {
            return [];
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return [];
        }

        $mappings = $manager->getPostAltMappings($post_id, $key_type);
        if (!$mappings) {
            return [];
        }

        usort($mappings, static function (array $left, array $right): int {
            return ((int) ($left['key_index'] ?? 0)) <=> ((int) ($right['key_index'] ?? 0));
        });

        $altsByIndex = [];
        foreach ($mappings as $mapping) {
            $index = (int) ($mapping['key_index'] ?? 0);
            if ($index < 0) {
                continue;
            }

            $alt = trim((string) ($mapping['alt'] ?? $mapping['url'] ?? ''));
            $altsByIndex[$index] = $alt;
        }

        if (!$altsByIndex) {
            return [];
        }

        ksort($altsByIndex);
        return $altsByIndex;
    }

    private static function get_db2_post_media_ifms_by_key_type(int $post_id, string $key_type): array
    {
        if (!function_exists('fifu_db2_manager')) {
            return [];
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return [];
        }

        $mappings = $manager->getPostMappings($post_id, $key_type);
        if (!$mappings) {
            return [];
        }

        usort($mappings, static function (array $left, array $right): int {
            return ((int) ($left['key_index'] ?? 0)) <=> ((int) ($right['key_index'] ?? 0));
        });

        $ifmsByIndex = [];
        foreach ($mappings as $mapping) {
            $index = (int) ($mapping['key_index'] ?? 0);
            if ($index < 0) {
                continue;
            }

            $ifmsByIndex[$index] = '';
        }

        if (!$ifmsByIndex) {
            return [];
        }

        ksort($ifmsByIndex);
        return $ifmsByIndex;
    }

    private static function should_hydrate_slider_payload(int $post_id): bool
    {
        if (Fifu_Options_Utils::is_on('fifu_slider')) {
            return true;
        }

        if (function_exists('fifu_db2_manager')) {
            $manager = fifu_db2_manager();
            if ($manager instanceof Fifu_Db2_Manager) {
                $mapping = $manager->getPostMapping($post_id, 'slider', 0);
                if (is_array($mapping) && trim((string) ($mapping['url'] ?? '')) !== '') {
                    return true;
                }
            }
        }

        $repository = new Fifu_Product_Gallery_Repository();
        $slider_rows = $repository->get_slider_urls($post_id);
        foreach ($slider_rows as $row) {
            if (!is_object($row)) {
                continue;
            }

            $index = isset($row->index) ? (int) $row->index : (isset($row->key_index) ? (int) $row->key_index : -1);
            $url = trim((string) ($row->url ?? ''));
            if ($index === 0 && $url !== '') {
                return true;
            }
        }

        $slider_url = Fifu_Post_Slider_Image_Url_Read_Service::get_slider_image_url($post_id, 0);
        return $slider_url !== null && trim((string) $slider_url) !== '';
    }
}
