<?php

declare(strict_types=1);

defined('ABSPATH') || exit;

final class Fifu_Admin_Featured_Media_Filter
{
    private const PARAMETER = 'fifu_featured_media';

    private const QUERY_VAR = 'fifu_featured_media_status';

    private const STATUSES = [
        'any',
        'none',
        'image',
        'remote_image',
        'local_image',
        'video',
        'slider',
        'audio',
    ];

    public static function register(): void
    {
        if (!is_user_logged_in() || !current_user_can('publish_posts')) {
            return;
        }

        add_action('restrict_manage_posts', [self::class, 'render_dropdown'], 10, 2);
        add_action('pre_get_posts', [self::class, 'filter_query'], 10, 1);
        add_filter('posts_clauses', [self::class, 'filter_posts_clauses'], 10, 2);
    }

    public static function render_dropdown($postType, $which): void
    {
        if (!is_string($postType) || !is_string($which)) {
            return;
        }
        if ($which !== 'top' || !post_type_supports($postType, 'thumbnail')) {
            return;
        }

        $selected = isset($_REQUEST[self::PARAMETER])
            ? sanitize_key(wp_unslash((string) $_REQUEST[self::PARAMETER]))
            : '';
        echo '<select name="' . esc_attr(self::PARAMETER)
            . '" id="' . esc_attr(self::PARAMETER)
            . '" class="fifu-featured-media-filter"'
            . ' style="min-width: 240px; padding-right: 28px;">';

        echo '<option value="">'
            . esc_html__('All featured media statuses', 'fifu-premium')
            . '</option>';

        echo '<optgroup label="'
            . esc_attr__('Status', 'fifu-premium')
            . '">';
        self::renderOption('any', __('Any featured media', 'fifu-premium'), $selected);
        self::renderOption('none', __('No assigned featured media', 'fifu-premium'), $selected);
        echo '</optgroup>';

        echo '<optgroup label="'
            . esc_attr__('Images', 'fifu-premium')
            . '">';
        self::renderOption('image', __('Featured image', 'fifu-premium'), $selected);
        self::renderOption('remote_image', __('Remote featured image', 'fifu-premium'), $selected);
        self::renderOption('local_image', __('Local featured image', 'fifu-premium'), $selected);
        echo '</optgroup>';

        echo '<optgroup label="'
            . esc_attr__('Other media', 'fifu-premium')
            . '">';
        self::renderOption('video', __('Featured video', 'fifu-premium'), $selected);
        self::renderOption('slider', __('Featured slider', 'fifu-premium'), $selected);
        self::renderOption('audio', __('Featured audio', 'fifu-premium'), $selected);
        echo '</optgroup>';

        echo '</select>';
    }

    private static function renderOption(string $value, string $label, string $selected): void
    {
        printf(
            '<option value="%1$s"%2$s>%3$s</option>',
            esc_attr($value),
            selected($selected, $value, false),
            esc_html($label)
        );
    }

    public static function filter_query($query): void
    {
        if (!$query instanceof WP_Query) {
            return;
        }
        global $pagenow;

        if (!is_admin() || $pagenow !== 'edit.php' || !$query->is_main_query()) {
            return;
        }

        $postType = $query->get('post_type') ?: 'post';
        if (!post_type_supports((string) $postType, 'thumbnail')) {
            return;
        }

        $status = $query->get(self::PARAMETER);

        if ((!is_string($status) || $status === '') && isset($_REQUEST[self::PARAMETER])) {
            $status = wp_unslash((string) $_REQUEST[self::PARAMETER]);
        }

        $status = sanitize_key((string) $status);
        if (in_array($status, self::STATUSES, true)) {
            $query->set(self::QUERY_VAR, $status);
        }
    }

    public static function filter_posts_clauses($clauses, $query)
    {
        if (!is_array($clauses) || !$query instanceof WP_Query) {
            return $clauses;
        }
        $status = $query->get(self::QUERY_VAR);
        if (!is_string($status) || !in_array($status, self::STATUSES, true)) {
            return $clauses;
        }

        $image = self::db2Expression(['image'], 0) . ' OR ' . self::legacyExpression(['fifu_image_url']);
        $remote = '(' . $image . ')';
        $local = self::localImageExpression($remote);
        $featured = '(' . $remote . ' OR ' . $local . ')';
        $video = '('
            . self::db2Expression(['video', 'custom_video'], 0)
            . ' OR '
            . self::legacyExpression(['fifu_video_url', 'fifu_custom_video_url'])
            . ')';
        $slider = '('
            . self::db2Expression(['slider'], 0)
            . ' OR '
            . self::legacyExpression(['fifu_slider_image_url_0'])
            . ')';
        $audio = '('
            . self::db2Expression(['audio'], 0)
            . ' OR '
            . self::legacyExpression(['fifu_audio_url'])
            . ')';
        $any = '(' . implode(' OR ', [$featured, $video, $slider, $audio]) . ')';

        $condition = [
            'any' => $any,
            'none' => 'NOT ' . $any,
            'image' => $featured,
            'remote_image' => $remote,
            'local_image' => $local,
            'video' => $video,
            'slider' => $slider,
            'audio' => $audio,
        ][$status];
        $clauses['where'] .= ' AND (' . $condition . ')';

        return $clauses;
    }

    private static function db2Expression(array $types, ?int $index = null): string
    {
        global $wpdb;
        $typesSql = implode(', ', array_map(static fn (string $type): string => "'" . esc_sql($type) . "'", $types));
        $indexSql = $index === null ? '' : ' AND m.key_index = ' . $index;
        return "EXISTS (SELECT 1 FROM {$wpdb->prefix}fifu_map m INNER JOIN {$wpdb->prefix}fifu_key k ON k.key_id = m.key_id INNER JOIN {$wpdb->prefix}fifu_url u ON u.hash = m.hash WHERE m.post_id = {$wpdb->posts}.ID{$indexSql} AND k.key_type IN ({$typesSql}) AND TRIM(u.url) <> '')";
    }

    private static function legacyExpression(array $keys): string
    {
        global $wpdb;
        $parts = [];
        foreach ($keys as $key) {
            $parts[] = "EXISTS (SELECT 1 FROM {$wpdb->postmeta} pm WHERE pm.post_id = {$wpdb->posts}.ID AND pm.meta_key = '" . esc_sql($key) . "' AND TRIM(pm.meta_value) <> '')";
        }
        return '(' . implode(' OR ', $parts) . ')';
    }

    private static function localImageExpression(string $remote): string
    {
        global $wpdb;
        $author = (int) Fifu_Options_Utils::get_author();
        return "(EXISTS (SELECT 1 FROM {$wpdb->postmeta} thumb INNER JOIN {$wpdb->posts} attachment ON attachment.ID = CAST(thumb.meta_value AS UNSIGNED) WHERE thumb.post_id = {$wpdb->posts}.ID AND thumb.meta_key = '_thumbnail_id' AND CAST(thumb.meta_value AS UNSIGNED) > 0 AND attachment.post_type = 'attachment' AND attachment.post_author <> {$author}) AND NOT {$remote})";
    }
}
