<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('Fifu_Post_Featured_Media_State_Resolver', false)) {
    require_once dirname(__DIR__, 2) . '/includes/meta/class-fifu-post-featured-media-state-resolver.php';
}

/**
 * Coordinator for the featured image column UI inside the admin list tables.
 */
final class Fifu_Admin_Featured_Image_Column
{
    /**
     * Legacy column height guideline that replaces the old FIFU_COLUMN_HEIGHT constant.
     */
    private const COLUMN_HEIGHT = 40;

    /**
     * Registers filters and actions originally wired by the legacy fifu_column() helper.
     */
    public static function register(): void
    {
        if (!is_user_logged_in() || !current_user_can('publish_posts')) {
            return;
        }

        add_filter('manage_posts_columns', [self::class, 'filter_list_table_columns']);
        add_filter('manage_pages_columns', [self::class, 'filter_list_table_columns']);
        add_filter('manage_edit-product_cat_columns', [self::class, 'filter_list_table_columns']);

        self::registerCustomPostTypeColumns();

        add_action('manage_posts_custom_column', [self::class, 'render_post_column'], 10, 2);
        add_action('manage_pages_custom_column', [self::class, 'render_post_column'], 10, 2);
        add_action('manage_product_cat_custom_column', [self::class, 'render_term_column'], 10, 3);
    }

    /**
     * Enqueues the styles/scripts and localization values that were formerly added inside fifu_admin_add_css_js().
     */
    public static function enqueue_assets(): void
    {
        $screen_base = Fifu_Wp_Context::check_screen_base();

        if (!in_array($screen_base, ['list', 'edit', 'new'], true)) {
            return;
        }

        if ($screen_base === 'list' && self::is_featured_image_column_hidden()) {
            return;
        }

        global $pagenow;
        if (!is_admin() || ('edit.php' !== $pagenow && 'post.php' !== $pagenow && 'term.php' !== $pagenow && 'post-new.php' !== $pagenow && 'edit-tags.php' !== $pagenow)) {
            return;
        }

        if (isset($_REQUEST['page']) && strpos($_REQUEST['page'], 'bbapp') !== false) {
            return;
        }

        if (isset($_REQUEST['post'])) {
            $blocked_list = ['wppb-rf-cpt', 'wppb-epf-cpt'];
            $post_id = $_REQUEST['post'];
            $post_type = get_post_type($post_id);
            if (in_array($post_type, $blocked_list, true)) {
                return;
            }
        }

        if (isset($_REQUEST['post_type'])) {
            $blocked_list = ['wppb-rf-cpt', 'wppb-epf-cpt'];
            $post_type = $_REQUEST['post_type'];
            if (in_array($post_type, $blocked_list, true)) {
                return;
            }
        }

        wp_enqueue_style('fancy-box-css', 'https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.css');
        wp_enqueue_script('fancy-box-js', 'https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js');
        wp_enqueue_style('fifu-column-css', plugins_url('/admin/html/css/column.css', FIFU_PLUGIN_FILE), [], Fifu_Plugin_Info::get_enqueue_version());
        wp_enqueue_style('fifu-slider-popup-css', plugins_url('/admin/html/css/slider-popup.css', FIFU_PLUGIN_FILE), [], Fifu_Plugin_Info::get_enqueue_version());
        wp_enqueue_script('fifu-video-util-js', plugins_url('/admin/html/js/video-util.js', FIFU_PLUGIN_FILE), ['jquery'], Fifu_Plugin_Info::get_enqueue_version());
        wp_enqueue_script(
            'fifu-shared-js',
            plugins_url('/admin/html/js/fifu-shared.js', FIFU_PLUGIN_FILE),
            array(),
            Fifu_Plugin_Info::get_enqueue_version()
        );
        wp_register_style('fifu-search-lightbox-css', plugins_url('/admin/html/css/search-lightbox.css', FIFU_PLUGIN_FILE), [], Fifu_Plugin_Info::get_enqueue_version());
        wp_enqueue_style('fifu-search-lightbox-css');
        wp_enqueue_script('fifu-search-lightbox-js', plugins_url('/admin/html/js/search-lightbox.js', FIFU_PLUGIN_FILE), ['jquery'], Fifu_Plugin_Info::get_enqueue_version());

        $fifu = Fifu_Quick_Edit_Strings::get_strings();
        $fifu_help = Fifu_Help_Strings::get_strings();
        $on_products_page = Fifu_Woocommerce_Context::is_products_admin_list();
        $column_dependencies = [
            'jquery',
            'jquery-ui-sortable',
            'fifu-video-util-js',
            'fifu-shared-js',
            'fifu-search-lightbox-js',
        ];

        if ($on_products_page) {
            wp_enqueue_script(
                'fifu-convert-url-js',
                plugins_url('/admin/html/js/convert-url.js', FIFU_PLUGIN_FILE),
                ['jquery'],
                Fifu_Plugin_Info::get_enqueue_version()
            );
            wp_localize_script('fifu-convert-url-js', 'fifuConvertUrlVars', [
                'restUrl' => esc_url_raw(rest_url()),
                'homeUrl' => esc_url_raw(home_url()),
                'nonce' => wp_create_nonce('wp_rest'),
                'partialKey' => Fifu_Options_Utils::partial_key(),
            ]);

            $mixed_strings = Fifu_Meta_Box_Strings::get_featured_image_box_strings();
            wp_enqueue_script(
                'woo-mixed-meta-box-js',
                plugins_url('/admin/html/js/woo-mixed-meta-box.js', FIFU_PLUGIN_FILE),
                [
                    'jquery',
                    'jquery-ui-sortable',
                    'fancy-box-js',
                    'fifu-video-util-js',
                    'fifu-convert-url-js',
                    'fifu-shared-js',
                ],
                Fifu_Plugin_Info::get_enqueue_version()
            );
            wp_localize_script('woo-mixed-meta-box-js', 'fifuMixedGalleryVars', [
                'restUrl' => esc_url_raw(rest_url()),
                'homeUrl' => esc_url_raw(home_url()),
                'nonce' => wp_create_nonce('wp_rest'),
                'images' => [],
                'videos' => [],
                'selectedType' => 'image',
                'videoEnabled' => Fifu_Options_Utils::is_on('fifu_video'),
                'text_image_video_url' => $mixed_strings['placeholder']['image-video'](),
                'text_image_url' => $mixed_strings['image']['url'](),
                'text_video_url' => $mixed_strings['video']['url'](),
                'text_alt' => $mixed_strings['image']['alt'](),
                'text_ifm' => $mixed_strings['image']['ifm'](),
                'text_ok' => $mixed_strings['image']['ok'](),
                'text_remove_image' => $mixed_strings['image']['remove'](),
                'text_remove_video' => $mixed_strings['video']['remove'](),
            ]);
            $column_dependencies[] = 'woo-mixed-meta-box-js';
        }

        wp_enqueue_script(
            'fifu-column-js',
            plugins_url('/admin/html/js/column.js', FIFU_PLUGIN_FILE),
            $column_dependencies,
            Fifu_Plugin_Info::get_enqueue_version()
        );

        wp_localize_script('fifu-video-util-js', 'fifuVideoUtilVars', [
            'uploadDir' => Fifu_Upload_Dir_Utils::get_upload_dir(),
        ]);

        $screen = function_exists('get_current_screen') ? get_current_screen() : null;

        wp_localize_script('fifu-column-js', 'fifuColumnVars', [
            'restUrl' => esc_url_raw(rest_url()),
            'nonce' => wp_create_nonce('wp_rest'),
            'labelImage' => $fifu['title']['image'](),
            'labelVideo' => $fifu['title']['video'](),
            'labelAudio' => $fifu['title']['audio'](),
            'labelImageGallery' => $fifu['title']['gallery']['image'](),
            'labelVideoGallery' => $fifu['title']['gallery']['video'](),
            'labelSlider' => $fifu['title']['slider'](),
            'urlImage' => $fifu['url']['image'](),
            'imageAlt' => $fifu['url']['image_alt'](),
            'urlVideo' => $fifu['url']['video'](),
            'thumbnailOptional' => $fifu['url']['video_thumbnail'](),
            'urlAudio' => $fifu['url']['audio'](),
            'thumbnailAudio' => $fifu['url']['audio_thumbnail'](),
            'sliderRatio' => $fifu['detail']['ratio'](),
            'sliderRatioExample' => $fifu['detail']['eg']() . ' 16:9',
            'buttonSave' => $fifu['button']['save'](),
            'buttonClean' => $fifu['button']['clean'](),
            'buttonPreview' => $fifu['button']['preview'](),
            'buttonRemoveImage' => $fifu['button']['remove_image'](),
            'buttonRemoveAudio' => $fifu['button']['remove_audio'](),
            'isDebugEnabled' => Fifu_Options_Utils::is_on('fifu_debug'),
            'buttonCopyDebugData' => 'Copy debug data',
            'buttonUpload' => $fifu['button']['upload'](),
            'buttonUploading' => $fifu['button']['uploading'](),
            'isAutoSetEnabled' => Fifu_Options_Utils::is_on('fifu_auto_set'),
            'isVideoEnabled' => Fifu_Options_Utils::is_on('fifu_video'),
            'isSliderEnabled' => Fifu_Options_Utils::is_on('fifu_slider'),
            'isUploadEnabled' => Fifu_Options_Utils::is_on('fifu_upload_show'),
            'onProductsPage' => $on_products_page,
            'onCategoriesPage' => Fifu_Woocommerce_Context::is_product_categories_admin_list(),
            'taxonomy' => $screen->taxonomy ?? null,
            'txt_title_examples' => $fifu_help['title']['examples'](),
            'imageAltHelp' => $fifu['alt']['help'](),
            'txt_title_keywords' => $fifu_help['title']['keywords'](),
            'txt_title_more' => $fifu_help['title']['more'](),
            'txt_title_url' => $fifu_help['title']['url'](),
            'txt_title_empty' => $fifu_help['title']['empty'](),
            'txt_desc_more' => $fifu_help['desc']['more'](),
            'txt_desc_url' => $fifu_help['desc']['url'](),
            'txt_desc_keywords' => $fifu_help['desc']['keywords'](),
            'txt_desc_empty' => $fifu_help['desc']['empty'](),
            'txt_loading' => $fifu_help['search']['loading'](),
            'labelVariable' => $fifu['title']['variable']['product'](),
            'labelVariation' => $fifu['title']['variable']['variation'](),
            'labelName' => $fifu['title']['variable']['name'](),
            'labelImageVideoGallery' => $fifu['title']['gallery']['mixed'](),
            'sortableCssUrl' => plugins_url('/admin/html/css/sortable.css', FIFU_PLUGIN_FILE),
            'convertUrlJs' => plugins_url('/admin/html/js/convert-url.js', FIFU_PLUGIN_FILE),
            'fifuVersionNumber' => Fifu_Plugin_Info::get_version(),
        ]);
    }

    /**
     * Prints the footer payload originally emitted by fifu_footer().
     */
    public static function print_footer_quick_edit_payload(): void
    {
        global $FIFU_SESSION;

        if (!empty($FIFU_SESSION['fifu-quick-edit']) || !empty($FIFU_SESSION['fifu-quick-edit-parent'])) {
            wp_enqueue_script('fifu-quick-edit', plugins_url('/admin/html/js/quick-edit.js', FIFU_PLUGIN_FILE), ['jquery'], Fifu_Plugin_Info::get_enqueue_version());
            wp_localize_script('fifu-quick-edit', 'fifuQuickEditVars', [
                'posts' => $FIFU_SESSION['fifu-quick-edit'] ?? null,
                'parent' => $FIFU_SESSION['fifu-quick-edit-parent'] ?? null,
            ]);
        }
    }

    /**
     * Adds the featured image column header as the legacy fifu_column_head() helper used to.
     */
    public static function filter_list_table_columns($columns)
    {
        if (!is_array($columns)) {
            return $columns;
        }
        if (strlen(get_option('fifu_key')) === (pow(2, 4) * 2 + 4)) {
            $fifu = Fifu_Quick_Edit_Strings::get_strings();
            $height = self::COLUMN_HEIGHT;
            $columns['featured_image'] = "<center style='max-width:{$height}px;min-width:{$height}px'><span class='dashicons dashicons-camera' style='font-size:20px; cursor:help;' title='" . esc_attr($fifu['tip']['column']()) . "'></span><div style='display:none'>FIFU</div></center>";
        }

        return $columns;
    }

    /**
     * Renders the featured image column for posts and pages, mirroring the original fifu_column_content().
     */
    public static function render_post_column($column, $post_id): void
    {
        if (!is_string($column)) {
            return;
        }

        $post_id = is_numeric($post_id) ? (int) $post_id : 0;
        if ($post_id <= 0) {
            return;
        }

        if ($column !== 'featured_image' || self::is_featured_image_column_hidden()) {
            return;
        }

        $db2Manager = null;
        if (function_exists('fifu_db2_manager')) {
            $candidate = fifu_db2_manager();
            if ($candidate instanceof Fifu_Db2_Manager) {
                $db2Manager = $candidate;
                $db2Manager->beginPostReadCacheScope();
            }
        }

        try {
            global $FIFU_SESSION;
            $is_variable_product = Fifu_Woocommerce_Context::is_variable_product($post_id);

            if (!$is_variable_product && isset($FIFU_SESSION['fifu-quick-edit'][$post_id])) {
                return;
            }

            $fifu = Fifu_Meta_Box_Strings::get_featured_image_box_strings();
            [$border, $height, $width, $video_url, $video_src, $is_ctgr, $is_variable, $image_url, $url, $vars] = self::buildPostFeaturedPayload(
                $post_id,
                $is_variable_product
            );
            include FIFU_ADMIN_DIR . '/html/column.html';

            if (Fifu_Options_Utils::is_on('fifu_video')) {
                wp_enqueue_script('fifu-video-meta-box-js', plugins_url('/admin/html/js/video-meta-box.js', FIFU_PLUGIN_FILE), ['jquery'], Fifu_Plugin_Info::get_enqueue_version());
                wp_localize_script('fifu-video-meta-box-js', 'fifuVideoMetaBoxVars', [
                    'restUrl' => esc_url_raw(rest_url()),
                    'nonce' => wp_create_nonce('wp_rest'),
                ]);
            }

            $post_ids = [$post_id];

            $FIFU_SESSION['fifu-quick-edit-parent'][$post_id] = null;
            if (class_exists('WooCommerce')) {
                $product = wc_get_product($post_id);
                if ($product) {
                    if ($product->get_type() === 'variable') {
                        $parent_data = [
                            'border' => $border,
                            'height' => $height,
                            'width' => $width,
                            'video-url' => $video_url ?: '',
                            'video-src' => $video_src ?: '',
                            'is-ctgr' => $is_ctgr ?: '',
                            'is-variable' => '',
                            'image-url' => $image_url,
                            'url' => $url,
                        ];
                        $FIFU_SESSION['fifu-quick-edit-parent'][$post_id] = $parent_data;
                        $vars[$post_id]['title'] = $product->get_title();
                    }

                    self::hydrate_product_quick_edit_image_payload((int) $post_id, $vars);

                    wp_enqueue_script('woo-meta-box-js', plugins_url('/admin/html/js/woo-meta-box.js', FIFU_PLUGIN_FILE), ['jquery', 'fifu-shared-js'], Fifu_Plugin_Info::get_enqueue_version());
                    wp_localize_script('woo-meta-box-js', 'fifuBoxImageVars', [
                        'restUrl' => esc_url_raw(rest_url()),
                        'homeUrl' => esc_url_raw(home_url()),
                        'nonce' => wp_create_nonce('wp_rest'),
                        'urls' => [],
                        'alts' => [],
                        'ifms' => [],
                        'nativeIds' => [],
                        'nativeUrls' => [],
                        'nativeAlts' => [],
                        'nativeIfms' => [],
                        'hasRealFifuGallery' => false,
                        'hasNativePreviewGallery' => false,
                        'text_url' => $fifu['image']['url'](),
                        'text_alt' => $fifu['image']['alt'](),
                        'text_ifm' => $fifu['image']['ifm'](),
                        'text_ok' => $fifu['image']['ok'](),
                    ]);

                    if (Fifu_Options_Utils::is_on('fifu_video')) {
                        $vars[$post_id]['fifu_video_url'] = $video_url ?: Fifu_Post_Video_Read_Service::get_video_url((int) $post_id);

                        $video_alt_urls = [];
                        $video_srcs = [];
                        $thumb_urls = [];
                        $i = 0;
                        while (true) {
                            $loop_video_url = Fifu_Post_Video_Gallery_Read_Service::get_video_url((int) $post_id, (int) $i);
                            if (!$loop_video_url) {
                                break;
                            }

                            $loop_video_src = Fifu_Video_Helper::get_embed_url($loop_video_url);
                            $loop_image_url = Fifu_Video_Helper::get_thumbnail_large($loop_video_url);
                            $video_alt_urls[$i] = $loop_video_url;
                            $video_srcs[$i] = $loop_video_src;
                            $thumb_urls[$i] = $loop_image_url;
                            $i++;
                        }
                        $vars[$post_id]['fifu_video_urls'] = $video_alt_urls;
                        $vars[$post_id]['fifu_video_srcs'] = $video_srcs;
                        $vars[$post_id]['fifu_thumb_urls'] = $thumb_urls;

                        wp_enqueue_script('woo-video-meta-box-js', plugins_url('/admin/html/js/woo-video-meta-box.js', FIFU_PLUGIN_FILE), ['jquery'], Fifu_Plugin_Info::get_enqueue_version());
                        wp_localize_script('woo-video-meta-box-js', 'fifuVideoVars', [
                            'restUrl' => esc_url_raw(rest_url()),
                            'homeUrl' => esc_url_raw(home_url()),
                            'nonce' => wp_create_nonce('wp_rest'),
                            'videoUrls' => [],
                            'imageUrls' => [],
                            'text_url' => $fifu['video']['url'](),
                            'text_ok' => $fifu['video']['ok'](),
                        ]);
                    }
                }
            }

            if (self::should_hydrate_slider_payload([$post_id])) {
                self::hydrate_slider_quick_edit_payload([$post_id], $vars);
                wp_enqueue_script('slider-meta-box-js', plugins_url('/admin/html/js/slider-meta-box.js', FIFU_PLUGIN_FILE), ['jquery'], Fifu_Plugin_Info::get_enqueue_version());
                wp_localize_script('slider-meta-box-js', 'fifuSliderVars', [
                    'restUrl' => esc_url_raw(rest_url()),
                    'homeUrl' => esc_url_raw(home_url()),
                    'nonce' => wp_create_nonce('wp_rest'),
                    'urls' => [],
                    'alts' => [],
                    'is_product' => get_post_type() === 'product',
                    'text_image_video_url' => $fifu['placeholder']['image-video'](),
                    'text_video_url' => $fifu['video']['url'](),
                    'text_alt' => $fifu['image']['alt'](),
                    'text_ok' => $fifu['image']['ok'](),
                    'text_remove_slider_item' => $fifu['slider']['remove'](),
                ]);
            }

            $payload = isset($vars[$post_id]) && is_array($vars[$post_id]) ? $vars[$post_id] : [];
            self::merge_quick_edit_payload_into_session($post_id, $payload);
        } finally {
            if ($db2Manager instanceof Fifu_Db2_Manager) {
                $db2Manager->endPostReadCacheScope();
            }
        }
    }

    /**
     * Renders the featured image column for taxonomy rows, porting fifu_ctgr_column_content().
     */
    public static function render_term_column($internal_image, $column, $term_id): void
    {
        if (!is_string($column)) {
            return;
        }

        if ($column !== 'featured_image') {
            echo $internal_image;
            return;
        }

        $term_id = is_numeric($term_id) ? (int) $term_id : 0;
        if ($term_id <= 0) {
            return;
        }

        if (self::is_featured_image_column_hidden()) {
            return;
        }

        global $FIFU_SESSION;

        [$border, $height, $width, $video_url, $video_src, $is_ctgr, $is_variable, $image_url, $url, $vars] = self::buildTermFeaturedPayload($term_id);
        $post_id = $term_id;
        include FIFU_ADMIN_DIR . '/html/column.html';

        $term_ids = [$term_id];
        foreach ($term_ids as $id) {
            $FIFU_SESSION['fifu-quick-edit-ctgr'][$id] = $vars[$id] ?? [];
        }

        wp_enqueue_script('fifu-quick-edit', plugins_url('/admin/html/js/quick-edit.js', FIFU_PLUGIN_FILE), ['jquery'], Fifu_Plugin_Info::get_enqueue_version());
        wp_localize_script('fifu-quick-edit', 'fifuQuickEditCtgrVars', [
            'terms' => $FIFU_SESSION['fifu-quick-edit-ctgr'] ?? [],
        ]);
    }

    /**
     * Adds featured image columns for registered custom post types, replacing fifu_column_custom_post_type().
     */
    private static function registerCustomPostTypeColumns(): void
    {
        foreach (Fifu_Post_Type_Utils::get_post_types() as $post_type) {
            add_filter("manage_edit-{$post_type}_columns", [self::class, 'filter_list_table_columns']);
        }
    }

    private static function is_featured_image_column_hidden(): bool
    {
        if (!function_exists('get_current_screen') || !function_exists('get_hidden_columns')) {
            return false;
        }

        $screen = get_current_screen();

        if (!is_object($screen)) {
            return false;
        }

        return in_array('featured_image', get_hidden_columns($screen), true);
    }

    /**
     * Builds the featured payload previously returned by fifu_column_featured().
     *
     * @return array{0:string,1:int,2:float,3:string|null,4:string|null,5:bool,6:bool,7:string|null,8:string|null,9:array<int,array<string,mixed>>}
     */
    private static function buildPostFeaturedPayload(int $post_id, bool $is_variable): array
    {
        $border = '';
        $height = self::COLUMN_HEIGHT;
        $width = $height * 1.0;
        $video_url = null;
        $video_src = null;
        $is_ctgr = false;
        $image_url = null;
        $vars = [];

        $url = Fifu_Post_Video_Read_Service::get_video_url((int) $post_id);
        $url = $url ?: Fifu_Post_Custom_Video_Read_Service::get_custom_video_url((int) $post_id);
        if ($url === '' || $url === null) {
            $image_url = Fifu_Post_Main_Image_Resolver::get_main_image_url($post_id, true);
            $image_alt = Fifu_Post_Image_Alt_Read_Service::get_image_alt((int) $post_id);
            if ($image_url === '' || $image_url === null) {
                $image_url = wp_get_attachment_url(get_post_thumbnail_id($post_id));
                $border = 'border-color: #ca4a1f !important; border: 2px; border-style: dotted; border-radius: 8px;';
            }

            $url = Fifu_Cdn_Thumbnail_Resolver::get_optimized_thumbnail_url(
                (string) $image_url,
                get_post_thumbnail_id($post_id),
                150,
                1
            );

            $vars[$post_id]['fifu_image_url'] = Fifu_Post_Image_Url_Read_Service::get_image_url((int) $post_id);
            $vars[$post_id]['fifu_image_alt'] = $image_alt;
        } else {
            $video_url = $url;
            $video_src = Fifu_Video_Helper::get_embed_url($video_url);
            $image_url = Fifu_Video_Helper::get_thumbnail_small($url);
            $image_url = $image_url ? $image_url : Fifu_Post_Main_Image_Resolver::get_main_image_url($post_id, true);
            $url = Fifu_Cdn_Thumbnail_Resolver::get_optimized_thumbnail_url(
                (string) $image_url,
                get_post_thumbnail_id($post_id),
                150,
                1
            );

            if (Fifu_Video_Helper::is_custom_video($video_url)) {
                $image_alt = Fifu_Post_Image_Alt_Read_Service::get_image_alt((int) $post_id);
                $vars[$post_id]['fifu_image_url'] = self::get_quick_edit_image_url((int) $post_id);
                $vars[$post_id]['fifu_image_alt'] = $image_alt;
                $vars[$post_id]['fifu_video_url'] = Fifu_Post_Custom_Video_Read_Service::get_custom_video_url((int) $post_id);
            } else {
                $vars[$post_id]['fifu_video_url'] = Fifu_Post_Video_Read_Service::get_video_url((int) $post_id);
            }

            $vars[$post_id]['fifu_video_src'] = $video_src;
        }

        $vars[$post_id]['fifu_audio_url'] = Fifu_Post_Audio_Read_Service::get_audio_url((int) $post_id) ?: '';
        $vars[$post_id]['fifu_featured_media_type'] = Fifu_Post_Featured_Media_State_Resolver::resolve_editor_type((int) $post_id);
        $vars[$post_id]['fifu_slider_ratio'] = (string) get_post_meta((int) $post_id, 'fifu_slider_ratio', true);

        return [$border, $height, $width, $video_url, $video_src, $is_ctgr, $is_variable, $image_url, $url, $vars];
    }

    /**
     * @return array{0:array<int,string>,1:array<int,string>,2:array<int,string>}
     */
    private static function get_product_gallery_real_payload(int $post_id): array
    {
        $db2_urls_by_index = self::get_db2_post_media_urls_by_key_type($post_id, 'image', true);
        if ($db2_urls_by_index !== []) {
            $db2_alts_by_index = self::get_db2_post_media_alts_by_key_type($post_id, 'image');
            $db2_ifms_by_index = self::get_db2_post_media_ifms_by_key_type($post_id, 'image');

            $urls = [];
            $alts = [];
            $ifms = [];
            foreach ($db2_urls_by_index as $index => $url) {
                if ((int) $index < 1) {
                    continue;
                }

                $urls[] = $url;
                $alts[] = $db2_alts_by_index[$index] ?? '';
                $ifms[] = $db2_ifms_by_index[$index] ?? '';
            }

            if ($urls !== []) {
                return [$urls, $alts, $ifms];
            }

            $legacy_payload = self::get_legacy_image_gallery_payload($post_id);
            if ($legacy_payload !== null) {
                return $legacy_payload;
            }

            return [[], [], []];
        }

        $legacy_payload = self::get_legacy_image_gallery_payload($post_id);
        if ($legacy_payload !== null) {
            return $legacy_payload;
        }

        return [[], [], []];
    }

    /**
     * @return array{0:array<int,string>,1:array<int,string>,2:array<int,string>}|null
     */
    private static function get_legacy_image_gallery_payload(int $post_id): ?array
    {
        $indexed_urls = [];

        foreach (get_post_meta($post_id) as $meta_key => $values) {
            if (preg_match('/^fifu_image_url_(\d+)$/', (string) $meta_key, $matches) !== 1) {
                continue;
            }

            $index = (int) $matches[1];
            $value = is_array($values) ? reset($values) : $values;
            $url = trim((string) $value);

            if ($url !== '') {
                $indexed_urls[$index] = $url;
            }
        }

        if ($indexed_urls !== []) {
            ksort($indexed_urls, SORT_NUMERIC);

            $urls = [];
            $alts = [];
            $ifms = [];

            foreach ($indexed_urls as $index => $url) {
                $urls[] = $url;
                $alts[] = trim((string) get_post_meta($post_id, 'fifu_image_alt_' . $index, true));
                $ifms[] = trim((string) get_post_meta($post_id, 'fifu_image_ifm_' . $index, true));
            }

            return [$urls, $alts, $ifms];
        }

        $list_urls = self::split_legacy_pipe_list(get_post_meta($post_id, 'fifu_list_url', true));
        if (count($list_urls) <= 1) {
            return null;
        }

        array_shift($list_urls);

        $list_alts = self::split_legacy_pipe_list(get_post_meta($post_id, 'fifu_list_alt', true));
        if ($list_alts !== []) {
            array_shift($list_alts);
        }

        $urls = array_values($list_urls);
        if ($urls === []) {
            return null;
        }

        $alts = [];
        $ifms = [];
        foreach ($urls as $index => $url) {
            $alts[] = $list_alts[$index] ?? '';
            $ifms[] = '';
        }

        return [$urls, $alts, $ifms];
    }

    /**
     * @param mixed $value
     * @return array<int,string>
     */
    private static function split_legacy_pipe_list($value): array
    {
        if (!is_string($value) || trim($value) === '') {
            return [];
        }

        return array_values(array_filter(
            array_map(
                static fn($item): string => trim((string) $item),
                explode('|', $value)
            ),
            static fn(string $item): bool => $item !== ''
        ));
    }

    /**
     * @return array<int,string>
     */
    private static function get_db2_post_media_urls_by_key_type(int $post_id, string $key_type, bool $skip_featured_index): array
    {
        if (!function_exists('fifu_db2_manager')) {
            return [];
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return [];
        }

        $mappings = $manager->getPostMappings($post_id, $key_type);
        if (!$mappings) {
            return [];
        }

        usort($mappings, static function (array $left, array $right): int {
            return ((int) ($left['key_index'] ?? 0)) <=> ((int) ($right['key_index'] ?? 0));
        });

        $urls = [];

        foreach ($mappings as $mapping) {
            $index = (int) ($mapping['key_index'] ?? 0);
            if ($skip_featured_index && $index < 1) {
                continue;
            }
            if ($index < 0) {
                continue;
            }

            $url = trim((string) ($mapping['url'] ?? ''));
            if ($url === '') {
                continue;
            }

            $urls[$index] = $url;
        }

        ksort($urls);
        return $urls;
    }

    /**
     * @return array<int,string>
     */
    private static function get_db2_post_media_alts_by_key_type(int $post_id, string $key_type): array
    {
        if (!function_exists('fifu_db2_manager')) {
            return [];
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return [];
        }

        $mappings = $manager->getPostAltMappings($post_id, $key_type);
        if (!$mappings) {
            return [];
        }

        usort($mappings, static function (array $left, array $right): int {
            return ((int) ($left['key_index'] ?? 0)) <=> ((int) ($right['key_index'] ?? 0));
        });

        $altsByIndex = [];
        foreach ($mappings as $mapping) {
            $index = (int) ($mapping['key_index'] ?? 0);
            if ($index < 0) {
                continue;
            }

            $alt = trim((string) ($mapping['alt'] ?? $mapping['url'] ?? ''));
            $altsByIndex[$index] = $alt;
        }

        if (!$altsByIndex) {
            return [];
        }

        ksort($altsByIndex);
        return $altsByIndex;
    }

    /**
     * @return array<int,string>
     */
    private static function get_db2_post_media_ifms_by_key_type(int $post_id, string $key_type): array
    {
        if (!function_exists('fifu_db2_manager')) {
            return [];
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return [];
        }

        $mappings = $manager->getPostMappings($post_id, $key_type);
        if (!$mappings) {
            return [];
        }

        usort($mappings, static function (array $left, array $right): int {
            return ((int) ($left['key_index'] ?? 0)) <=> ((int) ($right['key_index'] ?? 0));
        });

        $ifmsByIndex = [];
        foreach ($mappings as $mapping) {
            $index = (int) ($mapping['key_index'] ?? 0);
            if ($index < 0) {
                continue;
            }

            $ifmsByIndex[$index] = '';
        }

        if (!$ifmsByIndex) {
            return [];
        }

        ksort($ifmsByIndex);
        return $ifmsByIndex;
    }

    /**
     * @param array<int,int> $post_ids
     */
    private static function should_hydrate_slider_payload(array $post_ids): bool
    {
        if (Fifu_Options_Utils::is_on('fifu_slider')) {
            return true;
        }

        foreach ($post_ids as $post_id) {
            if (function_exists('fifu_db2_manager')) {
                $manager = fifu_db2_manager();
                if ($manager instanceof Fifu_Db2_Manager) {
                    $mapping = $manager->getPostMapping((int) $post_id, 'slider', 0);
                    if (is_array($mapping) && trim((string) ($mapping['url'] ?? '')) !== '') {
                        return true;
                    }
                }
            }

            $repository = new Fifu_Product_Gallery_Repository();
            $slider_rows = $repository->get_slider_urls((int) $post_id);
            foreach ($slider_rows as $row) {
                if (!is_object($row)) {
                    continue;
                }

                $index = isset($row->index) ? (int) $row->index : (isset($row->key_index) ? (int) $row->key_index : -1);
                $url = trim((string) ($row->url ?? ''));
                if ($index === 0 && $url !== '') {
                    return true;
                }
            }

            $slider_url = Fifu_Post_Slider_Image_Url_Read_Service::get_slider_image_url((int) $post_id, 0);
            if ($slider_url !== null && trim((string) $slider_url) !== '') {
                return true;
            }
        }

        return false;
    }

    private static function get_quick_edit_image_url(int $post_id): ?string
    {
        $provider_video_url =
            Fifu_Post_Video_Read_Service::get_video_url($post_id);

        $custom_video_url =
            Fifu_Post_Custom_Video_Read_Service::get_custom_video_url(
                $post_id
            );

        $is_custom_video =
            !$provider_video_url
            && $custom_video_url;

        if ($is_custom_video) {
            $poster_url =
                Fifu_Video_Oembed_Service::instance()
                    ->get_repository()
                    ->get_image_url_by_video_url(
                        (string) $custom_video_url
                    );

            if (
                is_string($poster_url)
                && trim($poster_url) !== ''
            ) {
                return trim($poster_url);
            }
        }

        return Fifu_Post_Image_Url_Read_Service::get_image_url(
            $post_id
        );
    }

    /**
     * @param array<int,array<string,mixed>> $vars
     */
    private static function hydrate_product_quick_edit_image_payload(int $post_id, array &$vars): void
    {
        $vars[$post_id] = $vars[$post_id] ?? [];
        $vars[$post_id]['fifu_image_url'] = self::get_quick_edit_image_url((int) $post_id);
        $vars[$post_id]['fifu_image_alt'] = Fifu_Post_Image_Alt_Read_Service::get_image_alt((int) $post_id);

        [$urls, $alts, $ifms] = self::get_product_gallery_real_payload((int) $post_id);

        $vars[$post_id]['fifu_image_urls'] = $urls;
        $vars[$post_id]['fifu_image_alts'] = $alts;
        $vars[$post_id]['fifu_image_ifms'] = $ifms;
        $vars[$post_id]['fifu_native_image_ids'] = [];
        $vars[$post_id]['fifu_native_image_urls'] = [];
        $vars[$post_id]['fifu_native_image_alts'] = [];
        $vars[$post_id]['fifu_native_image_ifms'] = [];
        $vars[$post_id]['fifu_audio_url'] = Fifu_Post_Audio_Read_Service::get_audio_url((int) $post_id) ?: '';
        $vars[$post_id]['fifu_featured_media_type'] = Fifu_Post_Featured_Media_State_Resolver::resolve_editor_type((int) $post_id);
    }

    /**
     * @param array<int,int> $post_ids
     * @param array<int,array<string,mixed>> $vars
     */
    private static function hydrate_slider_quick_edit_payload(array $post_ids, array &$vars): void
    {
        foreach ($post_ids as $post_id) {
            $vars[$post_id] = $vars[$post_id] ?? [];
            $urlsByIndex = self::get_db2_post_media_urls_by_key_type((int) $post_id, 'slider', false);
            $altsByIndex = self::get_db2_post_media_alts_by_key_type((int) $post_id, 'slider');

            if ($urlsByIndex === []) {
                $repository = new Fifu_Product_Gallery_Repository();
                $slider_rows = $repository->get_slider_urls((int) $post_id);
                foreach ($slider_rows as $row) {
                    if (!is_object($row)) {
                        continue;
                    }

                    $index = isset($row->index) ? (int) $row->index : (isset($row->key_index) ? (int) $row->key_index : -1);
                    $url = trim((string) ($row->url ?? ''));
                    if ($index < 0 || $url === '') {
                        continue;
                    }

                    $urlsByIndex[$index] = $url;
                    $altsByIndex[$index] = '';
                }

                if ($urlsByIndex === []) {
                    $i = 0;
                    while (true) {
                        $slider_url = Fifu_Post_Slider_Image_Url_Read_Service::get_slider_image_url(
                            (int) $post_id,
                            (int) $i
                        );
                        if (!$slider_url) {
                            break;
                        }

                        $urlsByIndex[$i] = $slider_url;
                        $altsByIndex[$i] = Fifu_Post_Slider_Image_Alt_Read_Service::get_slider_image_alt((int) $post_id, (int) $i) ?? '';
                        $i++;
                    }
                }
            }

            ksort($urlsByIndex);
            ksort($altsByIndex);

            $urls = [];
            $alts = [];
            foreach ($urlsByIndex as $index => $url) {
                $urls[] = $url;
                $alts[] = $altsByIndex[$index] ?? '';
            }

            $vars[$post_id]['fifu_slider_image_urls'] = $urls;
            $vars[$post_id]['fifu_slider_image_alts'] = $alts;
            $vars[$post_id]['fifu_slider_ratio'] = (string) get_post_meta((int) $post_id, 'fifu_slider_ratio', true);
        }
    }

    private static function merge_quick_edit_payload_into_session(int $post_id, array $payload): void
    {
        global $FIFU_SESSION;

        if (!isset($FIFU_SESSION) || !is_array($FIFU_SESSION)) {
            $FIFU_SESSION = [];
        }

        if (!isset($FIFU_SESSION['fifu-quick-edit']) || !is_array($FIFU_SESSION['fifu-quick-edit'])) {
            $FIFU_SESSION['fifu-quick-edit'] = [];
        }

        if (!isset($FIFU_SESSION['fifu-quick-edit'][$post_id]) || !is_array($FIFU_SESSION['fifu-quick-edit'][$post_id])) {
            $FIFU_SESSION['fifu-quick-edit'][$post_id] = [];
        }

        if (
            (
                (!isset($payload['fifu_image_urls']) || $payload['fifu_image_urls'] === [])
                && (!isset($payload['fifu_slider_image_urls']) || $payload['fifu_slider_image_urls'] === [])
            )
            && function_exists('get_post_type')
        ) {
            $hydrated = [$post_id => []];
            self::hydrate_product_quick_edit_image_payload($post_id, $hydrated);
            if (self::should_hydrate_slider_payload([$post_id])) {
                self::hydrate_slider_quick_edit_payload([$post_id], $hydrated);
            }
            $payload = array_replace($payload, $hydrated[$post_id] ?? []);
        }

        foreach (['fifu_image_urls', 'fifu_image_alts', 'fifu_image_ifms', 'fifu_slider_image_urls', 'fifu_slider_image_alts'] as $key) {
            if (array_key_exists($key, $payload) && $payload[$key] !== []) {
                $FIFU_SESSION['fifu-quick-edit'][$post_id][$key] = $payload[$key];
                continue;
            }

            if (!array_key_exists($key, $FIFU_SESSION['fifu-quick-edit'][$post_id])) {
                $FIFU_SESSION['fifu-quick-edit'][$post_id][$key] = $payload[$key] ?? [];
            }
        }

        foreach ($payload as $key => $value) {
            if (in_array($key, ['fifu_image_urls', 'fifu_image_alts', 'fifu_image_ifms', 'fifu_slider_image_urls', 'fifu_slider_image_alts'], true)) {
                continue;
            }

            if (!array_key_exists($key, $FIFU_SESSION['fifu-quick-edit'][$post_id]) || $value !== []) {
                $FIFU_SESSION['fifu-quick-edit'][$post_id][$key] = $value;
            }
        }
    }

    /**
     * Builds the featured payload for taxonomy rows that the legacy fifu_ctgr_column_featured() returned.
     *
     * @return array{0:string,1:int,2:float,3:string|null,4:string|null,5:bool,6:bool,7:string|null,8:string|null,9:array<int,array<string,mixed>>}
     */
    private static function buildTermFeaturedPayload(int $term_id): array
    {
        $border = '';
        $height = self::COLUMN_HEIGHT;
        $width = $height * 1.0;
        $video_url = null;
        $video_src = null;
        $is_ctgr = true;
        $is_variable = false;
        $image_url = null;
        $vars = [];

            $url = Fifu_Term_Video_Read_Service::get_video_url((int) $term_id);
            $url = $url ?: Fifu_Term_Custom_Video_Read_Service::get_custom_video_url((int) $term_id);
            if ($url === '' || $url === null) {
            $image_url = Fifu_Term_Image_Url_Read_Service::get_image_url((int) $term_id);
            $image_alt = Fifu_Term_Image_Alt_Read_Service::get_image_alt((int) $term_id);
            if ($image_url === '' || $image_url === null) {
                $thumb_id = get_term_meta($term_id, 'thumbnail_id', true);
                $image_url = wp_get_attachment_url($thumb_id);
                if ($image_url === false) {
                    $image_url = '';
                }
                $border = 'border-color: #ca4a1f !important; border: 2px; border-style: dotted; border-radius: 8px;';
            }

            $url = Fifu_Cdn_Thumbnail_Resolver::get_optimized_thumbnail_url(
                (string) $image_url,
                Fifu_Post_Meta_Utils::get_term_thumbnail_id($term_id),
                150,
                1
            );

            $vars[$term_id]['fifu_image_url'] = $image_url;
            $vars[$term_id]['fifu_image_alt'] = $image_alt;
        } else {
            $video_url = $url;
            $video_src = Fifu_Video_Helper::get_embed_url($video_url);
            $image_url = Fifu_Video_Helper::get_thumbnail_small($url);
            $image_url = $image_url ? $image_url : Fifu_Term_Image_Url_Read_Service::get_image_url((int) $term_id);
            $url = Fifu_Cdn_Thumbnail_Resolver::get_optimized_thumbnail_url(
                (string) $image_url,
                Fifu_Post_Meta_Utils::get_term_thumbnail_id($term_id),
                150,
                1
            );

            if (Fifu_Video_Helper::is_custom_video($video_url)) {
                $image_alt = Fifu_Term_Image_Alt_Read_Service::get_image_alt((int) $term_id);
                $vars[$term_id]['fifu_image_url'] = Fifu_Term_Image_Url_Read_Service::get_image_url((int) $term_id);
                $vars[$term_id]['fifu_image_alt'] = $image_alt;
                $vars[$term_id]['fifu_video_url'] = Fifu_Term_Custom_Video_Read_Service::get_custom_video_url((int) $term_id);
            } else {
                $vars[$term_id]['fifu_video_url'] = Fifu_Term_Video_Read_Service::get_video_url((int) $term_id);
            }

            $vars[$term_id]['fifu_video_src'] = $video_src;
        }

        return [$border, $height, $width, $video_url, $video_src, $is_ctgr, $is_variable, $image_url, $url, $vars];
    }

    /**
     * Builds the HTML table that represents variation data, mirroring fifu_array_to_sorted_html_table().
     */
    private static function buildVariationTableHtml(array $data, int $post_id): string
    {
        global $FIFU_SESSION;

        $html = '';
        $first_item = reset($data);
        $columns = $first_item ? array_keys($first_item) : [];
        if ($columns) {
            array_unshift($columns, 'ID');
            array_push($columns, '<center><span class="dashicons dashicons-camera" style="font-size:20px; text-align:right"></span></center>');
            uasort($data, function ($a, $b) {
                foreach ($a as $key => $value) {
                    if (isset($a[$key]) && isset($b[$key])) {
                        if ($a[$key] !== $b[$key]) {
                            return $a[$key] <=> $b[$key];
                        }
                    }
                }
                return 0;
            });
        }

        $html .= '<table id="fifu-variable-table" style="text-align:left; width:100%" post-parent="' . $post_id . '"><tbody>';
        $html .= '<tr class="color">';
        foreach ($columns as $col) {
            if (strpos($col, 'ID') !== false) {
                $html .= "<th style=\"width:64px\">$col</th>";
            } elseif (strpos($col, 'dashicons-camera') !== false) {
                $html .= "<th style=\"width:40px\">$col</th>";
            } else {
                $html .= "<th style=\"min-width:100px\">$col</th>";
            }
        }
        $html .= '</tr>';

        foreach ($data as $id => $attributes) {
            $html .= '<tr class="color">';
            $html .= "<td>$id</td>";
            foreach ($columns as $col) {
                if ($col !== 'ID') {
                    if (strpos($col, 'dashicons-camera') !== false) {
                        [$border, $height, $width, $video_url, $video_src, $is_ctgr, $is_variable, $image_url, $url, $vars] = self::buildPostFeaturedPayload($id, false);
                        $variation_id = (int) $id;
                        clean_post_cache($variation_id);
                        wp_cache_delete($variation_id, 'post_meta');
                        self::hydrate_product_quick_edit_image_payload($variation_id, $vars);
                        if (self::should_hydrate_slider_payload([$variation_id])) {
                            self::hydrate_slider_quick_edit_payload([$variation_id], $vars);
                        }
                        $payload = isset($vars[$variation_id]) && is_array($vars[$variation_id]) ? $vars[$variation_id] : [];
                        self::merge_quick_edit_payload_into_session($variation_id, $payload);
                        $html .= "
                            <td>
                                <div
                                    class=\"fifu-quick\"
                                    post-id=\"{$id}\"
                                    video-url=\"{$video_url}\"
                                    video-src=\"{$video_src}\"
                                    is-ctgr=\"{$is_ctgr}\"
                                    image-url=\"{$image_url}\"
                                    is-variable=\"{$is_variable}\"
                                    style=\"height: {$height}px; width: {$height}px; background:url('{$url}') no-repeat center center; background-size:cover; {$border}; cursor:pointer;\"
                                ></div>
                            </td>
                        ";
                    } else {
                        $html .= '<td>' . ($attributes[$col] ?? '') . '</td>';
                    }
                }
            }
            $html .= '</tr>';
        }

        $html .= '</tbody></table>';

        return $html;
    }

}
