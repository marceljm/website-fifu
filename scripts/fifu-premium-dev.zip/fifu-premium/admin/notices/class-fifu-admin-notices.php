<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

final class Fifu_Admin_Notices
{
    public static function register_hooks(): void
    {
        add_action('admin_notices', [self::class, 'display_expired_notice']);
        add_action('admin_enqueue_scripts', [self::class, 'enqueue_admin_scripts']);
        add_action('wp_ajax_fifu_dismiss_expired_notice', [self::class, 'ajax_dismiss_expired_notice']);
    }

    public static function display_expired_notice(): void
    {
        $fifu = Fifu_Notice_Strings::get_strings();
        if (get_option('fifu_key') && get_option('fifu_expired') && !get_option('fifu_expired_notice_dismissed')) {
            echo '<div class="notice notice-error is-dismissible" id="fifu-license-expired-notice"><p><span class="dashicons dashicons-camera"></span> <b>FIFU</b>: ' . $fifu['notice']['expired']() . ' <a href="' . esc_url(get_admin_url(null, 'admin.php?page=fifu-license-key')) . '" style="text-decoration:none"><span class="dashicons dashicons-update"></span></a></p></div>';
        }

        if (!get_option('fifu_key')) {
            echo '<div class="notice notice-error is-dismissible"><p><span class="dashicons dashicons-camera"></span> <b>FIFU</b>: ' . $fifu['notice']['key']() . ' <a href="' . esc_url(get_admin_url(null, 'admin.php?page=fifu-license-key')) . '" style="text-decoration:none"><span class="dashicons dashicons-admin-network"></span></a></p></div>';
        }
    }

    public static function enqueue_admin_scripts($hook): void
    {
        $has_key = (bool) get_option('fifu_key');
        $is_expired = (bool) get_option('fifu_expired');
        $dismissed = (bool) get_option('fifu_expired_notice_dismissed');

        if ($has_key && $is_expired && !$dismissed) {
            wp_enqueue_script(
                'fifu-notices',
                plugins_url('/admin/html/js/notices.js', FIFU_PLUGIN_FILE),
                array('jquery'),
                Fifu_Plugin_Info::get_enqueue_version()
            );
            wp_localize_script('fifu-notices', 'fifuAjax', array(
                'ajaxurl' => admin_url('admin-ajax.php'),
                'nonce'   => wp_create_nonce('fifu_dismiss_expired_nonce'),
            ));
        }
    }

    public static function ajax_dismiss_expired_notice(): void
    {
        check_ajax_referer('fifu_dismiss_expired_nonce', 'nonce');
        update_option('fifu_expired_notice_dismissed', true);
        wp_send_json_success();
    }
}
