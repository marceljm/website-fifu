<?php
declare(strict_types=1);

require_once __DIR__ . '/class-fifu-db2-identifier-value-helper.php';

/**
 * Observes legacy identifier meta changes and mirrors them into DB2.
 */
class Fifu_Db2_Identifier_Replication_Service {
    private Fifu_Db2_Identifier_Repository $repository;

    private const META_TO_TYPE = [
        'fifu_asin' => 'asin',
    ];

    public function __construct(Fifu_Db2_Identifier_Repository $repository) {
        $this->repository = $repository;
        $this->register_hooks();
    }

    private function register_hooks(): void {
        add_action('added_post_meta', [$this, 'handle_meta_added'], 10, 4);
        add_action('updated_post_meta', [$this, 'handle_meta_updated'], 10, 4);
        add_action('deleted_post_meta', [$this, 'handle_meta_deleted'], 10, 4);
    }

    public function handle_meta_added($metaId, $postId, $metaKey, $metaValue): void {
        unset($metaId);
        $postId = is_numeric($postId) ? (int) $postId : 0;
        if ($postId <= 0 || !is_string($metaKey)) {
            return;
        }
        $this->maybe_sync_identifier($postId, $metaKey, $metaValue);
    }

    public function handle_meta_updated($metaId, $postId, $metaKey, $metaValue): void {
        unset($metaId);
        $postId = is_numeric($postId) ? (int) $postId : 0;
        if ($postId <= 0 || !is_string($metaKey)) {
            return;
        }
        $this->maybe_sync_identifier($postId, $metaKey, $metaValue);
    }

    public function handle_meta_deleted($metaIds, $postId, $metaKey, $_meta_value): void {
        unset($metaIds, $_meta_value);
        $postId = is_numeric($postId) ? (int) $postId : 0;
        if ($postId <= 0 || !is_string($metaKey)) {
            return;
        }
        $this->delete_identifier($postId, $metaKey);
    }

    private function maybe_sync_identifier(int $postId, string $metaKey, $rawValue): void {
        if (!empty($GLOBALS['__fifu_skip_db2_identifier_replication'])) {
            return;
        }

        if ($postId <= 0) {
            return;
        }

        $typeKey = self::META_TO_TYPE[$metaKey] ?? null;
        if ($typeKey === null) {
            return;
        }

        $parsed = Fifu_Db2_Identifier_Value_Helper::parse($rawValue);
        if ($parsed['value'] === '') {
            $this->repository->delete_post_identifier($postId, $typeKey);
            return;
        }

        $this->repository->upsert_post_identifier($postId, $typeKey, $parsed['value'], $parsed['invalid'], $parsed['not_found']);
    }

    private function delete_identifier(int $postId, string $metaKey): void {
        if (!empty($GLOBALS['__fifu_skip_db2_identifier_replication'])) {
            return;
        }

        if ($postId <= 0) {
            return;
        }

        $typeKey = self::META_TO_TYPE[$metaKey] ?? null;
        if ($typeKey === null) {
            return;
        }

        $this->repository->delete_post_identifier($postId, $typeKey);
    }
}
