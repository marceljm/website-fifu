<?php
declare(strict_types=1);

defined('ABSPATH') || exit;

/**
 * Orchestrates DB2 speed-up operations for FIFU Premium.
 */
final class Fifu_Db2_Speed_Up_Service
{
    private Fifu_Db2_Speed_Up_Repository $repository;

    /**
     * @param Fifu_Db2_Speed_Up_Repository $repository
     */
    public function __construct(Fifu_Db2_Speed_Up_Repository $repository)
    {
        $this->repository = $repository;
    }

    /**
     * Speed up URLs for a given bucket and list of thumbnails (posts).
     *
     * Mirrors the behavior of admin/db.php::add_urls_su().
     *
     * @param string|int   $bucket_id
     * @param array $thumbnails
     * @return void
     */
    public function add_urls(string|int $bucket_id, array $thumbnails): void
    {
        $repository = $this->repository;
        $repository->speed_up_custom_fields($bucket_id, $thumbnails, false);

        $featured_list = [];
        $gallery_list = [];
        foreach ($thumbnails as $thumbnail) {
            if (
                isset($thumbnail->meta_key)
                && in_array(
                    $thumbnail->meta_key,
                    ['fifu_image_url', 'fifu_slider_image_url_0', 'fifu_video_url'],
                    true
                )
            ) {
                $featured_list[] = $thumbnail;
            } else {
                $gallery_list[] = $thumbnail;
            }
        }

        if (!empty($featured_list)) {
            $att_ids_map = $repository->get_thumbnail_ids($featured_list, false);
            if (!empty($att_ids_map)) {
                $repository->speed_up_attachments($bucket_id, $featured_list, $att_ids_map);
                $meta_ids_map = $repository->get_thumbnail_meta_ids($featured_list, $att_ids_map);
                if (!empty($meta_ids_map)) {
                    $repository->speed_up_attachments_meta($bucket_id, $featured_list, $meta_ids_map);
                }
            }
        }

        if (!empty($gallery_list)) {
            $att_ids_map = $repository->get_thumbnail_ids_gallery($gallery_list, false);
            if (!empty($att_ids_map)) {
                $repository->speed_up_attachments($bucket_id, $gallery_list, $att_ids_map);
                $meta_ids_map = $repository->get_thumbnail_meta_ids($gallery_list, $att_ids_map);
                if (!empty($meta_ids_map)) {
                    $repository->speed_up_attachments_meta($bucket_id, $gallery_list, $meta_ids_map);
                }
            }
        }

        $list_ids_map = $repository->get_list_ids($thumbnails, $bucket_id, false, null);
        $repository->speed_up_list_custom_fields($bucket_id, $thumbnails, $list_ids_map);
        $this->sync_tmp_product_gallery_snapshots($thumbnails);
    }

    /**
     * Migrates complete legacy media state for posts before Cloud uploads individual URLs.
     *
     * @param int[] $postIds
     * @return void
     */
    public function migrate_posts_legacy_media_state_before_cloud_upload(array $postIds): void
    {
        $this->repository->migrate_posts_legacy_media_state_before_cloud_upload($postIds);
    }

    /**
     * Consumes temporary WooCommerce gallery snapshots after a successful post upload.
     *
     * The Cloud upload pipeline does not go through the REST save hooks that normally
     * call sync_gallery_attachments(), so products can keep fifu_tmp_product_image_gallery
     * unless we trigger the same sync explicitly here.
     *
     * @param array $thumbnails
     * @return void
     */
    private function sync_tmp_product_gallery_snapshots(array $thumbnails): void
    {
        $post_ids = [];
        foreach ($thumbnails as $thumbnail) {
            $post_id = (int) ($thumbnail->post_id ?? 0);
            if ($post_id <= 0) {
                continue;
            }

            $post_ids[$post_id] = true;
        }

        $this->sync_tmp_product_gallery_snapshots_for_post_ids(array_keys($post_ids));
    }

    /**
     * Expands snapshot candidate IDs to include variation parents when needed.
     *
     * @param int[] $postIds
     * @return int[]
     */
    private function expand_tmp_product_gallery_snapshot_post_ids(array $postIds): array
    {
        $candidate_post_ids = [];
        foreach ($postIds as $post_id) {
            $post_id = (int) $post_id;
            if ($post_id <= 0) {
                continue;
            }

            $candidate_post_ids[$post_id] = true;

            if ((string) get_post_type($post_id) !== 'product_variation') {
                continue;
            }

            $parent_id = (int) wp_get_post_parent_id($post_id);
            if ($parent_id > 0) {
                $candidate_post_ids[$parent_id] = true;
            }
        }

        return array_keys($candidate_post_ids);
    }

    /**
     * Consumes temporary WooCommerce gallery snapshots for the provided posts.
     *
     * When a variation post participates in the flow, its parent product is also
     * considered because the temporary gallery snapshot can live on the parent.
     *
     * @param int[] $postIds
     * @return void
     */
    private function sync_tmp_product_gallery_snapshots_for_post_ids(array $postIds): void
    {
        if (!class_exists('Fifu_Post_Attachment_Sync_Service')) {
            return;
        }

        $candidatePostIds = $this->expand_tmp_product_gallery_snapshot_post_ids($postIds);
        if ($candidatePostIds === []) {
            return;
        }

        $snapshotPostIds = $this->repository->get_post_ids_with_tmp_product_gallery_snapshots($candidatePostIds);
        if ($snapshotPostIds === []) {
            return;
        }

        $candidatePostIdLookup = array_fill_keys(array_map('intval', $candidatePostIds), true);

        foreach ($snapshotPostIds as $post_id) {
            $post_id = (int) $post_id;
            if ($post_id <= 0 || !isset($candidatePostIdLookup[$post_id])) {
                continue;
            }

            $post_type = (string) get_post_type($post_id);
            if ($post_type !== 'product' && $post_type !== 'product_variation') {
                continue;
            }

            clean_post_cache($post_id);

            /*
             * Keep the final non-empty check for safety. The repository bulk lookup
             * prevents scanning every post; this only verifies the small set that
             * actually reported a temporary snapshot.
             */
            $tmp_gallery_csv = trim((string) get_post_meta($post_id, 'fifu_tmp_product_image_gallery', true));
            if ($tmp_gallery_csv === '') {
                continue;
            }

            Fifu_Post_Attachment_Sync_Service::sync_gallery_attachments($post_id);
        }
    }

    /**
     * Removes temporary WooCommerce gallery snapshots after the rollback is done.
     *
     * The delete/rollback flow already restored the local gallery IDs, so it only
     * needs to discard the transient snapshot stored on the product parent/owner.
     *
     * @param int[] $postIds
     * @return void
     */
    private function clear_tmp_product_gallery_snapshots_for_post_ids(array $postIds): void
    {
        foreach ($this->expand_tmp_product_gallery_snapshot_post_ids($postIds) as $post_id) {
            $post_type = (string) get_post_type($post_id);
            if ($post_type !== 'product' && $post_type !== 'product_variation') {
                continue;
            }

            delete_post_meta($post_id, 'fifu_tmp_product_image_gallery');
        }
    }

    /**
     * Speed up URLs for a given bucket and list of thumbnails (categories).
     *
     * Mirrors the behavior of admin/db.php::ctgr_add_urls_su().
     *
     * @param string|int   $bucket_id
     * @param array $thumbnails
     * @return void
     */
    public function add_category_urls(string|int $bucket_id, array $thumbnails): void
    {
        $repository = $this->repository;
        $repository->speed_up_custom_fields($bucket_id, $thumbnails, true);

        $featured_list = [];
        foreach ($thumbnails as $thumbnail) {
            $featured_list[] = $thumbnail;
        }

        if (!empty($featured_list)) {
            $att_ids_map = $repository->get_thumbnail_ids($featured_list, true);
            if (!empty($att_ids_map)) {
                $repository->speed_up_attachments($bucket_id, $featured_list, $att_ids_map);
                $meta_ids_map = $repository->get_thumbnail_meta_ids($featured_list, $att_ids_map);
                if (!empty($meta_ids_map)) {
                    $repository->speed_up_attachments_meta($bucket_id, $featured_list, $meta_ids_map);
                }
            }
        }
    }

    /**
     * Orchestrates the rollback of speed up changes for posts using the repository.
     *
     * @param string|int $bucketId
     * @param array $thumbnails
     * @param array $urls
     * @param array $videoUrls
     * @param array $attachmentIdsMap
     * @param array $metaIdsMap
     * @param array $listIdsMap
     * @return void
     */
    public function revert_posts_speed_up(
        string|int $bucketId,
        array $thumbnails,
        array $urls,
        array $videoUrls,
        array $attachmentIdsMap,
        array $metaIdsMap,
        array $listIdsMap
    ): void {
        $repository = $this->repository;

        $repository->revert_custom_fields($thumbnails, $urls, $videoUrls, false);

        if (!empty($attachmentIdsMap)) {
            $repository->revert_attachments($urls, $videoUrls, $thumbnails, $attachmentIdsMap);
        }

        if (!empty($metaIdsMap)) {
            $repository->revert_attachments_meta($urls, $videoUrls, $thumbnails, $metaIdsMap);
        }

        if (!empty($listIdsMap)) {
            $repository->revert_list_custom_fields($bucketId, $urls, $videoUrls, $thumbnails, $listIdsMap);
        }
    }

    /**
     * Orchestrates the rollback of speed up changes for terms using the repository.
     *
     * @param string|int $bucketId
     * @param array $thumbnails
     * @param array $urls
     * @param array $videoUrls
     * @param array $attachmentIdsMap
     * @param array $metaIdsMap
     * @param array $listIdsMap
     * @return void
     */
    public function revert_terms_speed_up(
        string|int $bucketId,
        array $thumbnails,
        array $urls,
        array $videoUrls,
        array $attachmentIdsMap,
        array $metaIdsMap,
        array $listIdsMap = []
    ): void {
        $repository = $this->repository;

        $repository->revert_custom_fields($thumbnails, $urls, $videoUrls, true);

        if (!empty($attachmentIdsMap)) {
            $repository->revert_attachments($urls, $videoUrls, $thumbnails, $attachmentIdsMap);
        }

        if (!empty($metaIdsMap)) {
            $repository->revert_attachments_meta($urls, $videoUrls, $thumbnails, $metaIdsMap);
        }

        if (!empty($listIdsMap)) {
            $repository->revert_list_custom_fields($bucketId, $urls, $videoUrls, $thumbnails, $listIdsMap);
        }
    }

    /**
     * Prepare post-level removals for speed-up rollback.
     *
     * @param string|int   $bucketId
     * @param array $thumbnails
     * @param array $urls
     * @param array $videoUrls
     */
    public function remove_post_urls(string|int $bucketId, array $thumbnails, array $urls, array $videoUrls): void
    {
        foreach ($thumbnails as $thumbnail) {
            if (empty($thumbnail->meta_id ?? null)) {
                $storageId = $thumbnail->storage_id ?? null;
                unset($urls[$storageId], $videoUrls[$storageId]);
            }
        }

        if (empty($urls) && empty($videoUrls)) {
            return;
        }

        $featuredList = [];
        $galleryList = [];
        foreach ($thumbnails as $thumbnail) {
            $metaKey = $thumbnail->meta_key ?? '';
            if (in_array($metaKey, ['fifu_image_url', 'fifu_slider_image_url_0', 'fifu_video_url'], true)) {
                $featuredList[] = $thumbnail;
                continue;
            }

            $galleryList[] = $thumbnail;
        }

        $galleryMetaSnapshots = [];
        if (!empty($galleryList)) {
            $galleryMetaSnapshots = $this->snapshot_gallery_revert_meta($galleryList);
        }

        $attIdsMapFeatured = [];
        $metaIdsMapFeatured = [];
        if (!empty($featuredList)) {
            $attIdsMapFeatured = $this->repository->get_thumbnail_ids($featuredList, false);
            if (!empty($attIdsMapFeatured)) {
                $metaIdsMapFeatured = $this->repository->get_thumbnail_meta_ids($featuredList, $attIdsMapFeatured);
            }
        }

        $attIdsMapGallery = [];
        $metaIdsMapGallery = [];
        if (!empty($galleryList)) {
            $attIdsMapGallery = $this->repository->get_thumbnail_ids_gallery($galleryList, true);
            if (!empty($attIdsMapGallery)) {
                $metaIdsMapGallery = $this->repository->get_thumbnail_meta_ids($galleryList, $attIdsMapGallery);
            }
        }

        $attachmentIdsMap = $attIdsMapFeatured + $attIdsMapGallery;
        $metaIdsMap = $metaIdsMapFeatured + $metaIdsMapGallery;

        $listIdsMap = $this->repository->get_list_ids($thumbnails, $bucketId, true, $videoUrls);

        $this->revert_posts_speed_up(
            $bucketId,
            $thumbnails,
            $urls,
            $videoUrls,
            $attachmentIdsMap,
            $metaIdsMap,
            $listIdsMap
        );

        $this->revert_featured_to_local($featuredList, false);
        $this->revert_gallery_to_local($galleryList, $attIdsMapGallery, $galleryMetaSnapshots, $urls);
        if (!empty($galleryList)) {
            $gallery_post_ids = [];
            foreach ($galleryList as $thumbnail) {
                $post_id = (int) ($thumbnail->post_id ?? 0);
                if ($post_id > 0) {
                    $gallery_post_ids[$post_id] = true;
                }
            }

            if (!empty($gallery_post_ids)) {
                $this->clear_tmp_product_gallery_snapshots_for_post_ids(array_keys($gallery_post_ids));
            }
        }
    }

    /**
     * Prepare term-level removals for speed-up rollback.
     *
     * @param string|int   $bucketId
     * @param array $thumbnails
     * @param array $urls
     * @param array $videoUrls
     */
    public function remove_term_urls(string|int $bucketId, array $thumbnails, array $urls, array $videoUrls): void
    {
        foreach ($thumbnails as $thumbnail) {
            if (empty($thumbnail->meta_id ?? null)) {
                $storageId = $thumbnail->storage_id ?? null;
                unset($urls[$storageId], $videoUrls[$storageId]);
            }
        }

        $this->cleanup_legacy_term_image_alt_after_speedup_delete($thumbnails);

        if (empty($urls) && empty($videoUrls)) {
            return;
        }

        $featuredList = [];
        foreach ($thumbnails as $thumbnail) {
            $featuredList[] = $thumbnail;
        }

        $attIdsMap = [];
        $metaIdsMap = [];
        if (!empty($featuredList)) {
            $attIdsMap = $this->repository->get_thumbnail_ids($featuredList, true);
            if (!empty($attIdsMap)) {
                $metaIdsMap = $this->repository->get_thumbnail_meta_ids($featuredList, $attIdsMap);
            }
        }

        $this->revert_terms_speed_up(
            $bucketId,
            $thumbnails,
            $urls,
            $videoUrls,
            $attIdsMap,
            $metaIdsMap,
            []
        );

        $this->revert_featured_to_local($featuredList, true);
    }

    /**
     * Revert featured items to local attachments.
     *
     * @param array $featuredList
     * @param bool  $isCategory
     */
    public function revert_featured_to_local(array $featuredList, bool $isCategory): void
    {
        if (empty($featuredList)) {
            return;
        }

        foreach ($featuredList as $item) {
            $objectId = $this->extract_post_id($item);
            if ($objectId <= 0) {
                continue;
            }

            $metaKey = $this->resolve_featured_source_meta_key($item);
            $backupId = $isCategory
                ? get_term_meta($objectId, 'bkp_thumbnail_id', true)
                : get_post_meta($objectId, 'bkp_thumbnail_id', true);
            $fifuUrl = $this->resolve_current_featured_fifu_url($objectId, $metaKey, $isCategory);
            $currentThumb = $isCategory
                ? get_term_meta($objectId, 'thumbnail_id', true)
                : get_post_meta($objectId, '_thumbnail_id', true);

            if (!$backupId || !$fifuUrl || !$currentThumb) {
                continue;
            }

            $backupId = (int) $backupId;
            if ($backupId <= 0) {
                continue;
            }

            $attachmentExists = false;
            if (function_exists('get_attached_file')) {
                $file = get_attached_file($backupId);
                if ($file && file_exists($file)) {
                    $attachmentExists = true;
                }
            }

            if (!$attachmentExists) {
                if ($isCategory) {
                    delete_term_meta($objectId, 'bkp_thumbnail_id');
                } else {
                    delete_post_meta($objectId, 'bkp_thumbnail_id');
                }
                continue;
            }

            if ($isCategory) {
                $this->clear_current_featured_media($objectId, $metaKey, true);
                update_term_meta($objectId, 'thumbnail_id', $backupId);
                delete_term_meta($objectId, 'bkp_thumbnail_id');
                continue;
            }

            $backupGallery = (string) get_post_meta($objectId, 'bkp_product_image_gallery', true);
            $this->clear_current_featured_media($objectId, $metaKey, false);
            update_post_meta($objectId, '_thumbnail_id', $backupId);
            delete_post_meta($objectId, 'bkp_thumbnail_id');
            $this->restore_product_gallery_backup_after_featured_revert($objectId, $backupGallery);
        }
    }

    /**
     * Resolve the featured source meta key from a thumbnail item.
     *
     * @param object|array $item
     * @return string
     */
    private function resolve_featured_source_meta_key(object|array $item): string
    {
        if (is_array($item)) {
            return (string) ($item['meta_key'] ?? '');
        }

        return (string) ($item->meta_key ?? '');
    }

    /**
     * Resolve the current FIFU media URL for the featured item based on its source meta key.
     *
     * @param int $objectId
     * @param string $metaKey
     * @param bool $isCategory
     * @return string
     */
    private function resolve_current_featured_fifu_url(int $objectId, string $metaKey, bool $isCategory): string
    {
        if ($isCategory) {
            return match ($metaKey) {
                'fifu_image_url' => (string) (Fifu_Term_Image_Url_Read_Service::get_image_url($objectId) ?? ''),
                'fifu_video_url' => (string) (Fifu_Term_Video_Read_Service::get_video_url($objectId) ?? ''),
                default => '',
            };
        }

        return match ($metaKey) {
            'fifu_image_url' => (string) (Fifu_Post_Image_Url_Read_Service::get_image_url($objectId) ?? ''),
            'fifu_video_url' => (string) (Fifu_Post_Video_Read_Service::get_video_url($objectId) ?? ''),
            'fifu_slider_image_url_0' => (string) (Fifu_Post_Slider_Image_Url_Read_Service::get_slider_image_url($objectId, 0) ?? ''),
            default => '',
        };
    }

    /**
     * Clear the current featured media using the correct media type for the source meta key.
     *
     * @param int $objectId
     * @param string $metaKey
     * @param bool $isCategory
     * @return void
     */
    private function clear_current_featured_media(int $objectId, string $metaKey, bool $isCategory): void
    {
        if (!class_exists('Fifu_Developer_Media_Service')) {
            return;
        }

        if ($isCategory) {
            match ($metaKey) {
                'fifu_image_url' => $this->clear_current_term_image_media($objectId),
                'fifu_video_url' => Fifu_Developer_Media_Service::set_category_video($objectId, ''),
                default => null,
            };
            return;
        }

        match ($metaKey) {
            'fifu_image_url', 'fifu_slider_image_url_0' => Fifu_Developer_Media_Service::set_image($objectId, ''),
            'fifu_video_url' => Fifu_Developer_Media_Service::set_video($objectId, ''),
            default => null,
        };
    }

    /**
     * Restore the local WooCommerce gallery backup after featured rollback cleanup.
     *
     * The featured image cleanup can remove FIFU-managed gallery attachment references as
     * a side effect. When only a featured Cloud item is being reverted, no gallery item
     * reaches revert_gallery_to_local(), so restore the local gallery backup here.
     *
     * @param int $postId
     * @param string $backupGallery
     * @return void
     */
    private function restore_product_gallery_backup_after_featured_revert(int $postId, string $backupGallery): void
    {
        $backupGallery = trim($backupGallery);
        if ($backupGallery === '') {
            return;
        }

        $backupGalleryArr = array_values(array_filter(
            explode(',', $backupGallery),
            static fn($value): bool => trim((string) $value) !== ''
        ));

        if (empty($backupGalleryArr)) {
            return;
        }

        $this->persist_product_gallery_meta($postId, $backupGalleryArr);
        delete_post_meta($postId, 'bkp_product_image_gallery');
    }

    /**
     * Clear the current term image and remove residual legacy ALT termmeta during SU rollback.
     *
     * @param int $termId
     * @return void
     */
    private function clear_current_term_image_media(int $termId): void
    {
        Fifu_Developer_Media_Service::set_category_image($termId, '');
        delete_term_meta($termId, 'fifu_image_alt');
    }

    /**
     * Remove residual legacy term ALT metadata for category image entries deleted via SU.
     *
     * This must run even when thumbnail restoration is skipped, because the cloud delete
     * flow can still revert/remove fifu_image_url without entering the local thumbnail branch.
     *
     * @param array $thumbnails
     * @return void
     */
    private function cleanup_legacy_term_image_alt_after_speedup_delete(array $thumbnails): void
    {
        global $wpdb;

        foreach ($thumbnails as $thumbnail) {
            $metaKey = $this->resolve_featured_source_meta_key($thumbnail);
            if ($metaKey !== 'fifu_image_url') {
                continue;
            }

            $termId = $this->extract_post_id($thumbnail);
            if ($termId <= 0) {
                $storageId = $this->extract_storage_id($thumbnail);
                if ($storageId === '' || !class_exists('WooCommerce')) {
                    continue;
                }

                $termId = (int) $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT tm.term_id
                        FROM {$wpdb->termmeta} tm
                        INNER JOIN {$wpdb->terms} t ON t.term_id = tm.term_id
                        WHERE tm.meta_key = 'fifu_image_url'
                          AND tm.meta_value LIKE %s
                        LIMIT 1",
                        '%https://cdn.fifu.app/%' . $storageId
                    )
                );
                if ($termId <= 0) {
                    continue;
                }
            }

            delete_term_meta($termId, 'fifu_image_alt');
        }
    }

    /**
     * Automatically assign missing category images using the repository.
     *
     * @return void
     */
    public function auto_assign_category_images(): void
    {
        $seed = (string) date('YmdH');
        $this->repository->insert_category_images_auto($seed);
    }

    /**
     * Automatically update category images using deterministic selection.
     *
     * @return void
     */
    public function auto_update_category_images(): void
    {
        $this->repository->update_category_images_auto();
    }

    /**
     * Backup attachments for the provided posts.
     *
     * @param array|int|string $postIds
     * @return void
     */
    public function backup_post_attachments(array|int|string $postIds): void
    {
        $this->repository->backup_post_attachment_ids($postIds);
    }

    /**
     * Backup attachments for the provided terms.
     *
     * @param array|int|string $termIds
     * @return void
     */
    public function backup_term_attachments(array|int|string $termIds): void
    {
        $this->repository->backup_term_attachment_ids($termIds);
    }

    /**
     * Delete post attachment IDs and clear related caches.
     *
     * @param array|int|string $postIds
     * @return void
     */
    public function delete_post_attachment_ids_with_cache(array|int|string $postIds): void
    {
        $this->repository->delete_post_attachment_ids($postIds);
        foreach ($this->normalize_ids($postIds) as $postId) {
            wp_cache_delete($postId, 'post_meta');
        }
    }

    /**
     * Delete only featured attachment IDs for the provided posts and clear related caches.
     *
     * @param array|int|string $postIds
     * @return void
     */
    public function delete_post_featured_attachment_ids_with_cache(array|int|string $postIds): void
    {
        $this->repository->delete_post_featured_attachment_ids($postIds);
        foreach ($this->normalize_ids($postIds) as $postId) {
            wp_cache_delete($postId, 'post_meta');
        }
    }

    /**
     * Delete only gallery attachment IDs for the provided posts and clear related caches.
     *
     * @param array|int|string $postIds
     * @return void
     */
    public function delete_post_gallery_attachment_ids_with_cache(array|int|string $postIds): void
    {
        $this->repository->delete_post_gallery_attachment_ids($postIds);
        foreach ($this->normalize_ids($postIds) as $postId) {
            wp_cache_delete($postId, 'post_meta');
        }
    }

    /**
     * Delete term attachment IDs and clear related caches.
     *
     * @param array|int|string $termIds
     * @return void
     */
    public function delete_term_attachment_ids_with_cache(array|int|string $termIds): void
    {
        $this->repository->delete_term_attachment_ids($termIds);
        foreach ($this->normalize_ids($termIds) as $termId) {
            wp_cache_delete($termId, 'term_meta');
        }
    }

    /**
     * Wraps a callable inside a SQL transaction.
     *
     * @param callable $callback
     */
    private function run_within_transaction(callable $callback): bool
    {
        $wpdb = $this->repository->get_wpdb();
        $wpdb->query('START TRANSACTION');

        try {
            $callback();
            $wpdb->query('COMMIT');
            return true;
        } catch (\Throwable $e) {
            error_log($e->getMessage());
            $wpdb->query('ROLLBACK');
            return false;
        }
    }

    /**
     * Placeholder for restoring attachments via insert_postmeta2/related operations.
     *
     * @param string $valuesSql
     * @param array|int|string $postIds
     */
    public function restore_post_attachment_meta(string $valuesSql, array|int|string $postIds): void
    {
        if ($valuesSql === '') {
            return;
        }

        $repository = $this->repository;
        $normalizedPostIds = $this->normalize_object_ids($postIds);
        $this->run_within_transaction(static function () use ($valuesSql, $postIds, $repository): void {
            $repository->insert_post_attachment_meta($valuesSql, $postIds);
        });
        foreach ($normalizedPostIds as $postId) {
            clean_post_cache($postId);
        }
    }

    /**
     * Placeholder for cleaning up FIFU-created attachment metadata.
     *
     * @param array|int|string $attachmentIds
     */
    public function cleanup_post_attachment_meta(array|int|string $attachmentIds): void
    {
        $repository = $this->repository;
        $this->run_within_transaction(static function () use ($attachmentIds, $repository): void {
            $repository->delete_attachment_meta($attachmentIds);
        });
    }

    /**
     * Placeholder for cleaning WooCommerce gallery metadata.
     *
     * @param array|int|string $postIds
     */
    public function cleanup_woocommerce_meta(array|int|string $postIds): void
    {
        $repository = $this->repository;
        $this->run_within_transaction(static function () use ($postIds, $repository): void {
            $repository->delete_woocommerce_gallery_meta($postIds);
        });
    }

    /**
     * Placeholder for cleaning term attachments metadata.
     *
     * @param array|int|string $termIds
     */
    public function cleanup_term_attachments(array|int|string $termIds): void
    {
        $repository = $this->repository;
        $this->run_within_transaction(static function () use ($termIds, $repository): void {
            $repository->delete_term_thumbnail_meta($termIds);
        });
    }

    /**
     * Placeholder for restoring WooCommerce attachment metadata.
     *
     * @param string $valuesSql
     * @param array|int|string $postIds
     */
    public function restore_woocommerce_meta(string $valuesSql, array|int|string $postIds): void
    {
        if ($valuesSql === '') {
            return;
        }

        $repository = $this->repository;
        $thumbIds = $repository->collect_thumbnail_ids($postIds);
        $normalizedPostIds = $this->normalize_object_ids($postIds);
        $transactionCommitted = $this->run_within_transaction(static function () use ($valuesSql, $postIds, $thumbIds, $repository): void {
            $repository->insert_woocommerce_attachment_meta($valuesSql, $postIds, $thumbIds);
        });

        if (!$transactionCommitted) {
            return;
        }

        foreach ($normalizedPostIds as $postId) {
            clean_post_cache($postId);
        }
        $this->sync_tmp_product_gallery_snapshots_for_post_ids($this->normalize_object_ids($postIds));
    }

    /**
     * Placeholder for restoring term attachment metadata.
     *
     * @param string $valuesSql
     * @param array|int|string $termIds
     */
    public function restore_term_attachments(string $valuesSql, array|int|string $termIds): void
    {
        if ($valuesSql === '') {
            return;
        }

        $repository = $this->repository;
        $this->run_within_transaction(static function () use ($valuesSql, $termIds, $repository): void {
            $repository->insert_term_attachment_meta($valuesSql, $termIds);
        });
    }

    /**
     * @param array|int|string $ids
     * @return int[]
     */
    private function normalize_object_ids(array|int|string $ids): array
    {
        if (is_array($ids)) {
            $values = $ids;
        } elseif (is_string($ids)) {
            $values = array_map('trim', explode(',', $ids));
        } else {
            $values = [$ids];
        }

        $normalized = [];
        foreach ($values as $value) {
            $id = (int) $value;
            if ($id <= 0) {
                continue;
            }

            $normalized[$id] = $id;
        }

        return array_values($normalized);
    }

    /**
     * Revert galleries to local attachments.
     *
     * @param array $galleryList
     * @param array $attachmentIdMap
     * @param array<int,array<string,string>> $galleryMetaSnapshots
     * @return void
     */
    public function revert_gallery_to_local(
        array $galleryList,
        array $attachmentIdMap,
        array $galleryMetaSnapshots = [],
        array $originalUrls = []
    ): void
    {
        if (empty($galleryList)) {
            return;
        }

        global $wpdb;

        foreach ($galleryList as $item) {
            $postId = $this->extract_post_id($item);
            if ($postId <= 0) {
                continue;
            }

            $backupGallery = get_post_meta($postId, 'bkp_product_image_gallery', true);
            $currentGallery = get_post_meta($postId, '_product_image_gallery', true);
            if (($backupGallery === '' || $currentGallery === '') && isset($galleryMetaSnapshots[$postId])) {
                $snapshot = $galleryMetaSnapshots[$postId];
                if ($backupGallery === '' && isset($snapshot['backup_gallery'])) {
                    $backupGallery = $snapshot['backup_gallery'];
                }
                if ($currentGallery === '' && isset($snapshot['current_gallery'])) {
                    $currentGallery = $snapshot['current_gallery'];
                }
            }
            if (!$backupGallery || !$currentGallery) {
                continue;
            }

            $backupGalleryArr = array_values(array_filter(explode(',', $backupGallery), 'strlen'));
            $currentGalleryArr = array_values(array_filter(explode(',', $currentGallery), 'strlen'));

            $metaId = $this->extract_meta_id($item);
            $attId = $metaId && isset($attachmentIdMap[$metaId]) ? (int) $attachmentIdMap[$metaId] : 0;

            $currentUrl = '';
            if ($attId > 0) {
                $currentUrl = $this->resolve_current_gallery_item_url($postId, $item, $attId);
            }

            $storageId = $this->extract_storage_id($item);

            $liveGalleryIndex = null;

            if ($storageId !== null && $storageId !== '') {
                $liveGalleryIndex = $this->resolve_current_gallery_slot_index_by_storage_id(
                    $currentGalleryArr,
                    $storageId
                );
            }

            if ($liveGalleryIndex === null && $attId > 0) {
                $index = array_search((string) $attId, $currentGalleryArr, true);
                if ($index !== false) {
                    $liveGalleryIndex = (int) $index;
                }
            }

            if ($liveGalleryIndex === null) {
                $galleryIndex = $this->extract_gallery_index($item);
                if ($galleryIndex !== null && isset($currentGalleryArr[$galleryIndex])) {
                    $liveGalleryIndex = $galleryIndex;
                }
            }

            if ($liveGalleryIndex === null) {
                continue;
            }

            $restoredUrl = '';
            if ($storageId !== null && $storageId !== '' && isset($originalUrls[$storageId])) {
                $restoredUrl = trim((string) $originalUrls[$storageId]);
            }

            if ($restoredUrl === '') {
                $restoredUrl = $this->resolve_reverted_gallery_original_url(
                    $postId,
                    $item,
                    $attId,
                    $originalUrls
                );
            }

            if ($restoredUrl === '' && $currentUrl !== '') {
                $restoredUrl = $currentUrl;
            }

            $matchedBackup = null;

            if ($restoredUrl !== '') {
                $matchedBackup = $this->resolve_backup_gallery_attachment_id(
                    $backupGalleryArr,
                    $restoredUrl,
                    $liveGalleryIndex
                );
            }

            if (!$matchedBackup && $currentUrl !== '') {
                $matchedBackup = $this->find_matching_backup_att_id($backupGalleryArr, $currentUrl);
            }

            if (!$matchedBackup) {
                $matchedBackup = $this->resolve_backup_gallery_attachment_id(
                    $backupGalleryArr,
                    '',
                    $liveGalleryIndex
                );
            }

            if (!$matchedBackup) {
                continue;
            }

            if (function_exists('get_attached_file')) {
                $file = get_attached_file($matchedBackup);
                if (!$file || !file_exists($file)) {
                    continue;
                }
            }

            $currentGalleryArr[$liveGalleryIndex] = (string) $matchedBackup;
            $currentGalleryArr = $this->remove_reverted_gallery_duplicates(
                $currentGalleryArr,
                $matchedBackup,
                $storageId
            );
            $currentGalleryArr = $this->normalize_gallery_attachment_ids($postId, $currentGalleryArr);
            $finalGalleryArr = $currentGalleryArr;

            $backupGalleryArr = array_filter($backupGalleryArr, static function ($value) use ($matchedBackup) {
                return (int) $value !== $matchedBackup;
            });

            $this->delete_matching_gallery_fifu_meta($postId, $item, $currentUrl);

            $this->persist_product_gallery_meta($postId, $finalGalleryArr);

            // Remove the DB2 gallery mapping for this reverted URL.
            $db2Enabled = false;
            if (function_exists('fifu_db2_mode')) {
                $mode = fifu_db2_mode();
                $db2Enabled = ($mode === Fifu_Db2_Mode::MODE_DB2 || $mode === Fifu_Db2_Mode::MODE_HYBRID);
            }
            if ($db2Enabled && $currentUrl) {
                $hash = md5($currentUrl);
                $prefix = $this->repository->get_wpdb()->prefix;
                $mapTable = $prefix . 'fifu_map';
                $keyTable = $prefix . 'fifu_key';
                $urlTable = $prefix . 'fifu_url';

                $wpdb->query(
                    $wpdb->prepare(
                        "DELETE m
                        FROM {$mapTable} m
                        INNER JOIN {$keyTable} k ON k.key_id = m.key_id
                        INNER JOIN {$urlTable} u ON u.hash = m.hash
                        WHERE m.post_id = %d
                          AND k.key_type = 'image'
                          AND m.key_index > 0
                          AND u.hash = %s",
                        $postId,
                        $hash
                    )
                );
            }

            if ($attId > 0) {
                $attachmentRepository = new Fifu_Attachment_Repository();
                if (
                    Fifu_Attachment_Update_Service::is_fifu_owned($attId)
                    && !$attachmentRepository->get_referenced_attachment_ids([$attId])
                ) {
                    (new Fifu_Local_Media_Cleanup())->delete_attachments_and_meta([$attId]);
                }
            }

            // Attachment deletion hooks may alter gallery metadata while the old
            // attachment is removed. Reassert the restored gallery only if a hook
            // changed the state persisted immediately before deletion.
            if (!$this->product_gallery_meta_matches($postId, $finalGalleryArr)) {
                $this->persist_product_gallery_meta($postId, $finalGalleryArr);
            }

            $this->update_backup_gallery_meta($postId, $backupGalleryArr);
        }
    }

    /**
     * Normalize ID inputs into an array of integers.
     *
     * @param array|int|string $ids
     * @return int[]
     */
    private function normalize_ids(array|int|string $ids): array
    {
        if (is_array($ids)) {
            return array_values(array_filter(array_map('intval', $ids), static function ($value) {
                return $value > 0;
            }));
        }

        if (is_int($ids)) {
            return $ids > 0 ? [$ids] : [];
        }

        $parts = array_filter(array_map('trim', explode(',', (string) $ids)));
        return array_values(array_filter(array_map('intval', $parts), static function ($value) {
            return $value > 0;
        }));
    }

    /**
     * Extract post ID from a thumbnail item.
     *
     * @param object|array $item
     * @return int
     */
    private function extract_post_id($item): int
    {
        if (is_array($item)) {
            return isset($item['post_id']) ? (int) $item['post_id'] : 0;
        }
        return isset($item->post_id) ? (int) $item->post_id : 0;
    }

    /**
     * Extract meta ID from a thumbnail item.
     *
     * @param object|array $item
     * @return int|null
     */
    private function extract_meta_id($item): ?int
    {
        if (is_array($item)) {
            return isset($item['meta_id']) ? (int) $item['meta_id'] : null;
        }
        return isset($item->meta_id) ? (int) $item->meta_id : null;
    }

    /**
     * Extract the zero-based gallery index from the thumbnail meta key.
     *
     * @param object|array $item
     * @return int|null
     */
    private function extract_gallery_index($item): ?int
    {
        $metaKey = null;
        if (is_array($item)) {
            $metaKey = $item['meta_key'] ?? null;
        } elseif (is_object($item)) {
            $metaKey = $item->meta_key ?? null;
        }

        if (!is_string($metaKey) || $metaKey === '') {
            return null;
        }

        if (preg_match('/_(\d+)$/', $metaKey, $matches) !== 1) {
            return null;
        }

        return isset($matches[1]) ? (int) $matches[1] : null;
    }

    /**
     * Find a backup attachment ID that matches the current URL.
     *
     * @param string[] $backupGallery
     * @param string $currentUrl
     * @return int|null
     */
    private function find_matching_backup_att_id(array $backupGallery, string $currentUrl): ?int
    {
        foreach ($backupGallery as $backupItem) {
            $backupId = (int) $backupItem;
            if ($backupId <= 0) {
                continue;
            }
            $backupUrl = $this->get_attachment_canonical_url($backupId);
            if ($backupUrl && strpos($currentUrl, $backupUrl) !== false) {
                return $backupId;
            }
        }
        return null;
    }

    /**
     * Resolve the backup attachment to restore.
     *
     * Prefer the original URL returned by Cloud. The DB2/meta_key index is not a
     * reliable source for local-link/FIFU Cloud rollback because DB2 image indexes
     * may not match the live WooCommerce gallery slot.
     *
     * @param string[] $backupGallery
     * @param string   $restoredUrl
     * @param int|null $liveGalleryIndex
     * @return int|null
     */
    private function resolve_backup_gallery_attachment_id(array $backupGallery, string $restoredUrl, ?int $fallbackGalleryIndex = null): ?int
    {
        if ($restoredUrl !== '') {
            foreach ($backupGallery as $backupItem) {
                $candidateId = (int) $backupItem;
                if ($candidateId <= 0) {
                    continue;
                }

                $candidates = [
                    (string) wp_get_attachment_url($candidateId),
                    $this->get_attachment_canonical_url($candidateId),
                    (string) get_post_meta($candidateId, '_wp_attached_file', true),
                ];

                if (function_exists('get_post')) {
                    $post = get_post($candidateId);
                    $candidates[] = (string) ($post->post_content_filtered ?? '');
                }

                foreach ($candidates as $candidateUrl) {
                    $candidateUrl = trim((string) $candidateUrl);
                    if ($candidateUrl === '') {
                        continue;
                    }

                    if ($this->urls_match_for_gallery_cleanup($candidateUrl, $restoredUrl)) {
                        return $candidateId;
                    }
                }
            }
        }

        if ($fallbackGalleryIndex !== null && isset($backupGallery[$fallbackGalleryIndex])) {
            $candidateId = (int) $backupGallery[$fallbackGalleryIndex];
            if ($candidateId > 0) {
                return $candidateId;
            }
        }

        return null;
    }

    /**
     * Resolve the live WooCommerce gallery slot by Cloud storage ID.
     *
     * This is the most reliable identity for local-link/FIFU Cloud rollback because
     * attachment IDs, DB2 indexes, and legacy meta indexes can diverge after
     * preflight migration.
     *
     * @param string[] $currentGalleryArr
     * @param string $storageId
     * @return int|null
     */
    private function resolve_current_gallery_slot_index_by_storage_id(array $currentGalleryArr, string $storageId): ?int
    {
        $storageId = trim($storageId);
        if ($storageId === '') {
            return null;
        }

        foreach ($currentGalleryArr as $index => $candidateAttachmentId) {
            $candidateId = (int) $candidateAttachmentId;
            if ($candidateId <= 0) {
                continue;
            }

            $candidates = [
                (string) get_post_meta($candidateId, '_wp_attached_file', true),
                $this->get_attachment_canonical_url($candidateId),
                (string) wp_get_attachment_url($candidateId),
            ];

            if (function_exists('get_post')) {
                $post = get_post($candidateId);
                $candidates[] = (string) ($post->post_content_filtered ?? '');
            }

            foreach ($candidates as $candidate) {
                $candidate = trim((string) $candidate);
                if ($candidate === '') {
                    continue;
                }

                if (strpos($candidate, '/' . $storageId) !== false || strpos($candidate, $storageId) !== false) {
                    return (int) $index;
                }
            }
        }

        return null;
    }

    /**
     * Delete the FIFU gallery meta for the reverted item.
     *
     * @param int $postId
     * @param object|array $item
     * @param string $currentUrl
     * @return void
     */
    private function delete_matching_gallery_fifu_meta(int $postId, $item, string $currentUrl): void
    {
        $metaKey = $this->extract_meta_key($item);
        if ($metaKey !== '') {
            FIFU_Post_Meta_Updater::instance()->delete($postId, $metaKey);
            return;
        }

        if ($currentUrl === '') {
            return;
        }

        $this->delete_matching_fifu_meta_by_url($postId, $currentUrl);
    }

    /**
     * Restore the DB2 mapping for the reverted gallery slot after removing the legacy mirror.
     *
     * revert_custom_fields() already rewrites the original URL into DB2 before
     * revert_gallery_to_local() runs. Deleting the legacy db2-only key through the
     * post meta updater removes that mapping again, so reapply the restored
     * attachment URL here to keep gallery readers consistent after rollback.
     *
     * @param int $postId
     * @param object|array $item
     * @param int $attachmentId
     * @return void
     */
    private function resolve_reverted_gallery_original_url(
        int $postId,
        $item,
        int $attachmentId,
        array $originalUrls = []
    ): string
    {
        $storageId = $this->extract_storage_id($item);
        if ($storageId !== '' && isset($originalUrls[$storageId])) {
            $originalUrl = trim((string) $originalUrls[$storageId]);
            if ($originalUrl !== '') {
                return $originalUrl;
            }
        }

        $restoredUrl = (string) wp_get_attachment_url($attachmentId);
        if ($restoredUrl !== '') {
            return $restoredUrl;
        }

        $restoredUrl = $this->get_attachment_canonical_url($attachmentId);
        if ($restoredUrl !== '') {
            return $restoredUrl;
        }

        $metaKey = $this->extract_meta_key($item);
        if ($metaKey === '') {
            return '';
        }

        return (string) get_post_meta($postId, $metaKey, true);
    }

    /**
     * Delete FIFU image meta that references the given URL.
     *
     * @param int $postId
     * @param string $currentUrl
     * @return void
     */
    private function delete_matching_fifu_meta_by_url(int $postId, string $currentUrl): void
    {
        global $wpdb;
        $metaKeys = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT meta_key FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key LIKE %s",
                $postId,
                'fifu_image_url_%'
            )
        );

        foreach ($metaKeys as $metaKey) {
            $metaValue = get_post_meta($postId, $metaKey, true);
            if ($metaValue === $currentUrl) {
                FIFU_Post_Meta_Updater::instance()->delete($postId, $metaKey);
            }
        }
    }

    /**
     * Update the backup gallery meta after removing entries.
     *
     * @param int $postId
     * @param array $backupGalleryArr
     * @return void
     */
    private function update_backup_gallery_meta(int $postId, array $backupGalleryArr): void
    {
        if (empty($backupGalleryArr)) {
            delete_post_meta($postId, 'bkp_product_image_gallery');
            return;
        }

        update_post_meta($postId, 'bkp_product_image_gallery', implode(',', $backupGalleryArr));
    }

    /**
     * Persist gallery metadata while keeping attachment order stable.
     *
     * @param int $postId
     * @param int[]|string[] $attachmentIds
     * @return void
     */
    private function persist_product_gallery_meta(int $postId, array $attachmentIds): void
    {
        $attachmentIds = array_values(array_unique(array_filter(
            array_map('intval', $attachmentIds),
            static fn(int $id): bool => $id > 0
        )));
        $csv = $attachmentIds ? implode(',', $attachmentIds) : '';

        if ($csv !== '') {
            update_post_meta($postId, '_product_image_gallery', $csv);
        } else {
            delete_post_meta($postId, '_product_image_gallery');
        }

        if (get_post_type($postId) === 'product_variation') {
            if ($csv !== '') {
                update_post_meta($postId, '_wc_additional_variation_images', $csv);
            } else {
                delete_post_meta($postId, '_wc_additional_variation_images');
            }
            return;
        }

        delete_post_meta($postId, '_wc_additional_variation_images');
    }

    /**
     * Check whether the current gallery metadata still matches the validated state.
     *
     * Deletion hooks may remove gallery metadata. WordPress metadata APIs keep the
     * post-meta cache in sync, so reading through get_post_meta() here observes
     * those changes without issuing a redundant update when no hook changed it.
     *
     * @param int $postId
     * @param int[]|string[] $attachmentIds
     * @return bool
     */
    private function product_gallery_meta_matches(int $postId, array $attachmentIds): bool
    {
        $attachmentIds = array_values(array_unique(array_filter(
            array_map('intval', $attachmentIds),
            static fn(int $id): bool => $id > 0
        )));
        $expectedCsv = $attachmentIds ? implode(',', $attachmentIds) : '';

        $gallery = get_post_meta($postId, '_product_image_gallery', true);
        $galleryCsv = is_scalar($gallery) ? trim((string) $gallery) : '';
        if ($galleryCsv !== $expectedCsv) {
            return false;
        }

        $additionalImages = get_post_meta($postId, '_wc_additional_variation_images', true);
        $additionalCsv = is_scalar($additionalImages) ? trim((string) $additionalImages) : '';
        if (get_post_type($postId) === 'product_variation') {
            return $additionalCsv === $expectedCsv;
        }

        return $additionalCsv === '';
    }

    /**
     * Snapshots gallery rollback state before intermediate hooks mutate the post meta.
     *
     * @param array $galleryList
     * @return array<int,array<string,string>>
     */
    private function snapshot_gallery_revert_meta(array $galleryList): array
    {
        $snapshots = [];

        foreach ($galleryList as $item) {
            $postId = $this->extract_post_id($item);
            if ($postId <= 0 || isset($snapshots[$postId])) {
                continue;
            }

            $snapshots[$postId] = [
                'backup_gallery' => (string) get_post_meta($postId, 'bkp_product_image_gallery', true),
                'current_gallery' => (string) get_post_meta($postId, '_product_image_gallery', true),
            ];
        }

        return $snapshots;
    }

    /**
     * Normalizes gallery attachment IDs by removing duplicates and excluding the featured image.
     *
     * @param int $postId
     * @param array $galleryIds
     * @return array
     */
    private function normalize_gallery_attachment_ids(int $postId, array $galleryIds): array
    {
        $normalized = [];
        $seenIds = [];
        $seenUrls = [];

        $featuredId = (int) get_post_meta($postId, '_thumbnail_id', true);
        $featuredUrl = $featuredId > 0 ? (string) wp_get_attachment_url($featuredId) : '';

        foreach ($galleryIds as $galleryId) {
            $galleryId = (int) $galleryId;
            if ($galleryId <= 0 || isset($seenIds[$galleryId])) {
                continue;
            }

            $galleryUrl = (string) wp_get_attachment_url($galleryId);
            if ($featuredId > 0 && $galleryId === $featuredId) {
                continue;
            }

            if ($this->urls_match_for_gallery_cleanup($galleryUrl, $featuredUrl)) {
                continue;
            }

            foreach (array_keys($seenUrls) as $seenUrl) {
                if ($this->urls_match_for_gallery_cleanup($galleryUrl, $seenUrl)) {
                    continue 2;
                }
            }

            $seenIds[$galleryId] = true;
            if ($galleryUrl !== '') {
                $seenUrls[$galleryUrl] = true;
            }

            $normalized[] = (string) $galleryId;
        }

        return $normalized;
    }

    /**
     * Removes leftover attachments that still point to the reverted gallery slot.
     *
     * @param array $galleryIds
     * @param int $matchedBackupId
     * @param string|null $storageId
     * @return array
     */
    private function remove_reverted_gallery_duplicates(array $galleryIds, int $matchedBackupId, ?string $storageId): array
    {
        $matchedBackupUrl = $this->get_attachment_canonical_url($matchedBackupId);
        $normalized = [];
        $keptBackup = false;

        foreach ($galleryIds as $galleryId) {
            $galleryId = (int) $galleryId;
            if ($galleryId <= 0) {
                continue;
            }

            if ($galleryId === $matchedBackupId) {
                if ($keptBackup) {
                    continue;
                }

                $keptBackup = true;
                $normalized[] = (string) $galleryId;
                continue;
            }

            if ($this->attachment_matches_reverted_gallery_slot($galleryId, $matchedBackupUrl, $storageId)) {
                continue;
            }

            $normalized[] = (string) $galleryId;
        }

        return $normalized;
    }

    /**
     * Returns whether an attachment still represents the reverted gallery slot.
     *
     * @param int $attachmentId
     * @param string $matchedBackupUrl
     * @param string|null $storageId
     * @return bool
     */
    private function attachment_matches_reverted_gallery_slot(int $attachmentId, string $matchedBackupUrl, ?string $storageId): bool
    {
        $attachedUrl = (string) get_post_meta($attachmentId, '_wp_attached_file', true);
        $post = function_exists('get_post') ? get_post($attachmentId) : null;
        $contentFiltered = (string) ($post->post_content_filtered ?? '');

        foreach ([$attachedUrl, $contentFiltered] as $candidate) {
            if ($this->urls_match_for_gallery_cleanup($candidate, $matchedBackupUrl)) {
                return true;
            }

            if ($storageId !== null && $storageId !== '' && strpos($candidate, '/' . $storageId) !== false) {
                return true;
            }
        }

        return false;
    }

    /**
     * Returns the canonical attachment URL used for local gallery matching.
     *
     * @param int $attachmentId
     * @return string
     */
    private function get_attachment_canonical_url(int $attachmentId): string
    {
        $attachedFile = (string) get_post_meta($attachmentId, '_wp_attached_file', true);
        if ($attachedFile !== '') {
            return $attachedFile;
        }

        if (function_exists('get_post')) {
            $post = get_post($attachmentId);
            $contentFiltered = (string) ($post->post_content_filtered ?? '');
            if ($contentFiltered !== '') {
                return $contentFiltered;
            }
        }

        return (string) wp_get_attachment_url($attachmentId);
    }

    /**
     * Resolves the current gallery item URL from the attachment first, then from the FIFU meta field.
     *
     * @param int $postId
     * @param object|array $item
     * @param int $attachmentId
     * @return string
     */
    private function resolve_current_gallery_item_url(int $postId, $item, int $attachmentId): string
    {
        $currentUrl = $this->get_attachment_canonical_url($attachmentId);
        if ($currentUrl !== '') {
            return $currentUrl;
        }

        $metaKey = $this->extract_meta_key($item);
        if ($metaKey === '') {
            return '';
        }

        return (string) get_post_meta($postId, $metaKey, true);
    }

    /**
     * Extract meta key from a thumbnail item.
     *
     * @param object|array $item
     * @return string
     */
    private function extract_meta_key($item): string
    {
        if (is_array($item)) {
            return (string) ($item['meta_key'] ?? '');
        }

        if (is_object($item)) {
            return (string) ($item->meta_key ?? '');
        }

        return '';
    }

    /**
     * Extract storage ID from a thumbnail item when available.
     *
     * @param object|array $item
     * @return string|null
     */
    private function extract_storage_id($item): ?string
    {
        $value = null;
        if (is_array($item)) {
            $value = $item['storage_id'] ?? null;
        } elseif (is_object($item)) {
            $value = $item->storage_id ?? null;
        }

        $value = is_string($value) ? trim($value) : '';
        return $value !== '' ? $value : null;
    }

    /**
     * Returns whether two gallery URLs should be treated as the same image.
     *
     * @param string $left
     * @param string $right
     * @return bool
     */
    private function urls_match_for_gallery_cleanup(string $left, string $right): bool
    {
        if ($left === '' || $right === '') {
            return false;
        }

        if ($left === $right) {
            return true;
        }

        return strpos($left, $right) !== false || strpos($right, $left) !== false;
    }

}
