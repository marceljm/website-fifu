<?php
declare(strict_types=1);

/**
 * Write service for db2 layer. Provides helper methods for FIFU media concepts.
 */
class Fifu_Db2_Write_Service {
    private Fifu_Db2_Manager $manager;

    public function __construct(Fifu_Db2_Manager $manager) {
        $this->manager = $manager;
    }

    public function save_post_image(
        int $post_id,
        string $url,
        ?int $width = null,
        ?int $height = null
    ): bool {
        return $this->manager->savePostUrl($post_id, 'image', 0, $url, $width, $height);
    }

    public function delete_post_image(int $post_id, ?int $index = null): int {
        return $this->manager->deletePostMappings($post_id, 'image', $index);
    }

    public function save_post_image_at_index(
        int $post_id,
        int $index,
        string $url,
        ?int $width = null,
        ?int $height = null
    ): bool {
        return $this->manager->savePostUrl($post_id, 'image', $index, $url, $width, $height);
    }

    public function save_post_slider(
        int $post_id,
        int $index,
        string $url,
        ?int $width = null,
        ?int $height = null
    ): bool {
        return $this->manager->savePostUrl($post_id, 'slider', $index, $url, $width, $height);
    }

    public function delete_post_slider(int $post_id, ?int $index = null): int {
        return $this->manager->deletePostMappings($post_id, 'slider', $index);
    }

    public function save_post_list_url_at_index(
        int $post_id,
        int $index,
        string $url,
        ?int $width = null,
        ?int $height = null
    ): bool {
        return $this->manager->savePostUrl($post_id, 'image', $index, $url, $width, $height);
    }

    public function delete_post_list_url(int $post_id, ?int $index = null): int {
        return $this->manager->deletePostMappings($post_id, 'image', $index);
    }


    public function save_post_video(
        int $post_id,
        string $url,
        ?int $width = null,
        ?int $height = null
    ): bool {
        return $this->manager->savePostUrl($post_id, 'video', 0, $url, $width, $height);
    }

    public function save_post_video_at_index(
        int $post_id,
        int $index,
        string $url,
        ?int $width = null,
        ?int $height = null
    ): bool {
        return $this->manager->savePostUrl($post_id, 'video', $index, $url, $width, $height);
    }

    public function delete_post_video(int $post_id, ?int $index = null): int {
        return $this->manager->deletePostMappings($post_id, 'video', $index);
    }

    public function save_post_audio(
        int $post_id,
        string $url,
        ?int $width = null,
        ?int $height = null
    ): bool {
        return $this->manager->savePostUrl($post_id, 'audio', 0, $url, $width, $height);
    }

    public function delete_post_audio(int $post_id): int {
        return $this->manager->deletePostMappings($post_id, 'audio', null);
    }

    public function save_term_image(
        int $term_id,
        string $url,
        ?int $width = null,
        ?int $height = null
    ): bool {
        return $this->manager->saveTermUrl($term_id, 'image', $url, $width, $height);
    }

    public function delete_term_image(int $term_id): int {
        return $this->manager->deleteTermMappings($term_id, 'image');
    }

    public function save_term_video(
        int $term_id,
        string $url,
        ?int $width = null,
        ?int $height = null
    ): bool {
        return $this->manager->saveTermUrl($term_id, 'video', $url, $width, $height);
    }

    public function delete_term_video(int $term_id): int {
        return $this->manager->deleteTermMappings($term_id, 'video');
    }

    public function save_term_custom_video(
        int $term_id,
        string $url,
        ?int $width = null,
        ?int $height = null
    ): bool {
        return $this->manager->saveTermUrl($term_id, 'custom_video', $url, $width, $height);
    }

    public function delete_term_custom_video(int $term_id, ?int $index = null): int {
        unset( $index );
        return $this->manager->deleteTermMappings($term_id, 'custom_video');
    }

    public function save_post_image_alt(
        int $post_id,
        string $alt
    ): bool {
        return $this->manager->savePostAlt($post_id, 'image', 0, $alt);
    }

    public function delete_post_image_alt(int $post_id, ?int $index = null): int {
        return $this->manager->deletePostAltMappings($post_id, 'image', $index);
    }

    public function save_post_image_alt_at_index(
        int $post_id,
        int $index,
        string $alt
    ): bool {
        return $this->manager->savePostAlt($post_id, 'image', $index, $alt);
    }

    public function save_post_slider_alt(
        int $post_id,
        int $index,
        string $alt
    ): bool {
        return $this->manager->savePostAlt($post_id, 'slider', $index, $alt);
    }

    public function delete_post_slider_alt(int $post_id, ?int $index = null): int {
        return $this->manager->deletePostAltMappings($post_id, 'slider', $index);
    }

    public function save_term_image_alt(
        int $term_id,
        string $alt
    ): bool {
        return $this->manager->saveTermAlt($term_id, 'image', $alt);
    }

    public function delete_term_image_alt(int $term_id): int {
        return $this->manager->deleteTermAltMappings($term_id, 'image');
    }

    public function save_post_custom_video(
        int $post_id,
        string $url,
        ?int $width = null,
        ?int $height = null
    ): bool {
        return $this->manager->savePostUrl($post_id, 'custom_video', 0, $url, $width, $height);
    }

    public function save_post_custom_video_at_index(
        int $post_id,
        int $index,
        string $url,
        ?int $width = null,
        ?int $height = null
    ): bool {
        return $this->manager->savePostUrl($post_id, 'custom_video', $index, $url, $width, $height);
    }

    public function save_post_custom_video_poster(
        int $post_id,
        string $video_url,
        string $poster_url,
        ?string $embed_url = null
    ): bool {
        unset($post_id);

        if (!class_exists('Fifu_Db2_Video_Oembed_Repository', false)) {
            require_once dirname((string) FIFU_PLUGIN_FILE) . '/admin/db2/repository/class-fifu-db2-video-oembed-repository.php';
        }

        if (!class_exists('Fifu_Db2_Video_Oembed_Repository', false)) {
            return false;
        }

        $repository = new Fifu_Db2_Video_Oembed_Repository();
        $final_embed_url = $embed_url ?? $video_url;
        $previous_image_url = $repository->get_image_url_by_video_url($video_url);
        $previous_embed_url = $repository->get_embed_url_by_video_url($video_url);
        $had_previous_row = $repository->exists($video_url);

        if (!$repository->upsert_oembed($video_url, $poster_url, $final_embed_url)) {
            return false;
        }

        $confirmed_image_url = $repository->get_image_url_by_video_url($video_url);
        $confirmed_embed_url = $repository->get_embed_url_by_video_url($video_url);
        if ($confirmed_image_url !== $poster_url || $confirmed_embed_url !== $final_embed_url) {
            if ($had_previous_row) {
                $repository->upsert_oembed($video_url, (string) $previous_image_url, (string) $previous_embed_url);
            } else {
                $repository->delete_by_video_url($video_url);
            }
            return false;
        }

        return true;
    }

    public function delete_post_custom_video(int $post_id, ?int $index = null): int {
        return $this->manager->deletePostMappings($post_id, 'custom_video', $index);
    }

    public function save_post_finder(
        int $post_id,
        string $url,
        ?int $width = null,
        ?int $height = null
    ): bool {
        return $this->manager->savePostUrl($post_id, 'finder', 0, $url, $width, $height);
    }

    public function delete_post_finder(int $post_id, ?int $index = null): int {
        return $this->manager->deletePostMappings($post_id, 'finder', $index);
    }

    public function save_post_redirect(
        int $post_id,
        string $url,
        ?int $width = null,
        ?int $height = null
    ): bool {
        return $this->manager->savePostUrl($post_id, 'redirect', 0, $url, $width, $height);
    }

    public function delete_post_redirect(int $post_id, ?int $index = null): int {
        return $this->manager->deletePostMappings($post_id, 'redirect', $index);
    }

    public function save_post_iframe(
        int $post_id,
        int $index,
        string $url,
        ?int $width = null,
        ?int $height = null
    ): bool {
        return $this->manager->savePostUrl($post_id, 'iframe', $index, $url, $width, $height);
    }

    public function delete_post_iframe(int $post_id, ?int $index = null): int {
        return $this->manager->deletePostMappings($post_id, 'iframe', $index);
    }

    public function delete_post_all_mappings(int $post_id): void {
        // Deletes all URL and ALT mappings tied to a post across supported key types.

        // Featured image (URL + ALT).
        $this->delete_post_image($post_id);
        $this->delete_post_image_alt($post_id);

        // Slider (URL + ALT).
        $this->delete_post_slider($post_id);
        $this->delete_post_slider_alt($post_id);

        // Other URL-based mappings that do not have ALT entries in db2.
        $this->delete_post_video($post_id);
        $this->delete_post_audio($post_id);
        $this->delete_post_custom_video($post_id);
        $this->delete_post_finder($post_id);
        $this->delete_post_redirect($post_id);
        $this->delete_post_iframe($post_id);
    }

    public function delete_term_all_mappings( int $term_id ): void {
        $this->delete_term_image( $term_id );
        $this->delete_term_image_alt( $term_id );
        $this->delete_term_video( $term_id );
        $this->delete_term_custom_video( $term_id );
    }
}
