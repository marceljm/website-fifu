<?php
declare(strict_types=1);

/**
 * Provides parsing helpers for legacy identifier meta values.
 */
class Fifu_Db2_Identifier_Value_Helper {
    private const PREFIX_INVALID = 'invalid:';
    private const PREFIX_NOT_FOUND = 'not-found:';

    /**
     * Parses the raw value written to post meta.
     *
     * @param mixed $raw
     * @return array{value:string,invalid:int,not_found:int}
     */
    public static function parse($raw): array {
        $value = trim(self::castToString($raw));
        $invalid = 0;
        $notFound = 0;

        if ($value === '') {
            return [
                'value' => '',
                'invalid' => 0,
                'not_found' => 0,
            ];
        }

        if (self::startsWith($value, self::PREFIX_INVALID)) {
            $invalid = 1;
            $value = trim(substr($value, strlen(self::PREFIX_INVALID)));
        } elseif (self::startsWith($value, self::PREFIX_NOT_FOUND)) {
            $notFound = 1;
            $value = trim(substr($value, strlen(self::PREFIX_NOT_FOUND)));
        }

        if ($value === '') {
            return [
                'value' => '',
                'invalid' => 0,
                'not_found' => 0,
            ];
        }

        return [
            'value' => $value,
            'invalid' => $invalid,
            'not_found' => $notFound,
        ];
    }

    private static function castToString($value): string {
        if (is_string($value)) {
            return $value;
        }

        if ($value === null) {
            return '';
        }

        if (is_scalar($value)) {
            return (string) $value;
        }

        if (is_object($value) && method_exists($value, '__toString')) {
            return (string) $value;
        }

        return '';
    }

    private static function startsWith(string $value, string $prefix): bool {
        if ($prefix === '') {
            return false;
        }

        return substr($value, 0, strlen($prefix)) === $prefix;
    }
}
