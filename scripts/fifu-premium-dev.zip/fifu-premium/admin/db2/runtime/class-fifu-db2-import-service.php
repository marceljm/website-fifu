<?php

declare(strict_types=1);


/**
 * Runtime facade exposing import repository operations.
 */
class Fifu_Db2_Import_Service {

    private Fifu_Db2_Import_Repository $repository;

    public function __construct(Fifu_Db2_Import_Repository $repository) {
        $this->repository = $repository;
    }

    /**
     * Queue a post or term import request.
     */
    public function queue_import(int $postId, bool $isCategory): void {
        $this->repository->insert_import($postId, $isCategory);
    }

    /**
     * Proxy to repository for retrieving valid post IDs.
     */
    public function get_valid_post_ids(array $postIds, string $metaKey): array {
        return $this->repository->get_valid_post_ids($postIds, $metaKey);
    }

    /**
     * Proxy to repository for retrieving valid term IDs.
     */
    public function get_valid_term_ids(array $termIds, string $metaKey): array {
        return $this->repository->get_valid_term_ids($termIds, $metaKey);
    }
}
