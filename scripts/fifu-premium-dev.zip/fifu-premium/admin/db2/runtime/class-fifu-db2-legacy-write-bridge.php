<?php
declare(strict_types=1);

require_once __DIR__ . '/class-fifu-db2-identifier-value-helper.php';

/**
 * Bridge between legacy meta keys and the new db2 write service.
 */
class Fifu_Db2_Legacy_Write_Bridge {
    private Fifu_Db2_Write_Service $write_service;
    private ?Fifu_Db2_Identifier_Repository $identifierRepository = null;
    /** @var array<string,bool> */
    private array $keyTypeExistsCache = [];
    private const IDENTIFIER_META_MAP = [
        'fifu_asin' => 'asin',
    ];

    public function __construct(Fifu_Db2_Write_Service $write_service) {
        $this->write_service = $write_service;
    }


    public function handle_post_meta_change(int $post_id, string $meta_key, ?string $url): bool {
        try {
            if (isset(self::IDENTIFIER_META_MAP[$meta_key])) {
                return $this->handle_identifier_meta_change($post_id, $meta_key, $url);
            }

            if ($meta_key === 'fifu_image_url') {
                if ($this->is_empty_url($url)) {
                    if (!$this->db2_key_type_exists('image')) {
                        return false;
                    }
                    $this->write_service->delete_post_image($post_id, 0);
                    return true;
                }

                $ok = $this->write_service->save_post_image($post_id, $url);
                if (!$ok) {
                    $this->log_db2_write_returned_false('post', $post_id, $meta_key, 0, $url);
                }
                return $ok;
            }

            if ($meta_key === 'fifu_slider_list_url') {
                if ($this->is_empty_url($url)) {
                    if (!$this->db2_key_type_exists('slider')) {
                        return false;
                    }
                    $this->write_service->delete_post_slider($post_id);
                    return true;
                }

                $entries = self::normalize_valid_url_entries((string) $url);
                if (!$entries) {
                    return false;
                }

                $this->write_service->delete_post_slider($post_id);

                $writeIndex = 0;

                foreach ($entries as $entry) {
                    $saved = $this->write_service->save_post_slider($post_id, $writeIndex, $entry);
                    if (!$saved) {
                        $this->log_db2_write_returned_false('post', $post_id, $meta_key, $writeIndex, $entry);
                        return false;
                    }

                    $writeIndex++;
                }

                return true;
            }

            if ($meta_key === 'fifu_list_video_url') {
                $raw = $url === null ? '' : (string) $url;
                $raw = trim($raw);
                $raw = rtrim($raw, '|');

                if ($raw === '') {
                    // Safety: do not clear legacy if DB2 key types are missing.
                    if (!$this->db2_key_type_exists('video') || !$this->db2_key_type_exists('custom_video')) {
                        return false;
                    }
                    $this->write_service->delete_post_video($post_id, null);
                    $this->write_service->delete_post_custom_video($post_id, null);
                    return true;
                }

                // Keep the rebuild best-effort but avoid a long-lived explicit transaction here.
                // This branch touches video/custom_video/image mappings in sequence and is a hot path
                // for developer updates, so shorter lock lifetimes reduce deadlock pressure on wp_fifu_map.
                $this->write_service->delete_post_video($post_id, null);
                $this->write_service->delete_post_custom_video($post_id, null);

                $entries = self::normalize_pipe_list_entries($raw);

                if (!$entries) {
                    $this->write_service->delete_post_video($post_id, null);
                    $this->write_service->delete_post_custom_video($post_id, null);
                    return true;
                }

                $ok = true;
                $normalVideoIndex = 0;
                $customVideoIndex = 0;

                foreach ($entries as $entry) {
                    $entry = trim((string) $entry);
                    if ($entry === '') {
                        continue;
                    }

                    if (strpos($entry, '\\') !== false) {
                        [$videoUrl, $posterUrl, $hasPoster] = self::split_custom_video_entry($entry);
                        $videoUrl = trim((string) $videoUrl);
                        $posterUrl = trim((string) $posterUrl);

                        if ($videoUrl === '' || !self::is_valid_db2_url_entry($videoUrl)) {
                            continue;
                        }

                        if ($hasPoster && $posterUrl !== '' && !self::is_valid_db2_url_entry($posterUrl)) {
                            continue;
                        }

                        if ($hasPoster && $posterUrl !== '') {
                            if (self::is_custom_video_transport_payload($entry)) {
                                $currentCustomVideoIndex = $customVideoIndex;

                                $saved = $this->write_service->save_post_custom_video_at_index($post_id, $currentCustomVideoIndex, $videoUrl);
                                if (!$saved) {
                                    $ok = false;
                                    $this->log_db2_write_returned_false('post', $post_id, $meta_key, $currentCustomVideoIndex, $videoUrl);
                                    break;
                                }

                                $posterSaved = $this->write_service->save_post_custom_video_poster($post_id, $videoUrl, $posterUrl);
                                if (!$posterSaved) {
                                    $ok = false;
                                    $this->log_db2_write_returned_false('post', $post_id, $meta_key, $currentCustomVideoIndex, $posterUrl);
                                    break;
                                }

                                $this->delete_post_image_mappings_matching_url($post_id, $posterUrl);
                                $customVideoIndex++;
                            }
                            continue;
                        }

                        $entry = $videoUrl;
                    }

                    if (self::is_custom_video_transport_payload($entry)) {
                        [$videoUrl, $posterUrl, $hasPoster] = self::split_custom_video_entry($entry);
                        $videoUrl = trim((string) $videoUrl);
                        $posterUrl = trim((string) $posterUrl);

                        if ($videoUrl === '' || !self::is_valid_db2_url_entry($videoUrl)) {
                            continue;
                        }

                        if ($hasPoster && $posterUrl !== '' && !self::is_valid_db2_url_entry($posterUrl)) {
                            continue;
                        }

                        if ($hasPoster && $posterUrl !== '') {
                            $currentCustomVideoIndex = $customVideoIndex;

                            $saved = $this->write_service->save_post_custom_video_at_index($post_id, $currentCustomVideoIndex, $videoUrl);
                            if (!$saved) {
                                $ok = false;
                                $this->log_db2_write_returned_false('post', $post_id, $meta_key, $currentCustomVideoIndex, $videoUrl);
                                break;
                            }

                            $posterSaved = $this->write_service->save_post_custom_video_poster($post_id, $videoUrl, $posterUrl);
                            if (!$posterSaved) {
                                $ok = false;
                                $this->log_db2_write_returned_false('post', $post_id, $meta_key, $currentCustomVideoIndex, $posterUrl);
                                break;
                            }

                            $this->delete_post_image_mappings_matching_url($post_id, $posterUrl);
                            $customVideoIndex++;
                        }
                        continue;
                    }

                    if (!self::is_valid_db2_url_entry($entry)) {
                        continue;
                    }

                    $currentNormalVideoIndex = $normalVideoIndex;

                    $saved = $this->save_normal_video_at_logical_index($post_id, $currentNormalVideoIndex, $entry);
                    if (!$saved) {
                        $ok = false;
                        $this->log_db2_write_returned_false('post', $post_id, $meta_key, $currentNormalVideoIndex, $entry);
                        break;
                    }

                    $normalVideoIndex++;
                }

                return $ok;
            }

            if ($meta_key === 'fifu_slider_list_alt') {
                if ($this->is_empty_alt($url)) {
                    if (!$this->db2_key_type_exists('slider')) {
                        return false;
                    }
                    $this->write_service->delete_post_slider_alt($post_id);
                    return true;
                }

                $entries = explode('|', (string) $url);
                $this->write_service->delete_post_slider_alt($post_id);

                $ok = true;
                $hadInvalid = false;
                foreach ($entries as $index => $entry) {
                    $entry = trim($entry);
                    if ($entry === '') {
                        continue;
                    }

                    $saved = $this->write_service->save_post_slider_alt($post_id, (int) $index, $entry);
                    if (!$saved) {
                        $ok = false;
                        $hadInvalid = true;
                        $this->log_db2_write_returned_false('post', $post_id, $meta_key, $index, $entry);
                    }
                }

                return $ok && !$hadInvalid;
            }

            if (self::should_skip_db2_sync_for_rest_list_cleanup($meta_key)) {
                $this->delete_legacy_postmeta_raw($post_id, $meta_key);
                return true;
            }

            $sliderIndex = $this->extract_suffix_index($meta_key, 'fifu_slider_image_url_');
            if ($sliderIndex !== null) {
                if ($this->is_empty_url($url)) {
                    if (!$this->db2_key_type_exists('slider')) {
                        return false;
                    }
                    $this->write_service->delete_post_slider($post_id, $sliderIndex);
                    return true;
                }

                $ok = $this->write_service->save_post_slider($post_id, $sliderIndex, $url);
                if (!$ok) {
                    $this->log_db2_write_returned_false('post', $post_id, $meta_key, $sliderIndex, $url);
                }
                return $ok;
            }

            $legacyImageIndex = $this->extract_suffix_index($meta_key, 'fifu_image_url_');
            if ($legacyImageIndex !== null) {
                if ($this->is_empty_url($url)) {
                    if (!$this->db2_key_type_exists('image')) {
                        return false;
                    }
                    $this->write_service->delete_post_image($post_id, $legacyImageIndex + 1);
                    return true;
                }

                $index = $legacyImageIndex + 1;
                $ok = $this->write_service->save_post_image_at_index($post_id, $index, $url);
                if (!$ok) {
                    $this->log_db2_write_returned_false('post', $post_id, $meta_key, $index, $url);
                }
                return $ok;
            }

            if ($meta_key === 'fifu_video_url') {
                if (strpos((string) $url, '\\') !== false) {
                    [$videoUrl, $posterUrl, $hasPoster] = self::split_custom_video_entry((string) $url);
                    $videoUrl = trim((string) $videoUrl);
                    $posterUrl = trim((string) $posterUrl);

                    if ($videoUrl === '') {
                        return false;
                    }

                    if ($hasPoster && $posterUrl !== '') {
                        $ok = $this->write_service->save_post_custom_video_at_index($post_id, 0, $videoUrl);
                        if (!$ok) {
                            $this->log_db2_write_returned_false('post', $post_id, $meta_key, 0, $videoUrl);
                            return false;
                        }

                        $posterSaved = $this->write_service->save_post_custom_video_poster($post_id, $videoUrl, $posterUrl);
                        if (!$posterSaved) {
                            $this->log_db2_write_returned_false('post', $post_id, $meta_key, 0, $posterUrl);
                            return false;
                        }

                        $imageMapping = $this->get_post_mapping($post_id, 'image', 0);
                        if (is_array($imageMapping) && (($imageMapping['url'] ?? null) === $posterUrl)) {
                            $this->write_service->delete_post_image($post_id, 0);
                        }

                        return true;
                    }

                    $url = $videoUrl;
                }

                if ($this->is_empty_url($url)) {
                    if (!$this->db2_key_type_exists('video')) {
                        return false;
                    }
                    $this->write_service->delete_post_video($post_id, 0);
                    return true;
                }

                $ok = $this->write_service->save_post_video($post_id, $url);
                if (!$ok) {
                    $this->log_db2_write_returned_false('post', $post_id, $meta_key, 0, $url);
                }
                return $ok;
            }

            $videoIndex = $this->extract_suffix_index($meta_key, 'fifu_video_url_');
            if ($videoIndex !== null) {
                if ($this->is_empty_url($url)) {
                    if (!$this->db2_key_type_exists('video')) {
                        return false;
                    }
                    $this->write_service->delete_post_video($post_id, $videoIndex + 1);
                    return true;
                }

                $index = $videoIndex + 1;
                $ok = $this->write_service->save_post_video_at_index($post_id, $index, $url);
                if (!$ok) {
                    $this->log_db2_write_returned_false('post', $post_id, $meta_key, $index, $url);
                }
                return $ok;
            }

            if ($meta_key === 'fifu_audio_url') {
                if ($this->is_empty_url($url)) {
                    if (!$this->db2_key_type_exists('audio')) {
                        return false;
                    }
                    $this->write_service->delete_post_audio($post_id);
                    return true;
                }

                if (!$this->db2_key_type_exists('audio')) {
                    return false;
                }

                $ok = $this->write_service->save_post_audio($post_id, $url);
                if (!$ok) {
                    $this->log_db2_write_returned_false('post', $post_id, $meta_key, 0, $url);
                }
                return $ok;
            }

            if ($meta_key === 'fifu_image_alt') {
                if ($this->is_empty_alt($url)) {
                    if (!$this->db2_key_type_exists('image')) {
                        return false;
                    }
                    $this->write_service->delete_post_image_alt($post_id, 0);
                    return true;
                }

                $ok = $this->write_service->save_post_image_alt($post_id, $url);
                if (!$ok) {
                    $this->log_db2_write_returned_false('post', $post_id, $meta_key, 0, $url);
                }
                return $ok;
            }

            if ($meta_key === 'fifu_list_alt') {
                $raw = $url === null ? '' : (string) $url;
                $raw = trim($raw);
                $forceGalleryOnly = $this->should_force_gallery_only_rebuild($post_id, $meta_key);

                if ($raw === '' || trim($raw, "|\t\n\r\0\x0B ") === '') {
                    if (!$this->db2_key_type_exists('image')) {
                        return false;
                    }
                    if ($forceGalleryOnly) {
                        $this->delete_image_gallery_only_alt($post_id);
                    } else {
                        $this->write_service->delete_post_image_alt($post_id, null);
                    }
                    return true;
                }

                if ($forceGalleryOnly) {
                    $this->delete_image_gallery_only_alt($post_id);
                } else {
                    $this->write_service->delete_post_image_alt($post_id, null);
                }

                $entries = explode('|', $raw);
                $ok = true;
                $hadInvalid = false;

                foreach ($entries as $index => $entry) {
                    $entry = trim((string) $entry);
                    if ($entry === '') {
                        continue;
                    }

                    $index = (int) $index;

                    if ($index === 0) {
                        $saved = $this->write_service->save_post_image_alt($post_id, $entry);
                    } else {
                        $saved = $this->write_service->save_post_image_alt_at_index($post_id, $index, $entry);
                    }
                    if (!$saved) {
                        $ok = false;
                        $hadInvalid = true;
                        $this->log_db2_write_returned_false('post', $post_id, $meta_key, $index, $entry);
                    }
                }

                return $ok && !$hadInvalid;
            }

            if ($meta_key === 'fifu_list_url') {
                $raw = $url === null ? '' : (string) $url;
                $raw = rtrim(trim($raw), '|');

                if ($raw === '') {
                    if (!$this->db2_key_type_exists('image')) {
                        return false;
                    }
                    $this->write_service->delete_post_list_url($post_id, null);
                    return true;
                }

                $validEntries = self::normalize_valid_url_entries($raw);
                if (!$validEntries) {
                    return false;
                }

                return $this->transactional(function () use ($post_id, $meta_key, $validEntries): bool {
                    $this->write_service->delete_post_list_url($post_id, null);

                    $writeIndex = 0;

                    foreach ($validEntries as $entry) {
                        $saved = $this->write_service->save_post_list_url_at_index($post_id, $writeIndex, $entry);
                        if (!$saved) {
                            $this->log_db2_write_returned_false('post', $post_id, $meta_key, $writeIndex, $entry);
                            return false;
                        }

                        $writeIndex++;
                    }

                    return true;
                });
            }

            if ($meta_key === 'fifu_list_iframe_url') {
                return $this->transactional(function () use ($post_id, $meta_key, $url): bool {
                    $raw = $url === null ? '' : (string) $url;
                    $raw = rtrim(trim($raw), '|');

                    if ($raw === '') {
                        if (!$this->db2_key_type_exists('iframe')) {
                            return false;
                        }

                        $this->write_service->delete_post_iframe($post_id, null);
                        return true;
                    }

                    $entries = self::normalize_pipe_list_entries($raw);

                    if (!$entries) {
                        $this->write_service->delete_post_iframe($post_id, null);
                        return true;
                    }

                    $this->write_service->delete_post_iframe($post_id, null);

                    $ok = true;

                    foreach ($entries as $offset => $entry) {
                        $entry = trim((string) $entry);
                        if ($entry === '') {
                            continue;
                        }

                        $index = (int) $offset;
                        $saved = $this->write_service->save_post_iframe($post_id, $index, $entry);
                        if (!$saved) {
                            $ok = false;
                            $this->log_db2_write_returned_false('post', $post_id, $meta_key, $index, $entry);
                        }
                    }

                    return $ok;
                });
            }

            $sliderAltIndex = $this->extract_suffix_index($meta_key, 'fifu_slider_image_alt_');
            if ($sliderAltIndex !== null) {
                if ($this->is_empty_alt($url)) {
                    if (!$this->db2_key_type_exists('slider')) {
                        return false;
                    }
                    $this->write_service->delete_post_slider_alt($post_id, $sliderAltIndex);
                    return true;
                }

                $ok = $this->write_service->save_post_slider_alt($post_id, $sliderAltIndex, $url);
                if (!$ok) {
                    $this->log_db2_write_returned_false('post', $post_id, $meta_key, $sliderAltIndex, $url);
                }
                return $ok;
            }

            $imageAltIndex = $this->extract_suffix_index($meta_key, 'fifu_image_alt_');
            if ($imageAltIndex !== null) {
                if ($this->is_empty_alt($url)) {
                    if (!$this->db2_key_type_exists('image')) {
                        return false;
                    }
                    $this->write_service->delete_post_image_alt($post_id, $imageAltIndex + 1);
                    return true;
                }

                $index = $imageAltIndex + 1;
                $ok = $this->write_service->save_post_image_alt_at_index($post_id, $index, $url);
                if (!$ok) {
                    $this->log_db2_write_returned_false('post', $post_id, $meta_key, $index, $url);
                }
                return $ok;
            }

            if ($meta_key === 'fifu_custom_video_url') {
                if ($this->is_empty_url($url)) {
                    if (!$this->db2_key_type_exists('custom_video')) {
                        return false;
                    }
                    $this->write_service->delete_post_custom_video($post_id, 0);
                    return true;
                }

                $ok = $this->write_service->save_post_custom_video($post_id, $url);
                if (!$ok) {
                    $this->log_db2_write_returned_false('post', $post_id, $meta_key, 0, $url);
                }
                return $ok;
            }

            if ($meta_key === 'fifu_finder_url') {
                if ($this->is_empty_url($url)) {
                    if (!$this->db2_key_type_exists('finder')) {
                        return false;
                    }
                    $this->write_service->delete_post_finder($post_id, 0);
                    return true;
                }

                if (!$this->db2_key_type_exists('finder')) {
                    return false;
                }

                $ok = $this->write_service->save_post_finder($post_id, $url);
                if (!$ok) {
                    $this->log_db2_write_returned_false('post', $post_id, $meta_key, 0, $url);
                }
                return $ok;
            }

            if ($meta_key === 'fifu_redirection_url') {
                if ($this->is_empty_url($url)) {
                    if (!$this->db2_key_type_exists('redirect')) {
                        return false;
                    }
                    $this->write_service->delete_post_redirect($post_id, 0);
                    return true;
                }

                if (!$this->db2_key_type_exists('redirect')) {
                    return false;
                }

                $ok = $this->write_service->save_post_redirect($post_id, $url);
                if (!$ok) {
                    $this->log_db2_write_returned_false('post', $post_id, $meta_key, 0, $url);
                }
                return $ok;
            }

            $iframeIndex = $this->extract_suffix_index($meta_key, 'fifu_image_ifm_');
            if ($iframeIndex !== null) {
                if ($this->is_empty_url($url)) {
                    if (!$this->db2_key_type_exists('iframe')) {
                        return false;
                    }
                    $this->write_service->delete_post_iframe($post_id, $iframeIndex);
                    return true;
                }

                $ok = $this->write_service->save_post_iframe($post_id, $iframeIndex, $url);
                if (!$ok) {
                    $this->log_db2_write_returned_false('post', $post_id, $meta_key, $iframeIndex, $url);
                }
                return $ok;
            }

            return false;
        } catch (\Throwable $exception) {
            error_log(sprintf('FIFU DB2 legacy bridge post write failed: %s', (string) $exception->getMessage()));
            return false;
        }
    }

    public function clear_featured_image_replacement_state(int $post_id): bool {
        try {
            return $this->transactional(function () use ($post_id): bool {
                $this->delete_image_gallery_only($post_id);
                $this->write_service->delete_post_image_alt($post_id, null);
                $this->write_service->delete_post_video($post_id, null);
                $this->write_service->delete_post_custom_video($post_id, null);
                $this->write_service->delete_post_slider($post_id, null);
                $this->write_service->delete_post_slider_alt($post_id, null);
                $this->write_service->delete_post_audio($post_id);
                return true;
            });
        } catch (\Throwable $exception) {
            error_log(sprintf('FIFU DB2 legacy bridge featured image cleanup failed: %s', (string) $exception->getMessage()));
            return false;
        }
    }

    public function clear_simple_featured_image_state(int $post_id): bool {
        try {
            return $this->transactional(function () use ($post_id): bool {
                $this->write_service->delete_post_image($post_id, null);
                $this->write_service->delete_post_image_alt($post_id, null);
                $this->write_service->delete_post_video($post_id, null);
                $this->write_service->delete_post_custom_video($post_id, null);
                $this->write_service->delete_post_slider($post_id, null);
                $this->write_service->delete_post_slider_alt($post_id, null);
                return true;
            });
        } catch (\Throwable $exception) {
            error_log(sprintf('FIFU DB2 legacy bridge simple featured image cleanup failed: %s', (string) $exception->getMessage()));
            return false;
        }
    }

    public function replace_with_simple_featured_image(int $post_id, string $image_url, ?string $preserved_alt = null, bool $preserve_inactive_media = false): bool {
        try {
            return $this->transactional(function () use ($post_id, $image_url, $preserved_alt, $preserve_inactive_media): bool {
                if (!$this->write_service->save_post_image($post_id, $image_url)) {
                    return false;
                }

                $this->delete_image_gallery_only($post_id);
                $this->write_service->delete_post_image_alt($post_id, null);

                if ($preserved_alt !== null && trim($preserved_alt) !== '') {
                    if (!$this->write_service->save_post_image_alt($post_id, $preserved_alt)) {
                        return false;
                    }
                }

                if (!$preserve_inactive_media) {
                    $this->write_service->delete_post_video($post_id, null);
                    $this->write_service->delete_post_custom_video($post_id, null);
                    $this->write_service->delete_post_slider($post_id, null);
                    $this->write_service->delete_post_slider_alt($post_id, null);
                }
                return true;
            });
        } catch (\Throwable $exception) {
            error_log(sprintf('FIFU DB2 legacy bridge simple featured image replace failed: %s', (string) $exception->getMessage()));
            return false;
        }
    }

    public function replace_with_simple_featured_video(int $post_id, string $video_url, bool $preserve_inactive_media = false): bool {
        try {
            return $this->transactional(function () use ($post_id, $video_url, $preserve_inactive_media): bool {
                if (!$this->write_service->save_post_video($post_id, $video_url)) {
                    return false;
                }

                $mapping = $this->get_post_mapping($post_id, 'video', 0);
                $confirmed_url = is_array($mapping) ? trim((string) ($mapping['url'] ?? '')) : '';
                if ($confirmed_url !== trim($video_url)) {
                    return false;
                }

                if (!$preserve_inactive_media) {
                    $this->write_service->delete_post_image($post_id, null);
                    $this->write_service->delete_post_custom_video($post_id, null);
                    $this->write_service->delete_post_slider($post_id, null);
                    $this->write_service->delete_post_slider_alt($post_id, null);
                    $this->write_service->delete_post_audio($post_id);
                }
                return true;
            });
        } catch (\Throwable $exception) {
            error_log(sprintf('FIFU DB2 legacy bridge simple featured video replace failed: %s', (string) $exception->getMessage()));
            return false;
        }
    }

    private function handle_identifier_meta_change(int $post_id, string $meta_key, ?string $url): bool {
        $typeKey = self::IDENTIFIER_META_MAP[$meta_key] ?? null;
        if ($typeKey === null) {
            return false;
        }

        $repository = $this->get_identifier_repository();
        if ($repository === null) {
            return false;
        }

        $parsed = Fifu_Db2_Identifier_Value_Helper::parse($url);
        if ($parsed['value'] === '') {
            $repository->delete_post_identifier($post_id, $typeKey);
            return true;
        }

        $ok = $repository->upsert_post_identifier($post_id, $typeKey, $parsed['value'], $parsed['invalid'], $parsed['not_found']);
        if (!$ok) {
            $this->log_db2_write_returned_false('post', $post_id, $meta_key, null, $parsed['value']);
        }
        return $ok;
    }

    private function get_identifier_repository(): ?Fifu_Db2_Identifier_Repository {
        if ($this->identifierRepository instanceof Fifu_Db2_Identifier_Repository) {
            return $this->identifierRepository;
        }

        if (! function_exists('fifu_db2_identifier_repository')) {
            return null;
        }

        $repository = fifu_db2_identifier_repository();
        if (! $repository instanceof Fifu_Db2_Identifier_Repository) {
            return null;
        }

        $this->identifierRepository = $repository;
        return $repository;
    }

    public function handle_term_meta_change(int $term_id, string $meta_key, ?string $url): bool {
        try {
            $logicalType = match ($meta_key) {
                'fifu_image_url', 'fifu_ctgr_image_url' => 'term_image',
                'fifu_video_url', 'fifu_ctgr_video_url' => 'term_video',
                'fifu_image_alt', 'fifu_ctgr_image_alt' => 'term_image_alt',
                default => null,
            };

            if ($logicalType === 'term_image') {
                if ($this->is_empty_url($url)) {
                    if (!$this->db2_key_type_exists('image')) {
                        return false;
                    }
                    $this->write_service->delete_term_image($term_id);
                    $this->write_service->delete_term_image_alt($term_id);
                    return true;
                }

                $ok = $this->write_service->save_term_image($term_id, $url);
                if (!$ok) {
                    $this->log_db2_write_returned_false('term', $term_id, $meta_key, null, $url);
                }
                return $ok;
            }

            if ($logicalType === 'term_video') {
                if ($this->is_empty_url($url)) {
                    if (!$this->db2_key_type_exists('video')) {
                        return false;
                    }
                    $this->write_service->delete_term_video($term_id);
                    return true;
                }

                $ok = $this->write_service->save_term_video($term_id, $url);
                if (!$ok) {
                    $this->log_db2_write_returned_false('term', $term_id, $meta_key, null, $url);
                }
                return $ok;
            }

            if ($logicalType === 'term_image_alt') {
                if ($this->is_empty_alt($url)) {
                    if (!$this->db2_key_type_exists('image')) {
                        return false;
                    }
                    $this->write_service->delete_term_image_alt($term_id);
                    return true;
                }

                $ok = $this->write_service->save_term_image_alt($term_id, $url);
                if (!$ok) {
                    $this->log_db2_write_returned_false('term', $term_id, $meta_key, null, $url);
                }
                return $ok;
            }

            return false;
        } catch (\Throwable $exception) {
            error_log(sprintf('FIFU DB2 legacy bridge term write failed: %s', (string) $exception->getMessage()));
            return false;
        }
    }

    /**
     * Runs a multi-step DB2 write inside a transaction when possible (best-effort).
     *
     * The callback must return true only when the DB2 state is fully consistent for the given meta change.
     * If the DB does not support transactions (or START TRANSACTION fails), the callback runs without a transaction.
     *
     * @param callable(): bool $callback
     */
    private function transactional(callable $callback): bool {
        $wpdb = $this->get_db2_wpdb();
        if (!$wpdb) {
            return (bool) $callback();
        }

        $started = $wpdb->query('START TRANSACTION');
        if ($started === false) {
            return (bool) $callback();
        }

        try {
            $ok = (bool) $callback();
            $wpdb->query($ok ? 'COMMIT' : 'ROLLBACK');
            return $ok;
        } catch (\Throwable $exception) {
            $wpdb->query('ROLLBACK');
            throw $exception;
        }
    }

    private function get_db2_wpdb(): ?wpdb {
        if (!function_exists('fifu_db2_manager')) {
            return null;
        }

        // Hardening: in some edge load orders the function may exist but the class is not loaded yet.
        // Avoid fatal errors on instanceof checks.
        if (!class_exists('Fifu_Db2_Manager')) {
            return null;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return null;
        }

        // Optional hardening: ensure the expected method exists.
        if (!method_exists($manager, 'getWpdb')) {
            return null;
        }

        $wpdb = $manager->getWpdb();
        if (!$wpdb instanceof wpdb) {
            return null;
        }

        return $wpdb;
    }

    /**
     * Safety check: if the expected DB2 key_type is missing, do not treat delete-only operations as "ok".
     */
    private function db2_key_type_exists(string $keyType): bool {
        $wpdb = $this->get_db2_wpdb();
        if (!$wpdb) {
            return false;
        }

        $table = $wpdb->prefix . 'fifu_key';
        $query = $wpdb->prepare("SELECT key_id FROM {$table} WHERE key_type = %s LIMIT 1", $keyType);
        $keyId = $wpdb->get_var($query);

        return $keyId !== null && $keyId !== false;
    }

    private function log_db2_write_returned_false(
        string $entity,
        int $entity_id,
        string $meta_key,
        ?int $index,
        ?string $value
    ): void {
        $valueHash = $value === null ? '' : substr(md5($value), 0, 8);

        error_log(
            sprintf(
                'FIFU DB2 legacy bridge write returned false: entity=%s id=%d meta_key=%s index=%s value_md5=%s',
                $entity,
                $entity_id,
                $meta_key,
                $index === null ? 'null' : (string) $index,
                $valueHash
            )
        );
    }

    private function extract_suffix_index(string $meta_key, string $prefix): ?int {
        if (strpos($meta_key, $prefix) !== 0) {
            return null;
        }

        $suffix = substr($meta_key, strlen($prefix));
        if ($suffix === '' || !ctype_digit($suffix)) {
            return null;
        }

        return (int) $suffix;
    }

    private function is_empty_url(?string $url): bool {
        return $url === null || trim($url) === '';
    }

    private function is_empty_alt(?string $alt): bool {
        return $alt === null || $alt === '';
    }

    /**
     * @return array<int,string>
     */
    private static function normalize_pipe_list_entries(string $raw): array {
        return array_values(
            array_filter(
                array_map('trim', explode('|', $raw)),
                static fn(string $value): bool => $value !== ''
            )
        );
    }

    private static function is_valid_db2_url_entry(string $url): bool {
        return class_exists('Fifu_Db2_Normalizer')
            ? Fifu_Db2_Normalizer::is_valid_url($url)
            : filter_var($url, FILTER_VALIDATE_URL) !== false;
    }

    /**
     * @return array<int,string>
     */
    private static function normalize_valid_url_entries(string $raw): array {
        $entries = self::normalize_pipe_list_entries($raw);
        $valid = array();

        foreach ($entries as $entry) {
            $entry = trim((string) $entry);
            if ($entry === '') {
                continue;
            }

            if (!self::is_valid_db2_url_entry($entry)) {
                continue;
            }

            $valid[] = $entry;
        }

        return $valid;
    }

    private static function should_skip_db2_sync_for_rest_list_cleanup(string $meta_key): bool {
        if (empty($GLOBALS['__fifu_rest_featured_image_cleanup__'])) {
            return false;
        }

        return in_array(
            $meta_key,
            [
                'fifu_list_url',
                'fifu_list_alt',
                'fifu_list_video_url',
                'fifu_slider_list_url',
                'fifu_slider_list_alt',
            ],
            true
        );
    }

    private function has_effective_featured_video(int $post_id): bool {
        $videoMapping = $this->get_post_mapping($post_id, 'video', 0);
        if (is_array($videoMapping) && !empty($videoMapping['url'])) {
            return true;
        }

        $customVideoMapping = $this->get_post_mapping($post_id, 'custom_video', 0);
        if (is_array($customVideoMapping) && !empty($customVideoMapping['url'])) {
            return true;
        }

        $videoUrl = (string) get_post_meta($post_id, 'fifu_video_url', true);
        if (trim($videoUrl) !== '') {
            return true;
        }

        $customVideoUrl = (string) get_post_meta($post_id, 'fifu_custom_video_url', true);
        return trim($customVideoUrl) !== '';
    }

    private function has_effective_featured_image(int $post_id): bool {
        if ($this->has_effective_featured_video($post_id)) {
            return false;
        }

        $imageMapping = $this->get_post_mapping($post_id, 'image', 0);
        if (is_array($imageMapping) && !empty($imageMapping['url'])) {
            return true;
        }

        $imageUrl = (string) get_post_meta($post_id, 'fifu_image_url', true);
        if (trim($imageUrl) !== '') {
            return true;
        }

        if (
            !class_exists('Fifu_Post_Meta_Utils', false)
            || !method_exists('Fifu_Post_Meta_Utils', 'has_local_featured_image')
            || !Fifu_Post_Meta_Utils::has_local_featured_image($post_id)
        ) {
            return function_exists('get_post_thumbnail_id')
                && (int) get_post_thumbnail_id($post_id) > 0;
        }

        return !method_exists('Fifu_Post_Meta_Utils', 'has_no_internal_image')
            || !Fifu_Post_Meta_Utils::has_no_internal_image($post_id);
    }

    private function should_force_gallery_only_rebuild(int $post_id, string $meta_key): bool {
        $context = $GLOBALS['__fifu_dev_gallery_only_db2_rebuild'] ?? null;
        if (!is_array($context)) {
            return false;
        }

        return (bool) ($context[$post_id . ':' . $meta_key] ?? false);
    }

    private function should_force_video_gallery_only_rebuild(int $post_id, string $meta_key): bool {
        $context = $GLOBALS['__fifu_dev_video_gallery_only_db2_rebuild'] ?? null;
        if (!is_array($context)) {
            return false;
        }

        return (bool) ($context[$post_id . ':' . $meta_key] ?? false);
    }

    private function delete_image_gallery_only(int $post_id): void {
        $mappings = $this->get_post_mappings($post_id, 'image');
        foreach ($mappings as $mapping) {
            $index = isset($mapping['key_index']) ? (int) $mapping['key_index'] : null;
            if ($index === null || $index <= 0) {
                continue;
            }

            $this->write_service->delete_post_image($post_id, $index);
        }
    }

    private function delete_image_gallery_only_alt(int $post_id): void {
        $mappings = $this->get_post_alt_mappings($post_id, 'image');
        foreach ($mappings as $mapping) {
            $index = isset($mapping['key_index']) ? (int) $mapping['key_index'] : null;
            if ($index === null || $index <= 0) {
                continue;
            }

            $this->write_service->delete_post_image_alt($post_id, $index);
        }
    }

    /**
     * @return array<int,true>
     */
    private function get_valid_image_url_indexes(int $post_id): array {
        $mappings = $this->get_post_mappings($post_id, 'image');
        if ($mappings === []) {
            return [];
        }

        $indexes = [];
        foreach ($mappings as $mapping) {
            if (!is_array($mapping) || !isset($mapping['key_index'])) {
                continue;
            }

            $index = (int) $mapping['key_index'];
            if ($index < 0) {
                continue;
            }

            $indexes[$index] = true;
        }

        return $indexes;
    }

    private function delete_video_gallery_only(int $post_id): void {
        $mappings = $this->get_post_mappings($post_id, 'video');
        foreach ($mappings as $mapping) {
            $index = isset($mapping['key_index']) ? (int) $mapping['key_index'] : null;
            if ($index === null || $index <= 0) {
                continue;
            }

            $this->write_service->delete_post_video($post_id, $index);
        }
    }

    private function get_post_mapping(int $post_id, string $key_type, int $key_index): ?array {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager')) {
            return null;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getPostMapping')) {
            return null;
        }

        $mapping = $manager->getPostMapping($post_id, $key_type, $key_index);
        return is_array($mapping) ? $mapping : null;
    }

    private function get_post_mappings(int $post_id, string $key_type): array {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager')) {
            return [];
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getPostMappings')) {
            return [];
        }

        $mappings = $manager->getPostMappings($post_id, $key_type);
        return is_array($mappings) ? $mappings : [];
    }

    private function get_post_alt_mappings(int $post_id, string $key_type): array {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager')) {
            return [];
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getPostAltMappings')) {
            return [];
        }

        $mappings = $manager->getPostAltMappings($post_id, $key_type);
        return is_array($mappings) ? $mappings : [];
    }

    private static function split_custom_video_entry(string $value): array {
        $parts = preg_split('/\\\\+/', $value, 2);
        $video = trim((string) ($parts[0] ?? ''));
        $image = trim((string) ($parts[1] ?? ''));

        return [$video, $image, $image !== ''];
    }

    private function save_normal_video_at_logical_index(int $post_id, int $index, string $url): bool {
        if ($index === 0) {
            return $this->write_service->save_post_video($post_id, $url);
        }

        return $this->write_service->save_post_video_at_index($post_id, $index, $url);
    }

    private static function is_custom_video_transport_payload(string $value): bool {
        $value = trim($value);
        if ($value === '') {
            return false;
        }

        if (strpos($value, 'fifu-thumb=') !== false) {
            if (strpos($value, '\\') === false) {
                return false;
            }

            [$videoUrl, $posterUrl, $hasPoster] = self::split_custom_video_entry($value);
            return trim((string) $videoUrl) !== '' && $hasPoster && trim((string) $posterUrl) !== '';
        }

        if (strpos($value, '\\') !== false) {
            [$videoUrl, $posterUrl, $hasPoster] = self::split_custom_video_entry($value);
            return trim((string) $videoUrl) !== '' && $hasPoster && trim((string) $posterUrl) !== '';
        }

        preg_match_all('#https?://#i', $value, $matches, PREG_OFFSET_CAPTURE);
        return isset($matches[0][1]);
    }

    private function delete_post_image_mappings_matching_url(int $post_id, string $image_url): void {
        $mappings = $this->get_post_mappings($post_id, 'image');
        foreach ($mappings as $mapping) {
            if (!is_array($mapping)) {
                continue;
            }

            if ((string) ($mapping['url'] ?? '') !== $image_url) {
                continue;
            }

            $index = isset($mapping['key_index']) ? (int) $mapping['key_index'] : null;
            $this->write_service->delete_post_image($post_id, $index);
        }
    }
}
