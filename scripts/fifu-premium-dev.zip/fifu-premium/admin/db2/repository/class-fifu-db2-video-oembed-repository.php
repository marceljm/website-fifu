<?php

declare(strict_types=1);

defined('ABSPATH') || exit;

/**
 * Repository for managing video oEmbed cache entries in DB2.
 */
class Fifu_Db2_Video_Oembed_Repository {

    /** @var wpdb */
    private wpdb $wpdb;

    /** @var string */
    private string $table_video_oembed;

    public function __construct(?wpdb $wpdb_instance = null) {
        $this->wpdb = $wpdb_instance ?? $GLOBALS['wpdb'];
        $this->table_video_oembed = $this->wpdb->prefix . 'fifu_video_oembed';
    }

    public function upsert_oembed(string $video_url, string $image_url, string $embed_url): bool {
        $sanitized_video_url = $this->sanitize_oembed_url($video_url);
        $sanitized_image_url = $this->sanitize_oembed_url($image_url);
        $sanitized_embed_url = $this->sanitize_oembed_url($embed_url);

        if ($sanitized_video_url === '' || $sanitized_image_url === '' || $sanitized_embed_url === '') {
            return false;
        }

        $existing = $this->get_oembed_row_by_video_url($sanitized_video_url);
        if ($existing && $existing->image_url === $sanitized_image_url && $existing->embed_url === $sanitized_embed_url) {
            return true;
        }

        if ($existing) {
            $result = $this->wpdb->update(
                $this->table_video_oembed,
                [
                    'image_url' => $sanitized_image_url,
                    'embed_url' => $sanitized_embed_url,
                ],
                ['id' => $existing->id],
                ['%s', '%s'],
                ['%d']
            );

            return $result !== false;
        }

        $result = $this->wpdb->query(
            $this->wpdb->prepare(
                "INSERT INTO {$this->table_video_oembed} (video_url, image_url, embed_url) VALUES (%s, %s, %s) ON DUPLICATE KEY UPDATE image_url = VALUES(image_url), embed_url = VALUES(embed_url)",
                $sanitized_video_url,
                $sanitized_image_url,
                $sanitized_embed_url
            )
        );

        return $result !== false;
    }

    public function delete_by_video_url(string $video_url): void {
        $sanitized = $this->sanitize_oembed_url($video_url);
        $this->wpdb->query(
            $this->wpdb->prepare(
                "DELETE FROM {$this->table_video_oembed} WHERE video_url = %s",
                $sanitized
            )
        );
    }

    public function delete_by_image_url(string $image_url): void {
        $sanitized = $this->sanitize_oembed_url($image_url);
        $this->wpdb->query(
            $this->wpdb->prepare(
                "DELETE FROM {$this->table_video_oembed} WHERE image_url = %s",
                $sanitized
            )
        );
    }

    public function delete_vimeo_oembed_cache(): void {
        $this->wpdb->query(
            "DELETE FROM {$this->table_video_oembed}
             WHERE video_url LIKE '%vimeo.com%'
                OR video_url LIKE '%player.vimeo.com%'"
        );
    }

    public function get_image_url_by_video_url(string $video_url): ?string {
        $row = $this->get_oembed_row_by_video_url($this->sanitize_oembed_url($video_url));
        return $row ? $row->image_url : null;
    }

    public function get_embed_url_by_video_url(string $video_url): ?string {
        $row = $this->get_oembed_row_by_video_url($this->sanitize_oembed_url($video_url));
        return $row ? $row->embed_url : null;
    }

    public function get_embed_url_by_image_url(string $image_url): ?string {
        $sanitized = $this->sanitize_oembed_url($image_url);
        if ($sanitized === '') {
            return null;
        }
        $result = $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT embed_url FROM {$this->table_video_oembed} WHERE image_url = %s",
                $sanitized
            )
        );
        return $result ? $result->embed_url : null;
    }

    public function exists(string $video_url): bool {
        return (bool) $this->get_oembed_row_by_video_url($this->sanitize_oembed_url($video_url));
    }

    private function get_oembed_row_by_video_url(string $video_url) {
        if ($video_url === '') {
            return null;
        }

        $sql = $this->wpdb->prepare(
            "SELECT id, video_url, image_url, embed_url FROM {$this->table_video_oembed} WHERE video_url = %s LIMIT 1",
            $video_url
        );
        return $this->wpdb->get_row($sql);
    }

    private function sanitize_oembed_url(string $url): string {
        if (trim($url) === '') {
            return '';
        }

        $protocols = function_exists('wp_allowed_protocols')
            ? wp_allowed_protocols()
            : ['http', 'https', 'ftp', 'ftps', 'mailto', 'news', 'irc', 'gopher', 'nntp', 'feed', 'telnet', 'mms', 'rtsp', 'svn', 'tel', 'fax', 'sms', 'cid', 'xmpp', 'webcal', 'urn'];
        $scheme = wp_parse_url(ltrim($url), PHP_URL_SCHEME);

        if (
            is_string($scheme)
            && $scheme !== ''
            && strpos($scheme, 'fifu-') === 0
            && ! in_array($scheme, $protocols, true)
        ) {
            $protocols[] = $scheme;
        }

        return (string) esc_url_raw($url, $protocols);
    }
}
