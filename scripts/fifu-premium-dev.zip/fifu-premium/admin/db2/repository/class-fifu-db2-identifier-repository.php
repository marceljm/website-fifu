<?php
declare(strict_types=1);

/**
 * Repository that writes identifier rows into the db2 identifier tables.
 */
class Fifu_Db2_Identifier_Repository {
    private wpdb $wpdb;
    private string $tableIdentifier;
    private string $tableType;

    /** @var array<string, int|null> */
    private array $typeIdCache = [];

    public function __construct(?wpdb $wpdbInstance = null) {
        if ($wpdbInstance === null) {
            /**
             * phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
             */
            global $wpdb;
            $wpdbInstance = $wpdb;
        }

        $this->wpdb = $wpdbInstance;
        $this->tableIdentifier = $wpdbInstance->prefix . 'fifu_identifier';
        $this->tableType = $wpdbInstance->prefix . 'fifu_identifier_type';
    }

    public function upsert_post_identifier(int $postId, string $typeKey, string $value, int $invalid = 0, int $notFound = 0): bool {
        $typeId = $this->resolveTypeId($typeKey);
        if ($typeId === null) {
            return false;
        }

        $query = $this->wpdb->prepare(
            "INSERT INTO {$this->tableIdentifier} (post_id, type_id, id_value, invalid, not_found) VALUES (%d, %d, %s, %d, %d) ON DUPLICATE KEY UPDATE id_value = VALUES(id_value), invalid = VALUES(invalid), not_found = VALUES(not_found)",
            $postId,
            $typeId,
            $value,
            $invalid,
            $notFound
        );

        $result = $this->wpdb->query($query);
        return $result !== false;
    }

    public function delete_post_identifier(int $postId, string $typeKey): int {
        $typeId = $this->resolveTypeId($typeKey);
        if ($typeId === null) {
            return 0;
        }

        $result = $this->wpdb->delete(
            $this->tableIdentifier,
            [
                'post_id' => $postId,
                'type_id' => $typeId,
            ],
            [
                '%d',
                '%d',
            ]
        );

        return $result === false ? 0 : (int) $result;
    }

    public function get_post_identifier(int $postId, string $typeKey): ?array {
        $typeId = $this->resolveTypeId($typeKey);
        if ($typeId === null) {
            return null;
        }

        $query = $this->wpdb->prepare(
            "SELECT id_value, invalid, not_found FROM {$this->tableIdentifier} WHERE post_id = %d AND type_id = %d LIMIT 1",
            $postId,
            $typeId
        );

        $row = $this->wpdb->get_row($query, ARRAY_A);
        if ($row === null || $row === false) {
            return null;
        }

        return [
            'value' => trim((string) ($row['id_value'] ?? '')),
            'invalid' => isset($row['invalid']) ? (int) $row['invalid'] : 0,
            'not_found' => isset($row['not_found']) ? (int) $row['not_found'] : 0,
        ];
    }

    private function resolveTypeId(string $typeKey): ?int {
        if (array_key_exists($typeKey, $this->typeIdCache)) {
            return $this->typeIdCache[$typeKey];
        }

        $query = $this->wpdb->prepare(
            "SELECT type_id FROM {$this->tableType} WHERE type_key = %s LIMIT 1",
            $typeKey
        );

        $typeId = $this->wpdb->get_var($query);
        $resolved = $typeId === null ? null : (int) $typeId;
        $this->typeIdCache[$typeKey] = $resolved;

        return $resolved;
    }
}
