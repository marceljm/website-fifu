<?php

declare(strict_types=1);

/**
 * Repository responsible for FIFU import table queries.
 */
class Fifu_Db2_Import_Repository {

    private wpdb $wpdb;
    private string $import_table;
    private string $postmeta_table;
    private string $termmeta_table;
    private const META_KEY_POST = 'fifu_metadatapost_sent';
    private const META_KEY_TERM = 'fifu_metadataterm_sent';
    private const META_KEY_IMPORT_POST = 'fifu_importpost_sent';
    private const META_KEY_IMPORT_TERM = 'fifu_importterm_sent';
    private const EVENT_KEY_POST = 'metadatapost';
    private const EVENT_KEY_TERM = 'metadataterm';
    private const EVENT_KEY_IMPORT_POST = 'importpost';
    private const EVENT_KEY_IMPORT_TERM = 'importterm';

    /**
     * @param wpdb $wpdb
     * @param string $import_table
     * @param string $postmeta_table
     * @param string $termmeta_table
     */
    public function __construct(wpdb $wpdb, string $import_table, string $postmeta_table, string $termmeta_table) {
        $this->wpdb = $wpdb;
        $this->import_table = $import_table;
        $this->postmeta_table = $postmeta_table;
        $this->termmeta_table = $termmeta_table;
    }

    /**
     * Queue a post for import by persisting the post ID and category flag.
     */
    public function insert_import(int $postId, bool $isCategory): void {
        $sql = $this->wpdb->prepare(
            "INSERT INTO {$this->import_table} (post_id, category) VALUES (%d, %d)
             ON DUPLICATE KEY UPDATE post_id = VALUES(post_id), category = VALUES(category)",
            $postId,
            (int) $isCategory
        );
        $this->wpdb->query($sql);
    }

    /**
     * Retrieve post IDs that already have the requested metadata and are queued as posts.
     */
    public function get_valid_post_ids(array $postIds, string $metaKey): array {
        $eventKey = $this->get_sent_event_key_for_post_meta($metaKey);
        if ($eventKey !== null && $this->has_sent_tables()) {
                return $this->get_sent_object_ids(
                    'post',
                    $eventKey,
                    $postIds,
                    $this->should_require_sent_true($metaKey),
                    $this->should_require_import_queue($metaKey),
                    0
                );
        }

        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($postIds);
        if ($idsCsv === '0') {
            return [];
        }

        $sql = $this->wpdb->prepare(
            "SELECT DISTINCT fi.post_id
             FROM {$this->import_table} fi
             WHERE fi.post_id IN ($idsCsv)
               AND fi.category = 0
               AND EXISTS (
                   SELECT 1 FROM {$this->postmeta_table} pm
                   WHERE pm.post_id = fi.post_id AND pm.meta_key = %s
               )",
            $metaKey
        );

        return (array) $this->wpdb->get_col($sql);
    }

    /**
     * Retrieve term IDs that already have the requested metadata and are queued as categories.
     */
    public function get_valid_term_ids(array $termIds, string $metaKey): array {
        $eventKey = $this->get_sent_event_key_for_term_meta($metaKey);
        if ($eventKey !== null && $this->has_sent_tables()) {
                return $this->get_sent_object_ids(
                    'term',
                    $eventKey,
                    $termIds,
                    $this->should_require_sent_true($metaKey),
                    $this->should_require_import_queue($metaKey),
                    1
                );
        }

        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($termIds);
        if ($idsCsv === '0') {
            return [];
        }

        $sql = $this->wpdb->prepare(
            "SELECT DISTINCT fi.post_id
             FROM {$this->import_table} fi
             WHERE fi.post_id IN ($idsCsv)
               AND fi.category = 1
               AND EXISTS (
                   SELECT 1 FROM {$this->termmeta_table} tm
                   WHERE tm.term_id = fi.post_id AND tm.meta_key = %s
               )",
            $metaKey
        );

        return (array) $this->wpdb->get_col($sql);
    }

    private function is_metadata_sent_meta_key(string $metaKey): bool {
        return $metaKey === self::META_KEY_POST || $metaKey === self::META_KEY_TERM;
    }

    private function get_sent_event_key_for_post_meta(string $metaKey): ?string {
        if ($metaKey === self::META_KEY_POST) {
            return self::EVENT_KEY_POST;
        }

        if ($metaKey === self::META_KEY_IMPORT_POST) {
            return self::EVENT_KEY_IMPORT_POST;
        }

        return null;
    }

    private function get_sent_event_key_for_term_meta(string $metaKey): ?string {
        if ($metaKey === self::META_KEY_TERM) {
            return self::EVENT_KEY_TERM;
        }

        if ($metaKey === self::META_KEY_IMPORT_TERM) {
            return self::EVENT_KEY_IMPORT_TERM;
        }

        return null;
    }

    private function has_sent_tables(): bool {
        return $this->table_exists($this->get_sent_table_name())
            && $this->table_exists($this->get_sent_event_table_name());
    }

    private function get_sent_table_name(): string {
        return $this->wpdb->prefix . 'fifu_sent';
    }

    private function get_sent_event_table_name(): string {
        return $this->wpdb->prefix . 'fifu_sent_event';
    }

    private function table_exists(string $table): bool {
        $sql = $this->wpdb->prepare("SHOW TABLES LIKE %s", $table);
        $result = $this->wpdb->get_var($sql);
        return $result !== null && $result !== false;
    }

    private function should_require_sent_true(string $metaKey): bool {
        return $metaKey === self::META_KEY_POST || $metaKey === self::META_KEY_TERM;
    }

    private function should_require_import_queue(string $metaKey): bool {
        return $metaKey === self::META_KEY_IMPORT_POST || $metaKey === self::META_KEY_IMPORT_TERM;
    }

    private function get_sent_object_ids(
        string $object_type,
        string $event_key,
        array $ids,
        bool $requireSentTrue,
        bool $requireImportQueue,
        int $categoryFlag
    ): array {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($ids);
        if ($idsCsv === '0') {
            return [];
        }

        $sentTable = $this->get_sent_table_name();
        $eventTable = $this->get_sent_event_table_name();

        $sql = "
            SELECT s.object_id
            FROM {$sentTable} s
            INNER JOIN {$eventTable} e ON e.id = s.event_id
            WHERE s.object_type = %s
              AND e.event_key = %s
              AND s.object_id IN ({$idsCsv})
        ";

        if ($requireSentTrue) {
            $sql .= "
              AND s.sent = 1
            ";
        } else {
            $sql .= "
              AND s.id IS NOT NULL
            ";
        }

        if ($requireImportQueue) {
            $sql .= "
              AND EXISTS (
                  SELECT 1
                  FROM {$this->import_table} fi
                  WHERE fi.post_id = s.object_id
                    AND fi.category = {$categoryFlag}
              )
            ";
        }

        $prepared = $this->wpdb->prepare($sql, $object_type, $event_key);
        $results = $this->wpdb->get_col($prepared);
        if (!is_array($results)) {
            return [];
        }

        return array_map('intval', $results);
    }
}
