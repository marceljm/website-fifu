<?php
declare(strict_types=1);


/**
 * Encapsulates heavy db and thumbnail queries for the speed-up UI.
 */
class Fifu_Db2_Speed_Up_Repository {
    private const DB2_MANAGED_LEGACY_KEYS = array(
        'fifu_redirection_url',
        'fifu_finder_url',
        'fifu_audio_url',
        'fifu_video_url',
        'fifu_image_alt',
        'fifu_image_url',
        'fifu_custom_video_url',
        'fifu_list_url',
        'fifu_list_alt',
        'fifu_list_video_url',
        'fifu_slider_list_url',
        'fifu_slider_list_alt',
    );

    private const DB2_MANAGED_SUFFIX_PATTERN = '/^(fifu_slider_image_(alt|url)|fifu_image_ifm|fifu_(video_url|image_url|image_alt))_\\d+$/';

    private wpdb $wpdb;
    private string $posts;
    private string $postmeta;
    private string $terms;
    private string $termmeta;
    private string $termTaxonomy;
    private string $termRelationships;
    private string $fifu_term_map_table;
    private string $fifu_map_table;
    private string $fifu_key_table;
    private string $fifu_url_table;
    private string $typesForInClause;
    private const LOCAL_IMAGE_POST_CONFLICT_KEYS = [
        'bkp_thumbnail_id',
        'bkp_product_image_gallery',
        'fifu_image_url',
        'fifu_video_url',
        'fifu_custom_video_url',
        'fifu_list_url',
        'fifu_list_video_url',
        'fifu_slider_list_url',
    ];
    private const LOCAL_IMAGE_TERM_CONFLICT_KEYS = [
        'bkp_thumbnail_id',
        'fifu_image_url',
        'fifu_video_url',
        'fifu_custom_video_url',
        'fifu_ctgr_image_url',
        'fifu_ctgr_video_url',
    ];

    private function debug_auto_category(string $message, array $context = []): void
    {
        if (!function_exists('get_option') || !get_option('fifu_debug_auto_category')) {
            return;
        }

        if (function_exists('wp_json_encode')) {
            error_log('[FIFU Auto Category DB2] ' . $message . ' ' . wp_json_encode($context));
            return;
        }

        error_log('[FIFU Auto Category DB2] ' . $message . ' ' . json_encode($context));
    }

    /**
     * Sets up the repository with the WordPress database connection.
     *
     * @param wpdb $wpdb
     */
    public function __construct( wpdb $wpdb ) {
        $this->wpdb = $wpdb;
        $prefix = $wpdb->prefix;
        $this->posts = $prefix . 'posts';
        $this->postmeta = $prefix . 'postmeta';
        $this->terms = $prefix . 'terms';
        $this->termmeta = $prefix . 'termmeta';
        $this->termTaxonomy = $prefix . 'term_taxonomy';
        $this->termRelationships = $prefix . 'term_relationships';
        $this->fifu_term_map_table = $prefix . 'fifu_term_map';
        $this->fifu_map_table = $prefix . 'fifu_map';
        $this->fifu_key_table = $prefix . 'fifu_key';
        $this->fifu_url_table = $prefix . 'fifu_url';
        $this->typesForInClause = Fifu_Db2_Sql_Helper::get_types_for_in_clause();
    }

    /**
     * Provides direct access to the WordPress database object for transaction handling.
     *
     * @return wpdb
     */
    public function get_wpdb(): wpdb {
        return $this->wpdb;
    }

    /**
     * Returns product/product_variation IDs that have a non-empty temporary
     * WooCommerce gallery snapshot.
     *
     * This avoids scanning every post with get_post_meta() during Image Metadata
     * rebuilds when no fifu_tmp_product_image_gallery snapshot exists.
     *
     * @param int[] $postIds
     * @return int[]
     */
    public function get_post_ids_with_tmp_product_gallery_snapshots(array $postIds): array {
        $postIds = array_values(array_unique(array_filter(
            array_map('intval', $postIds),
            static fn (int $postId): bool => $postId > 0
        )));

        if ($postIds === []) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($postIds), '%d'));

        $sql = "
            SELECT DISTINCT pm.post_id
            FROM {$this->postmeta} pm
            INNER JOIN {$this->posts} p ON p.ID = pm.post_id
            WHERE pm.post_id IN ({$placeholders})
              AND pm.meta_key = 'fifu_tmp_product_image_gallery'
              AND pm.meta_value IS NOT NULL
              AND TRIM(pm.meta_value) <> ''
              AND p.post_type IN ('product', 'product_variation')
        ";

        $ids = $this->wpdb->get_col($this->wpdb->prepare($sql, ...$postIds));
        if (!is_array($ids)) {
            return [];
        }

        $ids = array_values(array_unique(array_filter(
            array_map('intval', $ids),
            static fn (int $postId): bool => $postId > 0
        )));

        sort($ids);

        return $ids;
    }

    /**
     * Return only product_variation IDs from a sanitized post ID list.
     *
     * @param int[] $postIdsArray
     * @return int[]
     */
    private function get_product_variation_post_ids(array $postIdsArray): array {
        $postIdsArray = array_values(array_filter(array_map('intval', $postIdsArray)));
        if ($postIdsArray === []) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($postIdsArray), '%d'));
        $sql = "
            SELECT ID
            FROM {$this->posts}
            WHERE ID IN ({$placeholders})
              AND post_type = 'product_variation'
        ";

        $ids = $this->wpdb->get_col($this->wpdb->prepare($sql, ...$postIdsArray));
        if (!is_array($ids)) {
            return [];
        }

        return array_values(array_unique(array_filter(array_map('intval', $ids))));
    }

    /**
     * Return only product IDs from a sanitized post ID list.
     *
     * @param int[] $postIdsArray
     * @return int[]
     */
    private function get_product_post_ids(array $postIdsArray): array {
        $postIdsArray = array_values(array_filter(array_map('intval', $postIdsArray)));
        if ($postIdsArray === []) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($postIdsArray), '%d'));
        $sql = "
            SELECT ID
            FROM {$this->posts}
            WHERE ID IN ({$placeholders})
              AND post_type = 'product'
        ";

        $ids = $this->wpdb->get_col($this->wpdb->prepare($sql, ...$postIdsArray));
        if (!is_array($ids)) {
            return [];
        }

        return array_values(array_unique(array_filter(array_map('intval', $ids))));
    }

    /**
     * Checks whether the current attachment batch can produce at least one
     * _wp_attachment_image_alt row.
     *
     * Keep this WHERE clause aligned with the existing insert_attachment_alt SQL.
     *
     * @param int[] $postIdsArray
     */
    private function has_insertable_woocommerce_attachment_alt_meta(array $postIdsArray, int $author, string $thumbClause): bool {
        $postIdsArray = array_values(array_filter(array_map('intval', $postIdsArray)));
        if ($postIdsArray === []) {
            return false;
        }

        $postPlaceholders = implode(',', array_fill(0, count($postIdsArray), '%d'));

        $sql = "
            SELECT 1
            FROM {$this->posts} p
            WHERE p.post_parent IN ({$postPlaceholders})
              {$thumbClause}
              AND p.post_author = %d
              AND p.post_excerpt IS NOT NULL
              AND p.post_excerpt <> ''
            LIMIT 1
        ";

        $args = array_merge($postIdsArray, [$author]);

        return (bool) $this->wpdb->get_var($this->wpdb->prepare($sql, ...$args));
    }

    /**
     * Builds the storage URL for an SU bucket/storage pair.
     *
     * @param string|int $bucket_id
     * @param string $storage_id
     * @return string
     */
    private function build_su_url(string|int $bucket_id, string $storage_id): string {
        return 'https://cdn.fifu.app/' . $bucket_id . '/' . $storage_id;
    }

    private function resolve_internal_attachment_url(int $attachmentId): string
    {
        if ($attachmentId <= 0) {
            return '';
        }

        $attachedFile = trim((string) get_post_meta($attachmentId, '_wp_attached_file', true));
        if ($attachedFile !== '' && preg_match('#^https?://#i', $attachedFile)) {
            return $attachedFile;
        }

        $url = function_exists('wp_get_attachment_url') ? wp_get_attachment_url($attachmentId) : false;
        return is_string($url) ? trim($url) : '';
    }

    private function hydrate_internal_attachment_rows(array $rows): array {
        $hydrated = [];

        foreach ($rows as $row) {
            if (!is_object($row)) {
                continue;
            }

            $attachmentId = (int) ($row->thumbnail_id ?? $row->att_id ?? 0);
            if ($attachmentId <= 0) {
                continue;
            }

            $realUrl = $this->resolve_internal_attachment_url($attachmentId);
            if ($realUrl === '') {
                continue;
            }

            $row->url = $realUrl;
            $hydrated[] = $row;
        }

        return $hydrated;
    }

    private function is_valid_effective_db2_url(?string $url): bool {
        $url = trim((string) $url);
        if ($url === '') {
            return false;
        }

        if (class_exists('Fifu_Db2_Normalizer', false) && method_exists('Fifu_Db2_Normalizer', 'is_valid_url')) {
            return Fifu_Db2_Normalizer::is_valid_url($url);
        }

        return true;
    }

    private function has_effective_fifu_db2_state(int $postId, bool $isCategory = false): bool {
        if ($postId <= 0 || !$this->has_speedup_db2_tables()) {
            return false;
        }

        $mapTable = $isCategory && $this->has_term_speedup_db2_tables()
            ? $this->fifu_term_map_table
            : $this->fifu_map_table;
        $objectColumn = $isCategory ? 'term_id' : 'post_id';
        $sql = $this->wpdb->prepare(
            "
            SELECT u.url
            FROM {$mapTable} m
            INNER JOIN {$this->fifu_key_table} k ON k.key_id = m.key_id
            INNER JOIN {$this->fifu_url_table} u ON u.hash = m.hash
            WHERE m.{$objectColumn} = %d
              AND k.key_type IN ('image','video','custom_video','slider')
            ",
            $postId
        );

        $urls = $this->wpdb->get_col($sql);
        if (!is_array($urls)) {
            return false;
        }

        foreach ($urls as $url) {
            if ($this->is_valid_effective_db2_url(is_string($url) ? $url : null)) {
                return true;
            }
        }

        return false;
    }

    private function has_effective_fifu_legacy_state(int $postId, bool $isCategory = false): bool {
        if ($postId <= 0) {
            return false;
        }

        $getMeta = static function (int $objectId, string $metaKey) use ($isCategory): string {
            return $isCategory ? (string) get_term_meta($objectId, $metaKey, true) : (string) get_post_meta($objectId, $metaKey, true);
        };

        $legacyKeys = [
            'fifu_image_url',
            'fifu_list_url',
            'fifu_video_url',
            'fifu_list_video_url',
            'fifu_custom_video_url',
            'fifu_slider_list_url',
        ];

        foreach ($legacyKeys as $metaKey) {
            $value = trim($getMeta($postId, $metaKey));
            if ($value !== '') {
                return true;
            }
        }

        $allMeta = $isCategory ? get_term_meta($postId) : get_post_custom($postId);
        if (is_array($allMeta)) {
            foreach (['fifu_image_url_', 'fifu_video_url_', 'fifu_slider_image_url_'] as $prefix) {
                foreach ($allMeta as $metaKey => $metaValues) {
                    if (!is_string($metaKey) || strpos($metaKey, $prefix) !== 0) {
                        continue;
                    }

                    $value = $metaValues[0] ?? '';
                    if (trim((string) $value) !== '') {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    private function has_effective_fifu_state(int $postId): bool {
        return $this->has_effective_fifu_db2_state($postId) || $this->has_effective_fifu_legacy_state($postId);
    }

    private function has_effective_fifu_state_for_row(int $objectId, bool $isCategory): bool {
        return $this->has_effective_fifu_db2_state($objectId, $isCategory) || $this->has_effective_fifu_legacy_state($objectId, $isCategory);
    }

    private function has_local_conversion_backup_state_for_row(int $objectId, bool $isCategory): bool
    {
        if ($objectId <= 0) {
            return false;
        }

        if ($isCategory) {
            return metadata_exists('term', $objectId, 'bkp_thumbnail_id') && trim((string) get_term_meta($objectId, 'bkp_thumbnail_id', true)) !== '';
        }

        return (
            (metadata_exists('post', $objectId, 'bkp_thumbnail_id') && trim((string) get_post_meta($objectId, 'bkp_thumbnail_id', true)) !== '')
            || (metadata_exists('post', $objectId, 'bkp_product_image_gallery') && trim((string) get_post_meta($objectId, 'bkp_product_image_gallery', true)) !== '')
        );
    }

    private function filter_out_managed_local_media(array $rows): array {
        $filtered = [];

        foreach ($rows as $row) {
            if (!is_object($row)) {
                continue;
            }

            $postId = (int) ($row->post_id ?? 0);
            $isCategory = !empty($row->category);
            if ($postId > 0 && (
                $this->has_effective_fifu_state_for_row($postId, $isCategory)
                || $this->has_local_conversion_backup_state_for_row($postId, $isCategory)
            )) {
                continue;
            }

            $filtered[] = $row;
        }

        return $filtered;
    }

    /**
     * Removes any SU video thumbnail suffix so the base video URL can be compared or rebuilt.
     *
     * @param string $url
     * @return string
     */
    private function strip_suvideo_thumb_suffix(string $url): string {
        $url = trim($url);
        if ($url === '') {
            return '';
        }

        $stripped = preg_replace('/[?&]fifu-thumb=.*/', '', $url);
        return is_string($stripped) ? $stripped : $url;
    }

    /**
     * Normalizes any legacy SU video separator to the canonical ?fifu-thumb= marker.
     *
     * @param string $url
     * @return string
     */
    private function normalize_suvideo_thumb_separator(string $url): string {
        $url = trim($url);
        if ($url === '') {
            return '';
        }

        $normalized = preg_replace('/[?&]fifu-thumb=/', '?fifu-thumb=', $url, 1);
        return is_string($normalized) ? $normalized : $url;
    }

    /**
     * Builds the canonical SU transport URL for a video entry and its thumbnail.
     *
     * @param string $videoUrl
     * @param string $thumbUrl
     * @return string
     */
    private function build_suvideo_transport_url(string $videoUrl, string $thumbUrl): string {
        $videoUrl = trim($videoUrl);
        $thumbUrl = trim($thumbUrl);

        if ($videoUrl === '') {
            return '';
        }

        if ($thumbUrl === '') {
            return $this->normalize_suvideo_thumb_separator($videoUrl);
        }

        if (strpos($videoUrl, 'fifu-thumb=') !== false) {
            return $this->normalize_suvideo_thumb_separator($videoUrl);
        }

        $baseVideoUrl = $this->strip_suvideo_thumb_suffix($videoUrl);
        $baseVideoUrl = rtrim($baseVideoUrl, " &?\n\r\t\v\0");

        if ($baseVideoUrl === '') {
            return '';
        }

        return $baseVideoUrl . '?fifu-thumb=' . $thumbUrl;
    }

    /**
     * Replaces a video entry inside a pipe-delimited list using the canonical SU transport URL.
     *
     * @param string $listValue
     * @param string $baseVideoUrl
     * @param string $replacement
     * @return string
     */
    private function replace_suvideo_entry_in_pipe_list(string $listValue, string $baseVideoUrl, string $replacement): string {
        $baseVideoUrl = $this->strip_suvideo_thumb_suffix($baseVideoUrl);
        $replacement = trim($replacement);

        if ($listValue === '' || $baseVideoUrl === '' || $replacement === '') {
            return $listValue;
        }

        $entries = explode('|', $listValue);
        $changed = false;

        foreach ($entries as $index => $entry) {
            $entryString = trim((string) $entry);
            if ($entryString === '') {
                continue;
            }

            $entryBase = $this->strip_suvideo_thumb_suffix($entryString);
            if ($entryBase === $baseVideoUrl) {
                $entries[$index] = $replacement;
                $changed = true;
            }
        }

        if ($changed) {
            return implode('|', $entries);
        }

        return str_replace($baseVideoUrl, $replacement, $listValue);
    }

    /**
     * Lists all URLs for the admin speed-up table.
     *
     * @param int $page
     * @param string|null $type
     * @param string|null $keyword
     * @return array
     */
    public function get_all_urls(int $page, ?string $type, ?string $keyword): array {
        $page = max(0, $page);

        if (!function_exists('fifu_db2_mode')) {
            return $this->get_all_urls_legacy($page, $type, $keyword);
        }

        $mode = fifu_db2_mode();

        if ($mode === Fifu_Db2_Mode::MODE_DB2) {
            $db2Rows = $this->get_all_urls_db2($page, $type, $keyword);
            if ($db2Rows !== null) {
                return $db2Rows;
            }

            return $this->get_all_urls_legacy($page, $type, $keyword);
        }

        if ($mode === Fifu_Db2_Mode::MODE_LEGACY || $mode === Fifu_Db2_Mode::MODE_HYBRID) {
            return $this->get_all_urls_hybrid($page, $type, $keyword);
        }

        return $this->get_all_urls_legacy($page, $type, $keyword);
    }

    private function get_all_urls_legacy(int $page, ?string $type, ?string $keyword): array {
        $page = max(0, $page);
        $start = $page * 1000;

        $filter_posts = '';
        if ($keyword) {
            $like = '%' . $this->wpdb->esc_like($keyword) . '%';
            if ($type === 'title') {
                $filter_posts = $this->wpdb->prepare('AND p.post_title LIKE %s', $like);
            } elseif ($type === 'url') {
                $filter_posts = $this->wpdb->prepare('AND pm.meta_value LIKE %s', $like);
            }
        }

        $sql = "
            (
                SELECT pm.meta_id, pm.post_id, pm.meta_value AS url, pm.meta_key, p.post_name, p.post_title, p.post_date, false AS category, null AS video_url
                FROM {$this->postmeta} pm
                INNER JOIN {$this->posts} p ON pm.post_id = p.id {$filter_posts}
                WHERE (pm.meta_key LIKE 'fifu_%image_url%' OR pm.meta_key LIKE 'fifu_video_url%')
                AND pm.meta_key NOT LIKE 'fifu_image_url_%'
                AND pm.meta_key NOT LIKE 'fifu_video_url_%'
                AND pm.meta_key NOT LIKE 'fifu_slider_image_url_%'
                AND pm.meta_value NOT LIKE '%https://cdn.fifu.app/%'
                AND pm.meta_value NOT LIKE 'http://localhost/%'
                AND p.post_status <> 'trash'
            )
        ";

        if (class_exists('WooCommerce')) {
            $filter_terms = '';
            if ($keyword) {
                $like = '%' . $this->wpdb->esc_like($keyword) . '%';
                if ($type === 'title') {
                    $filter_terms = $this->wpdb->prepare('AND t.name LIKE %s', $like);
                } elseif ($type === 'url') {
                    $filter_terms = $this->wpdb->prepare('AND tm.meta_value LIKE %s', $like);
                }
            }
            $sql .= "
                UNION
                (
                    SELECT tm.meta_id, tm.term_id AS post_id, tm.meta_value AS url, tm.meta_key, null AS post_name, t.name AS post_title, null AS post_date, true AS category, null AS video_url
                    FROM {$this->termmeta} tm
                    INNER JOIN {$this->terms} t ON tm.term_id = t.term_id {$filter_terms}
                    WHERE tm.meta_key IN ('fifu_image_url', 'fifu_video_url')
                    AND tm.meta_key NOT LIKE 'fifu_image_url_%'
                    AND tm.meta_key NOT LIKE 'fifu_video_url_%'
                    AND tm.meta_value NOT LIKE '%https://cdn.fifu.app/%'
                    AND tm.meta_value NOT LIKE 'http://localhost/%'
                )
            ";
        }

        $sql .= "
            ORDER BY post_id DESC
            LIMIT {$start},1000
        ";

        $rows = $this->wpdb->get_results($sql);
        return is_array($rows) ? $rows : [];
    }

    private function get_all_urls_db2(int $page, ?string $type, ?string $keyword): ?array {
        if (!$this->has_speedup_db2_tables()) {
            return null;
        }

        $page = max(0, $page);
        $start = $page * 1000;
        $includeTerms = class_exists('WooCommerce') && $this->has_term_speedup_db2_tables();

        $filter_posts = '';
        if ($keyword) {
            $like = '%' . $this->wpdb->esc_like($keyword) . '%';
            if ($type === 'title') {
                $filter_posts = $this->wpdb->prepare('AND p.post_title LIKE %s', $like);
            } elseif ($type === 'url') {
                $filter_posts = $this->wpdb->prepare('AND u.url LIKE %s', $like);
            }
        }

        $sql = "
            (
                SELECT
                    m.id AS meta_id,
                    m.post_id,
                    u.url AS url,
                    CASE
                        WHEN k.key_type = 'image' AND m.key_index = 0 THEN 'fifu_image_url'
                        WHEN k.key_type = 'image' THEN CONCAT('fifu_image_url_', m.key_index - 1)
                        WHEN k.key_type = 'slider' THEN CONCAT('fifu_slider_image_url_', m.key_index)
                        WHEN k.key_type = 'video' AND m.key_index = 0 THEN 'fifu_video_url'
                        ELSE CONCAT('fifu_video_url_', m.key_index - 1)
                    END AS meta_key,
                    p.post_name,
                    p.post_title,
                    p.post_date,
                    FALSE AS category,
                    NULL AS video_url
                FROM {$this->fifu_map_table} m
                INNER JOIN {$this->fifu_key_table} k ON k.key_id = m.key_id
                INNER JOIN {$this->fifu_url_table} u ON u.hash = m.hash
                INNER JOIN {$this->posts} p ON p.ID = m.post_id {$filter_posts}
                WHERE k.key_type IN ('image','video','slider')
                  AND u.url NOT LIKE '%https://cdn.fifu.app/%'
                  AND u.url NOT LIKE 'http://localhost/%'
                  AND p.post_status <> 'trash'
            )
        ";

        if ($includeTerms) {
            $filter_terms = '';
            if ($keyword) {
                $like = '%' . $this->wpdb->esc_like($keyword) . '%';
                if ($type === 'title') {
                    $filter_terms = $this->wpdb->prepare('AND t.name LIKE %s', $like);
                } elseif ($type === 'url') {
                    $filter_terms = $this->wpdb->prepare('AND u.url LIKE %s', $like);
                }
            }

            $sql .= "
                UNION
                (
                    SELECT
                        tm.id AS meta_id,
                        tm.term_id AS post_id,
                        u.url AS url,
                        CASE
                            WHEN k.key_type = 'image' THEN 'fifu_image_url'
                            ELSE 'fifu_video_url'
                        END AS meta_key,
                        NULL AS post_name,
                        t.name AS post_title,
                        NULL AS post_date,
                        TRUE AS category,
                        NULL AS video_url
                    FROM {$this->fifu_term_map_table} tm
                    INNER JOIN {$this->fifu_key_table} k ON k.key_id = tm.key_id
                    INNER JOIN {$this->fifu_url_table} u ON u.hash = tm.hash
                    INNER JOIN {$this->terms} t ON t.term_id = tm.term_id {$filter_terms}
                    WHERE k.key_type IN ('image','video')
                      AND u.url NOT LIKE '%https://cdn.fifu.app/%'
                      AND u.url NOT LIKE 'http://localhost/%'
                )
            ";
        }

        $sql .= $this->wpdb->prepare(
            "
            ORDER BY post_id DESC
            LIMIT %d,1000
            ",
            $start
        );

        $rows = $this->wpdb->get_results($sql);
        if ($rows === false) {
            return null;
        }

        return $rows;
    }

    private function get_all_urls_hybrid(int $page, ?string $type, ?string $keyword): array {
        $page = max(0, $page);
        $offset = $page * 1000;
        $limit = 1000;
        $needed = $offset + $limit;
        $sourcePage = 0;
        $mergedMap = [];
        $legacyDone = false;
        $db2Done = false;

        while (count($mergedMap) < $needed && (!$legacyDone || !$db2Done)) {
            if (!$db2Done) {
                $db2Batch = $this->get_all_urls_db2($sourcePage, $type, $keyword);
                if ($db2Batch === null) {
                    $db2Done = true;
                } else {
                    $this->merge_upload_rows($mergedMap, $db2Batch, true);
                    if (count($db2Batch) < $limit) {
                        $db2Done = true;
                    }
                }
            }

            if (!$legacyDone) {
                $legacyBatch = $this->get_all_urls_legacy($sourcePage, $type, $keyword);
                $this->merge_upload_rows($mergedMap, $legacyBatch, false);
                if (count($legacyBatch) < $limit) {
                    $legacyDone = true;
                }
            }

            $sourcePage++;
        }

        $rows = array_values($mergedMap);
        usort($rows, static function ($left, $right): int {
            $postCompare = (int) ($right->post_id ?? 0) <=> (int) ($left->post_id ?? 0);
            if ($postCompare !== 0) {
                return $postCompare;
            }

            $categoryCompare = (int) ($left->category ?? 0) <=> (int) ($right->category ?? 0);
            if ($categoryCompare !== 0) {
                return $categoryCompare;
            }

            $metaKeyCompare = strcmp((string) ($left->meta_key ?? ''), (string) ($right->meta_key ?? ''));
            if ($metaKeyCompare !== 0) {
                return $metaKeyCompare;
            }

            return (int) ($right->meta_id ?? 0) <=> (int) ($left->meta_id ?? 0);
        });

        return array_slice($rows, $offset, $limit);
    }

    private function merge_upload_rows(array &$mergedMap, array $rows, bool $overwrite): void {
        foreach ($rows as $row) {
            $identityKey = $this->build_upload_row_identity_key($row);
            if ($identityKey === null) {
                continue;
            }

            if ($overwrite || !isset($mergedMap[$identityKey])) {
                $mergedMap[$identityKey] = $row;
            }
        }
    }

    private function build_upload_row_identity_key($row): ?string {
        if (!is_object($row) && !is_array($row)) {
            return null;
        }

        $category = (int) (!empty(is_array($row) ? ($row['category'] ?? 0) : ($row->category ?? 0)));
        $postId = (int) (is_array($row) ? ($row['post_id'] ?? 0) : ($row->post_id ?? 0));
        $metaKey = trim((string) (is_array($row) ? ($row['meta_key'] ?? '') : ($row->meta_key ?? '')));

        if ($postId <= 0 || $metaKey === '') {
            return null;
        }

        return "{$category}:{$postId}:{$metaKey}";
    }

    private function has_speedup_db2_tables(): bool {
        return $this->table_exists($this->fifu_map_table)
            && $this->table_exists($this->fifu_key_table)
            && $this->table_exists($this->fifu_url_table);
    }

    private function has_term_speedup_db2_tables(): bool {
        return $this->has_speedup_db2_tables()
            && $this->table_exists($this->fifu_term_map_table)
            && $this->table_exists($this->terms);
    }

    private function table_exists(string $table): bool {
        $sql = $this->wpdb->prepare("SHOW TABLES LIKE %s", $table);
        $result = $this->wpdb->get_var($sql);
        return $result !== null;
    }

    /**
     * Returns all stored hex IDs.
     *
     * @return array
     */
    public function get_all_hex_ids(): array {
        if (!function_exists('fifu_db2_mode')) {
            return $this->get_all_hex_ids_legacy();
        }

        $mode = fifu_db2_mode();

        if ($mode === Fifu_Db2_Mode::MODE_DB2 || $mode === Fifu_Db2_Mode::MODE_HYBRID) {
            $db2Rows = $this->get_all_hex_ids_db2();
            if ($db2Rows !== null) {
                return $db2Rows;
            }
        }

        return $this->get_all_hex_ids_legacy();
    }

    private function get_all_hex_ids_legacy(): array {
        $sql = "
            (
                SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(pm.meta_value, '/', -1), '-', 1) AS hex_id
                FROM {$this->postmeta} pm
                INNER JOIN {$this->posts} p ON pm.post_id = p.id
                WHERE (pm.meta_key LIKE 'fifu_%image_url%' OR pm.meta_key LIKE 'fifu_video_url%')
                AND pm.meta_value LIKE '%https://cdn.fifu.app/%'
            )
        ";

        if (class_exists('WooCommerce')) {
            $sql .= "
                UNION
                (
                    SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(tm.meta_value, '/', -1), '-', 1) AS hex_id
                    FROM {$this->termmeta} tm
                    INNER JOIN {$this->terms} t ON tm.term_id = t.term_id
                    WHERE tm.meta_key IN ('fifu_image_url', 'fifu_video_url')
                    AND tm.meta_value LIKE '%https://cdn.fifu.app/%'
                )
            ";
        }

        $sql .= "
            ORDER BY hex_id DESC
        ";

        $hexIds = $this->wpdb->get_col($sql);
        return $hexIds ?: [];
    }

    private function get_all_hex_ids_db2(): ?array {
        if (!$this->has_speedup_db2_tables()) {
            return null;
        }

        if (class_exists('WooCommerce') && !$this->has_term_speedup_db2_tables()) {
            return null;
        }

        $sql = "
            (
                SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(u.url, '/', -1), '-', 1) AS hex_id
                FROM {$this->fifu_map_table} m
                INNER JOIN {$this->fifu_key_table} k ON k.key_id = m.key_id
                INNER JOIN {$this->fifu_url_table} u ON u.hash = m.hash
                INNER JOIN {$this->posts} p ON p.ID = m.post_id
                WHERE k.key_type IN ('image','video','slider')
                  AND u.url LIKE '%https://cdn.fifu.app/%'
            )
        ";

        if (class_exists('WooCommerce')) {
            $sql .= "
                UNION
                (
                    SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(u.url, '/', -1), '-', 1) AS hex_id
                    FROM {$this->fifu_term_map_table} tm
                    INNER JOIN {$this->fifu_key_table} k ON k.key_id = tm.key_id
                    INNER JOIN {$this->fifu_url_table} u ON u.hash = tm.hash
                    INNER JOIN {$this->terms} t ON t.term_id = tm.term_id
                    WHERE k.key_type IN ('image','video')
                      AND u.url LIKE '%https://cdn.fifu.app/%'
                )
            ";
        }

        $sql .= "
            ORDER BY hex_id DESC
        ";

        $hexIds = $this->wpdb->get_col($sql);
        if ($hexIds === false) {
            return null;
        }

        return $hexIds;
    }

    /**
     * Retrieves posts that have internal featured images.
     *
     * @param int $page
     * @param string|null $type
     * @param string|null $keyword
     * @return array
     */
    public function get_posts_with_internal_featured_image(int $page, ?string $type, ?string $keyword): array {
        $page = max(0, (int) $page);
        $type = $type ?? '';
        $keyword = $keyword ?? '';

        if (!function_exists('fifu_db2_mode')) {
            return $this->get_posts_with_internal_featured_image_legacy($page, $type, $keyword);
        }

        $mode = fifu_db2_mode();

        if ($mode === Fifu_Db2_Mode::MODE_DB2 || $mode === Fifu_Db2_Mode::MODE_HYBRID) {
            $db2Rows = $this->get_posts_with_internal_featured_image_db2($page, $type, $keyword);
            if ($db2Rows !== null) {
                return $db2Rows;
            }
        }

        return $this->get_posts_with_internal_featured_image_legacy($page, $type, $keyword);
    }

    private function get_posts_with_internal_featured_image_legacy(int $page, string $type, ?string $keyword): array {
        $start = $page * 1000;

        $filter = '';
        if ($keyword) {
            if ($type === 'title') {
                $like = '%' . $this->wpdb->esc_like($keyword) . '%';
                $filter = $this->wpdb->prepare('AND p.post_title LIKE %s', $like);
            } elseif ($type === 'postid') {
                $filter = $this->wpdb->prepare('AND pm.post_id = %d', (int) $keyword);
            }
        }

        $authorClause = $this->wpdb->prepare('AND att.post_author <> %d', $this->get_author());
        $sql = "
            (
                SELECT 
                    pm.post_id, 
                    att.guid AS url, 
                    p.post_name, 
                    p.post_title, 
                    p.post_date, 
                    att.id AS thumbnail_id,
                    (SELECT meta_value FROM {$this->postmeta} pm2 WHERE pm2.post_id = pm.post_id AND pm2.meta_key = '_product_image_gallery') AS gallery_ids,
                    false AS category
                FROM {$this->postmeta} pm
                INNER JOIN {$this->posts} p ON pm.post_id = p.id {$filter} AND p.post_title <> ''
                INNER JOIN {$this->posts} att ON (
                    pm.meta_key = '_thumbnail_id'
                    AND pm.meta_value = att.id
                    {$authorClause}
                )
                AND p.post_type <> 'attachment'
                AND p.post_status <> 'trash'
            )
        ";

        if (class_exists('WooCommerce')) {
            $filter = '';
            if ($keyword) {
                if ($type === 'title') {
                    $like = '%' . $this->wpdb->esc_like($keyword) . '%';
                    $filter = $this->wpdb->prepare('AND t.name LIKE %s', $like);
                } elseif ($type === 'postid') {
                    $filter = $this->wpdb->prepare('AND tm.term_id = %d', (int) $keyword);
                }
            }
            $sql .= "
                UNION 
                (
                    SELECT
                        tm.term_id AS post_id, 
                        att.guid AS url, 
                        null AS post_name, 
                        t.name AS post_title, 
                        null AS post_date, 
                        att.id AS thumbnail_id,
                        null AS gallery_ids,
                        true AS category
                    FROM {$this->termmeta} tm
                    INNER JOIN {$this->terms} t ON tm.term_id = t.term_id {$filter}
                    INNER JOIN {$this->posts} att ON (
                        tm.meta_key = 'thumbnail_id'
                        AND tm.meta_value = att.id
                        {$authorClause}
                    )
                    AND att.post_type = 'attachment'
                )
            ";
        }

        $sql .= "
            ORDER BY post_id DESC
            LIMIT {$start},1000
        ";

        $rows = $this->wpdb->get_results($sql);
        if (!$rows) {
            return [];
        }

        return $this->filter_out_managed_local_media($this->hydrate_internal_attachment_rows($rows));
    }

    private function get_posts_with_internal_featured_image_db2(int $page, string $type, ?string $keyword): ?array {
        if (!$this->has_speedup_db2_tables()) {
            return null;
        }

        $start = $page * 1000;

        $filterPosts = '';
        if ($keyword) {
            if ($type === 'title') {
                $like = '%' . $this->wpdb->esc_like($keyword) . '%';
                $filterPosts = $this->wpdb->prepare('AND p.post_title LIKE %s', $like);
            } elseif ($type === 'postid') {
                $filterPosts = $this->wpdb->prepare('AND pm.post_id = %d', (int) $keyword);
            }
        }

        $authorClausePosts = $this->wpdb->prepare('AND att.post_author <> %d', $this->get_author());
        $postmeta = $this->postmeta;
        $posts = $this->posts;
        $map = $this->fifu_map_table;
        $key = $this->fifu_key_table;
        $sql = "
            (
                SELECT 
                    pm.post_id, 
                    att.guid AS url, 
                    p.post_name, 
                    p.post_title, 
                    p.post_date, 
                    att.id AS thumbnail_id,
                    (SELECT meta_value FROM {$postmeta} pm2 WHERE pm2.post_id = pm.post_id AND pm2.meta_key = '_product_image_gallery') AS gallery_ids,
                    false AS category
                FROM {$this->postmeta} pm
                INNER JOIN {$posts} p ON pm.post_id = p.id {$filterPosts} AND p.post_title <> ''
                INNER JOIN {$posts} att ON (
                    pm.meta_key = '_thumbnail_id'
                    AND pm.meta_value = att.id
                    {$authorClausePosts}
                )
                AND p.post_type <> 'attachment'
                AND p.post_status <> 'trash'
            )
        ";

        if (class_exists('WooCommerce')) {
            if (!$this->has_term_speedup_db2_tables()) {
                return null;
            }

            $filterTerms = '';
            if ($keyword) {
                if ($type === 'title') {
                    $like = '%' . $this->wpdb->esc_like($keyword) . '%';
                    $filterTerms = $this->wpdb->prepare('AND t.name LIKE %s', $like);
                } elseif ($type === 'postid') {
                    $filterTerms = $this->wpdb->prepare('AND tm.term_id = %d', (int) $keyword);
                }
            }

            $authorClauseTerms = $authorClausePosts;
            $termmeta = $this->termmeta;
            $terms = $this->terms;
            $termMap = $this->fifu_term_map_table;
            $sql .= "
                UNION 
                (
                    SELECT
                        tm.term_id AS post_id, 
                        att.guid AS url, 
                        null AS post_name, 
                        t.name AS post_title, 
                        null AS post_date, 
                        att.id AS thumbnail_id,
                        null AS gallery_ids,
                        true AS category
                    FROM {$termmeta} tm
                    INNER JOIN {$terms} t ON tm.term_id = t.term_id {$filterTerms}
                    INNER JOIN {$this->posts} att ON (
                        tm.meta_key = 'thumbnail_id'
                        AND tm.meta_value = att.id
                        {$authorClauseTerms}
                    )
                    AND att.post_type = 'attachment'
                )
            ";
        }

        $sql .= $this->wpdb->prepare(
            "
            ORDER BY post_id DESC
            LIMIT %d,1000
            ",
            $start
        );

        $rows = $this->wpdb->get_results($sql);
        if ($rows === false || !$rows) {
            return null;
        }

        return $this->filter_out_managed_local_media($this->hydrate_internal_attachment_rows($rows));
    }

    /**
     * Retrieves posts that have external storage entries.
     *
     * @param array $storage_ids
     * @return array
     */
    public function get_posts_su(array $storage_ids): array {
        if (!function_exists('fifu_db2_mode')) {
            return $this->get_posts_su_legacy($storage_ids);
        }

        $mode = fifu_db2_mode();

        if ($mode === Fifu_Db2_Mode::MODE_DB2) {
            $db2Rows = $this->get_posts_su_db2($storage_ids);
            if ($db2Rows !== null) {
                return $db2Rows;
            }

            return $this->get_posts_su_legacy($storage_ids);
        }

        if ($mode === Fifu_Db2_Mode::MODE_LEGACY || $mode === Fifu_Db2_Mode::MODE_HYBRID) {
            return $this->get_posts_su_hybrid($storage_ids);
        }

        return $this->get_posts_su_legacy($storage_ids);
    }

    /**
     * Returns only post/product IDs that reference the provided Cloud storage IDs.
     *
     * This is intentionally post-only and must not inspect term/termmeta/term DB2
     * tables. It is used by Cloud preflight migration before delete, where category
     * behavior must remain untouched.
     *
     * @param array $storage_ids
     * @return int[]
     */
    public function get_post_ids_su_for_cloud_preflight(array $storage_ids): array {
        $ids = $this->sanitize_storage_ids($storage_ids);
        if ($ids === []) {
            return [];
        }

        $postIds = [];
        $placeholders = implode(',', array_fill(0, count($ids), '%s'));

        $filterPostImage = $this->wpdb->prepare(
            "AND SUBSTRING_INDEX(SUBSTRING_INDEX(pm.meta_value, '/', 5), '/', -1) IN ($placeholders)",
            $ids
        );

        $filterPostVideo = $this->wpdb->prepare(
            "AND SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.meta_value, 'fifu-thumb=', 5), 'fifu-thumb=', -1), '/', 5), '/', -1) IN ($placeholders)",
            $ids
        );

        $legacySql = "
            (
                SELECT DISTINCT pm.post_id
                FROM {$this->postmeta} pm
                INNER JOIN {$this->posts} p ON pm.post_id = p.ID
                WHERE pm.meta_key LIKE 'fifu_%image_url%'
                  AND pm.meta_value LIKE 'https://cdn.fifu.app/%'
                  {$filterPostImage}
            )
            UNION
            (
                SELECT DISTINCT pm.post_id
                FROM {$this->postmeta} pm
                INNER JOIN {$this->posts} p ON pm.post_id = p.ID
                WHERE pm.meta_key LIKE 'fifu_video_url%'
                  AND pm.meta_value LIKE '%https://cdn.fifu.app/%'
                  {$filterPostVideo}
            )
        ";

        $legacyPostIds = $this->wpdb->get_col($legacySql);
        if (is_array($legacyPostIds)) {
            foreach ($legacyPostIds as $postId) {
                $postId = (int) $postId;
                if ($postId > 0) {
                    $postIds[$postId] = true;
                }
            }
        }

        if ($this->has_speedup_db2_tables()) {
            $exprImg = "SUBSTRING_INDEX(SUBSTRING_INDEX(u.url, '/', 5), '/', -1)";
            $exprVid = "SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(u.url, 'fifu-thumb=', 5), 'fifu-thumb=', -1), '/', 5), '/', -1)";

            $filterDb2PostImage = $this->wpdb->prepare(
                "AND {$exprImg} IN ($placeholders)",
                $ids
            );

            $filterDb2PostVideo = $this->wpdb->prepare(
                "AND {$exprVid} IN ($placeholders)",
                $ids
            );

            $db2Sql = "
                (
                    SELECT DISTINCT m.post_id
                    FROM {$this->fifu_map_table} m
                    INNER JOIN {$this->fifu_key_table} k ON k.key_id = m.key_id
                    INNER JOIN {$this->fifu_url_table} u ON u.hash = m.hash
                    INNER JOIN {$this->posts} p ON p.ID = m.post_id
                    WHERE k.key_type IN ('image', 'slider')
                      AND u.url LIKE 'https://cdn.fifu.app/%'
                      {$filterDb2PostImage}
                )
                UNION
                (
                    SELECT DISTINCT m.post_id
                    FROM {$this->fifu_map_table} m
                    INNER JOIN {$this->fifu_key_table} k ON k.key_id = m.key_id
                    INNER JOIN {$this->fifu_url_table} u ON u.hash = m.hash
                    INNER JOIN {$this->posts} p ON p.ID = m.post_id
                    WHERE k.key_type = 'video'
                      AND u.url LIKE '%https://cdn.fifu.app/%'
                      {$filterDb2PostVideo}
                )
            ";

            $db2PostIds = $this->wpdb->get_col($db2Sql);
            if (is_array($db2PostIds)) {
                foreach ($db2PostIds as $postId) {
                    $postId = (int) $postId;
                    if ($postId > 0) {
                        $postIds[$postId] = true;
                    }
                }
            }
        }

        return array_keys($postIds);
    }

    private function get_posts_su_hybrid(array $storage_ids): array {
        $mergedMap = [];
        $db2Rows = $this->get_posts_su_db2($storage_ids);
        if ($db2Rows !== null) {
            $this->merge_posts_su_rows($mergedMap, $db2Rows, true);
        }

        $legacyRows = $this->get_posts_su_legacy($storage_ids);
        $this->merge_posts_su_rows($mergedMap, $legacyRows, false);

        $rows = array_values($mergedMap);
        usort($rows, static function ($left, $right): int {
            $postCompare = (int) ($right->post_id ?? 0) <=> (int) ($left->post_id ?? 0);
            if ($postCompare !== 0) {
                return $postCompare;
            }

            $categoryCompare = (int) ($left->category ?? 0) <=> (int) ($right->category ?? 0);
            if ($categoryCompare !== 0) {
                return $categoryCompare;
            }

            $metaKeyCompare = strcmp((string) ($left->meta_key ?? ''), (string) ($right->meta_key ?? ''));
            if ($metaKeyCompare !== 0) {
                return $metaKeyCompare;
            }

            return (int) ($right->meta_id ?? 0) <=> (int) ($left->meta_id ?? 0);
        });

        return $rows;
    }

    private function merge_posts_su_rows(array &$mergedMap, array $rows, bool $overwrite): void {
        foreach ($rows as $row) {
            $identityKey = $this->build_upload_row_identity_key($row);
            if ($identityKey === null) {
                continue;
            }

            if ($overwrite || !isset($mergedMap[$identityKey])) {
                $mergedMap[$identityKey] = $row;
            }
        }
    }

    private function get_posts_su_legacy(array $storage_ids): array {
        $filter_post_image = '';
        $filter_term_image = '';
        $filter_post_video = '';
        $filter_term_video = '';

        $ids = $this->sanitize_storage_ids($storage_ids);
        if ($ids) {
            $placeholders = implode(',', array_fill(0, count($ids), '%s'));
            $filter_post_image = $this->wpdb->prepare(
                "AND SUBSTRING_INDEX(SUBSTRING_INDEX(pm.meta_value, '/', 5), '/', -1) IN ($placeholders)",
                $ids
            );
            $filter_term_image = $this->wpdb->prepare(
                "AND SUBSTRING_INDEX(SUBSTRING_INDEX(tm.meta_value, '/', 5), '/', -1) IN ($placeholders)",
                $ids
            );
            $filter_post_video = $this->wpdb->prepare(
                "AND SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.meta_value, 'fifu-thumb=', 5), 'fifu-thumb=', -1), '/', 5), '/', -1) IN ($placeholders)",
                $ids
            );
            $filter_term_video = $this->wpdb->prepare(
                "AND SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(tm.meta_value, 'fifu-thumb=', 5), 'fifu-thumb=', -1), '/', 5), '/', -1) IN ($placeholders)",
                $ids
            );
        }

        $sql = "
            (
                SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(pm.meta_value, '/', 5), '/', -1) AS storage_id, 
                    p.post_title, 
                    p.post_date, 
                    pm.meta_id, 
                    pm.post_id, 
                    pm.meta_key, 
                    false AS category
                FROM {$this->postmeta} pm
                INNER JOIN {$this->posts} p ON pm.post_id = p.id
                WHERE pm.meta_key LIKE 'fifu_%image_url%'
                AND pm.meta_value LIKE 'https://cdn.fifu.app/%'
                {$filter_post_image}
            )
            UNION
            (
                SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(pm.meta_value, 'fifu-thumb=', 5), 'fifu-thumb=', -1), '/', 5), '/', -1) AS storage_id, 
                    p.post_title, 
                    p.post_date, 
                    pm.meta_id, 
                    pm.post_id, 
                    pm.meta_key, 
                    false AS category
                FROM {$this->postmeta} pm
                INNER JOIN {$this->posts} p ON pm.post_id = p.id
                WHERE pm.meta_key LIKE 'fifu_video_url%'
                AND pm.meta_value LIKE '%https://cdn.fifu.app/%'
                {$filter_post_video}
            )
        ";

        $sql .= "
            UNION
            (
                SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(tm.meta_value, '/', 5), '/', -1) AS storage_id, 
                    t.name AS post_title, 
                    NULL AS post_date, 
                    tm.meta_id, 
                    tm.term_id AS post_id, 
                    tm.meta_key, 
                    true AS category
                FROM {$this->termmeta} tm
                INNER JOIN {$this->terms} t ON tm.term_id = t.term_id
                WHERE tm.meta_key = 'fifu_image_url'
                AND tm.meta_value LIKE 'https://cdn.fifu.app/%'
                {$filter_term_image}
            )
            UNION
            (
                SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(tm.meta_value, 'fifu-thumb=', 5), 'fifu-thumb=', -1), '/', 5), '/', -1) AS storage_id,
                    t.name AS post_title, 
                    NULL AS post_date, 
                    tm.meta_id, 
                    tm.term_id AS post_id, 
                    tm.meta_key, 
                    true AS category
                FROM {$this->termmeta} tm
                INNER JOIN {$this->terms} t ON tm.term_id = t.term_id
                WHERE tm.meta_key = 'fifu_video_url'
                AND tm.meta_value LIKE '%https://cdn.fifu.app/%'
                {$filter_term_video}
            )
        ";

        $rows = $this->wpdb->get_results($sql);
        return $rows ?: [];
    }

    private function get_posts_su_db2(array $storage_ids): ?array {
        if (!$this->has_speedup_db2_tables()) {
            return null;
        }

        $includeTermRows = $this->has_term_speedup_db2_tables();

        $exprImg = "SUBSTRING_INDEX(SUBSTRING_INDEX(u.url, '/', 5), '/', -1)";
        $exprVid = "SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(u.url, 'fifu-thumb=', 5), 'fifu-thumb=', -1), '/', 5), '/', -1)";
        $filterPostImage = '';
        $filterTermImage = '';
        $filterPostVideo = '';
        $filterTermVideo = '';

        $ids = $this->sanitize_storage_ids($storage_ids);
        if ($ids) {
            $placeholders = implode(',', array_fill(0, count($ids), '%s'));
            $filterPostImage = $this->wpdb->prepare("AND {$exprImg} IN ($placeholders)", $ids);
            $filterTermImage = $this->wpdb->prepare("AND {$exprImg} IN ($placeholders)", $ids);
            $filterPostVideo = $this->wpdb->prepare("AND {$exprVid} IN ($placeholders)", $ids);
            $filterTermVideo = $this->wpdb->prepare("AND {$exprVid} IN ($placeholders)", $ids);
        }

        $sql = "
            (
                SELECT {$exprImg} AS storage_id,
                    p.post_title,
                    p.post_date,
                    m.id AS meta_id,
                    m.post_id,
                    CASE
                        WHEN k.key_type = 'image' AND m.key_index = 0 THEN 'fifu_image_url'
                        WHEN k.key_type = 'image' THEN CONCAT('fifu_image_url_', m.key_index - 1)
                        WHEN k.key_type = 'slider' THEN CONCAT('fifu_slider_image_url_', m.key_index)
                        WHEN k.key_type = 'video' AND m.key_index = 0 THEN 'fifu_video_url'
                        ELSE CONCAT('fifu_video_url_', m.key_index - 1)
                    END AS meta_key,
                    false AS category
                FROM {$this->fifu_map_table} m
                INNER JOIN {$this->fifu_key_table} k ON k.key_id = m.key_id
                INNER JOIN {$this->fifu_url_table} u ON u.hash = m.hash
                INNER JOIN {$this->posts} p ON p.ID = m.post_id
                WHERE k.key_type IN ('image','slider')
                  AND u.url LIKE 'https://cdn.fifu.app/%'
                  {$filterPostImage}
            )
            UNION
            (
                SELECT {$exprVid} AS storage_id,
                    p.post_title,
                    p.post_date,
                    m.id AS meta_id,
                    m.post_id,
                    CASE
                        WHEN k.key_type = 'video' AND m.key_index = 0 THEN 'fifu_video_url'
                        ELSE CONCAT('fifu_video_url_', m.key_index - 1)
                    END AS meta_key,
                    false AS category
                FROM {$this->fifu_map_table} m
                INNER JOIN {$this->fifu_key_table} k ON k.key_id = m.key_id
                INNER JOIN {$this->fifu_url_table} u ON u.hash = m.hash
                INNER JOIN {$this->posts} p ON p.ID = m.post_id
                WHERE k.key_type = 'video'
                  AND u.url LIKE '%https://cdn.fifu.app/%'
                  {$filterPostVideo}
            )
        ";

        if ($includeTermRows) {
            $sql .= "
                UNION
                (
                    SELECT {$exprImg} AS storage_id,
                        t.name AS post_title,
                        NULL AS post_date,
                        tm.id AS meta_id,
                        tm.term_id AS post_id,
                        'fifu_image_url' AS meta_key,
                        true AS category
                    FROM {$this->fifu_term_map_table} tm
                    INNER JOIN {$this->fifu_key_table} k ON k.key_id = tm.key_id
                    INNER JOIN {$this->fifu_url_table} u ON u.hash = tm.hash
                    INNER JOIN {$this->terms} t ON t.term_id = tm.term_id
                    WHERE k.key_type = 'image'
                      AND u.url LIKE 'https://cdn.fifu.app/%'
                      {$filterTermImage}
                )
                UNION
                (
                    SELECT {$exprVid} AS storage_id,
                        t.name AS post_title,
                        NULL AS post_date,
                        tm.id AS meta_id,
                        tm.term_id AS post_id,
                        'fifu_video_url' AS meta_key,
                        true AS category
                    FROM {$this->fifu_term_map_table} tm
                    INNER JOIN {$this->fifu_key_table} k ON k.key_id = tm.key_id
                    INNER JOIN {$this->fifu_url_table} u ON u.hash = tm.hash
                    INNER JOIN {$this->terms} t ON t.term_id = tm.term_id
                    WHERE k.key_type = 'video'
                      AND u.url LIKE '%https://cdn.fifu.app/%'
                      {$filterTermVideo}
                )
            ";
        }

        $results = $this->wpdb->get_results($sql);
        if ($results === false) {
            return null;
        }

        return $results;
    }

    private function sanitize_storage_ids(array $storage_ids): array {
        $ids = array_values(
            array_filter(
                array_map('strval', $storage_ids),
                static function ($value) {
                    return $value !== '';
                }
            )
        );
        return $ids;
    }

    /**
     * Applies custom field updates for the speed-up bucket view.
     *
     * @param string|int $bucket_id
     * @param array $thumbnails
     * @param bool $isCategory
     * @return int
     */
    public function speed_up_custom_fields(string|int $bucket_id, array $thumbnails, bool $isCategory): int {
        $table = $isCategory ? $this->termmeta : $this->postmeta;

        if (empty($thumbnails)) {
            return 0;
        }

        $legacyBridge = null;
        if (
            function_exists('fifu_db2_legacy_write_bridge')
            && class_exists('Fifu_Db2_Legacy_Write_Bridge')
        ) {
            $bridgeCandidate = fifu_db2_legacy_write_bridge();
            if ($bridgeCandidate instanceof Fifu_Db2_Legacy_Write_Bridge) {
                $legacyBridge = $bridgeCandidate;
            }
        }

        $metaIds = [];
        foreach ($thumbnails as $thumbnail) {
            $metaIds[] = (int) ($thumbnail->meta_id ?? 0);
        }
        $metaIds = array_values(array_unique($metaIds));

        $metaById = [];
        if (!empty($metaIds)) {
            $objectColumn = $isCategory ? 'term_id' : 'post_id';
            $placeholders = implode(',', array_fill(0, count($metaIds), '%d'));
            $sql = "
                SELECT meta_id, {$objectColumn} AS object_id, meta_key
                FROM {$table}
                WHERE meta_id IN ({$placeholders})
            ";
            $query = $this->wpdb->prepare($sql, ...$metaIds);
            $metaRows = $this->wpdb->get_results($query);
            if (is_array($metaRows)) {
                foreach ($metaRows as $row) {
                    $id = (int) ($row->meta_id ?? 0);
                    if ($id <= 0) {
                        continue;
                    }
                    $metaById[$id] = [
                        'object_id' => (int) ($row->object_id ?? 0),
                        'meta_key' => (string) ($row->meta_key ?? ''),
                    ];
                }
            }
        }

        $db2Rows = [];

        foreach ($thumbnails as $thumbnail) {
            $thumbUrl = $this->build_su_url($bucket_id, (string) $thumbnail->storage_id);
            $su_url = $thumbUrl;

            $videoUrl = trim((string) ($thumbnail->video_url ?? ''));
            if ($videoUrl !== '') {
                $su_url = $this->build_suvideo_transport_url($videoUrl, $thumbUrl);
            }

            $target = $this->resolve_speed_up_custom_field_target($thumbnail, $metaById, $isCategory);
            if ($target === null) {
                continue;
            }

            $metaId = (int) ($thumbnail->meta_id ?? 0);
            $metaKey = $target['meta_key'];
            $objectId = $target['object_id'];
            $isManagedKey = $this->is_db2_managed_fifu_key($metaKey);
            $isDb2Row = $isManagedKey && $objectId > 0 && $legacyBridge !== null;

            if ($isDb2Row) {
                $db2Rows[] = [
                    'meta_id' => $metaId,
                    'object_id' => $objectId,
                    'meta_key' => $metaKey,
                    'meta_value' => $su_url,
                ];
                continue;
            }

        }

        if (
            $legacyBridge
            && !empty($db2Rows)
        ) {
            foreach ($db2Rows as $row) {
                $metaKey = (string) ($row['meta_key'] ?? '');
                $metaValue = (string) ($row['meta_value'] ?? '');
                $objectId = (int) ($row['object_id'] ?? 0);

                if ($metaKey === '' || $metaValue === '') {
                    continue;
                }

                $ok = $isCategory
                    ? $legacyBridge->handle_term_meta_change($objectId, $metaKey, $metaValue)
                    : $legacyBridge->handle_post_meta_change($objectId, $metaKey, $metaValue);

                if ($ok !== true) {
                    continue;
                }

                if ($isCategory) {
                    $this->wpdb->delete(
                        $this->termmeta,
                        ['term_id' => $objectId, 'meta_key' => $metaKey],
                        ['%d', '%s']
                    );
                    clean_term_cache($objectId);
                    wp_cache_delete($objectId, 'term_meta');

                    $this->migrate_paired_legacy_term_image_alt_after_speed_up(
                        $legacyBridge,
                        $objectId,
                        $metaKey
                    );
                    continue;
                }

                $this->wpdb->delete(
                    $this->postmeta,
                    ['post_id' => $objectId, 'meta_key' => $metaKey],
                    ['%d', '%s']
                );
                clean_post_cache($objectId);
                wp_cache_delete($objectId, 'post_meta');

                $this->migrate_paired_legacy_post_image_alt_after_speed_up(
                    $legacyBridge,
                    $objectId,
                    $metaKey
                );
            }
        }

        return 0;
    }

    /**
     * Migrates the paired legacy post ALT row after a successful featured image URL write.
     */
    private function migrate_paired_legacy_post_image_alt_after_speed_up(
        object $legacyBridge,
        int $postId,
        string $imageMetaKey
    ): void {
        if ($postId <= 0 || $imageMetaKey !== 'fifu_image_url') {
            return;
        }

        if (!method_exists($legacyBridge, 'handle_post_meta_change')) {
            return;
        }

        $altMetaKey = 'fifu_image_alt';
        $legacyAlt = $this->get_legacy_post_meta_value_for_speed_up($postId, $altMetaKey);
        if ($legacyAlt === null) {
            return;
        }

        $ok = $legacyBridge->handle_post_meta_change($postId, $altMetaKey, $legacyAlt);
        if ($ok !== true) {
            return;
        }

        $this->wpdb->delete(
            $this->postmeta,
            ['post_id' => $postId, 'meta_key' => $altMetaKey],
            ['%d', '%s']
        );
        clean_post_cache($postId);
        wp_cache_delete($postId, 'post_meta');
    }

    /**
     * Migrates the paired legacy term ALT row after a successful category URL write.
     */
    private function migrate_paired_legacy_term_image_alt_after_speed_up(
        object $legacyBridge,
        int $termId,
        string $imageMetaKey
    ): void {
        if ($termId <= 0 || $imageMetaKey !== 'fifu_image_url') {
            return;
        }

        if (!method_exists($legacyBridge, 'handle_term_meta_change')) {
            return;
        }

        $altMetaKey = 'fifu_image_alt';
        $legacyAlt = $this->get_legacy_term_meta_value_for_speed_up($termId, $altMetaKey);
        if ($legacyAlt === null) {
            return;
        }

        $ok = $legacyBridge->handle_term_meta_change($termId, $altMetaKey, $legacyAlt);
        if ($ok !== true) {
            return;
        }

        $this->wpdb->delete(
            $this->termmeta,
            ['term_id' => $termId, 'meta_key' => $altMetaKey],
            ['%d', '%s']
        );
        clean_term_cache($termId);
        wp_cache_delete($termId, 'term_meta');
    }

    /**
     * Returns the legacy post meta value when the row exists, otherwise null.
     *
     * get_post_meta(..., true) cannot reliably distinguish a missing row from an
     * existing empty row, so use the postmeta table directly. Existing empty ALT
     * rows are still passed to the bridge so DB2 can confirm/delete the logical ALT
     * state before the legacy row is removed.
     */
    private function get_legacy_post_meta_value_for_speed_up(int $postId, string $metaKey): ?string
    {
        if ($postId <= 0 || $metaKey === '') {
            return null;
        }

        $value = $this->wpdb->get_var($this->wpdb->prepare(
            "SELECT meta_value FROM {$this->postmeta} WHERE post_id = %d AND meta_key = %s LIMIT 1",
            $postId,
            $metaKey
        ));

        return $value === null || $value === false ? null : (string) $value;
    }

    /**
     * Returns the legacy term meta value when the row exists, otherwise null.
     */
    private function get_legacy_term_meta_value_for_speed_up(int $termId, string $metaKey): ?string
    {
        if ($termId <= 0 || $metaKey === '') {
            return null;
        }

        $value = $this->wpdb->get_var($this->wpdb->prepare(
            "SELECT meta_value FROM {$this->termmeta} WHERE term_id = %d AND meta_key = %s LIMIT 1",
            $termId,
            $metaKey
        ));

        return $value === null || $value === false ? null : (string) $value;
    }

    /**
     * Resolves the target object/meta pair for a speed-up write-back row.
     *
     * @param object $thumbnail
     * @param array $metaById
     * @param bool $isCategory
     * @return array|null
     */
    private function resolve_speed_up_custom_field_target(object $thumbnail, array $metaById, bool $isCategory): ?array {
        $metaKey = trim((string) ($thumbnail->meta_key ?? ''));
        $objectId = $isCategory
            ? (int) ($thumbnail->term_id ?? 0)
            : (int) ($thumbnail->post_id ?? 0);

        if ($isCategory && $objectId <= 0) {
            $objectId = (int) ($thumbnail->post_id ?? 0);
        }

        /*
         * DB2 Cloud rows carry an opaque numeric meta_id whose namespace is not
         * wp_postmeta/termmeta. For DB2-managed FIFU keys, the explicit object
         * identity from the Cloud row is therefore authoritative.
         *
         * Looking up meta_id first can accidentally match an unrelated WordPress
         * metadata row and either skip the correct write or redirect it to another
         * object.
         */
        if (
            $metaKey !== ''
            && $objectId > 0
            && $this->is_db2_managed_fifu_key($metaKey)
        ) {
            return [
                'object_id' => $objectId,
                'meta_key' => $metaKey,
                'resolved_via_meta_table' => false,
            ];
        }

        $metaId = (int) ($thumbnail->meta_id ?? 0);

        if ($metaId > 0 && isset($metaById[$metaId])) {
            $metaInfo = $metaById[$metaId];
            $resolvedMetaKey = trim((string) ($metaInfo['meta_key'] ?? ''));
            $resolvedObjectId = (int) ($metaInfo['object_id'] ?? 0);

            if ($resolvedMetaKey === '' || $resolvedObjectId <= 0) {
                return null;
            }

            return [
                'object_id' => $resolvedObjectId,
                'meta_key' => $resolvedMetaKey,
                'resolved_via_meta_table' => true,
            ];
        }

        if ($metaKey === '' || $objectId <= 0) {
            return null;
        }

        return [
            'object_id' => $objectId,
            'meta_key' => $metaKey,
            'resolved_via_meta_table' => false,
        ];
    }

    /**
     * Applies custom field updates for list thumbnails.
     *
     * @param string|int $bucket_id
     * @param array $thumbnails
     * @param array $list_ids_map
     * @return void
     */
    public function speed_up_list_custom_fields(string|int $bucket_id, array $thumbnails, array $list_ids_map): void {
        $map1_image = $map2_image = [];
        $map1_slider = $map2_slider = [];
        $map1_video = $map2_video = [];

        $legacyBridge = null;
        if (
            function_exists('fifu_db2_legacy_write_bridge')
            && class_exists('Fifu_Db2_Legacy_Write_Bridge')
        ) {
            $bridgeCandidate = fifu_db2_legacy_write_bridge();
            if ($bridgeCandidate instanceof Fifu_Db2_Legacy_Write_Bridge) {
                $legacyBridge = $bridgeCandidate;
            }
        }

        foreach ($thumbnails as $thumbnail) {
            if (!isset($list_ids_map[$thumbnail->meta_id])) {
                continue;
            }

            $thumbUrl = $this->build_su_url($bucket_id, (string) $thumbnail->storage_id);
            $videoUrl = trim((string) ($thumbnail->video_url ?? ''));

            if ($videoUrl !== '') {
                $baseVideoUrl = $this->strip_suvideo_thumb_suffix($videoUrl);
                $suVideoUrl = $this->build_suvideo_transport_url($videoUrl, $thumbUrl);

                $postId = (int) $thumbnail->post_id;
                $listMetaValue = isset($map1_video[$postId])
                    ? $map1_video[$postId]
                    : (string) $list_ids_map[$thumbnail->meta_id][1];

                $map1_video[$postId] = $this->replace_suvideo_entry_in_pipe_list(
                    $listMetaValue,
                    $baseVideoUrl,
                    $suVideoUrl
                );
                $map2_video[$list_ids_map[$thumbnail->meta_id][0]] = $postId;
                continue;
            } else {
                $url = $thumbnail->meta_value;
                $isSlider = strpos((string) ($thumbnail->meta_key ?? ''), 'slider') !== false;
                $targetMap = $isSlider ? $map1_slider : $map1_image;
                $listMetaValue = isset($targetMap[$thumbnail->post_id]) ? $targetMap[$thumbnail->post_id] : $list_ids_map[$thumbnail->meta_id][1];
                $su_url = $thumbUrl;
                $updatedListMetaValue = str_replace(
                    $url,
                    $su_url,
                    $listMetaValue
                );
                if ($isSlider) {
                    $map1_slider[$thumbnail->post_id] = $updatedListMetaValue;
                    $map2_slider[$list_ids_map[$thumbnail->meta_id][0]] = $thumbnail->post_id;
                } else {
                    $map1_image[$thumbnail->post_id] = $updatedListMetaValue;
                    $map2_image[$list_ids_map[$thumbnail->meta_id][0]] = $thumbnail->post_id;
                }
            }
        }

        $syncedImagePostIds = $this->persist_speed_up_list_meta_updates($legacyBridge, $map1_image, $map2_image);
        $syncedSliderPostIds = $this->persist_speed_up_list_meta_updates($legacyBridge, $map1_slider, $map2_slider);
        $syncedVideoPostIds = $this->persist_speed_up_list_meta_updates($legacyBridge, $map1_video, $map2_video);

        $this->sync_post_list_meta_group(
            $legacyBridge,
            $map1_image,
            'fifu_list_url',
            'fifu_list_alt',
            ['fifu_image_url', 'fifu_image_alt'],
            ['fifu_image_url_', 'fifu_image_alt_'],
            [],
            $syncedImagePostIds
        );
        $this->sync_post_list_meta_group(
            $legacyBridge,
            $map1_slider,
            'fifu_slider_list_url',
            'fifu_slider_list_alt',
            [],
            ['fifu_slider_image_alt_'],
            ['fifu_list_alt'],
            $syncedSliderPostIds
        );

        foreach ($syncedVideoPostIds as $postId) {
            $postId = (int) $postId;
            if ($postId <= 0) {
                continue;
            }

            $this->wpdb->delete(
                $this->postmeta,
                ['post_id' => $postId, 'meta_key' => 'fifu_list_video_url'],
                ['%d', '%s']
            );

            $this->delete_post_meta_keys_by_patterns(
                $postId,
                ['fifu_video_url'],
                ['fifu_video_url_']
            );

            clean_post_cache($postId);
            wp_cache_delete($postId, 'post_meta');
        }
    }

    /**
     * Migrates complete legacy post media state to DB2 before Cloud uploads an individual URL.
     *
     * This preflight writes the original legacy URLs to DB2. The Cloud response path later
     * updates only the uploaded URL/index to the Cloud URL.
     *
     * @param int[] $postIds
     * @return void
     */
    public function migrate_posts_legacy_media_state_before_cloud_upload(array $postIds): void
    {
        $postIds = array_values(array_unique(array_filter(array_map('intval', $postIds), static function ($postId) {
            return $postId > 0;
        })));

        if ($postIds === []) {
            return;
        }

        $legacyBridge = null;
        if (
            function_exists('fifu_db2_legacy_write_bridge')
            && class_exists('Fifu_Db2_Legacy_Write_Bridge')
        ) {
            $bridgeCandidate = fifu_db2_legacy_write_bridge();
            if ($bridgeCandidate instanceof Fifu_Db2_Legacy_Write_Bridge) {
                $legacyBridge = $bridgeCandidate;
            }
        }

        if (!$legacyBridge) {
            return;
        }

        $rowsByPostId = $this->get_post_list_meta_rows($postIds, [
            'fifu_image_url',
            'fifu_image_alt',
            'fifu_list_url',
            'fifu_list_alt',
            'fifu_list_video_url',
            'fifu_slider_list_url',
            'fifu_slider_list_alt',
        ]);

        $imageListByPostId = [];
        $videoListByPostId = [];
        $sliderListByPostId = [];

        if ($rowsByPostId !== []) {
            foreach ($rowsByPostId as $postId => $rows) {
                $postId = (int) $postId;
                if ($postId <= 0) {
                    continue;
                }

                $imageUrlValue = trim((string) ($rows['fifu_image_url']['meta_value'] ?? ''));
                if ($imageUrlValue !== '') {
                    $this->sync_featured_image_meta_group_before_cloud_operation($legacyBridge, [$postId]);
                }

                $imageListValue = trim((string) ($rows['fifu_list_url']['meta_value'] ?? ''));
                if ($imageListValue !== '') {
                    $imageListByPostId[$postId] = $imageListValue;
                }

                $videoListValue = trim((string) ($rows['fifu_list_video_url']['meta_value'] ?? ''));
                if ($videoListValue !== '') {
                    $videoListByPostId[$postId] = $videoListValue;
                }

                $sliderListValue = trim((string) ($rows['fifu_slider_list_url']['meta_value'] ?? ''));
                if ($sliderListValue !== '') {
                    $sliderListByPostId[$postId] = $sliderListValue;
                }
            }
        }

        $indexedSliderLists = $this->get_indexed_slider_lists_for_cloud_preflight($postIds);
        $indexedSliderAltByPostId = [];

        foreach ($indexedSliderLists as $postId => $indexedSliderList) {
            $postId = (int) $postId;
            if ($postId <= 0) {
                continue;
            }

            if (!isset($sliderListByPostId[$postId]) || trim((string) $sliderListByPostId[$postId]) === '') {
                $sliderListByPostId[$postId] = (string) ($indexedSliderList['urls'] ?? '');
                $indexedSliderAltByPostId[$postId] = (string) ($indexedSliderList['alts'] ?? '');
            }
        }

        $this->sync_post_list_meta_group(
            $legacyBridge,
            $imageListByPostId,
            'fifu_list_url',
            'fifu_list_alt',
            ['fifu_image_url', 'fifu_image_alt'],
            ['fifu_image_url_', 'fifu_image_alt_'],
            []
        );

        $this->sync_post_list_meta_group(
            $legacyBridge,
            $videoListByPostId,
            'fifu_list_video_url',
            null,
            ['fifu_video_url'],
            ['fifu_video_url_'],
            []
        );

        $this->sync_post_list_meta_group(
            $legacyBridge,
            $sliderListByPostId,
            'fifu_slider_list_url',
            'fifu_slider_list_alt',
            [],
            ['fifu_slider_image_url_', 'fifu_slider_image_alt_'],
            ['fifu_list_alt'],
            [],
            $indexedSliderAltByPostId
        );

        $postsWithoutImageList = array_values(array_filter(
            array_map('intval', $postIds),
            function (int $postId) use ($imageListByPostId): bool {
                return $postId > 0
                    && (!isset($imageListByPostId[$postId]) || trim((string) $imageListByPostId[$postId]) === '');
            }
        ));

        $this->sync_indexed_image_gallery_meta_group_before_cloud_operation($legacyBridge, $postsWithoutImageList);
    }

    /**
     * Migrates simple featured image legacy state before Cloud operations.
     *
     * This covers posts that only have fifu_image_url + fifu_image_alt and no
     * fifu_list_url. It writes both through the DB2 legacy bridge and deletes
     * legacy postmeta only after successful DB2 writes.
     *
     * @param object $legacyBridge
     * @param int[]  $postIds
     * @return void
     */
    private function sync_featured_image_meta_group_before_cloud_operation(object $legacyBridge, array $postIds): void
    {
        if (!method_exists($legacyBridge, 'handle_post_meta_change')) {
            return;
        }

        $rowsByPostId = $this->get_post_list_meta_rows($postIds, [
            'fifu_image_url',
            'fifu_image_alt',
        ]);

        if ($rowsByPostId === []) {
            return;
        }

        foreach ($rowsByPostId as $postId => $rows) {
            $postId = (int) $postId;
            if ($postId <= 0) {
                continue;
            }

            $imageUrl = trim((string) ($rows['fifu_image_url']['meta_value'] ?? ''));
            if ($imageUrl === '') {
                continue;
            }

            $urlOk = $legacyBridge->handle_post_meta_change($postId, 'fifu_image_url', $imageUrl);
            if ($urlOk !== true) {
                continue;
            }

            $this->wpdb->delete(
                $this->postmeta,
                ['post_id' => $postId, 'meta_key' => 'fifu_image_url'],
                ['%d', '%s']
            );

            if (array_key_exists('fifu_image_alt', $rows)) {
                $imageAlt = (string) ($rows['fifu_image_alt']['meta_value'] ?? '');
                $altOk = $legacyBridge->handle_post_meta_change($postId, 'fifu_image_alt', $imageAlt);

                if ($altOk === true) {
                    $this->wpdb->delete(
                        $this->postmeta,
                        ['post_id' => $postId, 'meta_key' => 'fifu_image_alt'],
                        ['%d', '%s']
                    );
                }
            }

            clean_post_cache($postId);
            wp_cache_delete($postId, 'post_meta');
        }
    }

    /**
     * Reconstructs slider URL/ALT lists from indexed legacy fields.
     *
     * Used when old legacy slider state exists only as:
     * fifu_slider_image_url_0, fifu_slider_image_url_1...
     * fifu_slider_image_alt_0, fifu_slider_image_alt_1...
     *
     * @param int[] $postIds
     * @return array<int,array{urls:string,alts:string}>
     */
    private function get_indexed_slider_lists_for_cloud_preflight(array $postIds): array
    {
        $postIds = array_values(array_unique(array_filter(array_map('intval', $postIds), static function ($postId) {
            return $postId > 0;
        })));

        if ($postIds === []) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($postIds), '%d'));

        $sql = $this->wpdb->prepare(
            "
        SELECT post_id, meta_key, meta_value
        FROM {$this->postmeta}
        WHERE post_id IN ($placeholders)
          AND (
              meta_key LIKE 'fifu_slider_image_url_%'
              OR meta_key LIKE 'fifu_slider_image_alt_%'
          )
        ORDER BY post_id ASC, meta_key ASC
        ",
            $postIds
        );

        $rows = $this->wpdb->get_results($sql);
        if (!is_array($rows) || $rows === []) {
            return [];
        }

        $byPost = [];

        foreach ($rows as $row) {
            $postId = (int) ($row->post_id ?? 0);
            $metaKey = (string) ($row->meta_key ?? '');
            $metaValue = (string) ($row->meta_value ?? '');

            if ($postId <= 0 || $metaKey === '') {
                continue;
            }

            if (preg_match('/^fifu_slider_image_url_(\d+)$/', $metaKey, $matches)) {
                $index = (int) $matches[1];
                $value = trim($metaValue);
                if ($value !== '') {
                    $byPost[$postId]['urls'][$index] = $value;
                }
                continue;
            }

            if (preg_match('/^fifu_slider_image_alt_(\d+)$/', $metaKey, $matches)) {
                $index = (int) $matches[1];
                $byPost[$postId]['alts'][$index] = $metaValue;
                continue;
            }
        }

        $lists = [];

        foreach ($byPost as $postId => $parts) {
            $urlsByIndex = $parts['urls'] ?? [];
            if ($urlsByIndex === []) {
                continue;
            }

            ksort($urlsByIndex, SORT_NUMERIC);

            $urls = [];
            $alts = [];
            $altsByIndex = $parts['alts'] ?? [];

            foreach ($urlsByIndex as $index => $url) {
                $url = trim((string) $url);
                if ($url === '') {
                    continue;
                }

                $urls[] = $url;
                $alts[] = (string) ($altsByIndex[$index] ?? '');
            }

            if ($urls === []) {
                continue;
            }

            $lists[(int) $postId] = [
                'urls' => implode('|', $urls),
                'alts' => implode('|', $alts),
            ];
        }

        return $lists;
    }

    /**
     * Migrates indexed legacy image gallery fields before Cloud operations.
     *
     * This preserves legacy gallery semantics:
     * fifu_image_url_0 => DB2 image index 1
     * fifu_image_url_1 => DB2 image index 2
     *
     * Do not rewrite these fields through fifu_list_url because fifu_list_url
     * position 0 is treated as the featured image / DB2 image index 0.
     *
     * @param Fifu_Db2_Legacy_Write_Bridge|null $legacyBridge
     * @param int[]                             $postIds
     * @return void
     */
    private function sync_indexed_image_gallery_meta_group_before_cloud_operation(
        ?Fifu_Db2_Legacy_Write_Bridge $legacyBridge,
        array $postIds
    ): void {
        if ($legacyBridge === null || !method_exists($legacyBridge, 'handle_post_meta_change')) {
            return;
        }

        $postIds = array_values(array_unique(array_filter(array_map('intval', $postIds), static function ($postId) {
            return $postId > 0;
        })));

        if ($postIds === []) {
            return;
        }

        $placeholders = implode(',', array_fill(0, count($postIds), '%d'));

        $sql = $this->wpdb->prepare(
            "
            SELECT post_id, meta_key, meta_value
            FROM {$this->postmeta}
            WHERE post_id IN ($placeholders)
              AND (
                  meta_key LIKE 'fifu_image_url_%'
                  OR meta_key LIKE 'fifu_image_alt_%'
              )
            ORDER BY post_id ASC, meta_key ASC
            ",
            $postIds
        );

        $rows = $this->wpdb->get_results($sql);
        if (!is_array($rows) || $rows === []) {
            return;
        }

        $byPost = [];

        foreach ($rows as $row) {
            $postId = (int) ($row->post_id ?? 0);
            $metaKey = (string) ($row->meta_key ?? '');
            $metaValue = (string) ($row->meta_value ?? '');

            if ($postId <= 0 || $metaKey === '') {
                continue;
            }

            if (preg_match('/^fifu_image_url_(\d+)$/', $metaKey, $matches)) {
                $index = (int) $matches[1];
                $value = trim($metaValue);
                if ($value !== '') {
                    $byPost[$postId][$index]['url_key'] = $metaKey;
                    $byPost[$postId][$index]['url'] = $value;
                }
                continue;
            }

            if (preg_match('/^fifu_image_alt_(\d+)$/', $metaKey, $matches)) {
                $index = (int) $matches[1];
                $byPost[$postId][$index]['alt_key'] = $metaKey;
                $byPost[$postId][$index]['alt'] = $metaValue;
            }
        }

        foreach ($byPost as $postId => $itemsByIndex) {
            $postId = (int) $postId;
            if ($postId <= 0 || !is_array($itemsByIndex) || $itemsByIndex === []) {
                continue;
            }

            ksort($itemsByIndex, SORT_NUMERIC);
            $postChanged = false;

            foreach ($itemsByIndex as $index => $item) {
                $index = (int) $index;
                $urlKey = (string) ($item['url_key'] ?? ('fifu_image_url_' . $index));
                $url = trim((string) ($item['url'] ?? ''));

                if ($url === '') {
                    continue;
                }

                $urlOk = $legacyBridge->handle_post_meta_change($postId, $urlKey, $url);
                if ($urlOk !== true) {
                    continue;
                }

                $this->wpdb->delete(
                    $this->postmeta,
                    ['post_id' => $postId, 'meta_key' => $urlKey],
                    ['%d', '%s']
                );
                $postChanged = true;

                if (array_key_exists('alt', $item)) {
                    $altKey = (string) ($item['alt_key'] ?? ('fifu_image_alt_' . $index));
                    $alt = (string) ($item['alt'] ?? '');

                    $altOk = $legacyBridge->handle_post_meta_change($postId, $altKey, $alt);
                    if ($altOk === true) {
                        $this->wpdb->delete(
                            $this->postmeta,
                            ['post_id' => $postId, 'meta_key' => $altKey],
                            ['%d', '%s']
                        );
                        $postChanged = true;
                    }
                }
            }

            if ($postChanged) {
                clean_post_cache($postId);
                wp_cache_delete($postId, 'post_meta');
            }
        }
    }

    /**
     * Persist list meta URL updates through the DB2 bridge using the resolved list meta rows.
     *
     * @param Fifu_Db2_Legacy_Write_Bridge|null $legacyBridge
     * @param array                             $metaValueByPostId
     * @param array                             $metaIdToPostIdMap
     * @return int[]
     */
    private function persist_speed_up_list_meta_updates(
        ?Fifu_Db2_Legacy_Write_Bridge $legacyBridge,
        array $metaValueByPostId,
        array $metaIdToPostIdMap
    ): array {
        if ($legacyBridge === null || empty($metaValueByPostId) || empty($metaIdToPostIdMap)) {
            return [];
        }

        $metaRowsById = $this->get_postmeta_rows_by_meta_ids(array_keys($metaIdToPostIdMap));
        if (empty($metaRowsById)) {
            return [];
        }

        $syncedPostIds = [];
        foreach ($metaIdToPostIdMap as $metaId => $postId) {
            $metaId = (int) $metaId;
            $postId = (int) $postId;
            $metaValue = (string) ($metaValueByPostId[$postId] ?? '');
            if ($metaId <= 0 || $postId <= 0 || $metaValue === '') {
                continue;
            }

            $metaRow = $metaRowsById[$metaId] ?? null;
            $metaKey = (string) ($metaRow['meta_key'] ?? '');
            $resolvedPostId = (int) ($metaRow['post_id'] ?? $postId);
            if ($metaKey === '' || $resolvedPostId <= 0 || !$this->is_db2_managed_fifu_key($metaKey)) {
                continue;
            }

            $ok = $legacyBridge->handle_post_meta_change($resolvedPostId, $metaKey, $metaValue);
            if ($ok !== true) {
                continue;
            }

            if ($metaKey === 'fifu_list_url' && !$this->db2_image_list_matches($resolvedPostId, $metaValue)) {
                continue;
            }

            $this->wpdb->delete(
                $this->postmeta,
                ['post_id' => $resolvedPostId, 'meta_key' => $metaKey],
                ['%d', '%s']
            );
            clean_post_cache($resolvedPostId);
            wp_cache_delete($resolvedPostId, 'post_meta');
            $syncedPostIds[] = $resolvedPostId;
        }

        return array_values(array_unique($syncedPostIds));
    }

    /**
     * Load postmeta rows keyed by meta_id.
     *
     * @param array $metaIds
     * @return array
     */
    private function get_postmeta_rows_by_meta_ids(array $metaIds): array {
        $metaIds = array_values(array_unique(array_filter(array_map('intval', $metaIds), static function ($id) {
            return $id > 0;
        })));
        if (empty($metaIds)) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($metaIds), '%d'));
        $sql = "
            SELECT meta_id, post_id, meta_key
            FROM {$this->postmeta}
            WHERE meta_id IN ({$placeholders})
        ";
        $rows = $this->wpdb->get_results($this->wpdb->prepare($sql, ...$metaIds));
        if (!is_array($rows)) {
            return [];
        }

        $rowsById = [];
        foreach ($rows as $row) {
            $metaId = (int) ($row->meta_id ?? 0);
            if ($metaId <= 0) {
                continue;
            }

            $rowsById[$metaId] = [
                'post_id' => (int) ($row->post_id ?? 0),
                'meta_key' => (string) ($row->meta_key ?? ''),
            ];
        }

        return $rowsById;
    }

    /**
     * Persist DB2-managed list meta through the legacy bridge and remove the redundant wp_postmeta
     * only after the grouped write has succeeded.
     *
     * @param Fifu_Db2_Legacy_Write_Bridge|null $legacyBridge
     * @param array                             $urlValuesByPostId
     * @param string                            $urlMetaKey
     * @param string|null                       $altMetaKey
     * @param array                             $extraExactMetaKeys
     * @param array                             $extraMetaPrefixes
     * @return void
     */
    private function sync_post_list_meta_group(
        ?Fifu_Db2_Legacy_Write_Bridge $legacyBridge,
        array $urlValuesByPostId,
        string $urlMetaKey,
        ?string $altMetaKey = null,
        array $extraExactMetaKeys = [],
        array $extraMetaPrefixes = [],
        array $fallbackAltMetaKeys = [],
        array $alreadySyncedUrlPostIds = [],
        array $altListOverrideByPostId = []
    ): void {
        if ($legacyBridge === null || empty($urlValuesByPostId)) {
            return;
        }

        $postIds = array_values(array_unique(array_filter(array_map('intval', array_keys($urlValuesByPostId)))));
        if (empty($postIds)) {
            return;
        }

        $metaKeys = [$urlMetaKey];
        if ($altMetaKey !== null && $altMetaKey !== '') {
            $metaKeys[] = $altMetaKey;
        }
        foreach ($fallbackAltMetaKeys as $fallbackAltMetaKey) {
            if ($fallbackAltMetaKey !== null && $fallbackAltMetaKey !== '') {
                $metaKeys[] = $fallbackAltMetaKey;
            }
        }

        $rowsByPostId = $this->get_post_list_meta_rows($postIds, $metaKeys);

        foreach ($postIds as $postId) {
            $urlMetaValue = (string) ($urlValuesByPostId[$postId] ?? '');
            if ($urlMetaValue === '') {
                continue;
            }

            $postRows = $rowsByPostId[$postId] ?? [];
            $urlMetaAlreadySynced = in_array($postId, $alreadySyncedUrlPostIds, true);

            $writes = [];
            if (!$urlMetaAlreadySynced) {
                $writes[] = [$urlMetaKey, $urlMetaValue];
            }

            if ($altMetaKey !== null) {
                if (isset($altListOverrideByPostId[$postId])) {
                    $writes[] = [$altMetaKey, (string) $altListOverrideByPostId[$postId]];
                } else {
                    $altSourceMetaKey = $this->resolve_alt_source_meta_key(
                        $postRows,
                        $urlMetaKey,
                        $altMetaKey,
                        $fallbackAltMetaKeys
                    );
                    if ($altSourceMetaKey !== null) {
                        $writes[] = [$altMetaKey, (string) ($postRows[$altSourceMetaKey]['meta_value'] ?? ''), $altSourceMetaKey];
                    }
                }
            }

            if (empty($writes) && !$urlMetaAlreadySynced) {
                continue;
            }

            $allOk = true;
            foreach ($writes as $write) {
                [$metaKey, $metaValue] = $write;
                $ok = $legacyBridge->handle_post_meta_change($postId, $metaKey, $metaValue);
                if ($ok !== true) {
                    $allOk = false;
                    break;
                }
            }

            if (!$allOk) {
                continue;
            }

            if ($urlMetaKey === 'fifu_list_url' && !$this->db2_image_list_matches($postId, $urlMetaValue)) {
                continue;
            }

            foreach ($writes as $write) {
                $metaKeyToDelete = isset($write[2]) ? (string) $write[2] : (string) $write[0];
                $this->wpdb->delete(
                    $this->postmeta,
                    ['post_id' => $postId, 'meta_key' => $metaKeyToDelete],
                    ['%d', '%s']
                );
            }

            $this->delete_post_meta_keys_by_patterns($postId, $extraExactMetaKeys, $extraMetaPrefixes);

            clean_post_cache($postId);
            wp_cache_delete($postId, 'post_meta');
        }
    }

    /**
     * Load the legacy list meta rows used by speed-up list persistence.
     *
     * @param array $postIds
     * @param array $metaKeys
     * @return array
     */
    private function get_post_list_meta_rows(array $postIds, array $metaKeys): array {
        if (empty($postIds) || empty($metaKeys)) {
            return [];
        }

        $postPlaceholders = implode(',', array_fill(0, count($postIds), '%d'));
        $keyPlaceholders = implode(',', array_fill(0, count($metaKeys), '%s'));
        $query = $this->wpdb->prepare(
            "
                SELECT post_id, meta_key, meta_value
                FROM {$this->postmeta}
                WHERE post_id IN ({$postPlaceholders})
                AND meta_key IN ({$keyPlaceholders})
            ",
            ...array_merge($postIds, $metaKeys)
        );

        $rows = $this->wpdb->get_results($query);
        if (!is_array($rows)) {
            return [];
        }

        $rowsByPostId = [];
        foreach ($rows as $row) {
            $postId = (int) ($row->post_id ?? 0);
            $metaKey = (string) ($row->meta_key ?? '');
            if ($postId <= 0 || $metaKey === '') {
                continue;
            }

            if (!isset($rowsByPostId[$postId])) {
                $rowsByPostId[$postId] = [];
            }

            $rowsByPostId[$postId][$metaKey] = [
                'meta_value' => (string) ($row->meta_value ?? ''),
            ];
        }

        return $rowsByPostId;
    }

    /**
     * Resolve which legacy ALT field should be used as the source for a DB2 list-alt write.
     *
     * @param array       $postRows
     * @param string      $urlMetaKey
     * @param string      $altMetaKey
     * @param array       $fallbackAltMetaKeys
     * @return string|null
     */
    private function resolve_alt_source_meta_key(array $postRows, string $urlMetaKey, string $altMetaKey, array $fallbackAltMetaKeys): ?string {
        if (
            $urlMetaKey === 'fifu_slider_list_url'
            && isset($postRows['fifu_list_alt'])
            && !isset($postRows['fifu_list_url'])
        ) {
            $sliderListValue = (string) ($postRows[$urlMetaKey]['meta_value'] ?? '');
            if ($sliderListValue === '' || strpos($sliderListValue, 'https://cdn.fifu.app/') !== false) {
                return 'fifu_list_alt';
            }
        }

        if (isset($postRows[$altMetaKey])) {
            return $altMetaKey;
        }

        foreach ($fallbackAltMetaKeys as $fallbackAltMetaKey) {
            if (!isset($postRows[$fallbackAltMetaKey])) {
                continue;
            }

            // Preserve the REST/import rule: only promote fifu_list_alt to the slider channel
            // when there is no image-gallery list competing for that same legacy field.
            if (
                $urlMetaKey === 'fifu_slider_list_url'
                && $fallbackAltMetaKey === 'fifu_list_alt'
                && isset($postRows['fifu_list_url'])
            ) {
                continue;
            }

            return $fallbackAltMetaKey;
        }

        return null;
    }

    /**
     * Delete redundant legacy postmeta keys that have already been persisted to DB2.
     *
     * @param int   $postId
     * @param array $exactMetaKeys
     * @param array $metaPrefixes
     * @return void
     */
    private function delete_post_meta_keys_by_patterns(int $postId, array $exactMetaKeys, array $metaPrefixes): void {
        if ($postId <= 0 || (empty($exactMetaKeys) && empty($metaPrefixes))) {
            return;
        }

        $meta = get_post_meta($postId);
        if (!is_array($meta)) {
            return;
        }

        foreach (array_keys($meta) as $metaKey) {
            if (in_array($metaKey, $exactMetaKeys, true)) {
                delete_post_meta($postId, $metaKey);
                continue;
            }

            foreach ($metaPrefixes as $prefix) {
                if (strpos($metaKey, $prefix) === 0) {
                    delete_post_meta($postId, $metaKey);
                    break;
                }
            }
        }
    }

    /**
     * Persist reverted image-gallery list metadata through DB2 and remove the legacy postmeta
     * only after the grouped write has succeeded.
     *
     * @param Fifu_Db2_Legacy_Write_Bridge|null $legacyBridge
     * @param array                             $urlValuesByPostId
     * @return void
     */
    private function sync_reverted_image_list_meta_group(
        ?Fifu_Db2_Legacy_Write_Bridge $legacyBridge,
        array $urlValuesByPostId
    ): void {
        if ($legacyBridge === null || empty($urlValuesByPostId)) {
            return;
        }

        $postIds = array_values(array_unique(array_filter(array_map('intval', array_keys($urlValuesByPostId)))));
        if (empty($postIds)) {
            return;
        }

        foreach ($postIds as $postId) {
            $urlMetaValue = (string) ($urlValuesByPostId[$postId] ?? '');
            if ($postId <= 0 || $urlMetaValue === '') {
                continue;
            }

            $writes = [
                ['fifu_list_url', $urlMetaValue],
            ];

            $altMetaValue = $this->resolve_reverted_image_list_alt_value($postId);
            if ($altMetaValue !== null) {
                $writes[] = ['fifu_list_alt', $altMetaValue];
            }

            $allOk = true;
            foreach ($writes as $write) {
                [$metaKey, $metaValue] = $write;
                $ok = $legacyBridge->handle_post_meta_change($postId, $metaKey, $metaValue);
                if ($ok !== true) {
                    $allOk = false;
                    break;
                }
            }

            if (!$allOk) {
                continue;
            }

            if (!$this->db2_image_list_matches($postId, $urlMetaValue)) {
                continue;
            }

            $this->delete_post_meta_keys_by_patterns(
                $postId,
                ['fifu_list_url', 'fifu_list_alt', 'fifu_image_alt'],
                ['fifu_image_alt_']
            );

            clean_post_cache($postId);
            wp_cache_delete($postId, 'post_meta');
        }
    }

    /**
     * Persist reverted video-gallery list metadata through DB2 and remove the legacy postmeta
     * only after the write has succeeded.
     *
     * @param Fifu_Db2_Legacy_Write_Bridge|null $legacyBridge
     * @param array                             $urlValuesByPostId
     * @param array                             $metaKeysByPostId
     * @return void
     */
    private function sync_reverted_video_list_meta_group(
        ?Fifu_Db2_Legacy_Write_Bridge $legacyBridge,
        array $urlValuesByPostId,
        array $metaKeysByPostId
    ): void {
        if ($legacyBridge === null || empty($urlValuesByPostId) || empty($metaKeysByPostId)) {
            return;
        }

        $postIds = array_values(array_unique(array_filter(array_map('intval', array_keys($urlValuesByPostId)))));
        if (empty($postIds)) {
            return;
        }

        foreach ($postIds as $postId) {
            $urlMetaValue = (string) ($urlValuesByPostId[$postId] ?? '');
            $metaKey = (string) ($metaKeysByPostId[$postId] ?? '');
            if ($postId <= 0 || $urlMetaValue === '' || $metaKey === '' || !$this->is_db2_managed_fifu_key($metaKey)) {
                continue;
            }

            $ok = $legacyBridge->handle_post_meta_change($postId, $metaKey, $urlMetaValue);
            if ($ok !== true) {
                continue;
            }

            $this->wpdb->delete(
                $this->postmeta,
                ['post_id' => $postId, 'meta_key' => $metaKey],
                ['%d', '%s']
            );
            clean_post_cache($postId);
            wp_cache_delete($postId, 'post_meta');
        }
    }

    /**
     * Resolve the legacy image ALT list that should be preserved in DB2 during image-gallery rollback.
     *
     * Preference order:
     * 1. fifu_list_alt
     * 2. fifu_image_alt
     * 3. fifu_image_alt_*
     *
     * @param int $postId
     * @return string|null
     */
    private function resolve_reverted_image_list_alt_value(int $postId): ?string {
        if ($postId <= 0) {
            return null;
        }

        $meta = get_post_meta($postId);
        if (!is_array($meta)) {
            return null;
        }

        $legacyListAlt = trim((string) ($meta['fifu_list_alt'][0] ?? ''));
        $legacyListAlt = rtrim($legacyListAlt, '|');
        if ($legacyListAlt !== '') {
            return $legacyListAlt;
        }

        $alts = [];

        $featuredAlt = trim((string) ($meta['fifu_image_alt'][0] ?? ''));
        if ($featuredAlt !== '') {
            $alts[] = $featuredAlt;
        }

        $indexedAlts = [];
        foreach ($meta as $metaKey => $values) {
            if (strpos((string) $metaKey, 'fifu_image_alt_') !== 0) {
                continue;
            }

            $suffix = substr((string) $metaKey, strlen('fifu_image_alt_'));
            if ($suffix === '' || !ctype_digit($suffix)) {
                continue;
            }

            $altValue = trim((string) ($values[0] ?? ''));
            if ($altValue === '') {
                continue;
            }

            $indexedAlts[(int) $suffix] = $altValue;
        }

        if (!empty($indexedAlts)) {
            ksort($indexedAlts);
            foreach ($indexedAlts as $altValue) {
                $alts[] = $altValue;
            }
        }

        if (empty($alts)) {
            return null;
        }

        return implode('|', $alts);
    }

    /**
     * Reverts custom field URLs back to their original sources after speed up operations.
     *
     * @param array $thumbnails
     * @param array $urls
     * @param array $videoUrls
     * @param bool $isCategory
     * @return int|null
     */
    public function revert_custom_fields(
        array $thumbnails,
        array $urls,
        array $videoUrls,
        bool $isCategory
    ): ?int {
        $table = $isCategory ? $this->termmeta : $this->postmeta;

        $legacyBridge = null;
        if (
            function_exists('fifu_db2_legacy_write_bridge')
            && class_exists('Fifu_Db2_Legacy_Write_Bridge')
        ) {
            $bridgeCandidate = fifu_db2_legacy_write_bridge();
            if ($bridgeCandidate instanceof Fifu_Db2_Legacy_Write_Bridge) {
                $legacyBridge = $bridgeCandidate;
            }
        }

        if (empty($thumbnails)) {
            return null;
        }

        $result = 0;
        // Avoid unsafe legacy updates by meta_id; meta_id is not scoped to FIFU keys.
        foreach ($thumbnails as $thumbnail) {
            $video_url = isset($videoUrls[$thumbnail->storage_id]) ? $videoUrls[$thumbnail->storage_id] : null;
            $meta_value = $video_url ? $video_url : (isset($urls[$thumbnail->storage_id]) ? $urls[$thumbnail->storage_id] : '');
            $meta_key = (string) ($thumbnail->meta_key ?? '');

            if ($meta_key === '') {
                continue;
            }

            if (!$this->is_db2_managed_fifu_key($meta_key)) {
                continue;
            }

            $objectId = $isCategory ? (int) ($thumbnail->term_id ?? 0) : (int) ($thumbnail->post_id ?? 0);
            if ($isCategory && $objectId <= 0) {
                $objectId = (int) ($thumbnail->post_id ?? 0);
            }

            if ($objectId <= 0) {
                continue;
            }

            if ($legacyBridge) {
                $ok = $isCategory
                    ? $legacyBridge->handle_term_meta_change($objectId, $meta_key, $meta_value)
                    : $legacyBridge->handle_post_meta_change($objectId, $meta_key, $meta_value);

                if ($ok === true) {
                    if ($isCategory) {
                        $this->wpdb->delete(
                            $this->termmeta,
                            ['term_id' => $objectId, 'meta_key' => $meta_key],
                            ['%d', '%s']
                        );
                        clean_term_cache($objectId);
                        wp_cache_delete($objectId, 'term_meta');
                    } else {
                        $this->wpdb->delete(
                            $this->postmeta,
                            ['post_id' => $objectId, 'meta_key' => $meta_key],
                            ['%d', '%s']
                        );
                        clean_post_cache($objectId);
                        wp_cache_delete($objectId, 'post_meta');
                    }

                    $result++;
                    continue;
                }
            }

            if ($isCategory) {
                update_term_meta($objectId, $meta_key, $meta_value);
            } else {
                update_post_meta($objectId, $meta_key, $meta_value);
            }

            $result++;
        }

        return $result;
    }

    /**
     * Restores attachment post content filtered values after a speed up rollback.
     *
     * @param array $urls
     * @param array $thumbnails
     * @param array $attachmentIdsMap
     * @return array
     */
    public function revert_attachments(
        array $urls,
        array $videoUrls,
        array $thumbnails,
        array $attachmentIdsMap
    ): array {
        if ($urls === null || !is_array($urls)) {
            $urls = [];
        }
        if ($videoUrls === null || !is_array($videoUrls)) {
            $videoUrls = [];
        }
        if ($thumbnails === null || !is_array($thumbnails)) {
            $thumbnails = [];
        }
        if ($attachmentIdsMap === null || !is_array($attachmentIdsMap)) {
            $attachmentIdsMap = [];
        }

        $count = 0;
        $query = "
            INSERT INTO {$this->posts} (id, post_content_filtered) VALUES ";

        foreach ($thumbnails as $thumbnail) {
            if (!isset($attachmentIdsMap[$thumbnail->meta_id])) {
                continue;
            }

            if ($count++ !== 0) {
                $query .= ", ";
            }

            $url = $this->resolve_original_attachment_url_for_thumbnail($thumbnail, $urls);
            $query .= $this->wpdb->prepare("(%d, %s)", (int) $attachmentIdsMap[$thumbnail->meta_id], $url);
        }

        if ($count === 0) {
            return [];
        }

        $query .= "ON DUPLICATE KEY UPDATE post_content_filtered=VALUES(post_content_filtered)";
        $results = $this->wpdb->get_results($query);
        return $results ?: [];
    }

    /**
     * Restores attachment metadata values after a speed up rollback.
     *
     * @param array $urls
     * @param array $thumbnails
     * @param array $metaIdsMap
     * @return array
     */
    public function revert_attachments_meta(
        array $urls,
        array $videoUrls,
        array $thumbnails,
        array $metaIdsMap
    ): array {
        $attachmentMetaIds = [];
        $metaValueById = [];
        foreach ($thumbnails as $thumbnail) {
            if (!isset($metaIdsMap[$thumbnail->meta_id])) {
                continue;
            }

            $metaId = (int) $metaIdsMap[$thumbnail->meta_id];
            if ($metaId <= 0) {
                continue;
            }

            $url = $this->resolve_original_attachment_url_for_thumbnail($thumbnail, $urls);
            $attachmentMetaIds[] = $metaId;
            $metaValueById[$metaId] = $url;
        }

        if (empty($attachmentMetaIds)) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($attachmentMetaIds), '%d'));
        $sql = "
            SELECT meta_id, post_id, meta_key
            FROM {$this->postmeta}
            WHERE meta_id IN ({$placeholders})
            AND meta_key = %s
        ";
        $params = array_merge($attachmentMetaIds, ['_wp_attached_file']);
        $rows = $this->wpdb->get_results($this->wpdb->prepare($sql, $params));

        if ($rows === null) {
            return [];
        }

        $updated = [];
        foreach ($rows as $row) {
            $metaId = (int) ($row->meta_id ?? 0);
            $postId = (int) ($row->post_id ?? 0);
            $metaValue = $metaValueById[$metaId] ?? null;
            $metaKey = (string) ($row->meta_key ?? '');

            if ($metaId <= 0 || $postId <= 0 || $metaValue === null || $metaKey === '') {
                continue;
            }

            if (strpos($metaKey, 'fifu_') === 0) {
                continue;
            }

            // Avoid unsafe legacy updates by meta_id; use (post_id, meta_key) scoping.
            update_post_meta($postId, $metaKey, $metaValue);
            $updated[] = $postId;
        }

        return $updated;
    }

    /**
     * Reverts list custom fields for posts and terms after rolling back speed up changes.
     *
     * @param string|int $bucketId
     * @param array $urls
     * @param array $videoUrls
     * @param array $thumbnails
     * @param array $listIdsMap
     * @return void
     */
    public function revert_list_custom_fields(
        string|int $bucketId,
        array $urls,
        array $videoUrls,
        array $thumbnails,
        array $listIdsMap
    ): void {
        $map1_image = [];
        $map1_slider = [];
        $map1_video = [];
        $videoListMetaKeysByPostId = [];

        $legacyBridge = null;
        if (
            function_exists('fifu_db2_legacy_write_bridge')
            && class_exists('Fifu_Db2_Legacy_Write_Bridge')
        ) {
            $bridgeCandidate = fifu_db2_legacy_write_bridge();
            if ($bridgeCandidate instanceof Fifu_Db2_Legacy_Write_Bridge) {
                $legacyBridge = $bridgeCandidate;
            }
        }

        foreach ($thumbnails as $thumbnail) {
            if (!isset($listIdsMap[$thumbnail->meta_id])) {
                continue;
            }

            $video_url = isset($videoUrls[$thumbnail->storage_id]) ? $videoUrls[$thumbnail->storage_id] : null;
            $originalUrl = $this->resolve_original_url_for_thumbnail($thumbnail, $urls, $videoUrls);
            $listMetaKey = (string) ($listIdsMap[$thumbnail->meta_id][2] ?? '');

            if ($listMetaKey === 'fifu_list_video_url' || ($listMetaKey === '' && $video_url)) {
                $postId = (int) $thumbnail->post_id;
                $str_list = isset($map1_video[$postId])
                    ? $map1_video[$postId]
                    : (string) $listIdsMap[$thumbnail->meta_id][1];

                $baseVideoUrl = $video_url
                    ? $this->strip_suvideo_thumb_suffix((string) $video_url)
                    : $this->strip_suvideo_thumb_suffix((string) ($thumbnail->video_url ?? ''));

                if ($baseVideoUrl === '') {
                    $baseVideoUrl = $this->strip_suvideo_thumb_suffix($originalUrl);
                }

                $thumbUrl = $this->build_su_url($bucketId, (string) $thumbnail->storage_id);
                $replacement = $this->build_suvideo_transport_url($baseVideoUrl, $thumbUrl);

                $map1_video[$postId] = $this->replace_suvideo_entry_in_pipe_list(
                    $str_list,
                    $baseVideoUrl,
                    $replacement
                );
                if ($listMetaKey !== '') {
                    $videoListMetaKeysByPostId[$postId] = $listMetaKey;
                }
            } else {
                $isSlider = $listMetaKey === 'fifu_slider_list_url'
                    || ($listMetaKey === '' && strpos((string) ($thumbnail->meta_key ?? ''), 'slider') !== false);
                $targetMap = $isSlider ? $map1_slider : $map1_image;
                $str_list = isset($targetMap[$thumbnail->post_id])
                    ? $targetMap[$thumbnail->post_id]
                    : $listIdsMap[$thumbnail->meta_id][1];
                $updatedListValue = str_replace(
                    'https://cdn.fifu.app/' . $bucketId . '/' . $thumbnail->storage_id,
                    $originalUrl,
                    $str_list
                );

                if ($isSlider) {
                    $map1_slider[$thumbnail->post_id] = $updatedListValue;
                } else {
                    $map1_image[$thumbnail->post_id] = $updatedListValue;
                }
            }
        }

        $this->sync_reverted_image_list_meta_group($legacyBridge, $map1_image);
        $this->sync_reverted_video_list_meta_group($legacyBridge, $map1_video, $videoListMetaKeysByPostId);
        $this->sync_post_list_meta_group(
            $legacyBridge,
            $map1_slider,
            'fifu_slider_list_url',
            'fifu_slider_list_alt',
            ['fifu_slider_list_url', 'fifu_list_alt', 'fifu_slider_list_alt'],
            ['fifu_slider_image_url_', 'fifu_slider_image_alt_'],
            ['fifu_list_alt']
        );
    }

    /**
     * Resolve the original source URL for a thumbnail using video URLs first, then image URLs.
     *
     * @param object $thumbnail
     * @param array $urls
     * @param array $videoUrls
     * @return string
     */
    private function resolve_original_url_for_thumbnail(object $thumbnail, array $urls, array $videoUrls): string
    {
        $storageId = (string) ($thumbnail->storage_id ?? '');
        if ($storageId === '') {
            return '';
        }

        $videoUrl = $videoUrls[$storageId] ?? '';
        if ($videoUrl !== '') {
            return (string) $videoUrl;
        }

        return (string) ($urls[$storageId] ?? '');
    }

    /**
     * Resolve the original thumbnail URL for attachment-backed records.
     *
     * Attachments store the rendered thumbnail source, not the raw video URL.
     *
     * @param object $thumbnail
     * @param array $urls
     * @return string
     */
    private function resolve_original_attachment_url_for_thumbnail(object $thumbnail, array $urls): string
    {
        $storageId = (string) ($thumbnail->storage_id ?? '');
        if ($storageId === '') {
            return '';
        }

        return (string) ($urls[$storageId] ?? '');
    }

    /**
     * Collects attachment IDs for the provided thumbnail mappings.
     *
     * @param array $thumbnails
     * @param bool $isCategory
     * @return array
     */
    public function get_thumbnail_ids(array $thumbnails, bool $isCategory): array {
        $ids_list = [];
        foreach ($thumbnails as $thumbnail) {
            $ids_list[] = (int) $thumbnail->post_id;
        }

        $ids = Fifu_Db2_Sql_Helper::sanitize_ids_csv($ids_list);

        if ($isCategory) {
            $result = $this->wpdb->get_results("
                SELECT term_id AS post_id, meta_value AS att_id
                FROM {$this->termmeta} 
                WHERE term_id IN ({$ids}) 
                AND meta_key = 'thumbnail_id'
            ");
        } else {
            $result = $this->wpdb->get_results("
                SELECT post_id, meta_value AS att_id
                FROM {$this->postmeta} 
                WHERE post_id IN ({$ids}) 
                AND meta_key = '_thumbnail_id'
            ");
        }

        $featured_map = [];
        if (is_array($result)) {
            foreach ($result as $res) {
                $featured_map[$res->post_id] = $res->att_id;
            }
        }

        $map = [];
        foreach ($thumbnails as $thumbnail) {
            if (isset($featured_map[$thumbnail->post_id])) {
                $map[$thumbnail->meta_id] = $featured_map[$thumbnail->post_id];
            }
        }

        return $map;
    }

    /**
     * Collects gallery attachment IDs for thumbnail deletions.
     *
     * @param array $thumbnails
     * @param bool $is_delete
     * @return array
     */
    public function get_thumbnail_ids_gallery(array $thumbnails, bool $is_delete): array {
        $ids_list = [];
        foreach ($thumbnails as $thumbnail) {
            $ids_list[] = (int) $thumbnail->post_id;
        }
        $ids = Fifu_Db2_Sql_Helper::sanitize_ids_csv($ids_list);

        $result = $this->wpdb->get_results("
            SELECT post_id, meta_key, meta_value AS att_ids
            FROM {$this->postmeta} 
            WHERE post_id IN ({$ids}) 
            AND meta_key IN ('_product_image_gallery', '_wc_additional_variation_images')
        ");

        $gallery_map = [];
        if (is_array($result)) {
            foreach ($result as $res) {
                $gallery_map[$res->post_id] = $res->att_ids;
            }
        }

        $map = [];
        $done = [];
        foreach ($thumbnails as $thumbnail) {
            if (!isset($gallery_map[$thumbnail->post_id])) {
                continue;
            }
            $att_ids = $gallery_map[$thumbnail->post_id];

            if ($is_delete) {
                $att_ids_csv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($att_ids);
                $result = $this->wpdb->get_results("
                    SELECT post_id, SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(meta_value, '/', 5), '/', -1), '?', 1) AS storage_id
                    FROM {$this->postmeta} 
                    WHERE meta_key = '_wp_attached_file'
                    AND post_id IN ({$att_ids_csv})
                ");
                $storage_ids = [];
                if (is_array($result)) {
                    foreach ($result as $res) {
                        $storage_ids[$res->storage_id] = $res->post_id;
                    }
                }
                $att_id = isset($storage_ids[$thumbnail->storage_id]) ? $storage_ids[$thumbnail->storage_id] : null;
            } else {
                $att_ids_csv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($att_ids);
                $result = $this->wpdb->get_results("
                    SELECT post_id, meta_value
                    FROM {$this->postmeta} 
                    WHERE meta_key = '_wp_attached_file'
                    AND post_id IN ({$att_ids_csv})
                ");
                $values = [];
                if (is_array($result)) {
                    foreach ($result as $res) {
                        if (!isset($done[$res->post_id])) {
                            $values[$res->meta_value] = $res->post_id;
                        }
                    }
                }
                $att_id = isset($values[$thumbnail->meta_value]) ? $values[$thumbnail->meta_value] : null;
                if ($att_id !== null) {
                    $done[$att_id] = true;
                }
            }

            if ($att_id !== null) {
                $map[$thumbnail->meta_id] = $att_id;
            }
        }

        return $map;
    }

    /**
     * Updates attachments for a storage bucket.
     *
     * @param string|int $bucket_id
     * @param array $thumbnails
     * @param array $att_ids_map
     * @return array
     */
    public function speed_up_attachments(string|int $bucket_id, array $thumbnails, array $att_ids_map): array {
        $count = 0;
        $query = "
        INSERT INTO {$this->posts} (id, post_content_filtered) VALUES ";

        foreach ($thumbnails as $thumbnail) {
            if (!isset($att_ids_map[$thumbnail->meta_id])) {
                continue;
            }

            $su_url = $this->build_su_url($bucket_id, $thumbnail->storage_id);

            if ($thumbnail->video_url && strpos($thumbnail->video_url, 'video-thumb=') === false) {
                $su_url .= '?video-thumb=' . Fifu_Video_Helper::get_thumbnail_small($thumbnail->video_url);
            }

            if ($count++ !== 0) {
                $query .= ", ";
            }

            $query .= $this->wpdb->prepare("(%d, %s)", $att_ids_map[$thumbnail->meta_id], $su_url) . " ";
        }

        $query .= "ON DUPLICATE KEY UPDATE post_content_filtered=VALUES(post_content_filtered)";
        $result = $this->wpdb->get_results($query);
        return $result ?: [];
    }

    /**
     * Collects metadata IDs for the provided attachments.
     *
     * @param array $thumbnails
     * @param array $att_ids_map
     * @return array
     */
    public function get_thumbnail_meta_ids(array $thumbnails, array $att_ids_map): array {
        $ids_arr = [];
        foreach ($thumbnails as $thumbnail) {
            if (!isset($att_ids_map[$thumbnail->meta_id])) {
                continue;
            }
            $ids_arr[] = (int) $att_ids_map[$thumbnail->meta_id];
        }

        $ids_arr = array_values(array_unique(array_filter($ids_arr, static function ($value) {
            return $value > 0;
        })));

        if (empty($ids_arr)) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($ids_arr), '%d'));
        $sql = "
            SELECT meta_id, post_id
            FROM {$this->postmeta}
            WHERE post_id IN ({$placeholders})
            AND meta_key = %s
        ";
        $params = array_merge($ids_arr, ['_wp_attached_file']);
        $result = $this->wpdb->get_results($this->wpdb->prepare($sql, $params));

        $attid_metaid_map = [];
        if (is_array($result)) {
            foreach ($result as $res) {
                $attid_metaid_map[$res->post_id] = $res->meta_id;
            }
        }

        $map = [];
        foreach ($thumbnails as $thumbnail) {
            if (!isset($att_ids_map[$thumbnail->meta_id])) {
                continue;
            }
            $att_id = (int) $att_ids_map[$thumbnail->meta_id];
            if (!isset($attid_metaid_map[$att_id])) {
                continue;
            }
            $map[$thumbnail->meta_id] = $attid_metaid_map[$att_id];
        }

        return $map;
    }

    /**
     * Updates attachment metadata for a storage bucket.
     *
     * @param string|int $bucket_id
     * @param array $thumbnails
     * @param array $meta_ids_map
     * @return array
     */
    public function speed_up_attachments_meta(string|int $bucket_id, array $thumbnails, array $meta_ids_map): array {
        $metaValues = [];
        foreach ($thumbnails as $thumbnail) {
            if (!isset($meta_ids_map[$thumbnail->meta_id])) {
                continue;
            }

            $su_url = $this->build_su_url($bucket_id, $thumbnail->storage_id);
            if ($thumbnail->video_url && strpos($thumbnail->video_url, 'video-thumb=') === false) {
                $su_url .= '?video-thumb=' . Fifu_Video_Helper::get_thumbnail_small($thumbnail->video_url);
            }

            $metaValues[(int) $meta_ids_map[$thumbnail->meta_id]] = $su_url;
        }

        if (empty($metaValues)) {
            return [];
        }

        $metaIds = array_keys($metaValues);
        $placeholders = implode(',', array_fill(0, count($metaIds), '%d'));
        $sql = "
            SELECT meta_id, post_id, meta_key
            FROM {$this->postmeta}
            WHERE meta_id IN ({$placeholders})
        ";
        $query = $this->wpdb->prepare($sql, ...$metaIds);
        $rows = $this->wpdb->get_results($query);

        if (!is_array($rows)) {
            return [];
        }

        $allowedKeys = [
            '_wp_attached_file',
            '_wp_attachment_metadata',
        ];

        $updated = [];
        foreach ($rows as $row) {
            $metaId = (int) ($row->meta_id ?? 0);
            $postId = (int) ($row->post_id ?? 0);
            $metaKey = (string) ($row->meta_key ?? '');
            $metaValue = $metaValues[$metaId] ?? '';

            if ($metaId <= 0 || $postId <= 0 || $metaValue === '') {
                continue;
            }

            if (strpos($metaKey, 'fifu_') === 0) {
                continue;
            }

            if (!in_array($metaKey, $allowedKeys, true)) {
                continue;
            }

            // Avoid unsafe legacy updates by meta_id; attachment meta updates are scoped by (post_id, meta_key) and allowlisted.
            update_post_meta($postId, $metaKey, $metaValue);
            $updated[] = [
                'post_id' => $postId,
                'meta_key' => $metaKey,
                'meta_value' => $metaValue,
            ];
        }

        return $updated;
    }

    /**
     * Returns list IDs related to the thumbnails being processed.
     *
     * @param array $thumbnails
     * @param string|int $bucket_id
     * @param bool $is_delete
     * @param array|null $video_urls
     * @return array
     */
    public function get_list_ids(array $thumbnails, string|int $bucket_id, bool $is_delete, ?array $video_urls = null): array {
        $post_ids_normal_arr = [];
        $post_ids_slider_arr = [];
        foreach ($thumbnails as $thumbnail) {
            $is_slider = strpos($thumbnail->meta_key, 'slider') !== false;
            if ($is_slider) {
                $post_ids_slider_arr[] = (int) $thumbnail->post_id;
            } else {
                $post_ids_normal_arr[] = (int) $thumbnail->post_id;
            }
        }

        $post_ids_slider = $post_ids_slider_arr ? Fifu_Db2_Sql_Helper::sanitize_ids_csv($post_ids_slider_arr) : '';
        $post_ids_normal = $post_ids_normal_arr ? Fifu_Db2_Sql_Helper::sanitize_ids_csv($post_ids_normal_arr) : '';

        if ($post_ids_slider) {
            $result_slider = $this->wpdb->get_results("
                SELECT meta_id, post_id, meta_key, meta_value
                FROM {$this->postmeta} 
                WHERE post_id IN ({$post_ids_slider}) 
                AND meta_key = 'fifu_slider_list_url'
            ");
        } else {
            $result_slider = [];
        }

        if ($post_ids_normal) {
            $result_normal = $this->wpdb->get_results("
                SELECT meta_id, post_id, meta_key, meta_value
                FROM {$this->postmeta} 
                WHERE post_id IN ({$post_ids_normal}) 
                AND meta_key IN ('fifu_list_url', 'fifu_list_video_url')
            ");
        } else {
            $result_normal = [];
        }

        $slider_map = [];
        if (is_array($result_slider)) {
            foreach ($result_slider as $res) {
                $slider_map[$res->post_id] = [$res->meta_id, $res->meta_value, $res->meta_key];
            }
        }

        $normal_map = [];
        if (is_array($result_normal)) {
            foreach ($result_normal as $res) {
                if (!isset($normal_map[$res->post_id])) {
                    $normal_map[$res->post_id] = [];
                }
                $normal_map[$res->post_id][] = [$res->meta_id, $res->meta_value, $res->meta_key];
            }
        }

        $map = [];
        foreach ($thumbnails as $thumbnail) {
            $arr = null;
            $is_slider = strpos($thumbnail->meta_key, 'slider') !== false;
            if ($is_slider) {
                if (isset($slider_map[$thumbnail->post_id])) {
                    $arr = $slider_map[$thumbnail->post_id];
                }
            } else {
                if (isset($normal_map[$thumbnail->post_id])) {
                    foreach ($normal_map[$thumbnail->post_id] as $list) {
                        if ($is_delete) {
                            $image_url = $this->build_su_url($bucket_id, $thumbnail->storage_id);
                            $video_url = $video_urls && isset($video_urls[$thumbnail->storage_id]) ? $video_urls[$thumbnail->storage_id] : null;
                        } else {
                            $image_url = $thumbnail->meta_value;
                            $video_url = $thumbnail->video_url;
                        }
                        $url = $video_url ? $video_url : $image_url;
                        if (strpos($list[1], $url) !== false) {
                            $arr = $list;
                            break;
                        }
                    }
                }
            }
            if ($arr) {
                $map[$thumbnail->meta_id] = $arr;
            }
        }

        return $map;
    }

    /**
     * Insert missing category images automatically using a unique seed.
     *
     * Branches based on the active DB2 mode, falling back to legacy metadata for missing tables or errors.
     *
     * @param string $seed
     * @return void
     */
    public function insert_category_images_auto(string $seed): void {
        $modeLegacy = 'legacy';
        $modeDb2 = 'db2';
        $modeHybrid = 'hybrid';

        if (class_exists('Fifu_Db2_Mode')) {
            $modeLegacy = Fifu_Db2_Mode::MODE_LEGACY;
            $modeDb2 = Fifu_Db2_Mode::MODE_DB2;
            $modeHybrid = Fifu_Db2_Mode::MODE_HYBRID;
        }

        $mode = $modeLegacy;
        if (function_exists('fifu_db2_mode')) {
            $mode = fifu_db2_mode();
        }

        $this->debug_auto_category('insert_entry', [
            'seed' => $seed,
            'mode' => $mode,
            'mode_db2' => $modeDb2,
            'mode_hybrid' => $modeHybrid,
            'mode_legacy' => $modeLegacy,
        ]);

        if ($mode === $modeDb2) {
            $this->debug_auto_category('insert_branch_db2');
            if ($this->insert_category_images_auto_db2($seed) === null) {
                $this->debug_auto_category('insert_db2_returned_null_falling_back_legacy');
                $this->insert_category_images_auto_legacy($seed);
            }
            return;
        }

        if ($mode === $modeHybrid) {
            $this->debug_auto_category('insert_branch_hybrid');
            $this->insert_category_images_auto_db2($seed);
            $this->insert_category_images_auto_legacy($seed);
            return;
        }

        $this->debug_auto_category('insert_branch_legacy_db2_first');
        $this->insert_category_images_auto_db2($seed);

        $this->debug_auto_category('insert_branch_legacy');
        $this->insert_category_images_auto_legacy($seed);
    }

    /**
     * Performs the legacy termmeta insert with the deterministic seed.
     *
     * @param string $seed
     * @return void
     */
    private function insert_category_images_auto_legacy(string $seed): void {
        $result = $this->wpdb->get_results(
            $this->wpdb->prepare("
            SELECT tt.term_id, c.meta_value
            FROM {$this->termTaxonomy} tt
            INNER JOIN (
                SELECT ranked.term_taxonomy_id, ranked.object_id, ranked.meta_value
                FROM (
                    SELECT
                        cand.term_taxonomy_id,
                        cand.object_id,
                        cand.meta_value,
                        CONV(SUBSTRING(MD5(CONCAT(cand.term_taxonomy_id, ':', cand.object_id, ':', %s)), 1, 16), 16, 10) AS rnd
                    FROM (
                        SELECT
                            tr.term_taxonomy_id,
                            tr.object_id,
                            pm.meta_value
                        FROM {$this->termRelationships} tr
                        INNER JOIN {$this->termTaxonomy} tt2
                            ON tt2.term_taxonomy_id = tr.term_taxonomy_id
                           AND tt2.taxonomy = 'product_cat'
                           AND tt2.count > 0
                        INNER JOIN {$this->posts} p
                            ON p.id = tr.object_id
                           AND p.post_status <> 'trash'
                        INNER JOIN {$this->postmeta} pm
                            ON pm.post_id = tr.object_id
                           AND pm.meta_key = 'fifu_image_url'
                           AND pm.meta_value IS NOT NULL
                           AND pm.meta_value <> ''
                        WHERE NOT EXISTS (
                            SELECT 1
                            FROM {$this->termmeta} tm2
                            WHERE tm2.term_id = tt2.term_id
                              AND tm2.meta_key = 'fifu_image_url'
                        )
                        AND NOT EXISTS (
                            SELECT 1
                            FROM {$this->fifu_term_map_table} tm_db2
                            INNER JOIN {$this->fifu_key_table} k_db2
                                ON k_db2.key_id = tm_db2.key_id
                               AND k_db2.key_type = 'image'
                            WHERE tm_db2.term_id = tt2.term_id
                        )
                    ) cand
                ) ranked
                INNER JOIN (
                    SELECT term_taxonomy_id, MIN(rnd) AS min_rnd
                    FROM (
                        SELECT
                            cand.term_taxonomy_id,
                            CONV(SUBSTRING(MD5(CONCAT(cand.term_taxonomy_id, ':', cand.object_id, ':', %s)), 1, 16), 16, 10) AS rnd
                        FROM (
                            SELECT
                                tr.term_taxonomy_id,
                                tr.object_id,
                                pm.meta_value
                            FROM {$this->termRelationships} tr
                            INNER JOIN {$this->termTaxonomy} tt2
                                ON tt2.term_taxonomy_id = tr.term_taxonomy_id
                               AND tt2.taxonomy = 'product_cat'
                               AND tt2.count > 0
                            INNER JOIN {$this->posts} p
                                ON p.id = tr.object_id
                               AND p.post_status <> 'trash'
                            INNER JOIN {$this->postmeta} pm
                                ON pm.post_id = tr.object_id
                               AND pm.meta_key = 'fifu_image_url'
                               AND pm.meta_value IS NOT NULL
                               AND pm.meta_value <> ''
                            WHERE NOT EXISTS (
                                SELECT 1
                                FROM {$this->termmeta} tm2
                                WHERE tm2.term_id = tt2.term_id
                                  AND tm2.meta_key = 'fifu_image_url'
                            )
                            AND NOT EXISTS (
                                SELECT 1
                                FROM {$this->fifu_term_map_table} tm_db2
                                INNER JOIN {$this->fifu_key_table} k_db2
                                    ON k_db2.key_id = tm_db2.key_id
                                   AND k_db2.key_type = 'image'
                                WHERE tm_db2.term_id = tt2.term_id
                            )
                        ) cand
                    ) ranked_min
                    GROUP BY term_taxonomy_id
                ) tr_min
                    ON ranked.term_taxonomy_id = tr_min.term_taxonomy_id
                   AND ranked.rnd = tr_min.min_rnd
            ) c ON tt.term_taxonomy_id = c.term_taxonomy_id
        ", $seed, $seed)
        ) ?: [];

        foreach ($result as $res) {
            $term_id = isset($res->term_id) ? (int) $res->term_id : 0;
            $meta_value = isset($res->meta_value) ? (string) $res->meta_value : '';

            if ($term_id <= 0 || $meta_value === '') {
                continue;
            }

            if (!$this->persist_auto_category_image_url($term_id, $meta_value)) {
                update_term_meta($term_id, 'fifu_image_url', $meta_value);
                $this->ctgr_update_fake_attach_id($term_id);
            }
        }
    }

    /**
     * Inserts seeds into the DB2 term map when possible.
     *
     * @param string $seed
     * @return void|null
     */
    private function insert_category_images_auto_db2(string $seed) {
        $hasRequiredTables = $this->has_required_db2_tables();
        $this->debug_auto_category('db2_insert_start', [
            'seed' => $seed,
            'has_required_tables' => $hasRequiredTables,
            'term_map_table' => $this->fifu_term_map_table,
            'map_table' => $this->fifu_map_table,
            'key_table' => $this->fifu_key_table,
            'url_table' => $this->fifu_url_table,
        ]);

        if (!$hasRequiredTables) {
            $this->debug_auto_category('db2_insert_abort_missing_required_tables');
            return null;
        }

        $db2Sql = "
            SELECT
                tt.term_id,
                rs.key_id,
                rs.hash
            FROM {$this->termTaxonomy} tt
            INNER JOIN (
                SELECT ranked.term_taxonomy_id, ranked.key_id, ranked.hash
                FROM (
                    SELECT
                        candidates.term_taxonomy_id,
                        candidates.key_id,
                        candidates.hash,
                        candidates.rnd
                    FROM (
                        SELECT
                            tr.term_taxonomy_id,
                            tr.object_id,
                            k.key_id,
                            m.hash,
                            SUBSTRING(MD5(CONCAT(tr.term_taxonomy_id, ':', tr.object_id, ':', %s)), 1, 16) AS rnd
                        FROM {$this->termRelationships} tr
                        INNER JOIN {$this->termTaxonomy} tt2
                            ON tt2.term_taxonomy_id = tr.term_taxonomy_id
                           AND tt2.taxonomy = 'product_cat'
                           AND tt2.count > 0
                        INNER JOIN {$this->posts} p
                            ON p.ID = tr.object_id
                           AND p.post_status <> 'trash'
                        INNER JOIN {$this->fifu_map_table} m
                            ON m.post_id = tr.object_id
                           AND m.key_index = 0
                        INNER JOIN {$this->fifu_key_table} k
                            ON k.key_id = m.key_id
                           AND k.key_type = 'image'
                        INNER JOIN {$this->fifu_url_table} u
                            ON u.hash = m.hash
                           AND u.url IS NOT NULL
                           AND u.url <> ''
                        WHERE NOT EXISTS (
                            SELECT 1
                            FROM {$this->fifu_term_map_table} tm
                            WHERE tm.term_id = tt2.term_id
                              AND tm.key_id = k.key_id
                        )
                    ) candidates
                ) ranked
                INNER JOIN (
                    SELECT term_taxonomy_id, MIN(rnd) AS min_rnd
                    FROM (
                        SELECT
                            tr.term_taxonomy_id,
                            tr.object_id,
                            SUBSTRING(MD5(CONCAT(tr.term_taxonomy_id, ':', tr.object_id, ':', %s)), 1, 16) AS rnd
                        FROM {$this->termRelationships} tr
                        INNER JOIN {$this->termTaxonomy} tt2
                            ON tt2.term_taxonomy_id = tr.term_taxonomy_id
                           AND tt2.taxonomy = 'product_cat'
                           AND tt2.count > 0
                        INNER JOIN {$this->posts} p
                            ON p.ID = tr.object_id
                           AND p.post_status <> 'trash'
                        INNER JOIN {$this->fifu_map_table} m
                            ON m.post_id = tr.object_id
                           AND m.key_index = 0
                        INNER JOIN {$this->fifu_key_table} k
                            ON k.key_id = m.key_id
                           AND k.key_type = 'image'
                        INNER JOIN {$this->fifu_url_table} u
                            ON u.hash = m.hash
                           AND u.url IS NOT NULL
                           AND u.url <> ''
                        WHERE NOT EXISTS (
                            SELECT 1
                            FROM {$this->fifu_term_map_table} tm
                            WHERE tm.term_id = tt2.term_id
                              AND tm.key_id = k.key_id
                        )
                    ) ranked_min
                    GROUP BY term_taxonomy_id
                ) tr_min
                    ON tr_min.term_taxonomy_id = ranked.term_taxonomy_id
                   AND tr_min.min_rnd = ranked.rnd
            ) rs
                ON tt.term_taxonomy_id = rs.term_taxonomy_id
            WHERE tt.taxonomy = 'product_cat'
              AND tt.count > 0
              AND NOT EXISTS (
                  SELECT 1
                  FROM {$this->fifu_term_map_table} tm
                  WHERE tm.term_id = tt.term_id
                    AND tm.key_id = rs.key_id
              );
        ";

        $prepared = $this->wpdb->prepare($db2Sql, $seed, $seed);
        $rows = $this->wpdb->get_results($prepared) ?: [];

        $this->debug_auto_category('db2_insert_rows_selected', [
            'count' => count($rows),
            'last_error' => $this->wpdb->last_error,
            'sample' => array_slice(array_map(static function ($row) {
                return [
                    'term_id' => isset($row->term_id) ? (int) $row->term_id : null,
                    'key_id' => isset($row->key_id) ? (int) $row->key_id : null,
                    'hash' => isset($row->hash) ? (string) $row->hash : null,
                ];
            }, $rows), 0, 10),
        ]);

        if ($this->wpdb->last_error !== '') {
            $this->debug_auto_category('db2_insert_select_error', [
                'last_error' => $this->wpdb->last_error,
            ]);
            return null;
        }

        foreach ($rows as $row) {
            $term_id = isset($row->term_id) ? (int) $row->term_id : 0;
            $key_id = isset($row->key_id) ? (int) $row->key_id : 0;
            $hash = isset($row->hash) ? (string) $row->hash : '';

            if ($term_id <= 0 || $key_id <= 0 || $hash === '') {
                continue;
            }

            $this->debug_auto_category('db2_insert_row_before_insert', [
                'term_id' => $term_id,
                'key_id' => $key_id,
                'hash' => $hash,
            ]);

            $this->wpdb->query($this->wpdb->prepare(
                "INSERT INTO {$this->fifu_term_map_table} (term_id, key_id, hash)
                 VALUES (%d, %d, %s)
                 ON DUPLICATE KEY UPDATE hash = hash",
                $term_id,
                $key_id,
                $hash
            ));

            $this->debug_auto_category('db2_insert_row_after_insert', [
                'term_id' => $term_id,
                'key_id' => $key_id,
                'hash' => $hash,
                'rows_affected' => $this->wpdb->rows_affected,
                'last_error' => $this->wpdb->last_error,
            ]);

            if ($this->wpdb->last_error !== '') {
                return null;
            }

            clean_term_cache($term_id);
            wp_cache_delete($term_id, 'term_meta');
            $thumbnailBefore = (int) get_term_meta($term_id, 'thumbnail_id', true);
            $this->debug_auto_category('db2_insert_before_thumbnail_sync', [
                'term_id' => $term_id,
                'thumbnail_before' => $thumbnailBefore,
            ]);
            $this->ctgr_update_fake_attach_id($term_id);
            $thumbnailAfter = (int) get_term_meta($term_id, 'thumbnail_id', true);
            $this->debug_auto_category('db2_insert_after_thumbnail_sync', [
                'term_id' => $term_id,
                'thumbnail_after' => $thumbnailAfter,
            ]);
        }

        return;
    }

    /**
     * Ensures required DB2 tables exist before executing DB2 writes.
     *
     * @return bool
     */
    private function has_required_db2_tables(): bool {
        $tables = [
            $this->fifu_term_map_table,
            $this->fifu_map_table,
            $this->fifu_key_table,
            $this->fifu_url_table,
        ];

        foreach ($tables as $table) {
            $exists = $this->wpdb->get_var(
                $this->wpdb->prepare("SHOW TABLES LIKE %s", $table)
            );

            if ($exists === null || $exists === false) {
                return false;
            }
        }

        return true;
    }

    /**
     * Update existing category images automatically, respecting the current DB2 mode.
     *
     * @return void
     */
    public function update_category_images_auto(): void {
        $modeDb2 = 'db2';
        $modeHybrid = 'hybrid';

        if (class_exists('Fifu_Db2_Mode')) {
            $modeDb2 = Fifu_Db2_Mode::MODE_DB2;
            $modeHybrid = Fifu_Db2_Mode::MODE_HYBRID;
        }

        $seed = mt_rand();
        $mode = function_exists('fifu_db2_mode') ? fifu_db2_mode() : null;

        if ($mode === $modeDb2) {
            $ok = $this->update_category_images_auto_db2($seed);
            if ($ok === null) {
                $this->update_category_images_auto_legacy($seed);
            }
            return;
        }

        if ($mode === $modeHybrid) {
            $this->update_category_images_auto_db2($seed);
            $this->update_category_images_auto_legacy($seed);
            return;
        }

        $this->update_category_images_auto_legacy($seed);
    }

    /**
     * Legacy metadata updates for the automatic category image selection.
     *
     * @param int $seed
     * @return void
     */
    private function update_category_images_auto_legacy(int $seed): void {
        $result = $this->wpdb->get_results(
            $this->wpdb->prepare("
            SELECT tt.term_id, c.meta_value
            FROM {$this->termTaxonomy} tt
            INNER JOIN (
                SELECT ranked.term_taxonomy_id, ranked.object_id, ranked.meta_value
                FROM (
                    SELECT
                        cand.term_taxonomy_id,
                        cand.object_id,
                        cand.meta_value,
                        CONV(SUBSTRING(MD5(CONCAT(cand.term_taxonomy_id, ':', cand.object_id, ':', %d)), 1, 16), 16, 10) AS rnd
                    FROM (
                        SELECT
                            tr.term_taxonomy_id,
                            tr.object_id,
                            pm.meta_value
                        FROM {$this->termRelationships} tr
                        INNER JOIN {$this->termTaxonomy} tt2
                            ON tt2.term_taxonomy_id = tr.term_taxonomy_id
                           AND tt2.taxonomy = 'product_cat'
                           AND tt2.count > 0
                        INNER JOIN {$this->posts} p
                            ON p.id = tr.object_id
                           AND p.post_status <> 'trash'
                        INNER JOIN {$this->postmeta} pm
                            ON pm.post_id = tr.object_id
                           AND pm.meta_key = 'fifu_image_url'
                           AND pm.meta_value IS NOT NULL
                           AND pm.meta_value <> ''
                        WHERE EXISTS (
                            SELECT 1
                            FROM {$this->termmeta} tm2
                            WHERE tm2.term_id = tt2.term_id
                              AND tm2.meta_key = 'fifu_image_url'
                        )
                        AND NOT EXISTS (
                            SELECT 1
                            FROM {$this->fifu_term_map_table} tm_db2
                            INNER JOIN {$this->fifu_key_table} k_db2
                                ON k_db2.key_id = tm_db2.key_id
                               AND k_db2.key_type = 'image'
                            WHERE tm_db2.term_id = tt2.term_id
                        )
                    ) cand
                ) ranked
                INNER JOIN (
                    SELECT term_taxonomy_id, MIN(rnd) AS min_rnd
                    FROM (
                        SELECT
                            cand.term_taxonomy_id,
                            CONV(SUBSTRING(MD5(CONCAT(cand.term_taxonomy_id, ':', cand.object_id, ':', %d)), 1, 16), 16, 10) AS rnd
                        FROM (
                            SELECT
                                tr.term_taxonomy_id,
                                tr.object_id,
                                pm.meta_value
                            FROM {$this->termRelationships} tr
                            INNER JOIN {$this->termTaxonomy} tt2
                                ON tt2.term_taxonomy_id = tr.term_taxonomy_id
                               AND tt2.taxonomy = 'product_cat'
                               AND tt2.count > 0
                            INNER JOIN {$this->posts} p
                                ON p.id = tr.object_id
                               AND p.post_status <> 'trash'
                            INNER JOIN {$this->postmeta} pm
                                ON pm.post_id = tr.object_id
                               AND pm.meta_key = 'fifu_image_url'
                               AND pm.meta_value IS NOT NULL
                               AND pm.meta_value <> ''
                            WHERE EXISTS (
                                SELECT 1
                                FROM {$this->termmeta} tm2
                                WHERE tm2.term_id = tt2.term_id
                                  AND tm2.meta_key = 'fifu_image_url'
                            )
                            AND NOT EXISTS (
                                SELECT 1
                                FROM {$this->fifu_term_map_table} tm_db2
                                INNER JOIN {$this->fifu_key_table} k_db2
                                    ON k_db2.key_id = tm_db2.key_id
                                   AND k_db2.key_type = 'image'
                                WHERE tm_db2.term_id = tt2.term_id
                            )
                        ) cand
                    ) ranked_min
                    GROUP BY term_taxonomy_id
                ) tr_min
                    ON ranked.term_taxonomy_id = tr_min.term_taxonomy_id
                   AND ranked.rnd = tr_min.min_rnd
            ) c ON tt.term_taxonomy_id = c.term_taxonomy_id
        ", $seed, $seed)
        );

        $result = $result ?: [];

        foreach ($result as $res) {
            $term_id = isset($res->term_id) ? (int) $res->term_id : 0;
            $meta_value = isset($res->meta_value) ? (string) $res->meta_value : '';
            if ($term_id <= 0) {
                continue;
            }

            if ($meta_value === '') {
                continue;
            }

            if ($this->persist_auto_category_image_url($term_id, $meta_value)) {
                continue;
            }

            update_term_meta($term_id, 'fifu_image_url', $meta_value);
            $this->ctgr_update_fake_attach_id($term_id);
        }
    }

    /**
     * Persists the auto-category term image URL via the DB2 layer when available.
     *
     * On success, remove any stale legacy row so term reads resolve from DB2 first.
     *
     * @param int $termId
     * @param string $url
     * @return bool
     */
    private function persist_auto_category_image_url(int $termId, string $url): bool {
        if ($termId <= 0 || $url === '') {
            return false;
        }

        if (!function_exists('fifu_db2_mode')) {
            return false;
        }

        $ok = false;

        if (
            function_exists('fifu_db2_legacy_write_bridge')
            && class_exists('Fifu_Db2_Legacy_Write_Bridge')
        ) {
            $bridgeCandidate = fifu_db2_legacy_write_bridge();
            if ($bridgeCandidate instanceof Fifu_Db2_Legacy_Write_Bridge) {
                $ok = $bridgeCandidate->handle_term_meta_change($termId, 'fifu_image_url', $url);
            }
        }

        if (
            !$ok
            && function_exists('fifu_db2_write_service')
            && class_exists('Fifu_Db2_Write_Service')
        ) {
            $writeService = fifu_db2_write_service();
            if ($writeService instanceof Fifu_Db2_Write_Service) {
                $ok = $writeService->save_term_image($termId, $url);
            }
        }

        if (!$ok) {
            return false;
        }

        $this->wpdb->delete(
            $this->termmeta,
            ['term_id' => $termId, 'meta_key' => 'fifu_image_url'],
            ['%d', '%s']
        );
        clean_term_cache($termId);
        wp_cache_delete($termId, 'term_meta');
        wp_cache_flush();
        $this->ctgr_update_fake_attach_id($termId);

        return true;
    }

    /**
     * DB2 updates for category images using the new term map schema.
     *
     * @param int $seed
     * @return bool|null
     */
    private function update_category_images_auto_db2(int $seed): ?bool {
        if (!$this->has_required_db2_tables()) {
            return null;
        }

        $image_key_id = (int) $this->wpdb->get_var("
            SELECT key_id
            FROM {$this->fifu_key_table}
            WHERE key_type = 'image'
            LIMIT 1
        ");

        if (!$image_key_id) {
            return null;
        }

        $query = "
            SELECT
                tt.term_id,
                m.hash AS new_hash
            FROM {$this->termTaxonomy} tt
            INNER JOIN (
                SELECT tr_rnd.term_taxonomy_id, tr_rnd.object_id
                FROM (
                    SELECT tr.term_taxonomy_id, tr.object_id, RAND(%d) AS rnd
                    FROM {$this->termRelationships} tr
                ) tr_rnd
                INNER JOIN (
                    SELECT term_taxonomy_id, MIN(rnd) AS min_rnd
                    FROM (
                        SELECT tr.term_taxonomy_id, RAND(%d) AS rnd
                        FROM {$this->termRelationships} tr
                    ) tr_rnd2
                    GROUP BY term_taxonomy_id
                ) tr_min
                    ON tr_rnd.term_taxonomy_id = tr_min.term_taxonomy_id
                   AND tr_rnd.rnd = tr_min.min_rnd
            ) rs
                ON tt.term_taxonomy_id = rs.term_taxonomy_id
            INNER JOIN {$this->fifu_map_table} m
                ON m.post_id = rs.object_id
               AND m.key_index = 0
            INNER JOIN {$this->fifu_key_table} k
                ON k.key_id = m.key_id
               AND k.key_type = 'image'
            INNER JOIN {$this->fifu_url_table} u
                ON u.hash = m.hash
            WHERE tt.taxonomy = 'product_cat'
              AND tt.count > 0
              AND EXISTS (
                  SELECT 1
                  FROM {$this->fifu_term_map_table} tm
                  WHERE tm.term_id = tt.term_id
                    AND tm.key_id = k.key_id
              )
        ";

        $result = $this->wpdb->get_results(
            $this->wpdb->prepare($query, $seed, $seed)
        );

        if ($this->wpdb->last_error !== '') {
            return null;
        }

        $result = $result ?: [];

        foreach ($result as $res) {
            $term_id  = (int) $res->term_id;
            $new_hash = (string) $res->new_hash;

            $this->wpdb->update(
                $this->fifu_term_map_table,
                array('hash' => $new_hash),
                array('term_id' => $term_id, 'key_id' => $image_key_id),
                array(),
                array()
            );

            if ($this->wpdb->last_error !== '') {
                return null;
            }

            wp_cache_flush();
            $this->ctgr_update_fake_attach_id($term_id);
        }

        return true;
    }

    /**
     * Synchronizes the category attachment as the legacy helper did.
     *
     * @param int $term_id
     * @return void
     */
    private function ctgr_update_fake_attach_id(int $term_id): void {
        $this->debug_auto_category('thumbnail_sync_entry', [
            'term_id' => $term_id,
            'sync_class_exists' => class_exists('Fifu_Post_Attachment_Sync_Service'),
            'thumbnail_before' => (int) get_term_meta($term_id, 'thumbnail_id', true),
        ]);

        if (! class_exists('Fifu_Post_Attachment_Sync_Service')) {
            $this->debug_auto_category('thumbnail_sync_abort_missing_class', [
                'term_id' => $term_id,
            ]);
            return;
        }

        Fifu_Post_Attachment_Sync_Service::sync_category_attachment($term_id);
        $this->debug_auto_category('thumbnail_sync_exit', [
            'term_id' => $term_id,
            'thumbnail_after' => (int) get_term_meta($term_id, 'thumbnail_id', true),
        ]);
    }

    /**
     * Insert custom fields for posts as part of speed-up operations.
     *
     * @param string $valuesSql
     * @return int
     */
    public function insert_post_custom_fields(string $valuesSql): int {
        if (!$valuesSql) {
            return 0;
        }

        $valuesSql = $this->filter_values_sql_for_db2_rows($valuesSql);
        if ($valuesSql === '') {
            return 0;
        }

        if ($this->values_sql_contains_db2_managed_key($valuesSql)) {
            // DB2-only: do not write DB2-managed FIFU keys to legacy meta.
            return 0;
        }

        $query = "INSERT INTO {$this->postmeta} (post_id, meta_key, meta_value) VALUES {$valuesSql}";
        return (int) $this->wpdb->query($query);
    }

    /**
     * Insert custom fields for terms as part of speed-up operations.
     *
     * @param string $valuesSql
     * @return int
     */
    public function insert_term_custom_fields(string $valuesSql): int {
        if (!$valuesSql) {
            return 0;
        }

        $valuesSql = $this->filter_values_sql_for_db2_rows($valuesSql);
        if ($valuesSql === '') {
            return 0;
        }

        if ($this->values_sql_contains_db2_managed_key($valuesSql)) {
            // DB2-only: do not write DB2-managed FIFU keys to legacy meta.
            return 0;
        }

        $query = "INSERT INTO {$this->termmeta} (term_id, meta_key, meta_value) VALUES {$valuesSql}";
        return (int) $this->wpdb->query($query);
    }

    /**
     * Return internal URLs associated with the given posts.
     *
     * @param array|int|string $postIds
     * @return array
     */
    public function get_internal_urls_for_posts(array|int|string $postIds): array {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($postIds);
        if (!$idsCsv) {
            return [];
        }

        $this->wpdb->query("SET SESSION group_concat_max_len = 1048576;");
        $query = "
            SELECT
                p.id AS att_id,
                p.guid AS url,
                (
                    SELECT alt.meta_value
                    FROM {$this->postmeta} alt
                    WHERE alt.post_id = p.id
                      AND alt.meta_key = '_wp_attachment_image_alt'
                    LIMIT 1
                ) AS alt
            FROM {$this->posts} p
            WHERE FIND_IN_SET(p.id,
                (
                    SELECT GROUP_CONCAT(pm.meta_value) AS att_ids
                    FROM {$this->postmeta} pm
                    WHERE pm.post_id IN ({$idsCsv})
                    AND meta_key IN ('bkp_thumbnail_id', 'bkp_product_image_gallery')
                )
            )
        ";

        $results = $this->wpdb->get_results($query);
        return $results ? $this->hydrate_internal_attachment_rows($results) : [];
    }

    /**
     * Return internal URLs associated with the given terms.
     *
     * @param array|int|string $termIds
     * @return array
     */
    public function get_internal_urls_for_terms(array|int|string $termIds): array {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($termIds);
        if (!$idsCsv) {
            return [];
        }

        $this->wpdb->query("SET SESSION group_concat_max_len = 1048576;");
        $query = "
            SELECT
                p.id AS att_id,
                p.guid AS url,
                (
                    SELECT alt.meta_value
                    FROM {$this->postmeta} alt
                    WHERE alt.post_id = p.id
                      AND alt.meta_key = '_wp_attachment_image_alt'
                    LIMIT 1
                ) AS alt
            FROM {$this->posts} p
            WHERE FIND_IN_SET(p.id,
                (
                    SELECT GROUP_CONCAT(tm.meta_value) AS att_ids
                    FROM {$this->termmeta} tm
                    WHERE tm.term_id IN ({$idsCsv})
                    AND meta_key = 'bkp_thumbnail_id'
                )
            )
        ";

        $results = $this->wpdb->get_results($query);
        return $results ? $this->hydrate_internal_attachment_rows($results) : [];
    }

    /**
     * Delete attachment IDs linked to the provided posts for speed-up cleanup.
     *
     * @param array|int|string $postIds
     * @return int
     */
    public function delete_post_attachment_ids(array|int|string $postIds): int {
        return $this->delete_post_attachment_ids_by_keys(
            $postIds,
            ['_thumbnail_id', '_product_image_gallery']
        );
    }

    /**
     * Delete only featured attachment IDs linked to the provided posts.
     *
     * @param array|int|string $postIds
     * @return int
     */
    public function delete_post_featured_attachment_ids(array|int|string $postIds): int {
        return $this->delete_post_attachment_ids_by_keys($postIds, ['_thumbnail_id']);
    }

    /**
     * Delete only gallery attachment IDs linked to the provided posts.
     *
     * @param array|int|string $postIds
     * @return int
     */
    public function delete_post_gallery_attachment_ids(array|int|string $postIds): int {
        return $this->delete_post_attachment_ids_by_keys(
            $postIds,
            ['_product_image_gallery', '_wc_additional_variation_images']
        );
    }

    /**
     * Delete attachment IDs linked to the provided terms for speed-up cleanup.
     *
     * @param array|int|string $termIds
     * @return int
     */
    public function delete_term_attachment_ids(array|int|string $termIds): int {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($termIds);
        if (!$idsCsv) {
            return 0;
        }

        $termIdsArray = array_values(array_filter(array_map('intval', explode(',', $idsCsv))));
        if (!$termIdsArray) {
            return 0;
        }

        $allowedKeys = ['thumbnail_id'];
        $termPlaceholders = implode(',', array_fill(0, count($termIdsArray), '%d'));
        $keyPlaceholders = implode(',', array_fill(0, count($allowedKeys), '%s'));

        $query = "
            DELETE FROM {$this->termmeta}
            WHERE term_id IN ({$termPlaceholders})
            AND meta_key IN ({$keyPlaceholders})
            AND meta_key NOT LIKE 'fifu\\_%'
        ";

        $args = array_merge($termIdsArray, $allowedKeys);
        return (int) $this->wpdb->query($this->wpdb->prepare($query, ...$args));
    }

    /**
     * Delete attachment IDs linked to the provided posts for the given meta keys.
     *
     * @param array|int|string $postIds
     * @param string[]         $allowedKeys
     * @return int
     */
    private function delete_post_attachment_ids_by_keys(array|int|string $postIds, array $allowedKeys): int {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($postIds);
        if (!$idsCsv) {
            return 0;
        }

        $postIdsArray = array_values(array_filter(array_map('intval', explode(',', $idsCsv))));
        if (!$postIdsArray) {
            return 0;
        }

        $allowedKeys = array_values(array_filter(array_unique($allowedKeys), static fn(string $key): bool => $key !== ''));
        if (!$allowedKeys) {
            return 0;
        }

        $postPlaceholders = implode(',', array_fill(0, count($postIdsArray), '%d'));
        $keyPlaceholders = implode(',', array_fill(0, count($allowedKeys), '%s'));

        $query = "
            DELETE FROM {$this->postmeta}
            WHERE post_id IN ({$postPlaceholders})
            AND meta_key IN ({$keyPlaceholders})
            AND meta_key NOT LIKE 'fifu\\_%'
        ";

        $args = array_merge($postIdsArray, $allowedKeys);
        return (int) $this->wpdb->query($this->wpdb->prepare($query, ...$args));
    }

    /**
     * Backup attachment IDs linked to the provided posts before deletion.
     *
     * @param array|int|string $postIds
     * @return int
     */
    public function backup_post_attachment_ids(array|int|string $postIds): int {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($postIds);
        if (!$idsCsv) {
            return 0;
        }

        $postIdsArray = array_values(array_filter(array_map('intval', explode(',', $idsCsv))));
        if (!$postIdsArray) {
            return 0;
        }

        $allowedKeys = ['_thumbnail_id', '_product_image_gallery'];
        $allowedKeysFiltered = [];
        foreach ($allowedKeys as $metaKey) {
            if ($metaKey === '' || strncmp($metaKey, 'fifu_', 5) === 0) {
                continue;
            }
            if ($this->is_db2_managed_fifu_key($metaKey)) {
                continue;
            }
            $allowedKeysFiltered[] = $metaKey;
        }
        $allowedKeysFiltered = array_values(array_unique($allowedKeysFiltered));
        if (!$allowedKeysFiltered) {
            return 0;
        }

        $backupKeys = array_map(fn(string $metaKey): string => 'bkp' . $metaKey, $allowedKeysFiltered);
        $backupMap = array_combine($allowedKeysFiltered, $backupKeys);

        $postPlaceholders = implode(',', array_fill(0, count($postIdsArray), '%d'));
        $keyPlaceholders = implode(',', array_fill(0, count($allowedKeysFiltered), '%s'));
        $caseParts = [];
        foreach ($backupMap as $metaKey => $backupKey) {
            $caseParts[] = "WHEN '{$metaKey}' THEN '{$backupKey}'";
        }
        $caseExpression = implode("\n", $caseParts);
        $caseSql = "
            CASE pm.meta_key
                {$caseExpression}
                ELSE ''
            END
        ";

        $query = "
            INSERT INTO {$this->postmeta} (post_id, meta_key, meta_value)
            (
                SELECT pm.post_id, CONCAT('bkp', pm.meta_key) AS meta_key, pm.meta_value
                FROM {$this->postmeta} pm
                WHERE pm.post_id IN ({$postPlaceholders})
                AND pm.meta_key IN ({$keyPlaceholders})
                AND pm.meta_key NOT LIKE 'fifu\\_%'
                AND NOT EXISTS (
                    SELECT 1
                    FROM {$this->postmeta} pm2
                    WHERE pm2.post_id = pm.post_id
                    AND pm2.meta_key = {$caseSql}
                )
            )
        ";

        $args = array_merge($postIdsArray, $allowedKeysFiltered);
        return (int) $this->wpdb->query($this->wpdb->prepare($query, ...$args));
    }

    /**
     * Backup attachment IDs linked to the provided terms before deletion.
     *
     * @param array|int|string $termIds
     * @return int
     */
    public function backup_term_attachment_ids(array|int|string $termIds): int {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($termIds);
        if (!$idsCsv) {
            return 0;
        }

        $termIdsArray = array_values(array_filter(array_map('intval', explode(',', $idsCsv))));
        if (!$termIdsArray) {
            return 0;
        }

        $allowedKeys = ['thumbnail_id'];
        $allowedKeysFiltered = [];
        foreach ($allowedKeys as $metaKey) {
            if ($metaKey === '' || strncmp($metaKey, 'fifu_', 5) === 0) {
                continue;
            }
            if ($this->is_db2_managed_fifu_key($metaKey)) {
                continue;
            }
            $allowedKeysFiltered[] = $metaKey;
        }
        $allowedKeysFiltered = array_values(array_unique($allowedKeysFiltered));
        if (!$allowedKeysFiltered) {
            return 0;
        }

        $backupKeys = array_map(fn(string $metaKey): string => 'bkp_' . $metaKey, $allowedKeysFiltered);

        $termPlaceholders = implode(',', array_fill(0, count($termIdsArray), '%d'));
        $keyPlaceholders = implode(',', array_fill(0, count($allowedKeysFiltered), '%s'));
        $backupPlaceholders = implode(',', array_fill(0, count($backupKeys), '%s'));

        $query = "
            INSERT INTO {$this->termmeta} (term_id, meta_key, meta_value)
            (
                SELECT tm.term_id, CONCAT('bkp_', tm.meta_key) AS meta_key, tm.meta_value
                FROM {$this->termmeta} tm
                WHERE tm.term_id IN ({$termPlaceholders})
                AND tm.meta_key IN ({$keyPlaceholders})
                AND tm.meta_key NOT LIKE 'fifu\\_%'
                AND NOT EXISTS (
                    SELECT 1
                    FROM {$this->termmeta} tm2
                    WHERE tm2.term_id = tm.term_id
                    AND tm2.meta_key IN ({$backupPlaceholders})
                )
            )
        ";

        $args = array_merge($termIdsArray, $allowedKeysFiltered, $backupKeys);
        return (int) $this->wpdb->query($this->wpdb->prepare($query, ...$args));
    }

    /**
     * Collect thumbnail IDs for the provided posts.
     *
     * @param array|int|string $postIds
     * @return int[]
     */
    public function collect_thumbnail_ids(array|int|string $postIds): array {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($postIds);
        if ($idsCsv === '0') {
            return [];
        }

        $results = $this->wpdb->get_col("
            SELECT meta_value
            FROM {$this->postmeta}
            WHERE post_id IN ({$idsCsv})
            AND meta_key = '_thumbnail_id'
        ");

        $ids = [];
        foreach ($results as $result) {
            $id = (int) $result;
            if ($id > 0) {
                $ids[] = $id;
            }
        }

        return array_values(array_unique($ids));
    }

    /**
     * Inserts FIFU attachments for posts as part of insert_postmeta2.
     *
     * @param string $valuesSql
     * @param array|int|string $postIds
     */
    public function insert_post_attachment_meta(string $valuesSql, array|int|string $postIds): void {
        if ($valuesSql === '') {
            return;
        }

        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($postIds);
        if ($idsCsv === '0') {
            return;
        }

        $this->wpdb->query("INSERT INTO {$this->posts} (post_author, guid, post_title, post_excerpt, post_mime_type, post_type, post_status, post_parent, post_date, post_date_gmt, post_modified, post_modified_gmt, post_content, to_ping, pinged, post_content_filtered) VALUES {$valuesSql}");

        $author = $this->get_author();
        $postIdsArray = array_values(array_filter(array_map('intval', explode(',', $idsCsv))));
        if ($postIdsArray) {
            $allowedKeys = ['_thumbnail_id'];
            $metaKey = '_thumbnail_id';
            if (
                in_array($metaKey, $allowedKeys, true)
                && strncmp($metaKey, 'fifu_', 5) !== 0
                && !$this->is_db2_managed_fifu_key($metaKey)
            ) {
                $postPlaceholders = implode(',', array_fill(0, count($postIdsArray), '%d'));
                $targetSql = "
                    SELECT p.post_parent AS post_id, MIN(p.ID) AS attachment_id
                      FROM {$this->posts} p
                     WHERE p.post_parent IN ({$postPlaceholders})
                       AND p.post_author = %d
                       AND p.post_parent > 0
                     GROUP BY p.post_parent
                ";
                $updateSql = $this->wpdb->prepare(
                    "
                    UPDATE {$this->postmeta} pm
                    INNER JOIN ({$targetSql}) target
                            ON target.post_id = pm.post_id
                       SET pm.meta_value = target.attachment_id
                     WHERE pm.meta_key = %s
                       AND CAST(pm.meta_value AS UNSIGNED) = 0
                    ",
                    ...array_merge($postIdsArray, [$author, $metaKey])
                );
                $this->wpdb->query($updateSql);

                $insertSql = $this->wpdb->prepare(
                    "
                    INSERT INTO {$this->postmeta} (post_id, meta_key, meta_value)
                    SELECT target.post_id, %s, target.attachment_id
                      FROM ({$targetSql}) target
                     WHERE NOT EXISTS (
                           SELECT 1
                             FROM {$this->postmeta} pm
                            WHERE pm.post_id = target.post_id
                              AND pm.meta_key = %s
                     )
                    ",
                    ...array_merge([$metaKey], $postIdsArray, [$author, $metaKey])
                );
                $this->wpdb->query($insertSql);

                $deleteSql = "
                    DELETE pm_zero
                      FROM {$this->postmeta} pm_zero
                      INNER JOIN {$this->postmeta} pm_real
                              ON pm_real.post_id = pm_zero.post_id
                             AND pm_real.meta_key = %s
                             AND CAST(pm_real.meta_value AS UNSIGNED) > 0
                     WHERE pm_zero.post_id IN ({$postPlaceholders})
                       AND pm_zero.meta_key = %s
                       AND CAST(pm_zero.meta_value AS UNSIGNED) = 0
                ";
                $this->wpdb->query($this->wpdb->prepare($deleteSql, ...array_merge([$metaKey], $postIdsArray, [$metaKey])));
            }
        }

        if ($postIdsArray) {
            $allowedFileKeys = ['_wp_attached_file'];
            $fileMetaKey = '_wp_attached_file';
            if (
                in_array($fileMetaKey, $allowedFileKeys, true)
                && strncmp($fileMetaKey, 'fifu_', 5) !== 0
                && !$this->is_db2_managed_fifu_key($fileMetaKey)
            ) {
                $postPlaceholders = implode(',', array_fill(0, count($postIdsArray), '%d'));
                $fileQuery = "
                    INSERT INTO {$this->postmeta} (post_id, meta_key, meta_value) (
                        SELECT p.id, %s, p.post_content_filtered
                        FROM {$this->posts} p
                        WHERE p.post_parent IN ({$postPlaceholders})
                        AND p.post_author = %d
                    )
                ";
                $sqlFileArgs = array_merge([$fileMetaKey], $postIdsArray, [$author]);
                $sqlFile = $this->wpdb->prepare($fileQuery, ...$sqlFileArgs);
                $this->wpdb->query($sqlFile);
            }
        }

        if ($postIdsArray) {
            $allowedAltKeys = ['_wp_attachment_image_alt'];
            $altMetaKey = '_wp_attachment_image_alt';
            if (
                in_array($altMetaKey, $allowedAltKeys, true)
                && strncmp($altMetaKey, 'fifu_', 5) !== 0
                && !$this->is_db2_managed_fifu_key($altMetaKey)
            ) {
                $postPlaceholders = implode(',', array_fill(0, count($postIdsArray), '%d'));
                $altQuery = "
                    INSERT INTO {$this->postmeta} (post_id, meta_key, meta_value) (
                        SELECT p.id, %s, p.post_title
                        FROM {$this->posts} p
                        WHERE p.post_parent IN ({$postPlaceholders})
                        AND p.post_author = %d
                        AND p.post_title IS NOT NULL
                        AND p.post_title != ''
                    )
                ";
                $sqlAltArgs = array_merge([$altMetaKey], $postIdsArray, [$author]);
                $sqlAlt = $this->wpdb->prepare($altQuery, ...$sqlAltArgs);
                $this->wpdb->query($sqlAlt);
            }
        }
        foreach ($postIdsArray as $postId) {
            clean_post_cache($postId);
            wp_cache_delete($postId, 'post_meta');
        }
    }

    /**
     * Deletes FIFU-generated attachment metadata as part of delete_attmeta2.
     *
     * @param array|int|string $attachmentIds
     */
    public function delete_attachment_meta(array|int|string $attachmentIds): void {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($attachmentIds);
        if ($idsCsv === '0') {
            return;
        }

        $attachmentIdsArray = array_values(array_filter(array_map('intval', explode(',', $idsCsv))));
        if (!$attachmentIdsArray) {
            return;
        }

        $repository = new Fifu_Attachment_Repository();
        $cleanup = new Fifu_Local_Media_Cleanup();
        $managed_post_reference_keys = ['_thumbnail_id'];
        $managed_term_reference_keys = ['thumbnail_id'];
        foreach ($attachmentIdsArray as $attachmentId) {
            if (
                $attachmentId <= 0
                || 'attachment' !== get_post_type($attachmentId)
                || (int) get_post_field('post_author', $attachmentId) !== $this->get_author()
                || $repository->get_referenced_attachment_ids(
                    [$attachmentId],
                    0,
                    $managed_post_reference_keys,
                    $managed_term_reference_keys
                )
                || !Fifu_Attachment_Update_Service::is_safe_to_delete_remote_attachment($attachmentId)
            ) {
                continue;
            }

            $cleanup->delete_attachments_and_meta(
                [$attachmentId],
                0,
                $managed_post_reference_keys,
                $managed_term_reference_keys
            );
            if (!get_post($attachmentId)) {
                $this->wpdb->delete($this->postmeta, ['meta_key' => '_thumbnail_id', 'meta_value' => (string) $attachmentId], ['%s', '%s']);
                $this->wpdb->delete($this->termmeta, ['meta_key' => 'thumbnail_id', 'meta_value' => (string) $attachmentId], ['%s', '%s']);
            }
        }
    }

    /**
     * Deletes WooCommerce gallery metadata when running delete_woometa2.
     *
     * @param array|int|string $postIds
     */
    public function delete_woocommerce_gallery_meta(array|int|string $postIds): void {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($postIds);
        if ($idsCsv === '0') {
            return;
        }

        $postIdsArray = array_values(array_filter(array_map('intval', explode(',', $idsCsv))));
        if (!empty($postIdsArray)) {
            $allowedMetaKeys = ['_product_image_gallery', '_wc_additional_variation_images'];
            $metaKeysSql = "'" . implode("','", $allowedMetaKeys) . "'";
            $placeholders = implode(',', array_fill(0, count($postIdsArray), '%d'));
            $sqlDeleteGallery = "
                DELETE FROM {$this->postmeta}
                WHERE meta_key IN ({$metaKeysSql})
                AND post_id IN ({$placeholders})
                AND meta_key NOT LIKE 'fifu\\_%'
            ";
            $deleted = $this->wpdb->query($this->wpdb->prepare($sqlDeleteGallery, ...$postIdsArray));

            if ($deleted !== false) {
                foreach ($postIdsArray as $postId) {
                    if ($postId <= 0) {
                        continue;
                    }

                    clean_post_cache($postId);
                    wp_cache_delete($postId, 'post_meta');
                }
            }
        }

        if (Fifu_Theme_Detector::is_houzez_active() && !empty($postIdsArray)) {
            $metaKey = 'fave_property_images';
            if (strncmp($metaKey, 'fifu_', 5) !== 0 && !$this->is_db2_managed_fifu_key($metaKey)) {
                $placeholders = implode(',', array_fill(0, count($postIdsArray), '%d'));
                $sqlHouzez = "
                    DELETE FROM {$this->postmeta}
                    WHERE meta_key = %s
                    AND post_id IN ({$placeholders})
                    AND meta_key NOT LIKE 'fifu\\_%'
                ";
                $this->wpdb->query($this->wpdb->prepare($sqlHouzez, $metaKey, ...$postIdsArray));
            }
        }

        if (Fifu_Theme_Detector::is_wpresidence_active() && !empty($postIdsArray)) {
            $metaKey = 'wpestate_property_gallery';
            if (strncmp($metaKey, 'fifu_', 5) !== 0 && !$this->is_db2_managed_fifu_key($metaKey)) {
                $placeholders = implode(',', array_fill(0, count($postIdsArray), '%d'));
                $sqlWpresidence = "
                    DELETE FROM {$this->postmeta}
                    WHERE meta_key = %s
                    AND post_id IN ({$placeholders})
                    AND meta_key NOT LIKE 'fifu\\_%'
                ";
                $this->wpdb->query($this->wpdb->prepare($sqlWpresidence, $metaKey, ...$postIdsArray));
            }
        }
    }

    /**
     * Deletes term thumbnail metadata as part of delete_termmeta2.
     *
     * @param array|int|string $termIds
     */
    public function delete_term_thumbnail_meta(array|int|string $termIds): void {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($termIds);
        if ($idsCsv === '0') {
            return;
        }

        $termIdsArray = array_values(array_filter(array_map('intval', explode(',', $idsCsv))));
        $metaKey = 'thumbnail_id';
        if ($termIdsArray) {
            $placeholders = implode(',', array_fill(0, count($termIdsArray), '%d'));
            $query = "
                DELETE FROM {$this->termmeta}
                WHERE meta_key = %s
                AND term_id IN ({$placeholders})
                AND meta_key NOT LIKE 'fifu\\_%'
            ";
            $this->wpdb->query($this->wpdb->prepare($query, $metaKey, ...$termIdsArray));
        }

        $author = $this->get_author();
        $sqlDeletePostmeta = $this->wpdb->prepare("
            DELETE pm
            FROM {$this->postmeta} pm
            JOIN {$this->posts} p ON pm.post_id = p.id
            WHERE pm.meta_key IN ('_wp_attached_file', '_wp_attachment_image_alt', '_wp_attachment_metadata')
            AND p.post_parent IN ({$idsCsv})
            AND p.post_author = %d
            AND p.post_name LIKE 'fifu-category%'
        ", $author);
        $this->wpdb->query($sqlDeletePostmeta);
    }

    /**
     * Inserts WooCommerce gallery attachments and metadata from insert_woometa2.
     *
     * @param string $valuesSql
     * @param array|int|string $postIds
     * @param array $thumbIds
     */
    public function insert_woocommerce_attachment_meta(
        string $valuesSql,
        array|int|string $postIds,
        array $thumbIds
    ): void {
        if ($valuesSql === '') {
            return;
        }

        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($postIds);
        if ($idsCsv === '0') {
            return;
        }

        $thumbIdsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($thumbIds);
        $thumbClause = $thumbIdsCsv !== '0' ? "AND p.id NOT IN ({$thumbIdsCsv})" : '';

        $postIdsArray = array_values(array_filter(array_map('intval', explode(',', $idsCsv))));
        $productPostIdsArray = $this->get_product_post_ids($postIdsArray);

        $this->wpdb->query("INSERT INTO {$this->posts} (post_author, guid, post_title, post_excerpt, post_mime_type, post_type, post_status, post_parent, post_date, post_date_gmt, post_modified, post_modified_gmt, post_content, to_ping, pinged, post_content_filtered) VALUES {$valuesSql}");

        $author = $this->get_author();
        if ($postIdsArray) {
            $allowedFileMetaKeys = ['_wp_attached_file'];
            $fileMetaKey = '_wp_attached_file';
            if (
                in_array($fileMetaKey, $allowedFileMetaKeys, true)
                && strncmp($fileMetaKey, 'fifu_', 5) !== 0
                && !$this->is_db2_managed_fifu_key($fileMetaKey)
            ) {
                $postPlaceholders = implode(',', array_fill(0, count($postIdsArray), '%d'));
                $fileQuery = "
                    INSERT INTO {$this->postmeta} (post_id, meta_key, meta_value) (
                        SELECT p.id, %s, p.post_content_filtered
                        FROM {$this->posts} p
                        WHERE p.post_parent IN ({$postPlaceholders})
                        {$thumbClause}
                        AND p.post_author = %d
                    )
                ";
                $sqlFileArgs = array_merge([$fileMetaKey], $postIdsArray, [$author]);
                $sqlFile = $this->wpdb->prepare($fileQuery, ...$sqlFileArgs);
                $this->wpdb->query($sqlFile);
            }
        }

        if ($postIdsArray) {
            $allowedAltKeys = ['_wp_attachment_image_alt'];
            $altMetaKey = '_wp_attachment_image_alt';
            if (
                in_array($altMetaKey, $allowedAltKeys, true)
                && strncmp($altMetaKey, 'fifu_', 5) !== 0
                && !$this->is_db2_managed_fifu_key($altMetaKey)
            ) {
                if (!$this->has_insertable_woocommerce_attachment_alt_meta($postIdsArray, $author, $thumbClause)) {
                } else {
                    $postPlaceholders = implode(',', array_fill(0, count($postIdsArray), '%d'));
                    $altQuery = "
                        INSERT INTO {$this->postmeta} (post_id, meta_key, meta_value) (
                            SELECT p.id, %s, p.post_excerpt
                            FROM {$this->posts} p
                            WHERE p.post_parent IN ({$postPlaceholders})
                            {$thumbClause}
                            AND p.post_author = %d
                            AND p.post_excerpt IS NOT NULL
                            AND p.post_excerpt != ''
                        )
                    ";
                    $sqlAltArgs = array_merge([$altMetaKey], $postIdsArray, [$author]);
                    $sqlAlt = $this->wpdb->prepare($altQuery, ...$sqlAltArgs);
                    $this->wpdb->query($sqlAlt);
                }
            }
        }

        if (!empty($postIdsArray)) {
            $metaKeysSql = "'_wc_additional_variation_images'";
            $placeholders = implode(',', array_fill(0, count($postIdsArray), '%d'));
            $sqlDeleteMeta = "
                DELETE pm
                FROM {$this->postmeta} pm
                WHERE pm.post_id IN ({$placeholders})
                AND pm.meta_key IN ({$metaKeysSql})
                AND pm.meta_key NOT LIKE 'fifu\\_%'
            ";
            $this->wpdb->query($this->wpdb->prepare($sqlDeleteMeta, ...$postIdsArray));
        }

        if ($productPostIdsArray) {
            $productPlaceholders = implode(',', array_fill(0, count($productPostIdsArray), '%d'));
            $sqlDeleteProductGallery = "
                DELETE pm
                FROM {$this->postmeta} pm
                WHERE pm.post_id IN ({$productPlaceholders})
                  AND pm.meta_key = '_product_image_gallery'
                  AND pm.meta_key NOT LIKE 'fifu\\_%'
            ";
            $this->wpdb->query($this->wpdb->prepare($sqlDeleteProductGallery, ...$productPostIdsArray));
        }

        if ($productPostIdsArray) {
            $allowedGalleryKeys = ['_product_image_gallery'];
            $galleryMetaKey = '_product_image_gallery';
            if (
                in_array($galleryMetaKey, $allowedGalleryKeys, true)
                && strncmp($galleryMetaKey, 'fifu_', 5) !== 0
                && !$this->is_db2_managed_fifu_key($galleryMetaKey)
            ) {
                $postPlaceholders = implode(',', array_fill(0, count($productPostIdsArray), '%d'));
                $galleryQuery = "
                    INSERT INTO {$this->postmeta} (post_id, meta_key, meta_value) (
                        SELECT post_parent, %s, GROUP_CONCAT(id ORDER BY id)
                        FROM {$this->posts} p
                        WHERE p.post_parent IN ({$postPlaceholders})
                        AND NOT EXISTS (
                            SELECT 1
                            FROM {$this->postmeta} pm_thumb
                            WHERE pm_thumb.post_id = p.post_parent
                              AND pm_thumb.meta_key = '_thumbnail_id'
                              AND pm_thumb.meta_value = CAST(p.id AS CHAR)
                        )
                        AND p.post_author = %d
                        GROUP BY post_parent
                    )
                ";
                $sqlGalleryArgs = array_merge([$galleryMetaKey], $productPostIdsArray, [$author]);
                $sqlGallery = $this->wpdb->prepare($galleryQuery, ...$sqlGalleryArgs);
                $this->wpdb->query($sqlGallery);
            }
        }

        if (Fifu_Theme_Detector::is_houzez_active() && $postIdsArray) {
            $allowedHouzezKeys = ['fave_property_images'];
            $houzezMetaKey = 'fave_property_images';
            if (
                in_array($houzezMetaKey, $allowedHouzezKeys, true)
                && strncmp($houzezMetaKey, 'fifu_', 5) !== 0
                && !$this->is_db2_managed_fifu_key($houzezMetaKey)
            ) {
                $postPlaceholders = implode(',', array_fill(0, count($postIdsArray), '%d'));
                $houzezQuery = "
                    INSERT INTO {$this->postmeta} (post_id, meta_key, meta_value) (
                        SELECT post_parent, %s, id
                        FROM {$this->posts} p
                        WHERE p.post_parent IN ({$postPlaceholders})
                        {$thumbClause}
                        AND p.post_author = %d
                    )
                ";
                $sqlHouzezArgs = array_merge([$houzezMetaKey], $postIdsArray, [$author]);
                $sqlHouzez = $this->wpdb->prepare($houzezQuery, ...$sqlHouzezArgs);
                $this->wpdb->query($sqlHouzez);
            }
        }

        if (Fifu_Theme_Detector::is_wpresidence_active() && $postIdsArray) {
            $allowedWpestateKeys = ['wpestate_property_gallery'];
            $wpestateMetaKey = 'wpestate_property_gallery';
            if (
                in_array($wpestateMetaKey, $allowedWpestateKeys, true)
                && strncmp($wpestateMetaKey, 'fifu_', 5) !== 0
                && !$this->is_db2_managed_fifu_key($wpestateMetaKey)
            ) {
                $postPlaceholders = implode(',', array_fill(0, count($postIdsArray), '%d'));
                $wpestateQuery = "
                    INSERT INTO {$this->postmeta} (post_id, meta_key, meta_value) (
                        SELECT post_parent, %s, GROUP_CONCAT(id ORDER BY id)
                        FROM {$this->posts} p
                        WHERE p.post_parent IN ({$postPlaceholders})
                        AND p.post_author = %d
                        GROUP BY post_parent
                    )
                ";
                $sqlWpestateArgs = array_merge([$wpestateMetaKey], $postIdsArray, [$author]);
                $sqlWpestate = $this->wpdb->prepare($wpestateQuery, ...$sqlWpestateArgs);
                $this->wpdb->query($sqlWpestate);
            }

            $postsWithGalleries = $this->wpdb->get_results("
                SELECT post_id, GROUP_CONCAT(meta_value) AS attachment_ids
                FROM {$this->postmeta}
                WHERE post_id IN ({$idsCsv})
                AND meta_key = 'wpestate_property_gallery'
                GROUP BY post_id
            ");

            foreach ($postsWithGalleries as $post) {
                $galleryIds = explode(',', $post->attachment_ids);
                $formattedGallery = array_combine(range(1, count($galleryIds)), $galleryIds);
                update_post_meta($post->post_id, 'wpestate_property_gallery', $formattedGallery);
            }
        }

        if ($postIdsArray) {
            $allowedAdditionalKeys = ['_wc_additional_variation_images'];
            $additionalMetaKey = '_wc_additional_variation_images';
            if (
                in_array($additionalMetaKey, $allowedAdditionalKeys, true)
                && strncmp($additionalMetaKey, 'fifu_', 5) !== 0
                && !$this->is_db2_managed_fifu_key($additionalMetaKey)
            ) {
                $variationPostIdsArray = $this->get_product_variation_post_ids($postIdsArray);

                if ($variationPostIdsArray === []) {
                } else {
                    $variationPlaceholders = implode(',', array_fill(0, count($variationPostIdsArray), '%d'));
                    $additionalQuery = "
                        INSERT INTO {$this->postmeta} (post_id, meta_key, meta_value) (
                            SELECT p.post_parent, %s, GROUP_CONCAT(p.id ORDER BY p.id)
                            FROM {$this->posts} p
                            WHERE p.post_parent IN ({$variationPlaceholders})
                            AND NOT EXISTS (
                                SELECT 1
                                FROM {$this->postmeta} pm_thumb
                                WHERE pm_thumb.post_id = p.post_parent
                                  AND pm_thumb.meta_key = '_thumbnail_id'
                                  AND pm_thumb.meta_value = CAST(p.id AS CHAR)
                            )
                            AND p.post_author = %d
                            GROUP BY p.post_parent
                        )
                    ";

                    $sqlAdditionalArgs = array_merge([$additionalMetaKey], $variationPostIdsArray, [$author]);
                    $sqlAdditional = $this->wpdb->prepare($additionalQuery, ...$sqlAdditionalArgs);

                    $this->wpdb->query($sqlAdditional);
                }
            }
        }
    }

    /**
     * Backfills missing _wp_attached_file values for FIFU gallery attachments of a single post.
     *
     * @param int $postId
     * @return int
     */
    public function backfill_missing_attached_file_for_gallery_post(int $postId): int {
        if ($postId <= 0) {
            return 0;
        }

        $galleryMetaKeysSql = "'_product_image_gallery','_wc_additional_variation_images'";
        $candidateSql = $this->wpdb->prepare(
            "
                SELECT DISTINCT
                    p.id AS attachment_id,
                    p.post_content_filtered AS attached_file
                FROM {$this->posts} p
                INNER JOIN {$this->postmeta} gm
                    ON gm.post_id = %d
                   AND gm.meta_key IN ({$galleryMetaKeysSql})
                   AND FIND_IN_SET(
                       CAST(p.id AS CHAR),
                       REPLACE(TRIM(BOTH ',' FROM gm.meta_value), ' ', '')
                   ) > 0
                WHERE p.post_parent = %d
                  AND p.post_author = %d
                  AND p.post_type = 'attachment'
                  AND p.post_content_filtered IS NOT NULL
                  AND p.post_content_filtered <> ''
            ",
            $postId,
            $postId,
            $this->get_author()
        );

        $attachmentIds = array_values(array_unique(array_map(
            'intval',
            $this->wpdb->get_col("SELECT candidates.attachment_id FROM ({$candidateSql}) candidates")
        )));

        if (!$attachmentIds) {
            return 0;
        }

        $affectedRows = 0;
        $fileMetaKey = '_wp_attached_file';

        $updateSql = $this->wpdb->prepare(
            "
                UPDATE {$this->postmeta} pm
                INNER JOIN ({$candidateSql}) candidates
                    ON candidates.attachment_id = pm.post_id
                SET pm.meta_value = candidates.attached_file
                WHERE pm.meta_key = %s
                  AND (pm.meta_value IS NULL OR pm.meta_value = '')
            ",
            $fileMetaKey
        );
        $this->wpdb->query($updateSql);
        $affectedRows += max(0, (int) $this->wpdb->rows_affected);

        $insertSql = $this->wpdb->prepare(
            "
                INSERT INTO {$this->postmeta} (post_id, meta_key, meta_value)
                SELECT DISTINCT candidates.attachment_id, %s, candidates.attached_file
                FROM ({$candidateSql}) candidates
                LEFT JOIN {$this->postmeta} pm
                    ON pm.post_id = candidates.attachment_id
                   AND pm.meta_key = %s
                WHERE pm.post_id IS NULL
            ",
            $fileMetaKey,
            $fileMetaKey
        );
        $this->wpdb->query($insertSql);
        $affectedRows += max(0, (int) $this->wpdb->rows_affected);

        foreach ($attachmentIds as $attachmentId) {
            clean_post_cache($attachmentId);
            wp_cache_delete($attachmentId, 'post_meta');
        }

        return $affectedRows;
    }

    /**
     * Inserts term attachments for insert_termmeta2.
     *
     * @param string $valuesSql
     * @param array|int|string $termIds
     */
    public function insert_term_attachment_meta(string $valuesSql, array|int|string $termIds): void {
        if ($valuesSql === '') {
            return;
        }

        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($termIds);
        if ($idsCsv === '0') {
            return;
        }

        $this->wpdb->query("INSERT INTO {$this->posts} (post_author, guid, post_title, post_excerpt, post_mime_type, post_type, post_status, post_parent, post_date, post_date_gmt, post_modified, post_modified_gmt, post_content, to_ping, pinged, post_content_filtered, post_name) VALUES {$valuesSql}");

        $author = $this->get_author();
        $termIdsArray = array_values(array_filter(array_map('intval', explode(',', $idsCsv))));
        $allowedTermMetaKeys = ['thumbnail_id'];
        $termMetaKey = 'thumbnail_id';
        if (
            $termIdsArray
            && in_array($termMetaKey, $allowedTermMetaKeys, true)
            && strncmp($termMetaKey, 'fifu_', 5) !== 0
            && !$this->is_db2_managed_fifu_key($termMetaKey)
        ) {
            $termPlaceholders = implode(',', array_fill(0, count($termIdsArray), '%d'));
            $sqlTermThumbnailArgs = array_merge([$termMetaKey], $termIdsArray, [$author]);
            $sqlTermThumbnail = $this->wpdb->prepare("
                INSERT INTO {$this->termmeta} (term_id, meta_key, meta_value) (
                    SELECT p.post_parent, %s, p.id
                    FROM {$this->posts} p
                    WHERE p.post_parent IN ({$termPlaceholders})
                    AND p.post_author = %d
                    AND p.post_name LIKE 'fifu-category%'
                )
            ", ...$sqlTermThumbnailArgs);
            $this->wpdb->query($sqlTermThumbnail);
        }

        if ($termIdsArray) {
            $termPlaceholders = implode(',', array_fill(0, count($termIdsArray), '%d'));
            $allowedPostMetaKeys = ['_wp_attached_file', '_wp_attachment_image_alt'];

            $fileMetaKey = '_wp_attached_file';
            if (
                in_array($fileMetaKey, $allowedPostMetaKeys, true)
                && strncmp($fileMetaKey, 'fifu_', 5) !== 0
                && !$this->is_db2_managed_fifu_key($fileMetaKey)
            ) {
                $sqlTermFileArgs = array_merge([$fileMetaKey], $termIdsArray, [$author]);
                $sqlTermFile = $this->wpdb->prepare("
                    INSERT INTO {$this->postmeta} (post_id, meta_key, meta_value) (
                        SELECT p.id, %s, p.post_content_filtered
                        FROM {$this->posts} p
                        WHERE p.post_parent IN ({$termPlaceholders})
                        AND p.post_author = %d
                        AND p.post_name LIKE 'fifu-category%'
                    )
                ", ...$sqlTermFileArgs);
                $this->wpdb->query($sqlTermFile);
            }

            $altMetaKey = '_wp_attachment_image_alt';
            if (
                in_array($altMetaKey, $allowedPostMetaKeys, true)
                && strncmp($altMetaKey, 'fifu_', 5) !== 0
                && !$this->is_db2_managed_fifu_key($altMetaKey)
            ) {
                $sqlTermAltArgs = array_merge([$altMetaKey], $termIdsArray, [$author]);
                $sqlTermAlt = $this->wpdb->prepare("
                    INSERT INTO {$this->postmeta} (post_id, meta_key, meta_value) (
                        SELECT p.id, %s, p.post_title
                        FROM {$this->posts} p
                        WHERE p.post_parent IN ({$termPlaceholders})
                        AND p.post_author = %d
                        AND p.post_title IS NOT NULL
                        AND p.post_title != ''
                        AND p.post_name LIKE 'fifu-category%'
                    )
                ", ...$sqlTermAltArgs);
                $this->wpdb->query($sqlTermAlt);
            }
        }
    }

    /**
     * @param string $meta_key
     * @return bool
     */
    private function is_db2_managed_legacy_key(string $meta_key): bool {
        if (in_array($meta_key, self::DB2_MANAGED_LEGACY_KEYS, true)) {
            return true;
        }

        return preg_match(self::DB2_MANAGED_SUFFIX_PATTERN, $meta_key) === 1;
    }

    /**
     * @param string $meta_key
     * @return bool
     */
    private function is_db2_managed_fifu_key(string $meta_key): bool {
        static $exactKeys = [
            'fifu_image_url',
            'fifu_video_url',
            'fifu_custom_video_url',
            'fifu_image_alt',
            'fifu_list_url',
            'fifu_list_alt',
            'fifu_list_video_url',
            'fifu_slider_list_url',
            'fifu_slider_list_alt',
            'fifu_finder_url',
            'fifu_redirection_url',
            'fifu_audio_url',
            'fifu_metadatapost_sent',
            'fifu_metadataterm_sent',
            'fifu_uploadpost_sent',
            'fifu_uploadterm_sent',
            'fifu_importpost_sent',
            'fifu_importterm_sent',
            'fifu_auto_set_sent',
            'fifu_isbn_sent',
            'fifu_asin_sent',
            'fifu_finder_sent',
            'fifu_finder_counter',
        ];

        static $patterns = [
            '/^fifu_image_url_\\d+$/',
            '/^fifu_video_url_\\d+$/',
            '/^fifu_image_alt_\\d+$/',
            '/^fifu_slider_image_url_\\d+$/',
            '/^fifu_slider_image_alt_\\d+$/',
            '/^fifu_image_ifm_\\d+$/',
        ];

        if (in_array($meta_key, $exactKeys, true)) {
            return true;
        }

        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $meta_key) === 1) {
                return true;
            }
        }

        return false;
    }

    private function get_author(): int {
        return (int) Fifu_Options_Utils::get_author();
    }

    /**
     * @param string $valuesSql
     * @return bool
     */
    private function values_sql_contains_db2_managed_key(string $valuesSql): bool {
        if ($valuesSql === '') {
            return false;
        }

        if (!preg_match_all('/\(\s*[^,]+,\s*([\'"])([^\'"]+)\1\s*,/i', $valuesSql, $matches)) {
            return false;
        }

        foreach ($matches[2] as $meta_key) {
            if ($this->is_db2_managed_fifu_key($meta_key) || $this->is_db2_managed_legacy_key($meta_key)) {
                return true;
            }
        }

        return false;
    }

    private function filter_values_sql_for_db2_rows(string $valuesSql): string {
        if ($valuesSql === '') {
            return '';
        }

        $rows = $this->split_values_sql_rows($valuesSql);
        if ($rows === null) {
            return $valuesSql;
        }

        $allowedRows = [];
        foreach ($rows as $row) {
            if ($this->row_contains_db2_managed_key($row)) {
                continue;
            }
            $allowedRows[] = $row;
        }

        return implode(', ', $allowedRows);
    }

    private function row_contains_db2_managed_key(string $row): bool {
        if (!preg_match('/\(\s*[^,]+,\s*([\'"])([^\'"]+)\1\s*,/i', $row, $match)) {
            return false;
        }

        $metaKey = (string) $match[2];
        return $this->is_db2_managed_fifu_key($metaKey) || $this->is_db2_managed_legacy_key($metaKey);
    }

    private function split_values_sql_rows(string $valuesSql): ?array {
        $rows = [];
        $length = strlen($valuesSql);
        $depth = 0;
        $inQuote = null;
        $escapeNext = false;
        $start = null;

        for ($i = 0; $i < $length; $i++) {
            $char = $valuesSql[$i];

            if ($escapeNext) {
                $escapeNext = false;
                continue;
            }

            if ($char === '\\' && $inQuote !== null) {
                $escapeNext = true;
                continue;
            }

            if ($inQuote !== null) {
                if ($char === $inQuote) {
                    $inQuote = null;
                }
                continue;
            }

            if ($char === '\'' || $char === '"') {
                $inQuote = $char;
                continue;
            }

            if ($char === '(') {
                if ($depth === 0) {
                    $start = $i;
                }
                $depth++;
                continue;
            }

            if ($char === ')') {
                $depth--;
                if ($depth === 0 && $start !== null) {
                    $rows[] = substr($valuesSql, $start, $i - $start + 1);
                    $start = null;
                } elseif ($depth < 0) {
                    return null;
                }
            }
        }

        if ($depth !== 0 || $inQuote !== null) {
            return null;
        }

        return $rows;
    }

    /**
     * Confirm that DB2 stores exactly the expected image list for a post.
     *
     * @param int    $postId
     * @param string $expectedList
     * @return bool
     */
    private function db2_image_list_matches(int $postId, string $expectedList): bool {
        $expected = array_values(array_filter(
            array_map('trim', explode('|', rtrim(trim($expectedList), '|'))),
            static fn(string $value): bool => $value !== ''
        ));

        if ($postId <= 0 || empty($expected)) {
            return false;
        }

        if (!function_exists('fifu_db2_manager')) {
            return false;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return false;
        }

        try {
            $rows = $manager->getPostMappings($postId, 'image');
        } catch (\Throwable $e) {
            return false;
        }

        if (!is_array($rows) || empty($rows)) {
            return false;
        }

        usort(
            $rows,
            static fn(array $a, array $b): int => ($a['key_index'] ?? 0) <=> ($b['key_index'] ?? 0)
        );

        $actual = [];
        foreach ($rows as $row) {
            $url = trim((string) ($row['url'] ?? ''));
            if ($url === '') {
                continue;
            }

            $actual[] = $url;
        }

        return $actual === $expected;
    }

}
