<?php

declare(strict_types=1);

defined('ABSPATH') || exit;

/**
 * Repository for managing FIFU MD5 URL cache entries in DB2.
 */
class Fifu_Db2_Md5_Repository {

    /** @var wpdb */
    private wpdb $wpdb;

    /** @var string */
    private string $table_md5;

    public function __construct(?wpdb $wpdb_instance = null) {
        $this->wpdb = $wpdb_instance ?? $GLOBALS['wpdb'];
        $this->table_md5 = $this->wpdb->prefix . 'fifu_md5';
    }

    /**
     * Find a thumbnail ID by original URL.
     *
     * @param string $url
     * @return int|null
     */
    public function find_thumbnail_id_by_url(string $url): ?int {
        $md5 = md5($url);
        $sql = $this->wpdb->prepare(
            "SELECT thumbnail_id FROM {$this->table_md5} WHERE md5 = %s",
            $md5
        );
        $result = $this->wpdb->get_row($sql);
        return $result ? (int) $result->thumbnail_id : null;
    }

    public function insert_mapping(string $url, int $thumbnail_id): void {
        if ($this->find_thumbnail_id_by_url($url)) {
            return;
        }

        $md5 = md5($url);
        $this->wpdb->query(
            $this->wpdb->prepare(
                "INSERT INTO {$this->table_md5} (md5, thumbnail_id) VALUES (%s, %d)",
                $md5,
                $thumbnail_id
            )
        );
    }

    public function delete_by_thumbnail_id(int $thumbnail_id): void {
        $this->wpdb->query(
            $this->wpdb->prepare(
                "DELETE FROM {$this->table_md5} WHERE thumbnail_id = %d",
                $thumbnail_id
            )
        );
    }
}
