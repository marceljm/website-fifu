=== Featured Image from URL (FIFU) Premium ===
Requires at least: 5.6
Tested up to: 7.2
Requires PHP: 8.1
Stable tag: 8.3.4
WC requires at least: 4.0
WC tested up to: 11.2.1

== Broken Link Checker ==

Broken Link Checker checks featured image URLs in the background when a theme requests the image. It retries failed checks after 24 hours and lists links that fail three daily checks in the Link Checker settings.

Enable or disable it from the Link Checker settings, or run `wp fifu image --validate-featured-image-urls=<on|off>`.
