<?php

declare( strict_types=1 );

defined( 'ABSPATH' ) || exit;

/**
 * Fifu_Meta_Box_Php_Strings.
 *
 * @package Fifu_Premium
 */
class Fifu_Meta_Box_Php_Strings {

    /**
     * @return array<string, mixed>
     */
    public static function get_strings(): array {
        $fifu = array();

        // common
        $fifu['common']['wait'] = function () {
            return __("Please wait...", FIFU_SLUG);
        };
        $fifu['common']['updating_featured_image'] = function () {
            return __("Updating featured image...", FIFU_SLUG);
        };
        $fifu['common']['image'] = function () {
            return __("Image URL", FIFU_SLUG);
        };
        $fifu['common']['video'] = function () {
            return __("Video URL", FIFU_SLUG);
        };
        $fifu['common']['alt'] = function () {
            return __("Alternative text", FIFU_SLUG);
        };
        $fifu['common']['media_type'] = function () {
            return __("Media type", FIFU_SLUG);
        };

        // wait
        $fifu['title']['product']['image'] = function () {
            return __("Product image", FIFU_SLUG);
        };
        $fifu['title']['product']['images'] = function () {
            return __("Image gallery", FIFU_SLUG);
        };
        $fifu['title']['product']['gallery'] = function () {
            return __("Image/video gallery", FIFU_SLUG);
        };
        $fifu['title']['product']['video'] = function () {
            return __("Featured video", FIFU_SLUG);
        };
        $fifu['title']['product']['videos'] = function () {
            return __("Video gallery", FIFU_SLUG);
        };
        $fifu['title']['product']['slider'] = function () {
            return __("Featured slider", FIFU_SLUG);
        };
        $fifu['title']['post']['image'] = function () {
            return __("Featured image", FIFU_SLUG);
        };
        $fifu['title']['post']['video'] = function () {
            return __("Featured video", FIFU_SLUG);
        };
        $fifu['title']['post']['slider'] = function () {
            return __("Featured slider", FIFU_SLUG);
        };
        $fifu['title']['post']['asin'] = function () {
            return __("ASIN", FIFU_SLUG);
        };
        $fifu['title']['post']['finder'] = function () {
            return __("Media finder", FIFU_SLUG);
        };
        $fifu['title']['post']['audio'] = function () {
            return __("Featured audio", FIFU_SLUG);
        };
        $fifu['title']['post']['redirection'] = function () {
            return __("Page redirection", FIFU_SLUG);
        };
        $fifu['title']['post']['popup'] = function () {
            return __("Custom popup", FIFU_SLUG);
        };

        // variation
        $fifu['variation']['new']['upload'] = function () {
            return __("Upload to media library", FIFU_SLUG);
        };
        $fifu['variation']['new']['images'] = function () {
            return __("Images", FIFU_SLUG);
        };
        $fifu['variation']['new']['help'] = function () {
            return __("The first slot is for the featured image, and the others are for the image gallery.", FIFU_SLUG);
        };

        return $fifu;
    }
}
