<?php

declare( strict_types=1 );

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/class-fifu-settings-strings.php';
require_once __DIR__ . '/class-fifu-meta-box-strings.php';

/**
 * Façade for admin UI strings.
 *
 * @package Fifu_Premium
 */
class Fifu_Admin_Strings {

    /**
     * Return the complete settings strings payload handled by the legacy loader.
     *
     * @return array<string, mixed>
     */
    public static function get_settings_strings(): array {
        $fifu = array();

        // description (not used)
        $fifu['plugins']['description'] = function () {
            return __("Add remote featured images and WooCommerce product images from external URLs. Save storage, speed up imports, and use featured videos with FIFU PRO.", FIFU_SLUG);
        };

        // options
        $fifu['options'] = Fifu_Settings_Strings::get_option_labels();

        // php
        $fifu['php']['message']['wait'] = function () {
            return __("Please wait a few seconds...", FIFU_SLUG);
        };
        $fifu['php']['message']['wait1'] = function () {
            return __("Please wait 1 minute...", FIFU_SLUG);
        };

        // buttons
        $fifu['button']['submit'] = function () {
            _e("Submit", FIFU_SLUG);
        };
        $fifu['button']['clipboard'] = function () {
            _e("Copy to clipboard", FIFU_SLUG);
        };

        // details
        $fifu['detail']['important'] = function () {
            _e("Important", FIFU_SLUG);
        };
        $fifu['detail']['requirement'] = function () {
            _e("Requirement", FIFU_SLUG);
        };
        $fifu['detail']['tip'] = function () {
            _e("Tip", FIFU_SLUG);
        };
        $fifu['detail']['example'] = function () {
            _e("Example", FIFU_SLUG);
        };
        $fifu['detail']['eg'] = function () {
            _e("e.g.:", FIFU_SLUG);
        };
        $fifu['detail']['result'] = function () {
            _e("Result", FIFU_SLUG);
        };
        $fifu['detail']['notice'] = function () {
            _e("Note", FIFU_SLUG);
        };
        $fifu['detail']['developers'] = function () {
            _e("Developers", FIFU_SLUG);
        };

        // words
        $fifu['word']['color'] = function () {
            _e("color", FIFU_SLUG);
        };
        $fifu['word']['mode'] = function () {
            _e("mode", FIFU_SLUG);
        };
        $fifu['word']['inline'] = function () {
            _e("inline", FIFU_SLUG);
        };
        $fifu['word']['lightbox'] = function () {
            _e("lightbox", FIFU_SLUG);
        };
        $fifu['word']['zindex'] = function () {
            _e("z-index", FIFU_SLUG);
        };
        $fifu['word']['size'] = function () {
            _e("size", FIFU_SLUG);
        };
        $fifu['word']['zoom'] = function () {
            _e("zoom", FIFU_SLUG);
        };
        $fifu['word']['function'] = function () {
            _e("Function", FIFU_SLUG);
        };
        $fifu['word']['field'] = function () {
            _e("Fields", FIFU_SLUG);
        };
        $fifu['word']['delimiter'] = function () {
            _e("Delimiter", FIFU_SLUG);
        };
        $fifu['word']['pro'] = function () {
            _e("PRO", FIFU_SLUG);
        };
        $fifu['word']['yes'] = function () {
            _e("yes", FIFU_SLUG);
        };
        $fifu['word']['no'] = function () {
            _e("no", FIFU_SLUG);
        };
        $fifu['word']['local'] = function () {
            _e("Local", FIFU_SLUG);
        };
        $fifu['word']['external'] = function () {
            _e("Remote", FIFU_SLUG);
        };
        $fifu['word']['status'] = function () {
            _e("Status", FIFU_SLUG);
        };
        $fifu['word']['name'] = function () {
            _e("Name", FIFU_SLUG);
        };
        $fifu['word']['type'] = function () {
            _e("Type", FIFU_SLUG);
        };
        $fifu['word']['data'] = function () {
            _e("Data", FIFU_SLUG);
        };
        $fifu['word']['option'] = function () {
            _e("Option", FIFU_SLUG);
        };
        $fifu['word']['description'] = function () {
            _e("Description", FIFU_SLUG);
        };
        $fifu['word']['width'] = function () {
            _e("Width", FIFU_SLUG);
        };
        $fifu['word']['height'] = function () {
            _e("Height", FIFU_SLUG);
        };
        $fifu['word']['crop'] = function () {
            _e("Crop", FIFU_SLUG);
        };
        $fifu['word']['pages'] = function () {
            _e("Pages", FIFU_SLUG);
        };
        $fifu['word']['saving'] = function () {
            return __("Saving", FIFU_SLUG);
        };
        $fifu['word']['saved'] = function () {
            return __("Saved", FIFU_SLUG);
        };
        $fifu['word']['error'] = function () {
            return __("Error", FIFU_SLUG);
        };
        $fifu['word']['reset'] = function () {
            return __("Reset", FIFU_SLUG);
        };
        $fifu['word']['save'] = function () {
            return __("Save", FIFU_SLUG);
        };

        // where
        $fifu['where']['page'] = function () {
            _e("on other pages", FIFU_SLUG);
        };
        $fifu['where']['post'] = function () {
            _e("on posts ", FIFU_SLUG);
        };
        $fifu['where']['cpt'] = function () {
            _e("on custom post types", FIFU_SLUG);
        };
        $fifu['where']['home'] = function () {
            _e("on homepage", FIFU_SLUG);
        };
        $fifu['where']['else'] = function () {
            _e("elsewhere", FIFU_SLUG);
        };
        $fifu['where']['single'] = function () {
            _e("on single post types", FIFU_SLUG);
        };
        $fifu['where']['desktop'] = function () {
            _e("on desktop", FIFU_SLUG);
        };
        $fifu['where']['mobile'] = function () {
            _e("on mobile phone", FIFU_SLUG);
        };

        // player
        $fifu['player']['available']['for'] = function () {
            _e("Available for", FIFU_SLUG);
        };
        $fifu['player']['available']['mouse'] = function () {
            _e("YouTube, Vimeo, local videos, remote video files", FIFU_SLUG);
        };
        $fifu['player']['available']['autoplay'] = function () {
            _e("YouTube, Vimeo, Odysee, Rumble, local videos, remote video files", FIFU_SLUG);
        };
        $fifu['player']['available']['loop'] = function () {
            _e("YouTube, Vimeo, local videos, remote video files", FIFU_SLUG);
        };
        $fifu['player']['available']['mute'] = function () {
            _e("Videos", FIFU_SLUG);
        };
        $fifu['player']['available']['background'] = function () {
            _e("Vimeo", FIFU_SLUG);
        };
        $fifu['player']['available']['privacy'] = function () {
            _e("YouTube", FIFU_SLUG);
        };

        // chrome
        $fifu['chrome']['link'] = function () {
            _e("Chrome extension", FIFU_SLUG);
        };
        $fifu['server']['details'] = function () {
            _e("Async requests from the FIFU server to your site may be used to split data processing into parts, avoiding execution timeouts on slower tasks and excessive memory usage on larger tasks. They also bypass the lack of a real cron system in WordPress, keeping some automatic features running even when the site is not receiving visitors.", FIFU_SLUG);
        };
        $fifu['server']['success'] = function () {
            return __("Test connection with the FIFU server completed successfully.", FIFU_SLUG);
        };
        $fifu['server']['fail'] = function () {
            return __("Test connection with the FIFU server failed. If you are using a firewall, please allow FIFU requests.", FIFU_SLUG);
        };
        $fifu['key']['success']['main'] = function () {
            return __("Your license key was successfully registered.", FIFU_SLUG);
        };
        $fifu['key']['expired']['main'] = function () {
            return __("Your license key has expired.", FIFU_SLUG);
        };
        $fifu['key']['invalid']['main'] = function () {
            return __("Your license key is invalid.", FIFU_SLUG);
        };
        $fifu['key']['success']['details'] = function () {
            return __("FIFU is now fully activated, and all features are unlocked.", FIFU_SLUG);
        };
        $fifu['key']['expired']['details'] = function () {
            return __("Please renew or upgrade it to continue receiving updates and support.", FIFU_SLUG);
        };
        $fifu['key']['invalid']['details'] = function () {
            return __("Please check the key and try again, or contact support for assistance. A valid license key is required for the plugin to work correctly and without limitations.", FIFU_SLUG);
        };

        // messages
        $fifu['message'] = Fifu_Settings_Strings::get_messages();

        // tabs
        $fifu['tab'] = Fifu_Settings_Strings::get_tab_labels();

        // titles
        $fifu['title']['support'] = function () {
            _e("Technical support", FIFU_SLUG);
        };
        $fifu['title']['start'] = function () {
            _e("Getting started", FIFU_SLUG);
        };
        $fifu['title']['reset'] = function () {
            _e("Reset Settings", FIFU_SLUG);
        };
        $fifu['title']['media'] = function () {
            _e("Save in the Media Library", FIFU_SLUG);
        };
        $fifu['title']['auto'] = function () {
            _e("Auto set featured image using post title and search engine", FIFU_SLUG);
        };
        $fifu['title']['asin'] = function () {
            _e("Auto set product images from ASIN", FIFU_SLUG);
        };
        $fifu['title']['customfield'] = function () {
            _e("Auto set featured media from custom field", FIFU_SLUG);
        };
        $fifu['title']['screenshot'] = function () {
            _e("Auto set screenshot as featured image", FIFU_SLUG);
        };
        $fifu['title']['finder'] = function () {
            _e("Auto set featured media using web page address", FIFU_SLUG);
        };
        $fifu['title']['share'] = function () {
            _e("Auto-share on social media", FIFU_SLUG);
        };
        $fifu['title']['block'] = function () {
            _e("Disable right-click", FIFU_SLUG);
        };
        $fifu['title']['replace'] = function () {
            _e("Replace Not Found Image", FIFU_SLUG);
        };
        $fifu['title']['link_checker'] = function () {
            _e("Broken Link Checker", FIFU_SLUG);
        };
        $fifu['link_checker']['desc'] = function () {
            _e("Check featured image URLs and flag broken links.", FIFU_SLUG);
        };
        $fifu['link_checker']['tab']['settings'] = function () {
            _e("Settings", FIFU_SLUG);
        };
        $fifu['link_checker']['tab']['broken-links'] = function () {
            _e("Broken Links", FIFU_SLUG);
        };
        $fifu['broken-links']['desc'] = function () {
            _e("Posts with broken featured image links will be listed below. Select a post to open its editor.", FIFU_SLUG);
        };
        $fifu['broken-links']['post'] = function () {
            _e("Post", FIFU_SLUG);
        };
        $fifu['broken-links']['url'] = function () {
            _e("Broken Image URL", FIFU_SLUG);
        };
        $fifu['title']['default'] = function () {
            _e("Default Featured Image", FIFU_SLUG);
        };
        $fifu['title']['pcontent'] = function () {
            _e("Modify Post Content", FIFU_SLUG);
        };
        $fifu['title']['hide'] = function () {
            _e("Hide Featured Media", FIFU_SLUG);
        };
        $fifu['title']['popup'] = function () {
            _e("Custom Popup", FIFU_SLUG);
        };
        $fifu['title']['redirection'] = function () {
            _e("Page Redirection", FIFU_SLUG);
        };
        $fifu['title']['html'] = function () {
            _e("Auto set featured media from post content", FIFU_SLUG);
        };
        $fifu['title']['metadata'] = function () {
            _e("Image Metadata", FIFU_SLUG);
        };
        $fifu['title']['clean'] = function () {
            _e("Clear Metadata", FIFU_SLUG);
        };
        $fifu['title']['schedule'] = function () {
            _e("Schedule Metadata Generation", FIFU_SLUG);
        };
        $fifu['title']['delete'] = function () {
            _e("Delete All URLs", FIFU_SLUG);
        };
        $fifu['title']['audio'] = function () {
            _e("Featured audio", FIFU_SLUG);
        };
        $fifu['title']['debug'] = function () {
            _e("Debug Mode", FIFU_SLUG);
        };
        $fifu['title']['jetpack'] = function () {
            _e("Optimized Images", FIFU_SLUG);
        };
        $fifu['title']['api'] = function () {
            _e("WP / WooCommerce REST API", FIFU_SLUG);
        };
        $fifu['title']['shortcodes'] = function () {
            _e("FIFU Shortcode", FIFU_SLUG);
        };
        $fifu['title']['slider'] = function () {
            _e("Featured Slider", FIFU_SLUG);
        };
        $fifu['title']['bbpress'] = function () {
            _e("bbPress and BuddyBoss Platform", FIFU_SLUG);
        };
        $fifu['title']['taxonomy'] = function () {
            _e("Taxonomy Image", FIFU_SLUG);
        };
        $fifu['title']['video'] = function () {
            _e("Featured Video / Audio", FIFU_SLUG);
        };
        $fifu['title']['thumbnail'] = function () {
            _e("Video Thumbnail", FIFU_SLUG);
        };
        $fifu['title']['play'] = function () {
            _e("Play Button", FIFU_SLUG);
        };
        $fifu['title']['width'] = function () {
            _e("Minimum Width", FIFU_SLUG);
        };
        $fifu['title']['controls'] = function () {
            _e("Video Controls", FIFU_SLUG);
        };
        $fifu['title']['mouseover'] = function () {
            _e("Autoplay on Mouseover", FIFU_SLUG);
        };
        $fifu['title']['autoplay'] = function () {
            _e("Autoplay", FIFU_SLUG);
        };
        $fifu['title']['loop'] = function () {
            _e("Playback Loop", FIFU_SLUG);
        };
        $fifu['title']['mute'] = function () {
            _e("Mute", FIFU_SLUG);
        };
        $fifu['title']['background'] = function () {
            _e("Background Video", FIFU_SLUG);
        };
        $fifu['title']['vimeo-options'] = function () {
            _e("Vimeo options", FIFU_SLUG);
        };
        $fifu['title']['youtube-options'] = function () {
            _e("YouTube options", FIFU_SLUG);
        };
        $fifu['title']['privacy'] = function () {
            _e("Privacy Enhanced Mode", FIFU_SLUG);
        };
        $fifu['title']['later'] = function () {
            _e("Watch Later", FIFU_SLUG);
        };
        $fifu['title']['zoom'] = function () {
            _e("Lightbox and Zoom", FIFU_SLUG);
        };
        $fifu['title']['category'] = function () {
            _e("Auto set category images", FIFU_SLUG);
        };
        $fifu['title']['order-email'] = function () {
            _e("Add image to order email", FIFU_SLUG);
        };
        $fifu['title']['import'] = function () {
            _e("Import", FIFU_SLUG);
        };
        $fifu['title']['addon'] = function () {
            _e("Add-On", FIFU_SLUG);
        };
        $fifu['title']['activation'] = function () {
            _e("Activation", FIFU_SLUG);
        };
        $fifu['title']['gallery'] = function () {
            _e("FIFU Product Gallery", FIFU_SLUG);
        };
        $fifu['title']['buy'] = function () {
            _e("Quick Buy", FIFU_SLUG);
        };

        $fifu['vimeo']['mp4-desc'] = function () {
            _e("When an access token is provided, FIFU can use Vimeo MP4 video files instead of Vimeo streaming.", FIFU_SLUG);
        };
        $fifu['vimeo']['tab']['access-token'] = function () {
            _e("Access token", FIFU_SLUG);
        };
        $fifu['vimeo']['access-token'] = function () {
            _e("access token", FIFU_SLUG);
        };
        $fifu['vimeo']['tab']['resolution'] = function () {
            _e("Video resolution", FIFU_SLUG);
        };
        $fifu['vimeo']['mp4-rendition'] = function () {
            _e("preferred video resolution", FIFU_SLUG);
        };
        $fifu['vimeo']['mp4-resolution-desc'] = function () {
            _e("FIFU will use the selected MP4 resolution when available. If it is not available, FIFU will use the closest lower resolution, or the closest higher one if no lower file exists.", FIFU_SLUG);
        };
        $fifu['vimeo']['access-token-info'] = function () {
            _e("Required scopes: public, private, video_files.", FIFU_SLUG);
        };
        $fifu['vimeo']['access-token-help'] = function () {
            _e("How to generate a personal access token", FIFU_SLUG);
        };

        // help texts
        foreach ( Fifu_Settings_Strings::get_help_texts() as $key => $value ) {
            $fifu[ $key ] = $value;
        }

        // cli
        $fifu['cli']['desc'] = function () {
            _e("Configure FIFU via command line.", FIFU_SLUG);
        };
        $fifu['cli']['tab']['commands'] = function () {
            _e("FIFU commands", FIFU_SLUG);
        };
        $fifu['cli']['tab']['fields'] = function () {
            _e("FIFU custom fields", FIFU_SLUG);
        };
        $fifu['cli']['documentation']['site'] = function () {
            _e("WP-CLI", FIFU_SLUG);
        };
        $fifu['cli']['fields']['create'] = function () {
            _e("Create a post", FIFU_SLUG);
        };
        $fifu['cli']['fields']['api'] = function () {
            _e("Other custom fields can be found under Settings → Developers → REST API → Custom fields.", FIFU_SLUG);
        };
        $fifu['cli']['column']['tab'] = function () {
            _e("Tab", FIFU_SLUG);
        };
        $fifu['cli']['column']['section'] = function () {
            _e("Section", FIFU_SLUG);
        };
        $fifu['cli']['column']['feature'] = function () {
            _e("Feature", FIFU_SLUG);
        };
        $fifu['cli']['column']['option'] = function () {
            _e("Option", FIFU_SLUG);
        };
        $fifu['cli']['column']['command'] = function () {
            _e("Command", FIFU_SLUG);
        };
        $fifu['cli']['column']['eg'] = function () {
            _e("e.g. (args)", FIFU_SLUG);
        };
        $fifu['cli']['column']['action'] = function () {
            _e("Action", FIFU_SLUG);
        };
        $fifu['cli']['column']['example'] = function () {
            _e("Command example", FIFU_SLUG);
        };

        // reset
        $fifu['reset']['desc'] = function () {
            _e("Reset FIFU settings to the default values.", FIFU_SLUG);
        };
        $fifu['reset']['reset'] = function () {
            _e("reset settings", FIFU_SLUG);
        };

        // media library
        $fifu['media']['desc'] = function () {
            _e("It's possible to save remote images in the media library and automatically set them as featured images or gallery images. Make a backup before running the scheduled event, as making an image local cannot be reverted.", FIFU_SLUG);
        };
        $fifu['media']['upload'] = function () {
            _e("show save button on post editor", FIFU_SLUG);
        };
        $fifu['media']['job'] = function () {
            _e("run a function that periodically searches for remote images and saves them in the media library.", FIFU_SLUG);
        };
        $fifu['media']['tab']['main'] = function () {
            _e("Main", FIFU_SLUG);
        };
        $fifu['media']['tab']['domain'] = function () {
            _e("Filter by domain", FIFU_SLUG);
        };
        $fifu['media']['tab']['proxy'] = function () {
            _e("Proxy", FIFU_SLUG);
        };
        $fifu['media']['proxy']['desc'] = function () {
            _e("Proxies are utilized to bypass IP bans that can occur when your site downloads a large number of images from the same host. However, using proxies has certain disadvantages. A proxy can impose limitations on the number of requests, and its IP address may also get banned. In such cases, the plugin will attempt to find alternative proxies until it discovers a functional one. Consequently, the use of proxies can potentially slow down the process, unless you have access to a private proxy. By default, FIFU plugin incorporates a list of public proxies that are updated every 30 minutes. The plugin also caches the proxies that are working correctly with your image URLs.", FIFU_SLUG);
        };
        $fifu['media']['proxy']['toggle'] = function () {
            _e("use proxies to intermediate the traffic between your site and the image hosts", FIFU_SLUG);
        };
        $fifu['media']['proxy']['private'] = function () {
            _e("Private proxy", FIFU_SLUG);
        };
        $fifu['media']['proxy']['placeholder'] = function () {
            _e("192.168.0.1:80, 127.0.0.1:8080, username:password@172.16.0.0:443", FIFU_SLUG);
        };
        $fifu['media']['domain']['desc'] = function () {
            _e("Only save images from specific domains.", FIFU_SLUG);
        };

        // auto set
        $fifu['auto']['desc'] = function () {
            _e("Set featured images automatically. The plugin checks every minute for post types without featured images and performs web searches based on post titles to retrieve the image URLs (1 per minute).", FIFU_SLUG);
        };
        $fifu['auto']['important2'] = function () {
            _e("Don't restrict the search too much. Because depending on the post title and the filters applied, the search engine might return an image that's not very relevant, or even no image. A quick and easy way to test if the search engine has relevant images for the applied filters is by accessing the post editor or FIFU quick editor and performing a search with the 'Keywords' field empty. A list of the top images based on the post's title will be displayed.", FIFU_SLUG);
        };
        $fifu['auto']['tab']['auto'] = function () {
            _e("Auto set", FIFU_SLUG);
        };
        $fifu['auto']['tab']['search'] = function () {
            _e("Search filters", FIFU_SLUG);
        };
        $fifu['auto']['tab']['credits'] = function () {
            _e("Credits", FIFU_SLUG);
        };
        $fifu['auto']['tab']['filters'] = function () {
            _e("Filter by size", FIFU_SLUG);
        };
        $fifu['auto']['tab']['blocklist'] = function () {
            _e("Blocklist", FIFU_SLUG);
        };
        $fifu['auto']['tab']['cpt'] = function () {
            _e("Post types", FIFU_SLUG);
        };
        $fifu['auto']['tab']['source'] = function () {
            _e("Filter by source", FIFU_SLUG);
        };
        $fifu['auto']['tab']['layout'] = function () {
            _e("Filter by layout", FIFU_SLUG);
        };
        $fifu['auto']['filter']['width'] = function () {
            _e("minimum width (px)", FIFU_SLUG);
        };
        $fifu['auto']['filter']['height'] = function () {
            _e("minimum height (px)", FIFU_SLUG);
        };
        $fifu['auto']['filter']['blocklist'] = function () {
            _e("List of prohibited strings in the image URL:", FIFU_SLUG);
        };
        $fifu['auto']['cpt']['desc'] = function () {
            _e("This feature is pre-configured to work only with the post type \"post.\" You can include more post types below (separated by commas).", FIFU_SLUG);
        };
        $fifu['auto']['cpt']['found'] = function () {
            _e("Post types found on your site:", FIFU_SLUG);
        };
        $fifu['auto']['source']['desc'] = function () {
            _e("Limit the search to one or more specific sites.", FIFU_SLUG);
        };
        $fifu['auto']['layout']['all'] = function () {
            _e("All", FIFU_SLUG);
        };
        $fifu['auto']['layout']['square'] = function () {
            _e("Square", FIFU_SLUG);
        };
        $fifu['auto']['layout']['tall'] = function () {
            _e("Tall", FIFU_SLUG);
        };
        $fifu['auto']['layout']['wide'] = function () {
            _e("Wide", FIFU_SLUG);
        };
        $fifu['auto']['credits']['desc'] = function () {
            _e("When FIFU imports an image URL from the search engine, it also retrieves the address of the remote post that owns the image. By enabling 'Settings → Image → Page Redirection', FIFU adds a link to the image when it’s displayed on singular posts of your site. Then, by clicking on the image, the visitor is redirected to the remote post. This is FIFU’s way of giving credit to the author, since the search engine may include copyrighted images in the results.
    ", FIFU_SLUG);
        };

        // auto share
        $fifu['share']['desc'] = function () {
            _e("Automatically share published posts when they are created or updated on WordPress to social media. The rate limit is 16 posts per day for each connected social media platform.", FIFU_SLUG);
        };
        $fifu['share']['tab']['auto'] = function () {
            _e("Auto share", FIFU_SLUG);
        };
        $fifu['share']['tab']['social'] = function () {
            _e("Social media", FIFU_SLUG);
        };
        $fifu['share']['tab']['test'] = function () {
            _e("Test", FIFU_SLUG);
        };
        $fifu['share']['window']['connect'] = function () {
            return __("Connecting", FIFU_SLUG);
        };
        $fifu['share']['label']['client'] = function () {
            _e("OAuth 2.0 Client ID", FIFU_SLUG);
        };
        $fifu['share']['label']['postid'] = function () {
            _e("Post ID", FIFU_SLUG);
        };
        $fifu['share']['button']['now'] = function () {
            _e("Share now", FIFU_SLUG);
        };
        $fifu['share']['info']['requirements'] = function () {
            return __("Requirements", FIFU_SLUG);
        };
        $fifu['share']['info']['facebook']['page'] = function () {
            return __("You need a Facebook Page; sharing to personal profiles is not supported.", FIFU_SLUG);
        };
        $fifu['share']['info']['facebook']['published'] = function () {
            return __("The Page must be Published and visible to everyone.", FIFU_SLUG);
        };
        $fifu['share']['info']['instagram']['professional'] = function () {
            return __("Use an Instagram Professional account (Business or Creator); personal accounts won’t work.", FIFU_SLUG);
        };
        $fifu['share']['info']['instagram']['public'] = function () {
            return __("The Instagram account must be Public (not private).", FIFU_SLUG);
        };
        $fifu['share']['info']['x']['developer'] = function () {
            return __("Create an app in the Developer Portal", FIFU_SLUG);
        };
        $fifu['share']['info']['x']['permissions'] = function () {
            return __("Set permissions to \"Read and write\".", FIFU_SLUG);
        };
        $fifu['share']['info']['x']['type'] = function () {
            return __("Choose the type of app: \"Native App\".", FIFU_SLUG);
        };
        $fifu['share']['info']['x']['callback'] = function () {
            return __("Add the callback URI", FIFU_SLUG);
        };
        $fifu['share']['info']['x']['client'] = function () {
            return __("Copy the \"Client ID\" from the \"Keys and tokens\" section.", FIFU_SLUG);
        };


        // asin
        $fifu['asin']['desc'] = function () {
            _e("Set product images automatically. The plugin checks every minute for post types without images and uses the ASIN and Amazon's Product Advertising API to retrieve the image URLs. For WooCommerce products, the URLs will be saved as the featured image and gallery, while for other post types, the URLs will be saved as a featured slider.", FIFU_SLUG);
        };
        $fifu['asin']['tab']['auto'] = function () {
            _e("Auto set", FIFU_SLUG);
        };
        $fifu['asin']['tab']['custom'] = function () {
            _e("Custom field", FIFU_SLUG);
        };
        $fifu['asin']['tab']['credentials'] = function () {
            _e("Credentials", FIFU_SLUG);
        };
        $fifu['asin']['custom']['desc'] = function () {
            _e("If you already have the ASIN saved in your database, specify its custom field name here. The plugin will access the field and import the value. For example, if the ASIN is saved in the SKU field, you can add \"_sku,\" which is the field where the SKU is stored.", FIFU_SLUG);
        };
        $fifu['asin']['label']['partner'] = function () {
            return _e("Partner tag", FIFU_SLUG);
        };
        $fifu['asin']['label']['access'] = function () {
            return _e("Access key", FIFU_SLUG);
        };
        $fifu['asin']['label']['secret'] = function () {
            return _e("Secret key", FIFU_SLUG);
        };
        $fifu['asin']['label']['locale'] = function () {
            return _e("Locale", FIFU_SLUG);
        };

        // customfield
        $fifu['customfield']['desc'] = function () {
            _e("Set featured media automatically. The plugin checks every minute for post types without featured images or videos and performs searches on the informed custom fields to retrieve the URLs. With that, you can integrate FIFU with any third-party plugin or theme that stores URLs in the database.", FIFU_SLUG);
        };
        $fifu['customfield']['prefix'] = function () {
            _e("Most users will simply add the custom field name, which is expected to contain an image or video URL. However, if all your URLs follow the same pattern, i.e., have the same prefix and suffix, you could add something like this into the field above: https://domain/{custom_field}.webp, where custom_field is some kind of ID instead of a URL.", FIFU_SLUG);
        };
        $fifu['customfield']['tab']['auto'] = function () {
            _e("Auto set", FIFU_SLUG);
        };
        $fifu['customfield']['tab']['custom'] = function () {
            _e("Custom field", FIFU_SLUG);
        };

        // screenshot
        $fifu['screenshot']['desc'] = function () {
            _e("To use a website screenshot as the featured image of a post, add \"https://screenshot.fifu.app/\" before the website address. Then use this new address as the image URL. For example, if you want the screenshot of the website \"https://openai.com/\" as the featured image of a post, your image URL should be: https://screenshot.fifu.app/https://openai.com/", FIFU_SLUG);
        };
        $fifu['screenshot']['desc3'] = function () {
            _e("If the GIF \"Generating Preview\" appears, ignore it. It means the screenshot was not found in the cache but is being generated on the server. You can save the post and exit the editor. The screenshot will be ready in a few seconds. Refresh the page.", FIFU_SLUG);
        };
        $fifu['screenshot']['custom']['desc'] = function () {
            _e("If you have the web page address saved in your database, please specify its custom field name here. The plugin will access the field, generate the screenshot URL, and set that as the featured image automatically.", FIFU_SLUG);
        };
        $fifu['screenshot']['tab']['auto'] = function () {
            _e("Auto set", FIFU_SLUG);
        };
        $fifu['screenshot']['tab']['custom'] = function () {
            _e("Custom field", FIFU_SLUG);
        };
        $fifu['screenshot']['tab']['size'] = function () {
            _e("Size", FIFU_SLUG);
        };

        // find
        $fifu['finder']['desc'] = function () {
            _e("Automatically defines featured media using images found on remote web pages. The plugin checks every minute for post types without featured media and accesses the provided web page URLs to retrieve the main image. FIFU looks for the Open Graph tag image (used for sharing on social media). If og:image is not found, it retrieves the largest image available. It can also search for embedded videos and set the first one found as the featured video.", FIFU_SLUG);
        };
        $fifu['finder']['auto'] = function () {
            _e("auto set featured media using web page address", FIFU_SLUG);
        };
        $fifu['finder']['video'] = function () {
            _e("look for embedded videos", FIFU_SLUG);
        };
        $fifu['finder']['tab']['auto'] = function () {
            _e("Auto set", FIFU_SLUG);
        };
        $fifu['finder']['tab']['custom'] = function () {
            _e("Custom field", FIFU_SLUG);
        };
        $fifu['finder']['amazon']['gallery'] = function () {
            _e("set images and videos to the product gallery", FIFU_SLUG);
        };
        $fifu['finder']['custom']['desc'] = function () {
            _e("If you already have the web page address saved in your database, specify its custom field name here. The plugin will access the field and import the value. For example, if the web page URL is saved in the Product URL field, you can add \"_product_url,\" which is the field where the remote URL to the product is stored. For posts created by WP Automatic plugin, add \"original_link\".", FIFU_SLUG);
        };

        // block
        $fifu['block']['desc'] = function () {
            _e("Disable right-click on all images.", FIFU_SLUG);
        };

        // popup
        $fifu['popup']['desc'] = function () {
            _e("Adds a new field to the post editor where you can paste any embed code. Its content will be displayed in a popup when the visitor clicks on the featured image. Here's an example of a popup containing a TikTok embed code:", FIFU_SLUG);
        };

        // redirection
        $fifu['redirection']['desc'] = function () {
            _e("Adds a new field in the post editor where you can specify a forwarding URL. When accessing a post and clicking on the featured image, the user will be redirected to the specified address.", FIFU_SLUG);
        };

        // replace
        $fifu['replace']['desc'] = function () {
            _e("Define the URL of an image to be displayed in case of an image not found error.", FIFU_SLUG);
        };

        // default
        $fifu['default']['desc'] = function () {
            _e("Define the URL of a default image to be displayed when you create or update a post without a featured image.", FIFU_SLUG);
        };
        $fifu['default']['tab']['url'] = function () {
            _e("Default featured image", FIFU_SLUG);
        };
        $fifu['default']['tab']['cpt'] = function () {
            _e("Filter by post type", FIFU_SLUG);
        };
        $fifu['default']['cpt']['found'] = function () {
            _e("Post types found on your site:", FIFU_SLUG);
        };
        $fifu['default']['cpt']['info'] = function () {
            _e("After adding or removing a post type, you need to restart the feature by disabling and enabling the toggle below.", FIFU_SLUG);
        };
        $fifu['default']['placeholder']['url'] = function () {
            _e("Image URL", FIFU_SLUG);
        };

        // pcontent
        $fifu['pcontent']['desc'] = function () {
            _e("Post content refers to the main body of text within a post. It comes after the post title and doesn't include the featured media (image or video). However, with this feature, you can add the featured media to the top of the content, which may be useful when the theme doesn't render the featured media on single posts. You can also remove media from the content, which is useful when the same media is defined as the featured media, causing unwanted duplication. These changes are dynamic, happening only on page load, so they won't change the database and can be easily undone.", FIFU_SLUG);
        };
        $fifu['pcontent']['tab']['modify'] = function () {
            _e("Modify post content", FIFU_SLUG);
        };
        $fifu['pcontent']['tab']['type'] = function () {
            _e("Filter by post type", FIFU_SLUG);
        };
        $fifu['pcontent']['option']['add'] = function () {
            _e("add missing media", FIFU_SLUG);
        };
        $fifu['pcontent']['option']['remove'] = function () {
            _e("remove duplicated media", FIFU_SLUG);
        };
        $fifu['pcontent']['type']['found'] = function () {
            _e("Apply the feature to specific post types:", FIFU_SLUG);
        };

        // hide
        $fifu['hide']['desc'] = function () {
            _e("Hide the featured media (image, video, or slider) on posts but keep its visibility on the homepage.", FIFU_SLUG);
        };
        $fifu['hide']['tab']['hide'] = function () {
            _e("Hide", FIFU_SLUG);
        };
        $fifu['hide']['tab']['cpt'] = function () {
            _e("Filter by post type", FIFU_SLUG);
        };
        $fifu['hide']['tab']['format'] = function () {
            _e("Filter by post format", FIFU_SLUG);
        };
        $fifu['hide']['type']['apply'] = function () {
            _e("Apply the feature to specific post formats:  ", FIFU_SLUG);
        };
        $fifu['hide']['format']['found'] = function () {
            _e("Post formats found on your site:", FIFU_SLUG);
        };

        // configuration
        $fifu['html']['desc'] = function () {
            _e("Set featured media automatically. The plugin reads the HTML of your post content and uses the first image or video found as the featured media when the post is created or updated.", FIFU_SLUG);
        };
        $fifu['html']['tab']['auto'] = function () {
            _e("Auto set", FIFU_SLUG);
        };
        $fifu['html']['tab']['all'] = function () {
            _e("Run it for all posts", FIFU_SLUG);
        };
        $fifu['html']['tab']['source'] = function () {
            _e("Filter by source", FIFU_SLUG);
        };
        $fifu['html']['tab']['type'] = function () {
            _e("Filter by post type", FIFU_SLUG);
        };
        $fifu['html']['tab']['media'] = function () {
            _e("Filter by media type", FIFU_SLUG);
        };
        $fifu['html']['first'] = function () {
            _e("auto set featured media from post content", FIFU_SLUG);
        };
        $fifu['html']['overwrite'] = function () {
            _e("overwrite the existing featured media", FIFU_SLUG);
        };
        $fifu['html']['skip']['desc'] = function () {
        _e("Skip media tags containing these keywords:", FIFU_SLUG);
        };
        $fifu['html']['media']['image'] = function () {
            _e("Image", FIFU_SLUG);
        };
        $fifu['html']['media']['video'] = function () {
            _e("Video", FIFU_SLUG);
        };
        $fifu['html']['media']['all'] = function () {
            _e("All", FIFU_SLUG);
        };

        // all
        $fifu['all']['desc'] = function () {
            _e("Update all your posts applying the above configuration. To repeat the process, enable the toggle again.", FIFU_SLUG);
        };
        $fifu['all']['update'] = function () {
            _e("run it for each post, only once, and right now", FIFU_SLUG);
        };

        // metadata
        $fifu['metadata']['desc'] = function () {
            _e("Generate the necessary database records for WordPress components to work with remote images.", FIFU_SLUG);
        };
        $fifu['metadata']['generate'] = function () {
            _e("generate the missing metadata now", FIFU_SLUG);
        };

        // clear
        $fifu['clean']['desc'] = function () {
            _e("Clear the Image Metadata generated by FIFU, but not the URLs. Run this function if you intend to deactivate the plugin and use only local featured images again.", FIFU_SLUG);
        };
        $fifu['clean']['disabled'] = function () {
            _e("the toggle will be automatically disabled when finished", FIFU_SLUG);
        };

        // schedule
        $fifu['schedule']['desc'] = function () {
            _e("If you are setting the image URLs in a non-standard way, the images may not be displayed to visitors because additional metadata is required. Here, you can schedule an event to run every minute and check for image URLs without metadata and generate it.", FIFU_SLUG);
        };

        // delete
        $fifu['delete']['important'] = function () {
            _e("by default, this plugin doesn't save images in the media library. Enabling this toggle will remove all featured images from post types that have remote featured images, and this action cannot be undone. This also applies to FIFU galleries, videos, audios, and sliders.", FIFU_SLUG);
        };
        $fifu['delete']['now'] = function () {
            _e("delete all your URLs now", FIFU_SLUG);
        };
        $fifu['delete']['requirement'] = function () {
            _e("Requirement: Go to Plugins → Plugin Editor → Select plugin to edit → FIFU → Select. Then change the value of FIFU_DELETE_ALL_URLS from false to true.", FIFU_SLUG);
        };

        // jetpack
        $fifu['jetpack']['tab']['optimize'] = function () {
            _e("Optimize", FIFU_SLUG);
        };
        $fifu['jetpack']['tab']['sizes'] = function () {
            _e("Sizes", FIFU_SLUG);
        };
        $fifu['jetpack']['tab']['registered'] = function () {
            _e("Registered sizes", FIFU_SLUG);
        };
        $fifu['jetpack']['tab']['square'] = function () {
            _e("Make all images square", FIFU_SLUG);
        };
        $fifu['jetpack']['tab']['fifu'] = function () {
            _e("FIFU CDN", FIFU_SLUG);
        };
        $fifu['jetpack']['desc'] = function () {
            _e("Your remote images will be automatically optimized and served from a public CDN. In addition, the plugin will load the thumbnails in the exact size your site requires, further enhancing performance.", FIFU_SLUG);
        };
        $fifu['jetpack']['toggle']['cdn'] = function () {
            _e("optimize featured images", FIFU_SLUG);
        };
        $fifu['jetpack']['toggle']['content'] = function () {
            _e("optimize secondary images", FIFU_SLUG);
        };
        $fifu['jetpack']['toggle']['otfcdn'] = function () {
            _e("optimize images with FIFU CDN", FIFU_SLUG);
        };
        $fifu['jetpack']['toggle']['domain'] = function () {
            _e("use your site's domain", FIFU_SLUG);
        };
        $fifu['jetpack']['sizes']['desc'] = function () {
            _e("Registered sizes are predefined dimensions that themes and plugins create to display images, and the FIFU CDN reads these values to deliver remote images in the exact requested size.", FIFU_SLUG);
        };
        $fifu['jetpack']['sizes']['reset'] = function () {
            _e("The sizes listed here are automatically detected by FIFU as you navigate through your site's page types. If you need to reset the size values for any reason, simply browse your pages again or wait for your visitors to do so, and FIFU will detect and list them here once more.", FIFU_SLUG);
        };
        $fifu['jetpack']['square']['description'] = function () {
            _e("These options apply to images served by FIFU CDN or FIFU Cloud.", FIFU_SLUG);
        };
        $fifu['jetpack']['square']['details']['none'] = function () {
            _e("Does not make the images square and automatically applies the registered sizes.", FIFU_SLUG);
        };
        $fifu['jetpack']['square']['details']['crop'] = function () {
            _e("Cut off parts of the images to make them square.", FIFU_SLUG);
        };
        $fifu['jetpack']['square']['details']['extend'] = function () {
            _e("Adds empty space around the images to make them square.", FIFU_SLUG);
        };
        $fifu['jetpack']['square']['label']['desktop'] = function () {
            _e("Desktop computer", FIFU_SLUG);
        };
        $fifu['jetpack']['square']['label']['mobile'] = function () {
            _e("Mobile phone", FIFU_SLUG);
        };
        $fifu['jetpack']['square']['select']['crop'] = function () {
            _e("Make square by cropping", FIFU_SLUG);
        };
        $fifu['jetpack']['square']['select']['extend'] = function () {
            _e("Make square by extending", FIFU_SLUG);
        };
        $fifu['jetpack']['otfcdn']['desc'] = function () {
            _e("For a long time, optimized images relied solely on a public third-party CDN. While this approach offered cost advantages, it also introduced several challenges. Now, FIFU provides its own CDN, designed to achieve the following goals:", FIFU_SLUG);
        };
        $fifu['jetpack']['otfcdn']['goal']['domain'] = function () {
            _e("Serve remote images using your site's domain", FIFU_SLUG);
        };
        $fifu['jetpack']['otfcdn']['goal']['source'] = function () {
            _e("Support any image sources", FIFU_SLUG);
        };
        $fifu['jetpack']['otfcdn']['goal']['format'] = function () {
            _e("Render images in a modern and efficient web format (WebP)", FIFU_SLUG);
        };
        $fifu['jetpack']['otfcdn']['goal']['time'] = function () {
            _e("Retrieve cached images in under 100ms", FIFU_SLUG);
        };
        $fifu['jetpack']['otfcdn']['goal']['first'] = function () {
            _e("Provide first-request images in less than 1 second", FIFU_SLUG);
        };
        $fifu['jetpack']['otfcdn']['goal']['smart'] = function () {
            _e("Smartly crop images", FIFU_SLUG);
        };
        $fifu['jetpack']['otfcdn']['goal']['process'] = function () {
            _e("Expand image processing capabilities", FIFU_SLUG);
        };
        $fifu['jetpack']['otfcdn']['goal']['seo'] = function () {
            _e("Optimize image URLs for SEO", FIFU_SLUG);
        };
        $fifu['jetpack']['otfcdn']['goal']['replication'] = function () {
            _e("Enhance content replication", FIFU_SLUG);
        };
        $fifu['jetpack']['otfcdn']['goal']['regional'] = function () {
            _e("Improve regional availability", FIFU_SLUG);
        };
        $fifu['jetpack']['otfcdn']['goal']['cache'] = function () {
            _e("Enable cache purging", FIFU_SLUG);
        };
        $fifu['jetpack']['otfcdn']['goal']['support'] = function () {
            _e("Provide dedicated technical support", FIFU_SLUG);
        };
        $fifu['jetpack']['otfcdn']['goal']['replace'] = function () {
            _e("Seamlessly integrate with other features", FIFU_SLUG);
        };
        $fifu['jetpack']['otfcdn']['cost'] = function () {
            _e("Due to the costs associated with processing and delivering millions of images daily, this feature is not currently available in the free version of FIFU or on staging sites using the PRO version. However, a small fee may soon be introduced to ensure its sustainability. For PRO users, the FIFU CDN will initially work only on the production site, unless the key has expired.", FIFU_SLUG);
        };
        $fifu['jetpack']['otfcdn']['setup'] = function () {
            _e("To serve remote images with your site domain, simply create a DNS record for your domain with the following details:", FIFU_SLUG);
        };

        // debug
        $fifu['debug']['desc'] = function () {
            _e("When FIFU is in debug mode, JavaScript and CSS files are not cached.", FIFU_SLUG);
        };
        $fifu['debug']['tables'] = function () {
            _e("It also enables troubleshooting tools that help collect diagnostic data from posts, products, categories, and media records.", FIFU_SLUG);
        };

        // api
        $fifu['api']['tab']['endpoints'] = function () {
            _e("Endpoints", FIFU_SLUG);
        };
        $fifu['api']['tab']['custom'] = function () {
            _e("FIFU custom fields", FIFU_SLUG);
        };
        $fifu['api']['tab']['product'] = function () {
            _e("Creating your first product", FIFU_SLUG);
        };
        $fifu['api']['tab']['category'] = function () {
            _e("product category", FIFU_SLUG);
        };
        $fifu['api']['tab']['variable'] = function () {
            _e("variable product", FIFU_SLUG);
        };
        $fifu['api']['tab']['variation'] = function () {
            _e("product variation", FIFU_SLUG);
        };
        $fifu['api']['tab']['batch-product'] = function () {
            _e("batch of products", FIFU_SLUG);
        };
        $fifu['api']['tab']['batch-category'] = function () {
            _e("batch of categories", FIFU_SLUG);
        };
        $fifu['api']['tab']['post'] = function () {
            _e("WordPress post", FIFU_SLUG);
        };
        $fifu['api']['tab']['documentation'] = function () {
            _e("Documentation", FIFU_SLUG);
        };
        $fifu['api']['endpoint']['product'] = function () {
            _e("Product", FIFU_SLUG);
        };
        $fifu['api']['endpoint']['category'] = function () {
            _e("Product category", FIFU_SLUG);
        };
        $fifu['api']['endpoint']['variation'] = function () {
            _e("Product variation", FIFU_SLUG);
        };
        $fifu['api']['endpoint']['batch-product'] = function () {
            _e("Batch of products", FIFU_SLUG);
        };
        $fifu['api']['endpoint']['batch-category'] = function () {
            _e("Batch of categories", FIFU_SLUG);
        };
        $fifu['api']['endpoint']['post'] = function () {
            _e("WordPress post", FIFU_SLUG);
        };
        $fifu['api']['endpoint']['cpt'] = function () {
            _e("Custom post type", FIFU_SLUG);
        };
        $fifu['api']['custom']['image'] = function () {
            _e("URL of featured image", FIFU_SLUG);
        };
        $fifu['api']['custom']['title'] = function () {
            _e("Alternative text of featured image", FIFU_SLUG);
        };
        $fifu['api']['custom']['video'] = function () {
            _e("URL of featured video", FIFU_SLUG);
        };
        $fifu['api']['custom']['key'] = function () {
            _e("Key", FIFU_SLUG);
        };
        $fifu['api']['documentation']['wordpress'] = function () {
            _e("WordPress REST API", FIFU_SLUG);
        };
        $fifu['api']['documentation']['woocommerce'] = function () {
            _e("WooCommerce REST API", FIFU_SLUG);
        };

        // FIFU shortcodes
        $fifu['shortcodes']['desc'] = function () {
            _e("Add FIFU elements anywhere with a shortcode.", FIFU_SLUG);
        };
        $fifu['shortcodes']['tab']['shortcodes'] = function () {
            _e("Display media", FIFU_SLUG);
        };
        $fifu['shortcodes']['column']['shortcode'] = function () {
            _e("Shortcode", FIFU_SLUG);
        };
        $fifu['shortcodes']['column']['description'] = function () {
            _e("Description", FIFU_SLUG);
        };
        $fifu['shortcodes']['column']['optional'] = function () {
            _e("Optional parameters", FIFU_SLUG);
        };
        $fifu['shortcodes']['column']['required'] = function () {
            _e("Required parameters", FIFU_SLUG);
        };
        $fifu['shortcodes']['description']['fifu'] = function () {
            _e("Displays the featured image/video", FIFU_SLUG);
        };
        $fifu['shortcodes']['description']['slider'] = function () {
            _e("Displays the featured slider", FIFU_SLUG);
        };
        $fifu['shortcodes']['description']['gallery'] = function () {
            _e("Displays the product gallery", FIFU_SLUG);
        };
        $fifu['shortcodes']['description']['taxonomy'] = function () {
            _e("Displays the taxonomy image", FIFU_SLUG);
        };

        // slider
        $fifu['slider']['desc'] = function () {
            _e("This feature allows to have a slider of images and videos instead of a regular featured image. It is particularly useful for certain types of websites, such as real estate, and can handle a large number of high-resolution images with optimal performance.", FIFU_SLUG);
        };
        $fifu['slider']['tab']['configuration'] = function () {
            _e("Configuration", FIFU_SLUG);
        };
        $fifu['slider']['featured'] = function () {
            _e("Featured slider", FIFU_SLUG);
        };
        $fifu['slider']['pause'] = function () {
            _e("Pause autoplay on hover", FIFU_SLUG);
        };
        $fifu['slider']['buttons'] = function () {
            _e("Show previous/next buttons", FIFU_SLUG);
        };
        $fifu['slider']['start'] = function () {
            _e("Start autoplay automatically", FIFU_SLUG);
        };
        $fifu['slider']['click'] = function () {
            _e("Show gallery on click", FIFU_SLUG);
        };
        $fifu['slider']['thumb'] = function () {
            _e("Show thumbnail gallery", FIFU_SLUG);
        };
        $fifu['slider']['counter'] = function () {
            _e("Show counter", FIFU_SLUG);
        };
        $fifu['slider']['crop'] = function () {
            _e("Display images at the same height", FIFU_SLUG);
        };
        $fifu['slider']['single'] = function () {
            _e("Load slider on singular post types only", FIFU_SLUG);
        };
        $fifu['slider']['vertical'] = function () {
            _e("Vertical mode", FIFU_SLUG);
        };
        $fifu['slider']['time'] = function () {
            _e("Time between each transition (in ms)", FIFU_SLUG);
        };
        $fifu['slider']['duration'] = function () {
            _e("Transition duration (in ms)", FIFU_SLUG);
        };
        $fifu['slider']['left'] = function () {
            _e("Previous button", FIFU_SLUG);
        };
        $fifu['slider']['right'] = function () {
            _e("Next button", FIFU_SLUG);
        };
        $fifu['slider']['optional'] = function () {
            _e("Image URL (optional)", FIFU_SLUG);
        };

        // quick buy
        $fifu['buy']['enable'] = function () {
            _e("Quick buy", FIFU_SLUG);
        };
        $fifu['buy']['text']['text'] = function () {
            _e("Text button", FIFU_SLUG);
        };
        $fifu['buy']['disclaimer']['text'] = function () {
            _e("Disclaimer", FIFU_SLUG);
        };
        $fifu['buy']['cf']['text'] = function () {
            _e("Custom field", FIFU_SLUG);
        };
        $fifu['buy']['text']['placeholder'] = function () {
            _e("Buy now (optional)", FIFU_SLUG);
        };
        $fifu['buy']['disclaimer']['placeholder'] = function () {
            _e("Disclaimer (optional)", FIFU_SLUG);
        };
        $fifu['buy']['cf']['placeholder'] = function () {
            _e("Custom field name (optional)", FIFU_SLUG);
        };

        // bbpress
        $fifu['bbpress']['desc'] = function () {
            _e("Enable the addition of remote images to forums, topics, replies, and activities.", FIFU_SLUG);
        };

        // taxonomy
        $fifu['taxonomy']['desc'] = function () {
            _e("Enables the featured image field for taxonomies. It's automatically integrated with the 'Variation Swatches for WooCommerce' plugin. To display the image for taxonomies from different plugins or themes, use a shortcode like this:", FIFU_SLUG);
        };

        // video
        $fifu['video']['desc'] = function () {
            _e("FIFU supports videos and audios from YouTube, Vimeo, Twitter, 9GAG, Cloudinary, Tumblr, Publitio, JW Player, VideoPress, Sprout, Odysee, Rumble, Dailymotion, Cloudflare Stream, Bunny Stream, Amazon, BitChute, Brighteon, Google Drive, Spotify and SoundCloud. It also supports remote and local video files.", FIFU_SLUG);
        };
        $fifu['video']['tab']['video'] = function () {
            _e("Featured video / audio", FIFU_SLUG);
        };
        $fifu['video']['tab']['local'] = function () {
            _e("Video files", FIFU_SLUG);
        };
        $fifu['video']['local']['desc'] = function () {
            _e("It's possible to use videos from your media library as featured videos. However it's required to create a video thumbnail, that will be stored in your media library. For that, in the Feature video field, forward the video to a frame you like and click on \"set this frame as thumbnail\" button. Save the post and that's it.", FIFU_SLUG);
        };
        $fifu['video']['external']['desc'] = function () {
            _e("Remote videos are also supported, but a remote featured image (video thumbnail) must be set as well.", FIFU_SLUG);
        };
        $fifu['video']['external']['import'] = function () {
            _e("When using import plugins, add the URL of the thumbnail after the video URL, separated by a backslash. For example: 'video_url\image_url'.", FIFU_SLUG);
        };
        $fifu['video']['tip']['frame'] = function () {
            _e("Start at", FIFU_SLUG);
        };
        $fifu['video']['tip']['type'] = function () {
            _e("Supported types", FIFU_SLUG);
        };
        $fifu['video']['tip']['time'] = function () {
            _e("You can add #t=N to the end of the local or remote video URL, where N represents the number of seconds at which the video should start. The format #t=N,M is used to specify a frame where the video should stop as well.", FIFU_SLUG);
        };

        // thumbnail
        $fifu['thumbnail']['desc'] = function () {
            _e("Show the video thumbnail instead of the video itself. Thumbnails are images, so they load much faster than embedded videos.", FIFU_SLUG);
        };

        // play
        $fifu['play']['desc'] = function () {
            _e("Add a play button to the video thumbnail. When clicking on the button, the video will start (in inline or lightbox mode).", FIFU_SLUG);
        };
        $fifu['play']['hide'] = function () {
            _e("Hide from grid", FIFU_SLUG);
        };

        // width
        $fifu['width']['desc'] = function () {
            _e("Define a minimum width for a container to display a video. If the minimum width is not reached, the plugin automatically shows only the video thumbnail.", FIFU_SLUG);
        };

        // black
        $fifu['controls']['desc'] = function () {
            _e("You can disable video controls here.", FIFU_SLUG);
        };
        // mouseover
        $fifu['mouseover']['desc'] = function () {
            _e("Play a video on \"mouseover\" and pause on \"mouseout\". Requires \"Video Controls\" (except for video files) and \"Mute\".", FIFU_SLUG);
        };

        // autoplay
        $fifu['autoplay']['desc'] = function () {
            _e("Video autoplay based on viewport. Requires \"Mute\".", FIFU_SLUG);
        };
        $fifu['autoplay']['front_all'] = function () {
            _e(
                'play all homepage videos simultaneously',
                FIFU_SLUG
            );
        };

        // loop
        $fifu['loop']['desc'] = function () {
            _e("Looping video playback.", FIFU_SLUG);
        };

        // mute
        $fifu['mute']['desc'] = function () {
            _e("Start videos without audio.", FIFU_SLUG);
        };

        // background
        $fifu['background']['desc'] = function () {
            _e("These options are only for Vimeo videos.", FIFU_SLUG);
        };
        $fifu['background']['tab']['background'] = function () {
            _e("Background video", FIFU_SLUG);
        };
        $fifu['background']['tab']['mp4'] = function () {
            _e("mp4", FIFU_SLUG);
        };
        $fifu['background']['video-desc'] = function () {
            _e("Start videos in the background, meaning autoplay with no controls and no sound.", FIFU_SLUG);
        };
        $fifu['background']['video'] = function () {
            _e("background video", FIFU_SLUG);
        };
        $fifu['background']['single'] = function () {
            _e("on single post types only", FIFU_SLUG);
        };

        // privacy
        $fifu['privacy']['desc'] = function () {
            _e("These options are only for YouTube videos.", FIFU_SLUG);
        };
        $fifu['privacy']['label'] = function () {
            _e("privacy enhanced mode", FIFU_SLUG);
        };
        $fifu['privacy']['info'] = function () {
            _e("Prevents views of embedded YouTube content from affecting the viewer's browsing experience on YouTube.", FIFU_SLUG);
        };

        // watch later
        $fifu['later']['desc'] = function () {
            _e("Adds the Watch Later and Queue buttons.", FIFU_SLUG);
        };
        $fifu['later']['button']['add'] = function () {
            _e("watch later and queue buttons", FIFU_SLUG);
        };
        $fifu['later']['button']['left'] = function () {
            _e("move to left", FIFU_SLUG);
        };

        // zoom
        $fifu['zoom']['desc'] = function () {
            _e("Define whether lightbox and zoom should be applied to the image gallery.", FIFU_SLUG);
        };

        // category
        $fifu['category']['desc'] = function () {
            _e("Set one image for each category. The chosen image will be a random featured image from the products in that category.", FIFU_SLUG);
        };

        // gallery
        $fifu['gallery']['desc'] = function () {
            _e("To work correctly, some galleries provided by some themes require that the dimensions of the images are saved in the database, which can be impractical due to the slowness of this process. So the plugin offers its own product gallery that does not depend on the dimensions of remote images to function properly. You can configure the behavior of this gallery in the \"Featured slider\" tab.", FIFU_SLUG);
        };
        $fifu['gallery']['toggle'] = function () {
            _e("FIFU product gallery", FIFU_SLUG);
        };
        $fifu['gallery']['adaptive'] = function () {
            _e("Adaptive height", FIFU_SLUG);
        };
        $fifu['gallery']['videos'] = function () {
            _e("Videos before images", FIFU_SLUG);
        };
        $fifu['gallery']['variations'] = function () {
            _e("Variantions images in the main gallery", FIFU_SLUG);
        };
        $fifu['gallery']['tab']['custom'] = function () {
            _e("Custom content", FIFU_SLUG);
        };
        $fifu['gallery']['custom'] = function () {
            _e("The lightbox can display custom content instead of an image or video, such as a 360º product view, PDF, Google Map, web page, or any other content that can be rendered through an iframe tag. To set this up, go to the product editor, select a slot in the 'Image gallery,' and fill out both the 'Image URL' and 'iframe URL' fields.", FIFU_SLUG);
        };

        // buy
        $fifu['buy']['desc'] = function () {
            _e("This is a faster alternative to the WooCommerce product page. An icon added to each product on the grid opens a lightbox with the main product information and a 'Buy Now' button, which adds the product to the cart and redirects to the checkout page.", FIFU_SLUG);
        };

        // order email
        $fifu['order-email']['desc'] = function () {
            _e("Add product images to order emails.", FIFU_SLUG);
        };

        // import
        $fifu['import']['desc'] = function () {
            _e("Use FIFU with the import tool from WooCommerce.", FIFU_SLUG);
        };
        $fifu['import']['tab']['import'] = function () {
            _e("Importing products...", FIFU_SLUG);
        };
        $fifu['import']['tab']['custom'] = function () {
            _e("Custom fields", FIFU_SLUG);
        };
        $fifu['import']['import']['csv'] = function () {
            _e("CSV example", FIFU_SLUG);
        };
        $fifu['import']['custom']['general'] = function () {
            _e("For general usage", FIFU_SLUG);
        };
        $fifu['import']['custom']['specific'] = function () {
            _e("For specific features", FIFU_SLUG);
        };
        $fifu['import']['custom']['key'] = function () {
            _e("Key", FIFU_SLUG);
        };
        $fifu['import']['custom']['image'] = function () {
            _e("Featured image URL", FIFU_SLUG);
        };
        $fifu['import']['custom']['alt'] = function () {
            _e("Featured image title", FIFU_SLUG);
        };
        $fifu['import']['custom']['video'] = function () {
            _e("Featured video URL", FIFU_SLUG);
        };
        $fifu['import']['custom']['images'] = function () {
            _e("URLs of featured image and image gallery", FIFU_SLUG);
        };
        $fifu['import']['custom']['titles'] = function () {
            _e("Alternative texts of featured image and image gallery", FIFU_SLUG);
        };
        $fifu['import']['custom']['videos'] = function () {
            _e("URLs of featured video and video gallery", FIFU_SLUG);
        };
        $fifu['import']['custom']['slider'] = function () {
            _e("URLs of featured slider", FIFU_SLUG);
        };
        $fifu['import']['custom']['iframes'] = function () {
            _e("URLs of iframes", FIFU_SLUG);
        };

        // addon
        $fifu['addon']['desc'] = function () {
            _e("The plugin automatically adds its add-on to WP All Import.", FIFU_SLUG);
        };
        $fifu['addon']['tab']['import'] = function () {
            _e("Importing...", FIFU_SLUG);
        };
        $fifu['addon']['tab']['faq'] = function () {
            _e("FAQ", FIFU_SLUG);
        };
        $fifu['addon']['import']['csv'] = function () {
            _e("CSV example", FIFU_SLUG);
        };
        $fifu['addon']['faq']['woocommerce'] = function () {
            _e("Importing variable products", FIFU_SLUG);
        };
        $fifu['addon']['faq']['variation-child-xml'] = function () {
            _e('Examples for \'Variations As Child XML Elements\'', FIFU_SLUG);
        };
        $fifu['addon']['faq']['export-local-images-urls'] = function () {
            _e('Exporting local image URLs using the WP All Export plugin.', FIFU_SLUG);
        };
        $fifu['addon']['faq']['xml'] = function () {
            _e("XML", FIFU_SLUG);
        };
        $fifu['addon']['faq']['words']['section'] = function () {
            _e("Section", FIFU_SLUG);
        };
        $fifu['addon']['faq']['words']['for'] = function () {
            _e("For", FIFU_SLUG);
        };
        $fifu['addon']['faq']['words']['description'] = function () {
            _e("Description", FIFU_SLUG);
        };
        $fifu['addon']['faq']['template'] = function () {
            _e("Import template", FIFU_SLUG);
        };
        $fifu['addon']['faq']['how']['examples'] = function () {
            _e("Examples", FIFU_SLUG);
        };
        $fifu['addon']['faq']['how']['not'] = function () {
            _e("How NOT to configure WP All Import", FIFU_SLUG);
        };
        $fifu['addon']['faq']['how']['to'] = function () {
            _e("How to configure the FIFU Add-On", FIFU_SLUG);
        };
        $fifu['addon']['faq']['section']['images'] = function () {
            _e("Images", FIFU_SLUG);
        };
        $fifu['addon']['faq']['section']['addon'] = function () {
            _e("FIFU Add-On", FIFU_SLUG);
        };
        $fifu['addon']['faq']['section']['cf'] = function () {
            _e("Custom Fields", FIFU_SLUG);
        };
        $fifu['addon']['faq']['for']['delimiter'] = function () {
            _e("List of URLs delimited by comma", FIFU_SLUG);
        };
        $fifu['addon']['faq']['for']['columns'] = function () {
            _e("URLs in different columns", FIFU_SLUG);
        };
        $fifu['addon']['faq']['description']['empty'] = function () {
            _e("Do NOT add filenames or URLs. Keep the text fields EMPTY", FIFU_SLUG);
        };
        $fifu['addon']['faq']['description']['cf'] = function () {
            _e("Do NOT add FIFU custom fields", FIFU_SLUG);
        };
        $fifu['addon']['faq']['description']['delimiter'] = function () {
            _e("Enter a comma in the 'List delimiter' field", FIFU_SLUG);
        };

        // key
        $fifu['key']['desc'] = function () {
            _e("Please insert your license key below to receive updates and use this plugin without limitations.", FIFU_SLUG);
        };
        $fifu['key']['buy'] = function () {
            _e("If you intend to use FIFU on multiple distinct sites, you can purchase additional license keys <a href='https://fifu.app/#price' target='_blank'>here</a>.", FIFU_SLUG);
        };
        $fifu['key']['renew'] = function () {
            _e("You can renew your license key(s) or get more information about that <a href='https://ws.featuredimagefromurl.com/keys/' target='_blank'>here</a>.", FIFU_SLUG);
        };
        $fifu['key']['key'] = function () {
            _e("License key", FIFU_SLUG);
        };
        $fifu['key']['tab']['activation'] = function () {
            _e("Activation", FIFU_SLUG);
        };
        $fifu['key']['tab']['documentation'] = function () {
            _e("Documentation", FIFU_SLUG);
        };
        $fifu['key']['documentation'] = function () {
            _e("FIFU activation is based on the domain. Submitting your license key from the site example.com, [subdomain].example.com, or example.com/[anything] will activate the domain example.com. After that, you can use the same license key on the sites example.com, [subdomain].example.com, and example.com/[anything]. You can also use the same license key to activate a second domain for your test/development/stage site. If your domain has changed, please contact support.", FIFU_SLUG);
        };
        $fifu['key']['important'] = function () {
            _e("Even though with 1 license you can use FIFU on unlimited sites from the same domain, the technical support is still limited to 1 site.", FIFU_SLUG);
        };

        // cloud

        $fifu['cloud']['details']['photon'] = function () {
            _e("FIFU Cloud can also serve optimized thumbnails from a global CDN, providing image storage (not just cache), support for any image source, technical support, smart cropping, hotlink protection, and more.", FIFU_SLUG);
        };
        $fifu['cloud']['details']['click'] = function () {
            _e("FIFU Cloud improves the security of your images by offering hotlink protection. With this feature, even if a bot or someone else obtains image URLs from the source code of your website, they won't be able to embed them on other websites. Instead, an error message is displayed instead of the images.", FIFU_SLUG);
        };
        $fifu['cloud']['details']['library'] = function () {
            _e("FIFU Cloud can work as an alternative to the WordPress media library. Both store images, but FIFU Cloud processes them in the cloud, while the WordPress core consumes a lot of your website's resources. Additionally, FIFU Cloud is able to process and store thousands of images simultaneously in a few seconds, while the media library works with one image at a time.", FIFU_SLUG);
        };
        $fifu['cloud']['details']['replace'] = function () {
            _e("FIFU Cloud prevents image loss by saving your local or remote images in the cloud.", FIFU_SLUG);
        };

        // pro
        $fifu['unlock'] = function () {
            _e("Upgrade to PRO", FIFU_SLUG);
        };

        return $fifu;
    }
}
