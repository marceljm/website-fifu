<?php

declare( strict_types=1 );

defined( 'ABSPATH' ) || exit;

/**
 * Fifu_Wai_Strings.
 *
 * @package Fifu_Premium
 */
class Fifu_Wai_Strings {

    /**
     * @return array<string, mixed>
     */
    public static function get_strings(): array {
        $fifu = array();

        // titles
        $fifu['title']['image'] = function () {
            return __("Featured image (URL)", FIFU_SLUG);
        };
        $fifu['title']['title'] = function () {
            return __("Featured image title", FIFU_SLUG);
        };
        $fifu['title']['video'] = function () {
            return __("Featured video (URL)", FIFU_SLUG);
        };
        $fifu['title']['images'] = function () {
            return __("Product image URL + gallery URLs", FIFU_SLUG);
        };
        $fifu['title']['titles'] = function () {
            return __("Product image title + gallery titles", FIFU_SLUG);
        };
        $fifu['title']['videos'] = function () {
            return __("Product video URL + gallery URLs", FIFU_SLUG);
        };
        $fifu['title']['slider'] = function () {
            return __("Featured slider (URLs)", FIFU_SLUG);
        };
        $fifu['title']['delimiter'] = function () {
            return __("List delimiter", FIFU_SLUG);
        };        $fifu['title']['asin'] = function () {
            return __("ASIN", FIFU_SLUG);
        };
        $fifu['title']['finder'] = function () {
            return __("Media finder (webpage URL)", FIFU_SLUG);
        };
        $fifu['title']['redirection'] = function () {
            return __("Page redirection (forwarding URL)", FIFU_SLUG);
        };

        // info
        $fifu['info']['delimited'] = function () {
            return __("By default, FIFU uses | as the URL delimiter. You can define a different value in the 'List delimiter' field.", FIFU_SLUG);
        };
        $fifu['info']['default'] = function () {
            return __("Default is '|'", FIFU_SLUG);
        };
        $fifu['info']['finder'] = function () {
            return __("Works with \"Auto set featured media using web page address\"", FIFU_SLUG);
        };
        $fifu['info']['alts'] = function () {
            return __("If empty, FIFU will automatically use the product title as alternative text for every image.", FIFU_SLUG);
        };
        $fifu['info']['alt'] = function () {
            return __("If empty, FIFU will automatically use the post title as alternative text.", FIFU_SLUG);
        };

        return $fifu;
    }
}

