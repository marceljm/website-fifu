<?php

declare( strict_types=1 );

defined( 'ABSPATH' ) || exit;

/**
 * Fifu_Notice_Strings.
 *
 * @package Fifu_Premium
 */
class Fifu_Notice_Strings {

    /**
     * @return array<string, mixed>
     */
    public static function get_strings(): array {
        $fifu = array();

        // options
        $fifu['notice']['key'] = function () {
            return __("Please submit your activation key to use the plugin without limitations.", FIFU_SLUG);
        };
        $fifu['notice']['expired'] = function () {
            return __("Your license key has expired. Please renew or upgrade it to continue receiving updates and support.", FIFU_SLUG);
        };

        return $fifu;
    }
}

