<?php

declare( strict_types=1 );

defined( 'ABSPATH' ) || exit;

/**
 * Fifu_Video_Strings.
 *
 * @package Fifu_Premium
 */
class Fifu_Video_Strings {

    /**
     * @return array<string, mixed>
     */
    public static function get_strings(): array {
        $fifu = array();

        $fifu['button']['later'] = function () {
            return __("Watch later", FIFU_SLUG);
        };
        $fifu['button']['queue'] = function () {
            return __("Queue", FIFU_SLUG);
        };

        return $fifu;
    }
}

