<?php

declare( strict_types=1 );

defined( 'ABSPATH' ) || exit;

/**
 * Fifu_Shortcode_Strings.
 *
 * @package Fifu_Premium
 */
class Fifu_Shortcode_Strings {

    /**
     * @return array<string, mixed>
     */
    public static function get_strings(): array {
        $fifu = array();

        if (isset($GLOBALS['__fifu_shortcode_strings']) && is_array($GLOBALS['__fifu_shortcode_strings'])) {
            return $GLOBALS['__fifu_shortcode_strings'];
        }

        $fifu['label']['image'] = function () {
            return __("Featured image", FIFU_SLUG);
        };
        $fifu['placeholder']['image'] = function () {
            return __("Image URL", FIFU_SLUG);
        };

        return $fifu;
    }
}
