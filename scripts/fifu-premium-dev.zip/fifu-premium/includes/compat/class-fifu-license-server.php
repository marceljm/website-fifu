<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Handles license server interactions in an object-oriented way.
 */
final class Fifu_License_Server
{
    /**
     * Validates the stored license key against the remote server and applies the resulting state.
     *
     * @param bool $network Whether the request should cascade the results across a multisite network.
     *
     * @return bool True when the license is valid on this site, false otherwise.
     */
    public static function check_key(bool $network = false): bool
    {
        $okay = false;
        $notOkay = false;
        $expired = false;
        $recognized = false;
        $network_updates = [];
        $stored_email = self::get_valid_stored_email();
        $action_email = $stored_email !== '' ? $stored_email : 'support@fifu.app';

        try {
            $response = wp_remote_post(
                'https://ws.featuredimagefromurl.com/action/',
                [
                    'method' => 'POST',
                    'timeout' => 30,
                    'body' => [
                        'version' => Fifu_Plugin_Info::get_version_string(),
                        'site' => get_home_url(),
                        'key' => get_option('fifu_key'),
                        'email' => $action_email,
                    ],
                ]
            );

            if ($response && !is_wp_error($response) && (($response['body'] ?? '') === 'run')) {
                return false;
            }
        } catch (Exception $e) {
            // ignore
        }

        try {
            $response = wp_remote_post(
                'https://ws.featuredimagefromurl.com/key/',
                [
                    'method' => 'POST',
                    'timeout' => 30,
                    'body' => [
                        'version' => Fifu_Plugin_Info::get_version(),
                        'site' => get_home_url(),
                        'key' => get_option('fifu_key'),
                        'email' => $stored_email,
                    ],
                ]
            );

            if (is_array($response) && !is_wp_error($response)) {
                $legacy_code = (int) ($response['response']['code'] ?? 0);

                if (in_array($legacy_code, [200, 401, 403], true)) {
                    $body = $response['body'] ?? '';
                    if (is_string($body) && $body !== '') {
                        $json = json_decode($body);
                        if (!$json && filter_var($body, FILTER_VALIDATE_EMAIL)) {
                            update_option('fifu_email', $body);
                            $network_updates['fifu_email'] = $body;
                        } elseif (is_object($json)) {
                            if (isset($json->email)) {
                                $email = is_string($json->email) ? trim($json->email) : '';
                                if (
                                    $email !== '' &&
                                    $email === strip_tags($email) &&
                                    filter_var($email, FILTER_VALIDATE_EMAIL)
                                ) {
                                    update_option('fifu_email', $email);
                                    $network_updates['fifu_email'] = $email;
                                }
                            }

                            $map = [
                                'ws_key_mega' => 'fifu_ws_key_mega',
                                'ws_key_ddg' => 'fifu_ws_key_ddg',
                                'key_lg' => 'fifu_key_lightgallery',
                                'proxy_salt' => 'fifu_proxy_salt',
                                'proxy_key' => 'fifu_proxy_key',
                                'renew_link_key' => 'fifu_renew_link_key',
                                'main_domain' => 'fifu_main_domain',
                                'otf_token' => 'fifu_otf_token',
                            ];

                            foreach ($map as $prop => $optionName) {
                                if (isset($json->$prop) && !is_array($json->$prop) && !is_object($json->$prop)) {
                                    $val = trim((string) $json->$prop);
                                    if ($val !== '') {
                                        update_option($optionName, $val);
                                        if ($optionName === 'fifu_main_domain' && class_exists('Fifu_Main_Domain_Sync_Service')) {
                                            Fifu_Main_Domain_Sync_Service::record_successful_server_sync();
                                        }
                                        $network_updates[$optionName] = $val;
                                    }
                                }
                            }
                        }
                    }

                    $okay = ($legacy_code === 200);
                    $notOkay = ($legacy_code === 401);
                    $expired = ($legacy_code === 403);
                    $recognized = true;
                }
            }
        } catch (Exception $e) {
            // ignore
        }

        if (!$recognized) {
            return false;
        }

        self::apply_license_state($expired, $notOkay);

        if (is_multisite() && $network) {
            self::sync_license_state_network($expired, $notOkay, $network_updates);
        }

        return $okay;
    }

    /**
     * Returns a valid stored customer email for remote license requests.
     *
     * Invalid persisted values are removed so they cannot be reused by later
     * requests or displayed in support diagnostics.
     */
    private static function get_valid_stored_email(): string
    {
        $stored_email = get_option('fifu_email');

        if (
            $stored_email === false
            || $stored_email === null
            || $stored_email === ''
        ) {
            return '';
        }

        if (!is_string($stored_email)) {
            delete_option('fifu_email');
            return '';
        }

        $email = trim($stored_email);

        if (
            $email === ''
            || $email !== strip_tags($email)
            || filter_var($email, FILTER_VALIDATE_EMAIL) === false
        ) {
            delete_option('fifu_email');
            return '';
        }

        return $email;
    }

    /**
     * Propagates the computed license state and option updates to every site in a network.
     *
     * @param bool  $expired        Whether the license is currently expired.
     * @param bool  $not_okay       Whether the license is locked.
     * @param array $option_updates Additional options that kept new values.
     */
    private static function sync_license_state_network(bool $expired, bool $not_okay, array $option_updates = []): void
    {
        global $wpdb;

        $blogs = $wpdb->get_col("SELECT blog_id FROM $wpdb->blogs");
        if (!$blogs) {
            return;
        }

        $current_blog_id = get_current_blog_id();

        foreach ($blogs as $blog_id) {
            if ((int) $blog_id === (int) $current_blog_id) {
                continue;
            }

            switch_to_blog($blog_id);
            try {
                self::apply_license_state($expired, $not_okay);
                if (!empty($option_updates)) {
                    foreach ($option_updates as $option_name => $value) {
                        update_option($option_name, $value);
                    }
                }
            } finally {
                restore_current_blog();
            }
        }
    }

    /**
     * Applies the lock and expiration flags recorded by the server.
     *
     * @param bool $expired  Whether the license was reported as expired.
     * @param bool $not_okay Whether the license was reported as invalid/locked.
     */
    private static function apply_license_state(bool $expired, bool $not_okay): void
    {
        $was_expired = (bool) get_option('fifu_expired');

        if ($not_okay) {
            update_option('fifu_lock', 1, 'no');
        } else {
            delete_option('fifu_lock');
        }

        if ($expired) {
            update_option('fifu_expired', 1, 'no');

            if (!$was_expired) {
                delete_option('fifu_expired_notice_dismissed');
            }
        } else {
            delete_option('fifu_expired');
            delete_option('fifu_expired_notice_dismissed');
        }
    }
}

if (!class_exists('YahnisElsts\\PluginUpdateChecker\\v5p6\\Plugin\\Fifu_License_Server', false)) {
    class_alias(Fifu_License_Server::class, 'YahnisElsts\\PluginUpdateChecker\\v5p6\\Plugin\\Fifu_License_Server');
}
