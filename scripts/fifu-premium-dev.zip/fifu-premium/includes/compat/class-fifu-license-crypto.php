<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

final class Fifu_License_Crypto
{
    public static function create_keys(string $email): string
    {
        $config = [
            'digest_alg' => 'sha256',
            'private_key_bits' => 2048,
            'private_key_type' => OPENSSL_KEYTYPE_RSA,
        ];

        $res = openssl_pkey_new($config);
        openssl_pkey_export($res, $privKey);
        $pubKey = openssl_pkey_get_details($res);
        $pubKey = $pubKey['key'] ?? '';

        update_option('fifu_su_email', [base64_encode($email)], 'no');
        $encrypted = openssl_encrypt(
            $privKey,
            'AES-128-ECB',
            $email . Fifu_Image_Url_Utils::get_home_url_no_scheme()
        );
        update_option('fifu_su_privkey', [base64_encode($encrypted)], 'no');

        return base64_encode($pubKey);
    }

    public static function create_signature(string $data): string
    {
        $email = base64_decode((get_option('fifu_su_email')[0] ?? ''));
        $privKey = openssl_decrypt(
            base64_decode((get_option('fifu_su_privkey')[0] ?? '')),
            'AES-128-ECB',
            $email . Fifu_Image_Url_Utils::get_home_url_no_scheme()
        );

        openssl_sign($data, $signature, $privKey, OPENSSL_ALGO_SHA256);

        return base64_encode($signature);
    }

    public static function create_hash(string $data): string
    {
        $license_key = get_option('fifu_key');

        return hash_hmac('sha256', $data, $license_key);
    }

    public static function get_renew_link(): string
    {
        $default = 'https://ws.featuredimagefromurl.com/keys/';

        $key = get_option('fifu_key');
        $email = get_option('fifu_email');

        if (!$key || !$email) {
            return $default;
        }

        $encoded_email = base64_encode($email);
        $data = $encoded_email . '|' . $key;

        $encryption_key = get_option('fifu_renew_link_key');

        if (!$encryption_key) {
            return $default;
        }

        $encryption_key = str_pad($encryption_key, 32, '0');
        $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));

        $block_size = 16;
        $padding = $block_size - (strlen($data) % $block_size);
        $data .= str_repeat(chr($padding), $padding);

        $encrypted_data = openssl_encrypt(
            $data,
            'aes-256-cbc',
            $encryption_key,
            OPENSSL_RAW_DATA,
            $iv
        );

        if ($encrypted_data === false) {
            error_log('Encryption failed');

            return $default;
        }

        $url = $default . 'renew?data=' . urlencode(base64_encode($iv . $encrypted_data));

        return $url;
    }

    public static function generate_random_key(): string
    {
        return bin2hex(self::get_random_bytes(16));
    }

    private static function get_random_bytes(int $length): string
    {
        if (function_exists('random_bytes')) {
            return random_bytes($length);
        }

        if (function_exists('openssl_random_pseudo_bytes')) {
            $bytes = openssl_random_pseudo_bytes($length);
            if ($bytes !== false) {
                return substr($bytes, 0, $length);
            }
        }

        return substr(hash('sha256', mt_rand() . microtime(true), true), 0, $length);
    }
}
