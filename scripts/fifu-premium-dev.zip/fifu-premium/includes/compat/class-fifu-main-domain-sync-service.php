<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Keeps the server-authoritative main domain synchronized with the public host.
 */
final class Fifu_Main_Domain_Sync_Service
{
    private const OPTION_LAST_SITE_HOST = 'fifu_last_site_host';
    private const RETRY_TRANSIENT = 'fifu_main_domain_sync_retry';
    private const RETRY_TTL = HOUR_IN_SECONDS;

    public static function register_hooks(): void
    {
        add_action('admin_init', [self::class, 'maybe_refresh']);
    }

    public static function get_current_site_host(): string
    {
        $host = wp_parse_url(get_home_url(), PHP_URL_HOST);
        if (!is_string($host)) {
            return '';
        }

        return self::normalize_host($host);
    }

    public static function needs_refresh(): bool
    {
        $current_host = self::get_current_site_host();
        if ($current_host === '' || trim((string) get_option('fifu_key', '')) === '') {
            return false;
        }

        $main_domain = trim((string) get_option('fifu_main_domain', ''));
        $last_site_host = self::normalize_host((string) get_option(self::OPTION_LAST_SITE_HOST, ''));

        return $main_domain === '' || $last_site_host !== $current_host;
    }

    public static function maybe_refresh(): void
    {
        self::ensure_current(false);
    }

    public static function ensure_current(bool $force = false): bool
    {
        if (self::get_current_site_host() === '' || trim((string) get_option('fifu_key', '')) === '') {
            return false;
        }

        if (!$force && !self::needs_refresh()) {
            return true;
        }

        if (!$force && get_transient(self::RETRY_TRANSIENT) !== false) {
            return false;
        }

        set_transient(self::RETRY_TRANSIENT, 1, self::RETRY_TTL);
        Fifu_License_Server::check_key();

        if (!self::needs_refresh()) {
            delete_transient(self::RETRY_TRANSIENT);
            return true;
        }

        return false;
    }

    public static function record_successful_server_sync(): void
    {
        $current_host = self::get_current_site_host();
        if ($current_host === '') {
            return;
        }

        update_option(self::OPTION_LAST_SITE_HOST, $current_host, 'no');
        delete_transient(self::RETRY_TRANSIENT);
    }

    private static function normalize_host(string $host): string
    {
        return strtolower(rtrim(trim($host), '.'));
    }
}
