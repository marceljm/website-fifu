<?php

declare(strict_types=1);

defined('ABSPATH') || exit;

class Fifu_Theme_Woocommerce_Gallery_Compat {

    /** @var array<int, array{product_id: int, first_gallery_image: int, replaced: bool}|null> */
    private static array $blocksy_quick_view_gallery_frames = [];

    /**
     * Register theme-specific compatibility hooks for the WooCommerce product gallery.
     */
    public static function register(): void {
        if (!class_exists('Fifu_Theme_Detector')) {
            return;
        }

        if (Fifu_Theme_Detector::is_rey_active()) {
            self::register_rey();
        } elseif (Fifu_Theme_Detector::is_blocksy_active()) {
            self::register_blocksy();
        } else {
            self::register_default();
        }
    }

    /**
     * Register WooCommerce gallery integration for Rey theme.
     */
    private static function register_rey(): void {
        add_action('fifu_render_woocommerce_gallery_template', [self::class, 'render_rey_gallery']);
    }

    /**
     * Register WooCommerce gallery integration for Blocksy theme.
     */
    private static function register_blocksy(): void {
        add_filter('blocksy:woocommerce:product-view:content', [self::class, 'filter_blocksy_gallery_content'], 10, 4);
        add_action('fifu_render_woocommerce_gallery_template', [self::class, 'render_blocksy_gallery']);
        add_action('blocksy:woocommerce:product-view:start', [self::class, 'begin_blocksy_quick_view_gallery'], 10, 1);
        add_filter('woocommerce_single_product_image_thumbnail_html', [self::class, 'filter_blocksy_quick_view_gallery_html'], 10, 2);
        add_action('blocksy:woocommerce:product-gallery:after', [self::class, 'end_blocksy_quick_view_gallery']);
    }

    /**
     * Register default WooCommerce gallery integration (fallback).
     */
    private static function register_default(): void {
        add_action('fifu_render_woocommerce_gallery_template', [self::class, 'render_default_gallery']);
    }

    /**
     * Render the gallery for Rey theme.
     */
    public static function render_rey_gallery(): void {
        self::render_gallery_with_class('fifu-woo-gallery woocommerce-product-gallery--with-images woocommerce-product-gallery--columns-4 images');
    }

    /**
     * Render the gallery for Blocksy theme.
     */
    public static function render_blocksy_gallery(): void {
        self::render_gallery_with_class('fifu-woo-gallery woocommerce-product-gallery woocommerce-product-gallery--with-images woocommerce-product-gallery--columns-4 images');
    }

    /**
     * Return FIFU gallery content inside Blocksy's native gallery wrapper.
     *
     * @param mixed $content
     * @param mixed $product
     * @param mixed $gallery_images
     * @param mixed $is_single
     * @return mixed
     */
    public static function filter_blocksy_gallery_content($content, $product, $gallery_images, $is_single) {
        unset($gallery_images, $is_single);

        if (!is_object($product) || !method_exists($product, 'get_id')) {
            return $content;
        }

        $product_id = $product->get_id();
        if (is_string($product_id) && ctype_digit($product_id)) {
            $product_id = (int) $product_id;
        } elseif (!is_int($product_id)) {
            return $content;
        }

        if ($product_id <= 0) {
            return $content;
        }

        return self::render_blocksy_gallery_for_product_id($product_id);
    }

    /**
     * Start Quick View replacement scope for a Blocksy gallery render.
     *
     * @param mixed $gallery_images
     */
    public static function begin_blocksy_quick_view_gallery($gallery_images): void {
        global $blocksy_is_quick_view, $product;

        if (!$blocksy_is_quick_view) {
            self::$blocksy_quick_view_gallery_frames[] = null;
            return;
        }

        if (!is_object($product) || !method_exists($product, 'get_id')) {
            self::$blocksy_quick_view_gallery_frames[] = null;
            return;
        }

        $product_id = $product->get_id();
        if (!is_int($product_id) || $product_id <= 0) {
            self::$blocksy_quick_view_gallery_frames[] = null;
            return;
        }

        $first_gallery_image = is_array($gallery_images) && array_key_exists(0, $gallery_images)
            ? $gallery_images[0]
            : null;
        if (!is_int($first_gallery_image) || $first_gallery_image <= 0) {
            self::$blocksy_quick_view_gallery_frames[] = null;
            return;
        }

        self::$blocksy_quick_view_gallery_frames[] = [
            'product_id' => $product_id,
            'first_gallery_image' => $first_gallery_image,
            'replaced' => false,
        ];
    }

    /**
     * Replace only Blocksy's complete Quick View gallery inner HTML.
     *
     * @param mixed $html
     * @param mixed $attachment_id
     * @return mixed
     */
    public static function filter_blocksy_quick_view_gallery_html($html, $attachment_id) {
        if (self::$blocksy_quick_view_gallery_frames === []) {
            return $html;
        }

        $frame_index = array_key_last(self::$blocksy_quick_view_gallery_frames);
        $frame = self::$blocksy_quick_view_gallery_frames[$frame_index];

        if ($frame === null) {
            return $html;
        }

        if (
            $frame['replaced']
            || $attachment_id !== $frame['first_gallery_image']
        ) {
            return $html;
        }

        self::$blocksy_quick_view_gallery_frames[$frame_index]['replaced'] = true;
        return self::render_blocksy_gallery_for_product_id($frame['product_id']);
    }

    /**
     * Clear the current Blocksy Quick View gallery scope.
     */
    public static function end_blocksy_quick_view_gallery(): void {
        if (self::$blocksy_quick_view_gallery_frames !== []) {
            array_pop(self::$blocksy_quick_view_gallery_frames);
        }
    }

    /**
     * Build the FIFU gallery using Blocksy's inner gallery classes.
     */
    private static function render_blocksy_gallery_for_product_id(int $product_id): string {
        return Fifu_Woocommerce_Gallery_Renderer::render_product_gallery(
            $product_id,
            null,
            'fifu-woo-gallery woocommerce-product-gallery--with-images woocommerce-product-gallery--columns-4 images',
            '',
            true
        );
    }

    /**
     * Render the default gallery integration.
     */
    public static function render_default_gallery(): void {
        self::render_gallery_with_class('fifu-woo-gallery woocommerce-product-gallery woocommerce-product-gallery--with-images woocommerce-product-gallery--columns-4 images');
    }

    /**
     * Render the gallery block with the given CSS class.
     */
    private static function render_gallery_with_class(string $gallery_class): void {
        global $post;

        if (!isset($post) || !isset($post->ID)) {
            return;
        }

        echo Fifu_Woocommerce_Gallery_Renderer::render_product_gallery(
            (int) $post->ID,
            null,
            $gallery_class,
            '',
            true
        );
    }
}
