<?php

declare( strict_types=1 );

defined( 'ABSPATH' ) || exit;

/**
 * Central manager for FIFU Premium settings and options.
 *
 * @package Fifu_Premium
 */
class Fifu_Settings_Manager {

    /** @var bool[] Tracks reset_settings invocations for tests. */
    public static array $reset_settings_calls = [];

    /**
     * Missing list of menu-related options derived from the legacy FIFU_SETTINGS constant.
     *
     * @var string[]
     */
    private const MENU_SETTINGS = [
        'fifu_block',
        'fifu_popup',
        'fifu_redirection',
        'fifu_auto_share',
        'fifu_auto_share_facebook',
        'fifu_auto_share_instagram',
        'fifu_auto_share_x',
        'fifu_auto_set',
        'fifu_auto_set_width',
        'fifu_auto_set_height',
        'fifu_auto_set_blocklist',
        'fifu_auto_set_cpt',
        'fifu_auto_set_source',
        'fifu_auto_set_layout',
        'fifu_html_media',
        'fifu_upload_domain',
        'fifu_skip',
        'fifu_html_cpt',
        'fifu_isbn',
        'fifu_isbn_custom_field',
        'fifu_asin',
        'fifu_asin_custom_field',
        'fifu_asin_credentials_partner',
        'fifu_asin_credentials_access',
        'fifu_asin_credentials_secret',
        'fifu_asin_credentials_locale',
        'fifu_auto_share_x_clientid',
        'fifu_square_mobile',
        'fifu_square_desktop',
        'fifu_screenshot_custom_field',
        'fifu_screenshot_size',
        'fifu_customfield',
        'fifu_customfield_custom_field',
        'fifu_finder_custom_field',
        'fifu_finder',
        'fifu_video_finder',
        'fifu_amazon_finder',
        'fifu_screenshot',
        'fifu_debug',
        'fifu_photon',
        'fifu_otfcdn',
        'fifu_own_domain',
        'fifu_cdn_content',
        'fifu_reset',
        'fifu_fake',
        'fifu_order_email',
        'fifu_gallery',
        'fifu_adaptive_height',
        'fifu_videos_before',
        'fifu_variations_merge',
        'fifu_buy',
        'fifu_key',
        'fifu_email',
        'fifu_error_url',
        'fifu_validate_featured_image_urls',
        'fifu_default_url',
        'fifu_default_cpt',
        'fifu_pcontent_types',
        'fifu_hide_format',
        'fifu_hide_type',
        'fifu_enable_default_url',
        'fifu_cron_metadata',
        'fifu_video_min_width',
        'fifu_video_color',
        'fifu_video_zindex',
        'fifu_video_size',
        'fifu_slider',
        'fifu_slider_auto',
        'fifu_slider_gallery',
        'fifu_slider_thumb',
        'fifu_slider_counter',
        'fifu_slider_crop',
        'fifu_slider_single',
        'fifu_slider_vertical',
        'fifu_slider_ctrl',
        'fifu_slider_stop',
        'fifu_slider_speed',
        'fifu_slider_pause',
        'fifu_wc_lbox',
        'fifu_wc_zoom',
        'fifu_hide',
        'fifu_pcontent_add',
        'fifu_pcontent_remove',
        'fifu_get_first',
        'fifu_ovw_first',
        'fifu_update_all',
        'fifu_run_delete_all',
        'fifu_mouse_video',
        'fifu_loop',
        'fifu_autoplay',
        'fifu_autoplay_front',
        'fifu_autoplay_front_all',
        'fifu_autoplay_elsewhere',
        'fifu_video_mute',
        'fifu_video_mute_mobile',
        'fifu_video_background',
        'fifu_video_background_single',
        'fifu_video_privacy',
        'fifu_vimeo_access_token',
        'fifu_vimeo_mp4_rendition',
        'fifu_video_later',
        'fifu_video_later_left',
        'fifu_video',
        'fifu_video_thumb',
        'fifu_video_thumb_page',
        'fifu_video_thumb_post',
        'fifu_video_thumb_cpt',
        'fifu_video_play_button',
        'fifu_video_play_hide_grid',
        'fifu_video_play_hide_grid_wc',
        'fifu_video_controls',
        'fifu_auto_category',
        'fifu_taxonomy',
        'fifu_data_clean',
        'fifu_play_type',
        'fifu_upload_show',
        'fifu_upload_proxy',
        'fifu_upload_job',
        'fifu_upload_private_proxy',
        'fifu_slider_left',
        'fifu_slider_right',
        'fifu_buy_text',
        'fifu_buy_disclaimer',
        'fifu_buy_cf',
        'fifu_bbpress_fields',
        'fifu_cloud_upload_auto',
        'fifu_cloud_delete_auto',
        'fifu_cloud_hotlink',
    ];

    /**
     * Provides the menu settings keys that will replace FIFU_SETTINGS.
     *
     * @return string[]
     */
    public static function get_menu_settings(): array {
        return self::MENU_SETTINGS;
    }

    // TODO: Add metadata map (types, defaults, validation) currently implicit in the legacy settings handlers.

    /**
     * Register and ensure defaults for all plugin menu settings.
     */
    public static function register_menu_settings(): void {
        foreach ( self::get_menu_settings() as $option_name ) {
            self::ensure_default( (string) $option_name );
        }
    }

    /**
     * Reset configurable settings while preserving license and identity values.
     */
    public static function reset_settings(): void {
        foreach ( self::get_menu_settings() as $option_name ) {
            if ( in_array( $option_name, array( 'fifu_key', 'fifu_email', 'fifu_default_url', 'fifu_enable_default_url' ), true ) ) {
                continue;
            }

            delete_option( $option_name );
        }

        self::$reset_settings_calls[] = true;
    }

    /**
     * Utility reset used by CLI tests.
     */
    public static function reset(): void {
        self::$reset_settings_calls = [];
    }

    /**
     * Ensure the requested option has a default value before use.
     *
     * @param string $option_name Option key whose default should be enforced.
     */
    public static function ensure_default( string $option_name ): void {
        register_setting( 'settings-group', $option_name );

        $arrPlayType = array( 'fifu_play_type' );
        $arrAutoSetDimensions = array(
            'fifu_auto_set_width' => 600,
            'fifu_auto_set_height' => 315,
        );
        $arrEmpty = array(
            'fifu_default_url',
            'fifu_upload_private_proxy',
            'fifu_slider_left',
            'fifu_slider_right',
            'fifu_buy_text',
            'fifu_buy_disclaimer',
            'fifu_buy_cf',
            'fifu_isbn_custom_field',
            'fifu_asin_custom_field',
            'fifu_asin_credentials_partner',
            'fifu_asin_credentials_access',
            'fifu_asin_credentials_secret',
            'fifu_asin_credentials_locale',
            'fifu_auto_share_x_clientid',
            'fifu_square_mobile',
            'fifu_square_desktop',
            'fifu_screenshot_custom_field',
            'fifu_customfield_custom_field',
            'fifu_finder_custom_field',
            'fifu_auto_set_source',
            'fifu_auto_set_layout',
            'fifu_upload_domain',
            'fifu_skip',
            'fifu_html_cpt',
            'fifu_hide_format',
            'fifu_hide_type',
            'fifu_pcontent_types',
        );
        $arrEmptyNo = array( 'fifu_error_url', 'fifu_key', 'fifu_email', 'fifu_auto_set_blocklist', 'fifu_vimeo_access_token' );
        $arrVimeoMp4Rendition = array( 'fifu_vimeo_mp4_rendition' );
        $arrDefaultType = array( 'fifu_default_cpt' );
        $arr50 = array( 'fifu_video_size' );
        $arr100 = array( 'fifu_video_min_width' );
        $arr1000 = array( 'fifu_slider_speed', 'fifu_video_zindex' );
        $arr2000 = array( 'fifu_slider_pause' );
        $arr1280x960 = array( 'fifu_screenshot_size' );
        $arrRed = array( 'fifu_video_color' );
        $arrPost = array( 'fifu_auto_set_cpt' );
        $arrImage = array( 'fifu_html_media' );
        $arrOn = array( 'fifu_wc_zoom', 'fifu_wc_lbox' );
        $arrOnNo = array(
            'fifu_fake',
            'fifu_video_play_button',
            'fifu_video_thumb',
            'fifu_video_thumb_post',
            'fifu_video_thumb_page',
            'fifu_video_thumb_cpt',
            'fifu_video_controls',
            'fifu_slider_crop',
            'fifu_adaptive_height',
            'fifu_gallery',
            'fifu_slider_thumb',
        );
        $arrOffNo = array( 'fifu_auto_category_created', 'fifu_data_clean', 'fifu_update_all', 'fifu_run_delete_all', 'fifu_reset', 'fifu_enable_cron_metadata', 'fifu_autoplay_front_all' );

        if ( get_option( $option_name ) === false ) {
            if ( in_array( $option_name, $arrPlayType, true ) ) {
                update_option( $option_name, 'inline', 'no' );
            } elseif ( array_key_exists( $option_name, $arrAutoSetDimensions ) ) {
                update_option( $option_name, $arrAutoSetDimensions[ $option_name ] );
            } elseif ( in_array( $option_name, $arrEmpty, true ) ) {
                update_option( $option_name, '' );
            } elseif ( in_array( $option_name, $arrEmptyNo, true ) ) {
                update_option( $option_name, '', 'no' );
            } elseif ( in_array( $option_name, $arrVimeoMp4Rendition, true ) ) {
                update_option( $option_name, '540p', 'no' );
            } elseif ( in_array( $option_name, $arrDefaultType, true ) ) {
                update_option( $option_name, 'post,page,product', 'no' );
            } elseif ( in_array( $option_name, $arr50, true ) ) {
                update_option( $option_name, 50 );
            } elseif ( in_array( $option_name, $arr100, true ) ) {
                update_option( $option_name, 100, 'no' );
            } elseif ( in_array( $option_name, $arr1000, true ) ) {
                update_option( $option_name, 1000 );
            } elseif ( in_array( $option_name, $arr2000, true ) ) {
                update_option( $option_name, 2000 );
            } elseif ( in_array( $option_name, $arr1280x960, true ) ) {
                update_option( $option_name, '1280x960' );
            } elseif ( in_array( $option_name, $arrRed, true ) ) {
                update_option( $option_name, 'red', 'no' );
            } elseif ( in_array( $option_name, $arrPost, true ) ) {
                update_option( $option_name, 'post', 'no' );
            } elseif ( in_array( $option_name, $arrImage, true ) ) {
                update_option( $option_name, 'image', 'no' );
            } elseif ( in_array( $option_name, $arrOn, true ) ) {
                update_option( $option_name, 'toggleon' );
            } elseif ( in_array( $option_name, $arrOnNo, true ) ) {
                update_option( $option_name, 'toggleon', 'no' );
            } elseif ( in_array( $option_name, $arrOffNo, true ) ) {
                update_option( $option_name, 'toggleoff', 'no' );
            } else {
                update_option( $option_name, 'toggleoff' );
            }
        }
    }

    /**
     * Update settings based on the submitted request payload.
     *
     * @return array<string,mixed> Structured data returned by the legacy update handler.
     */
    public static function update_from_request(): array {
        if ( self::is_valid_nonce( 'nonce_fifu_form_block' ) ) {
            self::update_single_option( 'fifu_input_block', 'fifu_block' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_popup' ) ) {
            self::update_single_option( 'fifu_input_popup', 'fifu_popup' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_redirection' ) ) {
            self::update_single_option( 'fifu_input_redirection', 'fifu_redirection' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_auto_share' ) ) {
            self::update_single_option( 'fifu_input_auto_share', 'fifu_auto_share' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_auto_share_facebook' ) ) {
            self::update_single_option( 'fifu_input_auto_share_facebook', 'fifu_auto_share_facebook' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_auto_share_instagram' ) ) {
            self::update_single_option( 'fifu_input_auto_share_instagram', 'fifu_auto_share_instagram' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_auto_share_x' ) ) {
            self::update_single_option( 'fifu_input_auto_share_x', 'fifu_auto_share_x' );
            self::update_single_option( 'fifu_input_auto_share_x_clientid', 'fifu_auto_share_x_clientid' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_auto_set' ) ) {
            self::update_single_option( 'fifu_input_auto_set', 'fifu_auto_set' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_auto_set_dimensions' ) ) {
            self::update_single_option( 'fifu_input_auto_set_width', 'fifu_auto_set_width' );
            self::update_single_option( 'fifu_input_auto_set_height', 'fifu_auto_set_height' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_auto_set_blocklist' ) ) {
            self::update_single_option( 'fifu_input_auto_set_blocklist', 'fifu_auto_set_blocklist' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_auto_set_cpt' ) ) {
            self::update_single_option( 'fifu_input_auto_set_cpt', 'fifu_auto_set_cpt' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_auto_set_source' ) ) {
            self::update_single_option( 'fifu_input_auto_set_source', 'fifu_auto_set_source' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_auto_set_layout' ) ) {
            self::update_single_option( 'fifu_input_auto_set_layout', 'fifu_auto_set_layout' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_html_media' ) ) {
            self::update_single_option( 'fifu_input_html_media', 'fifu_html_media' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_upload_domain' ) ) {
            self::update_single_option( 'fifu_input_upload_domain', 'fifu_upload_domain' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_skip' ) ) {
            self::update_single_option( 'fifu_input_skip', 'fifu_skip' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_html_cpt' ) ) {
            self::update_single_option( 'fifu_input_html_cpt', 'fifu_html_cpt' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_isbn' ) ) {
            self::update_single_option( 'fifu_input_isbn', 'fifu_isbn' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_isbn_custom_field' ) ) {
            self::update_single_option( 'fifu_input_isbn_custom_field', 'fifu_isbn_custom_field' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_asin' ) ) {
            self::update_single_option( 'fifu_input_asin', 'fifu_asin' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_asin_custom_field' ) ) {
            self::update_single_option( 'fifu_input_asin_custom_field', 'fifu_asin_custom_field' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_asin_credentials' ) ) {
            self::update_single_option( 'fifu_input_asin_credentials_partner', 'fifu_asin_credentials_partner' );
            self::update_single_option( 'fifu_input_asin_credentials_access', 'fifu_asin_credentials_access' );
            self::update_single_option( 'fifu_input_asin_credentials_secret', 'fifu_asin_credentials_secret' );
            self::update_single_option( 'fifu_input_asin_credentials_locale', 'fifu_asin_credentials_locale' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_square' ) ) {
            self::update_single_option( 'fifu_input_square_mobile', 'fifu_square_mobile' );
            self::update_single_option( 'fifu_input_square_desktop', 'fifu_square_desktop' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_screenshot_custom_field' ) ) {
            self::update_single_option( 'fifu_input_screenshot_custom_field', 'fifu_screenshot_custom_field' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_screenshot_size' ) ) {
            self::update_single_option( 'fifu_input_screenshot_size', 'fifu_screenshot_size' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_customfield' ) ) {
            self::update_single_option( 'fifu_input_customfield', 'fifu_customfield' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_customfield_custom_field' ) ) {
            self::update_single_option( 'fifu_input_customfield_custom_field', 'fifu_customfield_custom_field' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_finder_custom_field' ) ) {
            self::update_single_option( 'fifu_input_finder_custom_field', 'fifu_finder_custom_field' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_finder' ) ) {
            self::update_single_option( 'fifu_input_finder', 'fifu_finder' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_video_finder' ) ) {
            self::update_single_option( 'fifu_input_video_finder', 'fifu_video_finder' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_amazon_finder' ) ) {
            self::update_single_option( 'fifu_input_amazon_finder', 'fifu_amazon_finder' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_screenshot' ) ) {
            self::update_single_option( 'fifu_input_screenshot', 'fifu_screenshot' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_debug' ) ) {
            self::update_single_option( 'fifu_input_debug', 'fifu_debug' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_photon' ) ) {
            self::update_single_option( 'fifu_input_photon', 'fifu_photon' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_own_domain' ) ) {
            $value = $_POST['fifu_input_own_domain'] ?? '';

            if ( in_array( $value, array( 'on', 'off' ), true ) ) {
                Fifu_Cloud_Otfcdn_Service::set_own_domain( 'on' === $value );
            }
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_cdn_content' ) ) {
            self::update_single_option( 'fifu_input_cdn_content', 'fifu_cdn_content' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_reset' ) ) {
            self::update_single_option( 'fifu_input_reset', 'fifu_reset' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_fake' ) ) {
            self::update_single_option( 'fifu_input_fake', 'fifu_fake' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_order_email' ) ) {
            self::update_single_option( 'fifu_input_order_email', 'fifu_order_email' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_gallery' ) ) {
            self::update_single_option( 'fifu_input_gallery', 'fifu_gallery' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_adaptive_height' ) ) {
            self::update_single_option( 'fifu_input_adaptive_height', 'fifu_adaptive_height' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_videos_before' ) ) {
            self::update_single_option( 'fifu_input_videos_before', 'fifu_videos_before' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_variations_merge' ) ) {
            self::update_single_option( 'fifu_input_variations_merge', 'fifu_variations_merge' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_buy' ) ) {
            self::update_single_option( 'fifu_input_buy', 'fifu_buy' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_buy_text' ) ) {
            self::update_single_option( 'fifu_input_buy_text', 'fifu_buy_text' );
            self::update_single_option( 'fifu_input_buy_disclaimer', 'fifu_buy_disclaimer' );
            self::update_single_option( 'fifu_input_buy_cf', 'fifu_buy_cf' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_error_url' ) ) {
            self::update_single_option( 'fifu_input_error_url', 'fifu_error_url' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_validate_featured_image_urls' ) ) {
            self::update_single_option( 'fifu_input_validate_featured_image_urls', 'fifu_validate_featured_image_urls' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_default_url' ) ) {
            self::update_single_option( 'fifu_input_default_url', 'fifu_default_url' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_default_cpt' ) ) {
            self::update_single_option( 'fifu_input_default_cpt', 'fifu_default_cpt' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_pcontent_types' ) ) {
            self::update_single_option( 'fifu_input_pcontent_types', 'fifu_pcontent_types' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_hide_format' ) ) {
            self::update_single_option( 'fifu_input_hide_format', 'fifu_hide_format' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_hide_type' ) ) {
            self::update_single_option( 'fifu_input_hide_type', 'fifu_hide_type' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_enable_default_url' ) ) {
            self::update_single_option( 'fifu_input_enable_default_url', 'fifu_enable_default_url' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_cron_metadata' ) ) {
            self::update_single_option( 'fifu_input_cron_metadata', 'fifu_cron_metadata' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_spinner' ) ) {
            self::update_single_option( 'fifu_input_slider_pause', 'fifu_slider_pause' );
            self::update_single_option( 'fifu_input_slider_speed', 'fifu_slider_speed' );
            self::update_single_option( 'fifu_input_slider_left', 'fifu_slider_left' );
            self::update_single_option( 'fifu_input_slider_right', 'fifu_slider_right' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_video_min_width' ) ) {
            self::update_single_option( 'fifu_input_video_min_width', 'fifu_video_min_width' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_video_color' ) ) {
            self::update_single_option( 'fifu_input_video_color', 'fifu_video_color' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_video_zindex' ) ) {
            self::update_single_option( 'fifu_input_video_zindex', 'fifu_video_zindex' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_video_size' ) ) {
            self::update_single_option( 'fifu_input_video_size', 'fifu_video_size' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_slider' ) ) {
            self::update_single_option( 'fifu_input_slider', 'fifu_slider' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_slider_auto' ) ) {
            self::update_single_option( 'fifu_input_slider_auto', 'fifu_slider_auto' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_slider_gallery' ) ) {
            self::update_single_option( 'fifu_input_slider_gallery', 'fifu_slider_gallery' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_slider_thumb' ) ) {
            self::update_single_option( 'fifu_input_slider_thumb', 'fifu_slider_thumb' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_slider_counter' ) ) {
            self::update_single_option( 'fifu_input_slider_counter', 'fifu_slider_counter' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_slider_crop' ) ) {
            self::update_single_option( 'fifu_input_slider_crop', 'fifu_slider_crop' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_slider_single' ) ) {
            self::update_single_option( 'fifu_input_slider_single', 'fifu_slider_single' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_slider_vertical' ) ) {
            self::update_single_option( 'fifu_input_slider_vertical', 'fifu_slider_vertical' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_slider_ctrl' ) ) {
            self::update_single_option( 'fifu_input_slider_ctrl', 'fifu_slider_ctrl' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_slider_stop' ) ) {
            self::update_single_option( 'fifu_input_slider_stop', 'fifu_slider_stop' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_wc_lbox' ) ) {
            self::update_single_option( 'fifu_input_wc_lbox', 'fifu_wc_lbox' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_wc_zoom' ) ) {
            self::update_single_option( 'fifu_input_wc_zoom', 'fifu_wc_zoom' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_hide' ) ) {
            self::update_single_option( 'fifu_input_hide', 'fifu_hide' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_pcontent_add' ) ) {
            self::update_single_option( 'fifu_input_pcontent_add', 'fifu_pcontent_add' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_pcontent_remove' ) ) {
            self::update_single_option( 'fifu_input_pcontent_remove', 'fifu_pcontent_remove' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_get_first' ) ) {
            self::update_single_option( 'fifu_input_get_first', 'fifu_get_first' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_ovw_first' ) ) {
            self::update_single_option( 'fifu_input_ovw_first', 'fifu_ovw_first' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_update_all' ) ) {
            self::update_single_option( 'fifu_input_update_all', 'fifu_update_all' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_run_delete_all' ) ) {
            self::update_single_option( 'fifu_input_run_delete_all', 'fifu_run_delete_all' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_autoplay' ) ) {
            self::update_single_option( 'fifu_input_autoplay', 'fifu_autoplay' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_autoplay_front' ) ) {
            self::update_single_option( 'fifu_input_autoplay_front', 'fifu_autoplay_front' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_autoplay_front_all' ) ) {
            self::update_single_option( 'fifu_input_autoplay_front_all', 'fifu_autoplay_front_all' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_autoplay_elsewhere' ) ) {
            self::update_single_option( 'fifu_input_autoplay_elsewhere', 'fifu_autoplay_elsewhere' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_video_mute' ) ) {
            self::update_single_option( 'fifu_input_video_mute', 'fifu_video_mute' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_video_mute_mobile' ) ) {
            self::update_single_option( 'fifu_input_video_mute_mobile', 'fifu_video_mute_mobile' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_video_background' ) ) {
            self::update_single_option( 'fifu_input_video_background', 'fifu_video_background' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_video_background_single' ) ) {
            self::update_single_option( 'fifu_input_video_background_single', 'fifu_video_background_single' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_video_privacy' ) ) {
            self::update_single_option( 'fifu_input_video_privacy', 'fifu_video_privacy' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_vimeo_access_token' ) ) {
            self::update_single_option( 'fifu_input_vimeo_access_token', 'fifu_vimeo_access_token' );

            $token = trim( (string) get_option( 'fifu_vimeo_access_token' ) );
            if ( '' === $token ) {
                update_option( 'fifu_vimeo_access_token_scopes', '', false );
            } else {
                update_option( 'fifu_vimeo_access_token_scopes', self::detect_vimeo_access_token_scopes( $token ), false );
            }

            if ( ! class_exists( \Fifu_Video_Oembed_Service::class, false ) ) {
                require_once dirname( (string) FIFU_PLUGIN_FILE ) . '/includes/video/bootstrap.php';
            }

            \Fifu_Video_Oembed_Service::instance()->delete_vimeo_oembed_cache();
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_vimeo_mp4_rendition' ) ) {
            self::update_single_option( 'fifu_input_vimeo_mp4_rendition', 'fifu_vimeo_mp4_rendition' );

            if ( ! class_exists( \Fifu_Video_Oembed_Service::class, false ) ) {
                require_once dirname( (string) FIFU_PLUGIN_FILE ) . '/includes/video/bootstrap.php';
            }

            \Fifu_Video_Oembed_Service::instance()->delete_vimeo_oembed_cache();
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_video_later' ) ) {
            self::update_single_option( 'fifu_input_video_later', 'fifu_video_later' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_video_later_left' ) ) {
            self::update_single_option( 'fifu_input_video_later_left', 'fifu_video_later_left' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_loop' ) ) {
            self::update_single_option( 'fifu_input_loop', 'fifu_loop' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_mouse_video' ) ) {
            self::update_single_option( 'fifu_input_mouse_video', 'fifu_mouse_video' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_video' ) ) {
            self::update_single_option( 'fifu_input_video', 'fifu_video' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_video_thumb' ) ) {
            self::update_single_option( 'fifu_input_video_thumb', 'fifu_video_thumb' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_video_thumb_page' ) ) {
            self::update_single_option( 'fifu_input_video_thumb_page', 'fifu_video_thumb_page' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_video_thumb_post' ) ) {
            self::update_single_option( 'fifu_input_video_thumb_post', 'fifu_video_thumb_post' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_video_thumb_cpt' ) ) {
            self::update_single_option( 'fifu_input_video_thumb_cpt', 'fifu_video_thumb_cpt' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_video_play_button' ) ) {
            self::update_single_option( 'fifu_input_video_play_button', 'fifu_video_play_button' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_video_play_hide_grid' ) ) {
            self::update_single_option( 'fifu_input_video_play_hide_grid', 'fifu_video_play_hide_grid' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_video_play_hide_grid_wc' ) ) {
            self::update_single_option( 'fifu_input_video_play_hide_grid_wc', 'fifu_video_play_hide_grid_wc' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_video_controls' ) ) {
            self::update_single_option( 'fifu_input_video_controls', 'fifu_video_controls' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_auto_category' ) ) {
            self::update_single_option( 'fifu_input_auto_category', 'fifu_auto_category' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_taxonomy' ) ) {
            self::update_single_option( 'fifu_input_taxonomy', 'fifu_taxonomy' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_data_clean' ) ) {
            self::update_single_option( 'fifu_input_data_clean', 'fifu_data_clean' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_play_type' ) ) {
            self::update_single_option( 'fifu_input_play_type', 'fifu_play_type' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_upload_show' ) ) {
            self::update_single_option( 'fifu_input_upload_show', 'fifu_upload_show' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_upload_proxy' ) ) {
            self::update_single_option( 'fifu_input_upload_proxy', 'fifu_upload_proxy' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_upload_job' ) ) {
            self::update_single_option( 'fifu_input_upload_job', 'fifu_upload_job' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_upload_private_proxy' ) ) {
            self::update_single_option( 'fifu_input_upload_private_proxy', 'fifu_upload_private_proxy' );
        }

        if ( self::is_valid_nonce( 'nonce_fifu_form_bbpress_fields' ) ) {
            self::update_single_option( 'fifu_input_bbpress_fields', 'fifu_bbpress_fields' );
        }

        if ( Fifu_Options_Utils::is_on( 'fifu_run_delete_all' ) ) {
            update_option( 'fifu_run_delete_all_time', current_time( 'mysql' ), 'no' );
        }

        $arr = array();

        if ( isset( $_POST['fifu_input_default_url'] ) ) {
            $arr['fifu_default_url'] = wp_strip_all_tags( $_POST['fifu_input_default_url'] );
        } else {
            $default_url = get_option( 'fifu_default_url' );
            $arr['fifu_default_url'] = $default_url ? $default_url : '';
        }

        if ( isset( $_POST['fifu_input_default_cpt'] ) ) {
            $arr['fifu_default_cpt'] = wp_strip_all_tags( $_POST['fifu_input_default_cpt'] );
        } else {
            $arr['fifu_default_cpt'] = null;
        }

        if ( isset( $_POST['fifu_input_pcontent_types'] ) ) {
            $arr['fifu_pcontent_types'] = wp_strip_all_tags( $_POST['fifu_input_pcontent_types'] );
        } else {
            $arr['fifu_pcontent_types'] = null;
        }

        if ( isset( $_POST['fifu_input_hide_format'] ) ) {
            $arr['fifu_hide_format'] = wp_strip_all_tags( $_POST['fifu_input_hide_format'] );
        } else {
            $arr['fifu_hide_format'] = null;
        }

        if ( isset( $_POST['fifu_input_hide_type'] ) ) {
            $arr['fifu_hide_type'] = wp_strip_all_tags( $_POST['fifu_input_hide_type'] );
        } else {
            $arr['fifu_hide_type'] = null;
        }

        return $arr;
    }

    /**
     * Detect Vimeo access-token scopes.
     */
    private static function detect_vimeo_access_token_scopes( string $token ): string {
        $token = trim( $token );

        if ( '' === $token ) {
            return '';
        }

        $response = wp_remote_get( 'https://api.vimeo.com/oauth/verify', array(
            'timeout' => 10,
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Accept' => 'application/json',
            ),
        ) );

        if ( is_wp_error( $response ) ) {
            return '';
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        if ( $code < 200 || $code >= 300 ) {
            return '';
        }

        $body = json_decode( (string) wp_remote_retrieve_body( $response ), true );
        if ( ! is_array( $body ) ) {
            return '';
        }

        $scopes = array();

        if ( isset( $body['scope'] ) && is_string( $body['scope'] ) ) {
            $scopes = preg_split( '/\s+/', trim( $body['scope'] ) ) ?: array();
        } elseif ( isset( $body['scopes'] ) && is_array( $body['scopes'] ) ) {
            $scopes = $body['scopes'];
        }

        $scopes = array_values( array_filter( array_map( static function ( $scope ): string {
            return trim( (string) $scope );
        }, $scopes ), static function ( string $scope ): bool {
            return '' !== $scope;
        } ) );

        if ( ! $scopes ) {
            return '';
        }

        return implode( ', ', $scopes );
    }

    /**
     * Validate and persist a single option from the request body.
     *
     * @param string $input_name  Input field name submitted via the settings form.
     * @param string $option_name Corresponding option key to update.
     */
    public static function update_single_option( string $input_name, string $option_name ): void {
        if ( ! isset( $_POST[ $input_name ] ) ) {
            return;
        }

        $value = $_POST[ $input_name ] ?? '';

        if ( 'fifu_vimeo_mp4_rendition' === $option_name ) {
            $rendition = trim( (string) $value );

            if ( in_array( $rendition, array( '1080p', '720p', '540p', '360p', '240p' ), true ) ) {
                update_option( $option_name, $rendition, 'no' );
            }

            return;
        }

        $arr_boolean = array(
            'fifu_adaptive_height',
            'fifu_videos_before',
            'fifu_variations_merge',
            'fifu_taxonomy',
            'fifu_auto_category',
            'fifu_auto_set',
            'fifu_autoplay',
            'fifu_autoplay_front',
            'fifu_autoplay_front_all',
            'fifu_autoplay_elsewhere',
            'fifu_bbpress_fields',
            'fifu_block',
            'fifu_buy',
            'fifu_cdn_content',
            'fifu_cron_metadata',
            'fifu_data_clean',
            'fifu_enable_default_url',
            'fifu_fake',
            'fifu_finder',
            'fifu_gallery',
            'fifu_get_first',
            'fifu_hide',
            'fifu_pcontent_add',
            'fifu_pcontent_remove',
            'fifu_isbn',
            'fifu_asin',
            'fifu_customfield',
            'fifu_debug',
            'fifu_loop',
            'fifu_mouse_video',
            'fifu_ovw_first',
            'fifu_photon',
            'fifu_otfcdn',
            'fifu_own_domain',
            'fifu_popup',
            'fifu_redirection',
            'fifu_auto_share',
            'fifu_auto_share_facebook',
            'fifu_auto_share_instagram',
            'fifu_auto_share_x',
            'fifu_reset',
            'fifu_run_delete_all',
            'fifu_slider',
            'fifu_slider_auto',
            'fifu_slider_counter',
            'fifu_slider_crop',
            'fifu_slider_single',
            'fifu_slider_ctrl',
            'fifu_slider_gallery',
            'fifu_slider_stop',
            'fifu_slider_thumb',
            'fifu_slider_vertical',
            'fifu_screenshot',
            'fifu_update_all',
            'fifu_upload_job',
            'fifu_upload_proxy',
            'fifu_upload_show',
            'fifu_order_email',
            'fifu_video',
            'fifu_video_background',
            'fifu_video_background_single',
            'fifu_video_privacy',
            'fifu_video_later',
            'fifu_video_later_left',
            'fifu_video_controls',
            'fifu_video_finder',
            'fifu_amazon_finder',
            'fifu_video_mute',
            'fifu_video_mute_mobile',
            'fifu_video_play_button',
            'fifu_video_play_hide_grid',
            'fifu_video_play_hide_grid_wc',
            'fifu_video_thumb',
            'fifu_video_thumb_cpt',
            'fifu_video_thumb_page',
            'fifu_video_thumb_post',
            'fifu_wc_lbox',
            'fifu_wc_zoom',
            'fifu_cloud_upload_auto',
            'fifu_cloud_delete_auto',
            'fifu_cloud_hotlink',
            'fifu_validate_featured_image_urls',
        );
        if ( in_array( $option_name, $arr_boolean, true ) ) {
            if ( in_array( $value, array( 'on', 'off' ), true ) ) {
                update_option( $option_name, 'toggle' . $value );
            }

            return;
        }

        if ( 'fifu_video_min_width' === $option_name ) {
            $normalized_value = self::normalize_positive_integer_option_value( $value );

            if ( null !== $normalized_value ) {
                update_option( $option_name, $normalized_value );
            }

            return;
        }

        $arr_non_negative_int = array(
            'fifu_auto_set_height',
            'fifu_auto_set_width',
            'fifu_slider_pause',
            'fifu_slider_speed',
        );
        if ( in_array( $option_name, $arr_non_negative_int, true ) ) {
            $normalized_value = self::normalize_non_negative_integer_option_value( $value );

            if ( null !== $normalized_value ) {
                update_option( $option_name, $normalized_value );
            }

            return;
        }

        $arr_int = array( 'fifu_video_zindex', 'fifu_video_size' );
        if ( in_array( $option_name, $arr_int, true ) ) {
            if ( filter_var( $value, FILTER_VALIDATE_INT ) ) {
                update_option( $option_name, $value );
            }

            return;
        }

        $arr_hex = array( 'fifu_key' );
        if ( in_array( $option_name, $arr_hex, true ) ) {
            if ( filter_var( trim( $value ), FILTER_VALIDATE_REGEXP, array( 'options' => array( 'regexp' => '/^[a-z0-9-]+$/' ) ) ) ) {
                update_option( $option_name, trim( $value ) );
            }

            return;
        }

        $arr_hex = array( 'fifu_screenshot_size' );
        if ( in_array( $option_name, $arr_hex, true ) ) {
            if ( filter_var( trim( $value ), FILTER_VALIDATE_REGEXP, array( 'options' => array( 'regexp' => '/^\d{1,4}x\d{1,4}$/' ) ) ) ) {
                update_option( $option_name, trim( $value ) );
            }

            return;
        }

        $arr_email = array( 'fifu_email' );
        if ( in_array( $option_name, $arr_email, true ) ) {
            if ( filter_var( $value, FILTER_VALIDATE_EMAIL ) ) {
                update_option( $option_name, $value );
            }

            return;
        }

        $arr_play_type = array( 'fifu_play_type' );
        if ( in_array( $option_name, $arr_play_type, true ) ) {
            if ( in_array( $value, array( 'inline', 'lightbox' ), true ) ) {
                update_option( $option_name, $value );
            }

            return;
        }

        $arr_square_type = array( 'fifu_square_mobile', 'fifu_square_desktop' );
        if ( in_array( $option_name, $arr_square_type, true ) ) {
            if ( in_array( $value, array( '', 'crop', 'extend' ), true ) ) {
                update_option( $option_name, $value );
            }

            return;
        }

        $arr_url = array( 'fifu_default_url', 'fifu_error_url', 'fifu_slider_left', 'fifu_slider_right' );
        if ( in_array( $option_name, $arr_url, true ) ) {
            if ( ! is_scalar( $value ) ) {
                return;
            }

            $raw_value = (string) $value;

            if ( '' === $raw_value ) {
                update_option( $option_name, '' );
                return;
            }

            $trimmed_value = trim( $raw_value );

            if ( '' === $trimmed_value ) {
                return;
            }

            if ( filter_var( $trimmed_value, FILTER_VALIDATE_URL ) ) {
                update_option( $option_name, esc_url_raw( $trimmed_value ) );
            }

            return;
        }

        $arr_textarea = array( 'fifu_auto_set_blocklist' );
        if ( in_array( $option_name, $arr_textarea, true ) ) {
            update_option( $option_name, sanitize_textarea_field( $value ) );

            return;
        }

        $arr_text = array(
            'fifu_auto_set_cpt',
            'fifu_auto_set_source',
            'fifu_auto_set_layout',
            'fifu_html_media',
            'fifu_upload_domain',
            'fifu_default_cpt',
            'fifu_pcontent_types',
            'fifu_hide_format',
            'fifu_hide_type',
            'fifu_finder_custom_field',
            'fifu_isbn_custom_field',
            'fifu_asin_custom_field',
            'fifu_asin_credentials_partner',
            'fifu_asin_credentials_access',
            'fifu_asin_credentials_secret',
            'fifu_asin_credentials_locale',
            'fifu_auto_share_x_clientid',
            'fifu_screenshot_custom_field',
            'fifu_customfield_custom_field',
            'fifu_skip',
            'fifu_html_cpt',
            'fifu_upload_private_proxy',
            'fifu_video_color',
            'fifu_vimeo_access_token',
            'fifu_buy_text',
            'fifu_buy_disclaimer',
            'fifu_buy_cf',
        );
        if ( in_array( $option_name, $arr_text, true ) ) {
            update_option( $option_name, sanitize_text_field( $value ) );
        }
    }

    /**
     * Normalize a positive integer option value.
     *
     * @param mixed $value Raw submitted value.
     * @return string|null Normalized string when valid, null otherwise.
     */
    private static function normalize_positive_integer_option_value( $value ): ?string {
        if ( ! is_scalar( $value ) ) {
            return null;
        }

        $value = trim( (string) $value );

        if ( ! preg_match( '/^[1-9][0-9]*$/', $value ) ) {
            return null;
        }

        return $value;
    }

    /**
     * Normalize a non-negative integer option value.
     *
     * @param mixed $value Raw submitted value.
     * @return string|null Normalized string when valid, null otherwise.
     */
    private static function normalize_non_negative_integer_option_value( $value ): ?string {
        if ( ! is_scalar( $value ) ) {
            return null;
        }

        $value = trim( (string) $value );

        if ( ! preg_match( '/^(0|[1-9][0-9]*)$/', $value ) ) {
            return null;
        }

        return $value;
    }

    /**
     * Validate a nonce used for settings submissions.
     *
     * @param string $nonce_field Nonce field name from the request payload.
     * @param string $action      Action name used when the nonce was generated.
     *
     * @return bool True when the nonce is valid for the given action.
     */
    public static function is_valid_nonce( string $nonce_field, ?string $action = null ): bool {
        $default_action = 'fifu_settings_action';
        if ( defined( 'Fifu_Admin_Menu::ACTION_SETTINGS' ) ) {
            $default_action = Fifu_Admin_Menu::ACTION_SETTINGS;
        }

        if ( $action === null ) {
            $action = $default_action;
        }

        return isset( $_POST[ $nonce_field ] ) && wp_verify_nonce( $_POST[ $nonce_field ], $action );
    }
}
