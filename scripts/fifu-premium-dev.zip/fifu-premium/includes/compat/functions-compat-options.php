<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once __DIR__ . '/class-fifu-options-cleanup.php';

function fifu_db_delete_deprecated_data(): void {
    global $wpdb;
    Fifu_Options_Cleanup::delete_deprecated_options( $wpdb );
}

if ( ! function_exists( 'fifu_is_on' ) ) {
    /**
     * Compatibility wrapper for legacy call sites that expect the global helper.
     *
     * @param string $option
     * @return bool
     */
    function fifu_is_on( string $option ): bool {
        return class_exists( 'Fifu_Options_Utils', false ) && Fifu_Options_Utils::is_on( $option );
    }
}
