<?php

defined( 'ABSPATH' ) || exit;

/**
 * Multisite license propagation helpers for FIFU Premium.
 *
 * @package Fifu_Premium
 */
class Fifu_Multisite_License {

    public static function propagate_key( $network_wide ) {
        if ( ! is_multisite() || ! $network_wide ) {
            return;
        }

        global $wpdb;
        $blogs = $wpdb->get_results( "SELECT blog_id FROM $wpdb->blogs" );

        if ( ! $blogs ) {
            return;
        }

        $key   = get_option( 'fifu_key' );
        $email = get_option( 'fifu_email' );

        foreach ( $blogs as $blog ) {
            $blog_id = (int) $blog->blog_id;

            switch_to_blog( $blog_id );
            try {
                update_option( 'fifu_key', $key );
                update_option( 'fifu_email', $email );
            } finally {
                restore_current_blog();
            }
        }
    }
}
