<?php

defined('ABSPATH') || exit;

global $post;

if (!isset($post) || !isset($post->ID)) {
    return;
}

do_action('fifu_render_woocommerce_gallery_template');
