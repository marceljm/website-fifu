function fifu_get_popup_html(post_id) {
    if (typeof fifuPopupVars === 'undefined' || !fifuPopupVars || !fifuPopupVars.html)
        return null;

    return fifuPopupVars.html[post_id] || fifuPopupVars.html[String(post_id)] || null;
}

function fifu_has_popup_html(post_id) {
    return !!fifu_get_popup_html(post_id);
}

jQuery(document).ready(function () {
    jQuery('body').on('click', function (e) {
        if (jQuery('.fancybox-content').length)
            return;

        let $target = jQuery(e.target);
        let $popupSource = null;

        if ($target.is('img[fifu-featured]')) {
            $popupSource = $target;
        } else if ($target.is('a') && $target.has('img[fifu-featured]').length) {
            $popupSource = $target;
        } else {
            let $backgroundSource = $target.closest('*[style*=background-image]');
            if ($backgroundSource.length)
                $popupSource = $backgroundSource;
        }

        if (!$popupSource || !$popupSource.length)
            return;

        let post_id = $popupSource.attr('post-id');
        if (!post_id || !fifu_has_popup_html(post_id))
            return;

        e.preventDefault();
        e.stopPropagation();

        fifu_open_popup(post_id);
    });
});

function fifu_open_popup(post_id) {
    let html = fifu_get_popup_html(post_id);
    if (!html)
        return;

    let opts = {
        toolbar: false,
        downloadButton: true,
        closeBtn: false,
    }

    let $html = jQuery(normalizeString(html));
    let $embed = $html.children().first();
    if (!$embed || !$embed.length)
        $embed = $html;

    $embed.css('width', '101%');
    $embed.css('height', '100%');

    jQuery.fancybox.open($html, opts);

    $html.css({
        width: $embed.width() + 'px',
        height: $embed.height() + 'px'
    });
}

function normalizeString(str) {
    var tempEl = jQuery('<div/>').html(str);
    let isMobile = window.innerWidth <= 768;
    let w_ratio = isMobile ? 0.95 : 0.85;
    let h_ratio = isMobile ? 0.95 : 0.85;
    let w = jQuery(window).width() * w_ratio;
    let h = jQuery(window).height() * h_ratio;
    let max_w = jQuery(window).width();
    let max_h = jQuery(window).height() * 0.95;
    return `<div class="fifu-popup-container" style="width:${w}px; height:${h}px; max-width:${max_w}px; max-height:${max_h}px;">${tempEl.text()}</div>`;
}
