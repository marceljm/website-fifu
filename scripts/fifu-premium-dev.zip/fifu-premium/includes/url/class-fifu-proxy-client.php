<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Object-oriented replacement for the legacy admin proxy helpers.
 */
final class Fifu_Proxy_Client
{
    /** @var callable|null */
    private static $proxy_downloader = null;

    /**
     * Attempts to download a remote resource using cached, private, or scraped proxies.
     *
     * @param string $url      The remote URL that should be downloaded.
     * @param bool   $get_html Whether HTML payloads are acceptable.
     *
     * @return string|null Binary data, HTML, or null on failure.
     */
    public static function download(string $url, bool $get_html)
    {
        $host = Fifu_Image_Url_Utils::get_host($url);
        $has_private_proxy = trim((string) get_option('fifu_upload_private_proxy')) !== '';
        $content = null;

        if ($has_private_proxy) {
            delete_option('fifu_cache_proxy');

            $proxies = self::get_list();
            foreach ($proxies as $proxy) {
                $params = [];
                for ($j = 0; $j <= 3; $j++) {
                    $params[] = $proxy[$j] ?? null;
                }

                Fifu_File_Logger::plugin([
                    'fifu_proxy_download' => [
                        'Trying private proxy' => ($params[0] ?? 'N/A') . ':' . ($params[1] ?? 'N/A'),
                    ],
                ]);

                $content = self::download_via_proxy($url, $params[0] ?? null, $params[1] ?? null, $params[2] ?? null, $params[3] ?? null, $get_html);
                if ($content === 'invalid-type') {
                    continue;
                }

                if ($content) {
                    break;
                }
            }

            return self::finalize_download_result($content, $get_html);
        }

        $cache_proxy = self::get_cache();

        if ($cache_proxy) {
            foreach ($cache_proxy as $i => $proxy) {
                if (isset($proxy[$host])) {
                    $params = [];
                    for ($j = 0; $j <= 3; $j++) {
                        $params[] = $proxy[$host][$j] ?? null;
                    }

                    Fifu_File_Logger::plugin(['fifu_proxy_download' => ['Cached proxy' => ($params[0] ?? 'N/A')]]);

                    $content = self::download_via_proxy($url, $params[0] ?? null, $params[1] ?? null, $params[2] ?? null, $params[3] ?? null, $get_html);
                    if (!$content) {
                        $content = self::download_via_proxy($url, $params[0] ?? null, $params[1] ?? null, $params[2] ?? null, $params[3] ?? null, $get_html);
                        if (!$content) {
                            unset($cache_proxy[$i]);
                        }
                    } else {
                        break;
                    }
                }
            }
        } else {
            $cache_proxy = [];
        }

        if (!$content) {
            $proxies = self::get_list();
            $i = 0;
            foreach ($proxies as $proxy) {
                $params = [];
                for ($j = 0; $j <= 3; $j++) {
                    $params[] = $proxy[$j] ?? null;
                }

                Fifu_File_Logger::plugin([
                    'fifu_proxy_download' => [
                        'Trying proxy' => "{$i}: " . ($params[0] ?? 'N/A') . ':' . ($params[1] ?? 'N/A'),
                    ],
                ]);
                $i++;

                $content = self::download_via_proxy($url, $params[0] ?? null, $params[1] ?? null, $params[2] ?? null, $params[3] ?? null, $get_html);
                if ($content === 'invalid-type') {
                    continue;
                }

                if ($content) {
                    $cache_proxy[] = [$host => $proxy];
                    self::set_cache($cache_proxy);
                    Fifu_File_Logger::plugin(['fifu_proxy_download' => ['Notice' => 'Good one!']]);
                    break;
                }
            }
        }

        return self::finalize_download_result($content, $get_html);
    }

    /**
     * Finalizes a proxy download result for HTML or binary payloads.
     *
     * @param string|null $content
     * @param bool        $get_html
     *
     * @return string|null
     */
    private static function finalize_download_result(?string $content, bool $get_html): ?string
    {
        if ($get_html) {
            return $content;
        } elseif ($content) {
            $tmp = get_temp_dir() . date('Ymd-His') . '.jpg';
            file_put_contents($tmp, $content);
            return $tmp;
        }

        return null;
    }

    /**
     * Parses the configured private proxies or falls back to scraped proxies.
     *
     * @return array<int, array{0?: string, 1?: string, 2?: string|null, 3?: string|null}>
     */
    private static function get_list(): array
    {
        $private = get_option('fifu_upload_private_proxy');
        if ($private) {
            $list = [];
            preg_match_all("/([^ ,]+[:][^ ,]+[@])*([0-9]{1,3}[.]){3}[0-9]{1,3}[:][0-9]{1,5}/", $private, $matches);
            foreach ($matches[0] as $match) {
                $match_parts = explode('@', $match);
                if (count($match_parts) > 1) {
                    [$username, $password] = self::parse_credentials($match_parts[0] ?? '');
                    [$proxy, $port] = self::parse_address($match_parts[1] ?? '');
                } else {
                    $username = null;
                    $password = null;
                    [$proxy, $port] = self::parse_address($match_parts[0] ?? '');
                }

                $list[] = [$proxy, $port, $username, $password];
            }

            return $list;
        }

        $list = Fifu_Transient_Manager::get('fifu_proxy_list');
        if ($list) {
            return $list;
        }

        $list = self::scrape();
        if ($list) {
            Fifu_Transient_Manager::set('fifu_proxy_list', $list, 300);
        }

        return $list ?? [];
    }

    /**
     * Fetches a fresh list of proxy candidates from the remote worker.
     *
     * @return array<int, array>|null
     */
    private static function scrape(): ?array
    {
        $queryParams = http_build_query([
            'site' => Fifu_Image_Url_Utils::get_home_url_no_scheme(),
            'partial_key' => Fifu_Options_Utils::partial_key(),
        ]);
        $workerUrl = 'https://free-proxy-list.fifu.workers.dev?' . $queryParams;

        try {
            $response = wp_remote_get($workerUrl);

            if (is_wp_error($response) || wp_remote_retrieve_response_code($response) != 200) {
                return null;
            }

            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);

            if (!empty($data['proxies'] ?? null)) {
                return $data['proxies'];
            }
        } catch (Exception $e) {
            error_log('fifu-proxy: ' . $e->getMessage());
        }

        return null;
    }

    /**
     * Reads the cached proxies for the current host.
     *
     * @return array<int, array>|null
     */
    private static function get_cache(): ?array
    {
        $cache = get_option('fifu_cache_proxy');
        return $cache ? unserialize($cache) : null;
    }

    /**
     * Persists the proxy cache so future downloads can reuse hosts.
     *
     * @param array<int, array> $cache
     */
    private static function set_cache(array $cache): void
    {
        update_option('fifu_cache_proxy', serialize($cache), 'no');
    }

    /**
     * Executes a cURL request through a proxy server.
     *
     * @param string      $url      URL to download.
     * @param string|null $ip       Proxy IP address.
     * @param string|null $port     Proxy port.
     * @param string|null $user     Proxy username.
     * @param string|null $password Proxy password.
     * @param bool        $get_html Whether HTML payloads are allowed.
     *
     * @return string|null
     */
    private static function download_via_proxy(string $url, ?string $ip, ?string $port, ?string $user, ?string $password, bool $get_html): ?string
    {
        if (is_callable(self::$proxy_downloader)) {
            return (string) call_user_func(self::$proxy_downloader, $url, $ip, $port, $user, $password, $get_html);
        }

        $crl = curl_init();
        curl_setopt($crl, CURLOPT_PROXY, "{$ip}:{$port}");
        curl_setopt($crl, CURLOPT_URL, $url);
        curl_setopt($crl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($crl, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($crl, CURLOPT_HTTPPROXYTUNNEL, false);
        curl_setopt($crl, CURLOPT_FOLLOWLOCATION, false);
        curl_setopt($crl, CURLOPT_VERBOSE, true);

        if ($get_html) {
            curl_setopt($crl, CURLOPT_ENCODING, '');
        }

        if ($user) {
            curl_setopt($crl, CURLOPT_PROXYUSERPWD, "{$user}:{$password}");
        }

        try {
            $ret = curl_exec($crl);
        } catch (Exception $e) {
            unset($crl);
            return null;
        }

        $content_type = curl_getinfo($crl, CURLINFO_CONTENT_TYPE);
        unset($crl);

        if ($get_html) {
            return $ret;
        } elseif ($content_type) {
            if (strpos($content_type, 'image') !== false) {
                return $ret;
            }

            return 'invalid-type';
        }

        return null;
    }

    /**
     * Splits stored credentials into username/password.
     *
     * @param string $raw Raw credential string.
     *
     * @return array{0?: string|null, 1?: string|null}
     */
    private static function parse_credentials(string $raw): array
    {
        $parts = explode(':', $raw);
        return [
            $parts[0] ?? null,
            $parts[1] ?? null,
        ];
    }

    /**
     * Splits a proxy address into IP and port.
     *
     * @param string $raw Raw proxy address.
     *
     * @return array{0?: string|null, 1?: string|null}
     */
    private static function parse_address(string $raw): array
    {
        $parts = explode(':', $raw);
        return [
            $parts[0] ?? null,
            $parts[1] ?? null,
        ];
    }
}
