<?php

declare( strict_types=1 );

defined( 'ABSPATH' ) || exit;

/**
 * Placeholder service for OTF/CDN URL operations pending migration.
 */
class Fifu_Otf_Url_Service {

    /**
     * Future: builds a signed OTF URL for an image.
     */
    public static function get_image_url( ?int $attachment_id, string $image_url, ?string $qp ): string {
        $encoded_url = Fifu_Image_Url_Utils::base64( $image_url );

        if ( $attachment_id ) {
            $alt = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
            $slug = $alt ? $alt : Fifu_Post_Meta_Utils::get_parent_slug( $attachment_id );
            $post = get_post( $attachment_id );
            $post_id = $post ? ( $post->post_parent ?? null ) : null;
        } else {
            $slug = 'not-found';
            $post_id = null;
        }

        $decoded_string = urldecode( $slug );
        $normalized_slug = $decoded_string;
        if ( function_exists( 'transliterator_transliterate' ) ) {
            $transliterated = transliterator_transliterate( 'Any-Latin; Latin-ASCII', $decoded_string );
            if ( is_string( $transliterated ) ) {
                $normalized_slug = $transliterated;
            }
        }

        $ascii_slug = preg_replace( '/[^\x20-\x7E]/u', '', $normalized_slug );
        $normalized_slug = is_string( $ascii_slug ) ? $ascii_slug : '';

        $post_slug = sanitize_title( $normalized_slug );
        $post_slug = $post_slug ?: 'image';

        $prefix  = Fifu_Options_Utils::is_own_domain_effective() ? "//img." : "//i0.fifu.app/";
        $base_url = str_replace( "//", $prefix, get_home_url() ) . '/' . $post_slug . '.webp';

        $params = [];
        $qp_string = $qp ?? '';
        if ( $qp_string !== '' ) {
            $qp_string = ltrim( $qp_string, '?' );
            parse_str( $qp_string, $params );
        }

        if ( $post_id ) {
            $params['p'] = $post_id;
        }
        $params['u'] = $encoded_url;

        if ( wp_is_mobile() ) {
            $square_mobile = get_option( 'fifu_square_mobile' );
            if ( $square_mobile ) {
                $params['sq'] = 1;
                $params['c']  = $square_mobile === 'crop' ? 1 : 0;
            }
        } else {
            $square_desktop = get_option( 'fifu_square_desktop' );
            if ( $square_desktop ) {
                $params['sq'] = 1;
                $params['c']  = $square_desktop === 'crop' ? 1 : 0;
            }
        }

        self::add_session_params( $params, $image_url, $post_id );

        $url_for_signature = $base_url;
        if ( ! empty( $params ) ) {
            $url_for_signature .= '?' . http_build_query( $params );
        }

        $signature = self::get_signature( $url_for_signature, get_option( 'fifu_otf_token' ) );
        $signed_url = self::add_signature_to_url( $base_url, $signature );

        if ( ! empty( $params ) ) {
            $signed_url .= '?' . http_build_query( $params );
        }

        return $signed_url;
    }

    /**
     * Future: resizes an OTF URL to a specific width.
     */
    public static function resize( int $size, string $url ): string {
        $size = (int) $size;

        $url = self::remove_signature_from_url( $url );

        $parsed_url = parse_url( $url );
        $clean_url  = ( $parsed_url['scheme'] ?? 'https' ) . '://' . ( $parsed_url['host'] ?? '' ) . ( $parsed_url['path'] ?? '' );

        $params = [];
        if ( isset( $parsed_url['query'] ) ) {
            parse_str( $parsed_url['query'], $existing_params );
            foreach ( $existing_params as $key => $value ) {
                if ( ! in_array( $key, ['w', 'h', 'c'], true ) ) {
                    $params[ $key ] = $value;
                }
            }
        }

        $params['w'] = $size;
        $params['h'] = 0;
        $params['c'] = 0;

        $url_for_signature = $clean_url;
        if ( ! empty( $params ) ) {
            $url_for_signature .= '?' . http_build_query( $params );
        }

        $new_signature = self::get_signature( $url_for_signature, get_option( 'fifu_otf_token' ) );
        $signed_url    = self::add_signature_to_url( $clean_url, $new_signature );

        if ( ! empty( $params ) ) {
            $signed_url .= '?' . http_build_query( $params );
        }

        return $signed_url;
    }

    /**
     * Future: builds the responsive OTF srcset.
     */
    public static function get_srcset( string $url, bool $is_slider ): string {
        $quality = $is_slider ? 1.1 : 1;
        $set     = '';
        $count   = 0;
        foreach ( Fifu_Jetpack_Cdn_Service::JETPACK_SIZES as $i ) {
            $set .= ( $count++ !== 0 ? ', ' : '' ) . self::resize( (int) ( $i * $quality ), $url ) . ' ' . $i . 'w';
        }
        return $set;
    }

    /**
     * Future: reads the original image dimensions from the headers.
     *
     * @return array{0:int,1:int}
     */
    public static function get_original_image_dimensions( string $url ): array {
        $headers = static::fetch_headers( $url );

        $width  = '';
        $height = '';

        foreach ( explode( "\n", $headers ) as $header ) {
            if ( stripos( $header, 'x-original-img-width:' ) !== false ) {
                $width = (int) trim( str_ireplace( 'x-original-img-width:', '', $header ) );
            }
            if ( stripos( $header, 'x-original-img-height:' ) !== false ) {
                $height = (int) trim( str_ireplace( 'x-original-img-height:', '', $header ) );
            }
        }

        return [$width, $height];
    }

    /**
     * Seam for testing: read only headers for a URL.
     *
     * @param string $url
     * @return string
     */
    protected static function fetch_headers( string $url ): string {
        $ch = curl_init();
        curl_setopt_array(
            $ch,
            [
                CURLOPT_URL            => $url,
                CURLOPT_HEADER         => true,
                CURLOPT_NOBODY         => true,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_USERAGENT      => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            ]
        );

        $headers = curl_exec( $ch );

        return (string) $headers;
    }

    /**
     * Future: generates the URL HMAC signature.
     */
    public static function get_signature( string $url, string $token ): string {
        $hash = hash_hmac( 'sha256', $url, $token, true );
        $signature = substr( bin2hex( $hash ), 0, 12 );
        return $signature;
    }

    /**
     * Future: removes the signature from the URL path.
     */
    private static function remove_signature_from_url( string $url ): string {
        $parsed_url = parse_url( $url );
        $path       = $parsed_url['path'] ?? '';

        $path_parts = explode( '/', trim( $path, '/' ) );

        if ( count( $path_parts ) >= 2 && strpos( $path_parts[ count( $path_parts ) - 1 ] ?? '', '.' ) !== false ) {
            $filename = $path_parts[ count( $path_parts ) - 1 ] ?? '';

            if ( count( $path_parts ) > 2 ) {
                array_splice( $path_parts, count( $path_parts ) - 2, 1 );
                $new_path = '/' . implode( '/', $path_parts );

                $result = ( $parsed_url['scheme'] ?? 'https' ) . '://' . ( $parsed_url['host'] ?? '' ) . $new_path;
                if ( isset( $parsed_url['query'] ) ) {
                    $result .= '?' . $parsed_url['query'];
                }
                return $result;
            }
        }

        return $url;
    }

    /**
     * Future: adds the signature as the penultimate path segment.
     */
    private static function add_signature_to_url( string $url, string $signature ): string {
        $parsed_url = parse_url( $url );
        $path       = $parsed_url['path'] ?? '';

        $path_parts = explode( '/', trim( $path, '/' ) );

        if ( count( $path_parts ) >= 1 && strpos( $path_parts[ count( $path_parts ) - 1 ] ?? '', '.' ) !== false ) {
            $filename = array_pop( $path_parts );

            $path_parts[] = $signature;
            $path_parts[] = $filename;

            $new_path = '/' . implode( '/', $path_parts );

            $result = ( $parsed_url['scheme'] ?? 'https' ) . '://' . ( $parsed_url['host'] ?? '' ) . $new_path;
            if ( isset( $parsed_url['query'] ) ) {
                $result .= '?' . $parsed_url['query'];
            }
            return $result;
        }

        return $url;
    }

    /**
     * Future: appends session parameters (video/audio) to the query.
     */
    private static function add_session_params( array &$params, string $image_url, ?int $post_id ): void {
        if ( Fifu_Options_Utils::is_on( 'fifu_video' ) ) {
            if ( Fifu_Video_Helper::is_video_thumb( $image_url ) ) {
                $video_src = Fifu_Video_Helper::get_embed_url_by_image( $image_url );
                $params['v'] = Fifu_Image_Url_Utils::base64( $video_src );
                return;
            }

            if ( $post_id ) {
                $custom_video_url = Fifu_Post_Custom_Video_Read_Service::get_custom_video_url( (int) $post_id );
                if ( $custom_video_url ) {
                    $permalink = get_permalink( $post_id );
                    $params['v'] = Fifu_Image_Url_Utils::base64( $custom_video_url );
                    $params['l'] = Fifu_Image_Url_Utils::base64( $permalink );
                    return;
                }
            }
        }

        if ( Fifu_Options_Utils::is_on( 'fifu_video' ) ) {
            $audio_url = Fifu_Post_Audio_Read_Service::get_audio_url( (int) $post_id );
            if ( $audio_url ) {
                $params['a'] = Fifu_Image_Url_Utils::base64( $audio_url );
            }
        }
    }
}
