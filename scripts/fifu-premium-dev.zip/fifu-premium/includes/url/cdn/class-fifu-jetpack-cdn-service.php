<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Responsible for Jetpack/Photon CDN interactions and feature parity with legacy helpers.
 */
final class Fifu_Jetpack_Cdn_Service
{
    /**
     * Holds the legacy Jetpack size options that powered the srcset generation.
     *
     * @var int[]
     */
    public const JETPACK_SIZES = [75, 100, 150, 240, 320, 500, 640, 800, 1024, 1280, 1600];

    /**
     * Domains that identify Jetpack Photon URLs.
     *
     * @var string[]
     */
    private const PHOTON_DOMAINS = ['wp.fifu.app'];

    /**
     * Blocked hostnames that should never be routed through Photon when OTF CDN is disabled.
     *
     * @var string[]
     */
    private const BLOCKED_HOSTS = [
        'localhost',
        'amazon-adsystem.com',
        'sapo.io',
        'image.influenster.com',
        'api.screenshotmachine.com',
        'img.brownsfashion.com',
        'fbcdn.net',
        'nitrocdn.com',
        'brightspotcdn.com',
        'realtysouth.com',
        'tiktokcdn.com',
        'fdcdn.akamaized.net',
        'blockchainstock.azureedge.net',
        'aa.com.tr',
        'cdn.discordapp.com',
        'download.schneider-electric.com',
        'cdn.fbsbx.com',
        'canva.com',
        'cdn.fifu.app',
        'cloud.fifu.app',
        'images.placeholders.dev',
    ];

    /**
     * Normalize various attachment identifier inputs into a positive integer.
     *
     * @param int|string|null $attachment_id
     * @return int|null
     */
    private static function normalize_attachment_id(int|string|null $attachment_id): ?int
    {
        if (is_int($attachment_id)) {
            return $attachment_id > 0 ? $attachment_id : null;
        }

        if (is_string($attachment_id)) {
            $normalized = filter_var(
                $attachment_id,
                FILTER_VALIDATE_INT,
                ['options' => ['min_range' => 1]]
            );

            if ($normalized !== false) {
                return $normalized;
            }
        }

        return null;
    }

    public static function is_jetpack_cdn_url(string $url): bool
    {
        if ($url === '') {
            return false;
        }

        foreach (self::PHOTON_DOMAINS as $domain) {
            if (strpos($url, $domain) !== false) {
                return true;
            }
        }

        return false;
    }

    public static function is_blocked_source(string $url): bool
    {
        if ($url === '') {
            return true;
        }

        if (Fifu_Options_Utils::is_on('fifu_otfcdn')) {
            return false;
        }

        if (self::is_jetpack_cdn_url($url)) {
            return true;
        }

        foreach (self::BLOCKED_HOSTS as $domain) {
            if (strpos($url, $domain) !== false) {
                return true;
            }
        }

        return false;
    }

    public static function resize($size, string $url): string
    {
        if (strpos($url, 'wp.fifu.app/') === false) {
            return $url;
        }

        $parts = parse_url($url);
        $path_parts = explode('/', trim($parts['path'] ?? '', '/'));
        $path_count = count($path_parts);

        $query = $parts['query'] ?? '';
        parse_str($query, $query_params);

        $query_params['w'] = $size;
        $query_params['h'] = 0;
        $query_params['c'] = 0;

        if ($path_count < 4) {
            return $url;
        }

        $signature_index = $path_count - 2;
        unset($path_parts[$signature_index]);
        $new_path = '/' . implode('/', $path_parts);
        $new_query = http_build_query($query_params);
        $unsigned_url = '//' . ($parts['host'] ?? '') . $new_path . ($new_query ? '?' . $new_query : '');
        $new_signature = Fifu_Otf_Url_Service::get_signature($unsigned_url, 'fifu');
        array_splice($path_parts, $signature_index, 0, $new_signature);
        $final_path = '/' . implode('/', $path_parts);
        return ($parts['scheme'] ?? 'https') . '://' . ($parts['host'] ?? '') . $final_path . ($new_query ? '?' . $new_query : '');
    }

    public static function build_srcset(string $url, bool $is_slider): string
    {
        $quality = $is_slider ? 1.1 : 1;
        $set = '';
        $count = 0;

        foreach (self::JETPACK_SIZES as $size) {
            $resized = self::resize($size * $quality, $url);
            $set .= ($count++ !== 0 ? ', ' : '') . $resized . ' ' . $size . 'w';
        }

        return $set;
    }

    public static function crop(string $url, float $w, float $h, float $p, float $q): string
    {
        $x = 0.0;
        $y = 0.0;
        $a = 0.0;
        $b = 0.0;

        if ($p !== $q) {
            if (($p / $q) >= ($w / $h)) {
                $a = $w;
                $b = $w * $q / $p;
                $y = ($h - $b) / 2;
            } else {
                $b = $h;
                $a = $h * $p / $q;
                $x = ($w - $a) / 2;
            }
        } else {
            if ($w >= $h) {
                $b = $h;
                $a = $h;
                $x = ($w - $a) / 2;
            } else {
                $a = $w;
                $b = $w;
                $y = ($h - $b) / 2;
            }
        }

        return sprintf('%s&crop=%spx,%spx,%spx,%spx', $url, $x, $y, $a, $b);
    }

    public static function build_photon_url(string $url, array|string|null $args, int|string|null $att_id): string
    {
        if (self::is_blocked_source($url)) {
            return $url;
        }

        $attachment_id = self::normalize_attachment_id($att_id);

        $arguments = '';
        if ($args) {
            if (is_array($args)) {
                $arguments = add_query_arg($args, '?');
            } else {
                $arguments = $args;
            }
        }

        if (Fifu_Options_Utils::is_on('fifu_otfcdn')) {
            if (Fifu_Generic_Utils::ends_with($url, '.svg')) {
                return str_replace(
                    '.webp',
                    '.svg',
                    Fifu_Otf_Url_Service::get_image_url($attachment_id, $url, '')
                );
            }

            $query = $arguments;
            return Fifu_Otf_Url_Service::get_image_url($attachment_id, $url, $query);
        }

        if (Fifu_Generic_Utils::ends_with($url, '.svg')) {
            return $url;
        }

        return Fifu_Pubcdn_Url_Service::get_image_url($attachment_id, $url, $arguments);
    }

    /**
     * Placeholder for the legacy fifu_get_photon_url behavior.
     *
     * This will eventually call Fifu_Attachment_Image_Src_Filter::apply_registered_size(),
     * Fifu_Jetpack_Cdn_Service::build_photon_url(), and delegate to
     * Fifu_Local_Media_Renderer::enrich_attachment_url().
     *
     * @param array    $image
     * @param mixed    $size
     * @param int      $attachment_id
     * @return array
     */
    public static function filter_photon_image(array $image, $size, int $attachment_id): array
    {
        $source_url = (string) ($image[0] ?? '');

        $result = Fifu_Attachment_Image_Src_Filter::apply_registered_size($image, $size);
        $image = $result['image'] ?? $image;
        $w = $image[1] ?? 0;
        $h = $image[2] ?? 0;
        $c = ($result['crop'] ?? false) ? 1 : 0;

        $optimized_url = self::build_photon_url($source_url, "?w={$w}&h={$h}&c={$c}", $attachment_id);
        self::record_cdn_source_mapping($optimized_url, $source_url);

        $image[0] = Fifu_Local_Media_Renderer::enrich_attachment_url($optimized_url, $attachment_id, $size);
        self::record_cdn_source_mapping((string) ($image[0] ?? ''), $source_url);

        return $image;
    }

    /**
     * Records the original source URL for an optimized/CDN URL.
     *
     * Frontend video detection uses this map to resolve optimized image URLs
     * back to provider thumbnails such as i.vimeocdn.com, img.youtube.com or
     * Speed Up video thumbnails before deciding whether to render a play button.
     */
    private static function record_cdn_source_mapping(string $cdn_url, string $source_url): void
    {
        if ($cdn_url === '' || $source_url === '' || $cdn_url === $source_url) {
            return;
        }

        global $FIFU_SESSION;

        if (!isset($FIFU_SESSION) || !is_array($FIFU_SESSION)) {
            $FIFU_SESSION = [];
        }

        if (!isset($FIFU_SESSION['cdn-new-old']) || !is_array($FIFU_SESSION['cdn-new-old'])) {
            $FIFU_SESSION['cdn-new-old'] = [];
        }

        $FIFU_SESSION['cdn-new-old'][$cdn_url] = $source_url;
    }

    public static function get_original_image_url(string $url): string
    {
        if (!self::is_jetpack_cdn_url($url)) {
            return $url;
        }

        return Fifu_Pubcdn_Url_Service::decode_pubcdn_url($url);
    }

    public static function replace_src(string $photon_url, string $error_url, ?int $att_id): string
    {
        if (Fifu_Options_Utils::is_on('fifu_otfcdn')) {
            if (strpos($photon_url, '//img.') === false && strpos($photon_url, '//i0.fifu.app') === false) {
                return $error_url;
            }

            $query_parameters = explode('?', $photon_url)[1] ?? '';
            $qp = $query_parameters ? '?' . $query_parameters : '';
            return Fifu_Otf_Url_Service::get_image_url(null, $error_url, $qp);
        }

        if (strpos($photon_url, 'wp.fifu.app/') === false) {
            return $error_url;
        }

        $query_parameters = explode('?', $photon_url)[1] ?? '';
        $query_parameters = explode('&p=', $query_parameters)[0] ?? $query_parameters;
        $qp = $query_parameters ? '?' . $query_parameters : '';
        return Fifu_Pubcdn_Url_Service::get_image_url($att_id, $error_url, $qp);
    }

    public static function filter_jetpack_photon_skip_image($skip, $image_url, $args = null): bool
    {
        if (is_string($image_url) && Fifu_Image_Url_Utils::is_remote_image_url($image_url)) {
            return true;
        }

        return (bool) $skip;
    }

    /**
     * Provides the square resize arguments that mirror the legacy photon helper.
     *
     * These arguments are consumed by Jetpack Photon and OTF CDN to ensure a square
     * thumbnail is always requested.
     *
     * @param int $size Width and height for the square image.
     * @param int $crop Flag that describes crop behaviour.
     * @return array<string,int>
     */
    public static function get_square_args(int $size, int $crop): array
    {
        if (Fifu_Options_Utils::is_on('fifu_otfcdn')) {
            return [
                'w' => $size,
                'h' => $size,
                'c' => $crop,
            ];
        }

        return [
            'resize' => "{$size},{$size}",
        ];
    }

    /**
     * Returns a Photon/CDN URL for a given image and records the legacy session map.
     *
     * @param string|false|null $url Source image URL.
     * @param int|string|null $attachment_id Optional attachment reference.
     * @param int|null $width Requested side length.
     * @param int|null $crop Crop indicator.
     * @return string
     */
    public static function get_cdn_url(
        string|false|null $url,
        int|string|null $attachment_id,
        ?int $width,
        ?int $crop
    ): string {
        if ( ! $url ) {
            return '';
        }
        if (Fifu_Options_Utils::is_off('fifu_photon')) {
            return $url;
        }

        global $FIFU_SESSION;

        $args = null;
        if (Fifu_Options_Utils::is_on('fifu_otfcdn')) {
            $args = self::get_square_args($width ?? 0, (int) ($crop ?? 1));
        }

        $new_url = self::build_photon_url($url, $args, $attachment_id);
        $FIFU_SESSION['cdn-new-old'][$new_url] = $url;

        return $new_url;
    }
}
