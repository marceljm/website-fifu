<?php

defined( 'ABSPATH' ) || exit;

/**
 * Static-only service class for tracking and sending CDN usage statistics.
 *
 * Future migration of fifu_update_cdn_stats, fifu_send_cdn_stats and fifu_is_bot_request
 * will occur within this class.
 *
 * @package Fifu_Premium
 */
class Fifu_Image_Cdn_Stats_Service {

    /**
     * Triggered when a CDN image is served to increment counters and possibly dispatch reports.
     *
     * @return void
     */
    public static function maybe_update_stats(): void {
        if ( function_exists( 'is_admin' ) && is_admin() ) {
            return;
        }

        if ( self::is_bot_request() ) {
            return;
        }

        $date       = ( new DateTime() )->format( 'Y-m-d' );
        $stats_date = get_option( 'fifu_stats_date' );

        if ( ! $stats_date ) {
            update_option( 'fifu_stats_date', $date );
            set_transient( 'fifu_stats_cdn_count', 1, 0 );
            return;
        }

        if ( $stats_date === $date ) {
            $cdn_count = get_transient( 'fifu_stats_cdn_count' ) ?? 0;
            set_transient( 'fifu_stats_cdn_count', $cdn_count + 1, 0 );
            return;
        }

        self::send_stats();
        delete_option( 'fifu_stats_date' );
        delete_transient( 'fifu_stats_cdn_count' );
    }

    /**
     * Perform an asynchronous POST to the remote stats endpoint when thresholds are met.
     *
     * @return bool
     */
    private static function send_stats(): bool {
        $date = get_option( 'fifu_stats_date' );
        if ( ! $date ) {
            return false;
        }

        $num_urls = fifu_db_count_urls();
        $num_cdn  = get_transient( 'fifu_stats_cdn_count' ) ?? 0;

        $site_url = parse_url( get_site_url(), PHP_URL_HOST );
        $site_id  = md5( $site_url );

        $data = array(
            'id'      => $site_id,
            'num_urls' => $num_urls,
            'num_cdn'  => $num_cdn,
            'date'     => $date,
            'slug'     => FIFU_SLUG,
            'version'  => (int) str_replace( '.', '', Fifu_Plugin_Info::get_version() ),
        );

        $api_url = 'https://i0.fifu.app/stats';

        $response = wp_remote_post(
            $api_url,
            array(
                'method'      => 'POST',
                'timeout'     => 15,
                'redirection' => 5,
                'httpversion' => '1.1',
                'blocking'    => false,
                'headers'     => array(
                    'Content-Type' => 'application/json',
                ),
                'body'        => json_encode( $data ),
                'cookies'     => array(),
                'sslverify'   => false,
            )
        );

        if ( is_wp_error( $response ) ) {
            error_log( 'FIFU stats sending error: ' . $response->get_error_message() );
            return false;
        }

        return true;
    }

    /**
     * Detect bots via HTTP headers to avoid counting automated requests.
     *
     * @return bool
     */
    private static function is_bot_request(): bool {
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        if ( empty( $user_agent ) ) {
            return true;
        }

        $bot_keywords = array(
            'bot', 'crawl', 'spider', 'slurp', 'search', 'archive', 'scrap',
            'lighthouse', 'pingdom', 'pagespeed', 'monitor', 'whatsapp', 'facebook',
            'snippet', 'headless', 'python', 'perl', 'urllib', 'curl', 'wget',
            'semrush', 'ahrefs', 'screaming', 'phantom', 'zgrab', 'siteaudit', 'time.news',
        );

        foreach ( $bot_keywords as $keyword ) {
            if ( stripos( $user_agent, $keyword ) !== false ) {
                return true;
            }
        }

        $browser_keywords = array( 'chrome', 'firefox', 'safari', 'opera', 'edge', 'msie', 'trident' );
        $has_browser_keyword = false;

        foreach ( $browser_keywords as $keyword ) {
            if ( stripos( $user_agent, $keyword ) !== false ) {
                $has_browser_keyword = true;
                break;
            }
        }

        if ( ! $has_browser_keyword ) {
            return true;
        }

        if ( empty( $_SERVER['HTTP_ACCEPT'] ?? '' ) ) {
            return true;
        }

        if ( empty( $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '' ) ) {
            return true;
        }

        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        if ( 'GET' !== $method && 'POST' !== $method ) {
            return true;
        }

        return false;
    }
}
