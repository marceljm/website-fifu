<?php

defined( 'ABSPATH' ) || exit;

/**
 * Constructs HTML markup for FIFU image elements.
 */
class Fifu_Image_Html_Renderer {

    /**
     * Builds an <img> tag for a remote featured image.
     *
     * @param string      $url    Image source URL.
     * @param string      $alt    Alt text to apply.
     * @param int|string  $width  Desired width.
     * @param int|string  $height Desired height.
     * @return string
     */
    public static function build_img_tag( string $url, string $alt, $width, $height ): string {
        $css = '';
        $cls = Fifu_Video_Helper::is_video( $url ) ? 'fifu-video' : 'fifu';
        if ( Fifu_Video_Helper::is_video( $url ) && class_exists( 'WooCommerce' ) && is_cart() ) {
            $cls = 'fifu';
        }

        if ( Fifu_Image_Display_Policy::should_hide_featured_media() ) {
            $css = 'display:none';
            $cls = 'fifu';
        }

        $safe_url    = esc_url( $url );
        $safe_alt    = esc_attr( $alt );
        $safe_css    = esc_attr( $css );
        $safe_width  = esc_attr( $width );
        $safe_height = esc_attr( $height );
        $onerror     = self::build_onerror_handler();

        return sprintf(
            '<img class="%s" src="%s" alt="%s" title="%s" style="%s" data-large_image="%s" data-large_image_width="%s" data-large_image_height="%s" onerror="%s" width="%s" height="%s">',
            $cls,
            $safe_url,
            $safe_alt,
            $safe_alt,
            $safe_css,
            $safe_url,
            '800',
            '600',
            $onerror,
            $safe_width,
            $safe_height
        );
    }

    private static function build_onerror_handler(): string {
        $errorUrl = trim((string) get_option('fifu_error_url'));

        if ($errorUrl === '' || !filter_var($errorUrl, FILTER_VALIDATE_URL)) {
            return 'jQuery(this).hide();';
        }

        return sprintf(
            "this.src='%s'; jQuery(this).removeAttr('srcset');",
            esc_js(esc_url_raw($errorUrl))
        );
    }
}
