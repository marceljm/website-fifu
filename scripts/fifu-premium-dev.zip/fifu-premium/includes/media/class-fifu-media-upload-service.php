<?php
declare(strict_types=1);

defined('ABSPATH') || exit;

/**
 * Service responsible for uploading remote media to local WordPress attachments.
 */
class Fifu_Media_Upload_Service
{

    /**
     * Handles remote image upload triggered via REST API.
     *
     * This method is responsible for:
     * - Handling featured image upload.
     * - Handling gallery image upload.
     * - Dealing with product or category targets.
     * - Returning attachment IDs and local URL when applicable.
     *
     * @param int         $postId
     * @param string|null $featuredUrl
     * @param string|null $featuredAlt
     * @param string[]    $galleryUrls
     * @param string[]    $galleryAlts
     * @param bool        $metaBox
     * @param bool        $isCategory
     * @param bool        $fromSlider
     *
     * @return array {
     *     @type string|null $local_url
     *     @type int[]       $attachment_ids
     * }
     */
    public static function upload_via_rest(
        int $postId,
        ?string $featuredUrl,
        ?string $featuredAlt,
        array $galleryUrls,
        array $galleryAlts,
        bool $metaBox,
        bool $isCategory,
        bool $fromSlider = false
    ): array
    {
        $targetId = $postId;
        $attachmentIds = [];
        $galleryAttachmentIds = [];
        $localUrl = null;
        $featuredAttachmentId = 0;
        $featuredUrl = trim((string) ($featuredUrl ?? ''));
        $featuredAlt = trim((string) ($featuredAlt ?? ''));
        $previousAttachmentIds = ($fromSlider && !$isCategory)
            ? self::get_previous_slider_attachment_ids(
                $targetId,
                $featuredUrl,
                $galleryUrls
            )
            : [];
        $postType = $isCategory ? '' : (string) get_post_type($postId);

        if ($featuredUrl !== '') {
            $attId = Fifu_Media_Image_Service::upload_remote_image($targetId, $featuredUrl, $featuredAlt, $isCategory);
            if ($attId) {
                $featuredAttachmentId = (int) $attId;
                $localUrl = wp_get_attachment_url($attId) ?: null;
                if ($metaBox) {
                    $attachmentIds[] = (int) $attId;
                }

                if ($isCategory) {
                    fifu_delete_term_meta($targetId, 'fifu_image_url');
                    fifu_delete_term_meta($targetId, 'fifu_image_alt');
                    Fifu_Post_Attachment_Sync_Service::sync_category_attachment($targetId);
                    update_term_meta($targetId, 'thumbnail_id', $attId);
                } else {
                    fifu_delete_post_meta($targetId, 'fifu_image_url');
                    fifu_delete_post_meta($targetId, 'fifu_image_alt');
                    Fifu_Post_Attachment_Sync_Service::sync_featured_attachment($targetId);
                    set_post_thumbnail($targetId, $attId);
                }

                if ($featuredAlt !== '') {
                    update_post_meta($attId, '_wp_attachment_image_alt', $featuredAlt);
                }
                wp_update_post(['ID' => $attId, 'post_content' => $featuredUrl]);
            }
        }

        foreach ($galleryUrls as $index => $galleryUrl) {
            $galleryUrl = trim((string) $galleryUrl);
            if ($galleryUrl === '') {
                continue;
            }

            $galleryAlt = $galleryAlts[$index] ?? '';
            $galleryAlt = trim((string) $galleryAlt);
            $galleryAttId = Fifu_Media_Image_Service::upload_remote_image($targetId, $galleryUrl, $galleryAlt, false);
            if ($galleryAttId) {
                $galleryAttId = (int) $galleryAttId;
                if ($galleryAlt !== '') {
                    update_post_meta($galleryAttId, '_wp_attachment_image_alt', $galleryAlt);
                }
                wp_update_post(['ID' => $galleryAttId, 'post_content' => $galleryUrl]);
                $galleryAttachmentIds[] = $galleryAttId;
                $attachmentIds[] = $galleryAttId;
            }
        }

        $shouldPersistNativeProductGallery =
            !$isCategory
            && in_array($postType, ['product', 'product_variation'], true)
            && !empty($galleryAttachmentIds);

        if ($shouldPersistNativeProductGallery) {
            $galleryCsv = implode(',', $galleryAttachmentIds);
            self::ensure_tmp_product_gallery_snapshot($targetId);
            update_post_meta($targetId, '_product_image_gallery', $galleryCsv);
            self::clear_remote_gallery_source_meta($targetId);

            if ($postType === 'product_variation') {
                update_post_meta($targetId, '_wc_additional_variation_images', $galleryCsv);
            }

            if ($fromSlider) {
                delete_post_meta($targetId, 'fifu_tmp_product_image_gallery');
            } else {
                Fifu_Post_Attachment_Sync_Service::sync_gallery_attachments($targetId);
            }
        }

        if ($fromSlider && !$isCategory) {
            self::clear_remote_slider_state_after_local_upload($targetId);
            self::delete_attachment_ids_after_local_upload(
                array_values(array_filter(array_unique(array_merge(
                    $featuredAttachmentId > 0 ? [$featuredAttachmentId] : [],
                    $galleryAttachmentIds
                )))),
                $previousAttachmentIds
            );
        }

        if (
            $metaBox
            && !$isCategory
            && !$fromSlider
            && in_array($postType, ['product', 'product_variation'], true)
        ) {
            $localUrl = null;
        }

        return [
            'local_url' => $localUrl,
            'attachment_ids' => $attachmentIds,
        ];
    }

    /**
     * Upload remote media for a post (featured image and gallery) and sync attachments.
     *
     * @param int $postId
     * @return bool
     */
    public static function upload_post(int $postId): bool
    {
        $postType = (string) get_post_type($postId);
        $isProductLike = in_array($postType, ['product', 'product_variation'], true);
        $payload = self::build_upload_post_payload($postId, $isProductLike);
        if ($payload === null) {
            return false;
        }

        $createdAttachmentIds = [];

        try {
            Fifu_File_Logger::plugin(['fifu_upload_post' => [$postId => $payload['featured_url']]]);

            $attId = Fifu_Media_Image_Service::upload_remote_image(
                $postId,
                $payload['featured_url'],
                $payload['featured_alt'],
                false
            );
            if (!$attId || is_wp_error($attId)) {
                Fifu_File_Logger::plugin(['fifu_upload_image' => ['ERROR' => $postId]]);
                return false;
            }
            $createdAttachmentIds[] = (int) $attId;

            if ($payload['featured_alt']) {
                update_post_meta($attId, '_wp_attachment_image_alt', $payload['featured_alt']);
            }

            wp_update_post(['ID' => $attId, 'post_content' => $payload['featured_url']]);

            $attachmentIds = [];
            foreach ($payload['gallery_items'] as $galleryItem) {
                $galAttId = Fifu_Media_Image_Service::upload_remote_image(
                    $postId,
                    $galleryItem['url'],
                    $galleryItem['alt'],
                    false
                );
                if (!$galAttId || is_wp_error($galAttId)) {
                    Fifu_File_Logger::plugin(['fifu_upload_image' => ['ERROR' => $postId]]);
                    throw new Exception('Failed to upload gallery image for post ' . $postId);
                }

                $galAttId = (int) $galAttId;
                $createdAttachmentIds[] = $galAttId;
                if ($galleryItem['alt']) {
                    update_post_meta($galAttId, '_wp_attachment_image_alt', $galleryItem['alt']);
                }
                wp_update_post(['ID' => $galAttId, 'post_content' => $galleryItem['url']]);
                $attachmentIds[] = $galAttId;
            }
        } catch (Exception $e) {
            self::delete_created_attachments_after_failed_upload($createdAttachmentIds);
            Fifu_File_Logger::plugin(['fifu_upload_post' => ['ERROR' => $e->getMessage()]]);
            Fifu_File_Logger::plugin(['fifu_upload_image' => ['ERROR' => $postId]]);
            return false;
        }

        set_post_thumbnail($postId, $attId);
        FIFU_Post_Meta_Updater::instance()->delete($postId, 'fifu_image_url');
        FIFU_Post_Meta_Updater::instance()->delete($postId, 'fifu_image_alt');
        Fifu_Post_Attachment_Sync_Service::sync_featured_attachment($postId);

        $galleryCsv = implode(',', $attachmentIds);
        $shouldPersistNativeProductGallery =
            in_array($postType, ['product', 'product_variation'], true)
            && $galleryCsv !== '';
        $fromSlider = !empty($payload['from_slider']);

        if ($shouldPersistNativeProductGallery) {
            update_post_meta($postId, '_product_image_gallery', $galleryCsv);
            self::clear_remote_gallery_source_meta($postId);

            if ($postType === 'product_variation') {
                update_post_meta($postId, '_wc_additional_variation_images', $galleryCsv);
            }

            if (!$fromSlider) {
                Fifu_Post_Attachment_Sync_Service::sync_gallery_attachments($postId);
            }
        }

        if ($fromSlider) {
            self::clear_remote_slider_state_after_local_upload($postId);
        }

        return true;
    }

    /**
     * Builds a canonical upload payload for post media.
     *
     * The payload is collected before any attachment is created so the upload can
     * fail atomically without mutating remote FIFU state.
     *
     * @param int  $postId
     * @param bool $isProductLike
     * @return array<string, mixed>|null
     */
    private static function build_upload_post_payload(int $postId, bool $isProductLike): ?array
    {
        $featuredUrl = trim((string) (Fifu_Post_Image_Url_Read_Service::get_image_url($postId) ?? ''));
        $featuredAlt = trim((string) (Fifu_Post_Image_Alt_Read_Service::get_image_alt($postId) ?? ''));
        $sliderPayload = $isProductLike ? self::build_slider_upload_payload($postId) : null;

        if ($sliderPayload !== null && $featuredUrl === $sliderPayload['featured_url']) {
            return [
                'from_slider' => true,
                'featured_url' => $sliderPayload['featured_url'],
                'featured_alt' => $sliderPayload['featured_alt'],
                'gallery_items' => self::normalize_gallery_items($sliderPayload['gallery_urls'], $sliderPayload['gallery_alts']),
            ];
        }

        if ($featuredUrl === '' && $sliderPayload !== null) {
            return [
                'from_slider' => true,
                'featured_url' => $sliderPayload['featured_url'],
                'featured_alt' => $sliderPayload['featured_alt'],
                'gallery_items' => self::normalize_gallery_items($sliderPayload['gallery_urls'], $sliderPayload['gallery_alts']),
            ];
        }

        $galleryItems = self::get_canonical_gallery_items($postId);
        if ($featuredUrl !== '') {
            $galleryItems = self::drop_leading_featured_gallery_item($galleryItems, $featuredUrl);
        }

        if ($featuredUrl === '' && !$galleryItems) {
            return null;
        }

        if ($featuredUrl === '' && $galleryItems) {
            $firstGalleryItem = array_shift($galleryItems);
            $featuredUrl = $firstGalleryItem['url'];
            $featuredAlt = $firstGalleryItem['alt'];
        }

        if ($featuredUrl === '') {
            return null;
        }

        return [
            'from_slider' => false,
            'featured_url' => $featuredUrl,
            'featured_alt' => $featuredAlt,
            'gallery_items' => $galleryItems,
        ];
    }

    /**
     * Returns gallery items from canonical list sources, preserving index/ALT alignment.
     *
     * @param int $postId
     * @return array<int, array{url: string, alt: string}>
     */
    private static function get_canonical_gallery_items(int $postId): array
    {
        $listUrl = trim((string) (Fifu_Post_Image_List_Url_Read_Service::get_image_list_url($postId) ?? ''));
        $listAlt = trim((string) (Fifu_Post_Image_List_Alt_Read_Service::get_image_list_alt($postId) ?? ''));
        if ($listUrl !== '') {
            return self::build_items_from_delimited_lists($listUrl, $listAlt, '|');
        }

        $galleryRepo = new Fifu_Product_Gallery_Repository();
        $gallery = $galleryRepo->get_gallery_urls($postId);
        $items = [];
        foreach ($gallery as $item) {
            $index = self::extract_index_from_media_row($item);
            $url = trim((string) ($item->url ?? $item->meta_value ?? ''));
            if ($index === null || $index < 0 || $url === '') {
                continue;
            }

            $alt = trim((string) (Fifu_Post_Image_List_Alt_Read_Service::get_image_alt($postId, $index) ?? ''));
            $items[] = ['url' => $url, 'alt' => $alt];
        }

        return array_values($items);
    }

    /**
     * Normalizes a delimited URL/ALT list into upload items.
     *
     * @param string $urls
     * @param string $alts
     * @param string $delimiter
     * @return array<int, array{url: string, alt: string}>
     */
    private static function build_items_from_delimited_lists(string $urls, string $alts, string $delimiter): array {
        $splitPattern = '/' . preg_quote($delimiter, '/') . '|,/';
        $urlParts = array_values(array_filter(array_map('trim', preg_split($splitPattern, $urls) ?: []), static fn(string $url): bool => $url !== ''));
        if (!$urlParts) {
            return [];
        }

        $altParts = array_map('trim', preg_split($splitPattern, $alts) ?: []);
        $items = [];
        foreach ($urlParts as $index => $url) {
            $items[] = [
                'url' => $url,
                'alt' => trim((string) ($altParts[$index] ?? '')),
            ];
        }

        return array_values($items);
    }

    /**
     * Removes a duplicated featured item from the start of the gallery list.
     *
     * @param array<int, array{url: string, alt: string}> $galleryItems
     * @param string $featuredUrl
     * @return array<int, array{url: string, alt: string}>
     */
    private static function drop_leading_featured_gallery_item(array $galleryItems, string $featuredUrl): array
    {
        $featuredUrl = trim($featuredUrl);
        if ($featuredUrl === '' || !$galleryItems) {
            return $galleryItems;
        }

        $first = $galleryItems[0] ?? null;
        if (is_array($first) && trim((string) ($first['url'] ?? '')) === $featuredUrl) {
            array_shift($galleryItems);
        }

        return array_values($galleryItems);
    }

    /**
     * Converts parallel URL/ALT arrays into canonical gallery items.
     *
     * @param string[] $urls
     * @param string[] $alts
     * @return array<int, array{url: string, alt: string}>
     */
    private static function normalize_gallery_items(array $urls, array $alts): array
    {
        $items = [];
        foreach ($urls as $index => $url) {
            $url = trim((string) $url);
            if ($url === '') {
                continue;
            }

            $items[] = [
                'url' => $url,
                'alt' => trim((string) ($alts[$index] ?? '')),
            ];
        }

        return $items;
    }

    /**
     * Extracts a numeric media index from a DB2 or legacy row.
     *
     * @param object|mixed $row
     * @return int|null
     */
    private static function extract_index_from_media_row($row): ?int
    {
        if (is_object($row) && isset($row->index) && is_numeric($row->index)) {
            return (int) $row->index;
        }

        if (is_object($row) && isset($row->key_index) && is_numeric($row->key_index)) {
            return (int) $row->key_index;
        }

        if (!is_object($row) || !isset($row->meta_key)) {
            return null;
        }

        if (preg_match('/_(\d+)$/', (string) $row->meta_key, $matches) !== 1) {
            return null;
        }

        return (int) $matches[1];
    }

    /**
     * Deletes attachments created by a failed upload attempt.
     *
     * @param int[] $attachmentIds
     * @return void
     */
    private static function delete_created_attachments_after_failed_upload(array $attachmentIds): void
    {
        global $wpdb;

        $attachmentIds = array_values(array_unique(array_filter(array_map('intval', $attachmentIds))));
        foreach ($attachmentIds as $attachmentId) {
            if ($attachmentId <= 0) {
                continue;
            }

            $wpdb->delete($wpdb->postmeta, ['post_id' => $attachmentId]);
            $wpdb->delete($wpdb->posts, ['ID' => $attachmentId]);
            clean_post_cache($attachmentId);
        }
    }

    /**
     * Builds a slider upload payload treating slide 0 as featured and remaining slides as gallery.
     *
     * @param int $postId
     * @return array<string, mixed>|null
     */
    private static function build_slider_upload_payload(int $postId): ?array
    {
        $featuredUrl = trim((string) (Fifu_Post_Slider_Image_Url_Read_Service::get_slider_image_url($postId, 0) ?? ''));
        if ($featuredUrl === '') {
            return null;
        }

        $featuredAlt = trim((string) (Fifu_Post_Slider_Image_Alt_Read_Service::get_slider_image_alt($postId, 0) ?? ''));
        $galleryUrls = [];
        $galleryAlts = [];
        $sliderListUrl = trim((string) (Fifu_Post_Slider_List_Url_Read_Service::get_slider_list_url($postId) ?? ''));
        $sliderListAlt = trim((string) (Fifu_Post_Slider_List_Alt_Read_Service::get_slider_list_alt($postId) ?? ''));
        if ($sliderListUrl !== '') {
            $sliderItems = self::build_items_from_delimited_lists($sliderListUrl, $sliderListAlt, '|');
            foreach ($sliderItems as $index => $sliderItem) {
                if ($index === 0) {
                    continue;
                }

                $galleryUrls[] = $sliderItem['url'];
                $galleryAlts[] = $sliderItem['alt'];
            }
        }

        return [
            'featured_url' => $featuredUrl,
            'featured_alt' => $featuredAlt,
            'gallery_urls' => $galleryUrls,
            'gallery_alts' => $galleryAlts,
        ];
    }

    /**
     * Upload remote media for a term (category image) and sync attachments.
     *
     * @param int $termId
     * @return bool
     */
    public static function upload_term(int $termId): bool
    {
        $url = Fifu_Term_Image_Url_Read_Service::get_image_url((int) $termId);
        $alt = (string) (Fifu_Term_Image_Alt_Read_Service::get_image_alt((int) $termId) ?? '');
        if (!$url) {
            return false;
        }

        try {
            $attId = Fifu_Media_Image_Service::upload_remote_image($termId, $url, $alt, true);
            if (!$attId || is_wp_error($attId)) {
                Fifu_File_Logger::plugin(['fifu_upload_image' => ['ERROR' => $termId]]);
                return false;
            }

            if ($alt) {
                update_post_meta($attId, '_wp_attachment_image_alt', $alt);
            }

            wp_update_post(['ID' => $attId, 'post_content' => $url]);
            FIFU_Term_Meta_Updater::instance()->delete($termId, 'fifu_image_url');
            FIFU_Term_Meta_Updater::instance()->delete($termId, 'fifu_image_alt');

            Fifu_Post_Attachment_Sync_Service::sync_category_attachment($termId);
            update_term_meta($termId, 'thumbnail_id', $attId);
        } catch (Exception $e) {
            Fifu_File_Logger::plugin(['fifu_upload_term' => ['ERROR' => $e->getMessage()]]);
            Fifu_File_Logger::plugin(['fifu_upload_image' => ['ERROR' => $termId]]);
            return false;
        }

        return true;
    }

    private static function get_max_image_list_suffix(int $postId): int {
        $maxSuffix = -1;
        if (function_exists('fifu_db2_manager')) {
            $manager = fifu_db2_manager();
            if ($manager instanceof Fifu_Db2_Manager) {
                $mappings = $manager->getPostMappings($postId, 'image');
                foreach ($mappings as $mapping) {
                    $keyIndex = $mapping['key_index'] ?? null;
                    if ($keyIndex !== null && $keyIndex > 0) {
                        $maxSuffix = max($maxSuffix, $keyIndex - 1);
                    }
                }
            }
        }

        global $wpdb;
        $metaTable = $wpdb->postmeta;
        $rows = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT meta_key FROM {$metaTable} WHERE post_id = %d AND meta_key LIKE 'fifu_image_url\\_%'",
                $postId
            )
        );

        foreach ($rows ?: [] as $metaKey) {
            $parts = explode('_', $metaKey);
            $suffix = end($parts);
            if (ctype_digit($suffix)) {
                $maxSuffix = max($maxSuffix, (int) $suffix);
            }
        }

        return $maxSuffix;
    }

    private static function ensure_tmp_product_gallery_snapshot(int $postId): void
    {
        $postType = (string) get_post_type($postId);
        if ($postType !== 'product' && $postType !== 'product_variation') {
            return;
        }

        $tmpGalleryCsv = trim((string) get_post_meta($postId, 'fifu_tmp_product_image_gallery', true), ',');
        if ($tmpGalleryCsv !== '') {
            return;
        }

        $currentGalleryCsv = trim((string) get_post_meta($postId, '_product_image_gallery', true), ',');
        if ($currentGalleryCsv === '') {
            return;
        }

        update_post_meta($postId, 'fifu_tmp_product_image_gallery', $currentGalleryCsv);
    }

    private static function clear_remote_gallery_source_meta(int $postId): void
    {
        $maxSuffix = self::get_max_image_list_suffix($postId);
        if ($maxSuffix >= 0) {
            for ($i = 0; $i <= $maxSuffix; $i++) {
                fifu_delete_post_meta($postId, 'fifu_image_url_' . $i);
                fifu_delete_post_meta($postId, 'fifu_image_alt_' . $i);
            }
        }

        FIFU_Post_Meta_Updater::instance()->delete($postId, 'fifu_list_url');
        FIFU_Post_Meta_Updater::instance()->delete($postId, 'fifu_list_alt');
        FIFU_Post_Meta_Updater::instance()->delete($postId, 'fifu_list_all');
    }

    private static function clear_remote_slider_state_after_local_upload(int $postId): void
    {
        $metaUpdater = FIFU_Post_Meta_Updater::instance();
        $metaUpdater->delete($postId, 'fifu_slider_list_url');
        $metaUpdater->delete($postId, 'fifu_slider_list_alt');
        $metaUpdater->delete($postId, 'fifu_slider_ratio');
        $metaUpdater->delete($postId, 'fifu_image_url');
        $metaUpdater->delete($postId, 'fifu_image_alt');
        $metaUpdater->delete($postId, 'fifu_video_url');
        $metaUpdater->delete($postId, 'fifu_custom_video_url');

        $meta = get_post_meta($postId);
        foreach (array_keys($meta) as $metaKey) {
            if (
                strpos((string) $metaKey, 'fifu_slider_image_url_') !== 0
                && strpos((string) $metaKey, 'fifu_slider_image_alt_') !== 0
            ) {
                continue;
            }

            $metaUpdater->delete($postId, (string) $metaKey);
        }
    }

    private static function get_current_product_media_attachment_ids(int $postId): array
    {
        $attachmentIds = [];
        $featuredId = (int) get_post_meta($postId, '_thumbnail_id', true);
        if ($featuredId > 0) {
            $attachmentIds[] = $featuredId;
        }

        $galleryIds = explode(',', (string) get_post_meta($postId, '_product_image_gallery', true));
        foreach ($galleryIds as $galleryId) {
            $galleryId = (int) trim((string) $galleryId);
            if ($galleryId > 0) {
                $attachmentIds[] = $galleryId;
            }
        }

        return array_values(array_unique($attachmentIds));
    }

    private static function get_previous_slider_attachment_ids(
        int $postId,
        string $featuredUrl,
        array $galleryUrls
    ): array {
        $attachmentIds = self::get_current_product_media_attachment_ids($postId);
        $sliderUrls = array_values(array_filter(array_map(
            static fn($url): string => trim((string) $url),
            array_merge([$featuredUrl], $galleryUrls)
        )));

        if (!$sliderUrls) {
            return array_values(array_unique($attachmentIds));
        }

        $md5Repo = new Fifu_Db2_Md5_Repository();
        foreach ($sliderUrls as $sliderUrl) {
            $mappedAttachmentId = (int) $md5Repo->find_thumbnail_id_by_url($sliderUrl);
            if ($mappedAttachmentId > 0) {
                $attachmentIds[] = $mappedAttachmentId;
            }
        }

        global $wpdb;
        $placeholders = implode(',', array_fill(0, count($sliderUrls), '%s'));
        $queryArgs = array_merge(
            [$postId, (int) Fifu_Options_Utils::get_author()],
            $sliderUrls
        );
        $sql = $wpdb->prepare(
            "SELECT ID
            FROM {$wpdb->posts}
            WHERE post_parent = %d
              AND post_type = 'attachment'
              AND post_author = %d
              AND post_content_filtered IN ({$placeholders})",
            $queryArgs
        );
        $rows = $wpdb->get_col($sql);
        foreach ($rows ?: [] as $attachmentId) {
            $attachmentIds[] = (int) $attachmentId;
        }

        return array_values(array_unique(array_filter($attachmentIds)));
    }

    private static function delete_attachment_ids_after_local_upload(array $currentAttachmentIds, array $previousAttachmentIds): void
    {
        global $wpdb;

        $md5Repo = new Fifu_Db2_Md5_Repository();
        $currentAttachmentIds = array_values(array_unique(array_map('intval', $currentAttachmentIds)));
        $previousAttachmentIds = array_values(array_unique(array_map('intval', $previousAttachmentIds)));

        foreach ($previousAttachmentIds as $attachmentId) {
            if ($attachmentId <= 0 || in_array($attachmentId, $currentAttachmentIds, true)) {
                continue;
            }

            $wpdb->delete($wpdb->postmeta, ['post_id' => $attachmentId]);
            $wpdb->delete($wpdb->posts, ['ID' => $attachmentId]);
            $md5Repo->delete_by_thumbnail_id($attachmentId);
            clean_post_cache($attachmentId);
        }
    }
}
