<?php
declare(strict_types=1);

final class Fifu_Media_Image_Service {

    /**
     * Google Translate proxy used when downloading some remote images.
     */
    private const GOOGLE_TRANSLATE_PROXY = 'https://translate.google.com/translate?hl=en&sl=pt&u=';

    /** @var Fifu_Db2_Md5_Repository|null */
    private static $md5_repository = null;

    /**
     * Crop an attachment to the given height and return the new attachment ID.
     */
    public static function crop_attachment(int $attachment_id, int $new_height, int $post_id, string $description) {
        $sizes = wp_get_attachment_image_src($attachment_id, 'full');
        $width = $sizes[1] ?? null;
        $height = $sizes[2] ?? null;
        $path = wp_crop_image($attachment_id, 0, 0, $width, $new_height, $width, $new_height);

        $file_array = array();
        $file_array['name'] = date("Ymd-His") . '.jpg';
        $file_array['tmp_name'] = $path;
        if (is_wp_error($path)) {
            @unlink($file_array['name'] ?? '');
            return null;
        }
        $new_att_id = media_handle_sideload($file_array, $post_id, $description);
        if (is_wp_error($new_att_id)) {
            @unlink($file_array['tmp_name'] ?? '');
            return $new_att_id;
        }
        wp_delete_attachment($attachment_id);
        return $new_att_id;
    }

    /**
     * Resize an attachment to the given width and return the new attachment ID.
     */
    public static function resize_attachment(int $post_id, int $attachment_id, string $description, int $width) {
        $path = wp_get_original_image_path($attachment_id);

        $file_array = array();
        $file_array['name'] = date("Ymd-His") . '.jpg';
        $file_array['tmp_name'] = $path;

        $image = wp_get_image_editor($path, array());
        if (!is_wp_error($image)) {
            $image->resize($width, null, true);
            $image->save($path);
        }

        $new_att_id = media_handle_sideload($file_array, $post_id, $description);
        if (is_wp_error($new_att_id)) {
            @unlink($file_array['tmp_name'] ?? '');
            return $new_att_id;
        }

        wp_delete_attachment($attachment_id);
        return $new_att_id;
    }

    /**
     * Handle upload and registration of a captured video frame in the media library.
     */
    public static function upload_captured_frame(string $frame_path, string $video_url, string $time_frame): void {
        $path = parse_url($video_url, PHP_URL_PATH);
        $file_name = basename($path);
        $extension = pathinfo($file_name, PATHINFO_EXTENSION);
        $new_name = str_replace('.' . $extension, "-fifu-{$time_frame}-" . $extension . '.webp', $file_name);
        $image_url = str_replace($file_name, $new_name, $video_url);

        $aux = explode('/', $path);
        $year = $aux[count($aux) - 3] ?? null;
        $month = $aux[count($aux) - 2] ?? null;

        $upload_dir = wp_upload_dir();
        $image_data = file_get_contents($frame_path);

        $upload_dir_path = ($upload_dir['basedir'] ?? '') . "/{$year}/{$month}";
        if (wp_mkdir_p($upload_dir_path)) {
            $file = "{$upload_dir_path}/{$new_name}";
        } else {
            $file = ($upload_dir['basedir'] ?? '') . "/{$new_name}";
        }

        $atts = self::find_existing_frames(sanitize_file_name($new_name), $time_frame);
        foreach ($atts as $att) {
            wp_delete_attachment($att->ID);
        }

        file_put_contents($file, $image_data);

        $wp_filetype = wp_check_filetype($new_name, null);
        $attachment = array(
            'post_mime_type' => $wp_filetype['type'] ?? '',
            'post_title' => sanitize_file_name($new_name),
            'post_content' => '',
            'post_status' => 'inherit'
        );
        $att_id = wp_insert_attachment($attachment, $file);
        $attach_data = wp_generate_attachment_metadata($att_id, $file);
        wp_update_attachment_metadata($att_id, $attach_data);

        $queryParams = http_build_query([
            'site' => Fifu_Image_Url_Utils::get_home_url_no_scheme(),
            'partial_key' => Fifu_Options_Utils::partial_key(),
            'video_url' => $video_url,
            'image_url' => $image_url
        ]);
        $workerUrl = "https://oembed-local.fifu.workers.dev?" . $queryParams;
        wp_remote_get($workerUrl);

        $video_service = Fifu_Video_Oembed_Service::instance();
        $video_service->get_repository()->delete_by_video_url($video_url);
        $video_service->upsert_oembed($video_url, $image_url, $video_url);
    }

    /**
     * Upload a remote image to the media library and return the attachment ID.
     */
    public static function upload_remote_image(int $post_id, string $url, string $alt = '', bool $is_category = false) {
        if (self::should_skip_url($url)) {
            return null;
        }

        set_time_limit(120);
        if (!defined('WPINC')) {
            require_once(ABSPATH . '/wp-load.php');
        }
        require_once(ABSPATH . '/wp-admin/includes/image.php');
        require_once(ABSPATH . '/wp-admin/includes/file.php');
        require_once(ABSPATH . '/wp-admin/includes/media.php');

        if (strpos($url, ".fifu.app") !== false) {
            if (strpos($url, "screenshot.fifu.app") === false) {
                return null;
            }
        }

        $is_google_drive = (new Fifu_Google_Drive_Provider())->supports($url);
        if ($is_google_drive) {
            $url = (new Fifu_Google_Drive_Provider())->convert($url);
        }

        $md5_repo = self::get_md5_repository();
        $att_id_md5 = $md5_repo->find_thumbnail_id_by_url($url);
        if ($att_id_md5) {
            $attachment_repo = new Fifu_Attachment_Repository();
            if (get_post($att_id_md5) && !$attachment_repo->is_fifu_attachment((int) $att_id_md5)) {
                return $att_id_md5;
            }
            $md5_repo->delete_by_thumbnail_id($att_id_md5);
        }

        if (Fifu_Image_Url_Utils::is_base64($url)) {
            $tmp = get_temp_dir() . date("Ymd-His") . '.jpg';
            file_put_contents($tmp, file_get_contents($url));
        } else {
            if ($is_google_drive) {
                $tmp = download_url(self::GOOGLE_TRANSLATE_PROXY . $url);
            } else {
                $tmp = Fifu_Options_Utils::is_on('fifu_upload_proxy') ? Fifu_Proxy_Client::download($url, false) : download_url($url);
            }
        }

        if (!$tmp || is_wp_error($tmp) || !is_string($tmp)) {
            return null;
        }

        if (!$alt) {
            $alt = strip_tags(get_the_title($post_id));
        }

        $is_webp = false;
        if (extension_loaded('gd') && function_exists('imagewebp')) {
            $imageType = @exif_imagetype($tmp);
            if ($imageType == IMAGETYPE_JPEG || $imageType == IMAGETYPE_PNG) {
                $image = ($imageType == IMAGETYPE_JPEG) ? @imagecreatefromjpeg($tmp) : @imagecreatefrompng($tmp);

                if ($image !== false) {
                    $width = imagesx($image);
                    $height = imagesy($image);

                    $has_transparency = $imageType == IMAGETYPE_PNG && imagecolortransparent($image) >= 0;

                    if ($width > 2048 || $height > 2048) {
                        $ratio = min(2048 / $width, 2048 / $height);
                        $newWidth = intval($width * $ratio);
                        $newHeight = intval($height * $ratio);
                        $resizedImage = imagecreatetruecolor($newWidth, $newHeight);

                        if ($imageType == IMAGETYPE_PNG) {
                            imagealphablending($resizedImage, false);
                            imagesavealpha($resizedImage, true);
                            $transparent = imagecolorallocatealpha($resizedImage, 255, 255, 255, 127);
                            imagefilledrectangle($resizedImage, 0, 0, $newWidth, $newHeight, $transparent);
                        }

                        imagecopyresampled($resizedImage, $image, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
                        $image = $resizedImage;
                    }

                    if (imageistruecolor($image) === false) {
                        $trueColorImage = imagecreatetruecolor(imagesx($image), imagesy($image));

                        if ($imageType == IMAGETYPE_PNG) {
                            imagealphablending($trueColorImage, false);
                            imagesavealpha($trueColorImage, true);
                            $transparent = imagecolorallocatealpha($trueColorImage, 255, 255, 255, 127);
                            imagefilledrectangle($trueColorImage, 0, 0, imagesx($image), imagesy($image), $transparent);
                        }

                        imagecopy($trueColorImage, $image, 0, 0, 0, 0, imagesx($image), imagesy($image));
                        $image = $trueColorImage;
                    }

                    if ($imageType == IMAGETYPE_PNG) {
                        imagealphablending($image, false);
                        imagesavealpha($image, true);
                    }

                    $webpPath = pathinfo($tmp, PATHINFO_DIRNAME) . '/' . pathinfo($tmp, PATHINFO_FILENAME) . '.webp';
                    $quality = ($imageType == IMAGETYPE_PNG && $has_transparency) ? 100 : 80;
                    imagewebp($image, $webpPath, $quality);
                    unset($image);

                    $tmp = $webpPath;
                    $is_webp = true;
                } else {
                    return null;
                }
            } else {
                        if (!$imageType) {
                            return null;
                        }
            }
        }

        $description = $alt;
        $file_array = array();
        $file_array['name'] = ($alt ? sanitize_title($alt) : date("Ymd-His")) . ($is_webp ? '.webp' : '.jpg');
        $file_array['tmp_name'] = $tmp;
        if (is_wp_error($tmp)) {
            @unlink($file_array['name'] ?? '');
            return null;
        }

        $att_id = media_handle_sideload($file_array, $post_id, $description);
        if (is_wp_error($att_id)) {
            @unlink($file_array['tmp_name'] ?? '');
            return $att_id;
        }

        if (file_exists($tmp)) {
            @unlink($tmp);
        }

        $md5_repo->insert_mapping($url, $att_id);

        return $att_id;
    }

    /**
     * Find existing frames that match the provided file name and time frame.
     */
    protected static function find_existing_frames(string $file_name, string $time_frame): array {
        global $wpdb;
        $title_pattern = str_replace("-fifu-{$time_frame}-", "-fifu-%", $file_name);
        $query = "
            SELECT * FROM {$wpdb->posts}
            WHERE post_title LIKE %s
            AND post_type = 'attachment'
        ";
        return $wpdb->get_results($wpdb->prepare($query, $title_pattern));
    }

    /**
     * Determine if the provided URL should be skipped.
     */
    protected static function should_skip_url(string $url): bool {
        if (strpos($url, ".fifu.app") !== false) {
            return true;
        }

        $domains = get_option('fifu_upload_domain');
        if ($domains) {
            $domains = explode(',', (string) $domains);
            $host = parse_url($url, PHP_URL_HOST);
            $host = is_string($host) ? strtolower(rtrim(trim($host), '.')) : '';
            if ($host === '') {
                return true;
            }

            foreach ($domains as $domain) {
                $domain = trim((string) $domain);
                if ($domain === '') {
                    continue;
                }

                if (strpos($domain, '://') === false) {
                    $domain = 'http://' . $domain;
                }

                $domainHost = parse_url($domain, PHP_URL_HOST);
                $domainHost = is_string($domainHost) ? strtolower(rtrim(trim($domainHost), '.')) : '';
                if ($domainHost === '') {
                    continue;
                }

                if (self::host_matches_allowed_domain($host, $domainHost)) {
                    return false;
                }
            }

            return true;
        }
        return false;
    }

    private static function host_matches_allowed_domain(string $host, string $domain): bool
    {
        $host = strtolower(rtrim(trim($host), '.'));
        $domain = strtolower(rtrim(trim($domain), '.'));

        if ($host === '' || $domain === '') {
            return false;
        }

        if ($host === $domain) {
            return true;
        }

        $suffix = '.' . $domain;
        return strlen($host) > strlen($suffix) && substr($host, -strlen($suffix)) === $suffix;
    }

    private static function get_md5_repository(): Fifu_Db2_Md5_Repository {
        if (self::$md5_repository === null) {
            self::$md5_repository = new Fifu_Db2_Md5_Repository();
        }
        return self::$md5_repository;
    }
}
