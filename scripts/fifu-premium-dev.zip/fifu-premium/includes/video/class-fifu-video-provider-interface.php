<?php
/**
 * Defines the contract for video providers.
 *
 * @package FIFU Premium
 */

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Interface for objects that represent remote video providers.
 */
interface Fifu_Video_Provider_Interface {

    /**
     * Determines whether the provider supports the supplied URL.
     *
     * @param string $url
     * @return bool
     */
    public function supports( string $url ): bool;

    /**
     * Returns the embed URL for the supplied video URL.
     *
     * @param string $url
     * @return string|null
     */
    public function get_embed_url( string $url ): ?string;

    /**
     * Returns the image URL for the supplied video URL.
     *
     * @param string $url
     * @return string|null
     */
    public function get_image_url( string $url ): ?string;

    /**
     * Returns the social image URL for the supplied video URL.
     *
     * @param string $url
     * @return string|null
     */
    public function get_social_image_url( string $url ): ?string;

    /**
     * Determines whether the supplied source is a provider thumbnail.
     *
     * @param string $src
     * @return bool
     */
    public function is_thumbnail( string $src ): bool;
}
