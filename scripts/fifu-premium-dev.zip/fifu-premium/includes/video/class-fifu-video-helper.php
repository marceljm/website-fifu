<?php

declare( strict_types=1 );

/**
 * Utility helpers for video caching and provider access.
 */
class Fifu_Video_Helper {

    /**
     * @return Fifu_Video_Oembed_Service
     */
    private static function get_service(): Fifu_Video_Oembed_Service {
        return Fifu_Video_Oembed_Service::instance();
    }

    /**
     * @param string $url
     * @return Fifu_Video_Provider|null
     */
    private static function get_provider_for_url( string $url ): ?Fifu_Video_Provider {
        if ( $url === '' ) {
            return null;
        }
        return self::get_service()->get_provider_for( $url );
    }

    /**
     * @param string $class_name
     * @return Fifu_Video_Provider|null
     */
    private static function get_provider_by_class( string $class_name ): ?Fifu_Video_Provider {
        return Fifu_Video_Provider_Registry::instance()->get_provider_by_class( $class_name );
    }

    /**
     * @param string $class_name
     * @param string $url
     * @return bool
     */
    private static function provider_supports_url( string $class_name, string $url ): bool {
        if ( $url === '' ) {
            return false;
        }
        $provider = self::get_provider_by_class( $class_name );
        return $provider ? $provider->supports( $url ) : false;
    }

    /**
     * @param string $class_name
     * @param string $src
     * @return bool
     */
    private static function provider_is_thumbnail( string $class_name, string $src ): bool {
        if ( $src === '' ) {
            return false;
        }
        $provider = self::get_provider_by_class( $class_name );
        return $provider ? $provider->is_thumbnail( $src ) : false;
    }

    /**
     * @param string $url
     * @return bool
     */
    private static function is_new_provider_video( string $url ): bool {
        return Fifu_Video_Provider_Registry::instance()->get_provider_for_url( $url ) !== null;
    }

    /**
     * @param string $url
     * @return string|null
     */
    public static function get_thumbnail_small( string $url ): ?string {
        $provider = self::get_provider_for_url( $url );
        if ( $provider instanceof Fifu_Youtube_Video_Provider ) {
            return self::get_service()->get_thumbnail( $url, 'default' );
        }
        if ( $provider instanceof Fifu_Vimeo_Video_Provider ) {
            return self::get_service()->get_thumbnail( $url, 'thumbnail_small' );
        }
        if ( $provider !== null ) {
            return self::get_service()->get_thumbnail( $url );
        }
        return null;
    }

    /**
     * @param string|null $url
     * @return string|null
     */
    public static function get_thumbnail_large( ?string $url ): ?string {
        if ( $url === null || $url === '' ) {
            return null;
        }
        $provider = self::get_provider_for_url( $url );
        if ( $provider instanceof Fifu_Vimeo_Video_Provider ) {
            return self::get_service()->get_thumbnail( $url, 'thumbnail_large' );
        }
        if ( $provider !== null ) {
            return self::get_service()->get_thumbnail( $url );
        }
        return null;
    }

    /**
     * @param string $url
     * @return string|null
     */
    public static function get_embed_url( string $url ): ?string {
        $provider = self::get_provider_for_url( $url );
        if ( $provider !== null ) {
            $embed = self::get_service()->get_embed_url( $url );
            if ( $embed ) {
                return $embed;
            }
        }
        if ( self::is_custom_video( $url ) ) {
            return self::normalize_custom_video_url( $url );
        }
        return null;
    }

    /**
     * Applies Privacy Enhanced Mode only to rendered YouTube embed URLs.
     *
     * @param string|null $embed_url
     * @return string|null
     */
    public static function apply_privacy_enhanced_mode_to_embed_url( ?string $embed_url ): ?string {
        if ( $embed_url === null || trim( $embed_url ) === '' ) {
            return $embed_url;
        }

        $privacy_enabled = false;

        if ( function_exists( 'fifu_is_on' ) ) {
            $privacy_enabled = fifu_is_on( 'fifu_video_privacy' );
        } elseif ( class_exists( 'Fifu_Options_Utils', false ) && method_exists( 'Fifu_Options_Utils', 'is_on' ) ) {
            $privacy_enabled = Fifu_Options_Utils::is_on( 'fifu_video_privacy' );
        }

        if ( ! $privacy_enabled ) {
            return $embed_url;
        }

        if ( stripos( $embed_url, 'youtube-nocookie.com/embed/' ) !== false ) {
            return $embed_url;
        }

        $privacy_embed_url = preg_replace(
            '~^(https?:)?//(?:www\.|m\.)?youtube\.com(/embed/)~i',
            '$1//www.youtube-nocookie.com$2',
            $embed_url
        );

        return is_string( $privacy_embed_url ) && $privacy_embed_url !== '' ? $privacy_embed_url : $embed_url;
    }

    /**
     * @param string $id
     * @return string|null
     */
    public static function get_social_url( string $id ): ?string {
        $provider = self::get_provider_for_url( $id );
        if ( $provider !== null ) {
            return $provider->get_social_url( $id );
        }
        return null;
    }

    /**
     * @param string $url
     * @return string|null
     */
    public static function get_social_image( string $url ): ?string {
        $provider = self::get_provider_for_url( $url );
        if ( $provider !== null ) {
            return self::get_service()->get_thumbnail( $url );
        }
        return null;
    }

    /**
     * @param string $url
     * @return bool
     */
    public static function is_local_video( string $url ): bool {
        return self::provider_supports_url( Fifu_Local_Video_Provider::class, $url );
    }

    /**
     * @param string $url
     * @return bool
     */
    public static function is_wpcom_video( string $url ): bool {
        return self::provider_supports_url( Fifu_Wpcom_Video_Provider::class, $url );
    }

    /**
     * @param string $url
     * @return bool
     */
    public static function is_youtube_video( string $url ): bool {
        return self::provider_supports_url( Fifu_Youtube_Video_Provider::class, $url );
    }

    /**
     * @param string $src
     * @return bool
     */
    public static function is_youtube_thumbnail( string $src ): bool {
        return self::provider_is_thumbnail( Fifu_Youtube_Video_Provider::class, $src );
    }

    /**
     * @param string $url
     * @return bool
     */
    public static function is_video( string $url ): bool {
        return self::is_automatic_video( $url ) || self::is_custom_video( $url );
    }

    /**
     * @param string $url
     * @return bool
     */
    public static function is_automatic_video( string $url ): bool {
        return self::get_provider_for_url( $url ) !== null;
    }

    /**
     * @param string $url
     * @return bool
     */
    public static function is_custom_video( string $url ): bool {
        $normalized = self::normalize_custom_video_url( $url );

        if ( self::is_automatic_video( $normalized ) ) {
            return false;
        }
        return strpos( $normalized, '.mp4' ) !== false || strpos( $normalized, '.mov' ) !== false || strpos( $normalized, '.webm' ) !== false || strpos( $normalized, '.ogg' ) !== false || strpos( $normalized, '.m3u8' ) !== false;
    }

    /**
     * @param string $url
     * @return string|null
     */
    public static function get_video_id( string $url ): ?string {
        $provider = self::get_provider_for_url( $url );
        if ( $provider !== null ) {
            return $provider->get_video_id( $url );
        }
        return null;
    }

    /**
     * @param string $url
     * @return bool
     */
    public static function is_video_thumb( ?string $url ): bool {
        if ( ! $url ) {
            return false;
        }
        $provider = self::get_provider_for_url( $url );
        if ( $provider !== null ) {
            return $provider->is_thumbnail( $url );
        }
        return false;
    }

    /**
     * Resolves a displayed thumbnail URL back to the original canonical lookup key.
     *
     * Signed Cloud URLs are mapped through `cdn-new-old`, then SU thumbnail query
     * parameters are canonicalized so lookups do not depend on incidental encoding.
     *
     * @param string|null $url
     * @return string|null
     */
    public static function resolve_original_video_thumb_url( ?string $url ): ?string {
        if ( ! $url ) {
            return null;
        }

        global $FIFU_SESSION;

        $resolved = $FIFU_SESSION['cdn-new-old'][ $url ] ?? $url;
        return self::canonicalize_video_thumb_lookup_url( is_string( $resolved ) ? $resolved : $url );
    }

    /**
     * Canonicalizes SU thumbnail URLs while preserving the original query layout.
     *
     * Only `video-thumb` and `resize` values are decoded; other query fragments are
     * left untouched to avoid accidental key drift caused by parse/build helpers.
     *
     * @param string|null $url
     * @return string|null
     */
    public static function canonicalize_video_thumb_lookup_url( ?string $url ): ?string {
        if ( ! $url || strpos( $url, '?' ) === false ) {
            return $url;
        }

        [ $base, $query, $fragment ] = self::split_url_query_and_fragment( $url );
        if ( $query === '' ) {
            return $url;
        }

        $normalized = array();
        foreach ( explode( '&', $query ) as $pair ) {
            if ( $pair === '' ) {
                continue;
            }

            $separator_index = strpos( $pair, '=' );
            if ( $separator_index === false ) {
                $normalized[] = $pair;
                continue;
            }

            $key = substr( $pair, 0, $separator_index );
            $value = substr( $pair, $separator_index + 1 );
            if ( in_array( $key, array( 'video-thumb', 'resize' ), true ) ) {
                $value = self::decode_query_value( $value );
            }

            $normalized[] = $key . '=' . $value;
        }

        $rebuilt = $base;
        if ( ! empty( $normalized ) ) {
            $rebuilt .= '?' . implode( '&', $normalized );
        }
        if ( $fragment !== '' ) {
            $rebuilt .= '#' . $fragment;
        }

        return $rebuilt;
    }

    /**
     * Returns whether the provided URL represents an SU thumbnail after resolution.
     *
     * @param string|null $url
     * @return bool
     */
    public static function is_suvideo_thumbnail( ?string $url ): bool {
        $resolved = self::resolve_original_video_thumb_url( $url );
        if ( ! $resolved ) {
            return false;
        }

        return strpos( $resolved, 'cdn.fifu.app' ) !== false && strpos( $resolved, 'video-thumb=' ) !== false;
    }

    /**
     * @param string|null $url
     * @return bool
     */
    public static function calls_oembed( ?string $url ): bool {
        if ( ! $url ) {
            return false;
        }
        return self::get_provider_for_url( $url ) !== null;
    }

    /**
     * @param string $image_url
     * @return string|null
     */
    public static function get_embed_url_by_image( string $image_url ): ?string {
        $repository = self::get_service()->get_repository();
        foreach ( self::get_image_lookup_variants( $image_url ) as $fallback_image_url ) {
            $embed_url = $repository->get_embed_url_by_image_url( $fallback_image_url );
            if ( $embed_url ) {
                return $embed_url;
            }
        }

        return null;
    }

    /**
     * Returns alternate image keys that may have been stored in the oEmbed repository.
     *
     * Speed Up video thumbnails wrap the real provider thumbnail in the `video-thumb`
     * query arg, so the repository lookup needs to fall back to that inner thumbnail.
     *
     * @param string $image_url
     * @return string[]
     */
    private static function get_image_lookup_variants( string $image_url ): array {
        $canonical_url = self::resolve_original_video_thumb_url( $image_url ) ?? $image_url;
        $variants = array( $canonical_url );

        $video_thumb = self::get_query_parameter_value( $canonical_url, 'video-thumb' );
        if ( is_string( $video_thumb ) && $video_thumb !== '' && $video_thumb !== $canonical_url ) {
            $variants[] = $video_thumb;
            $variants[] = strtok( $video_thumb, '?' ) ?: $video_thumb;
        }

        $without_resize = self::remove_query_parameter_preserving_format( $canonical_url, 'resize' );
        if ( $without_resize !== $canonical_url ) {
            $variants[] = $without_resize;
        }

        $without_query = strtok( $canonical_url, '?' );
        if ( is_string( $without_query ) && $without_query !== '' && $without_query !== $canonical_url ) {
            $variants[] = $without_query;
        }

        return array_values( array_unique( array_filter( $variants ) ) );
    }

    /**
     * Splits URL into base, query and fragment without mutating query contents.
     *
     * @param string $url
     * @return array{0:string,1:string,2:string}
     */
    private static function split_url_query_and_fragment( string $url ): array {
        $fragment = '';
        $fragment_index = strpos( $url, '#' );
        if ( $fragment_index !== false ) {
            $fragment = substr( $url, $fragment_index + 1 );
            $url = substr( $url, 0, $fragment_index );
        }

        $query = '';
        $query_index = strpos( $url, '?' );
        if ( $query_index !== false ) {
            $query = substr( $url, $query_index + 1 );
            $url = substr( $url, 0, $query_index );
        }

        return array( $url, $query, $fragment );
    }

    /**
     * Removes a single query parameter while preserving the text form of others.
     *
     * @param string $url
     * @param string $parameter
     * @return string
     */
    private static function remove_query_parameter_preserving_format( string $url, string $parameter ): string {
        [ $base, $query, $fragment ] = self::split_url_query_and_fragment( $url );
        if ( $query === '' ) {
            return $url;
        }

        $filtered = array();
        foreach ( explode( '&', $query ) as $pair ) {
            if ( $pair === '' ) {
                continue;
            }

            $key = explode( '=', $pair, 2 )[0] ?? '';
            if ( $key === $parameter ) {
                continue;
            }

            $filtered[] = $pair;
        }

        $rebuilt = $base;
        if ( ! empty( $filtered ) ) {
            $rebuilt .= '?' . implode( '&', $filtered );
        }
        if ( $fragment !== '' ) {
            $rebuilt .= '#' . $fragment;
        }

        return $rebuilt;
    }

    /**
     * Reads a query parameter from a canonicalized URL.
     *
     * @param string $url
     * @param string $parameter
     * @return string|null
     */
    private static function get_query_parameter_value( string $url, string $parameter ): ?string {
        [ , $query ] = self::split_url_query_and_fragment( $url );
        if ( $query === '' ) {
            return null;
        }

        foreach ( explode( '&', $query ) as $pair ) {
            if ( $pair === '' ) {
                continue;
            }

            $parts = explode( '=', $pair, 2 );
            if ( ( $parts[0] ?? '' ) !== $parameter ) {
                continue;
            }

            return $parts[1] ?? '';
        }

        return null;
    }

    /**
     * Decodes percent-encoded query values without altering plain values.
     *
     * @param string $value
     * @return string
     */
    private static function decode_query_value( string $value ): string {
        try {
            return rawurldecode( $value );
        } catch ( \Throwable $throwable ) {
            return $value;
        }
    }

    /**
     * @param string $url
     * @return string
     */
    private static function normalize_custom_video_url( string $url ): string {
        $parts = explode( "\\http", $url );
        return $parts[0] ?? $url;
    }
}
