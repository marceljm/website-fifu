<?php

declare( strict_types=1 );

defined( 'ABSPATH' ) || exit;

/**
 * Bootstrap loader for the FIFU video module.
 *
 * Responsible for wiring together the oEmbed service, provider registry,
 * provider implementations, and compatibility helpers before use.
 */
$files = array(
    'class-fifu-video-configuration.php',
    'class-fifu-video-thumbnail-policy.php',
    'class-fifu-video-attachment-utils.php',
    'class-fifu-video-oembed-service.php',
    'class-fifu-video-helper.php',
    'class-fifu-video-provider-registry.php',
    'class-fifu-video-provider-interface.php',
    'class-fifu-video-thumbnail-manager.php',
    'class-fifu-video-worker-client.php',
    'providers/interface-fifu-video-provider.php',
    'providers/abstract-class-fifu-remote-video-provider.php',
    'providers/class-fifu-video-worker-provider.php',
    'providers/class-fifu-vimeo-video-provider.php',
    'providers/class-fifu-youtube-video-provider.php',
    'providers/class-fifu-local-video-provider.php',
    'providers/class-fifu-wpcom-video-provider.php',
    'providers/class-fifu-tiktok-video-provider.php',
    'providers/class-fifu-cloudinary-video-provider.php',
    'providers/class-fifu-tumblr-video-provider.php',
    'providers/class-fifu-publitio-video-provider.php',
    'providers/class-fifu-gag-video-provider.php',
    'index.php',
);

foreach ( $files as $file ) {
    require_once __DIR__ . '/' . $file;
}

Fifu_Video_Oembed_Service::instance();

fifu_video_register_providers();
