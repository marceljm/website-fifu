<?php
/**
 * Bootstraps the video provider registry.
 *
 * @package FIFU Premium
 */

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once __DIR__ . '/class-fifu-video-provider-interface.php';
require_once __DIR__ . '/class-fifu-video-provider-registry.php';
require_once __DIR__ . '/class-fifu-video-thumbnail-manager.php';
require_once __DIR__ . '/class-fifu-video-worker-client.php';

require_once __DIR__ . '/providers/class-fifu-video-worker-provider.php';
require_once __DIR__ . '/providers/class-fifu-vimeo-video-provider.php';
require_once __DIR__ . '/providers/class-fifu-youtube-video-provider.php';
require_once __DIR__ . '/providers/class-fifu-local-video-provider.php';
require_once __DIR__ . '/providers/class-fifu-wpcom-video-provider.php';
require_once __DIR__ . '/providers/class-fifu-tiktok-video-provider.php';
require_once __DIR__ . '/providers/class-fifu-cloudinary-video-provider.php';
require_once __DIR__ . '/providers/class-fifu-tumblr-video-provider.php';
require_once __DIR__ . '/providers/class-fifu-publitio-video-provider.php';
require_once __DIR__ . '/providers/class-fifu-gag-video-provider.php';
require_once __DIR__ . '/providers/class-fifu-googledrive-video-provider.php';
require_once __DIR__ . '/providers/class-fifu-mega-video-provider.php';
require_once __DIR__ . '/providers/class-fifu-bunny-video-provider.php';
require_once __DIR__ . '/providers/class-fifu-bitchute-video-provider.php';
require_once __DIR__ . '/providers/class-fifu-brighteon-video-provider.php';
require_once __DIR__ . '/providers/class-fifu-spotify-video-provider.php';
require_once __DIR__ . '/providers/class-fifu-amazon-video-provider.php';
require_once __DIR__ . '/providers/class-fifu-jwplayer-video-provider.php';
require_once __DIR__ . '/providers/class-fifu-sprout-video-provider.php';
require_once __DIR__ . '/providers/class-fifu-rumble-video-provider.php';
require_once __DIR__ . '/providers/class-fifu-soundcloud-video-provider.php';
require_once __DIR__ . '/providers/class-fifu-dailymotion-video-provider.php';
require_once __DIR__ . '/providers/class-fifu-twitter-video-provider.php';
require_once __DIR__ . '/providers/class-fifu-cloudflarestream-video-provider.php';
require_once __DIR__ . '/providers/class-fifu-odysee-video-provider.php';
require_once __DIR__ . '/providers/class-fifu-suvideo-video-provider.php';

if ( ! class_exists( 'Fifu_Db2_Video_Oembed_Repository' ) ) {
    require_once FIFU_ADMIN_DIR . '/db2/repository/class-fifu-db2-video-oembed-repository.php';
}

/**
 * Returns the shared thumbnail manager for provider use.
 *
 * @return Fifu_Video_Thumbnail_Manager
 */
function fifu_video_provider_thumbnail_manager(): Fifu_Video_Thumbnail_Manager {
    /** @var Fifu_Video_Thumbnail_Manager|null $manager */
    static $manager = null;
    if ( $manager === null ) {
        $manager = new Fifu_Video_Thumbnail_Manager();
    }
    return $manager;
}

/**
 * Returns the shared worker client for provider use.
 *
 * @return Fifu_Video_Worker_Client
 */
function fifu_video_provider_worker_client(): Fifu_Video_Worker_Client {
    /** @var Fifu_Video_Worker_Client|null $client */
    static $client = null;
    if ( $client === null ) {
        $client = new Fifu_Video_Worker_Client();
    }
    return $client;
}

/**
 * Returns the shared repository for provider use.
 *
 * @return Fifu_Db2_Video_Oembed_Repository
 */
function fifu_video_provider_oembed_repository(): Fifu_Db2_Video_Oembed_Repository {
    /** @var Fifu_Db2_Video_Oembed_Repository|null $repository */
    static $repository = null;
    if ( $repository === null ) {
        $repository = new Fifu_Db2_Video_Oembed_Repository();
    }
    return $repository;
}

/**
 * Registers all video providers on demand.
 */
function fifu_video_register_providers(): void {
    /** @var bool $registered */
    static $registered = false;
    if ( $registered ) {
        return;
    }

    $registry = Fifu_Video_Provider_Registry::instance();

    $repository = fifu_video_provider_oembed_repository();
    $thumbnail_manager = fifu_video_provider_thumbnail_manager();
    $worker_client = fifu_video_provider_worker_client();

    $worker_provider_classes = array(
        Fifu_Vimeo_Video_Provider::class,
        Fifu_Youtube_Video_Provider::class,
        Fifu_Local_Video_Provider::class,
        Fifu_Wpcom_Video_Provider::class,
        Fifu_Tiktok_Video_Provider::class,
        Fifu_Cloudinary_Video_Provider::class,
        Fifu_Tumblr_Video_Provider::class,
        Fifu_Publitio_Video_Provider::class,
        Fifu_Gag_Video_Provider::class,
        Fifu_GoogleDrive_Video_Provider::class,
        Fifu_Mega_Video_Provider::class,
        Fifu_Bunny_Video_Provider::class,
        Fifu_Bitchute_Video_Provider::class,
        Fifu_Brighteon_Video_Provider::class,
        Fifu_Spotify_Video_Provider::class,
        Fifu_Amazon_Video_Provider::class,
        Fifu_JWPlayer_Video_Provider::class,
        Fifu_Sprout_Video_Provider::class,
        Fifu_Rumble_Video_Provider::class,
        Fifu_SoundCloud_Video_Provider::class,
        Fifu_Dailymotion_Video_Provider::class,
        Fifu_Twitter_Video_Provider::class,
        Fifu_Odysee_Video_Provider::class,
    );

    foreach ( $worker_provider_classes as $provider_class ) {
        if ( ! class_exists( $provider_class ) ) {
            continue;
        }

        $registry->register(
            new $provider_class(
                $repository,
                $thumbnail_manager,
                $worker_client
            )
        );
    }

    $registry->register( new Fifu_CloudflareStream_Video_Provider() );
    $registry->register( new Fifu_Suvideo_Video_Provider() );

    $registered = true;
}
