<?php

declare( strict_types=1 );

defined( 'ABSPATH' ) || exit;

/**
 * Define a política de exibição das miniaturas de vídeo em diferentes contextos.
 */
final class Fifu_Video_Thumbnail_Policy {

    /**
     * @return bool
     */
    public static function should_display_on_home_context(): bool {
        if ( ! Fifu_Options_Utils::is_on( 'fifu_video_thumb' ) ) {
            return false;
        }
        return self::is_primary_listing();
    }

    /**
     * @return bool
     */
    public static function should_display_on_page(): bool {
        if ( ! Fifu_Options_Utils::is_on( 'fifu_video_thumb_page' ) ) {
            return false;
        }

        if ( is_front_page() ) {
            return false;
        }

        return is_page() || is_home() || is_archive() || is_search();
    }

    /**
     * @return bool
     */
    public static function should_display_on_post(): bool {
        return Fifu_Options_Utils::is_on( 'fifu_video_thumb_post' ) && is_singular( 'post' );
    }

    /**
     * @return bool
     */
    public static function should_display_on_cpt(): bool {
        if ( ! Fifu_Options_Utils::is_on( 'fifu_video_thumb_cpt' ) ) {
            return false;
        }

        return Fifu_Post_Type_Utils::is_singular_custom_post_type();
    }

    /**
     * @return bool
     */
    private static function is_primary_listing(): bool {
        if ( is_front_page() ) {
            return true;
        }

        if ( function_exists( 'is_shop' ) && is_shop() ) {
            return true;
        }

        if ( function_exists( 'fifu_video_thumbnail_policy_is_shop' ) && fifu_video_thumbnail_policy_is_shop() ) {
            return true;
        }

        return false;
    }
}
