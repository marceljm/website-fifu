<?php

declare( strict_types=1 );

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Fifu_Db2_Video_Oembed_Repository' ) ) {
    require_once FIFU_ADMIN_DIR . '/db2/repository/class-fifu-db2-video-oembed-repository.php';
}

/**
 * Orchestrates video oEmbed retrieval and thumbnail persistence.
 *
 * This service wraps {@see Fifu_Db2_Video_Oembed_Repository} and
 * {@see Fifu_Video_Provider_Registry} so the rest of the plugin can rely on
 * object-oriented providers.
 */
class Fifu_Video_Oembed_Service {

    /**
     * @var Fifu_Video_Oembed_Service|null
     */
    private static ?Fifu_Video_Oembed_Service $instance = null;

    /**
     * @var Fifu_Db2_Video_Oembed_Repository
     */
    private Fifu_Db2_Video_Oembed_Repository $repository;

    /**
     * @var Fifu_Video_Provider_Registry
     */
    private Fifu_Video_Provider_Registry $provider_registry;

    /**
     * Private constructor to force static access.
     */
    private function __construct() {
        $this->repository = new Fifu_Db2_Video_Oembed_Repository();
        $this->provider_registry = Fifu_Video_Provider_Registry::instance();
    }

    /**
     * @return Fifu_Video_Oembed_Service
     */
    public static function instance(): Fifu_Video_Oembed_Service {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * @return Fifu_Db2_Video_Oembed_Repository
     */
    public function get_repository(): Fifu_Db2_Video_Oembed_Repository {
        return $this->repository;
    }

    /**
     * @param string $video_url
     * @param string|null $image_url
     * @param string|null $embed_url
     */
    public function upsert_oembed( string $video_url, ?string $image_url, ?string $embed_url ): bool {
        if ( ! $video_url || ! $image_url || ! $embed_url ) {
            return false;
        }
        return (bool) $this->repository->upsert_oembed( $video_url, $image_url, $embed_url );
    }

    public function delete_vimeo_oembed_cache(): void {
        $this->repository->delete_vimeo_oembed_cache();
    }

    /**
     * Finds the best provider for a given URL.
     *
     * @param string $url
     * @return Fifu_Video_Provider|null
     */
    public function get_provider_for( string $url ): ?Fifu_Video_Provider {
        $provider = $this->provider_registry->get_provider_for_url( $url );
        if ( $provider instanceof Fifu_Video_Provider ) {
            return $provider;
        }
        return null;
    }

    /**
     * @param string $url
     * @param string|null $size
     * @return string|null
     */
    public function get_thumbnail( string $url, ?string $size = null ): ?string {
        if ( ! $url ) {
            return null;
        }

        $provider = $this->get_provider_for( $url );
        $cached = $this->repository->get_image_url_by_video_url( $url );
        $cached_embed = $this->repository->get_embed_url_by_video_url( $url );
        if (
            $cached
            && (
                ! $provider
                || (
                    ! $this->should_skip_cache_for_request( $provider, $cached, $size )
                    && ! $this->should_refresh_vimeo_access_token_cache_for_url( $url, $cached_embed )
                )
            )
        ) {
            return $cached;
        }

        if ( ! $provider ) {
            return null;
        }

        $image_url = $provider->get_thumbnail_url( $url, $size );
        $refreshed_embed = $this->repository->get_embed_url_by_video_url( $url );
        if (
            $refreshed_embed
            && $this->is_vimeo_provider( $provider )
            && $this->is_vimeo_access_token_mode_enabled()
            && $this->is_direct_video_file_url( $refreshed_embed )
        ) {
            $embed_url = $refreshed_embed;
        } else {
            $embed_url = $provider->get_embed_url( $url );
        }

        if ( $image_url && $embed_url && $this->should_persist_thumbnail( $provider, $image_url, $size ) ) {
            $this->upsert_oembed( $url, $image_url, $embed_url );
        }

        return $image_url;
    }

    /**
     * @param string $url
     * @return string|null
     */
    public function get_embed_url( string $url ): ?string {
        if ( ! $url ) {
            return null;
        }

        $cached = $this->repository->get_embed_url_by_video_url( $url );

        if ( $cached && ! $this->should_refresh_vimeo_access_token_cache_for_url( $url, $cached ) ) {
            return $cached;
        }

        $provider = $this->get_provider_for( $url );

        if ( ! $provider ) {
            return $cached ?: null;
        }

        if ( $cached && $this->should_refresh_vimeo_access_token_cache_for_url( $url, $cached ) ) {
            $provider->get_thumbnail_url( $url );

            $refreshed = $this->repository->get_embed_url_by_video_url( $url );
            if ( $refreshed && ! $this->should_refresh_vimeo_access_token_cache_for_url( $url, $refreshed ) ) {
                return $refreshed;
            }

            return $cached;
        }

        return $provider->get_embed_url( $url );
    }

    /**
     * @param mixed $provider
     * @return bool
     */
    private function is_youtube_provider( $provider ): bool {
        return class_exists( 'Fifu_Youtube_Video_Provider', false ) && $provider instanceof Fifu_Youtube_Video_Provider;
    }

    /**
     * @param string|null $image_url
     * @return bool
     */
    private function is_youtube_default_thumbnail( ?string $image_url ): bool {
        if ( ! $image_url ) {
            return false;
        }

        $path = parse_url( $image_url, PHP_URL_PATH );
        if ( ! is_string( $path ) || $path === '' ) {
            return false;
        }

        return basename( $path ) === 'default.jpg';
    }

    /**
     * @param mixed $provider
     * @param string|null $cached
     * @param string|null $size
     * @return bool
     */
    private function should_skip_cache_for_request( $provider, ?string $cached, ?string $size ): bool {
        return $this->is_youtube_provider( $provider )
            && $size !== 'default'
            && $this->is_youtube_default_thumbnail( $cached );
    }

    /**
     * @param mixed $provider
     * @param string|null $cached_embed
     * @return bool
     */
    private function should_refresh_vimeo_access_token_cache_for_url( string $url, ?string $cached_embed ): bool {
        return $this->is_vimeo_access_token_mode_enabled()
            && $this->looks_like_vimeo_url_or_embed( $url, $cached_embed )
            && ! $this->is_direct_video_file_url( $cached_embed );
    }

    /**
     * @param string $url
     * @param string|null $cached_embed
     * @return bool
     */
    private function looks_like_vimeo_url_or_embed( string $url, ?string $cached_embed ): bool {
        return strpos( $url, 'vimeo.com' ) !== false
            || ( is_string( $cached_embed ) && strpos( $cached_embed, 'vimeo.com' ) !== false );
    }

    /**
     * @deprecated Use should_refresh_vimeo_access_token_cache_for_url() instead.
     * @param mixed $provider
     * @param string|null $cached_embed
     * @return bool
     */
    private function should_refresh_vimeo_access_token_cache( $provider, ?string $cached_embed ): bool {
        return $this->is_vimeo_provider( $provider )
            && $this->is_vimeo_access_token_mode_enabled()
            && ! $this->is_direct_video_file_url( $cached_embed );
    }

    /**
     * @param mixed $provider
     * @return bool
     */
    private function is_vimeo_provider( $provider ): bool {
        return class_exists( 'Fifu_Vimeo_Video_Provider', false ) && $provider instanceof Fifu_Vimeo_Video_Provider;
    }

    /**
     * @return bool
     */
    private function is_vimeo_access_token_mode_enabled(): bool {
        return trim( (string) get_option( 'fifu_vimeo_access_token' ) ) !== '';
    }

    /**
     * @param string|null $url
     * @return bool
     */
    private function is_direct_video_file_url( ?string $url ): bool {
        if ( ! is_string( $url ) || $url === '' ) {
            return false;
        }

        if ( strpos( $url, '/progressive_redirect/playback/' ) !== false ) {
            return true;
        }

        return preg_match( '/\.(mp4|webm|ogg|mov|m3u8)(?:\?|#|$)/i', $url ) === 1;
    }

    /**
     * @param mixed $provider
     * @param string|null $image_url
     * @param string|null $size
     * @return bool
     */
    private function should_persist_thumbnail( $provider, ?string $image_url, ?string $size ): bool {
        return ! (
            $this->is_youtube_provider( $provider )
            && $size === 'default'
            && $this->is_youtube_default_thumbnail( $image_url )
        );
    }
}
