<?php
/**
 * Video provider implementation.
 *
 * Supplies provider-specific metadata to the OO video stack.
 */
class Fifu_Amazon_Video_Provider extends Fifu_Video_Worker_Provider {

    /**
     * {@inheritDoc}
     */
    public function supports( string $url ): bool {
        return strpos( $url, 'm.media-amazon.com' ) !== false && strpos( $url, '.mp4' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function get_video_id( string $url ): ?string {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    public function get_embed_url( string $url ): ?string {
        return $url;
    }

    /**
     * {@inheritDoc}
     */
    public function is_thumbnail( string $src ): bool {
        return $src && strpos( $src, 'm.media-amazon.com' ) !== false && strpos( $src, 'SX1600_.' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function build_thumbnail_filename( string $url ): ?string {
        $path = wp_parse_url( $url, PHP_URL_PATH );
        $name = $path ? basename( $path ) : '';
        if ( ! $name ) {
            return null;
        }
        return sanitize_file_name( $name );
    }

    /**
     * {@inheritDoc}
     */
    protected function get_slug(): string {
        return 'amazon';
    }

    /**
     * {@inheritDoc}
     */
    protected function fetch_remote_metadata( string $url, ?string $size = null ): ?array {
        $params = array(
            'site' => Fifu_Image_Url_Utils::get_home_url_no_scheme(),
            'partial_key' => Fifu_Options_Utils::partial_key(),
            'url' => $url,
        );

        $image_url = $this->worker_client->get_raw_body( 'amazon', $params );
        if ( ! $image_url ) {
            return null;
        }

        return array(
            'image_url' => $image_url,
        );
    }

    /**
     * {@inheritDoc}
     */
    protected function get_embed_url_from_url( string $url ): ?string {
        return $this->get_embed_url( $url );
    }
}
