<?php

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Video provider implementation.
 *
 * Supplies provider-specific metadata to the OO video stack.
 */
class Fifu_Gag_Video_Provider extends Fifu_Video_Worker_Provider {

    /**
     * {@inheritDoc}
     */
    public function supports( string $url ): bool {
        return $url !== '' && strpos( $url, '9cache.com' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function get_video_id( string $url ): ?string {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    public function get_embed_url( string $url ): ?string {
        return $url;
    }

    /**
     * {@inheritDoc}
     */
    public function get_social_url( string $url_or_id ): ?string {
        return $this->get_embed_url( $url_or_id );
    }

    /**
     * {@inheritDoc}
     */
    public function is_thumbnail( string $src ): bool {
        return $src !== '' && strpos( $src, '9cache.com' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function build_thumbnail_filename( string $url ): ?string {
        $path = wp_parse_url( $url, PHP_URL_PATH );
        if ( $path ) {
            $name = pathinfo( $path, PATHINFO_FILENAME );
            return sanitize_file_name( $name . '.jpg' );
        }

        return sanitize_file_name( md5( $url ) . '.jpg' );
    }

    /**
     * {@inheritDoc}
     */
    protected function get_slug(): string {
        return 'gag';
    }

    /**
     * {@inheritDoc}
     */
    protected function fetch_remote_metadata( string $url, ?string $size = null ): ?array {
        $image_url = $this->build_thumbnail_url( $url );
        if ( ! $image_url ) {
            return null;
        }

        return array(
            'image_url' => $image_url,
            'embed_url' => $this->get_embed_url_from_url( $url ),
        );
    }

    /**
     * Build the thumbnail URL derived from the 9Gag video URL.
     */
    private function build_thumbnail_url( string $url ): ?string {
        $segments = explode( '_', $url );
        $base = $segments[0] ?? null;
        if ( $base ) {
            return $base;
        }
        return $url . '_460c_offset0.jpg';
    }

    /**
     * {@inheritDoc}
     */
    protected function get_embed_url_from_url( string $url ): ?string {
        return $this->get_embed_url( $url );
    }
}
