<?php
/**
 * Video provider implementation.
 *
 * Supplies provider-specific metadata to the OO video stack.
 */
class Fifu_SoundCloud_Video_Provider extends Fifu_Video_Worker_Provider {

    /**
     * {@inheritDoc}
     */
    public function supports( string $url ): bool {
        return strpos( $url, 'soundcloud.com' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function get_video_id( string $url ): ?string {
        $path = wp_parse_url( $url, PHP_URL_PATH );
        return $path ? trim( $path, '/' ) : null;
    }

    /**
     * {@inheritDoc}
     */
    public function get_embed_url( string $url ): ?string {
        $data = $this->fetch_cached_metadata( $url );
        return $data['embed_url'] ?? null;
    }

    /**
     * {@inheritDoc}
     */
    public function is_thumbnail( string $src ): bool {
        return $src && strpos( $src, 'sndcdn.com' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function build_thumbnail_filename( string $url ): ?string {
        $path = wp_parse_url( $url, PHP_URL_PATH );
        if ( ! $path ) {
            return null;
        }
        return sanitize_file_name( basename( $path ) . '.jpg' );
    }

    /**
     * {@inheritDoc}
     */
    protected function get_slug(): string {
        return 'soundcloud';
    }

    /**
     * {@inheritDoc}
     */
    protected function fetch_remote_metadata( string $url, ?string $size = null ): ?array {
        $params = array(
            'site' => Fifu_Image_Url_Utils::get_home_url_no_scheme(),
            'partial_key' => Fifu_Options_Utils::partial_key(),
            'url' => $url,
            'domain' => Fifu_Image_Url_Utils::get_domain(),
        );

        $payload = $this->worker_client->get_json( 'soundcloud', $params );
        if ( ! is_array( $payload ) ) {
            return null;
        }

        $image = $payload['image_url'] ?? null;
        $embed = $payload['embed_url'] ?? null;

        if ( ! $image && ! $embed ) {
            return null;
        }

        return array(
            'image_url' => $image,
            'embed_url' => $embed,
        );
    }
}
