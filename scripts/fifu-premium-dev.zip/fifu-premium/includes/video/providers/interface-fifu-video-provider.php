<?php

declare( strict_types=1 );

/**
 * Represents a generic video provider implementation.
 *
 * Providers supply metadata for the OO video stack.
 */
interface Fifu_Video_Provider {

    /**
     * Checks if the provider supports a given URL.
     *
     * @param string $url
     * @return bool
     */
    public function supports( string $url ): bool;

    /**
     * Extracts the provider-specific video ID from the URL.
     *
     * @param string $url
     * @return string|null
     */
    public function get_video_id( string $url ): ?string;

    /**
     * Returns the canonical embed URL for this provider.
     *
     * @param string $url
     * @return string|null
     */
    public function get_embed_url( string $url ): ?string;

    /**
     * Builds a provider-specific social share URL.
     *
     * @param string $url_or_id
     * @return string|null
     */
    public function get_social_url( string $url_or_id ): ?string;

    /**
     * Returns a thumbnail URL for the video.
     *
     * @param string $url
     * @param string|null $size
     * @return string|null
     */
    public function get_thumbnail_url( string $url, ?string $size = null ): ?string;

    /**
     * Determines whether a given source URL is a provider thumbnail.
     *
     * @param string $src
     * @return bool
     */
    public function is_thumbnail( string $src ): bool;
}
