<?php

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Video provider implementation.
 *
 * Supplies provider-specific metadata to the OO video stack.
 */
class Fifu_Local_Video_Provider extends Fifu_Video_Worker_Provider {

    /**
     * {@inheritDoc}
     */
    public function supports( string $url ): bool {
        if ( $url === '' ) {
            return false;
        }

        $upload_dir = Fifu_Upload_Dir_Utils::get_upload_dir();
        $host = parse_url( get_site_url(), PHP_URL_HOST );
        $is_hosted = $host ? strpos( $url, $host ) !== false : false;
        $is_uploaded = strpos( $url, $upload_dir ) !== false;
        $is_extension_supported = strpos( $url, 'mp4' ) !== false
            || strpos( $url, 'mov' ) !== false
            || strpos( $url, 'webm' ) !== false
            || strpos( $url, 'ogg' ) !== false
            || strpos( $url, 'm3u8' ) !== false;

        return $is_hosted && $is_uploaded && $is_extension_supported;
    }

    /**
     * {@inheritDoc}
     */
    public function get_video_id( string $url ): ?string {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    public function get_embed_url( string $url ): ?string {
        return $url;
    }

    /**
     * {@inheritDoc}
     */
    public function get_social_url( string $url_or_id ): ?string {
        return $url_or_id;
    }

    /**
     * {@inheritDoc}
     */
    public function is_thumbnail( string $src ): bool {
        if ( $src === '' ) {
            return false;
        }

        $upload_dir = Fifu_Upload_Dir_Utils::get_upload_dir();
        $host = parse_url( get_site_url(), PHP_URL_HOST );
        $has_host = $host ? strpos( $src, $host ) !== false : false;
        $has_upload_dir = strpos( $src, $upload_dir ) !== false;
        $has_marker = strpos( $src, '-fifu-' ) !== false;

        return $has_host && $has_upload_dir && $has_marker;
    }

    /**
     * {@inheritDoc}
     */
    public function build_thumbnail_filename( string $url ): ?string {
        $path = wp_parse_url( $url, PHP_URL_PATH );
        if ( $path ) {
            return sanitize_file_name( basename( $path ) . '.jpg' );
        }
        return sanitize_file_name( md5( $url ) . '.jpg' );
    }

    /**
     * {@inheritDoc}
     */
    protected function get_slug(): string {
        return 'local';
    }

    /**
     * {@inheritDoc}
     */
    protected function fetch_remote_metadata( string $url, ?string $size = null ): ?array {
        $params = $this->build_oembed_query_params( $url, $size );
        $image_url = $this->worker_client->get_raw_body( $this->get_slug(), $params );
        if ( ! $image_url ) {
            return null;
        }

        return array(
            'image_url' => $image_url,
            'embed_url' => $this->get_embed_url_from_url( $url ),
        );
    }

    /**
     * Builds the query params that the local worker expects.
     */
    protected function build_oembed_query_params( string $url, ?string $size = null ): array {
        return [
            'site'        => Fifu_Image_Url_Utils::get_home_url_no_scheme(),
            'partial_key' => Fifu_Options_Utils::partial_key(),
            'video_url'   => $url,
        ];
    }

    /**
     * {@inheritDoc}
     */
    protected function get_embed_url_from_url( string $url ): ?string {
        return $this->get_embed_url( $url );
    }
}
