<?php
/**
 * Video provider implementation.
 *
 * Supplies provider-specific metadata to the OO video stack.
 */
class Fifu_Dailymotion_Video_Provider extends Fifu_Video_Worker_Provider {

    /**
     * {@inheritDoc}
     */
    public function supports( string $url ): bool {
        return strpos( $url, 'dailymotion.com' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function get_embed_url( string $url ): ?string {
        if ( strpos( $url, '/video/' ) === false ) {
            return $url;
        }
        return str_replace( '/video/', '/embed/video/', $url );
    }

    /**
     * {@inheritDoc}
     */
    public function get_video_id( string $url ): ?string {
        $parts = explode( '/', $url );
        if ( isset( $parts[4] ) ) {
            return explode( '?', $parts[4] )[0] ?? null;
        }
        return null;
    }

    /**
     * {@inheritDoc}
     */
    public function is_thumbnail( string $src ): bool {
        return $src && strpos( $src, 'dmcdn.net' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function build_thumbnail_filename( string $url ): ?string {
        $path = wp_parse_url( $url, PHP_URL_PATH );
        $name = $path ? basename( $path ) : '';
        return $name ? sanitize_file_name( $name . '.jpg' ) : null;
    }

    /**
     * {@inheritDoc}
     */
    protected function get_slug(): string {
        return 'dailymotion';
    }

    /**
     * {@inheritDoc}
     */
    protected function fetch_remote_metadata( string $url, ?string $size = null ): ?array {
        $params = array(
            'site' => Fifu_Image_Url_Utils::get_home_url_no_scheme(),
            'partial_key' => Fifu_Options_Utils::partial_key(),
            'url' => $url,
            'domain' => Fifu_Image_Url_Utils::get_domain(),
        );

        $image_url = $this->worker_client->get_raw_body( 'dailymotion', $params );
        if ( ! $image_url ) {
            return null;
        }

        return array(
            'image_url' => $image_url,
            'embed_url' => $this->get_embed_url( $url ),
        );
    }
}
