<?php

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Video provider implementation.
 *
 * Supplies provider-specific metadata to the OO video stack.
 */
class Fifu_Cloudinary_Video_Provider extends Fifu_Video_Worker_Provider {

    /**
     * {@inheritDoc}
     */
    public function supports( string $url ): bool {
        return $url !== '' && strpos( $url, 'cloudinary.com' ) !== false && strpos( $url, '/video/' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function get_video_id( string $url ): ?string {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    public function get_embed_url( string $url ): ?string {
        return $url;
    }

    /**
     * {@inheritDoc}
     */
    public function get_social_url( string $url_or_id ): ?string {
        return $url_or_id;
    }

    /**
     * {@inheritDoc}
     */
    public function is_thumbnail( string $src ): bool {
        return $src !== '' && strpos( $src, 'res.cloudinary.com' ) !== false && strpos( $src, '/video/' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function build_thumbnail_filename( string $url ): ?string {
        $path = wp_parse_url( $url, PHP_URL_PATH );
        if ( $path ) {
            $name = pathinfo( $path, PATHINFO_FILENAME );
            return sanitize_file_name( $name . '.jpg' );
        }
        return sanitize_file_name( md5( $url ) . '.jpg' );
    }

    /**
     * {@inheritDoc}
     */
    protected function get_slug(): string {
        return 'cloudinary';
    }

    /**
     * {@inheritDoc}
     */
    protected function fetch_remote_metadata( string $url, ?string $size = null ): ?array {
        $image_url = $this->build_thumbnail_url( $url );
        if ( ! $image_url ) {
            return null;
        }

        return array(
            'image_url' => $image_url,
            'embed_url' => $this->get_embed_url_from_url( $url ),
        );
    }

    /**
     * {@inheritDoc}
     */
    protected function get_embed_url_from_url( string $url ): ?string {
        return $this->get_embed_url( $url );
    }

    /**
     * Builds the thumbnail URL derived from the Cloudinary video URL.
     */
    private function build_thumbnail_url( string $url ): ?string {
        return str_replace( 'mp4', 'jpg', $url );
    }
}
