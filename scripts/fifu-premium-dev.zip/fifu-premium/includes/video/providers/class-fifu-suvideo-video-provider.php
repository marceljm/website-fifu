<?php
/**
 * Video provider implementation.
 *
 * Supplies provider-specific metadata to the OO video stack.
 */
class Fifu_Suvideo_Video_Provider implements Fifu_Video_Provider_Interface {

    /**
     * {@inheritDoc}
     */
    public function supports( string $url ): bool {
        return strpos( $url, 'fifu-thumb=' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function get_embed_url( string $url ): ?string {
        $video_url = $this->extract_video_url( $url );
        if ( ! $video_url ) {
            return null;
        }

        return Fifu_Video_Helper::get_embed_url( $video_url );
    }

    /**
     * {@inheritDoc}
     */
    public function get_image_url( string $url ): ?string {
        return $this->build_thumb_url( $url );
    }

    /**
     * {@inheritDoc}
     */
    public function get_social_image_url( string $url ): ?string {
        return $this->get_image_url( $url );
    }

    /**
     * {@inheritDoc}
     */
    public function is_thumbnail( string $src ): bool {
        return Fifu_Video_Helper::is_suvideo_thumbnail( $src );
    }

    /**
     * {@inheritDoc}
     */
    public function get_video_id( string $url ): ?string {
        $video_url = $this->extract_video_url( $url );
        return $video_url ? Fifu_Video_Helper::get_video_id( $video_url ) : null;
    }

    /**
     * Returns the pure video URL that was encoded inside the thumbnail string.
     */
    private function extract_video_url( string $url ): ?string {
        $result = preg_replace( "/.fifu-thumb=.*/", '', $url );
        return $result ? $result : null;
    }

    /**
     * Builds the public thumbnail URL that matches the legacy suffix logic.
     */
    private function build_thumb_url( string $url ): ?string {
        $video_url = $this->extract_video_url( $url );
        if ( ! $video_url ) {
            return null;
        }

        $image_url = Fifu_Video_Helper::get_thumbnail_large( $video_url );
        if ( ! $image_url ) {
            return null;
        }

        $thumb_only = $this->extract_thumb_part( $url );
        $base = $thumb_only ? $thumb_only : '';
        return $base . '?video-thumb=' . Fifu_Image_Url_Utils::remove_query_strings( $image_url );
    }

    /**
     * Extracts the portion of the URL after “fifu-thumb=” that contains the local path.
     */
    private function extract_thumb_part( string $url ): string {
        return preg_replace( "/.*fifu-thumb=/", '', $url );
    }
}
