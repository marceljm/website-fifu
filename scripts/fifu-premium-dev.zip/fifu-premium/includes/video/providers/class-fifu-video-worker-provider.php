<?php
/**
 * Shared helper for worker-backed video providers.
 *
 * @package FIFU Premium
 */

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

abstract class Fifu_Video_Worker_Provider implements Fifu_Video_Provider_Interface, Fifu_Video_Provider {

    protected Fifu_Db2_Video_Oembed_Repository $repository;
    protected Fifu_Video_Thumbnail_Manager $thumbnail_manager;
    protected Fifu_Video_Worker_Client $worker_client;

    public function __construct(
        Fifu_Db2_Video_Oembed_Repository $repository,
        Fifu_Video_Thumbnail_Manager $thumbnail_manager,
        Fifu_Video_Worker_Client $worker_client
    ) {
        $this->repository = $repository;
        $this->thumbnail_manager = $thumbnail_manager;
        $this->worker_client = $worker_client;
        $this->thumbnail_manager->register_filename_resolver( $this->get_slug(), array( $this, 'build_thumbnail_filename' ) );
    }

    /**
     * {@inheritDoc}
     */
    abstract public function supports( string $url ): bool;

    /**
     * {@inheritDoc}
     */
    abstract public function get_video_id( string $url ): ?string;

    /**
     * {@inheritDoc}
     */
    public function get_image_url( string $url ): ?string {
        $metadata = $this->fetch_cached_metadata( $url );
        return $metadata['image_url'] ?? null;
    }

    /**
     * {@inheritDoc}
     */
    public function get_social_image_url( string $url ): ?string {
        return $this->get_image_url( $url );
    }

    /**
     * {@inheritDoc}
     */
    public function get_embed_url( string $url ): ?string {
        $metadata = $this->fetch_cached_metadata( $url );
        return $metadata['embed_url'] ?? null;
    }

    /**
     * {@inheritDoc}
     */
    abstract public function is_thumbnail( string $src ): bool;

    /**
     * Returns the provider slug used for thumbnail directories.
     *
     * @return string
     */
    abstract protected function get_slug(): string;

    /**
     * Builds the thumbnail filename that will be stored.
     *
     * @param string $url
     * @return string|null
     */
    abstract public function build_thumbnail_filename( string $url ): ?string;

    /**
     * Fetches metadata from cache or remote worker.
     *
     * @param string $url
     * @param string|null $size
     * @return array<string,string|null>|null
     */
    protected function fetch_cached_metadata( string $url, ?string $size = null ): ?array {
        $cached_image = $this->repository->get_image_url_by_video_url( $url );
        $cached_embed = $this->repository->get_embed_url_by_video_url( $url );

        if ( $cached_image && $cached_embed && $size === null && $this->should_store_thumbnail_locally() ) {
            return array(
                'image_url' => $cached_image,
                'embed_url' => $cached_embed,
            );
        }

        $remote = $this->fetch_remote_metadata( $url, $size );
        if ( ! $remote ) {
            if ( $cached_image || $cached_embed ) {
                return array(
                    'image_url' => $cached_image,
                    'embed_url' => $cached_embed,
                );
            }
            return null;
        }

        $image_url = $remote['image_url'] ?? $cached_image;
        $embed_url = $remote['embed_url'] ?? $cached_embed ?? $this->get_embed_url_from_url( $url );

        if ( $image_url && $image_url !== $cached_image && $this->should_store_thumbnail_locally() ) {
            $stored = $this->thumbnail_manager->download_and_store( $url, $image_url, $this->get_slug() );
            if ( $stored ) {
                $image_url = $stored;
            }
        }

        if ( $image_url && $embed_url ) {
            $this->repository->upsert_oembed( $url, $image_url, $embed_url );
        }

        return array(
            'image_url' => $image_url,
            'embed_url' => $embed_url,
        );
    }

    /**
     * Fetches metadata from the worker client.
     *
     * @param string $url
     * @param string|null $size
     * @return array<string,string|null>|null
     */
    abstract protected function fetch_remote_metadata( string $url, ?string $size = null ): ?array;

    /**
     * Returns an embed URL derived from the video URL when the worker doesn't provide one.
     *
     * @param string $url
     * @return string|null
     */
    protected function get_embed_url_from_url( string $url ): ?string {
        return null;
    }

    /**
     * Determines whether thumbnails for this provider should be stored locally by downloading them.
     *
     * @return bool
     */
    protected function should_store_thumbnail_locally(): bool {
        return false;
    }

    /**
     * {@inheritDoc}
     */
    public function get_social_url( string $url_or_id ): ?string {
        return $this->get_embed_url( $url_or_id );
    }

    /**
     * {@inheritDoc}
     */
    public function get_thumbnail_url( string $url, ?string $size = null ): ?string {
        $metadata = $this->fetch_cached_metadata( $url, $size );
        return $metadata['image_url'] ?? null;
    }
}
