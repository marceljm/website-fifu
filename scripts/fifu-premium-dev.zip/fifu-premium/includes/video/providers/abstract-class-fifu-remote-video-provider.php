<?php

declare( strict_types=1 );

/**
 * Base class for remote video providers that fetch metadata from FIFU workers.
 *
 * This class is intended to be extended by Vimeo, YouTube, Local, WP.com, and
 * TikTok providers which all rely on remote oEmbed/thumbnail endpoints.
 */
abstract class Fifu_Remote_Video_Provider implements Fifu_Video_Provider, Fifu_Video_Provider_Interface {

    /**
     * {@inheritDoc}
     */
    abstract public function supports( string $url ): bool;

    /**
     * {@inheritDoc}
     */
    abstract public function get_video_id( string $url ): ?string;

    /**
     * {@inheritDoc}
     */
    abstract public function get_embed_url( string $url ): ?string;

    /**
     * {@inheritDoc}
     */
    abstract public function get_social_url( string $url_or_id ): ?string;

    /**
     * {@inheritDoc}
     */
    abstract public function get_thumbnail_url( string $url, ?string $size = null ): ?string;

    /**
     * {@inheritDoc}
     */
    abstract public function is_thumbnail( string $src ): bool;

    /**
     * Returns the oEmbed endpoint URL for the concrete provider.
     *
     * @return string
     */
    abstract protected function get_oembed_endpoint(): string;

    /**
     * Builds the query arguments that `{provider}-oembed` worker expects.
     *
     * @param string $url
     * @param string|null $size
     * @return array<string, string>
     */
    abstract protected function build_oembed_query_params( string $url, ?string $size = null ): array;

    /**
     * Fetches a thumbnail URL from the remote endpoint for the supplied URL.
     *
     * @param string $url
     * @param string|null $size
     * @return string|null
     */
    protected function fetch_oembed_thumbnail( string $url, ?string $size = null ): ?string {
        $endpoint = $this->get_oembed_endpoint();
        if ( '' === $endpoint ) {
            return null;
        }

        $query_params = $this->build_oembed_query_params( $url, $size );
        if ( empty( $query_params ) ) {
            return null;
        }

        $query = http_build_query( $query_params );
        $url_with_query = $endpoint . ( $query ? '?' . $query : '' );

        $response = wp_remote_get( $url_with_query );
        if ( is_wp_error( $response ) ) {
            return null;
        }

        $status_code = wp_remote_retrieve_response_code( $response );
        if ( 200 !== $status_code ) {
            return null;
        }

        $body = wp_remote_retrieve_body( $response );
        return $body ? $body : null;
    }
}
