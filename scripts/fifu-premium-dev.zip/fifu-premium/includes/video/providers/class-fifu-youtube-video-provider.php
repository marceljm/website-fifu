<?php

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Video provider implementation.
 *
 * Supplies provider-specific metadata to the OO video stack.
 */
class Fifu_Youtube_Video_Provider extends Fifu_Video_Worker_Provider {

    private function get_author_id(): int {
        if ( function_exists( 'fifu_get_author' ) ) {
            return (int) fifu_get_author();
        }

        if ( class_exists( 'Fifu_Options_Utils', false ) && method_exists( 'Fifu_Options_Utils', 'get_author' ) ) {
            return (int) Fifu_Options_Utils::get_author();
        }

        return defined( 'FIFU_AUTHOR' ) ? (int) FIFU_AUTHOR : 7777777777;
    }

    /**
     * {@inheritDoc}
     */
    public function supports( string $url ): bool {
        return $url !== '' && strpos( $url, 'youtu' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function get_video_id( string $url ): ?string {
        preg_match( "/^(?:http(?:s)?:\/\/)?(?:www\.)?(?:m\.)?(?:youtu\.be\/|youtube\.com\/(?:(?:watch)?\?(?:.*&)?v(?:i)?=|(?:embed|v|vi|user|shorts)\/))([^\?&\"'>]+)/", $url, $matches );
        return sizeof( $matches ) > 0 ? ( $matches[1] ?? null ) : null;
    }

    /**
     * {@inheritDoc}
     */
    public function get_embed_url( string $url ): ?string {
        $video_id = $this->get_video_id( $url );
        if ( ! $video_id ) {
            return null;
        }

        $playlist = '';
        if ( strpos( $url, 'list=' ) !== false ) {
            $query_params = array();
            $parsed_url = parse_url( $url, PHP_URL_QUERY );
            parse_str( $parsed_url ?? '', $query_params );
            $playlist = '?list=' . ( $query_params['list'] ?? '' );
        }

        return 'https://www.youtube.com/embed/' . $video_id . $playlist;
    }

    /**
     * {@inheritDoc}
     */
    public function get_social_url( string $url_or_id ): ?string {
        $id = strpos( $url_or_id, 'youtu' ) !== false ? $this->get_video_id( $url_or_id ) : $url_or_id;
        if ( ! $id ) {
            return null;
        }
        return 'https://www.youtube.com/v/' . $id . '?version=3&amp;autohide=1';
    }

    /**
     * {@inheritDoc}
     */
    public function is_thumbnail( string $src ): bool {
        return $src !== '' && strpos( $src, 'img.youtube.com' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function get_thumbnail_url( string $url, ?string $size = null ): ?string {
        if ( $size ) {
            $video_id = $this->get_video_id( $url );
            if ( $video_id ) {
                return 'https://img.youtube.com/vi/' . $video_id . '/' . $size . '.jpg';
            }
            return null;
        }

        $image_url = parent::get_thumbnail_url( $url, $size );
        if ( $image_url && strpos( $image_url, 'mqdefault' ) !== false ) {
            $this->downgrade_maxres_thumbnail_rows(
                str_replace( 'mqdefault', 'maxresdefault', $image_url ),
                $image_url
            );
        }

        return $image_url;
    }

    private function downgrade_maxres_thumbnail_rows( string $maxres_image_url, string $mq_image_url ): void {
        if ( $maxres_image_url === '' || $mq_image_url === '' || $maxres_image_url === $mq_image_url ) {
            return;
        }

        /** @var wpdb $wpdb */
        global $wpdb;

        $author_id = $this->get_author_id();
        if ( $author_id <= 0 ) {
            return;
        }

        $wpdb->update(
            $wpdb->postmeta,
            array( 'meta_value' => $mq_image_url ),
            array(
                'meta_key'   => '_wp_attached_file',
                'meta_value' => $maxres_image_url,
            ),
            array( '%s' ),
            array( '%s', '%s' )
        );

        $wpdb->update(
            $wpdb->posts,
            array( 'post_content_filtered' => $mq_image_url ),
            array(
                'post_author'           => $author_id,
                'post_content_filtered' => $maxres_image_url,
            ),
            array( '%s' ),
            array( '%d', '%s' )
        );
    }

    /**
     * {@inheritDoc}
     */
    public function build_thumbnail_filename( string $url ): ?string {
        $id = $this->get_video_id( $url );
        if ( $id ) {
            return sanitize_file_name( $id . '.jpg' );
        }

        $path = wp_parse_url( $url, PHP_URL_PATH );
        if ( $path ) {
            return sanitize_file_name( basename( $path ) . '.jpg' );
        }

        return sanitize_file_name( md5( $url ) . '.jpg' );
    }

    /**
     * {@inheritDoc}
     */
    protected function get_slug(): string {
        return 'youtube';
    }

    /**
     * {@inheritDoc}
     */
    protected function fetch_remote_metadata( string $url, ?string $size = null ): ?array {
        $params = $this->build_oembed_query_params( $url, $size );
        if ( empty( $params ) ) {
            return null;
        }

        $image_url = $this->worker_client->get_raw_body( $this->get_slug(), $params );
        if ( ! $image_url ) {
            return null;
        }

        return array(
            'image_url' => $image_url,
            'embed_url' => $this->get_embed_url_from_url( $url ),
        );
    }

    /**
     * {@inheritDoc}
     */
    protected function get_embed_url_from_url( string $url ): ?string {
        return $this->get_embed_url( $url );
    }

    /**
     * Builds the query params that the YouTube worker expects.
     */
    protected function build_oembed_query_params( string $url, ?string $size = null ): array {
        $video_id = $this->get_video_id( $url );
        if ( ! $video_id ) {
            return array();
        }

        return [
            'site'        => Fifu_Image_Url_Utils::get_home_url_no_scheme(),
            'partial_key' => Fifu_Options_Utils::partial_key(),
            'video_id'    => $video_id,
        ];
    }
}
