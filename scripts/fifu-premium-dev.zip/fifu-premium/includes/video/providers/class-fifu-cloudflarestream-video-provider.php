<?php
/**
 * Video provider implementation.
 *
 * Supplies provider-specific metadata to the OO video stack.
 */
class Fifu_CloudflareStream_Video_Provider implements Fifu_Video_Provider_Interface {

    /**
     * {@inheritDoc}
     */
    public function supports( string $url ): bool {
        return strpos( $url, 'cloudflarestream.com' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function get_embed_url( string $url ): ?string {
        return preg_replace( '/manifest\\/video.*/', 'iframe', $url );
    }

    /**
     * {@inheritDoc}
     */
    public function get_image_url( string $url ): ?string {
        return preg_replace( '/manifest\\/video.*/', 'thumbnails/thumbnail.jpg', $url );
    }

    /**
     * {@inheritDoc}
     */
    public function get_social_image_url( string $url ): ?string {
        return $this->get_image_url( $url );
    }

    /**
     * {@inheritDoc}
     */
    public function is_thumbnail( string $src ): bool {
        return $src && strpos( $src, 'cloudflarestream.com' ) !== false && strpos( $src, '/thumbnails/' ) !== false;
    }
}
