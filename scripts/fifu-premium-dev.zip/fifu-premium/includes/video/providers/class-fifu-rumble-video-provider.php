<?php
/**
 * Video provider implementation.
 *
 * Supplies provider-specific metadata to the OO video stack.
 */
class Fifu_Rumble_Video_Provider extends Fifu_Video_Worker_Provider {

    /**
     * {@inheritDoc}
     */
    public function supports( string $url ): bool {
        return strpos( $url, 'rumble.com' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function get_video_id( string $url ): ?string {
        $path = wp_parse_url( $url, PHP_URL_PATH );
        if ( ! is_string( $path ) || $path === '' ) {
            return null;
        }

        return sanitize_file_name( basename( $path ) );
    }

    /**
     * {@inheritDoc}
     */
    public function is_thumbnail( string $src ): bool {
        return $src && ( strpos( $src, 'rmbl.ws' ) !== false || strpos( $src, 'rumble.cloud' ) !== false || strpos( $src, '1a-1791.com' ) !== false );
    }

    /**
     * {@inheritDoc}
     */
    public function build_thumbnail_filename( string $url ): ?string {
        $id = $this->get_video_id( $url );
        return $id ? sanitize_file_name( $id . '.jpg' ) : null;
    }

    /**
     * {@inheritDoc}
     */
    protected function get_slug(): string {
        return 'rumble';
    }

    /**
     * {@inheritDoc}
     */
    protected function fetch_remote_metadata( string $url, ?string $size = null ): ?array {
        $params = array(
            'site' => Fifu_Image_Url_Utils::get_home_url_no_scheme(),
            'partial_key' => Fifu_Options_Utils::partial_key(),
            'url' => $url,
            'domain' => Fifu_Image_Url_Utils::get_domain(),
        );

        $payload = $this->worker_client->get_json( 'rumble', $params );
        if ( ! is_array( $payload ) ) {
            return null;
        }

        $image = $payload['image_url'] ?? null;
        $embed = $payload['embed_url'] ?? null;

        if ( ! $image && ! $embed ) {
            return null;
        }

        return array(
            'image_url' => $image,
            'embed_url' => $embed,
        );
    }
}
