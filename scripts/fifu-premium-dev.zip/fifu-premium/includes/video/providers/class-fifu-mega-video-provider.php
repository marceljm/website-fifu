<?php
/**
 * Video provider implementation.
 *
 * Supplies provider-specific metadata to the OO video stack.
 */
class Fifu_Mega_Video_Provider extends Fifu_Video_Worker_Provider {

    /**
     * {@inheritDoc}
     */
    public function supports( string $url ): bool {
        return strpos( $url, 'mega.nz' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function get_video_id( string $url ): ?string {
        $parts = explode( '/', $url );
        if ( isset( $parts[4] ) ) {
            return explode( '!', $parts[4] )[0] ?? null;
        }
        return null;
    }

    /**
     * {@inheritDoc}
     */
    public function get_embed_url( string $url ): ?string {
        $video_id = $this->get_video_id( $url );
        if ( ! $video_id ) {
            return null;
        }
        return 'https://mega.nz/embed/' . $video_id;
    }

    /**
     * {@inheritDoc}
     */
    public function get_social_url( string $url_or_id ): ?string {
        return $this->get_embed_url( $url_or_id );
    }

    /**
     * {@inheritDoc}
     */
    public function is_thumbnail( string $src ): bool {
        return $src && strpos( $src, '/fifu/videothumb/mega/' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function build_thumbnail_filename( string $url ): ?string {
        $id = $this->get_video_id( $url );
        if ( ! $id ) {
            return null;
        }
        return sanitize_file_name( str_replace( '#', '-', $id ) . '.jpg' );
    }

    /**
     * {@inheritDoc}
     */
    protected function get_slug(): string {
        return 'mega';
    }

    /**
     * {@inheritDoc}
     */
    protected function fetch_remote_metadata( string $url, ?string $size = null ): ?array {
        $video_id = $this->get_video_id( $url );
        if ( ! $video_id ) {
            return null;
        }

        $api_key = get_option( 'fifu_ws_key_mega' );
        if ( ! $api_key ) {
            return null;
        }

        $body = array(
            'source' => 'mega',
            'id' => $video_id,
            'key' => $api_key,
        );

        $response = wp_remote_post( 'https://mega.fifu.workers.dev/', array(
            'body' => $body,
            'timeout' => 10,
            'headers' => array(
                'Referer' => Fifu_Image_Url_Utils::get_domain(),
            ),
        ) );

        if ( is_wp_error( $response ) ) {
            return null;
        }

        if ( 200 !== wp_remote_retrieve_response_code( $response ) ) {
            return null;
        }

        $payload = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( ! is_array( $payload ) || ! isset( $payload['create'] ) ) {
            return null;
        }

        $image_url = null;
        if ( $payload['create'] ) {
            $second = wp_remote_post( $payload['url'] ?? '', array(
                'body' => wp_json_encode( $body ),
                'headers' => array(
                    'Content-Type' => 'application/json',
                ),
                'timeout' => 10,
            ) );
            if ( ! is_wp_error( $second ) && 200 === wp_remote_retrieve_response_code( $second ) ) {
                $image_url = wp_remote_retrieve_body( $second );
            }
        } else {
            $image_url = $payload['url'] ?? null;
        }

        if ( ! $image_url ) {
            return null;
        }

        return array(
            'image_url' => $image_url,
        );
    }

    /**
     * {@inheritDoc}
     */
    protected function should_store_thumbnail_locally(): bool {
        return true;
    }

    /**
     * {@inheritDoc}
     */
    protected function get_embed_url_from_url( string $url ): ?string {
        return $this->get_embed_url( $url );
    }
}
