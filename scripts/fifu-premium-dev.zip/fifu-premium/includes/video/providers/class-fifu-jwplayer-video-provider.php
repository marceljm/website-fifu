<?php
/**
 * Video provider implementation.
 *
 * Supplies provider-specific metadata to the OO video stack.
 */
class Fifu_JWPlayer_Video_Provider extends Fifu_Video_Worker_Provider {

    /**
     * {@inheritDoc}
     */
    public function supports( string $url ): bool {
        return strpos( $url, 'jwplayer.com' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function get_video_id( string $url ): ?string {
        $segments = explode( '/', $url );
        $candidate = $segments[4] ?? '';
        $parts = explode( '.', $candidate );
        return $parts[0] ?? null;
    }

    /**
     * {@inheritDoc}
     */
    public function get_embed_url( string $url ): ?string {
        $id = $this->get_video_id( $url );
        if ( ! $id ) {
            return null;
        }
        return 'https://content.jwplatform.com/players/' . $id . '.html';
    }

    /**
     * {@inheritDoc}
     */
    public function get_social_url( string $url_or_id ): ?string {
        $id = $this->get_video_id( $url_or_id ) ?? $url_or_id;
        if ( ! $id ) {
            return null;
        }
        return 'https://cdn.jwplayer.com/players/' . $id . '.html';
    }

    /**
     * {@inheritDoc}
     */
    public function is_thumbnail( string $src ): bool {
        return $src && strpos( $src, 'jwplatform.com' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function build_thumbnail_filename( string $url ): ?string {
        $id = $this->get_video_id( $url );
        return $id ? sanitize_file_name( $id . '.jpg' ) : null;
    }

    /**
     * {@inheritDoc}
     */
    protected function get_slug(): string {
        return 'jwplayer';
    }

    /**
     * {@inheritDoc}
     */
    protected function fetch_remote_metadata( string $url, ?string $size = null ): ?array {
        $id = $this->get_video_id( $url );
        if ( ! $id ) {
            return null;
        }

        $params = array(
            'site' => Fifu_Image_Url_Utils::get_home_url_no_scheme(),
            'partial_key' => Fifu_Options_Utils::partial_key(),
            'video_id' => $id,
        );

        $image_url = $this->worker_client->get_raw_body( 'jwplayer', $params );
        if ( ! $image_url ) {
            return null;
        }

        return array(
            'image_url' => $image_url,
            'embed_url' => $this->get_embed_url_from_url( $url ),
        );
    }
}
