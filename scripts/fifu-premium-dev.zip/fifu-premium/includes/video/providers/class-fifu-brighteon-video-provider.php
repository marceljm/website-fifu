<?php
/**
 * Video provider implementation.
 *
 * Supplies provider-specific metadata to the OO video stack.
 */
class Fifu_Brighteon_Video_Provider extends Fifu_Video_Worker_Provider {

    /**
     * {@inheritDoc}
     */
    public function supports( string $url ): bool {
        return strpos( $url, 'www.brighteon.com' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function get_video_id( string $url ): ?string {
        $parts = explode( '/', $url );
        return $parts[3] ?? null;
    }

    /**
     * {@inheritDoc}
     */
    public function get_embed_url( string $url ): ?string {
        $id = $this->get_video_id( $url );
        if ( ! $id ) {
            return null;
        }
        return 'https://www.brighteon.com/embed/' . $id;
    }

    /**
     * {@inheritDoc}
     */
    public function is_thumbnail( string $src ): bool {
        return $src && ( strpos( $src, 'photos.brighteon.com' ) !== false || strpos( $src, 'video.brighteon.com' ) !== false );
    }

    /**
     * {@inheritDoc}
     */
    public function build_thumbnail_filename( string $url ): ?string {
        $id = $this->get_video_id( $url );
        return $id ? sanitize_file_name( $id . '.jpg' ) : null;
    }

    /**
     * {@inheritDoc}
     */
    protected function get_slug(): string {
        return 'brighteon';
    }

    /**
     * {@inheritDoc}
     */
    protected function fetch_remote_metadata( string $url, ?string $size = null ): ?array {
        $params = array(
            'site' => Fifu_Image_Url_Utils::get_home_url_no_scheme(),
            'partial_key' => Fifu_Options_Utils::partial_key(),
            'url' => $url,
            'domain' => Fifu_Image_Url_Utils::get_domain(),
        );

        $image_url = $this->worker_client->get_raw_body( 'brighteon', $params );
        if ( ! $image_url ) {
            return null;
        }

        return array(
            'image_url' => $image_url,
        );
    }

    /**
     * {@inheritDoc}
     */
    protected function get_embed_url_from_url( string $url ): ?string {
        return $this->get_embed_url( $url );
    }
}
