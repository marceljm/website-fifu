<?php
/**
 * Video provider implementation.
 *
 * Supplies provider-specific metadata to the OO video stack.
 */
class Fifu_Odysee_Video_Provider extends Fifu_Video_Worker_Provider {

    /**
     * {@inheritDoc}
     */
    public function supports( string $url ): bool {
        return strpos( $url, 'odysee.com' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function get_video_id( string $url ): ?string {
        $parts = explode( '/', $url );
        $section = ( $parts[3] ?? '' );
        $second = ( $parts[4] ?? '' );
        $id = trim( $section . '/' . $second, '/' );
        return $id ?: null;
    }

    /**
     * {@inheritDoc}
     */
    public function get_embed_url( string $url ): ?string {
        $video_id = $this->get_video_id( $url );
        if ( ! $video_id ) {
            return null;
        }
        return 'https://odysee.com/$/embed/' . $video_id;
    }

    /**
     * {@inheritDoc}
     */
    public function is_thumbnail( string $src ): bool {
        return $src && strpos( $src, 'thumbnails.odycdn.com' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function build_thumbnail_filename( string $url ): ?string {
        $video_id = $this->get_video_id( $url );
        if ( ! $video_id ) {
            return null;
        }
        return sanitize_file_name( str_replace( '/', '-', $video_id ) . '.jpg' );
    }

    /**
     * {@inheritDoc}
     */
    protected function get_slug(): string {
        return 'odysee';
    }

    /**
     * {@inheritDoc}
     */
    protected function fetch_remote_metadata( string $url, ?string $size = null ): ?array {
        $params = array(
            'site' => Fifu_Image_Url_Utils::get_home_url_no_scheme(),
            'partial_key' => Fifu_Options_Utils::partial_key(),
            'url' => $url,
            'domain' => Fifu_Image_Url_Utils::get_domain(),
        );

        $image_url = $this->worker_client->get_raw_body( 'odysee', $params );
        if ( ! $image_url ) {
            return null;
        }

        return array(
            'image_url' => $image_url,
            'embed_url' => $this->get_embed_url( $url ),
        );
    }
}
