<?php

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Video provider implementation.
 *
 * Supplies provider-specific metadata to the OO video stack.
 */
class Fifu_Vimeo_Video_Provider extends Fifu_Video_Worker_Provider {

    private const DEFAULT_MP4_RENDITION = '540p';

    private const SUPPORTED_MP4_RENDITIONS = array(
        '1080p',
        '720p',
        '540p',
        '360p',
        '240p',
    );

    /**
     * {@inheritDoc}
     */
    public function supports( string $url ): bool {
        return $url !== '' && strpos( $url, 'vimeo' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function get_video_id( string $url ): ?string {
        preg_match( "/(https?:\/\/)?(www\.)?(player\.)?vimeo\.com\/([a-z]*\/)*([0-9]{6,11}[\/]*[a-z0-9]*)[?]?.*/", $url, $matches );
        return sizeof( $matches ) > 4 ? ( $matches[5] ?? null ) : null;
    }

    /**
     * {@inheritDoc}
     */
    public function get_embed_url( string $url ): ?string {
        $video_id = $this->get_video_id( $url );
        if ( ! $video_id ) {
            return null;
        }
        return 'https://player.vimeo.com/video/' . str_replace( '/', '?h=', $video_id );
    }

    /**
     * {@inheritDoc}
     */
    public function get_social_url( string $url_or_id ): ?string {
        $id = strpos( $url_or_id, 'vimeo' ) !== false ? $this->get_video_id( $url_or_id ) : $url_or_id;
        if ( ! $id ) {
            return null;
        }
        return 'https://player.vimeo.com/video/' . $id . '?autoplay=1';
    }

    /**
     * {@inheritDoc}
     */
    public function is_thumbnail( string $src ): bool {
        return $src !== '' && strpos( $src, 'i.vimeocdn.com' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function build_thumbnail_filename( string $url ): ?string {
        $id = $this->get_video_id( $url );
        if ( $id ) {
            return sanitize_file_name( $id . '.jpg' );
        }

        $path = wp_parse_url( $url, PHP_URL_PATH );
        if ( $path ) {
            return sanitize_file_name( basename( $path ) . '.jpg' );
        }

        return sanitize_file_name( md5( $url ) . '.jpg' );
    }

    /**
     * {@inheritDoc}
     */
    protected function get_slug(): string {
        return 'vimeo';
    }

    /**
     * {@inheritDoc}
     */
    protected function fetch_remote_metadata( string $url, ?string $size = null ): ?array {
        $token = trim( (string) get_option( 'fifu_vimeo_access_token' ) );
        if ( $token !== '' ) {
            $metadata = $this->fetch_remote_metadata_from_vimeo_api( $url, $token );
            if ( $metadata !== null ) {
                return $metadata;
            }
        }

        $params = $this->build_oembed_query_params( $url, $size );
        if ( empty( $params ) ) {
            return null;
        }

        $image_url = $this->worker_client->get_raw_body( $this->get_slug(), $params );
        if ( ! $image_url ) {
            return null;
        }

        return array(
            'image_url' => $image_url,
            'embed_url' => $this->get_embed_url_from_url( $url ),
        );
    }

    /**
     * Fetches Vimeo metadata directly from the Vimeo API when access-token mode is enabled.
     */
    private function fetch_remote_metadata_from_vimeo_api( string $url, string $token ): ?array {
        $video_id = $this->get_numeric_video_id( $url );
        if ( ! $video_id ) {
            return null;
        }

        $api_url = sprintf( 'https://api.vimeo.com/videos/%s?fields=uri,name,link,duration,pictures.sizes,files', $video_id );
        $response = wp_remote_get(
            $api_url,
            array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $token,
                    'Accept' => 'application/vnd.vimeo.*+json;version=3.4',
                ),
                'timeout' => 10,
            )
        );

        if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
            return null;
        }

        $body = wp_remote_retrieve_body( $response );
        if ( ! is_string( $body ) || trim( $body ) === '' ) {
            return null;
        }

        $data = json_decode( $body, true );
        if ( ! is_array( $data ) ) {
            return null;
        }

        $thumbnail = $this->select_highest_thumbnail_from_api_data( $data );
        $embed_url = $this->select_mp4_from_api_data( $data );

        if ( ! $thumbnail || ! $embed_url ) {
            return null;
        }

        return array(
            'image_url' => $thumbnail,
            'embed_url' => $embed_url,
        );
    }

    /**
     * Extracts the numeric Vimeo video ID for API requests.
     */
    private function get_numeric_video_id( string $url ): ?string {
        $video_id = $this->get_video_id( $url );
        if ( ! $video_id ) {
            return null;
        }

        if ( preg_match( '/^([0-9]{6,11})/', $video_id, $matches ) === 1 ) {
            return $matches[1];
        }

        return null;
    }

    /**
     * Picks the highest-resolution thumbnail from the Vimeo API response.
     */
    private function select_highest_thumbnail_from_api_data( array $data ): ?string {
        $sizes = $data['pictures']['sizes'] ?? null;
        if ( ! is_array( $sizes ) ) {
            return null;
        }

        $best = null;
        $best_area = 0;

        foreach ( $sizes as $size ) {
            if ( ! is_array( $size ) || empty( $size['link'] ) ) {
                continue;
            }

            $width = isset( $size['width'] ) ? (int) $size['width'] : 0;
            $height = isset( $size['height'] ) ? (int) $size['height'] : 0;
            $area = $width * $height;

            if ( $area > $best_area ) {
                $best_area = $area;
                $best = $size['link'];
            }
        }

        return is_string( $best ) && $best !== '' ? $best : null;
    }

    /**
     * Picks the best MP4 file from the Vimeo API response.
     */
    private function select_mp4_from_api_data( array $data ): ?string {
        $files = $data['files'] ?? null;
        if ( ! is_array( $files ) ) {
            return null;
        }

        $selected_rendition = $this->get_selected_mp4_rendition();
        $selected_height = $this->extract_rendition_height( $selected_rendition );
        $mp4_files = array();
        foreach ( $files as $file ) {
            if ( ! is_array( $file ) || ( $file['type'] ?? '' ) !== 'video/mp4' || empty( $file['link'] ) ) {
                continue;
            }

            $rendition = isset( $file['rendition'] ) ? trim( (string) $file['rendition'] ) : '';
            $rendition_height = $this->extract_rendition_height( $rendition );
            $height = isset( $file['height'] ) ? (int) $file['height'] : 0;
            $mp4_files[] = array(
                'link' => (string) $file['link'],
                'rendition' => $rendition,
                'rendition_height' => $rendition_height,
                'height' => $height,
            );
        }

        if ( empty( $mp4_files ) ) {
            return null;
        }

        foreach ( $mp4_files as $file ) {
            if ( $file['rendition'] === $selected_rendition ) {
                return $file['link'];
            }
        }

        $below = array();
        $above = array();
        foreach ( $mp4_files as $file ) {
            $rendition_height = (int) $file['rendition_height'];
            if ( $rendition_height > 0 && $rendition_height < $selected_height ) {
                $below[] = $file;
                continue;
            }

            if ( $rendition_height > $selected_height ) {
                $above[] = $file;
            }
        }

        if ( ! empty( $below ) ) {
            usort(
                $below,
                static function ( array $left, array $right ): int {
                    return $right['rendition_height'] <=> $left['rendition_height'];
                }
            );
            return $below[0]['link'];
        }

        usort(
            $above,
            static function ( array $left, array $right ): int {
                $left_height = $left['rendition_height'] > 0 ? $left['rendition_height'] : $left['height'];
                $right_height = $right['rendition_height'] > 0 ? $right['rendition_height'] : $right['height'];
                return $left_height <=> $right_height;
            }
        );

        return $above[0]['link'] ?? null;
    }

    private function get_selected_mp4_rendition(): string {
        $rendition = trim( (string) get_option( 'fifu_vimeo_mp4_rendition', self::DEFAULT_MP4_RENDITION ) );

        if ( ! in_array( $rendition, self::SUPPORTED_MP4_RENDITIONS, true ) ) {
            return self::DEFAULT_MP4_RENDITION;
        }

        return $rendition;
    }

    /**
     * Converts a Vimeo rendition string like 720p to an integer height.
     */
    private function extract_rendition_height( string $rendition ): int {
        if ( preg_match( '/^(\d{3,4})p$/', $rendition, $matches ) === 1 ) {
            return (int) $matches[1];
        }

        return 0;
    }

    /**
     * {@inheritDoc}
     */
    protected function get_embed_url_from_url( string $url ): ?string {
        return $this->get_embed_url( $url );
    }

    /**
     * Builds the query params that the Vimeo worker expects.
     */
    protected function build_oembed_query_params( string $url, ?string $size = null ): array {
        $params = [
            'site'        => Fifu_Image_Url_Utils::get_home_url_no_scheme(),
            'partial_key' => Fifu_Options_Utils::partial_key(),
            'id'          => $this->get_video_id( $url ),
            'url'         => $url,
            'domain'      => Fifu_Image_Url_Utils::get_domain(),
        ];

        if ( $size !== null ) {
            $params['size'] = $size;
        }

        return array_filter( $params, static function ( $value ) {
            return $value !== null && $value !== '';
        } );
    }
}
