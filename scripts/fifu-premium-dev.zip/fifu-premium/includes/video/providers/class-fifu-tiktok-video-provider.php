<?php

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Video provider implementation.
 *
 * Supplies provider-specific metadata to the OO video stack.
 */
class Fifu_Tiktok_Video_Provider extends Fifu_Video_Worker_Provider {

    /**
     * {@inheritDoc}
     */
    public function supports( string $url ): bool {
        return $url !== '' && strpos( $url, 'tiktok.com' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function get_video_id( string $url ): ?string {
        $parts = explode( '/', $url );
        if ( isset( $parts[5] ) ) {
            return explode( '?', $parts[5] )[0] ?? null;
        }
        return null;
    }

    /**
     * {@inheritDoc}
     */
    public function get_embed_url( string $url ): ?string {
        $video_id = $this->get_video_id( $url );
        if ( ! $video_id ) {
            return null;
        }
        return 'https://www.tiktok.com/embed/v2/' . $video_id;
    }

    /**
     * {@inheritDoc}
     */
    public function get_social_url( string $url_or_id ): ?string {
        return $this->get_embed_url( $url_or_id );
    }

    /**
     * {@inheritDoc}
     */
    public function is_thumbnail( string $src ): bool {
        return $src !== '' && strpos( $src, 'tiktokcdn.com' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function build_thumbnail_filename( string $url ): ?string {
        $video_id = $this->get_video_id( $url );
        if ( $video_id ) {
            return sanitize_file_name( $video_id . '.jpg' );
        }

        $path = wp_parse_url( $url, PHP_URL_PATH );
        if ( $path ) {
            return sanitize_file_name( basename( $path ) . '.jpg' );
        }

        return sanitize_file_name( md5( $url ) . '.jpg' );
    }

    /**
     * {@inheritDoc}
     */
    protected function get_slug(): string {
        return 'tiktok';
    }

    /**
     * {@inheritDoc}
     */
    protected function fetch_remote_metadata( string $url, ?string $size = null ): ?array {
        $params = $this->build_oembed_query_params( $url, $size );
        if ( empty( $params ) ) {
            return null;
        }

        $image_url = $this->worker_client->get_raw_body( $this->get_slug(), $params );
        if ( ! $image_url ) {
            return null;
        }

        return array(
            'image_url' => $image_url,
            'embed_url' => $this->get_embed_url_from_url( $url ),
        );
    }

    /**
     * Builds the query params that the TikTok worker expects.
     */
    protected function build_oembed_query_params( string $url, ?string $size = null ): array {
        return [
            'site'        => Fifu_Image_Url_Utils::get_home_url_no_scheme(),
            'partial_key' => Fifu_Options_Utils::partial_key(),
            'url'         => $url,
            'domain'      => Fifu_Image_Url_Utils::get_domain(),
        ];
    }

    /**
     * {@inheritDoc}
     */
    protected function get_embed_url_from_url( string $url ): ?string {
        return $this->get_embed_url( $url );
    }
}
