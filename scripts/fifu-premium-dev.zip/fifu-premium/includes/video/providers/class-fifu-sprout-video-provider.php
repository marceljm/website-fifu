<?php
/**
 * Video provider implementation.
 *
 * Supplies provider-specific metadata to the OO video stack.
 */
class Fifu_Sprout_Video_Provider extends Fifu_Video_Worker_Provider {

    /**
     * {@inheritDoc}
     */
    public function supports( string $url ): bool {
        return strpos( $url, 'vids.io' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function get_video_id( string $url ): ?string {
        $parts = explode( '/videos/', $url );
        $after = $parts[1] ?? '';
        $segment = explode( '/', $after )[0] ?? '';
        return $segment ?: null;
    }

    /**
     * {@inheritDoc}
     */
    public function get_embed_url( string $url ): ?string {
        $data = $this->fetch_cached_metadata( $url );
        return $data['embed_url'] ?? null;
    }

    /**
     * {@inheritDoc}
     */
    public function is_thumbnail( string $src ): bool {
        return $src && strpos( $src, 'cdn-thumbnails.sproutvideo.com' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function build_thumbnail_filename( string $url ): ?string {
        $id = $this->get_video_id( $url );
        return $id ? sanitize_file_name( $id . '.jpg' ) : null;
    }

    /**
     * {@inheritDoc}
     */
    protected function get_slug(): string {
        return 'sprout';
    }

    /**
     * {@inheritDoc}
     */
    protected function fetch_remote_metadata( string $url, ?string $size = null ): ?array {
        $params = array(
            'site' => Fifu_Image_Url_Utils::get_home_url_no_scheme(),
            'partial_key' => Fifu_Options_Utils::partial_key(),
            'url' => $url,
            'domain' => Fifu_Image_Url_Utils::get_domain(),
        );

        $embed_url = $this->worker_client->get_raw_body( 'sprout', $params );
        if ( ! $embed_url ) {
            return null;
        }

        $image_url = $this->build_image_url_from_embed( $embed_url );
        return array(
            'image_url' => $image_url,
            'embed_url' => $embed_url,
        );
    }

    /**
     * {@inheritDoc}
     */
    protected function get_embed_url_from_url( string $url ): ?string {
        $cached = $this->repository->get_embed_url_by_video_url( $url );
        return $cached;
    }

    /**
     * Builds Sprout thumbnail URL from the embed URL.
     *
     * @param string $embed_url
     * @return string|null
     */
    private function build_image_url_from_embed( string $embed_url ): ?string {
        $segments = explode( '/', $embed_url );
        $video_id = $segments[4] ?? '';
        $security_token = $segments[5] ?? '';

        if ( ! $video_id || ! $security_token ) {
            return null;
        }

        return sprintf( 'https://cdn-thumbnails.sproutvideo.com/%s/%s/1/', $video_id, $security_token );
    }
}
