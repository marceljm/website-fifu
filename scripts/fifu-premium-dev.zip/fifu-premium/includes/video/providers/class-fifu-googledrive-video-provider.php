<?php
/**
 * Video provider implementation.
 *
 * Supplies provider-specific metadata to the OO video stack.
 */
class Fifu_GoogleDrive_Video_Provider extends Fifu_Video_Worker_Provider {

    /**
     * {@inheritDoc}
     */
    public function supports( string $url ): bool {
        return false !== strpos( $url, 'drive.google.com/file' );
    }

    /**
     * {@inheritDoc}
     */
    public function is_thumbnail( string $src ): bool {
        return $src && strpos( $src, '/fifu/videothumb/googledrive/' ) !== false;
    }

    /**
     * {@inheritDoc}
     */
    public function build_thumbnail_filename( string $url ): ?string {
        $video_id = $this->get_video_id( $url );
        return $video_id ? $video_id . '.jpg' : null;
    }

    /**
     * {@inheritDoc}
     */
    protected function get_slug(): string {
        return 'googledrive';
    }

    /**
     * {@inheritDoc}
     */
    protected function fetch_remote_metadata( string $url, ?string $size = null ): ?array {
        $video_id = $this->get_video_id( $url );
        if ( ! $video_id ) {
            return null;
        }

        $params = array(
            'site'        => Fifu_Image_Url_Utils::get_home_url_no_scheme(),
            'partial_key' => Fifu_Options_Utils::partial_key(),
            'video_id'    => $video_id,
            'domain'      => Fifu_Image_Url_Utils::get_domain(),
        );
        $image_url = $this->worker_client->get_raw_body( 'googledrive', $params );
        if ( ! $image_url ) {
            return null;
        }

        return array(
            'image_url' => $image_url,
            'embed_url' => $this->get_embed_url_from_url( $url ),
        );
    }

    /**
     * {@inheritDoc}
     */
    protected function should_store_thumbnail_locally(): bool {
        return true;
    }

    /**
     * {@inheritDoc}
     */
    protected function get_embed_url_from_url( string $url ): ?string {
        $video_id = $this->get_video_id( $url );
        if ( ! $video_id ) {
            return null;
        }
        return 'https://drive.google.com/file/d/' . $video_id . '/preview';
    }

    /**
     * Extracts the Google Drive video ID from the URL.
     *
     * @param string $url
     * @return string|null
     */
    public function get_video_id( string $url ): ?string {
        $parts = explode( '/', $url );
        if ( isset( $parts[5] ) ) {
            return explode( '/', $parts[5] )[0] ?? null;
        }
        return null;
    }
}
