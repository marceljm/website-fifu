<?php
/**
 * Client for remote video workers.
 *
 * @package FIFU Premium
 */

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Provides access to worker endpoints that handle video metadata.
 */
class Fifu_Video_Worker_Client {

    /**
     * Retrieves raw body content from a worker domain.
     *
     * @param string $worker_subdomain
     * @param array<string,mixed> $params
     * @return string|null
     */
    public function get_raw_body( string $worker_subdomain, array $params ): ?string {
        $url = $this->build_endpoint( $worker_subdomain, $params );
        $response = wp_remote_get( $url );
        if ( is_wp_error( $response ) ) {
            Fifu_File_Logger::plugin(
                array(
                    'fifu_video_worker_client' => array(
                        'url' => $url,
                        'error' => $response->get_error_message(),
                    ),
                )
            );
            return null;
        }

        $status_code = wp_remote_retrieve_response_code( $response );
        if ( 200 !== $status_code ) {
            return null;
        }

        $body = wp_remote_retrieve_body( $response );
        return $body ? $body : null;
    }

    /**
     * Retrieves JSON payload from a worker domain.
     *
     * @param string $worker_subdomain
     * @param array<string,mixed> $params
     * @return array<string,mixed>|null
     */
    public function get_json( string $worker_subdomain, array $params ): ?array {
        $body = $this->get_raw_body( $worker_subdomain, $params );
        if ( ! $body ) {
            return null;
        }

        $decoded = json_decode( $body, true );
        if ( json_last_error() !== JSON_ERROR_NONE || ! is_array( $decoded ) ) {
            return null;
        }

        return $decoded;
    }

    /**
     * Builds the worker endpoint URL with query parameters.
     *
     * @param string $worker_subdomain
     * @param array<string,mixed> $params
     * @return string
     */
    /**
     * @var array<string,string>
     */
    private const WORKER_DOMAINS = array(
        'vimeo' => 'https://oembed-vimeo.fifu.app',
    );

    private function build_endpoint( string $worker_subdomain, array $params ): string {
        $base = self::WORKER_DOMAINS[ $worker_subdomain ] ?? sprintf( 'https://oembed-%s.fifu.workers.dev', $worker_subdomain );
        if ( empty( $params ) ) {
            return $base;
        }
        return $base . '?' . http_build_query( $params );
    }
}
