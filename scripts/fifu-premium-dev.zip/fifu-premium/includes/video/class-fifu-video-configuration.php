<?php

declare( strict_types=1 );

defined( 'ABSPATH' ) || exit;

/**
 * Encapsula os flags de configuração de comportamento de vídeo do plugin.
 */
final class Fifu_Video_Configuration {

    /**
     * @return bool
     */
    public static function is_mouse_enabled(): bool {
        return Fifu_Options_Utils::is_on( 'fifu_mouse_video' );
    }

    /**
     * @return bool
     */
    public static function is_autoplay_enabled(): bool {
        return Fifu_Options_Utils::is_on( 'fifu_autoplay' );
    }

    /**
     * @return bool
     */
    public static function is_autoplay_front_enabled(): bool {
        return Fifu_Options_Utils::is_on( 'fifu_autoplay_front' );
    }

    /**
     * @return bool
     */
    public static function is_autoplay_front_all_enabled(): bool {
        return Fifu_Options_Utils::is_on( 'fifu_autoplay_front_all' );
    }

    /**
     * @return bool
     */
    public static function is_autoplay_elsewhere_enabled(): bool {
        return Fifu_Options_Utils::is_on( 'fifu_autoplay_elsewhere' );
    }

    /**
     * @return bool
     */
    public static function is_muted(): bool {
        return Fifu_Options_Utils::is_on( 'fifu_video_mute' );
    }

    /**
     * @return bool
     */
    public static function is_muted_on_mobile(): bool {
        return Fifu_Options_Utils::is_on( 'fifu_video_mute_mobile' );
    }

    /**
     * @return bool
     */
    public static function is_background_enabled(): bool {
        return Fifu_Options_Utils::is_on( 'fifu_video_background' );
    }

    /**
     * @return bool
     */
    public static function is_loop_enabled(): bool {
        return Fifu_Options_Utils::is_on( 'fifu_loop' );
    }

    /**
     * Calculates the play button padding based on the configured font size.
     *
     * @param int $font_size Font size in pixels.
     * @return string
     */
    public static function get_play_button_padding( int $font_size ): string {
        if ( $font_size > 20 && $font_size < 50 ) {
            return '2px 0px 2px 5px';
        }

        if ( $font_size <= 20 ) {
            return '1px 0px 1px 3px';
        }

        return '3px 0px 3px 7px';
    }
}
