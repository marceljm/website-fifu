<?php
/**
 * Registry that keeps track of available video providers.
 *
 * @package FIFU Premium
 */

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! interface_exists( 'Fifu_Video_Provider' ) && file_exists( __DIR__ . '/providers/interface-fifu-video-provider.php' ) ) {
    require_once __DIR__ . '/providers/interface-fifu-video-provider.php';
}

/**
 * Manages video provider registration and lookups.
 */
class Fifu_Video_Provider_Registry {

    /**
     * @var Fifu_Video_Provider_Registry|null
     */
    private static ?Fifu_Video_Provider_Registry $instance = null;

    /**
     * @var Fifu_Video_Provider_Interface[]
     */
    private array $providers = array();

    /**
     * @return Fifu_Video_Provider_Registry
     */
    public static function instance(): Fifu_Video_Provider_Registry {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Registers a provider instance.
     *
     * @param Fifu_Video_Provider_Interface $provider
     */
    public function register( Fifu_Video_Provider_Interface $provider ): void {
        $this->providers[] = $provider;
    }

    public function get_providers(): array {
        return $this->providers;
    }

    /**
     * @param string $class_name
     * @return Fifu_Video_Provider_Interface|null
     */
    public function get_provider_by_class( string $class_name ): ?Fifu_Video_Provider_Interface {
        foreach ( $this->providers as $provider ) {
            if ( $provider instanceof $class_name ) {
                return $provider;
            }
        }
        return null;
    }

    /**
     * @param string $url
     * @return Fifu_Video_Provider_Interface|null
     */
    public function get_provider_for_url( string $url ): ?Fifu_Video_Provider_Interface {
        foreach ( $this->providers as $provider ) {
            if ( $provider->supports( $url ) ) {
                return $provider;
            }
        }
        return null;
    }

    /**
     * @param string $url
     * @return string|null
     */
    public function get_embed_url( string $url ): ?string {
        $provider = $this->get_provider_for_url( $url );
        return $provider ? $provider->get_embed_url( $url ) : null;
    }

    /**
     * @param string $url
     * @return string|null
     */
    public function get_image_url( string $url ): ?string {
        $provider = $this->get_provider_for_url( $url );
        return $provider ? $provider->get_image_url( $url ) : null;
    }

    /**
     * @param string $url
     * @return string|null
     */
    public function get_social_image_url( string $url ): ?string {
        $provider = $this->get_provider_for_url( $url );
        return $provider ? $provider->get_social_image_url( $url ) : null;
    }

    /**
     * @param string $src
     * @return bool
     */
    public function is_thumbnail( string $src ): bool {
        foreach ( $this->providers as $provider ) {
            if ( $provider->is_thumbnail( $src ) ) {
                return true;
            }
        }
        return false;
    }
}
