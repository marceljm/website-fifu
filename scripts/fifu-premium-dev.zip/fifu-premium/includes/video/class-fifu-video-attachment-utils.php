<?php

declare( strict_types=1 );

defined( 'ABSPATH' ) || exit;

/**
 * Utilitários para manipular metadados de anexos de vídeo.
 */
final class Fifu_Video_Attachment_Utils {

    /**
     * Atualiza dimensões e metadados quando um anexo do YouTube é salvo.
     *
     * @param int $attachment_id
     * @param string $url
     */
    public static function update_youtube_dimensions( int $attachment_id, string $url ): void {
        $metadata = wp_get_attachment_metadata( $attachment_id );
        if ( ! $metadata ) {
            return;
        }

        $width = $metadata['width'] ?? 0;
        $height = $metadata['height'] ?? 0;
        if ( $width !== 120 || $height !== 90 ) {
            return;
        }

        update_post_meta( $attachment_id, '_wp_attached_file', $url );

        global $wpdb; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
        $wpdb->update(
            $wpdb->posts,
            [
                'post_content_filtered' => $url,
            ],
            [
                'ID' => $attachment_id,
            ]
        );

        $metadata['width']  = 320;
        $metadata['height'] = 180;
        wp_update_attachment_metadata( $attachment_id, $metadata );
    }
}
