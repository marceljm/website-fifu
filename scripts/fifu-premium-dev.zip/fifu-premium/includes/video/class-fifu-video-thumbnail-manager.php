<?php
/**
 * Handles thumbnail downloads for remote videos.
 *
 * @package FIFU Premium
 */

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'download_url' ) ) {
    require_once ABSPATH . 'wp-admin/includes/file.php';
}

/**
 * Manages remote video thumbnails.
 */
class Fifu_Video_Thumbnail_Manager {

    /**
     * @var array<string, callable>
     */
    private array $filename_resolvers = array();

    /**
     * @var string[]
     */
    private const ALLOWED_SLUGS = array(
        'googledrive',
        'mega',
    );

    /**
     * Registers a resolver which builds the filename for a slug.
     *
     * @param string $slug
     * @param callable $resolver
     */
    public function register_filename_resolver( string $slug, callable $resolver ): void {
        $this->filename_resolvers[ $slug ] = $resolver;
    }

    /**
     * Downloads a video thumbnail and stores it locally.
     *
     * @param string $video_url
     * @param string $thumbnail_url
     * @param string $slug
     * @return string|null
     */
    public function download_and_store( string $video_url, string $thumbnail_url, string $slug ): ?string {
        if ( empty( $thumbnail_url ) ) {
            return null;
        }

        if ( ! in_array( $slug, self::ALLOWED_SLUGS, true ) ) {
            return null;
        }

        $tmp = download_url( $thumbnail_url );
        if ( ! $tmp || is_wp_error( $tmp ) || ! is_string( $tmp ) ) {
            Fifu_File_Logger::plugin(
                array(
                    'fifu_video_thumbnail_manager' => array(
                        'error' => is_wp_error( $tmp ) ? $tmp->get_error_message() : 'download_failed',
                        'thumbnail_url' => $thumbnail_url,
                    ),
                )
            );
            return null;
        }

        $filename = $this->resolve_filename( $slug, $video_url );
        if ( ! $filename ) {
            @unlink( $tmp );
            return null;
        }

        $upload_dir = wp_upload_dir();
        $base_dir = $upload_dir['basedir'] ?? '';
        $base_url = $upload_dir['baseurl'] ?? '';
        $subdir = sprintf( '/fifu/videothumb/%s', $slug );
        $target_dir = $base_dir . $subdir;

        if ( ! file_exists( $target_dir ) ) {
            wp_mkdir_p( $target_dir );
        }

        $target_path = sprintf( '%s/%s', rtrim( $target_dir, '/' ), $filename );
        $contents = @file_get_contents( $tmp );
        if ( $contents === false ) {
            @unlink( $tmp );
            return null;
        }

        file_put_contents( $target_path, $contents );
        @unlink( $tmp );

        return rtrim( $base_url, '/' ) . $subdir . '/' . $filename;
    }

    /**
     * Returns a filename for a slug + video combination.
     *
     * @param string $slug
     * @param string $video_url
     * @return string|null
     */
    private function resolve_filename( string $slug, string $video_url ): ?string {
        if ( isset( $this->filename_resolvers[ $slug ] ) ) {
            $resolver = $this->filename_resolvers[ $slug ];
            return call_user_func( $resolver, $video_url );
        }
        $path = wp_parse_url( $video_url, PHP_URL_PATH );
        if ( ! is_string( $path ) || $path === '' ) {
            return null;
        }

        $name = basename( $path );
        if ( ! $name ) {
            return null;
        }
        return sanitize_file_name( $name );
    }
}
