<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Provides read access to post video metadata.
 */
final class Fifu_Post_Video_Read_Service
{
    /**
     * Returns the main video URL for a post, using db2 first and falling back to postmeta.
     *
     * @param int $postId
     * @return string|null
     */
    public static function get_video_url(int $postId): ?string
    {
        $db2Url = self::get_db2_video_url($postId);
        if ($db2Url !== null) {
            return $db2Url;
        }

        $legacyUrl = get_post_meta($postId, 'fifu_video_url', true);
        if ($legacyUrl === '' || $legacyUrl === null) {
            return null;
        }

        return (string) $legacyUrl;
    }

    private static function get_db2_video_url(int $postId): ?string
    {
        if (!function_exists('fifu_db2_manager')) {
            return null;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return null;
        }

        $mapping = $manager->getPostMapping($postId, 'video', 0);
        if (!is_array($mapping)) {
            return null;
        }

        $url = trim((string) ($mapping['url'] ?? ''));
        return $url !== '' ? $url : null;
    }
}
