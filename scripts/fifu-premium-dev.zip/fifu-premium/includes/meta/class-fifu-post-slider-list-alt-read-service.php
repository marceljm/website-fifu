<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Read service for slider ALT lists stored in db2.
 */
final class Fifu_Post_Slider_List_Alt_Read_Service
{
    /**
     * Returns the slider ALT list for a post, preferring db2 data with a legacy fallback.
     *
     * @param int $postId
     * @return string|null
     */
    public static function get_slider_list_alt(int $postId): ?string
    {
        if (function_exists('fifu_db2_manager')) {
            $manager = fifu_db2_manager();
            if ($manager instanceof Fifu_Db2_Manager) {
                $mappings = $manager->getPostAltMappings($postId, 'slider');
                if ($mappings) {
                    $db2AltsByIndex = self::normalize_db2_slider_alt_mappings($mappings);
                    if ($db2AltsByIndex !== []) {
                        return implode('|', array_values($db2AltsByIndex));
                    }
                }
            }
        }

        $legacy = self::reconstruct_indexed_legacy_slider_list_alt($postId);
        if ($legacy !== null) {
            return $legacy;
        }

        return self::normalize_legacy_pipe_list(get_post_meta($postId, 'fifu_slider_list_alt', true));
    }

    private static function reconstruct_indexed_legacy_slider_list_alt(int $postId): ?string
    {
        $meta = self::get_all_post_meta($postId);
        if ($meta === []) {
            return null;
        }

        $indexed = [];
        foreach ($meta as $metaKey => $value) {
            if (!is_string($metaKey) || preg_match('/^fifu_slider_image_alt_(\d+)$/', $metaKey, $matches) !== 1) {
                continue;
            }

            $alt = self::normalize_legacy_alt_value($value);
            if ($alt === null) {
                continue;
            }

            $indexed[(int) $matches[1]] = $alt;
        }

        if (!$indexed) {
            return null;
        }

        ksort($indexed, SORT_NUMERIC);
        return implode('|', array_values($indexed));
    }

    /**
     * @param array<int, array<string, mixed>> $mappings
     * @return array<int, string>
     */
    private static function normalize_db2_slider_alt_mappings(array $mappings): array
    {
        $byIndex = [];
        foreach ($mappings as $mapping) {
            if (!is_array($mapping)) {
                continue;
            }

            $index = (int) ($mapping['key_index'] ?? -1);
            if ($index < 0) {
                continue;
            }

            $alt = self::normalize_legacy_alt_value($mapping['alt'] ?? ($mapping['value'] ?? null));
            if ($alt === null) {
                continue;
            }

            $byIndex[$index] = $alt;
        }

        ksort($byIndex, SORT_NUMERIC);
        return $byIndex;
    }

    /**
     * @return array<string, mixed>
     */
    private static function get_all_post_meta(int $postId): array
    {
        $meta = get_post_meta($postId);
        if (!is_array($meta) || $meta === []) {
            return [];
        }

        $normalized = [];
        foreach ($meta as $metaKey => $metaValue) {
            if (!is_string($metaKey)) {
                continue;
            }

            if (is_array($metaValue)) {
                $metaValue = reset($metaValue);
            }

            $normalized[$metaKey] = $metaValue;
        }

        return $normalized;
    }

    private static function normalize_legacy_pipe_list($value): ?string
    {
        if (!is_scalar($value) && $value !== null) {
            return null;
        }

        $legacy = rtrim(trim((string) $value), '|');
        if ($legacy === '' || preg_match('/^(null|undefined)$/i', $legacy) === 1) {
            return null;
        }

        return $legacy === '' ? null : $legacy;
    }

    private static function normalize_legacy_alt_value($value): ?string
    {
        if (!is_scalar($value) && $value !== null) {
            return null;
        }

        $value = trim((string) $value);
        if ($value === '' || preg_match('/^(null|undefined)$/i', $value) === 1) {
            return null;
        }

        return $value;
    }

}
