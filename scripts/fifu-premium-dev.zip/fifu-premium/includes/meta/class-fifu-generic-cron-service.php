<?php declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/class-fifu-cron-job-service.php';

/**
 * Routes generic FIFU cron jobs identified by specific IDs.
 */
final class Fifu_Generic_Cron_Service
{
    private const METADATA_POST_REMOTE_BATCH_SIZE = 1000;
    private const METADATA_POST_DRAIN_MAX_ITERATIONS = 5;
    private const IMPORT_LOCAL_BATCH_SIZE = 50;
    private const REGISTRATION_EMPTY = 'empty';
    private const REGISTRATION_SUCCESS = 'success';
    private const REGISTRATION_FAILED = 'failed';
    private const LOCAL_IMPORT_HOOKS = [
        'importpost' => 'fifu_local_importpost_worker',
        'importterm' => 'fifu_local_importterm_worker',
    ];

    /**
     * Registers durable local import worker hooks.
     */
    public static function register_hooks(): void
    {
        add_action(
            self::LOCAL_IMPORT_HOOKS['importpost'],
            [self::class, 'run_local_importpost_worker']
        );
        add_action(
            self::LOCAL_IMPORT_HOOKS['importterm'],
            [self::class, 'run_local_importterm_worker']
        );
    }

    /**
     * Runs the scheduled local post import worker.
     */
    public static function run_local_importpost_worker(): void
    {
        self::run('importpost');
    }

    /**
     * Runs the scheduled local term import worker.
     */
    public static function run_local_importterm_worker(): void
    {
        self::run('importterm');
    }

    /**
     * Ensures that a durable local import worker event exists.
     */
    public static function schedule_local_import(string $service): bool
    {
        $hook = self::LOCAL_IMPORT_HOOKS[$service] ?? null;
        if ($hook === null) {
            return false;
        }

        if (wp_next_scheduled($hook) !== false) {
            return true;
        }

        $scheduled = wp_schedule_single_event(time(), $hook);

        if (is_wp_error($scheduled) || $scheduled === false) {
            return false;
        }

        return wp_next_scheduled($hook) !== false;
    }

    /**
     * Clears pending durable local import worker events.
     */
    public static function clear_local_import_schedule(string $service): void
    {
        $hook = self::LOCAL_IMPORT_HOOKS[$service] ?? null;
        if ($hook === null) {
            return;
        }

        wp_clear_scheduled_hook($hook);
    }

    /**
     * Runs a generic FIFU cron job identified by an ID.
     *
     * Supported IDs include:
     * - auto_set
     * - metadatapost
     * - metadataterm
     * - importpost
     * - importterm
     * - asin
     * - finder
     * - uploadpost
     * - uploadterm
     * - metain
     * - metaout
     * - content
     *
     * This method will:
     * - Query metadata gap repositories.
     * - Call remote update APIs.
     * - Insert "sent" markers into postmeta/termmeta.
     * - Manage retry counters and cleanup routines.
     *
     * @param string $id
     * @return void
     */
    public static function run(string $id): void
    {
        $id = trim($id);
        if (!self::is_supported_id($id)) {
            return;
        }

        if (!in_array($id, ['metain', 'metaout'], true)) {
            Fifu_Main_Domain_Sync_Service::ensure_current(false);
        }

        $isLocalImport = isset(
            self::LOCAL_IMPORT_HOOKS[$id]
        );

        if (
            Fifu_Cron_Job_Service::is_active(
                "fifu_{$id}_semaphore",
                5
            )
        ) {
            if (
                $isLocalImport
                && self::has_pending_local_import_work($id)
            ) {
                self::schedule_local_import($id);
            }

            return;
        }

        Fifu_Transient_Manager::set(
            "fifu_{$id}_semaphore",
            new DateTime(),
            0
        );

        try {
            if ($id === 'metadatapost') {
                self::run_metadatapost_drain_loop($id);
            } elseif ($id === 'metain') {
                self::run_local_metain_registration();
            } elseif ($id === 'metaout') {
                self::run_local_metaout_registration();
            } else {
                self::run_single_registration($id);
            }
        } finally {
            Fifu_Transient_Manager::delete(
                "fifu_{$id}_semaphore"
            );

            if ($isLocalImport) {
                self::finalize_local_import_run($id);
            }
        }
    }

    /**
     * Returns whether a local import queue still has pending work.
     */
    private static function has_pending_local_import_work(
        string $service
    ): bool {
        $queueRepository =
            new Fifu_Metadata_Queue_Repository();

        if ($service === 'importpost') {
            return $queueRepository
                ->get_all_posts_to_import() !== [];
        }

        if ($service === 'importterm') {
            return $queueRepository
                ->get_all_terms_to_import() !== [];
        }

        return false;
    }

    /**
     * Finalizes one local import worker lifecycle after releasing its semaphore.
     */
    private static function finalize_local_import_run(
        string $service
    ): void {
        if (
            self::has_pending_local_import_work(
                $service
            )
        ) {
            self::schedule_local_import($service);
            return;
        }

        self::clear_local_import_schedule($service);

        if ($service === 'importpost') {
            Fifu_Transient_Manager::delete(
                'fifu_import_running'
            );
        }
    }

    private static function run_local_metain_registration(): string
    {
        $queueRepository = new Fifu_Metadata_Queue_Repository();
        $result = $queueRepository->get_meta_in();

        if ($result === []) {
            Fifu_Metadata_Import_Service::prepare_meta_in_queue('', false);
            $result = $queueRepository->get_meta_in();
        }

        $firstEntry = $result[0] ?? null;
        $queueRowId = is_object($firstEntry)
            ? (int) ($firstEntry->post_id ?? 0)
            : 0;

        if ($queueRowId <= 0) {
            return self::REGISTRATION_EMPTY;
        }

        $token = self::generate_local_worker_token();
        $expiration = defined('MINUTE_IN_SECONDS') ? MINUTE_IN_SECONDS : 60;

        if (
            $token === ''
            || !Fifu_Transient_Manager::set(
                'fifu_api_metain_auth_token',
                $token,
                $expiration
            )
        ) {
            Fifu_File_Logger::plugin([
                'fifu-create-generic-hook' => [
                    'SERVICE' => 'metain',
                    'STATUS' => 'token_error',
                ],
            ]);

            return self::REGISTRATION_FAILED;
        }

        $response = wp_remote_post(
            get_rest_url() . 'fifu-premium/v2/metain/',
            [
                'method' => 'POST',
                'body' => wp_json_encode(['post_id' => $queueRowId]),
                'headers' => [
                    'Content-Type' => 'application/json',
                    'X-FIFU-Authorization' => $token,
                ],
                'blocking' => true,
                'timeout' => 30,
            ]
        );

        if (is_wp_error($response)) {
            Fifu_File_Logger::plugin([
                'fifu-create-generic-hook' => [
                    'SERVICE' => 'metain',
                    'STATUS' => $response->get_error_message(),
                ],
            ]);

            return self::REGISTRATION_FAILED;
        }

        $responseCode = wp_remote_retrieve_response_code($response);
        if ($responseCode !== 200) {
            Fifu_File_Logger::plugin([
                'fifu-create-generic-hook' => [
                    'SERVICE' => 'metain',
                    'STATUS' => $responseCode,
                ],
            ]);

            return self::REGISTRATION_FAILED;
        }

        Fifu_File_Logger::plugin([
            'fifu-create-generic-hook' => [
                'SERVICE' => 'metain',
                'STATUS' => $responseCode,
                'IDS' => 1,
            ],
        ]);

        return self::REGISTRATION_SUCCESS;
    }

    private static function run_local_metaout_registration(): string
    {
        $queueRepository = new Fifu_Metadata_Queue_Repository();
        $result = $queueRepository->get_meta_out();

        if ($result === []) {
            Fifu_Metadata_Import_Service::prepare_meta_out_queue('', false);
            $result = $queueRepository->get_meta_out();
        }

        $firstEntry = $result[0] ?? null;
        $queueRowId = is_object($firstEntry)
            ? (int) ($firstEntry->post_id ?? 0)
            : 0;

        if ($queueRowId <= 0) {
            return self::REGISTRATION_EMPTY;
        }

        $token = self::generate_local_worker_token();
        $expiration = defined('MINUTE_IN_SECONDS') ? MINUTE_IN_SECONDS : 60;

        if (
            $token === ''
            || !Fifu_Transient_Manager::set(
                'fifu_api_metaout_auth_token',
                $token,
                $expiration
            )
        ) {
            Fifu_File_Logger::plugin([
                'fifu-create-generic-hook' => [
                    'SERVICE' => 'metaout',
                    'STATUS' => 'token_error',
                ],
            ]);

            return self::REGISTRATION_FAILED;
        }

        $response = wp_remote_post(
            get_rest_url() . 'fifu-premium/v2/metaout/',
            [
                'method' => 'POST',
                'body' => wp_json_encode(['post_id' => $queueRowId]),
                'headers' => [
                    'Content-Type' => 'application/json',
                    'X-FIFU-Authorization' => $token,
                ],
                'blocking' => true,
                'timeout' => 30,
            ]
        );

        if (is_wp_error($response)) {
            Fifu_File_Logger::plugin([
                'fifu-create-generic-hook' => [
                    'SERVICE' => 'metaout',
                    'STATUS' => $response->get_error_message(),
                ],
            ]);

            return self::REGISTRATION_FAILED;
        }

        $responseCode = wp_remote_retrieve_response_code($response);
        if ($responseCode !== 200) {
            Fifu_File_Logger::plugin([
                'fifu-create-generic-hook' => [
                    'SERVICE' => 'metaout',
                    'STATUS' => $responseCode,
                ],
            ]);

            return self::REGISTRATION_FAILED;
        }

        Fifu_File_Logger::plugin([
            'fifu-create-generic-hook' => [
                'SERVICE' => 'metaout',
                'STATUS' => $responseCode,
                'IDS' => 1,
            ],
        ]);

        return self::REGISTRATION_SUCCESS;
    }

    private static function generate_local_worker_token(): string
    {
        if (function_exists('wp_generate_password')) {
            $token = wp_generate_password(8, false);
            if (is_string($token) && $token !== '') {
                return $token;
            }
        }

        try {
            return bin2hex(random_bytes(4));
        } catch (Throwable $throwable) {
            return substr(hash('sha256', uniqid('fifu-local-worker-', true)), 0, 8);
        }
    }

    private static function run_metadatapost_drain_loop(string $service): void
    {
        for ($iteration = 0; $iteration < self::METADATA_POST_DRAIN_MAX_ITERATIONS; $iteration++) {
            $result = self::run_single_registration($service);
            if ($result === self::REGISTRATION_EMPTY || $result === self::REGISTRATION_FAILED) {
                break;
            }
        }
    }

    private static function run_single_registration(string $id): string
    {
        $gapRepository = new Fifu_Meta_Gap_Repository();
        $queueRepository = new Fifu_Metadata_Queue_Repository();
        $service = '';
        $isTerm = false;
        $extraField = false;
        $result = [];

        switch ($id) {
        case 'auto_set':
            $postTypesArray = array_map('trim', explode(',', get_option("fifu_{$id}_cpt")));
            $postTypes = join("','", $postTypesArray);
            $types = Fifu_Db2_Sql_Helper::get_types_for_in_clause();
            $safeTypes = Fifu_Db2_Sql_Helper::sanitize_post_types_list($postTypes, $types);
            $result = $gapRepository->get_posts_without_featured_image($safeTypes);
            $service = 'title';
            $isTerm = false;
            $extraField = true;
            break;
        case 'metadatapost':
            $result = $gapRepository->get_all_posts_without_meta();
            $service = $id;
            $isTerm = false;
            $extraField = true;
            break;
        case 'metadataterm':
            if (Fifu_Options_Utils::is_on('fifu_auto_category')) {
                Fifu_Auto_Category_Image_Service::run();
            }
            $result = $gapRepository->get_categories_without_meta();
            $service = $id;
            $isTerm = true;
            $extraField = true;
            break;
        case 'importpost':
            $result = (new Fifu_Metadata_Queue_Repository())->get_all_posts_to_import();
            $service = $id;
            $isTerm = false;
            $extraField = true;
            break;
        case 'importterm':
            $result = (new Fifu_Metadata_Queue_Repository())->get_all_terms_to_import();
            $service = $id;
            $isTerm = true;
            $extraField = true;
            break;
        case 'asin':
            if (
                !get_option('fifu_asin_credentials_partner') ||
                !get_option('fifu_asin_credentials_access') ||
                !get_option('fifu_asin_credentials_secret') ||
                !get_option('fifu_asin_credentials_locale')
            ) {
                $result = [];
            } else {
                $result = $gapRepository->get_asins_without_featured_image();
            }
            $service = $id;
            $isTerm = false;
            $extraField = true;
            break;
        case 'finder':
            $result = $gapRepository->get_finders_without_featured_image();
            $service = $id;
            $isTerm = false;
            $extraField = true;
            break;
        case 'uploadpost':
            $result = (new Fifu_Upload_Queue_Repository())->get_posts_with_url_to_upload();
            $service = $id;
            $isTerm = false;
            $extraField = true;
            break;
        case 'uploadterm':
            $result = (new Fifu_Upload_Queue_Repository())->get_terms_with_url_to_upload();
            $service = $id;
            $isTerm = true;
            $extraField = true;
            break;
        case 'metain':
            $result = $queueRepository->get_meta_in();
            if (count($result) === 0) {
                Fifu_Metadata_Import_Service::prepare_meta_in_queue('', false);
                $result = $queueRepository->get_meta_in();
            }
            $service = $id;
            $extraField = false;
            break;
        case 'metaout':
            $result = $queueRepository->get_meta_out();
            if (count($result) === 0) {
                Fifu_Metadata_Import_Service::prepare_meta_out_queue('', false);
                $result = $queueRepository->get_meta_out();
            }
            $service = $id;
            $extraField = false;
            break;
        case 'content':
            $result = $queueRepository->get_content();
            if (count($result) === 0) {
                Fifu_Meta_Maintenance_Controller::prepare_content_queue();
                $result = $queueRepository->get_content();
            }
            $service = $id;
            $extraField = false;
            break;
        default:
            return self::REGISTRATION_EMPTY;
        }

        $metaKey = "fifu_{$id}_sent";
        $postIds = [];
        foreach ($result as $entry) {
            $postIds[] = $entry->post_id ?? null;
        }

        if (empty($postIds)) {
            if ($service === 'importpost' || $service === 'importterm') {
                $attempts = get_option("fifu_counter_{$service}");
                $attempts = $attempts ? $attempts + 1 : 1;
                if ($attempts >= 10) {
                    delete_option("fifu_counter_{$service}");
                    $request = new WP_REST_Request();
                    $request->set_param('toggle', "fifu_toggle_{$service}");
                    Fifu_Rest_Cron_Controller::cron_delete($request);
                } else {
                    update_option("fifu_counter_{$service}", $attempts, 'no');
                }

                if (class_exists('Fifu_Plugin_Detector') && Fifu_Plugin_Detector::is_wp_all_import_active()) {
                    Fifu_Metadata_Import_Service::delete_garbage_wai();
                }
            }

            return self::REGISTRATION_EMPTY;
        }

        $normalizedPostIds = self::normalize_post_ids($postIds);
        if ($service === 'importpost' || $service === 'importterm') {
            return self::run_local_import_registration($service, $normalizedPostIds, $isTerm);
        }

        $payload = [
            'route' => get_rest_url(),
            'post_ids' => $postIds,
        ];

        if ($service === 'metadatapost') {
            self::create_metadatapost_sent_markers($normalizedPostIds);
            $payload['batch_size'] = self::METADATA_POST_REMOTE_BATCH_SIZE;
        }

        $response = wp_remote_post(
            "https://plugin.featuredimagefromurl.com/api/update/{$service}/",
            [
                'method' => 'POST',
                'body' => json_encode($payload),
                'headers' => [
                    'Content-Type' => 'application/json',
                    'Authorization' => get_option('fifu_ws_key_ddg'),
                ],
                'timeout' => 60,
            ]
        );

        if (is_wp_error($response)) {
            $errorMessage = $response->get_error_message();
            Fifu_File_Logger::plugin([
                'fifu-create-generic-hook' => [
                    'SERVICE' => $service,
                    'STATUS' => $errorMessage,
                ],
            ]);
            if ($service === 'metadatapost') {
                self::rollback_metadatapost_sent_markers($normalizedPostIds);
            }
            return self::REGISTRATION_FAILED;
        }

        $responseCode = wp_remote_retrieve_response_code($response);
        if ($responseCode !== 200) {
            Fifu_File_Logger::plugin([
                'fifu-create-generic-hook' => [
                    'SERVICE' => $service,
                    'STATUS' => $responseCode,
                ],
            ]);

            if ($service === 'metadatapost') {
                self::rollback_metadatapost_sent_markers($normalizedPostIds);
            }
            return self::REGISTRATION_FAILED;
        }

        Fifu_File_Logger::plugin([
            'fifu-create-generic-hook' => [
                'SERVICE' => $service,
                'STATUS' => $responseCode,
                'IDS' => count($postIds),
            ],
        ]);
        if ($service === 'importpost' || $service === 'importterm') {
            update_option("fifu_counter_{$service}", 0, 'no');
        }
        if ($extraField && $service !== 'metadatapost') {
            $sentService = function_exists('fifu_db2_sent_service') ? fifu_db2_sent_service() : null;
            $objectType = $isTerm ? 'term' : 'post';
            foreach ($postIds as $postId) {
                if ($postId === null) {
                    continue;
                }

                $postId = (int) $postId;
                if ($postId <= 0) {
                    continue;
                }

                $bridgeHandled = false;
                if (class_exists('Fifu_Sent_Bridge')) {
                    if ($isTerm) {
                        $bridgeHandled = (bool) Fifu_Sent_Bridge::set_term_sent_attempts($postId, $id, 0, null);
                    } else {
                        $bridgeHandled = (bool) Fifu_Sent_Bridge::set_post_sent_attempts($postId, $id, 0, null);
                    }
                }

                $isDb2OnlyEvent = self::is_db2_only_event_key($id);

                if (!$bridgeHandled && !$isDb2OnlyEvent) {
                    if ($isTerm) {
                        update_term_meta($postId, $metaKey, 0);
                    } else {
                        update_post_meta($postId, $metaKey, 0);
                    }
                } elseif ($isDb2OnlyEvent) {
                    if ($isTerm) {
                        delete_term_meta($postId, $metaKey);
                    } else {
                        delete_post_meta($postId, $metaKey);
                    }
                }

                if ($sentService instanceof Fifu_Db2_Sent_Service) {
                    $sentService->set_attempts($objectType, $postId, $id, 0);
                }
            }
        }

        return self::REGISTRATION_SUCCESS;
    }

    /**
     * Dispatches a bounded import batch to the local import worker.
     *
     * @param string $service
     * @param array<int, int> $postIds
     * @param bool $isTerm
     */
    private static function run_local_import_registration(string $service, array $postIds, bool $isTerm): string
    {
        $batchIds = array_slice(array_values(array_unique($postIds)), 0, self::IMPORT_LOCAL_BATCH_SIZE);
        if ($batchIds === []) {
            return self::REGISTRATION_EMPTY;
        }

        $eventKey = $isTerm ? 'importterm' : 'importpost';
        foreach ($batchIds as $objectId) {
            if ($isTerm) {
                Fifu_Sent_Bridge::set_term_sent_attempts($objectId, $eventKey, 0, null);
            } else {
                Fifu_Sent_Bridge::set_post_sent_attempts($objectId, $eventKey, 0, null);
            }
        }

        $tokenKey = $isTerm
            ? 'fifu_api_importterm_auth_token'
            : 'fifu_api_importpost_auth_token';
        $token = self::generate_local_worker_token();
        if (
            $token === ''
            || !Fifu_Transient_Manager::set($tokenKey, $token, 60)
        ) {
            self::rollback_local_import_sent_state($batchIds, $eventKey, $isTerm);
            return self::REGISTRATION_FAILED;
        }

        $route = $isTerm ? 'import-term' : 'import-post';
        $response = wp_remote_post(
            get_rest_url() . "fifu-premium/v2/{$route}/",
            [
                'method' => 'POST',
                'body' => wp_json_encode([
                    'post_ids' => $batchIds,
                ]),
                'headers' => [
                    'Content-Type' => 'application/json',
                    'X-FIFU-Authorization' => $token,
                ],
                'blocking' => true,
                'timeout' => 60,
            ]
        );

        if (is_wp_error($response)) {
            Fifu_Transient_Manager::delete($tokenKey);
            self::rollback_local_import_sent_state($batchIds, $eventKey, $isTerm);
            Fifu_File_Logger::plugin([
                'fifu-create-generic-hook' => [
                    'SERVICE' => $service,
                    'STATUS' => $response->get_error_message(),
                ],
            ]);
            return self::REGISTRATION_FAILED;
        }

        $responseCode = wp_remote_retrieve_response_code($response);
        if ($responseCode !== 200) {
            Fifu_Transient_Manager::delete($tokenKey);
            self::rollback_local_import_sent_state($batchIds, $eventKey, $isTerm);
            Fifu_File_Logger::plugin([
                'fifu-create-generic-hook' => [
                    'SERVICE' => $service,
                    'STATUS' => $responseCode,
                ],
            ]);
            return self::REGISTRATION_FAILED;
        }

        update_option("fifu_counter_{$service}", 0, 'no');
        Fifu_File_Logger::plugin([
            'fifu-create-generic-hook' => [
                'SERVICE' => $service,
                'STATUS' => $responseCode,
                'IDS' => count($batchIds),
            ],
        ]);

        return self::REGISTRATION_SUCCESS;
    }

    /**
     * @param array<int, int> $objectIds
     */
    private static function rollback_local_import_sent_state(array $objectIds, string $eventKey, bool $isTerm): void
    {
        foreach ($objectIds as $objectId) {
            if ($isTerm) {
                Fifu_Sent_Bridge::delete_term_sent_status($objectId, $eventKey);
            } else {
                Fifu_Sent_Bridge::delete_post_sent_status($objectId, $eventKey);
            }
        }
    }

    private static function is_supported_id(string $id): bool
    {
        return in_array($id, [
            'auto_set',
            'metadatapost',
            'metadataterm',
            'importpost',
            'importterm',
            'asin',
            'finder',
            'uploadpost',
            'uploadterm',
            'metain',
            'metaout',
            'content',
        ], true);
    }

    /**
     * Returns true when the event must never recreate legacy postmeta/termmeta.
     */
    private static function is_db2_only_event_key(string $id): bool
    {
        return in_array($id, [
            'importpost',
            'importterm',
            'metadatapost',
            'uploadpost',
            'uploadterm',
        ], true);
    }

    /**
     * Normalizes post IDs to positive integers for sent-marker writes.
     *
     * @param array<int, mixed> $postIds
     * @return array<int, int>
     */
    private static function normalize_post_ids(array $postIds): array
    {
        $normalized = [];
        foreach ($postIds as $postId) {
            $postId = (int) $postId;
            if ($postId <= 0) {
                continue;
            }

            $normalized[] = $postId;
        }

        return $normalized;
    }

    /**
     * Creates local metadatapost sent markers before the remote registration call.
     *
     * @param array<int, int> $postIds
     * @return void
     */
    private static function create_metadatapost_sent_markers(array $postIds): void
    {
        $postIds = self::normalize_post_ids($postIds);

        if (empty($postIds)) {
            return;
        }

        $sentService = function_exists('fifu_db2_sent_service') ? fifu_db2_sent_service() : null;

        if ($sentService instanceof Fifu_Db2_Sent_Service && method_exists($sentService, 'bulk_set_attempts')) {
            $sentService->bulk_set_attempts('post', $postIds, 'metadatapost', 0, null);
            return;
        }

        if (!class_exists('Fifu_Sent_Bridge')) {
            return;
        }

        foreach ($postIds as $postId) {
            Fifu_Sent_Bridge::set_post_sent_attempts((int) $postId, 'metadatapost', 0, null);
        }
    }

    /**
     * Rolls back local metadatapost sent markers when remote registration fails.
     *
     * @param array<int, int> $postIds
     * @return void
     */
    private static function rollback_metadatapost_sent_markers(array $postIds): void
    {
        $postIds = self::normalize_post_ids($postIds);

        if (empty($postIds)) {
            return;
        }

        $sentService = function_exists('fifu_db2_sent_service') ? fifu_db2_sent_service() : null;

        if ($sentService instanceof Fifu_Db2_Sent_Service && method_exists($sentService, 'bulk_delete_status')) {
            $sentService->bulk_delete_status('post', $postIds, 'metadatapost');
            return;
        }

        if (!class_exists('Fifu_Sent_Bridge')) {
            return;
        }

        foreach ($postIds as $postId) {
            Fifu_Sent_Bridge::delete_post_sent((int) $postId, 'metadatapost');
        }
    }
}
