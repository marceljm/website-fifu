<?php

declare(strict_types=1);

defined('ABSPATH') || exit;

/**
 * Repository for retrieving FIFU attachment references.
 */
class Fifu_Attachment_Repository {

    /** @var wpdb */
    private wpdb $wpdb;

    /** @var string */
    private string $posts_table;

    /** @var string */
    private string $postmeta_table;

    /** @var string */
    private string $termmeta_table;

    public function __construct(?wpdb $wpdb_instance = null) {
        $this->wpdb = $wpdb_instance ?? $GLOBALS['wpdb'];
        $this->posts_table = $this->wpdb->posts;
        $this->postmeta_table = $this->wpdb->postmeta;
        $this->termmeta_table = $this->wpdb->termmeta;
    }

    private function getAuthorId(): int {
        return (int) Fifu_Options_Utils::get_author();
    }

    /**
     * Find an attachment ID by parent post, file path and category flag.
     *
     * @param int    $post_parent
     * @param string $file
     * @param bool   $is_category
     * @return int|null
     */
    public function find_attachment_id(
        int $post_parent,
        string $file,
        bool $is_category,
        int $exclude_attachment_id = 0,
        int $exclude_shared_term_references_for_term_id = 0
    ): ?int {
        $ctgr_sql = $is_category ? "AND p.post_name LIKE 'fifu-category%'" : '';
        $exclude_sql = $exclude_attachment_id > 0 ? 'AND p.ID <> %d' : '';
        $shared_term_sql = $exclude_shared_term_references_for_term_id > 0
            ? "AND NOT EXISTS (
                  SELECT 1
                  FROM {$this->termmeta_table} tm
                  WHERE tm.meta_key IN ('thumbnail_id', 'product_attribute_image')
                    AND tm.meta_value = CAST(p.ID AS CHAR)
                    AND tm.term_id <> %d
              )"
            : '';
        $order_sql = $exclude_shared_term_references_for_term_id > 0 ? 'ORDER BY pm.post_id ASC' : '';
        $args = [$file, $post_parent, $this->getAuthorId()];
        if ($exclude_attachment_id > 0) {
            $args[] = $exclude_attachment_id;
        }
        if ($exclude_shared_term_references_for_term_id > 0) {
            $args[] = $exclude_shared_term_references_for_term_id;
        }

        $sql = $this->wpdb->prepare(
            "SELECT pm.post_id
            FROM {$this->postmeta_table} pm
            WHERE pm.meta_key = '_wp_attached_file'
              AND pm.meta_value = %s
              AND pm.post_id IN (
                  SELECT p.id
                  FROM {$this->posts_table} p 
                  WHERE p.post_parent = %d
                    AND post_author = %d {$ctgr_sql}
                    {$exclude_sql}
                    {$shared_term_sql}
              )
            {$order_sql}
            LIMIT 1",
            $args
        );

        $row = $this->wpdb->get_row($sql);
        return $row ? (int) $row->post_id : null;
    }

    /** Find an incomplete FIFU attachment whose retained remote URL can be used for recovery. */
    public function find_incomplete_attachment_id(
        int $post_parent,
        string $url,
        bool $is_category,
        int $exclude_attachment_id = 0,
        int $exclude_shared_term_references_for_term_id = 0
    ): ?int
    {
        $ctgr_sql = $is_category ? "AND p.post_name LIKE 'fifu-category%'" : "AND p.post_name NOT LIKE 'fifu-category%'";
        $exclude_sql = $exclude_attachment_id > 0 ? 'AND p.ID <> %d' : '';
        $shared_term_sql = $exclude_shared_term_references_for_term_id > 0
            ? "AND NOT EXISTS (
                   SELECT 1
                   FROM {$this->termmeta_table} tm
                   WHERE tm.meta_key IN ('thumbnail_id', 'product_attribute_image')
                     AND tm.meta_value = CAST(p.ID AS CHAR)
                     AND tm.term_id <> %d
               )"
            : '';
        $args = [
            $post_parent,
            $this->getAuthorId(),
        ];
        if ($exclude_attachment_id > 0) {
            $args[] = $exclude_attachment_id;
        }
        $args[] = trim(htmlspecialchars_decode($url));
        if ($exclude_shared_term_references_for_term_id > 0) {
            $args[] = $exclude_shared_term_references_for_term_id;
        }

        $sql = $this->wpdb->prepare(
            "SELECT p.ID
             FROM {$this->posts_table} p
             WHERE p.post_parent = %d
               AND p.post_author = %d
               AND p.post_type = 'attachment'
               {$ctgr_sql}
               {$exclude_sql}
               AND p.post_content_filtered = %s
               {$shared_term_sql}
               AND NOT EXISTS (
                   SELECT 1
                   FROM {$this->postmeta_table} pm
                   WHERE pm.post_id = p.ID
                     AND pm.meta_key = '_wp_attached_file'
                     AND TRIM(pm.meta_value) <> ''
               )
             ORDER BY p.ID ASC
             LIMIT 1",
            $args
        );

        $attachment_id = $this->wpdb->get_var($sql);
        return $attachment_id ? (int) $attachment_id : null;
    }

    /**
     * Check whether the given attachment ID was created by FIFU.
     *
     * @param int $attachment_id
     * @return bool
     */
    public function is_fifu_attachment(int $attachment_id): bool {
        if ($attachment_id <= 0) {
            return false;
        }

        if (
            function_exists('fifu_is_fifu_attachment_author')
        ) {
            $attachment = get_post($attachment_id);

            return $attachment
                && $attachment->post_type === 'attachment'
                && fifu_is_fifu_attachment_author(
                    $attachment->post_author
                );
        }

        $sql = $this->wpdb->prepare(
            "SELECT 1
             FROM {$this->posts_table}
             WHERE id = %d
               AND post_type = 'attachment'
               AND post_author = %d",
            $attachment_id,
            $this->getAuthorId()
        );
        return (bool) $this->wpdb->get_var($sql);
    }

    /**
     * Return attachment rows for the provided IDs, limited to FIFU-owned attachments.
     *
     * @param array<int,mixed> $attachment_ids
     * @return array<int,array<string,mixed>>
     */
    public function get_attachment_rows_by_ids(array $attachment_ids): array {
        $attachment_ids = array_values(array_unique(array_filter(
            array_map('intval', $attachment_ids),
            static fn(int $id): bool => $id > 0
        )));

        if (!$attachment_ids) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($attachment_ids), '%d'));
        $output_type = defined('ARRAY_A') ? ARRAY_A : 'ARRAY_A';
        $sql = $this->wpdb->prepare(
            "SELECT
                p.ID AS id,
                COALESCE(pm.meta_value, '') AS attached_file,
                COALESCE(pm_alt.meta_value, '') AS attachment_alt,
                p.post_title,
                p.post_excerpt,
                p.post_content_filtered
            FROM {$this->posts_table} p
            LEFT JOIN {$this->postmeta_table} pm
                ON pm.post_id = p.ID
               AND pm.meta_key = '_wp_attached_file'
            LEFT JOIN {$this->postmeta_table} pm_alt
                ON pm_alt.post_id = p.ID
               AND pm_alt.meta_key = '_wp_attachment_image_alt'
            WHERE p.ID IN ({$placeholders})
              AND p.post_type = 'attachment'
              AND p.post_author = %d",
            array_merge($attachment_ids, [$this->getAuthorId()])
        );

        $rows = $this->wpdb->get_results($sql, $output_type);
        return is_array($rows) ? $rows : [];
    }

    /**
     * Get the serialized gallery value stored for a product.
     *
     * @param int $post_id
     * @return string
     */
    public function get_product_image_gallery(int $post_id): string {
        return rtrim((string) get_post_meta($post_id, '_product_image_gallery', true), ',');
    }

    /**
     * Fetch the comma-separated list of featured and gallery IDs for a post.
     *
     * @param int $post_id
     * @return string|null
     */
    public function get_featured_and_gallery_ids(int $post_id): ?string {
        $rows = $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT meta_key, meta_value
             FROM {$this->postmeta_table}
             WHERE post_id = %d
               AND meta_key IN ('_thumbnail_id', '_product_image_gallery', '_wc_additional_variation_images')
             ORDER BY CASE meta_key
               WHEN '_thumbnail_id' THEN 0
               WHEN '_product_image_gallery' THEN 1
               ELSE 2
             END ASC, meta_id ASC",
            $post_id
        ));

        $ids = [];
        $seen = [];
        foreach ((array) $rows as $row) {
            $meta_key = (string) (is_object($row) ? ($row->meta_key ?? '') : ($row['meta_key'] ?? ''));
            $meta_value = trim((string) (is_object($row) ? ($row->meta_value ?? '') : ($row['meta_value'] ?? '')));
            if ($meta_value === '') {
                continue;
            }

            $values = $meta_key === '_thumbnail_id'
                ? [$meta_value]
                : preg_split('/[\\s,]+/', $meta_value, -1, PREG_SPLIT_NO_EMPTY);
            foreach ((array) $values as $value) {
                $value = trim((string) $value);
                if ($value === '' || !ctype_digit($value)) {
                    continue;
                }
                $id = (int) $value;
                if ($id > 0 && !isset($seen[$id])) {
                    $seen[$id] = true;
                    $ids[] = $id;
                }
            }
        }

        return $ids ? implode(',', $ids) : null;
    }

    /**
     * Fetch FIFU-owned child attachments that use ordinary post ownership.
     *
     * @param int $post_id
     * @return int[]
     */
    public function get_fifu_child_attachment_ids(int $post_id): array
    {
        if ($post_id <= 0) {
            return [];
        }

        $ids = $this->wpdb->get_col($this->wpdb->prepare(
            "SELECT ID
             FROM {$this->posts_table}
             WHERE post_type = %s
               AND post_parent = %d
               AND post_author = %d
               AND post_name NOT LIKE %s
             ORDER BY ID ASC",
            'attachment',
            $post_id,
            $this->getAuthorId(),
            'fifu-category-%'
        ));

        return array_values(array_unique(array_filter(
            array_map('intval', (array) $ids),
            static fn(int $attachment_id): bool => $attachment_id > 0
        )));
    }

    /**
     * Return the thumbnail ID for a parent post or category.
     *
     * @param int  $parent_id
     * @param bool $is_category
     * @return int|null
     */
    public function get_thumbnail_id(int $parent_id, bool $is_category): ?int {
        $category_condition = $is_category ? "AND post_name LIKE 'fifu-category%'" : '';
        $sql = $this->wpdb->prepare(
            "SELECT MIN(id) FROM {$this->posts_table}
            WHERE post_parent = %d
              AND post_type = 'attachment'
              {$category_condition}",
            $parent_id
        );
        $value = $this->wpdb->get_var($sql);
        return $value !== null ? (int) $value : null;
    }

    /**
     * Return the attachment CSV stored for a parent post or category gallery.
     *
     * @param int  $parent_id
     * @param bool $is_category
     * @return string|null
     */
    public function get_attachments_csv(int $parent_id, bool $is_category): ?string {
        $category_condition = $is_category ? "AND post_name LIKE 'fifu-category%'" : '';
        $sql = $this->wpdb->prepare(
            "SELECT GROUP_CONCAT(id ORDER BY id) FROM {$this->posts_table}
            WHERE post_parent = %d
              AND post_type = 'attachment'
              {$category_condition}",
            $parent_id
        );
        return $this->wpdb->get_var($sql) ?: null;
    }

    /**
     * Fetch the IDs of orphan attachments that are still linked to a post.
     *
     * @param int $post_id
     * @return string|null
     */
    public function get_orphan_attachments_for_post(int $post_id): ?string {
        $sql = $this->wpdb->prepare(
            "SELECT p.ID
            FROM {$this->posts_table} p
            WHERE p.post_parent = %d
              AND p.post_author = %d
              AND p.post_name NOT LIKE %s
              AND p.post_type = 'attachment'
              AND NOT EXISTS (
                  SELECT 1
                  FROM {$this->postmeta_table} pm2
                  WHERE pm2.post_id = p.post_parent
                    AND pm2.meta_key = '_thumbnail_id'
                    AND pm2.meta_value <> ''
                    AND CAST(pm2.meta_value AS UNSIGNED) = p.ID
              )
              AND NOT EXISTS (
                  SELECT 1
                  FROM {$this->postmeta_table} reference_meta
                  WHERE reference_meta.post_id = p.post_parent
                    AND (
                        TRIM(reference_meta.meta_value) = CAST(p.ID AS CHAR)
                        OR FIND_IN_SET(CAST(p.ID AS CHAR), REPLACE(reference_meta.meta_value, ' ', '')) > 0
                    )
              )
            ORDER BY p.ID ASC",
            $post_id,
            $this->getAuthorId(),
            'fifu-category%'
        );
        return $this->format_unreferenced_attachment_ids($this->wpdb->get_col($sql));
    }

    /**
     * Find recoverable incomplete attachments that are not active or referenced media.
     *
     * @param int[] $protected_ids Attachment IDs that must not be returned.
     */
    public function get_incomplete_orphan_attachments_for_post(int $post_id, array $protected_ids = []): ?string
    {
        $ids = array_values(array_unique(array_filter(
            array_map('intval', $protected_ids),
            static fn(int $id): bool => $id > 0
        )));
        $exclude_sql = $ids ? 'AND p.ID NOT IN (' . implode(',', $ids) . ')' : '';

        $sql = $this->wpdb->prepare(
            "SELECT p.ID
             FROM {$this->posts_table} p
             WHERE p.post_parent = %d
               AND p.post_author = %d
               AND p.post_name NOT LIKE %s
               AND p.post_type = 'attachment'
               AND (
                   TRIM(p.post_content_filtered) <> ''
                   OR TRIM(p.guid) = ''
               )
               {$exclude_sql}
               AND NOT EXISTS (
                   SELECT 1
                   FROM {$this->postmeta_table} file_meta
                   WHERE file_meta.post_id = p.ID
                     AND file_meta.meta_key = '_wp_attached_file'
                     AND TRIM(file_meta.meta_value) <> ''
               )
               AND NOT EXISTS (
                   SELECT 1
                   FROM {$this->postmeta_table} thumbnail_meta
                   WHERE thumbnail_meta.post_id = p.post_parent
                     AND thumbnail_meta.meta_key = '_thumbnail_id'
                     AND CAST(thumbnail_meta.meta_value AS UNSIGNED) = p.ID
               )
               AND NOT EXISTS (
                   SELECT 1
                   FROM {$this->postmeta_table} reference_meta
                   WHERE reference_meta.post_id = p.post_parent
                     AND (
                         TRIM(reference_meta.meta_value) = CAST(p.ID AS CHAR)
                         OR FIND_IN_SET(CAST(p.ID AS CHAR), REPLACE(reference_meta.meta_value, ' ', '')) > 0
                     )
               )
             ORDER BY p.ID ASC",
            $post_id,
            $this->getAuthorId(),
            'fifu-category%'
        );

        return $this->format_unreferenced_attachment_ids($this->wpdb->get_col($sql));
    }

    /** Return candidate IDs not referenced by supported metadata, using a batched cross-post check. */
    private function format_unreferenced_attachment_ids($candidate_ids): ?string
    {
        $ids = array_values(array_unique(array_filter(
            array_map('intval', (array) $candidate_ids),
            static fn(int $id): bool => $id > 0
        )));
        if (!$ids) {
            return null;
        }

        $referenced_ids = $this->get_referenced_attachment_ids($ids);
        $orphan_ids = array_values(array_diff($ids, $referenced_ids));

        return $orphan_ids ? implode(',', $orphan_ids) : null;
    }

    /**
     * Find candidate attachment IDs referenced by exact ID values, gallery lists,
     * or serialized arrays with an explicit attachment_id key.
     *
     * @param int[] $attachment_ids
     * @return int[]
     */
    public function get_referenced_attachment_ids(
        array $attachment_ids,
        int $exclude_post_id = 0,
        array $excluded_post_meta_keys = [],
        array $excluded_term_meta_keys = []
    ): array
    {
        $ids = array_values(array_unique(array_filter(
            array_map('intval', $attachment_ids),
            static fn(int $id): bool => $id > 0
        )));
        if (!$ids) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($ids), '%s'));
        $clauses = ["pm.meta_value IN ({$placeholders})", "pm.meta_value LIKE %s"];
        $args = array_map('strval', $ids);
        // The PHP parser validates explicit serialized keys without creating objects.
        $args[] = '%attachment_id%';

        foreach ($ids as $id) {
            $clauses[] = "(
                pm.meta_key IN ('_product_image_gallery', '_wc_additional_variation_images')
                AND FIND_IN_SET(%s, REPLACE(REPLACE(REPLACE(REPLACE(pm.meta_value, ' ', ''), CHAR(9), ''), CHAR(10), ''), CHAR(13), '')) > 0
            )";
            $args[] = (string) $id;

        }

        $post_scope_sql = $exclude_post_id > 0 ? ' AND pm.post_id <> %d' : '';
        if ($exclude_post_id > 0) {
            $args[] = $exclude_post_id;
        }
        $excluded_post_meta_keys = array_values(array_unique(array_filter(array_map('strval', $excluded_post_meta_keys))));
        $post_meta_exclusion_sql = '';
        if ($excluded_post_meta_keys) {
            $post_meta_exclusion_sql = ' AND pm.meta_key NOT IN (' . implode(',', array_fill(0, count($excluded_post_meta_keys), '%s')) . ')';
            array_push($args, ...$excluded_post_meta_keys);
        }
        $sql = "SELECT pm.meta_key, pm.meta_value
                FROM {$this->postmeta_table} pm
                WHERE (" . implode(' OR ', $clauses) . "){$post_scope_sql}{$post_meta_exclusion_sql}";
        $rows = $this->wpdb->get_results($this->wpdb->prepare($sql, $args));

        $referenced = [];
        foreach ((array) $rows as $row) {
            $meta_key = is_object($row) ? (string) ($row->meta_key ?? '') : (string) ($row['meta_key'] ?? '');
            $meta_value = is_object($row) ? (string) ($row->meta_value ?? '') : (string) ($row['meta_value'] ?? '');
            $serialized_references = $this->serialized_value_attachment_ids($meta_value, $ids);

            foreach ($ids as $id) {
                if (trim($meta_value) === (string) $id) {
                    $referenced[$id] = true;
                    continue;
                }

                if (
                    in_array($meta_key, ['_product_image_gallery', '_wc_additional_variation_images'], true)
                    && in_array((string) $id, preg_split('/\s*,\s*/', trim($meta_value), -1, PREG_SPLIT_NO_EMPTY), true)
                ) {
                    $referenced[$id] = true;
                    continue;
                }

                if (isset($serialized_references[$id])) {
                    $referenced[$id] = true;
                }
            }
        }

        // Term thumbnails and Variation Swatches images share attachment IDs
        // independently of post metadata. Check them in one batched query.
        $term_meta_keys = ['thumbnail_id', 'product_attribute_image'];
        $excluded_term_meta_keys = array_values(array_unique(array_filter(array_map('strval', $excluded_term_meta_keys))));
        $term_meta_keys = array_values(array_diff($term_meta_keys, $excluded_term_meta_keys));
        $term_rows = [];
        if ($term_meta_keys) {
            $term_key_placeholders = implode(',', array_fill(0, count($term_meta_keys), '%s'));
            $term_rows = $this->wpdb->get_results($this->wpdb->prepare(
                "SELECT tm.meta_key, tm.meta_value
                 FROM {$this->termmeta_table} tm
                 WHERE tm.meta_key IN ({$term_key_placeholders})
                   AND tm.meta_value IN ({$placeholders})",
                array_merge($term_meta_keys, array_map('strval', $ids))
            ));
        }
        $candidate_lookup = array_fill_keys($ids, true);
        foreach ((array) $term_rows as $row) {
            $value = trim((string) (is_object($row) ? ($row->meta_value ?? '') : ($row['meta_value'] ?? '')));
            if ($value !== '' && ctype_digit($value) && isset($candidate_lookup[(int) $value])) {
                $referenced[(int) $value] = true;
            }
        }

        return array_map('intval', array_keys($referenced));
    }

    /**
     * Return taxonomy terms that reference an attachment through supported media fields.
     *
     * @return int[]
     */
    public function get_attachment_reference_term_ids(int $attachment_id, int $exclude_term_id = 0): array
    {
        if ($attachment_id <= 0) {
            return [];
        }

        $sql = "SELECT DISTINCT tm.term_id
                FROM {$this->termmeta_table} tm
                WHERE tm.meta_key IN ('thumbnail_id', 'product_attribute_image')
                  AND tm.meta_value = %s";
        $args = [(string) $attachment_id];
        if ($exclude_term_id > 0) {
            $sql .= ' AND tm.term_id <> %d';
            $args[] = $exclude_term_id;
        }

        return array_values(array_unique(array_filter(
            array_map('intval', (array) $this->wpdb->get_col($this->wpdb->prepare($sql, $args))),
            static fn(int $term_id): bool => $term_id > 0
        )));
    }

    /**
     * Return surviving posts that use an attachment as media, ordered for ownership selection.
     *
     * Exact numeric values in arbitrary metadata remain covered by
     * get_referenced_attachment_ids(), but are not evidence that a post owns media.
     *
     * @return int[]
     */
    public function get_media_reference_post_ids(int $attachment_id, int $exclude_post_id = 0): array
    {
        if ($attachment_id <= 0) {
            return [];
        }

        $rows = $this->get_media_reference_rows($attachment_id, $exclude_post_id);
        $priorities = [];
        foreach ($rows as $row) {
            $meta_key = (string) ($row->meta_key ?? '');
            $meta_value = (string) ($row->meta_value ?? '');
            $post_id = (int) ($row->post_id ?? 0);
            if ($post_id <= 0) {
                continue;
            }

            $priority = null;
            if ($meta_key === '_thumbnail_id' && trim($meta_value) === (string) $attachment_id) {
                $priority = 0;
            } elseif (
                in_array($meta_key, ['_product_image_gallery', '_wc_additional_variation_images'], true)
                && in_array(
                    (string) $attachment_id,
                    preg_split('/\s*,\s*/', trim($meta_value), -1, PREG_SPLIT_NO_EMPTY),
                    true
                )
            ) {
                $priority = 1;
            } elseif (isset($this->serialized_value_attachment_ids($meta_value, [$attachment_id])[$attachment_id])) {
                $priority = 2;
            }

            if ($priority !== null && (!isset($priorities[$post_id]) || $priority < $priorities[$post_id])) {
                $priorities[$post_id] = $priority;
            }
        }

        uksort($priorities, static function (int $left, int $right) use ($priorities): int {
            $priority_order = $priorities[$left] <=> $priorities[$right];
            return $priority_order !== 0 ? $priority_order : ($left <=> $right);
        });

        return array_map('intval', array_keys($priorities));
    }

    /** @return array<int, object> */
    private function get_media_reference_rows(int $attachment_id, int $exclude_post_id = 0): array
    {
        $clauses = ['pm.meta_value = %s'];
        $args = [(string) $attachment_id];
        $clauses[] = "(
            pm.meta_key IN ('_product_image_gallery', '_wc_additional_variation_images')
            AND FIND_IN_SET(%s, REPLACE(REPLACE(REPLACE(REPLACE(pm.meta_value, ' ', ''), CHAR(9), ''), CHAR(10), ''), CHAR(13), '')) > 0
        )";
        $args[] = (string) $attachment_id;
        $clauses[] = 'pm.meta_value LIKE %s';
        $args[] = '%attachment_id%';

        $exclude_sql = '';
        if ($exclude_post_id > 0) {
            $exclude_sql = ' AND pm.post_id <> %d';
            $args[] = $exclude_post_id;
        }

        $sql = "SELECT pm.post_id, pm.meta_key, pm.meta_value
                FROM {$this->postmeta_table} pm
                WHERE (" . implode(' OR ', $clauses) . "){$exclude_sql}";

        return (array) $this->wpdb->get_results($this->wpdb->prepare($sql, $args));
    }

    /**
     * Decode each candidate metadata value once, without instantiating objects.
     *
     * @param int[] $candidate_ids
     * @return array<int, true>
     */
    private function serialized_value_attachment_ids(string $value, array $candidate_ids): array
    {
        if ($value === '' || strpos($value, 'attachment_id') === false) {
            return [];
        }

        $value = trim($value);
        if (function_exists('is_serialized') && !is_serialized($value)) {
            return [];
        }

        $decoded = @unserialize($value, [
            'allowed_classes' => false,
            'max_depth' => 128,
        ]);
        if (!is_array($decoded)) {
            return [];
        }

        $candidate_lookup = array_fill_keys($candidate_ids, true);
        $references = [];
        $this->collect_serialized_attachment_ids($decoded, $candidate_lookup, $references);

        return $references;
    }

    /**
     * @param array<int|string, mixed> $value
     * @param array<int, true> $candidate_lookup
     * @param array<int, true> $references
     */
    private function collect_serialized_attachment_ids(array $value, array $candidate_lookup, array &$references): void
    {
        foreach ($value as $key => $item) {
            if (
                $key === 'attachment_id'
                && (is_int($item) || (is_string($item) && ctype_digit($item)))
                && isset($candidate_lookup[(int) $item])
            ) {
                $references[(int) $item] = true;
            }

            if (is_array($item)) {
                $this->collect_serialized_attachment_ids($item, $candidate_lookup, $references);
            }
        }
    }

    /**
     * Fetch the IDs of orphan attachments that are still linked to a category term.
     *
     * @param int $term_id
     * @return string|null
     */
    public function get_orphan_attachments_for_term(int $term_id): ?string {
        $sql = $this->wpdb->prepare(
            "SELECT p.ID
            FROM {$this->posts_table} p
            WHERE p.post_parent = %d
              AND p.post_author = %d
              AND p.post_name LIKE %s
              AND p.post_type = 'attachment'
              AND p.ID > 0
              AND NOT EXISTS (
                  SELECT 1
                  FROM {$this->termmeta_table} tm
                  WHERE tm.term_id = p.post_parent
                    AND tm.meta_key = 'thumbnail_id'
                    AND tm.meta_value = p.ID
              )
            ORDER BY p.ID ASC",
            $term_id,
            $this->getAuthorId(),
            'fifu-category%'
        );
        $ids = array_values(array_unique(array_filter(array_map('intval', (array) $this->wpdb->get_col($sql)), static fn(int $id): bool => $id > 0)));
        if (!$ids) {
            return null;
        }

        $referenced = $this->get_referenced_attachment_ids($ids);
        $orphans = array_values(array_diff($ids, $referenced));
        return $orphans ? implode(',', $orphans) : null;
    }

    /**
     * Return the variation products associated with a configurable parent post.
     *
     * @param int $parent_product_id
     * @return array
     */
    public function get_variation_products(int $parent_product_id): array {
        $sql = $this->wpdb->prepare(
            "SELECT id, post_title
            FROM {$this->posts_table}
            WHERE post_parent = %d
              AND post_type = 'product_variation'
              AND post_status <> 'trash'
            ORDER BY menu_order",
            $parent_product_id
        );
        return $this->wpdb->get_results($sql);
    }

    /**
     * Count how many images are available as featured, gallery or category thumbnails.
     *
     * @return int
     */
    public function count_available_images(): int {
        $total = 0;

        $featured_count = $this->wpdb->get_var(
            "SELECT COUNT(1) AS total FROM {$this->postmeta_table} WHERE meta_key = '_thumbnail_id'"
        );
        $total += (int) $featured_count;

        if (class_exists('WooCommerce')) {
            $gallery_count = $this->wpdb->get_var(
                "SELECT SUM(LENGTH(meta_value) - LENGTH(REPLACE(meta_value, ',', '')) + 1) AS total
                FROM {$this->postmeta_table}
                WHERE meta_key = '_product_image_gallery'"
            );
            $total += (int) $gallery_count;

            $category_count = $this->wpdb->get_var(
                "SELECT COUNT(1) AS total FROM {$this->termmeta_table} WHERE meta_key = 'thumbnail_id'"
            );
            $total += (int) $category_count;
        }

        return $total;
    }
}
