<?php

defined('ABSPATH') || exit;

if (class_exists('Fifu_Slider_Renderer', false)) {
    return;
}

/**
 * Builds the markup for FIFU slider galleries on featured images.
 */
class Fifu_Slider_Renderer {

    /**
     * Renders the slider HTML used for advanced FIFU galleries.
     *
     * @param int         $post_id
     * @param string|null $original_class
     * @param string|null $gallery_class
     * @param string|null $gallery_css
     * @param int         $width
     * @param int         $height
     * @return string
     */
    public static function render_slider(int $post_id, ?string $original_class, ?string $gallery_class, ?string $gallery_css, int $width, int $height): string {
        global $FIFU_SESSION;

        $attachment_repository = fifu_attachment_repository();

        $att_id = get_post_thumbnail_id($post_id);
        $height = $height ?: 0;
        $width = $width ?: 0;

        $first_url = Fifu_Post_Slider_Image_Url_Read_Service::get_slider_image_url((int) $post_id, 0);
        if (!$first_url) {
            return '';
        }

        $css = Fifu_Image_Display_Policy::should_hide_featured_media() ? 'display:none' : '';

        $ratio = get_post_meta($post_id, 'fifu_slider_ratio', true);
        if (!$ratio && $width && $height && $width < 9999 && $height < 9999) {
            $ratio = $width . ':' . $height;
        }
        $attr_ratio = $ratio ? 'fifu-ratio="' . $ratio . '"' : '';

        $original_class = $original_class ?? '';
        $class = "fifu " . $original_class;

        $gallery_css = $gallery_css ? 'style="' . $gallery_css . '"' : '';

        $provider_registry = Fifu_Video_Provider_Registry::instance();
        $amazon_provider = $provider_registry->get_provider_by_class(Fifu_Amazon_Video_Provider::class);

        $html = sprintf('<div class="fifu-slider %s" id="fifu-slider-%s" %s %s>', $gallery_class, $post_id, $attr_ratio, $gallery_css);
        if (Fifu_Options_Utils::is_on('fifu_slider_counter')) {
            $html .= '<div style="font-size:12px; padding:2px 5px 2px 5px; background:rgba(0, 0, 0, 0.3); z-index:50; position:absolute; color:white" id="counter-slider"></div>';
        }
        $html .= '<ul id="image-gallery" class="gallery list-unstyled cS-hidden fifu-post-gallery">';

        $i = 0;
        while (true) {
            $url = $i === 0 ? $first_url : Fifu_Post_Slider_Image_Url_Read_Service::get_slider_image_url(
                (int) $post_id,
                (int) $i
            );
            if (!$url) {
                break;
            }

            $image_url = $url;
            $video_url = '';
            $separator_position = strpos($url, '#http');
            if ($separator_position !== false) {
                $image_url = substr($url, $separator_position + 1);
                $video_url = substr($url, 0, $separator_position);
                $video_url = Fifu_Video_Helper::get_embed_url($video_url) ?: $video_url;
                $video_src = Fifu_Video_Helper::get_embed_url_by_image($image_url);
                if ($video_src) {
                    $video_url = $video_src;
                }
                $FIFU_SESSION['fifu-video'][$image_url] = $video_src ? $video_src : $video_url;
            }

            $is_amazon_video = $amazon_provider && $video_url ? $amazon_provider->supports($video_url) : false;

            $alt = Fifu_Post_Slider_Image_Alt_Read_Service::get_slider_image_alt(
                (int) $post_id,
                (int) $i
            );

            $error_url = get_option('fifu_error_url');

            if ($image_url) {
                if (Fifu_Speedup_Url_Service::is_speedup_url($image_url)) {
                    $signed_url = Fifu_Speedup_Url_Service::get_signed_url($image_url, 128, 128, null, null, false);
                    $set = Fifu_Speedup_Url_Service::get_srcset($image_url);
                    $html .= sprintf(
                        '<li data-thumb="%s" data-src="%s" data-srcset="%s" data-alt="%s"><img src="%s" style="%s" class="%s" onerror="%s" alt="%s"/></li>',
                        esc_url($signed_url),
                        esc_url(Fifu_Media_Placeholders::TRANSPARENT_1PX_GIF),
                        esc_attr($set),
                        esc_attr($alt),
                        esc_url(Fifu_Speedup_Url_Service::get_signed_url($image_url, $width, $height, null, null, false)),
                        esc_attr($css),
                        esc_attr("fifu {$original_class}"),
                        "jQuery(this).hide();",
                        esc_attr($alt)
                    );
                    $i++;
                    continue;
                }

                if ($video_url) {
                    $type = 'data-src';
                    $data_video = '';

                    $is_local_video = Fifu_Video_Helper::is_local_video($video_url);
                    $is_wpcom_video = Fifu_Video_Helper::is_wpcom_video($video_url);
                    if ($is_local_video || $is_amazon_video || $is_wpcom_video) {
                        $type = 'data-video';
                        if ($is_local_video) {
                            $extension = pathinfo($video_url, PATHINFO_EXTENSION);
                            $file_type = "video/{$extension}";
                        } else {
                            $file_type = $is_amazon_video || $is_wpcom_video ? 'video/mp4' : 'video';
                        }
                        $data_video = '{"source": [{"src":"' . $video_url . '", "type":"' . $file_type . '"}], "attributes": {"preload": false, "controls": true}}';
                    }

                    $resolved_embed = Fifu_Video_Helper::get_embed_url($video_url);
                    if ($resolved_embed) {
                        $video_url = $resolved_embed;
                    }

                    $video_image_url = Fifu_Video_Oembed_Service::instance()->get_repository()->get_image_url_by_video_url($video_url);

                    $poster_attachment_id = $attachment_repository->find_attachment_id($post_id, $image_url, false);
                    if (
                        !$poster_attachment_id
                        && $video_image_url
                        && $video_image_url !== $image_url
                    ) {
                        $poster_attachment_id = $attachment_repository->find_attachment_id($post_id, $video_image_url, false);
                    }

                    $data_lg_size = '';
                    if ($poster_attachment_id) {
                        $metadata = wp_get_attachment_metadata($poster_attachment_id);
                        if ($metadata && isset($metadata['width'], $metadata['height'])) {
                            $video_image_width = $metadata['width'];
                            $video_image_height = $metadata['height'];
                            $data_lg_size = "data-lg-size=\"{$video_image_width}-{$video_image_height}\"";
                        }
                    }

                    $render_video_url = $video_url;
                    if ($type !== 'data-video') {
                        $render_video_url = Fifu_Video_Helper::get_embed_url($render_video_url) ?: $render_video_url;
                        $render_video_url = Fifu_Video_Helper::apply_privacy_enhanced_mode_to_embed_url($render_video_url);
                    }

                    $html .= sprintf(
                        '<li %s data-thumb="%s" %s=\'%s\' data-poster="%s"><img src="%s" style="%s" class="img-responsive%s" onerror="%s"/></li>',
                        $data_lg_size,
                        esc_url($image_url),
                        $type,
                        esc_attr($type == 'data-video' ? $data_video : $render_video_url),
                        esc_url($image_url),
                        esc_url($image_url),
                        esc_attr($css),
                        $class ? ' ' . esc_attr($class) : '',
                        $error_url ? sprintf("this.src='%s'", esc_url($error_url)) : ''
                    );
                } else {
                    $resized = $image_url;
                    if (Fifu_Options_Utils::is_on('fifu_photon')) {
                        $resized = Fifu_Image_Cdn_Resize_Service::resize_with_cdn($image_url, $width, $height, 1, $att_id, null);
                    }
                    $html .= sprintf(
                        '<li data-thumb="%s" data-src="%s" data-alt="%s"><img src="%s" style="%s" class="%s" onerror="%s" alt="%s"/></li>',
                        esc_url($resized),
                        esc_url($image_url),
                        esc_attr($alt),
                        esc_url($resized),
                        esc_attr($css),
                        esc_attr('fifu ' . $original_class),
                        $error_url ? sprintf("this.src='%s'", esc_url($error_url)) : '',
                        esc_attr($alt)
                    );
                }
            }
            $i++;
        }

        $html = str_replace('<img ', '<img fifu-replaced="1" ', $html);
        return $html . '</ul></div>';
    }
}
