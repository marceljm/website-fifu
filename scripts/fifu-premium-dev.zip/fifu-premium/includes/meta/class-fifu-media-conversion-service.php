<?php declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Handles conversions from internal attachments to FIFU remote metadata.
 */
final class Fifu_Media_Conversion_Service
{
    private static function create_post_fake_attachment(string $url, ?string $alt, int $postId): int
    {
        $url = trim(htmlspecialchars_decode($url));
        if ($url === '') {
            return 0;
        }

        $factory = new Fifu_Attachment_Factory();
        $attachmentId = $factory->create_attachment_for_url($url, $alt, $postId);
        if ($attachmentId <= 0) {
            return 0;
        }

        Fifu_Attachment_Update_Service::initialize_remote_attachment($attachmentId, $url, $alt, null, null, true);
        return $attachmentId;
    }

    private static function create_term_fake_attachment(string $url, ?string $alt, int $termId): int
    {
        $url = trim(htmlspecialchars_decode($url));
        if ($url === '') {
            return 0;
        }

        $factory = new Fifu_Attachment_Factory();
        $attachmentId = $factory->create_category_attachment_for_url($url, $alt, $termId);
        if ($attachmentId <= 0) {
            return 0;
        }

        Fifu_Attachment_Update_Service::initialize_remote_attachment($attachmentId, $url, $alt, null, null, true);
        return $attachmentId;
    }

    private static function is_post_image_url_confirmed_in_db2(int $postId, int $index, string $url): bool
    {
        if (!function_exists('fifu_db2_manager')) {
            return false;
        }

        $mapping = fifu_db2_manager()->getPostMapping($postId, 'image', $index);
        if (!is_array($mapping)) {
            return false;
        }

        return trim((string) ($mapping['url'] ?? '')) === trim($url);
    }

    private static function is_term_image_url_confirmed_in_db2(int $termId, string $url): bool
    {
        if (!function_exists('fifu_db2_manager')) {
            return false;
        }

        $mapping = fifu_db2_manager()->getTermMapping($termId, 'image');
        if (!is_array($mapping)) {
            return false;
        }

        return trim((string) ($mapping['url'] ?? '')) === trim($url);
    }

    /**
     * @param array $ids
     * @return int[]
     */
    private static function normalize_ids(array $ids): array
    {
        $normalized = [];
        foreach ($ids as $id) {
            $id = (int) $id;
            if ($id <= 0) {
                continue;
            }

            $normalized[$id] = true;
        }

        return array_keys($normalized);
    }

    /**
     * @param int[] $postIds
     * @return void
     */
    private static function invalidate_post_meta_cache(array $postIds): void
    {
        foreach (self::normalize_ids($postIds) as $postId) {
            wp_cache_delete($postId, 'post_meta');
        }
    }

    /**
     * @param int[] $termIds
     * @return void
     */
    private static function invalidate_term_meta_cache(array $termIds): void
    {
        foreach (self::normalize_ids($termIds) as $termId) {
            wp_cache_delete($termId, 'term_meta');
        }
    }

    /**
     * Converts internal media usage (attachments) into FIFU remote URL metadata.
     *
     * This method will:
     * - Backup current attachments for posts and terms.
     * - Build mapping from attachment IDs to URLs.
     * - Insert FIFU custom fields into DB2 tables.
     * - Clean up old attachment IDs and update caches.
     * - Trigger post/term metadata backfill in maintenance controller.
     *
     * @param array $selected List of items selected in the admin UI.
     *                        Each item mirrors the structure of the legacy REST payload.
     *
     * @return void
     */
    public static function convert_to_fifu(array $selected): void
    {
        $postIds = [];
        $termIds = [];
        $selectedPostIds = [];
        foreach ($selected as $item) {
            $postId = $item[0] ?? null;
            $url = $item[1] ?? null;
            $isCategory = ($item[4] ?? 0) == 1;

            if (!$postId || !$url) {
                continue;
            }

            if ($isCategory) {
                $termIds[] = $postId;
            } else {
                $postIds[] = $postId;
                $selectedPostIds[] = (int) $postId;
            }
        }

        $speedUpRepository = function_exists('fifu_db2_speed_up_repository') ? fifu_db2_speed_up_repository() : null;
        $speedUpService = $speedUpRepository ? new Fifu_Db2_Speed_Up_Service($speedUpRepository) : null;

        if (!empty($postIds)) {
            $speedUpService?->backup_post_attachments($postIds);
        }

        if (!empty($termIds)) {
            $speedUpService?->backup_term_attachments($termIds);
        }

        if (!empty($postIds) && $speedUpRepository) {
            $map = [];
            $results = $speedUpRepository->get_internal_urls_for_posts($postIds);
            foreach ($results as $result) {
                $attId = (int) ($result->att_id ?? 0);
                if ($attId <= 0) {
                    continue;
                }
                $map[$attId] = [
                    'url' => trim((string) ($result->url ?? '')),
                    'alt' => trim(wp_strip_all_tags((string) ($result->alt ?? ''))),
                ];
            }
        } else {
            $map = [];
        }

        if (!empty($termIds) && $speedUpRepository) {
            $ctgrMap = [];
            $ctgrResults = $speedUpRepository->get_internal_urls_for_terms($termIds);
            foreach ($ctgrResults as $result) {
                $attId = (int) ($result->att_id ?? 0);
                if ($attId <= 0) {
                    continue;
                }
                $ctgrMap[$attId] = [
                    'url' => trim((string) ($result->url ?? '')),
                    'alt' => trim(wp_strip_all_tags((string) ($result->alt ?? ''))),
                ];
            }
        } else {
            $ctgrMap = [];
        }

        $postMetaChanges = [];
        $termMetaChanges = [];
        $postAltChanges = [];
        $termAltChanges = [];
        $postAttachmentBackfills = [];
        $termAttachmentBackfills = [];
        foreach ($selected as $item) {
            $postId = $item[0] ?? null;
            $url = $item[1] ?? null;
            $thumbnailId = $item[2] ?? null;
            $galleryIds = $item[3] ?? null;
            $isCategory = ($item[4] ?? 0) == 1;

            if ($isCategory) {
                if ($thumbnailId) {
                    $featured = $ctgrMap[(int) $thumbnailId] ?? null;
                    $termMetaUrl = trim((string) ($featured['url'] ?? ''));
                    if ($termMetaUrl !== '') {
                        $featuredAlt = '';
                        $termMetaChanges[] = [
                            'term_id' => (int) $postId,
                            'meta_key' => 'fifu_image_url',
                            'url' => $termMetaUrl,
                            'confirmed' => false,
                        ];

                        $termAlt = trim((string) ($featured['alt'] ?? ''));
                        if ($termAlt !== '') {
                            $termAltChanges[] = [
                                'term_id' => (int) $postId,
                                'meta_key' => 'fifu_image_alt',
                                'alt' => $termAlt,
                            ];
                            $featuredAlt = $termAlt;
                        }

                        $termAttachmentBackfills[(int) $postId] = [
                            'url' => $termMetaUrl,
                            'alt' => $featuredAlt,
                        ];
                    }
                }
            } else {
                $resolvedGalleryEntries = [];
                $galleryTokens = [];
                if ($galleryIds) {
                    $galleryTokens = array_filter(array_map('trim', explode(',', (string) $galleryIds)), static fn ($value) => $value !== '');
                    foreach ($galleryTokens as $token) {
                        $galleryId = (int) $token;
                        if ($galleryId <= 0) {
                            continue;
                        }

                        $gallery = $map[$galleryId] ?? null;
                        $galleryUrl = trim((string) ($gallery['url'] ?? ''));
                        if ($galleryUrl === '') {
                            continue;
                        }

                        $resolvedGalleryEntries[] = [
                            'gallery_id' => $galleryId,
                            'url' => $galleryUrl,
                            'alt' => trim((string) ($gallery['alt'] ?? '')),
                        ];
                    }
                }

                if ($galleryTokens !== [] && count($resolvedGalleryEntries) === 1 && count($galleryTokens) > 1) {
                    self::invalidate_post_meta_cache([(int) $postId]);
                    self::invalidate_post_meta_cache([(int) $postId]);
                    continue;
                }

                if ($thumbnailId) {
                    $featured = $map[(int) $thumbnailId] ?? null;
                    $singleUrl = trim((string) ($featured['url'] ?? ''));
                    if ($singleUrl !== '') {
                        $postMetaChanges[] = [
                            'post_id' => (int) $postId,
                            'meta_key' => 'fifu_image_url',
                            'url' => $singleUrl,
                            'index' => 0,
                            'confirmed' => false,
                        ];

                        $featuredAlt = trim((string) ($featured['alt'] ?? ''));
                        if ($featuredAlt !== '') {
                            $postAltChanges[] = [
                                'post_id' => (int) $postId,
                                'meta_key' => 'fifu_image_alt',
                                'alt' => $featuredAlt,
                            ];
                        }

                        $postAttachmentBackfills[(int) $postId]['featured'] = [
                            'attachment_id' => (int) $thumbnailId,
                            'url' => $singleUrl,
                            'alt' => $featuredAlt,
                        ];
                    }
                }

                if ($resolvedGalleryEntries !== []) {
                    foreach ($resolvedGalleryEntries as $index => $galleryEntry) {
                        $postMetaChanges[] = [
                            'post_id' => (int) $postId,
                            'meta_key' => 'fifu_image_url_' . $index,
                            'url' => $galleryEntry['url'],
                            'index' => $index + 1,
                            'confirmed' => false,
                        ];

                        if ($galleryEntry['alt'] !== '') {
                            $postAltChanges[] = [
                                'post_id' => (int) $postId,
                                'meta_key' => 'fifu_image_alt_' . $index,
                                'alt' => $galleryEntry['alt'],
                            ];
                        }

                        $postAttachmentBackfills[(int) $postId]['gallery'][$index] = [
                            'attachment_id' => (int) $galleryEntry['gallery_id'],
                            'url' => $galleryEntry['url'],
                            'alt' => $galleryEntry['alt'],
                        ];
                    }
                }
            }
        }

        $legacyBridge = null;
        if (
            function_exists('fifu_db2_legacy_write_bridge')
            && class_exists('Fifu_Db2_Legacy_Write_Bridge')
        ) {
            $bridgeCandidate = fifu_db2_legacy_write_bridge();
            if ($bridgeCandidate instanceof Fifu_Db2_Legacy_Write_Bridge) {
                $legacyBridge = $bridgeCandidate;
            }
        }

        $featuredUrlAcceptedByPostId = [];
        $galleryUrlAcceptedByPostId = [];
        $featuredUrlConfirmedByPostId = [];
        $galleryUrlConfirmedByPostId = [];
        $termUrlAcceptedByTermId = [];
        $termUrlConfirmedByTermId = [];
        if ($legacyBridge && !empty($postMetaChanges)) {
            foreach ($postMetaChanges as $postMetaChange) {
                if ($postMetaChange['url'] === '') {
                    continue;
                }
                $result = $legacyBridge->handle_post_meta_change(
                    $postMetaChange['post_id'],
                    $postMetaChange['meta_key'],
                    $postMetaChange['url']
                );
                if (!$result) {
                    continue;
                }

                if ($postMetaChange['meta_key'] === 'fifu_image_url') {
                    $postId = (int) $postMetaChange['post_id'];
                    $featuredUrlAcceptedByPostId[$postId] = true;
                    if (self::is_post_image_url_confirmed_in_db2($postId, 0, $postMetaChange['url'])) {
                        $featuredUrlConfirmedByPostId[$postId] = true;
                    }
                    continue;
                }

                if (str_starts_with($postMetaChange['meta_key'], 'fifu_image_url_')) {
                    $postId = (int) $postMetaChange['post_id'];
                    $index = (int) ($postMetaChange['index'] ?? 0);
                    $galleryUrlAcceptedByPostId[$postId][] = $index;
                    if (self::is_post_image_url_confirmed_in_db2($postId, $index, $postMetaChange['url'])) {
                        $galleryUrlConfirmedByPostId[$postId][] = $index;
                    }
                }
            }
        }

        if ($legacyBridge && !empty($termMetaChanges)) {
            foreach ($termMetaChanges as $termMetaChange) {
                if ($termMetaChange['url'] === '') {
                    continue;
                }
                $result = $legacyBridge->handle_term_meta_change(
                    $termMetaChange['term_id'],
                    $termMetaChange['meta_key'],
                    $termMetaChange['url']
                );
                if ($result) {
                    $termId = (int) $termMetaChange['term_id'];
                    $termUrlAcceptedByTermId[$termId] = true;
                    if (self::is_term_image_url_confirmed_in_db2($termId, $termMetaChange['url'])) {
                        $termUrlConfirmedByTermId[$termId] = true;
                    }
                }
            }
        }

        $selectedPostIds = array_values(array_unique(array_map('intval', $selectedPostIds)));
        $selectedTermIds = array_values(array_unique(array_map('intval', $termIds)));

        if (!$legacyBridge) {
            self::invalidate_post_meta_cache($selectedPostIds);
            self::invalidate_term_meta_cache($selectedTermIds);
        }

        if ($legacyBridge && !empty($postAltChanges)) {
            foreach ($postAltChanges as $postAltChange) {
                if ($postAltChange['alt'] === '') {
                    continue;
                }

                $postId = (int) $postAltChange['post_id'];
                $metaKey = (string) $postAltChange['meta_key'];
                if ($metaKey === 'fifu_image_alt') {
                    if (empty($featuredUrlAcceptedByPostId[$postId])) {
                        continue;
                    }
                    $legacyBridge->handle_post_meta_change($postId, $metaKey, $postAltChange['alt']);
                    continue;
                }

                if (preg_match('/^fifu_image_alt_(\d+)$/', $metaKey, $matches)) {
                    $index = (int) $matches[1] + 1;
                    if (empty($galleryUrlAcceptedByPostId[$postId]) || !in_array($index, $galleryUrlAcceptedByPostId[$postId], true)) {
                        continue;
                    }
                    $legacyBridge->handle_post_meta_change($postId, $metaKey, $postAltChange['alt']);
                }
            }
        }

        if ($legacyBridge && !empty($termAltChanges)) {
            foreach ($termAltChanges as $termAltChange) {
                if ($termAltChange['alt'] === '') {
                    continue;
                }

                $termId = (int) $termAltChange['term_id'];
                if (empty($termUrlAcceptedByTermId[$termId])) {
                    continue;
                }

                $legacyBridge->handle_term_meta_change(
                    $termId,
                    $termAltChange['meta_key'],
                    $termAltChange['alt']
                );
            }
        }

        foreach ($postAttachmentBackfills as $postId => $backfill) {
            if (!empty($featuredUrlConfirmedByPostId[$postId]) && !empty($backfill['featured'])) {
                $featured = $backfill['featured'];
                $newAttachmentId = self::create_post_fake_attachment(
                    (string) $featured['url'],
                    (string) $featured['alt'],
                    (int) $postId
                );
                if ($newAttachmentId > 0) {
                    update_post_meta((int) $postId, '_thumbnail_id', $newAttachmentId);
                }
            }

            if (!empty($galleryUrlConfirmedByPostId[$postId]) && !empty($backfill['gallery'])) {
                $galleryAttachmentIds = [];
                foreach ($backfill['gallery'] as $index => $galleryItem) {
                    if (!in_array((int) $index + 1, $galleryUrlConfirmedByPostId[$postId], true)) {
                        continue;
                    }

                    $newAttachmentId = self::create_post_fake_attachment(
                        (string) $galleryItem['url'],
                        (string) $galleryItem['alt'],
                        (int) $postId
                    );
                    if ($newAttachmentId > 0) {
                        $galleryAttachmentIds[] = $newAttachmentId;
                    }
                }

                if ($galleryAttachmentIds !== []) {
                    update_post_meta((int) $postId, '_product_image_gallery', implode(',', $galleryAttachmentIds));
                } elseif (!metadata_exists('post', (int) $postId, '_product_image_gallery')) {
                    delete_post_meta((int) $postId, '_product_image_gallery');
                }
            }
        }

        foreach ($selectedTermIds as $termId) {
            if (empty($termUrlConfirmedByTermId[$termId]) || empty($termAttachmentBackfills[$termId])) {
                continue;
            }

            $termBackfill = $termAttachmentBackfills[$termId];
            $newAttachmentId = self::create_term_fake_attachment(
                (string) $termBackfill['url'],
                (string) $termBackfill['alt'],
                (int) $termId
            );
            if ($newAttachmentId > 0) {
                update_term_meta((int) $termId, 'thumbnail_id', $newAttachmentId);
            }
        }

        if ($legacyBridge) {
            self::invalidate_post_meta_cache(array_keys($featuredUrlAcceptedByPostId + $galleryUrlAcceptedByPostId));
            self::invalidate_term_meta_cache(array_keys($termUrlAcceptedByTermId));
        }

        Fifu_Meta_Maintenance_Controller::backfill_post_attachments();
        Fifu_Meta_Maintenance_Controller::backfill_external_galleries();
        Fifu_Meta_Maintenance_Controller::backfill_term_attachments();
    }
}
