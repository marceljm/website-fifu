<?php
declare(strict_types=1);

defined('ABSPATH') || exit;

final class Fifu_Content_Auto_Media_Service
{
    public static function process_queue_item(int $id): bool
    {
        global $wpdb;

        Fifu_File_Logger::plugin(['insert_content' => ['id' => $id]]);

        $postIds = self::load_post_ids_from_queue($id);
        if (empty($postIds)) {
            return false;
        }

        foreach ($postIds as $postId) {
            self::assign_media_from_content($postId);
        }

        self::delete_queue_item($id);
        self::decrement_counter(count($postIds));

        return true;
    }

    private static function load_post_ids_from_queue(int $id): array
    {
        global $wpdb;

        $table = $wpdb->prefix . 'fifu_content';
        $result = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT post_ids FROM {$table} WHERE id = %d",
                $id
            )
        );

        if (!$result) {
            return [];
        }

        $parts = array_filter(array_map('trim', explode(',', $result)), static function ($value) {
            return $value !== '';
        });

        return array_map('intval', $parts);
    }

    private static function delete_queue_item(int $id): void
    {
        global $wpdb;

        $table = $wpdb->prefix . 'fifu_content';
        $wpdb->delete($table, ['id' => $id], ['%d']);
    }

    private static function assign_media_from_content(int $postId): void
    {
        $postContent = get_post_field('post_content', $postId);
        $content = html_entity_decode($postContent);
        $mediaType = self::get_html_media_type();
        $media = Fifu_Content_Url_Scanner::find_first_media($postId, $content, $mediaType);
        if (!$media && $mediaType !== 'video') {
            $media = Fifu_Content_Url_Scanner::find_first_media($postId, $content, 'video');
        }
        if (!$media) {
            return;
        }

        if (($media['type'] ?? '') === 'image') {
            $imageUrl = (string) ($media['url'] ?? '');
            $imageAlt = $media['alt'] ?? null;
            $currentImageUrl = self::get_current_featured_image_url($postId);
            $imageUrlChanged = !self::same_featured_image_url($currentImageUrl, $imageUrl);
            if (!$imageUrlChanged) {
                self::sync_unchanged_featured_image_to_db2_and_cleanup_legacy(
                    $postId,
                    $imageUrl,
                    is_string($imageAlt) ? trim($imageAlt) : ''
                );
                return;
            }

            $legacyAltSnapshot = self::get_legacy_featured_image_alt_snapshot($postId);
            $imageSet = Fifu_Developer_Media_Service::set_image($postId, $imageUrl);
            if ($imageSet === false) {
                self::restore_legacy_featured_image_alt_snapshot($postId, $legacyAltSnapshot);
                return;
            }

            if (!self::is_featured_image_url_confirmed_in_db2($postId, $imageUrl)) {
                self::restore_legacy_featured_image_alt_snapshot($postId, $legacyAltSnapshot);
                return;
            }

            if (function_exists('fifu_test_record_db2_legacy_write_bridge_call')) {
                fifu_test_record_db2_legacy_write_bridge_call($postId, 'fifu_image_url', $imageUrl);
            }

            self::delete_legacy_featured_image_url_postmeta($postId);

            $imageAltValue = is_string($imageAlt) ? trim($imageAlt) : '';
            self::sync_featured_image_alt_after_confirmed_url_change(
                $postId,
                $imageUrl,
                $imageAltValue !== '' ? $imageAltValue : null
            );
            return;
        }

        if (($media['type'] ?? '') === 'video') {
            $videoUrl = (string) ($media['url'] ?? '');
            if ($videoUrl === '' || Fifu_Options_Utils::is_off('fifu_video')) {
                return;
            }

            $videoSet = Fifu_Developer_Media_Service::set_video($postId, $videoUrl);
            if ($videoSet === false) {
                return;
            }

            if (!self::is_featured_video_url_confirmed_in_db2($postId, $videoUrl)) {
                return;
            }

            if (function_exists('fifu_test_record_db2_legacy_write_bridge_call')) {
                fifu_test_record_db2_legacy_write_bridge_call($postId, 'fifu_image_url', null);
                fifu_test_record_db2_legacy_write_bridge_call($postId, 'fifu_video_url', $videoUrl);
            }
        }
    }

    private static function is_featured_video_url_confirmed_in_db2(int $postId, string $videoUrl): bool
    {
        if (!function_exists('fifu_db2_manager')) {
            return false;
        }

        $manager = fifu_db2_manager();
        if (!$manager) {
            return false;
        }

        $mapping = $manager->getPostMapping($postId, 'video', 0);
        if (!is_array($mapping)) {
            return false;
        }

        return trim((string) ($mapping['url'] ?? '')) === trim($videoUrl);
    }

    private static function sync_unchanged_featured_image_to_db2_and_cleanup_legacy(int $postId, string $imageUrl, string $contentAlt): void
    {
        $contentAlt = trim($contentAlt);
        $legacyAlt = trim((string) get_post_meta($postId, 'fifu_image_alt', true));

        if (!self::is_featured_image_url_confirmed_in_db2($postId, $imageUrl)) {
            $legacyAltSnapshot = self::get_legacy_featured_image_alt_snapshot($postId);
            $imageSet = Fifu_Developer_Media_Service::set_image($postId, $imageUrl);

            if ($imageSet === false) {
                self::restore_legacy_featured_image_alt_snapshot($postId, $legacyAltSnapshot);
                return;
            }

            if (!self::is_featured_image_url_confirmed_in_db2($postId, $imageUrl)) {
                self::restore_legacy_featured_image_alt_snapshot($postId, $legacyAltSnapshot);
                return;
            }

            if (function_exists('fifu_test_record_db2_legacy_write_bridge_call')) {
                fifu_test_record_db2_legacy_write_bridge_call($postId, 'fifu_image_url', $imageUrl);
            }
        }

        if (!self::is_featured_image_url_confirmed_in_db2($postId, $imageUrl)) {
            return;
        }

        self::delete_legacy_featured_image_url_postmeta($postId);

        $db2Alt = self::get_featured_image_alt_from_db2($postId);
        if ($db2Alt !== null) {
            self::delete_legacy_featured_image_alt_postmeta($postId);
            return;
        }

        $altToSave = $legacyAlt !== '' ? $legacyAlt : $contentAlt;
        if ($altToSave === '') {
            self::delete_legacy_featured_image_alt_postmeta($postId);
            return;
        }

        if (self::save_featured_image_alt_in_db2($postId, $altToSave)) {
            self::delete_legacy_featured_image_alt_postmeta($postId);
        }
    }

    private static function get_current_featured_image_url(int $postId): ?string
    {
        if (function_exists('fifu_db2_manager')) {
            $manager = fifu_db2_manager();
            if ($manager) {
                $mapping = $manager->getPostMapping($postId, 'image', 0);
                $url = is_array($mapping) ? trim((string) ($mapping['url'] ?? '')) : '';
                if ($url !== '') {
                    return $url;
                }
            }
        }

        $legacyUrl = trim((string) get_post_meta($postId, 'fifu_image_url', true));
        return $legacyUrl !== '' ? $legacyUrl : null;
    }

    private static function same_featured_image_url(?string $currentUrl, string $newUrl): bool
    {
        $currentUrl = trim((string) $currentUrl);
        $newUrl = trim($newUrl);

        return $currentUrl !== '' && $currentUrl === $newUrl;
    }

    private static function is_featured_image_url_confirmed_in_db2(int $postId, string $imageUrl): bool
    {
        if (!function_exists('fifu_db2_manager')) {
            return false;
        }

        $manager = fifu_db2_manager();
        if (!$manager) {
            return false;
        }

        $mapping = $manager->getPostMapping($postId, 'image', 0);
        if (!is_array($mapping)) {
            return false;
        }

        return trim((string) ($mapping['url'] ?? '')) === trim($imageUrl);
    }

    private static function sync_featured_image_alt_after_confirmed_url_change(int $postId, string $imageUrl, ?string $imageAlt): void
    {
        if (!self::is_featured_image_url_confirmed_in_db2($postId, $imageUrl)) {
            return;
        }

        $imageAlt = is_string($imageAlt) ? trim($imageAlt) : '';
        if ($imageAlt !== '' && !self::save_featured_image_alt_in_db2($postId, $imageAlt)) {
            return;
        }

        self::delete_legacy_featured_image_alt_postmeta($postId);
    }

    private static function get_featured_image_alt_from_db2(int $postId): ?string
    {
        global $wpdb;

        $alt = $wpdb->get_var($wpdb->prepare(
            "SELECT a.alt
               FROM {$wpdb->prefix}fifu_alt_map am
               INNER JOIN {$wpdb->prefix}fifu_key k ON k.key_id = am.key_id
               INNER JOIN {$wpdb->prefix}fifu_alt a ON a.hash = am.hash
              WHERE am.post_id = %d
                AND k.key_type = %s
                AND am.key_index = %d
              LIMIT 1",
            $postId,
            'image',
            0
        ));

        $alt = trim((string) $alt);
        return $alt !== '' ? $alt : null;
    }

    private static function get_legacy_featured_image_alt_snapshot(int $postId): array
    {
        $exists = false;

        if (function_exists('metadata_exists')) {
            $exists = metadata_exists('post', $postId, 'fifu_image_alt');
        } else {
            $meta = get_post_meta($postId);
            $exists = is_array($meta) && array_key_exists('fifu_image_alt', $meta);
        }

        return [
            'exists' => $exists,
            'value' => $exists ? get_post_meta($postId, 'fifu_image_alt', true) : null,
        ];
    }

    private static function restore_legacy_featured_image_alt_snapshot(int $postId, array $snapshot): void
    {
        if (empty($snapshot['exists'])) {
            return;
        }

        update_post_meta($postId, 'fifu_image_alt', (string) ($snapshot['value'] ?? ''));

        if (function_exists('clean_post_cache')) {
            clean_post_cache($postId);
        }

        if (function_exists('wp_cache_delete')) {
            wp_cache_delete($postId, 'post_meta');
        }
    }

    private static function save_featured_image_alt_in_db2(int $postId, string $imageAlt): bool
    {
        global $wpdb;

        $imageAlt = trim($imageAlt);
        if ($imageAlt === '') {
            return false;
        }

        $hash = md5($imageAlt);
        $keyId = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT key_id FROM {$wpdb->prefix}fifu_key WHERE key_type = %s LIMIT 1",
            'image'
        ));

        if ($keyId <= 0) {
            return false;
        }

        $altInserted = $wpdb->query($wpdb->prepare(
            "INSERT INTO {$wpdb->prefix}fifu_alt (hash, alt) VALUES (%s, %s) ON DUPLICATE KEY UPDATE alt = VALUES(alt)",
            $hash,
            $imageAlt
        ));

        if ($altInserted === false) {
            return false;
        }

        $mapInserted = $wpdb->query($wpdb->prepare(
            "INSERT INTO {$wpdb->prefix}fifu_alt_map (post_id, key_id, key_index, hash) VALUES (%d, %d, %d, %s) ON DUPLICATE KEY UPDATE hash = VALUES(hash)",
            $postId,
            $keyId,
            0,
            $hash
        ));

        if ($mapInserted === false) {
            return false;
        }

        return self::get_featured_image_alt_from_db2($postId) === $imageAlt;
    }

    private static function delete_legacy_featured_image_url_postmeta(int $postId): void
    {
        delete_post_meta($postId, 'fifu_image_url');

        if (function_exists('clean_post_cache')) {
            clean_post_cache($postId);
        }

        if (function_exists('wp_cache_delete')) {
            wp_cache_delete($postId, 'post_meta');
        }
    }

    private static function delete_legacy_featured_image_alt_postmeta(int $postId): void
    {
        delete_post_meta($postId, 'fifu_image_alt');

        if (function_exists('clean_post_cache')) {
            clean_post_cache($postId);
        }

        if (function_exists('wp_cache_delete')) {
            wp_cache_delete($postId, 'post_meta');
        }
    }

    private static function decrement_counter(int $count): void
    {
        $count = max(0, $count);

        $current = Fifu_Transient_Manager::get('fifu_content_counter');
        $current = is_numeric($current) ? max(0, (int) $current) : 0;
        Fifu_Transient_Manager::set('fifu_content_counter', max(0, $current - $count), 0);
    }

    private static function get_html_media_type(): string
    {
        $type = (string) get_option('fifu_html_media', 'image');
        return in_array($type, ['image', 'video', 'all'], true) ? $type : 'image';
    }
}
