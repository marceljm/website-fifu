<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

final class Fifu_Legacy_Image_Meta_Cleanup_Service
{
    /**
     * @param array<int,string> $skip_meta_keys
     */
    public static function cleanup_post_image_meta_after_db2_sync(int $post_id, array $skip_meta_keys = []): void
    {
        $manager = self::get_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return;
        }

        self::ensure_cleanup_guard_loaded();
        if (!class_exists('Fifu_Metadata_Db2_Cleanup_Guard', false)) {
            return;
        }

        $skip_meta_key_lookup = self::normalize_skip_meta_keys($skip_meta_keys);

        self::cleanup_single_image_meta($post_id, 'fifu_image_url', true, 0, $skip_meta_key_lookup);
        self::cleanup_single_image_meta($post_id, 'fifu_image_alt', false, 0, $skip_meta_key_lookup);

        self::cleanup_indexed_image_meta($post_id, true, $skip_meta_key_lookup);
        self::cleanup_indexed_image_meta($post_id, false, $skip_meta_key_lookup);

        self::cleanup_image_list_meta($post_id, 'fifu_list_url', true, $skip_meta_key_lookup);
        self::cleanup_image_list_meta($post_id, 'fifu_list_alt', false, $skip_meta_key_lookup);
    }

    private static function ensure_cleanup_guard_loaded(): void
    {
        if (class_exists('Fifu_Metadata_Db2_Cleanup_Guard', false)) {
            return;
        }

        $guardPath = __DIR__ . '/class-fifu-metadata-db2-cleanup-guard.php';
        if (is_readable($guardPath)) {
            require_once $guardPath;
        }
    }

    /**
     * @param array<string,bool> $skip_meta_key_lookup
     */
    private static function cleanup_single_image_meta(
        int $post_id,
        string $meta_key,
        bool $is_url,
        int $db2_index,
        array $skip_meta_key_lookup = []
    ): void
    {
        if (self::should_skip_meta_key($meta_key, $skip_meta_key_lookup)) {
            return;
        }

        if (!metadata_exists('post', $post_id, $meta_key)) {
            return;
        }

        $legacy_value = self::normalize_legacy_value(
            (string) get_post_meta($post_id, $meta_key, true),
            $is_url
        );

        if ($legacy_value === null) {
            return;
        }

        $db2_value = $is_url
            ? self::get_db2_image_url($post_id, $db2_index)
            : self::get_db2_image_alt($post_id, $db2_index);

        if ($db2_value === null || $db2_value !== $legacy_value) {
            return;
        }

        self::delete_legacy_postmeta_raw($post_id, $meta_key);
    }

    /**
     * @param array<string,bool> $skip_meta_key_lookup
     */
    private static function cleanup_indexed_image_meta(int $post_id, bool $is_url, array $skip_meta_key_lookup = []): void
    {
        $meta = get_post_meta($post_id);
        if (!is_array($meta) || empty($meta)) {
            return;
        }

        $pattern = $is_url ? '/^fifu_image_url_(\d+)$/' : '/^fifu_image_alt_(\d+)$/';

        foreach (array_keys($meta) as $meta_key) {
            if (!is_string($meta_key) || preg_match($pattern, $meta_key, $matches) !== 1) {
                continue;
            }

            if (self::should_skip_meta_key($meta_key, $skip_meta_key_lookup)) {
                continue;
            }

            $legacy_value = self::normalize_legacy_value((string) get_post_meta($post_id, $meta_key, true), $is_url);
            if ($legacy_value === null) {
                continue;
            }

            $legacy_index = (int) $matches[1];
            $db2_index = $legacy_index + 1;
            $db2_value = $is_url
                ? self::get_db2_image_url($post_id, $db2_index)
                : self::get_db2_image_alt($post_id, $db2_index);

            if ($db2_value === null || $db2_value !== $legacy_value) {
                continue;
            }

            self::delete_legacy_postmeta_raw($post_id, $meta_key);
        }
    }

    /**
     * @param array<string,bool> $skip_meta_key_lookup
     */
    private static function cleanup_image_list_meta(
        int $post_id,
        string $meta_key,
        bool $is_url,
        array $skip_meta_key_lookup = []
    ): void
    {
        if (self::should_skip_meta_key($meta_key, $skip_meta_key_lookup)) {
            return;
        }

        if (!metadata_exists('post', $post_id, $meta_key)) {
            return;
        }

        if (!empty($_REQUEST['fifu_preserve_legacy_gallery_list_until_db2_confirmation'])) {
            return;
        }

        if ($is_url) {
            $legacyValue = (string) get_post_meta($post_id, 'fifu_list_url', true);
            if ($legacyValue === '') {
                return;
            }

            $db2Value = self::get_db2_image_url_list($post_id);
            if (!Fifu_Metadata_Db2_Cleanup_Guard::can_cleanup_pipe_list($legacyValue, $db2Value)) {
                return;
            }

            self::delete_legacy_postmeta_raw($post_id, $meta_key);
            return;
        }

        $legacyValue = (string) get_post_meta($post_id, 'fifu_list_alt', true);
        if ($legacyValue === '') {
            return;
        }

        $db2Value = self::get_db2_image_alt_list($post_id);
        if (!Fifu_Metadata_Db2_Cleanup_Guard::can_cleanup_pipe_list($legacyValue, $db2Value)) {
            return;
        }

        self::delete_legacy_postmeta_raw($post_id, $meta_key);
    }

    /**
     * @param array<int,string> $skip_meta_keys
     * @return array<string,bool>
     */
    private static function normalize_skip_meta_keys(array $skip_meta_keys): array
    {
        $lookup = [];

        foreach ($skip_meta_keys as $meta_key) {
            $meta_key = trim((string) $meta_key);
            if ($meta_key !== '') {
                $lookup[$meta_key] = true;
            }
        }

        return $lookup;
    }

    /**
     * @param array<string,bool> $skip_meta_key_lookup
     */
    private static function should_skip_meta_key(string $meta_key, array $skip_meta_key_lookup): bool
    {
        return isset($skip_meta_key_lookup[$meta_key]);
    }

    /**
     * @return array<int, array{key_index:int,url:string|null}>
     */
    private static function get_db2_image_url_list_rows(int $post_id): array
    {
        $manager = self::get_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return [];
        }

        $rows = $manager->getPostMappings($post_id, 'image');
        if (!$rows) {
            return [];
        }

        usort(
            $rows,
            static fn(array $left, array $right): int => ((int) ($left['key_index'] ?? 0)) <=> ((int) ($right['key_index'] ?? 0))
        );

        $normalized = [];
        foreach ($rows as $row) {
            $value = self::normalize_legacy_value((string) ($row['url'] ?? ''), true);
            if ($value === null) {
                return [];
            }

            $normalized[] = [
                'key_index' => (int) ($row['key_index'] ?? 0),
                'url' => $value,
            ];
        }

        return $normalized;
    }

    /**
     * @return array<int, array{key_index:int,alt:string|null}>
     */
    private static function get_db2_image_alt_list_rows(int $post_id): array
    {
        $manager = self::get_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return [];
        }

        $rows = $manager->getPostAltMappings($post_id, 'image');
        if (!$rows) {
            return [];
        }

        usort(
            $rows,
            static fn(array $left, array $right): int => ((int) ($left['key_index'] ?? 0)) <=> ((int) ($right['key_index'] ?? 0))
        );

        $normalized = [];
        foreach ($rows as $row) {
            $value = self::normalize_legacy_value((string) ($row['alt'] ?? ''), false);
            if ($value === null) {
                return [];
            }

            $normalized[] = [
                'key_index' => (int) ($row['key_index'] ?? 0),
                'alt' => $value,
            ];
        }

        return $normalized;
    }

    private static function get_db2_image_url(int $post_id, int $index): ?string
    {
        $manager = self::get_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return null;
        }

        $mapping = $manager->getPostMapping($post_id, 'image', $index);
        if (!is_array($mapping)) {
            return null;
        }

        return self::normalize_legacy_value((string) ($mapping['url'] ?? ''), true);
    }

    private static function get_db2_image_alt(int $post_id, int $index): ?string
    {
        $manager = self::get_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return null;
        }

        $mapping = $manager->getPostAltMapping($post_id, 'image', $index);
        if (!is_array($mapping)) {
            return null;
        }

        return self::normalize_legacy_value((string) ($mapping['alt'] ?? ''), false);
    }

    /**
     * @return array<int, string>
     */
    private static function get_db2_image_url_list(int $post_id): array
    {
        $rows = self::get_db2_image_url_list_rows($post_id);
        if ($rows === []) {
            return [];
        }

        $urls = [];
        foreach ($rows as $position => $row) {
            if (($row['key_index'] ?? -1) !== $position) {
                return [];
            }

            $urls[] = (string) ($row['url'] ?? '');
        }

        return $urls;
    }

    /**
     * @return array<int, string>
     */
    private static function get_db2_image_alt_list(int $post_id): array
    {
        $rows = self::get_db2_image_alt_list_rows($post_id);
        if ($rows === []) {
            return [];
        }

        $alts = [];
        foreach ($rows as $position => $row) {
            if (($row['key_index'] ?? -1) !== $position) {
                return [];
            }

            $alts[] = (string) ($row['alt'] ?? '');
        }

        return $alts;
    }

    /**
     * @param array<int, string> $legacyList
     * @param array<int, string> $db2List
     */
    private static function pipe_lists_match(array $legacyList, array $db2List): bool
    {
        if ($legacyList === [] || $db2List === []) {
            return false;
        }

        if (count($legacyList) !== count($db2List)) {
            return false;
        }

        foreach ($legacyList as $index => $legacyValue) {
            if (!array_key_exists($index, $db2List) || $legacyValue !== $db2List[$index]) {
                return false;
            }
        }

        return true;
    }

    /**
     * @param string $value
     * @param bool   $is_url
     * @return string|null
     */
    private static function normalize_legacy_value(string $value, bool $is_url): ?string
    {
        $value = trim($value);
        if ($value === '') {
            return null;
        }

        if ($is_url && function_exists('fifu_convert')) {
            $value = trim((string) fifu_convert($value));
        }

        return $value === '' ? null : $value;
    }

    /**
     * @param string $value
     * @param bool   $is_url
     * @return array<int, string>
     */
    private static function parse_legacy_pipe_list(string $value, bool $is_url): array
    {
        $value = trim($value);
        if ($value === '') {
            return [];
        }

        $entries = array_values(
            array_filter(
                array_map('trim', explode('|', rtrim($value, '|'))),
                static fn(string $entry): bool => $entry !== ''
            )
        );

        if ($entries === []) {
            return [];
        }

        $normalized = [];
        foreach ($entries as $entry) {
            $normalizedEntry = self::normalize_legacy_value($entry, $is_url);
            if ($normalizedEntry === null) {
                return [];
            }

            $normalized[] = $normalizedEntry;
        }

        return $normalized;
    }

    private static function delete_legacy_postmeta_raw(int $post_id, string $meta_key): void
    {
        delete_post_meta($post_id, $meta_key);
    }

    private static function get_db2_manager(): ?Fifu_Db2_Manager
    {
        if (!function_exists('fifu_db2_manager')) {
            return null;
        }

        $manager = fifu_db2_manager();
        return $manager instanceof Fifu_Db2_Manager ? $manager : null;
    }
}
