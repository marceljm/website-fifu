<?php

if (!defined('ABSPATH')) {
    exit;
}

class Fifu_Slider_Meta_Service {

    public static function is_invalid_non_empty_slider_payload(array $request, ?array $payload = null): bool
    {
        $payload = $payload ?? self::extract_valid_slider_urls_and_alts($request);

        if (empty($payload['has_payload'])) {
            return false;
        }

        $listIds = trim((string) ($request['inputHiddenSliderListIds'] ?? ''));

        return $listIds !== '' && empty($payload['urls']);
    }

    public static function save_slider_properties( int $post_id, array $request ): bool {
        if ( empty( $request ) ) {
            return false;
        }

        $payload = self::extract_valid_slider_urls_and_alts( $request );
        if ( self::is_invalid_non_empty_slider_payload( $request, $payload ) ) {
            return false;
        }

        $ratio = $request['fifu_slider_input_ratio'] ?? '';
        fifu_update_or_delete_value( $post_id, 'fifu_slider_ratio', $ratio );

        if ( isset( $request['inputHiddenSliderLength'] ) ) {
            $length = (int) $request['inputHiddenSliderLength'];
            for ( $i = 0; $i < $length; $i++ ) {
                fifu_delete_post_meta( $post_id, 'fifu_slider_image_url_' . $i );
                fifu_delete_post_meta( $post_id, 'fifu_slider_image_alt_' . $i );
            }
        }

        if ( ! $payload['has_payload'] ) {
            return false;
        }

        if ( ! $payload['urls'] ) {
            if ( self::is_explicit_slider_clear_payload( $request ) ) {
                self::clear_slider_state_only( $post_id );
            }
            return false;
        }

        self::clear_slider_state_only( $post_id );

        $i = 0;
        foreach ( $payload['urls'] as $index => $url ) {
            fifu_update_or_delete( $post_id, 'fifu_slider_image_url_' . $i, $url );
            fifu_update_or_delete_value( $post_id, 'fifu_slider_image_alt_' . $i, $payload['alts'][ $index ] ?? '' );
            $i++;
        }

        fifu_update_or_delete_value( $post_id, 'fifu_slider_ratio', $ratio );

        if ( function_exists( 'fifu_db2_manager' ) ) {
            $manager = fifu_db2_manager();
            if ( $manager instanceof Fifu_Db2_Manager && method_exists( $manager, 'getPostMapping' ) ) {
                $confirmed = $manager->getPostMapping( $post_id, 'slider', 0 );
                if (
                    empty( $request['fifu_quick_edit_preserve_inactive_media'] )
                    && is_array( $confirmed )
                    && ! empty( $confirmed['url'] )
                ) {
                    self::clear_conflicting_featured_media_after_slider(
                        $post_id,
                        self::request_has_explicit_video_payload( $request )
                    );
                }
            }
        }

        return true;
    }

    private static function is_explicit_slider_clear_payload( array $request ): bool {
        if ( array_key_exists( 'inputHiddenSliderListIds', $request ) ) {
            $list_ids = trim( (string) $request['inputHiddenSliderListIds'] );
            if ( '' === $list_ids ) {
                return true;
            }
        }

        if ( array_key_exists( 'inputHiddenSliderLength', $request ) ) {
            return 0 === (int) $request['inputHiddenSliderLength']
                && ! array_key_exists( 'inputHiddenSliderListIds', $request );
        }

        return false;
    }

    public static function clear_slider_state_only( int $post_id ): void {
        if ( function_exists( 'fifu_db2_write_service' ) ) {
            $write_service = fifu_db2_write_service();
            if ( $write_service instanceof Fifu_Db2_Write_Service ) {
                $write_service->delete_post_slider( $post_id, null );
                $write_service->delete_post_slider_alt( $post_id, null );
            }
        }

        self::delete_slider_post_meta_direct( $post_id, 'fifu_slider_list_url' );
        self::delete_slider_post_meta_direct( $post_id, 'fifu_slider_list_alt' );
        self::delete_slider_post_meta_direct( $post_id, 'fifu_slider_ratio' );

        if ( ! function_exists( 'get_post_meta' ) ) {
            self::clear_slider_post_meta_cache( $post_id );
            return;
        }

        $meta = get_post_meta( $post_id );
        if ( ! is_array( $meta ) ) {
            self::clear_slider_post_meta_cache( $post_id );
            return;
        }

        foreach ( array_keys( $meta ) as $meta_key ) {
            if (
                strpos( $meta_key, 'fifu_slider_image_url_' ) === 0
                || strpos( $meta_key, 'fifu_slider_image_alt_' ) === 0
            ) {
                self::delete_slider_post_meta_direct( $post_id, (string) $meta_key );
            }
        }

        self::clear_slider_post_meta_cache( $post_id );
    }

    private static function delete_slider_post_meta_direct( int $post_id, string $meta_key ): void {
        if ( function_exists( 'delete_post_meta' ) ) {
            delete_post_meta( $post_id, $meta_key );
            return;
        }

        if ( function_exists( 'fifu_delete_post_meta' ) ) {
            fifu_delete_post_meta( $post_id, $meta_key );
        }
    }

    private static function clear_slider_post_meta_cache( int $post_id ): void {
        if ( function_exists( 'clean_post_cache' ) ) {
            clean_post_cache( $post_id );
        }

        if ( function_exists( 'wp_cache_delete' ) ) {
            wp_cache_delete( $post_id, 'post_meta' );
        }
    }

    private static function clear_conflicting_featured_media_after_slider( int $post_id, bool $clear_video_conflicts ): void {
        if ( function_exists( 'fifu_db2_manager' ) ) {
            $manager = fifu_db2_manager();
            if ( $manager instanceof Fifu_Db2_Manager ) {
                if ( method_exists( $manager, 'deletePostMappings' ) ) {
                    $manager->deletePostMappings( $post_id, 'image' );
                }
                if ( method_exists( $manager, 'deletePostAltMappings' ) ) {
                    $manager->deletePostAltMappings( $post_id, 'image' );
                }

                if ( $clear_video_conflicts ) {
                    if ( method_exists( $manager, 'deletePostMappings' ) ) {
                        $manager->deletePostMappings( $post_id, 'video' );
                        $manager->deletePostMappings( $post_id, 'custom_video' );
                    }
                    if ( method_exists( $manager, 'deletePostAltMappings' ) ) {
                        $manager->deletePostAltMappings( $post_id, 'video' );
                        $manager->deletePostAltMappings( $post_id, 'custom_video' );
                    }
                }
            }
        }

        $keys = array( 'fifu_image_url', 'fifu_image_alt', 'fifu_list_url', 'fifu_list_alt' );
        if ( $clear_video_conflicts ) {
            $keys = array_merge( $keys, array( 'fifu_video_url', 'fifu_custom_video_url', 'fifu_list_video_url' ) );
        }

        foreach ( $keys as $key ) {
            fifu_delete_post_meta( $post_id, $key );
        }

        $meta = get_post_meta( $post_id );
        if ( is_array( $meta ) ) {
            foreach ( array_keys( $meta ) as $meta_key ) {
                if (
                    strpos( $meta_key, 'fifu_image_url_' ) === 0
                    || strpos( $meta_key, 'fifu_image_alt_' ) === 0
                    || strpos( $meta_key, 'fifu_video_url_' ) === 0
                ) {
                    fifu_delete_post_meta( $post_id, $meta_key );
                }
            }
        }
    }

    private static function extract_valid_slider_urls_and_alts( array $request ): array {
        $result = array(
            'has_payload' => array_key_exists( 'inputHiddenSliderListIds', $request ),
            'urls' => array(),
            'alts' => array(),
        );

        $list = (string) ( $request['inputHiddenSliderListIds'] ?? '' );
        if ( $list === '' ) {
            return $result;
        }

        foreach ( explode( '|', $list ) as $index ) {
            $input_url = 'fifu_slider_input_url_' . $index;
            if ( ! array_key_exists( $input_url, $request ) ) {
                continue;
            }

            $url = self::normalize_slider_url_value( $request[ $input_url ] );
            if ( null === $url ) {
                continue;
            }

            $alt = self::normalize_slider_alt_value( $request[ 'fifu_slider_input_alt_' . $index ] ?? '' );
            $result['urls'][] = $url;
            $result['alts'][] = $alt;
        }

        return $result;
    }

    /**
     * Normalize slider alt text so invalid sentinels are treated as empty.
     *
     * @param mixed $value Alt text candidate.
     * @return string
     */
    private static function normalize_slider_alt_value( $value ): string {
        if ( null === $value ) {
            return '';
        }

        $raw = trim( (string) $value );
        if ( '' === $raw ) {
            return '';
        }

        $normalized = strtolower( $raw );
        if (
            'null' === $normalized
            || 'undefined' === $normalized
            || 'http://null' === $normalized
            || 'https://null' === $normalized
        ) {
            return '';
        }

        return wp_strip_all_tags( (string) $value );
    }

    /**
     * Normalize a slider URL candidate.
     *
     * @param mixed $value URL candidate.
     * @return string|null
     */
    private static function request_has_explicit_video_payload( array $request ): bool {
        return array_key_exists( 'fifu_video_input_url', $request )
            || array_key_exists( 'inputHiddenVideoLength', $request )
            || array_key_exists( 'inputHiddenVideoListIds', $request );
    }

    private static function normalize_slider_url_value( $value ): ?string {
        if ( null === $value || is_array( $value ) || is_object( $value ) ) {
            return null;
        }

        $raw = trim( (string) $value );

        if ( '' === $raw ) {
            return null;
        }

        $normalized = strtolower( $raw );
        if (
            in_array(
                $normalized,
                array( 'null', 'undefined', 'http://null', 'https://null', '[]', '{}', 'array', 'object' ),
                true
            )
        ) {
            return null;
        }

        $is_valid = class_exists( 'Fifu_Db2_Normalizer', false )
            ? Fifu_Db2_Normalizer::is_valid_url( $raw )
            : filter_var( $raw, FILTER_VALIDATE_URL ) !== false;

        if ( ! $is_valid ) {
            return null;
        }

        $url = trim( esc_url_raw( rtrim( $raw ) ) );

        return '' !== $url ? $url : null;
    }
}
