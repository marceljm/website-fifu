<?php

defined( 'ABSPATH' ) || exit;

/**
 * Controls how content interacts with featured media.
 */
class Fifu_Content_Image_Controller {

    /**
     * Appends the featured media to the rendered content.
     *
     * @param string $content Original post content.
     * @return string
     */
    public static function append_featured_image( $content ) {
        if (!is_string($content)) {
            return $content;
        }

        if ( Fifu_Options_Utils::is_off( 'fifu_pcontent_add' ) ) {
            return $content;
        }

        $post_types_string = get_option( 'fifu_pcontent_types' );
        $post_types_array = explode( ',', $post_types_string );
        if ( $post_types_string && ! is_singular( $post_types_array ) ) {
            return $content;
        }

        if ( has_post_thumbnail() ) {
            return '<div style="text-align:center">' . get_the_post_thumbnail() . '</div>' . $content;
        }

        return $content;
    }

    /**
     * Removes duplicate featured media from the post content.
     *
     * @param string $content Original post content.
     * @return string
     */
    public static function remove_duplicate_featured_from_content( $content ) {
        if (!is_string($content)) {
            return $content;
        }

        if ( Fifu_Options_Utils::is_off( 'fifu_pcontent_remove' ) ) {
            return $content;
        }

        $post_types_string = get_option( 'fifu_pcontent_types' );
        $post_types_array = explode( ',', $post_types_string );
        if ( $post_types_string && ! is_singular( $post_types_array ) ) {
            return $content;
        }

        global $post;
        if ( ! isset( $post ) || ! isset( $post->ID ) ) {
            return $content;
        }

        $post_id = $post->ID;
        $att_id = get_post_thumbnail_id( $post_id );
        $att_url = wp_get_attachment_url( $att_id );

        if ( ! empty( $att_url ) ) {
            foreach ( self::get_slider_duplicate_candidate_urls( (int) $post_id, $att_url ) as $slider_duplicate_candidate_url ) {
                $content_without_slider = self::remove_first_slider_fragment_with_image_url( $content, $slider_duplicate_candidate_url );
                if ( $content_without_slider !== $content ) {
                    $content = $content_without_slider;
                    break;
                }
            }

            $pattern = "/<img[^>]+src=['\"]([^'\"]+)['\"][^>]*>/i";
            preg_match_all( $pattern, $content, $matches );

            if ( ! empty( $matches[1] ?? [] ) ) {
                foreach ( $matches[1] as $match ) {
                    if ( self::urls_match( $match, $att_url ) ) {
                        $content = preg_replace( "/<img[^>]+src=['\"]" . preg_quote( $match, '/' ) . "['\"][^>]*>/i", '', $content, 1 );
                        return $content;
                    }
                }
            }

            if ( Fifu_Options_Utils::is_on( 'fifu_video' ) ) {
                $pattern = "/<(iframe|video)[^>]+src=['\"]([^'\"]+)['\"][^>]*>/i";
                preg_match_all( $pattern, $content, $matches );

                if ( ! empty( $matches[2] ?? [] ) ) {
                    foreach ( $matches[2] as $match ) {
                        $content_video_url = html_entity_decode( $match );
                        $video_url = Fifu_Post_Video_Read_Service::get_video_url( (int) get_the_ID() );
                        if ( $video_url ) {
                            $video_id = Fifu_Video_Helper::get_video_id( $video_url );
                            if ( $video_id && strpos( $content_video_url, $video_id ) !== false ) {
                                $content = preg_replace( "/<(iframe|video)[^>]+src=['\"]" . preg_quote( $match, '/' ) . "['\"][^>]*>/i", '', $content, 1 );
                                return $content;
                            }
                        }
                    }
                }
            }

            $custom_video_url = '';
            if ( class_exists( 'Fifu_Post_Custom_Video_Read_Service' ) ) {
                $custom_video_url = trim( (string) Fifu_Post_Custom_Video_Read_Service::get_custom_video_url( (int) $post_id ) );
            }
            if ( $custom_video_url === '' && function_exists( 'get_post_meta' ) ) {
                $custom_video_url = trim( (string) get_post_meta( (int) $post_id, 'fifu_custom_video_url', true ) );
            }

            if ( $custom_video_url !== '' ) {
                $pattern = '/<video\b[^>]*>.*?<\/video>/is';
                preg_match_all( $pattern, $content, $matches );

                if ( ! empty( $matches[0] ?? [] ) ) {
                    foreach ( $matches[0] as $video_html ) {
                        $src = self::get_html_attribute( $video_html, 'src' );
                        if ( ! $src ) {
                            $src = self::first_source_src_from_video_html( $video_html );
                        }

                        $poster = self::get_html_attribute( $video_html, 'poster' );

                        $src_matches = $src && trim( $src ) === $custom_video_url;
                        $poster_matches = $poster && trim( $poster ) === trim( $att_url );

                        if ( $src_matches || $poster_matches ) {
                            return self::remove_first_exact_html_fragment( $content, $video_html );
                        }
                    }
                }
            }
        }

        return $content;
    }

    /**
     * Gets the possible URLs for the featured slider duplicate.
     *
     * @param int $post_id Post ID.
     * @param string|null $att_url Attachment URL.
     * @return array<int, string>
     */
    private static function get_slider_duplicate_candidate_urls( int $post_id, ?string $att_url ): array {
        $candidate_urls = [];

        $add_candidate = static function ( ?string $url ) use ( &$candidate_urls ): void {
            $url = trim( (string) $url );
            if ( $url !== '' && ! in_array( $url, $candidate_urls, true ) ) {
                $candidate_urls[] = $url;
            }
        };

        $add_candidate( $att_url );

        if ( class_exists( 'Fifu_Post_Slider_Image_Url_Read_Service' ) ) {
            $add_candidate( Fifu_Post_Slider_Image_Url_Read_Service::get_slider_image_url( $post_id, 0 ) );
        }

        if ( function_exists( 'get_post_meta' ) ) {
            $add_candidate( get_post_meta( $post_id, 'fifu_slider_image_url_0', true ) );
        }

        return $candidate_urls;
    }

    /**
     * Removes the first slider fragment containing an image with the given URL.
     *
     * @param string $content Content to inspect.
     * @param string $att_url Attachment URL.
     * @return string
     */
    private static function remove_first_slider_fragment_with_image_url( string $content, string $att_url ): string {
        $pattern = '/<div\b[^>]*class\s*=\s*(["\'])(.*?)\1[^>]*>.*?<\/div>/is';

        if ( ! preg_match_all( $pattern, $content, $matches, PREG_SET_ORDER ) ) {
            return $content;
        }

        foreach ( $matches as $match ) {
            $fragment = $match[0];
            $class_attr = $match[2] ?? '';

            if ( ! preg_match( '/\bfifu-slider\b/i', $class_attr ) ) {
                continue;
            }

            if ( self::html_fragment_has_img_src( $fragment, $att_url ) ) {
                return self::remove_first_exact_html_fragment( $content, $fragment );
            }
        }

        return $content;
    }

    /**
     * Checks whether a fragment contains an image whose src matches the attachment URL.
     *
     * @param string $fragment HTML fragment.
     * @param string $att_url Attachment URL.
     * @return bool
     */
    private static function html_fragment_has_img_src( string $fragment, string $att_url ): bool {
        $pattern = '/<img\b[^>]*\bsrc\s*=\s*(["\'])(.*?)\1[^>]*>/i';

        if ( ! preg_match_all( $pattern, $fragment, $matches ) ) {
            return false;
        }

        foreach ( $matches[2] as $src ) {
            if ( self::urls_match( $src, $att_url ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Removes legacy source tags that may conflict with remote images.
     *
     * @param string $content Content to sanitize.
     * @return string
     */
    private static function remove_source_tags( string $content ): string {
        $pattern = '/<source\b[^>]*>(.*?)<\/source>|<source\b[^>]*\/?>/i';
        $cleaned_content = preg_replace( $pattern, '', $content );
        return $cleaned_content === null ? $content : $cleaned_content;
    }

    /**
     * Gets an HTML attribute value from a tag fragment.
     *
     * @param string $html HTML fragment.
     * @param string $attribute Attribute name.
     * @return string|null
     */
    private static function get_html_attribute( string $html, string $attribute ): ?string {
        $pattern = '/\b' . preg_quote( $attribute, '/' ) . '\s*=\s*(["\'])(.*?)\1/i';
        if ( ! preg_match( $pattern, $html, $matches ) ) {
            return null;
        }

        return html_entity_decode( $matches[2], ENT_QUOTES | ENT_HTML5 );
    }

    /**
     * Gets the first source src attribute from a video fragment.
     *
     * @param string $video_html Video HTML fragment.
     * @return string|null
     */
    private static function first_source_src_from_video_html( string $video_html ): ?string {
        $pattern = '/<source\b[^>]*\bsrc\s*=\s*(["\'])(.*?)\1[^>]*>/i';
        if ( ! preg_match( $pattern, $video_html, $matches ) ) {
            return null;
        }

        return html_entity_decode( $matches[2], ENT_QUOTES | ENT_HTML5 );
    }

    /**
     * Removes the first exact occurrence of a fragment from content.
     *
     * @param string $content Content to update.
     * @param string $fragment Fragment to remove.
     * @return string
     */
    private static function remove_first_exact_html_fragment( string $content, string $fragment ): string {
        $position = strpos( $content, $fragment );
        if ( $position === false ) {
            return $content;
        }

        return substr_replace( $content, '', $position, strlen( $fragment ) );
    }

    /**
     * Compares URLs after trimming and HTML entity decoding.
     *
     * @param string|null $left Left URL.
     * @param string|null $right Right URL.
     * @return bool
     */
    private static function urls_match( ?string $left, ?string $right ): bool {
        $left = trim( html_entity_decode( (string) $left, ENT_QUOTES | ENT_HTML5 ) );
        $right = trim( html_entity_decode( (string) $right, ENT_QUOTES | ENT_HTML5 ) );

        return $left !== '' && $right !== '' && $left === $right;
    }
}
