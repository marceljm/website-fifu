<?php
declare(strict_types=1);

defined('ABSPATH') || exit;

if (!class_exists('Fifu_Post_Slider_List_Url_Read_Service', false)) {
    require_once __DIR__ . '/class-fifu-post-slider-list-url-read-service.php';
}
if (!class_exists('Fifu_Attachment_Update_Service', false)) {
    require_once __DIR__ . '/class-fifu-attachment-update-service.php';
}
if (!class_exists('Fifu_Attachment_Factory', false)) {
    require_once __DIR__ . '/class-fifu-attachment-factory.php';
}
/**
 * Service to keep FIFU fake attachments in sync with WordPress posts.
 */
class Fifu_Post_Attachment_Sync_Service
{
    private static ?Fifu_Local_Media_Cleanup $cleanup = null;

    private static function debug_auto_category(string $message, array $context = []): void
    {
        if (!function_exists('get_option') || !get_option('fifu_debug_auto_category')) {
            return;
        }

        if (function_exists('wp_json_encode')) {
            error_log('[FIFU Auto Category Sync] ' . $message . ' ' . wp_json_encode($context));
            return;
        }

        error_log('[FIFU Auto Category Sync] ' . $message . ' ' . json_encode($context));
    }

    private static function persist_attachment_meta(int $attachment_id, string $url, ?string $alt = null): void
    {
        if ($attachment_id <= 0) {
            return;
        }

        $url = trim(htmlspecialchars_decode($url));
        if ($url === '') {
            return;
        }

        update_post_meta($attachment_id, '_wp_attached_file', $url);

        $alt = $alt === null ? '' : trim((string) $alt);
        if ($alt !== '') {
            update_post_meta($attachment_id, '_wp_attachment_image_alt', $alt);
        } else {
            delete_post_meta($attachment_id, '_wp_attachment_image_alt');
        }
    }

    private static function initialize_post_attachment(int $attachment_id, string $url, ?string $alt): bool
    {
        if (!Fifu_Attachment_Update_Service::can_initialize_remote_attachment($attachment_id, $url)) {
            return false;
        }

        Fifu_Attachment_Update_Service::initialize_remote_attachment($attachment_id, $url, $alt, null, null, true);
        self::persist_attachment_meta($attachment_id, $url, $alt);
        return Fifu_Attachment_Update_Service::has_remote_file_metadata($attachment_id, $url);
    }

    private static function find_or_create_initialized_post_attachment(
        Fifu_Attachment_Repository $attachment_repo,
        int $post_id,
        string $url,
        ?string $alt
    ): ?int {
        $attachment_id = $attachment_repo->find_attachment_id($post_id, $url, false);
        if (!$attachment_id) {
            $attachment_id = $attachment_repo->find_incomplete_attachment_id($post_id, $url, false);
        }
        if (!$attachment_id) {
            $attachment_id = (new Fifu_Attachment_Factory())->create_attachment_for_url($url, $alt, $post_id);
        }

        if (!$attachment_id || !self::initialize_post_attachment((int) $attachment_id, $url, $alt)) {
            return null;
        }

        return (int) $attachment_id;
    }

    private static function is_attachment_shared_with_other_media_owners(
        Fifu_Attachment_Repository $attachment_repo,
        int $attachment_id,
        int $post_id
    ): bool {
        return $attachment_repo->get_media_reference_post_ids($attachment_id, $post_id) !== []
            || $attachment_repo->get_attachment_reference_term_ids($attachment_id) !== [];
    }

    private static function create_initialized_independent_post_attachment(
        Fifu_Attachment_Repository $attachment_repo,
        int $post_id,
        string $url,
        ?string $alt,
        int $excluded_attachment_id
    ): ?int {
        $attachment_id = (new Fifu_Attachment_Factory())->create_attachment_for_url($url, $alt, $post_id);
        if (
            $attachment_id <= 0
            || $attachment_id === $excluded_attachment_id
            || !self::is_attachment_owned_by_post($attachment_id, $post_id)
            || !Fifu_Attachment_Update_Service::is_fifu_owned($attachment_id)
            || self::is_attachment_shared_with_other_media_owners($attachment_repo, $attachment_id, $post_id)
            || !self::initialize_post_attachment($attachment_id, $url, $alt)
        ) {
            return null;
        }

        return $attachment_id;
    }

    private static function delete_fifu_attachment_with_remote_metadata(
        int $attachment_id,
        int $exclude_reference_post_id = 0
    ): void
    {
        $attached_file = trim(htmlspecialchars_decode((string) get_post_meta($attachment_id, '_wp_attached_file', true)));
        $content_filtered = trim(htmlspecialchars_decode((string) get_post_field('post_content_filtered', $attachment_id)));

        if ($attached_file !== '') {
            if (
                !Fifu_Attachment_Update_Service::is_valid_remote_attachment_url($attached_file)
                || ($content_filtered !== '' && !Fifu_Attachment_Update_Service::is_valid_remote_attachment_url($content_filtered))
            ) {
                return;
            }
        } else {
            if (!Fifu_Attachment_Update_Service::is_valid_remote_attachment_url($content_filtered)) {
                return;
            }

            if (!Fifu_Attachment_Update_Service::can_initialize_remote_attachment($attachment_id, $content_filtered)) {
                return;
            }

            Fifu_Attachment_Update_Service::initialize_remote_attachment($attachment_id, $content_filtered);
            if (!Fifu_Attachment_Update_Service::has_remote_file_metadata($attachment_id, $content_filtered)) {
                return;
            }
        }

        if (Fifu_Attachment_Update_Service::is_safe_to_delete_remote_attachment($attachment_id)) {
            (new Fifu_Local_Media_Cleanup())->delete_attachments_and_meta(
                [$attachment_id],
                $exclude_reference_post_id
            );
        }
    }

    private static function delete_if_unreferenced_fifu_attachment(
        Fifu_Attachment_Repository $attachment_repo,
        int $attachment_id
    ): void {
        if (
            $attachment_id > 0
            && Fifu_Attachment_Update_Service::is_fifu_owned($attachment_id)
            && !$attachment_repo->get_referenced_attachment_ids([$attachment_id])
        ) {
            self::delete_fifu_attachment_with_remote_metadata($attachment_id);
        }
    }

    private static function is_attachment_owned_by_post(
        int $attachment_id,
        int $post_id
    ): bool {
        if (
            $attachment_id <= 0
            || $post_id <= 0
        ) {
            return false;
        }

        if (
            (int) get_post_field(
                'post_parent',
                $attachment_id
            ) !== $post_id
        ) {
            return false;
        }

        $post_name =
            (string) get_post_field(
                'post_name',
                $attachment_id
            );

        return strpos(
            $post_name,
            'fifu-category-'
        ) !== 0;
    }

    /**
     * Sync the FIFU "fake" featured attachment for a given post ID.
     *
     * Responsibility: mirror the behavior of admin/db.php::update_fake_attach_id().
     *
     * @param int $post_id
     * @param bool $force Whether to bypass generic post-save suppression for explicit FIFU operations.
     * @return void
     */
    public static function sync_featured_attachment(int $post_id, bool $force = false): void
    {
        if (
            !$force
            && class_exists('Fifu_Wai_Addon_Integration')
            && method_exists('Fifu_Wai_Addon_Integration', 'should_suppress_generic_post_save_media_sync')
            && Fifu_Wai_Addon_Integration::should_suppress_generic_post_save_media_sync($post_id)
        ) {
            return;
        }

        global $wpdb;

        $cleanup = new Fifu_Local_Media_Cleanup();
        $attachment_repo = self::get_attachment_repository();
        $default_attach_id = (int) get_option('fifu_default_attach_id');
        $att_id = (int) get_post_thumbnail_id($post_id);
        if ($att_id > 0 && !get_post($att_id)) {
            delete_post_meta($post_id, '_thumbnail_id');
            $att_id = 0;
        }
        $url = Fifu_Post_Main_Image_Resolver::get_main_image_url($post_id, false);
        $custom_video_url = Fifu_Post_Custom_Video_Read_Service::get_custom_video_url((int) $post_id);

        $has_fifu_attachment = $att_id
            ? ($attachment_repo->is_fifu_attachment($att_id) && $default_attach_id !== $att_id)
            : false;

        if (
            $has_fifu_attachment
            && !self::is_attachment_owned_by_post(
                $att_id,
                $post_id
            )
        ) {
            /*
             * Another post owns this FIFU attachment.
             *
             * Never mutate or delete the foreign attachment.
             * Remove only this post's reference.
             */
            delete_post_thumbnail($post_id);

            $att_id = 0;
            $has_fifu_attachment = false;
        }

        $default_url = (string) Fifu_Options_Utils::get_default_image_url();
        $should_use_default_fallback = !$url || (
            !$force
            && $url === $default_url
            && !$custom_video_url
        );

        if ($should_use_default_fallback) {
            if ($has_fifu_attachment && $att_id) {
                delete_post_thumbnail($post_id);
            } else {
                $attachment_ids = self::normalize_attachment_ids(
                    $attachment_repo->get_orphan_attachments_for_post($post_id)
                );
                if ($attachment_ids) {
                    $cleanup->delete_attachments_and_meta($attachment_ids);
                }
            }
            Fifu_Default_Image_Service::add_default_image_to_post($post_id);
        } else {
            $alt = Fifu_Post_Featured_Attachment_Alt_Resolver::resolve((int) $post_id, $url);
            $current_url = $att_id ? Fifu_Attachment_Update_Service::get_attachment_remote_url((int) $att_id) : '';
            $is_default_attachment = $att_id === $default_attach_id;
            $same_logical_media = self::is_same_logical_featured_media($current_url, $url);

            if ($has_fifu_attachment && $att_id && !$is_default_attachment) {
                if ($same_logical_media) {
                    if (!self::featured_attachment_state_matches((int) $att_id, (string) $url, $alt)) {
                        if (self::is_attachment_shared_with_other_media_owners($attachment_repo, (int) $att_id, $post_id)) {
                            $new_att_id = self::create_initialized_independent_post_attachment(
                                $attachment_repo,
                                $post_id,
                                $url,
                                $alt,
                                (int) $att_id
                            );
                            if ($new_att_id) {
                                update_post_meta($post_id, '_thumbnail_id', $new_att_id);
                            }
                        } elseif (!self::initialize_post_attachment((int) $att_id, $url, $alt)) {
                            delete_post_thumbnail($post_id);
                        }
                    }
                } else {
                    $new_att_id = self::is_attachment_shared_with_other_media_owners($attachment_repo, (int) $att_id, $post_id)
                        ? self::create_initialized_independent_post_attachment(
                            $attachment_repo,
                            $post_id,
                            $url,
                            $alt,
                            (int) $att_id
                        )
                        : self::find_or_create_initialized_post_attachment($attachment_repo, $post_id, $url, $alt);

                    if ($new_att_id) {
                        update_post_meta($post_id, '_thumbnail_id', (int) $new_att_id);
                    }
                }
            } else {
                $new_att_id = self::find_or_create_initialized_post_attachment($attachment_repo, $post_id, $url, $alt);
                if ($new_att_id) {
                    update_post_meta($post_id, '_thumbnail_id', $new_att_id);
                }

                $protected_attachment_ids = [];
                if (!empty($new_att_id)) {
                    $protected_attachment_ids[] = (int) $new_att_id;
                }

                $current_thumbnail_id = (int) get_post_meta($post_id, '_thumbnail_id', true);
                if ($current_thumbnail_id > 0) {
                    $protected_attachment_ids[] = $current_thumbnail_id;
                }

                $protected_attachment_ids = array_values(array_unique(array_filter(
                    array_map('intval', $protected_attachment_ids),
                    static fn(int $attachment_id): bool => $attachment_id > 0
                )));

                $attachment_ids = $new_att_id
                    ? self::normalize_attachment_ids($attachment_repo->get_orphan_attachments_for_post($post_id))
                    : [];

                if ($protected_attachment_ids) {
                    $attachment_ids = array_values(array_filter(
                        $attachment_ids,
                        static fn(int $attachment_id): bool => !in_array($attachment_id, $protected_attachment_ids, true)
                    ));
                }

                if ($attachment_ids) {
                    $cleanup->delete_attachments_and_meta($attachment_ids);
                }
            }
        }

        $current_thumbnail_id = (int) get_post_thumbnail_id($post_id);
        if (
            $att_id > 0
            && $att_id !== $default_attach_id
            && $current_thumbnail_id !== $att_id
            && $attachment_repo->is_fifu_attachment($att_id)
            && self::is_attachment_owned_by_post($att_id, $post_id)
        ) {
            self::delete_if_unreferenced_fifu_attachment($attachment_repo, $att_id);
        }

        $active_attachment_id = (int) get_post_thumbnail_id($post_id);
        $incomplete_orphans = self::normalize_attachment_ids(
            $attachment_repo->get_incomplete_orphan_attachments_for_post(
                $post_id,
                array_values(array_filter([$active_attachment_id, $default_attach_id]))
            )
        );
        foreach ($incomplete_orphans as $incomplete_attachment_id) {
            $attached_file = trim(htmlspecialchars_decode((string) get_post_meta($incomplete_attachment_id, '_wp_attached_file', true)));
            $recovery_url = trim(htmlspecialchars_decode((string) get_post_field('post_content_filtered', $incomplete_attachment_id)));
            if (
                $attached_file === ''
                && Fifu_Attachment_Update_Service::is_valid_remote_attachment_url($recovery_url)
            ) {
                $alt = (string) get_post_meta($incomplete_attachment_id, '_wp_attachment_image_alt', true);
                if (self::initialize_post_attachment($incomplete_attachment_id, $recovery_url, $alt)) {
                    $cleanup->delete_attachments_and_meta([$incomplete_attachment_id]);
                }
                continue;
            }

            if ($attached_file === '' && $recovery_url === '') {
                continue;
            }
        }
        if ($incomplete_orphans) {
            $cleanup->delete_blank_virtual_attachments($incomplete_orphans);
        }

        if (!Fifu_Speedup_Url_Service::is_speedup_url($url) && get_post_meta($post_id, 'bkp_thumbnail_id', true)) {
            delete_post_meta($post_id, 'bkp_thumbnail_id');
        }
    }

    private static function normalize_attachment_url(?string $value): ?string
    {
        if ($value === null) {
            return null;
        }

        $normalized = trim(htmlspecialchars_decode($value));
        return $normalized === '' ? null : $normalized;
    }

    private static function is_same_logical_featured_media(?string $current_url, ?string $new_url): bool
    {
        $current_url = self::normalize_attachment_url($current_url);
        $new_url = self::normalize_attachment_url($new_url);

        if ($current_url === null || $new_url === null) {
            return false;
        }

        if ($current_url === $new_url) {
            return true;
        }

        return Fifu_Attachment_Update_Service::is_youtube_thumbnail_quality_fallback($current_url, $new_url);
    }

    private static function featured_attachment_state_matches(int $attachmentId, string $url, ?string $alt): bool
    {
        if (!Fifu_Attachment_Update_Service::has_remote_file_metadata($attachmentId, $url)) {
            return false;
        }

        $currentUrl = self::normalize_attachment_url(Fifu_Attachment_Update_Service::get_attachment_remote_url($attachmentId));
        $desiredUrl = self::normalize_attachment_url($url);
        $currentAlt = trim((string) get_post_meta($attachmentId, '_wp_attachment_image_alt', true));
        $altMatches = $currentAlt === trim((string) $alt);
        $titleMatches = $alt === null
            || (string) get_post_field('post_title', $attachmentId) === trim($alt);
        $excerptMatches = $alt === null
            || (string) get_post_field('post_excerpt', $attachmentId) === trim($alt);

        return $currentUrl !== null
            && $currentUrl === $desiredUrl
            && $altMatches
            && $titleMatches
            && $excerptMatches;
    }

    /**
     * Sync the FIFU "fake" gallery attachments for a given post ID.
     *
     * Responsibility: mirror legacy gallery attachment syncing behavior.
     *
     * @param int  $post_id Post ID.
     * @param bool $force Whether to bypass generic post-save suppression for an explicit FIFU operation.
     * @return void
     */
    public static function sync_gallery_attachments(int $post_id, bool $force = false): void
    {
        if (
            ! $force
            &&
            class_exists('Fifu_Wai_Addon_Integration')
            && method_exists('Fifu_Wai_Addon_Integration', 'should_suppress_generic_post_save_media_sync')
            && Fifu_Wai_Addon_Integration::should_suppress_generic_post_save_media_sync($post_id)
        ) {
            return;
        }

        $current_gallery_csv = (string) get_post_meta($post_id, '_product_image_gallery', true);
        $tmp_gallery_csv = (string) get_post_meta($post_id, 'fifu_tmp_product_image_gallery', true);
        delete_post_meta($post_id, 'fifu_tmp_product_image_gallery');

        if (self::should_skip_empty_gallery_attachment_sync_for_insert($post_id, $current_gallery_csv, $tmp_gallery_csv)) {
            return;
        }

        $cleanup = new Fifu_Local_Media_Cleanup();
        $attachment_repo = self::get_attachment_repository();
        $gallery_repo = self::get_product_gallery_repository();

        $video_enabled = Fifu_Options_Utils::is_on('fifu_video');
        clean_post_cache($post_id);

        $current_attachment_ids = self::normalize_attachment_ids($current_gallery_csv);
        $tmp_attachment_ids = self::normalize_attachment_ids($tmp_gallery_csv);
        $attachment_ids = array_values(array_unique(array_merge($current_attachment_ids, $tmp_attachment_ids)));

        $attachment_type_map = [];
        $fifu_attachment_ids = [];
        if ($attachment_ids) {
            foreach ($attachment_ids as $attachment_id) {
                $is_fifu_attachment = $attachment_repo->is_fifu_attachment($attachment_id);
                $attachment_type_map[$attachment_id] = $is_fifu_attachment;

                if (
                    $is_fifu_attachment
                    && self::is_attachment_owned_by_post(
                        $attachment_id,
                        $post_id
                    )
                ) {
                    $fifu_attachment_ids[] = $attachment_id;
                }
            }
        }

        $current_native_attachment_ids = array_values(array_filter(
            $current_attachment_ids,
            static fn(int $attachment_id): bool =>
                $attachment_id > 0
                && get_post($attachment_id)
                && !($attachment_type_map[$attachment_id] ?? false)
        ));
        $tmp_native_attachment_ids = array_values(array_filter(
            $tmp_attachment_ids,
            static fn(int $attachment_id): bool => !($attachment_type_map[$attachment_id] ?? false)
        ));

        $urls = $gallery_repo->get_gallery_urls($post_id);
        $urls = self::deduplicate_gallery_rows_by_url($urls);
        $featured_attachment_id = (int) get_post_thumbnail_id($post_id);
        $featured_attachment_url = '';
        $has_featured_image_state = trim((string) Fifu_Post_Image_Url_Read_Service::get_image_url($post_id)) !== '';
        if (!$has_featured_image_state && $featured_attachment_id > 0 && class_exists('Fifu_Post_Meta_Utils', false) && method_exists('Fifu_Post_Meta_Utils', 'is_remote_image')) {
            $has_featured_image_state = !Fifu_Post_Meta_Utils::is_remote_image($featured_attachment_id);
        }
        if ($featured_attachment_id > 0) {
            $featured_attachment_url = trim((string) get_post_meta($featured_attachment_id, '_wp_attached_file', true));
            if ($featured_attachment_url === '') {
                $featured_attachment_url = trim((string) get_post_field('post_content_filtered', $featured_attachment_id));
            }
            $featured_attachment_url = htmlspecialchars_decode($featured_attachment_url);
        }
        $current_main_url = (string) Fifu_Post_Main_Image_Resolver::get_main_image_url($post_id, false);
        $alt_by_index = [];
        $alt_by_url = [];
        foreach ($gallery_repo->get_gallery_alts($post_id) as $alt_row) {
            if (isset($alt_row->index)) {
                $alt_by_index[(int) $alt_row->index] = (string) ($alt_row->alt ?? $alt_row->meta_value ?? '');
            }

            $alt_key = (string) ($alt_row->meta_key ?? '');
            if ($alt_key !== '') {
                $alt_by_url[$alt_key] = (string) ($alt_row->meta_value ?? '');
            }
        }

        $logical_list_alts = [];
        if (class_exists('Fifu_Post_Image_List_Alt_Read_Service', false)) {
            $logical_list_alts = self::normalize_list_values(
                (string) Fifu_Post_Image_List_Alt_Read_Service::get_image_list_alt($post_id)
            );
        }

        $slider_logical_list_alts = [];
        if (class_exists('Fifu_Post_Slider_List_Alt_Read_Service', false)) {
            $slider_logical_list_alts = self::normalize_list_values(
                (string) Fifu_Post_Slider_List_Alt_Read_Service::get_slider_list_alt($post_id)
            );
        }

        if (empty($urls)) {
            $native_attachment_ids = $current_gallery_csv !== ''
                ? $current_native_attachment_ids
                : $tmp_native_attachment_ids;

            $native_attachment_ids = array_values(array_filter(
                $native_attachment_ids,
                static fn(int $attachment_id): bool => $attachment_id > 0 && get_post($attachment_id) && !$attachment_repo->is_fifu_attachment($attachment_id)
            ));

            self::persist_gallery_meta($post_id, $native_attachment_ids);
            if ($fifu_attachment_ids) {
                self::delete_fifu_attachment_ids($cleanup, $fifu_attachment_ids, $post_id);
            }
            delete_post_meta($post_id, 'bkp_product_image_gallery');
            return;
        }

        $current_fifu_rows = $attachment_repo->get_attachment_rows_by_ids($fifu_attachment_ids);
        $available_fifu_attachments = [];
        foreach ($current_fifu_rows as $row) {
            $existing_id = (int) ($row['id'] ?? 0);
            if ($existing_id <= 0) {
                continue;
            }

            $existing_url = (string) ($row['attached_file'] ?? '');
            if ($existing_url === '') {
                $existing_url = (string) ($row['post_content_filtered'] ?? '');
            }

            if ($existing_url === '') {
                continue;
            }

            if (!isset($available_fifu_attachments[$existing_url])) {
                $available_fifu_attachments[$existing_url] = [];
            }

            $available_fifu_attachments[$existing_url][] = [
                'id' => $existing_id,
                'attached_file' => $existing_url,
                'post_title' => (string) ($row['post_title'] ?? ''),
                'post_excerpt' => (string) ($row['post_excerpt'] ?? ''),
                'post_content_filtered' => (string) ($row['post_content_filtered'] ?? ''),
                'attachment_alt' => array_key_exists('attachment_alt', $row) ? (string) $row['attachment_alt'] : null,
            ];
        }

        $new_attachment_ids = [];
        $has_fifu_cloud_url = false;
        $factory = new Fifu_Attachment_Factory();
        $reused_attachment_ids = [];
        $preserved_attachment_ids = [];
        $created_count = 0;
        $reused_count = 0;
        $skipped_count = 0;

        foreach ($urls as $index => $meta) {
            $field_url = (string) ($meta->meta_key ?? '');
            $url = (string) ($meta->url ?? $meta->meta_value ?? '');
            $scope = (string) ($meta->scope ?? '');
            $type = (string) ($meta->type ?? $scope);
            $row_index = self::resolve_gallery_row_index($meta, (int) $index);
            $is_slider_row = strpos($field_url, 'fifu_slider_image_url_') === 0;
            if ($featured_attachment_url !== '' && $type === 'video' && class_exists('Fifu_Video_Helper', false)) {
                $video_thumb = (string) (Fifu_Video_Helper::get_thumbnail_large($url) ?? '');
                if ($video_thumb !== '' && $video_thumb === $featured_attachment_url) {
                    $skipped_count++;
                    continue;
                }
            }

            if ($is_slider_row && $row_index === 0) {
                $skipped_count++;
                continue;
            }

            $logical_index = isset($meta->index) ? $row_index : $row_index + 1;
            $alt = self::resolve_gallery_attachment_alt(
                $meta,
                $index,
                $is_slider_row ? $slider_logical_list_alts : $logical_list_alts,
                $alt_by_index,
                $alt_by_url
            );
            $is_video_field = $type === 'video' || self::is_gallery_video_meta_key((string) $field_url);
            $is_image_like_field = $type === 'image' || self::is_gallery_image_like_meta_key((string) $field_url);
            $has_explicit_video_marker = self::has_explicit_video_marker($url);

            if ($video_enabled && ($is_video_field || $has_explicit_video_marker)) {
                $video_url = $url;
                if ($has_explicit_video_marker) {
                    $parts = explode('#', $url, 2);
                    if (isset($parts[1]) && strpos($parts[1], 'http') === 0) {
                        $video_url = $parts[1];
                    }
                }

                $resolved_video_thumb = (string) (Fifu_Video_Helper::get_thumbnail_large($video_url) ?? '');
                if ($resolved_video_thumb === '') {
                    $skipped_count++;
                    continue;
                }

                $url = $resolved_video_thumb;
            } elseif ($is_video_field && Fifu_Video_Helper::is_video($url)) {
                $resolved_video_thumb = (string) (Fifu_Video_Helper::get_thumbnail_large($url) ?? '');
                if ($resolved_video_thumb === '') {
                    $skipped_count++;
                    continue;
                }
                $url = $resolved_video_thumb;
            }

            if ($is_image_like_field && !$has_explicit_video_marker && fifu_is_google_drive_file_php($url)) {
                $converted_url = fifu_convert($url);
                if ($converted_url !== '') {
                    $url = $converted_url;
                    $preserve_legacy_gallery_meta = array_key_exists('fifu_preserve_legacy_gallery_meta_until_sync', $_REQUEST);
                    $previous_preserve_legacy_gallery_meta = $_REQUEST['fifu_preserve_legacy_gallery_meta_until_sync'] ?? null;
                    $_REQUEST['fifu_preserve_legacy_gallery_meta_until_sync'] = true;
                    try {
                        fifu_update_or_delete($post_id, $field_url, $url);
                    } finally {
                        if ($preserve_legacy_gallery_meta) {
                            $_REQUEST['fifu_preserve_legacy_gallery_meta_until_sync'] = $previous_preserve_legacy_gallery_meta;
                        } else {
                            unset($_REQUEST['fifu_preserve_legacy_gallery_meta_until_sync']);
                        }
                    }
                }
            }

            if (Fifu_Speedup_Url_Service::is_speedup_url($url)) {
                $has_fifu_cloud_url = true;
            }

            $att_id = 0;
            if (!empty($available_fifu_attachments[$url])) {
                $current_attachment = array_shift($available_fifu_attachments[$url]);
                $att_id = (int) ($current_attachment['id'] ?? 0);
            }

            if ($att_id > 0 && !self::gallery_attachment_state_matches($current_attachment, $url, $alt)) {
                if (!self::initialize_gallery_attachment($att_id, $post_id, $url, $alt)) {
                    $preserved_attachment_ids[$att_id] = true;
                    $att_id = 0;
                }
            }

            if ($att_id <= 0) {
                $att_id = self::find_or_create_initialized_gallery_attachment(
                    $attachment_repo,
                    $factory,
                    $post_id,
                    $url,
                    $alt
                ) ?? 0;
                if ($att_id > 0) {
                    $created_count++;
                }
            } else {
                $reused_attachment_ids[$att_id] = true;
                $reused_count++;
            }

            if ($att_id) {
                $new_attachment_ids[] = (int) $att_id;
            }
        }

        self::persist_gallery_meta(
            $post_id,
            array_merge(
                $current_native_attachment_ids,
                $new_attachment_ids
            )
        );
        $protected_attachment_ids = [];
        if ($featured_attachment_id > 0) {
            $protected_attachment_ids[$featured_attachment_id] = true;
        }

        $current_thumbnail_id = (int) get_post_meta($post_id, '_thumbnail_id', true);
        if ($current_thumbnail_id > 0) {
            $protected_attachment_ids[$current_thumbnail_id] = true;
        }

        $attachment_ids_to_delete = array_values(array_filter(
            $fifu_attachment_ids,
            static fn(int $attachment_id): bool =>
                !isset($reused_attachment_ids[$attachment_id])
                && !isset($preserved_attachment_ids[$attachment_id])
                && !isset($protected_attachment_ids[$attachment_id])
        ));
        if ($attachment_ids_to_delete) {
            self::delete_fifu_attachment_ids($cleanup, $attachment_ids_to_delete, $post_id);
        }

        if (!$has_fifu_cloud_url) {
            delete_post_meta($post_id, 'bkp_product_image_gallery');
        }
    }

    public static function sync_product_gallery_attachments_from_db2_image_list(int $post_id): void
    {
        if ($post_id <= 0 || !function_exists('fifu_db2_manager')) {
            return;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getPostMappings')) {
            return;
        }

        $mappings = $manager->getPostMappings($post_id, 'image');
        if (!is_array($mappings) || $mappings === []) {
            return;
        }

        $alt_mappings = method_exists($manager, 'getPostAltMappings')
            ? $manager->getPostAltMappings($post_id, 'image')
            : [];
        $alts_by_index = [];
        foreach ((array) $alt_mappings as $alt_mapping) {
            if (is_array($alt_mapping) && isset($alt_mapping['key_index'])) {
                $alts_by_index[(int) $alt_mapping['key_index']] = (string) ($alt_mapping['alt'] ?? '');
            }
        }

        $attachmentRepo = self::get_attachment_repository();
        $attachmentFactory = new Fifu_Attachment_Factory();
        $attachmentIds = [];

        foreach ($mappings as $mapping) {
            if (!is_array($mapping)) {
                continue;
            }

            $index = (int) ($mapping['key_index'] ?? -1);
            $url = trim((string) ($mapping['url'] ?? ''));
            if ($index < 0 || $url === '' || isset($attachmentIds[$index])) {
                return;
            }

            $alt = trim((string) ($mapping['alt'] ?? $alts_by_index[$index] ?? ''));
            $attachmentId = self::find_or_create_initialized_gallery_attachment(
                $attachmentRepo,
                $attachmentFactory,
                $post_id,
                $url,
                $alt
            );
            if ($attachmentId === null) {
                return;
            }
            $attachmentIds[$index] = $attachmentId;
        }

        if ($attachmentIds === [] || !array_key_exists(0, $attachmentIds)) {
            return;
        }

        ksort($attachmentIds);
        $attachmentIds = array_values($attachmentIds);

        $thumbnailId = (int) ($attachmentIds[0] ?? 0);
        if ($thumbnailId <= 0) {
            return;
        }

        update_post_meta($post_id, '_thumbnail_id', $thumbnailId);

        $galleryIds = array_values(array_filter(
            array_slice($attachmentIds, 1),
            static fn(int $attachmentId): bool => $attachmentId > 0 && $attachmentId !== $thumbnailId
        ));

        if ($galleryIds === []) {
            delete_post_meta($post_id, '_product_image_gallery');
        } else {
            self::persist_clean_product_gallery_meta($post_id, $galleryIds);
        }

        clean_post_cache($post_id);
        wp_cache_delete($post_id, 'post_meta');
    }

    public static function sanitize_product_image_gallery_meta($value, $meta_key = '', $object_type = '', $object_subtype = '')
    {
        if (is_array($value)) {
            $parts = $value;
        } elseif ($value === null || is_scalar($value)) {
            $parts = explode(',', (string) ($value ?? ''));
        } else {
            return '';
        }

        $ids = [];

        foreach ($parts as $part) {
            if ($part !== null && !is_scalar($part)) {
                continue;
            }

            $id = (int) trim((string) ($part ?? ''));
            if ($id <= 0) {
                continue;
            }

            $ids[] = $id;
        }

        $ids = array_values(array_unique($ids));

        return implode(',', $ids);
    }

    public static function delete_empty_product_image_gallery_meta($meta_id, $object_id, $meta_key, $meta_value): void
    {
        if (!is_string($meta_key) || $meta_key !== '_product_image_gallery') {
            return;
        }

        if ($meta_value !== null && !is_scalar($meta_value)) {
            return;
        }

        if ((string) ($meta_value ?? '') !== '') {
            return;
        }

        $meta_id = is_numeric($meta_id) ? (int) $meta_id : 0;
        if ($meta_id <= 0) {
            return;
        }

        delete_metadata_by_mid('post', $meta_id);
    }

    private static function should_skip_empty_gallery_attachment_sync_for_insert(
        int $post_id,
        string $current_gallery_csv,
        string $tmp_gallery_csv
    ): bool {
        $post_type = function_exists('get_post_type') ? (string) get_post_type($post_id) : '';
        if (in_array($post_type, ['product', 'product_variation'], true)) {
            return false;
        }

        if ($current_gallery_csv !== '' || $tmp_gallery_csv !== '') {
            return false;
        }

        if (self::has_explicit_gallery_sync_payload_from_request_or_meta($post_id)) {
            return false;
        }

        $skip_flag = $_REQUEST['fifu_skip_empty_gallery_attachment_sync_for_insert'] ?? null;
        if ($skip_flag !== null && $skip_flag !== '' && $skip_flag !== '0') {
            return true;
        }

        return true;
    }

    private static function has_explicit_gallery_sync_payload_from_request_or_meta(int $post_id): bool
    {
        $post_meta = get_post_meta($post_id);
        if (is_array($post_meta)) {
            foreach (array_keys($post_meta) as $meta_key) {
                $meta_key = (string) $meta_key;
                if (
                    preg_match('/^(fifu_image_url_\d+|fifu_image_alt_\d+|fifu_slider_image_url_\d+|fifu_slider_image_alt_\d+)$/', $meta_key) === 1
                    || in_array($meta_key, [
                        'fifu_list_url',
                        'fifu_list_alt',
                        'fifu_list_video_url',
                        'fifu_slider_list_url',
                        'fifu_slider_list_alt',
                    ], true)
                ) {
                    if (trim((string) get_post_meta($post_id, $meta_key, true)) !== '') {
                        return true;
                    }
                }
            }
        }

        foreach ([
            'fifu_wai_image_list_url',
            'fifu_wai_image_list_alt',
            'fifu_wai_gallery_only_image_list_url',
            'fifu_wai_gallery_only_image_list_alt',
            'fifu_wai_gallery_only_video_list_url',
            'fifu_wai_video_list_url',
            'fifu_wai_gallery_only_slider_list_url',
            'fifu_wai_gallery_only_slider_list_alt',
        ] as $request_key) {
            if (trim((string) ($_REQUEST[$request_key] ?? '')) !== '') {
                return true;
            }
        }

        return false;
    }

    /**
     * Remove duplicate gallery rows that resolve to the same URL.
     *
     * @param array<int,object> $rows
     * @return array<int,object>
     */
    private static function deduplicate_gallery_rows_by_url(array $rows): array
    {
        $seen = [];
        $deduped = [];

        foreach ($rows as $row) {
            $url = trim((string) ($row->url ?? $row->meta_value ?? ''));
            if ($url === '' || isset($seen[$url])) {
                continue;
            }

            $seen[$url] = true;
            $deduped[] = $row;
        }

        return $deduped;
    }

    private static function resolve_gallery_attachment_alt(object $meta, int $loop_index, array $logical_list_alts, array $alt_by_index, array $alt_by_url): string
    {
        $logical_index = isset($meta->index) ? (int) $meta->index : ((int) $loop_index + 1);

        // Gallery rows are stored zero-based, but the logical FIFU list keeps the featured image at index 0.
        // Use the logical list position so the first gallery item receives ALT[1], not ALT[0].
        if (isset($logical_list_alts[$logical_index])) {
            return (string) $logical_list_alts[$logical_index];
        }

        if (isset($meta->index) && array_key_exists((int) $meta->index, $alt_by_index)) {
            return (string) $alt_by_index[(int) $meta->index];
        }

        $url_meta_key = (string) ($meta->meta_key ?? '');
        $derived_alt_key = self::resolve_gallery_alt_meta_key($url_meta_key);
        if ($derived_alt_key !== null && array_key_exists($derived_alt_key, $alt_by_url)) {
            return (string) $alt_by_url[$derived_alt_key];
        }

        $logical_alt_key = 'fifu_image_alt_' . $logical_index;
        if (array_key_exists($logical_alt_key, $alt_by_url)) {
            return (string) $alt_by_url[$logical_alt_key];
        }

        if (array_key_exists($url_meta_key, $alt_by_url)) {
            return (string) $alt_by_url[$url_meta_key];
        }

        return '';
    }

    private static function resolve_gallery_alt_meta_key(string $url_meta_key): ?string
    {
        if (preg_match('/^fifu_image_url_(\d+)$/', $url_meta_key, $matches) === 1) {
            return 'fifu_image_alt_' . (int) $matches[1];
        }

        if (preg_match('/^fifu_slider_image_url_(\d+)$/', $url_meta_key, $matches) === 1) {
            $index = (int) $matches[1];
            return $index > 0 ? 'fifu_slider_image_alt_' . $index : null;
        }

        return null;
    }

    private static function resolve_gallery_row_index(object $meta, int $fallback_index): int
    {
        if (isset($meta->index)) {
            return (int) $meta->index;
        }

        $meta_key = (string) ($meta->meta_key ?? '');
        $extracted_index = self::extract_gallery_index_from_meta_key($meta_key);
        if ($extracted_index !== null) {
            return $extracted_index;
        }

        return $fallback_index;
    }

    private static function extract_gallery_index_from_meta_key(string $meta_key): ?int
    {
        if (preg_match('/^(?:fifu_image_url|fifu_video_url|fifu_slider_image_url)_(\d+)$/', $meta_key, $matches) === 1) {
            return (int) $matches[1];
        }

        return null;
    }

    /**
     * @return array<int,string>
     */
    private static function normalize_list_values(string $value): array
    {
        if ($value === '') {
            return [];
        }

        $values = [];
        foreach (explode('|', $value) as $index => $segment) {
            $segment = trim((string) $segment);
            if ($segment === '') {
                continue;
            }

            $values[$index] = $segment;
        }

        return $values;
    }


    /**
     * Sync theme-specific property gallery metadata after FIFU updates.
     *
     * @param int $postId
     * @return void
     */
    public static function sync_theme_property_images(int $postId): void
    {
        $hasSlider = Fifu_Post_Slider_Image_Url_Read_Service::get_slider_image_url(
            (int) $postId,
            0
        );
        if (!$hasSlider) {
            return;
        }

        if (Fifu_Theme_Detector::is_houzez_active()) {
            wp_cache_flush();
            if (class_exists('Fifu_Houzez_Property_Images')) {
                Fifu_Houzez_Property_Images::sync_property_images($postId);
            }
            return;
        }

        if (Fifu_Theme_Detector::is_wpresidence_active()) {
            wp_cache_flush();
            if (class_exists('Fifu_WpResidence_Property_Images')) {
                Fifu_WpResidence_Property_Images::sync_property_gallery($postId);
            }
        }
    }

    /**
     * Handle WordPress "before_delete_post" hook.
     *
     * Responsibility: mirror the behavior of admin/db.php::before_delete_post().
     *
     * @param int $post_id
     * @return void
     */
    public static function handle_post_deleted($post_id): void
    {
        $post_id = is_numeric($post_id) ? (int) $post_id : 0;
        if ($post_id <= 0) {
            return;
        }

        $cleanup = self::get_cleanup();
        $attachment_repo = self::get_attachment_repository();
        $default_att_id = (int) get_option('fifu_default_attach_id');

        $ids_csv = $attachment_repo->get_featured_and_gallery_ids($post_id);
        $ids = array_values(array_unique(array_merge(
            self::normalize_attachment_ids($ids_csv),
            $attachment_repo->get_fifu_child_attachment_ids($post_id)
        )));
        if (!$ids) {
            return;
        }

        foreach ($ids as $attachment_id) {
            if (
                $attachment_id <= 0
                || $attachment_id === $default_att_id
                || !$attachment_repo->is_fifu_attachment($attachment_id)
                || !self::is_attachment_owned_by_post($attachment_id, $post_id)
            ) {
                continue;
            }

            if ($attachment_repo->get_referenced_attachment_ids([$attachment_id], $post_id)) {
                $media_reference_post_ids = $attachment_repo->get_media_reference_post_ids($attachment_id, $post_id);
                $valid_reference_post_ids = [];
                foreach ($media_reference_post_ids as $reference_post_id) {
                    $reference_post = get_post($reference_post_id);
                    if ($reference_post && (int) $reference_post->ID !== $post_id) {
                        $valid_reference_post_ids[] = (int) $reference_post->ID;
                    }
                }

                $replacement_parent_id = $valid_reference_post_ids[0] ?? 0;
                if ($replacement_parent_id <= 0) {
                    // Keep term-only and ambiguous references protected; WordPress
                    // may detach their parent naturally during post deletion.
                    continue;
                }

                global $wpdb;
                $updated_rows = $wpdb->update(
                    $wpdb->posts,
                    ['post_parent' => $replacement_parent_id],
                    ['ID' => $attachment_id, 'post_parent' => $post_id],
                    ['%d'],
                    ['%d', '%d']
                );
                clean_post_cache($attachment_id);

                $read_persisted_parent = static function () use ($wpdb, $attachment_id): int {
                    return (int) $wpdb->get_var(
                        $wpdb->prepare(
                            "SELECT post_parent FROM {$wpdb->posts} WHERE ID = %d",
                            $attachment_id
                        )
                    );
                };

                $persisted_parent_id = $read_persisted_parent();
                $valid_reference_parent_lookup = array_fill_keys($valid_reference_post_ids, true);
                if (
                    $persisted_parent_id === $replacement_parent_id
                    || $persisted_parent_id === 0
                    || isset($valid_reference_parent_lookup[$persisted_parent_id])
                ) {
                    clean_post_cache($attachment_id);
                    continue;
                }

                $recovery_rows = null;
                $replacement_post = get_post($replacement_parent_id);
                if (
                    $persisted_parent_id === $post_id
                    && $replacement_post
                    && (int) $replacement_post->ID !== $post_id
                ) {
                    $recovery_sql = $wpdb->prepare(
                        "UPDATE {$wpdb->posts}
                         SET post_parent = %d
                         WHERE ID = %d
                           AND post_type = %s
                           AND post_author = %d
                           AND post_name NOT LIKE %s
                           AND post_parent = %d",
                        $replacement_parent_id,
                        $attachment_id,
                        'attachment',
                        Fifu_Options_Utils::get_author(),
                        'fifu-category-%',
                        $post_id
                    );
                    $recovery_rows = $wpdb->query($recovery_sql);
                    clean_post_cache($attachment_id);
                    $persisted_parent_id = $read_persisted_parent();
                }

                if (
                    $persisted_parent_id === $replacement_parent_id
                    || $persisted_parent_id === 0
                    || isset($valid_reference_parent_lookup[$persisted_parent_id])
                ) {
                    clean_post_cache($attachment_id);
                    continue;
                }

                $first_result = $updated_rows === false ? 'false' : (string) $updated_rows;
                $recovery_result = $recovery_rows === null
                    ? 'not attempted because the attachment parent changed'
                    : ($recovery_rows === false ? 'false' : (string) $recovery_rows);
                error_log(sprintf(
                    'FIFU: Shared attachment %d remains attached to post %d after reassignment to post %d failed (initial update: %s; guarded recovery: %s; current parent: %d). The attachment was preserved.',
                    $attachment_id,
                    $post_id,
                    $replacement_parent_id,
                    $first_result,
                    $recovery_result,
                    $persisted_parent_id
                ));
                clean_post_cache($attachment_id);
                continue;
            }

            $is_blank_virtual = trim((string) get_post_field('guid', $attachment_id)) === ''
                && trim((string) get_post_field('post_content_filtered', $attachment_id)) === ''
                && !metadata_exists('post', $attachment_id, '_wp_attached_file')
                && !metadata_exists('post', $attachment_id, '_wp_attachment_metadata')
                && !metadata_exists('post', $attachment_id, '_wp_attachment_backup_sizes');
            if ($is_blank_virtual) {
                $cleanup->delete_blank_virtual_attachments([$attachment_id], false, $post_id);
                continue;
            }

            if (Fifu_Attachment_Update_Service::is_safe_to_delete_remote_attachment($attachment_id)) {
                self::delete_fifu_attachment_with_remote_metadata($attachment_id, $post_id);
            }
        }
    }

    /**
     * Delete FIFU category images associated with a given post.
     *
     * Responsibility: mirror the behavior of admin/db.php::delete_category_image().
     *
     * @param int $post_id
     * @return void
     */
    public static function delete_category_image_for_post($post_id): void
    {
        $post_id = is_numeric($post_id) ? (int) $post_id : 0;
        if ($post_id <= 0) {
            return;
        }

        if (Fifu_Options_Utils::is_off('fifu_auto_category')) {
            return;
        }

        $cleanup = self::get_cleanup();
        $meta_gap = new Fifu_Meta_Gap_Repository();

        foreach ($meta_gap->get_category_id_from_post($post_id) as $result) {
            $term_id = $result->term_id ?? 0;
            if (!$term_id) {
                continue;
            }

            $term = get_term((int) $term_id);
            if (!$term || is_wp_error($term)) {
                continue;
            }
            $other_objects = get_objects_in_term((int) $term_id, (string) $term->taxonomy);
            if (is_wp_error($other_objects)) {
                continue;
            }
            $other_objects = array_values(array_filter(
                array_map('intval', (array) $other_objects),
                static fn(int $object_id): bool => $object_id > 0 && $object_id !== $post_id
            ));
            if ($other_objects !== []) {
                continue;
            }

            $cleanup->delete_image_url_category((int) $term_id);
            $att_id = $meta_gap->get_category_thumbnail_id((int) $term_id) ?? 0;
            update_term_meta((int) $term_id, 'thumbnail_id', 0);
            if (
                $att_id
                && self::is_category_attachment_owned_by_term((int) $att_id, (int) $term_id)
                && Fifu_Attachment_Update_Service::is_fifu_owned((int) $att_id)
            ) {
                self::delete_category_attachment_if_unreferenced((int) $att_id, (int) $term_id);
            }
        }
    }

    /**
     * Sync the FIFU attachment used by a category term.
     *
     * Mirrors the behavior of admin/db.php::ctgr_update_fake_attach_id().
     *
     * @param int  $term_id
     * @param bool $preserve_backup_thumbnail
     * @return void
     */
    public static function sync_category_attachment(
        int $term_id,
        bool $preserve_backup_thumbnail = false
    ): void
    {
        self::debug_auto_category('sync_category_attachment_start', [
            'term_id' => $term_id,
            'thumbnail_before' => (int) get_term_meta($term_id, 'thumbnail_id', true),
        ]);
        $attachment_repo = self::get_attachment_repository();

        $term_meta = get_term_meta($term_id, 'thumbnail_id');
        $att_id = $term_meta ? (int) $term_meta[0] : null;
        $has_fifu_attachment = $att_id ? $attachment_repo->is_fifu_attachment($att_id) : false;

        $url = null;
        $dimension_key_type = 'image';
        $video_url = Fifu_Term_Video_Read_Service::get_video_url((int) $term_id);
        if ($video_url) {
            $url = Fifu_Video_Helper::get_thumbnail_large($video_url);
            $dimension_key_type = 'video';
            if ($url && Fifu_Video_Helper::is_youtube_thumbnail($url) && strpos($url, 'maxresdefault') !== false) {
                $response = wp_remote_get($url);
                $status = $response['http_response']->get_response_object()->status_code ?? null;
                if ($status === 404) {
                    $url = str_replace('maxresdefault', 'mqdefault', $url);
                }
            }
        }
        $url = $url ?: Fifu_Term_Image_Url_Read_Service::get_image_url((int) $term_id);
        self::debug_auto_category('sync_category_attachment_url_resolved', [
            'term_id' => $term_id,
            'url' => $url,
            'thumbnail_current' => (int) get_term_meta($term_id, 'thumbnail_id', true),
        ]);

        $is_wvs = Fifu_Woocommerce_Context::is_woo_variation_swatches_taxonomy($term_id);
        $shared_attachment_id = 0;

        if (
            $has_fifu_attachment
            && $att_id
            && !self::is_category_attachment_owned_by_term($att_id, $term_id)
        ) {
            // Keep the current term state until a replacement is fully ready.
            // The attachment belongs to another term and must not be mutated.
            $att_id = null;
            $has_fifu_attachment = false;
        }

        if (!$url) {
            self::debug_auto_category('sync_category_attachment_abort_no_url', [
                'term_id' => $term_id,
                'has_fifu_attachment' => $has_fifu_attachment,
                'att_id' => $att_id,
            ]);
            if (
                $has_fifu_attachment
                && $att_id
                && Fifu_Attachment_Update_Service::is_fifu_owned((int) $att_id)
                && self::is_category_attachment_owned_by_term((int) $att_id, $term_id)
            ) {
                update_term_meta($term_id, 'thumbnail_id', 0);
                if ($is_wvs && (int) get_term_meta($term_id, 'product_attribute_image', true) === (int) $att_id) {
                    delete_term_meta($term_id, 'product_attribute_image');
                }
                self::delete_category_attachment_if_unreferenced((int) $att_id, $term_id);
            }
            return;
        }

        $url = trim(htmlspecialchars_decode((string) $url));
        if (!Fifu_Attachment_Update_Service::is_valid_remote_attachment_url($url)) {
            return;
        }

        if (
            $has_fifu_attachment
            && $att_id
            && self::is_category_attachment_owned_by_term($att_id, $term_id)
            && $attachment_repo->get_attachment_reference_term_ids($att_id, $term_id)
        ) {
            // Keep both term references intact until an independent replacement
            // is initialized successfully. The shared attachment must not enter
            // any in-place initialization or repair path.
            $shared_attachment_id = (int) $att_id;
        }

        $alt = Fifu_Term_Image_Alt_Read_Service::get_image_alt((int) $term_id);
        $current_url = $att_id ? Fifu_Attachment_Update_Service::get_attachment_remote_url((int) $att_id) : '';
        $has_attachment_metadata = $att_id ? metadata_exists('post', (int) $att_id, '_wp_attachment_metadata') : false;
        $dimensions = self::get_category_attachment_dimensions((int) $term_id, (string) $url, $dimension_key_type);
        $width = $dimensions['width'];
        $height = $dimensions['height'];
        $new_att_id = null;
        if (
            $has_fifu_attachment
            && $att_id
            && Fifu_Attachment_Update_Service::is_fifu_owned($att_id)
            && self::is_category_attachment_owned_by_term($att_id, $term_id)
            && $shared_attachment_id === 0
        ) {
            if ($current_url === $url) {
                if (
                    !$has_attachment_metadata
                    && Fifu_Attachment_Update_Service::is_safe_to_delete_remote_attachment($att_id)
                ) {
                    Fifu_Attachment_Update_Service::initialize_remote_attachment($att_id, $url, $alt, $width, $height, true);
                    $new_att_id = Fifu_Attachment_Update_Service::has_remote_file_metadata($att_id, $url)
                        ? $att_id
                        : null;
                } else {
                    $new_att_id = self::initialize_category_attachment($att_id, $term_id, $url, $alt, $width, $height)
                        ? $att_id
                        : null;
                }
            } elseif (!$has_attachment_metadata && Fifu_Attachment_Update_Service::is_safe_to_delete_remote_attachment($att_id)) {
                $new_att_id = self::initialize_category_attachment_with_rollback($att_id, $term_id, $url, $alt, $width, $height);
            }
        }

        if ($new_att_id === null) {
            $new_att_id = self::find_or_create_initialized_category_attachment(
                $attachment_repo,
                $term_id,
                $url,
                $alt,
                $width,
                $height,
                $shared_attachment_id
            );
        }
        if ($new_att_id === null) {
            return;
        }

        update_term_meta($term_id, 'thumbnail_id', $new_att_id);
        if ($is_wvs) {
            update_term_meta($term_id, 'product_attribute_image', $new_att_id);
        }

        if ($att_id && $att_id !== $new_att_id && self::is_category_attachment_owned_by_term($att_id, $term_id)) {
            self::delete_category_attachment_if_unreferenced($att_id, $term_id);
        }

        $orphan_ids = self::normalize_attachment_ids($attachment_repo->get_orphan_attachments_for_term($term_id));
        foreach ($orphan_ids as $orphan_id) {
            if (self::is_category_attachment_child_of_term($orphan_id, $term_id)) {
                self::delete_category_attachment_if_unreferenced($orphan_id, $term_id);
            }
        }

        self::debug_auto_category('sync_category_attachment_end', [
            'term_id' => $term_id,
            'thumbnail_after' => (int) get_term_meta($term_id, 'thumbnail_id', true),
        ]);

        if (
            !$preserve_backup_thumbnail
            && !Fifu_Speedup_Url_Service::is_speedup_url($url)
            && get_term_meta($term_id, 'bkp_thumbnail_id', true)
        ) {
            delete_term_meta($term_id, 'bkp_thumbnail_id');
        }
    }

    private static function is_category_attachment_owned_by_term(int $attachment_id, int $term_id): bool
    {
        if ($attachment_id <= 0 || $term_id <= 0 || get_post_type($attachment_id) !== 'attachment') {
            return false;
        }

        return (int) get_post_field('post_parent', $attachment_id) === $term_id
            && (string) get_post_field('post_name', $attachment_id) === 'fifu-category-' . $term_id;
    }

    private static function is_category_attachment_child_of_term(int $attachment_id, int $term_id): bool
    {
        if ($attachment_id <= 0 || $term_id <= 0 || get_post_type($attachment_id) !== 'attachment') {
            return false;
        }

        $name = (string) get_post_field('post_name', $attachment_id);
        $prefix = 'fifu-category-' . $term_id;
        return (int) get_post_field('post_parent', $attachment_id) === $term_id
            && ($name === $prefix || strpos($name, $prefix . '-') === 0);
    }

    private static function find_or_create_initialized_category_attachment(
        Fifu_Attachment_Repository $repository,
        int $term_id,
        string $url,
        ?string $alt,
        ?int $width,
        ?int $height,
        int $excluded_attachment_id = 0
    ): ?int {
        $attachment_id = $repository->find_attachment_id(
            $term_id,
            $url,
            true,
            $excluded_attachment_id,
            $term_id
        );
        if ($attachment_id && !self::is_category_attachment_owned_by_term($attachment_id, $term_id)) {
            $attachment_id = null;
        }
        if (!$attachment_id) {
            $attachment_id = $repository->find_incomplete_attachment_id(
                $term_id,
                $url,
                true,
                $excluded_attachment_id,
                $term_id
            );
            if ($attachment_id && !self::is_category_attachment_owned_by_term($attachment_id, $term_id)) {
                $attachment_id = null;
            }
        }
        if (!$attachment_id) {
            $attachment_id = (new Fifu_Attachment_Factory())->create_category_attachment_for_url($url, $alt, $term_id);
        }

        if (
            !$attachment_id
            || !self::is_category_attachment_owned_by_term((int) $attachment_id, $term_id)
            || !Fifu_Attachment_Update_Service::is_fifu_owned((int) $attachment_id)
            || !self::initialize_category_attachment((int) $attachment_id, $term_id, $url, $alt, $width, $height)
        ) {
            return null;
        }

        return (int) $attachment_id;
    }

    private static function initialize_category_attachment(
        int $attachment_id,
        int $term_id,
        string $url,
        ?string $alt,
        ?int $width,
        ?int $height,
        bool $allow_remote_url_change = false
    ): bool {
        if (
            !Fifu_Attachment_Update_Service::is_valid_remote_attachment_url($url)
            || !Fifu_Attachment_Update_Service::is_fifu_owned($attachment_id)
            || !self::is_category_attachment_owned_by_term($attachment_id, $term_id)
        ) {
            return false;
        }

        $attached_file = trim(htmlspecialchars_decode((string) get_post_meta($attachment_id, '_wp_attached_file', true)));
        $content_filtered = trim(htmlspecialchars_decode((string) get_post_field('post_content_filtered', $attachment_id)));
        $effective_file = get_attached_file($attachment_id);
        if (
            ($attached_file !== '' && !Fifu_Attachment_Update_Service::is_valid_remote_attachment_url($attached_file))
            || ($content_filtered !== '' && !Fifu_Attachment_Update_Service::is_valid_remote_attachment_url($content_filtered))
            || ($effective_file && !Fifu_Attachment_Update_Service::is_valid_remote_attachment_url((string) $effective_file))
            || ($attached_file !== '' && $attached_file !== $url && !$allow_remote_url_change)
            || ($content_filtered !== '' && $content_filtered !== $url && !$allow_remote_url_change)
        ) {
            return false;
        }

        $backup_sizes = get_post_meta($attachment_id, '_wp_attachment_backup_sizes', true);
        if (is_array($backup_sizes) || !empty($backup_sizes)) {
            return false;
        }
        $metadata = get_post_meta($attachment_id, '_wp_attachment_metadata', true);
        if ($metadata !== '' && $metadata !== false && $metadata !== []) {
            if (!is_array($metadata)) {
                return false;
            }
            if (isset($metadata['file']) && (
                !is_string($metadata['file'])
                || !Fifu_Attachment_Update_Service::is_valid_remote_attachment_url($metadata['file'])
                || (!$allow_remote_url_change && $metadata['file'] !== $url && $metadata['file'] !== $attached_file)
            )) {
                return false;
            }
            foreach (['thumb', 'sizes', 'original_image', 'source_image', 'animated_video', 'animated_video_poster'] as $key) {
                if (!empty($metadata[$key])) {
                    return false;
                }
            }
            if ($attached_file === '') {
                return false;
            }
        }

        if ($attached_file !== '' && !Fifu_Attachment_Update_Service::is_safe_to_delete_remote_attachment($attachment_id)) {
            return false;
        }

        Fifu_Attachment_Update_Service::initialize_remote_attachment($attachment_id, $url, $alt, $width, $height, true);
        return Fifu_Attachment_Update_Service::has_remote_file_metadata($attachment_id, $url);
    }

    private static function initialize_category_attachment_with_rollback(
        int $attachment_id,
        int $term_id,
        string $url,
        ?string $alt,
        ?int $width,
        ?int $height
    ): ?int {
        $keys = ['_wp_attached_file', '_wp_attachment_image_alt', '_wp_attachment_metadata', '_wp_attachment_backup_sizes'];
        $metadata_snapshot = [];
        foreach ($keys as $key) {
            $metadata_snapshot[$key] = get_post_meta($attachment_id, $key, false);
        }
        $post_snapshot = [
            'post_content_filtered' => (string) get_post_field('post_content_filtered', $attachment_id),
            'post_title' => (string) get_post_field('post_title', $attachment_id),
            'post_excerpt' => (string) get_post_field('post_excerpt', $attachment_id),
        ];

        if (self::initialize_category_attachment($attachment_id, $term_id, $url, $alt, $width, $height, true)) {
            return $attachment_id;
        }

        foreach ($metadata_snapshot as $key => $values) {
            delete_post_meta($attachment_id, $key);
            foreach ($values as $value) {
                add_post_meta($attachment_id, $key, maybe_unserialize($value), false);
            }
        }
        wp_update_post(array_merge(['ID' => $attachment_id], $post_snapshot));
        return null;
    }

    private static function delete_category_attachment_if_unreferenced(int $attachment_id, int $term_id): void
    {
        if (
            $attachment_id <= 0
            || $attachment_id === (int) get_option('fifu_default_attach_id')
            || !Fifu_Attachment_Update_Service::is_fifu_owned($attachment_id)
            || !self::is_category_attachment_child_of_term($attachment_id, $term_id)
        ) {
            return;
        }

        $repository = self::get_attachment_repository();
        if ($repository->get_referenced_attachment_ids([$attachment_id])) {
            return;
        }

        if (Fifu_Attachment_Update_Service::is_safe_to_delete_remote_attachment($attachment_id)) {
            self::delete_fifu_attachment_with_remote_metadata($attachment_id);
            return;
        }

        $blank_virtual = trim((string) get_post_field('guid', $attachment_id)) === ''
            && trim((string) get_post_field('post_content_filtered', $attachment_id)) === ''
            && !metadata_exists('post', $attachment_id, '_wp_attached_file')
            && !metadata_exists('post', $attachment_id, '_wp_attachment_metadata')
            && !metadata_exists('post', $attachment_id, '_wp_attachment_backup_sizes');
        if ($blank_virtual) {
            $cleanup = new Fifu_Local_Media_Cleanup();
            $cleanup->delete_blank_virtual_attachments([$attachment_id], true);
        }
    }

    /**
     * Resolve DB2 dimensions for the category attachment URL when available.
     *
     * @param int $term_id
     * @param string $url
     * @return array{width:int|null,height:int|null}
     */
    private static function get_category_attachment_dimensions(int $term_id, string $url, string $preferred_key_type = 'image'): array
    {
        $empty = [
            'width' => null,
            'height' => null,
        ];

        if ($term_id <= 0 || trim($url) === '' || !function_exists('fifu_db2_manager')) {
            return $empty;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getTermMapping')) {
            return $empty;
        }

        $target_url = self::normalize_category_dimension_url($url);

        $key_types = $preferred_key_type === 'video' ? ['video', 'image'] : ['image', 'video'];

        foreach ($key_types as $key_type) {
            $mapping = $manager->getTermMapping($term_id, $key_type);
            if (!is_array($mapping)) {
                continue;
            }

            $mapping_url = self::normalize_category_dimension_url((string) ($mapping['url'] ?? ''));
            if ($key_type !== 'video' && $mapping_url !== '' && $target_url !== '' && $mapping_url !== $target_url) {
                continue;
            }

            $width = isset($mapping['width']) ? (int) $mapping['width'] : 0;
            $height = isset($mapping['height']) ? (int) $mapping['height'] : 0;

            if ($width > 0 && $height > 0) {
                return [
                    'width' => $width,
                    'height' => $height,
                ];
            }
        }

        return $empty;
    }

    /**
     * Normalize remote URLs for DB2 dimension matching.
     *
     * @param string $url
     * @return string
     */
    private static function normalize_category_dimension_url(string $url): string
    {
        return trim(htmlspecialchars_decode($url));
    }

    /**
     * Build the VALUES tuple for a category attachment insert.
     *
     * @param string      $url
     * @param string|null $alt
     * @param int    $term_id
     * @return string
     */
    private static function build_category_attachment_tuple(string $url, ?string $alt, int $term_id): string
    {
        global $wpdb;
        $alt_value = trim($alt ?? '');
        return $wpdb->prepare(
            "(%d, %s, %s, %s, %s, %s, %s, %d, NOW(), NOW(), NOW(), NOW(), %s, %s, %s, %s, %s)",
            self::get_author_id(),
            '',
            $alt_value,
            $alt_value,
            'image/jpeg',
            'attachment',
            'inherit',
            $term_id,
            '',
            '',
            '',
            $url,
            'fifu-category-' . $term_id
        );
    }

    /**
     * Persist gallery metadata while keeping attachment order stable.
     *
     * @param int $post_id
     * @param int[] $attachment_ids
     * @return void
     */
    private static function persist_gallery_meta(int $post_id, array $attachment_ids): void
    {
        $thumbnail_id = (int) get_post_thumbnail_id($post_id);
        $attachment_ids = array_values(array_unique(array_filter(
            array_map('intval', $attachment_ids),
            static fn(int $id): bool => $id > 0 && $id !== $thumbnail_id
        )));
        self::persist_clean_product_gallery_meta($post_id, $attachment_ids);

        if (get_post_type($post_id) === 'product_variation') {
            $csv = $attachment_ids ? implode(',', $attachment_ids) : '';
            if ($csv !== '') {
                update_post_meta($post_id, '_wc_additional_variation_images', $csv);
            } else {
                delete_post_meta($post_id, '_wc_additional_variation_images');
            }
            return;
        }

        delete_post_meta($post_id, '_wc_additional_variation_images');
    }

    private static function normalize_product_gallery_ids($ids, int $thumbnail_id = 0): array
    {
        if (is_string($ids)) {
            $ids = explode(',', $ids);
        }

        if (!is_array($ids)) {
            return [];
        }

        $normalized = [];

        foreach ($ids as $id) {
            $id = (int) trim((string) $id);
            if ($id <= 0) {
                continue;
            }
            if ($thumbnail_id > 0 && $id === $thumbnail_id) {
                continue;
            }
            $normalized[] = $id;
        }

        return array_values(array_unique($normalized));
    }

    private static function persist_clean_product_gallery_meta(int $post_id, $attachment_ids): void
    {
        $thumbnail_id = (int) get_post_thumbnail_id($post_id);
        $attachment_ids = self::normalize_product_gallery_ids($attachment_ids, $thumbnail_id);

        $current_csv = (string) get_post_meta($post_id, '_product_image_gallery', true);

        if ($attachment_ids === []) {
            if (
                $current_csv !== ''
                || metadata_exists('post', $post_id, '_product_image_gallery')
            ) {
                delete_post_meta($post_id, '_product_image_gallery');
            }

            return;
        }

        $csv = implode(',', $attachment_ids);

        if ($current_csv === $csv) {
            return;
        }

        update_post_meta($post_id, '_product_image_gallery', $csv);
    }

    /** @param array<string,mixed> $attachment */
    private static function initialize_gallery_attachment(int $attachment_id, int $post_id, string $url, ?string $alt): bool
    {
        $url = trim(htmlspecialchars_decode($url));
        $attachment = get_post($attachment_id);
        if (
            $url === ''
            || !Fifu_Attachment_Update_Service::is_valid_remote_attachment_url($url)
            || !$attachment
            || $attachment->post_type !== 'attachment'
            || !Fifu_Attachment_Update_Service::is_fifu_owned($attachment_id)
            || (int) $attachment->post_parent !== $post_id
            || strpos((string) $attachment->post_name, 'fifu-category-') === 0
        ) {
            return false;
        }

        $attached_file = trim(htmlspecialchars_decode((string) get_post_meta($attachment_id, '_wp_attached_file', true)));
        $content_filtered = trim(htmlspecialchars_decode((string) $attachment->post_content_filtered));
        if ($attached_file !== '') {
            if (
                !Fifu_Attachment_Update_Service::is_valid_remote_attachment_url($attached_file)
                || self::normalize_attachment_url($attached_file) !== self::normalize_attachment_url($url)
                || ($content_filtered !== '' && (
                    !Fifu_Attachment_Update_Service::is_valid_remote_attachment_url($content_filtered)
                    || self::normalize_attachment_url($content_filtered) !== self::normalize_attachment_url($url)
                ))
            ) {
                return false;
            }
        } elseif (
            !Fifu_Attachment_Update_Service::is_valid_remote_attachment_url($content_filtered)
            || self::normalize_attachment_url($content_filtered) !== self::normalize_attachment_url($url)
        ) {
            return false;
        }

        return self::initialize_post_attachment($attachment_id, $url, $alt)
            && Fifu_Attachment_Update_Service::has_remote_file_metadata($attachment_id, $url);
    }

    private static function find_or_create_initialized_gallery_attachment(
        Fifu_Attachment_Repository $attachment_repo,
        Fifu_Attachment_Factory $factory,
        int $post_id,
        string $url,
        ?string $alt
    ): ?int {
        $url = trim(htmlspecialchars_decode($url));
        if ($url === '' || !Fifu_Attachment_Update_Service::is_valid_remote_attachment_url($url)) {
            return null;
        }

        $attachment_id = $attachment_repo->find_attachment_id($post_id, $url, false);
        if ($attachment_id) {
            $attached_file = trim(htmlspecialchars_decode((string) get_post_meta($attachment_id, '_wp_attached_file', true)));
            $content_filtered = trim(htmlspecialchars_decode((string) get_post_field('post_content_filtered', $attachment_id)));
            if (
                $attached_file !== ''
                && self::normalize_attachment_url($attached_file) === self::normalize_attachment_url($url)
                && ($content_filtered === '' || self::normalize_attachment_url($content_filtered) === self::normalize_attachment_url($url))
            ) {
                return self::initialize_gallery_attachment($attachment_id, $post_id, $url, $alt)
                    ? $attachment_id
                    : null;
            }
        }

        $incomplete_id = $attachment_repo->find_incomplete_attachment_id($post_id, $url, false);
        if ($incomplete_id) {
            return self::initialize_gallery_attachment($incomplete_id, $post_id, $url, $alt)
                ? $incomplete_id
                : null;
        }

        $attachment_id = $factory->create_attachment_for_url($url, $alt, $post_id);
        if (
            $attachment_id <= 0
            || !self::initialize_gallery_attachment($attachment_id, $post_id, $url, $alt)
        ) {
            return null;
        }

        return $attachment_id;
    }

    private static function gallery_attachment_state_matches(array $attachment, string $url, ?string $alt): bool
    {
        $desiredUrl = self::normalize_attachment_url($url);
        $attachmentId = (int) ($attachment['id'] ?? 0);
        if (
            $attachmentId <= 0
            || !Fifu_Attachment_Update_Service::has_remote_file_metadata($attachmentId, $url)
            || !Fifu_Attachment_Update_Service::is_valid_remote_attachment_url((string) ($attachment['attached_file'] ?? ''))
        ) {
            return false;
        }
        $attachedFile = trim((string) ($attachment['attached_file'] ?? ''));
        $currentUrl = self::normalize_attachment_url($attachedFile !== ''
            ? $attachedFile
            : (string) ($attachment['post_content_filtered'] ?? ''));
        $desiredAlt = trim((string) $alt);
        if ($currentUrl !== $desiredUrl
            || trim((string) ($attachment['post_title'] ?? '')) !== $desiredAlt
            || trim((string) ($attachment['post_excerpt'] ?? '')) !== $desiredAlt) {
            return false;
        }
        $filtered = self::normalize_attachment_url((string) ($attachment['post_content_filtered'] ?? ''));
        if ($filtered !== null && $filtered !== $desiredUrl) {
            return false;
        }
        return !array_key_exists('attachment_alt', $attachment)
            || $attachment['attachment_alt'] === null
            || trim((string) $attachment['attachment_alt']) === $desiredAlt;
    }

    private static function is_gallery_video_meta_key(string $meta_key): bool
    {
        return strpos($meta_key, 'fifu_video_url_') === 0;
    }

    private static function is_gallery_image_like_meta_key(string $meta_key): bool
    {
        return strpos($meta_key, 'fifu_image_url_') === 0
            || strpos($meta_key, 'fifu_slider_image_url_') === 0;
    }

    private static function has_explicit_video_marker(string $url): bool
    {
        return strpos($url, '#http') !== false;
    }

    private static function get_cleanup(): Fifu_Local_Media_Cleanup
    {
        if (self::$cleanup === null) {
            self::$cleanup = new Fifu_Local_Media_Cleanup();
        }

        return self::$cleanup;
    }

    private static function get_attachment_repository(): Fifu_Attachment_Repository
    {
        return new Fifu_Attachment_Repository();
    }

    private static function get_product_gallery_repository(): Fifu_Product_Gallery_Repository
    {
        return new Fifu_Product_Gallery_Repository();
    }

    private static function normalize_attachment_ids($value): array
    {
        if (!$value) {
            return [];
        }

        $items = is_array($value) ? $value : explode(',', (string) $value);
        $ids = [];
        foreach ($items as $item) {
            $item = trim((string) $item);
            if ($item === '') {
                continue;
            }
            $id = (int) $item;
            if ($id > 0) {
                $ids[] = $id;
            }
        }

        return $ids;
    }

    private static function delete_fifu_attachment_ids(
        Fifu_Local_Media_Cleanup $cleanup,
        array $attachment_ids,
        int $post_id
    ): void
    {
        $attachment_ids = self::normalize_attachment_ids($attachment_ids);
        if (!$attachment_ids) {
            return;
        }

        $attachment_repo = self::get_attachment_repository();
        $referenced_ids = $attachment_repo->get_referenced_attachment_ids($attachment_ids);
        $default_attachment_id = (int) get_option('fifu_default_attach_id');
        $blank_virtual_ids = [];

        foreach ($attachment_ids as $attachment_id) {
            if (
                $attachment_id === $default_attachment_id
                || in_array($attachment_id, $referenced_ids, true)
                || !$attachment_repo->is_fifu_attachment($attachment_id)
                || !self::is_attachment_owned_by_post($attachment_id, $post_id)
            ) {
                continue;
            }

            $attached_file = trim(htmlspecialchars_decode((string) get_post_meta($attachment_id, '_wp_attached_file', true)));
            $content_filtered = trim(htmlspecialchars_decode((string) get_post_field('post_content_filtered', $attachment_id)));
            if ($attached_file === '' && $content_filtered === '') {
                $blank_virtual_ids[] = $attachment_id;
                continue;
            }

            self::delete_fifu_attachment_with_remote_metadata($attachment_id);
        }

        if ($blank_virtual_ids) {
            $cleanup->delete_blank_virtual_attachments($blank_virtual_ids);
        }
    }

    private static function delete_gallery_meta_by_attachment_ids(int $parent_id, string $attach_ids_csv): void
    {
        $attach_ids = Fifu_Db2_Sql_Helper::sanitize_ids_csv($attach_ids_csv);
        $post_ids = Fifu_Db2_Sql_Helper::sanitize_ids_csv($parent_id);
        if (!$attach_ids || !$post_ids) {
            return;
        }

        global $wpdb;
        $wpdb->query("
            DELETE FROM {$wpdb->postmeta}
            WHERE post_id IN ({$post_ids})
              AND meta_key IN ('_product_image_gallery', '_wc_additional_variation_images')
              AND NOT EXISTS (
                SELECT 1
                FROM {$wpdb->posts}
                WHERE id IN ({$attach_ids})
            )
        ");
    }

    private static function clear_gallery_meta_for_parent_id(int $parent_id, bool $is_category): void
    {
        $post_ids_csv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($parent_id);
        if (!$post_ids_csv) {
            return;
        }

        $author_id = self::get_author_id();
        $ctgr_sql = $is_category ? "AND post_name LIKE 'fifu-category%'" : '';

        global $wpdb;
        $sql = "
            DELETE pm
            FROM {$wpdb->postmeta} pm
            JOIN {$wpdb->posts} p ON pm.post_id = p.post_parent
            WHERE pm.post_id IN ({$post_ids_csv})
              AND pm.meta_key IN ('_product_image_gallery', '_wc_additional_variation_images')
              AND p.post_author = %d
              {$ctgr_sql}
        ";

        $wpdb->query($wpdb->prepare($sql, $author_id));
    }

    private static function insert_product_image_gallery_meta_for_parent(int $parent_id, bool $is_category): void
    {
        $post_ids_csv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($parent_id);
        if (!$post_ids_csv) {
            return;
        }

        $author_id = self::get_author_id();
        $ctgr_sql = $is_category ? "AND p.post_name LIKE 'fifu-category%'" : '';

        global $wpdb;
        $sql = "
            INSERT INTO {$wpdb->postmeta} (post_id, meta_key, meta_value)
            (
                SELECT post_parent, '_product_image_gallery', GROUP_CONCAT(id)
                FROM {$wpdb->posts} p
                WHERE p.post_parent IN ({$post_ids_csv})
                AND p.id NOT IN (
                    SELECT pm.meta_value
                    FROM {$wpdb->postmeta} pm
                    WHERE pm.post_id = p.post_parent
                      AND pm.meta_key = '_thumbnail_id'
                )
                AND p.post_author = %d
                {$ctgr_sql}
                GROUP BY post_parent
            )
        ";

        $wpdb->query($wpdb->prepare($sql, $author_id));
    }

    private static function insert_wc_additional_variation_images_meta_for_parent(int $parent_id, bool $is_category): void
    {
        $post_ids_csv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($parent_id);
        if (!$post_ids_csv) {
            return;
        }

        $author_id = self::get_author_id();
        $ctgr_sql = $is_category ? "AND p.post_name LIKE 'fifu-category%'" : '';

        global $wpdb;
        $sql = "
            INSERT INTO {$wpdb->postmeta} (post_id, meta_key, meta_value)
            (
                SELECT post_parent, '_wc_additional_variation_images', GROUP_CONCAT(id)
                FROM {$wpdb->posts} p
                WHERE p.post_parent IN ({$post_ids_csv})
                AND p.id NOT IN (
                    SELECT pm.meta_value
                    FROM {$wpdb->postmeta} pm
                    WHERE pm.post_id = p.post_parent
                      AND pm.meta_key = '_thumbnail_id'
                )
                AND p.post_author = %d
                {$ctgr_sql}
                AND (SELECT post_type FROM {$wpdb->posts} WHERE id = p.post_parent) = 'product_variation'
                GROUP BY post_parent
            )
        ";

        $wpdb->query($wpdb->prepare($sql, $author_id));
    }

    private static function get_author_id(): int
    {
        return (int) Fifu_Options_Utils::get_author();
    }

    private static function insert_category_attachment_rows(string $values_sql): void
    {
        if (!$values_sql) {
            return;
        }
        global $wpdb;
        $wpdb->query("
            INSERT INTO {$wpdb->posts}
                (post_author, guid, post_title, post_excerpt, post_mime_type, post_type, post_status, post_parent,
                post_date, post_date_gmt, post_modified, post_modified_gmt, post_content, to_ping, pinged, post_content_filtered, post_name)
            VALUES {$values_sql}
        ");
    }
}
