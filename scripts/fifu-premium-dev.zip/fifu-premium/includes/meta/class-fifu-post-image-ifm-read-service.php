<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Provides read access to IFM image URL metadata.
 */
final class Fifu_Post_Image_Ifm_Read_Service
{
    /**
     * Returns the IFM image URL for a post and a given index, using db2 first and falling back to postmeta.
     *
     * @param int $postId
     * @param int $index
     * @return string|null
     */
    public static function get_image_ifm_url(int $postId, int $index): ?string
    {
        if ($index < 0) {
            return null;
        }

        if (function_exists('fifu_db2_manager')) {
            $manager = fifu_db2_manager();
            if ($manager instanceof Fifu_Db2_Manager) {
                $mapping = $manager->getPostMapping($postId, 'iframe', $index);
                if (is_array($mapping) && !empty($mapping['url'])) {
                    return (string) $mapping['url'];
                }
            }
        }

        $metaKey = 'fifu_image_ifm_' . $index;
        $legacyUrl = get_post_meta($postId, $metaKey, true);
        if ($legacyUrl === '' || $legacyUrl === null) {
            return null;
        }

        return (string) $legacyUrl;
    }
}
