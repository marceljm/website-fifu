<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('Fifu_Image_Url_Utils', false)) {
    require_once __DIR__ . '/../url/class-fifu-image-url-utils.php';
}

/**
 * Executes the screenshot cron job using the meta gap repository.
 */
final class Fifu_Screenshot_Cron_Service
{
    /**
     * Runs the screenshot cron job that backfills FIFU images from configured custom fields.
     */
    public static function run(): void
    {
        $gapRepository = new Fifu_Meta_Gap_Repository();
        $results = $gapRepository->get_posts_without_screenshot();

        if (empty($results)) {
            return;
        }

        $size = Fifu_Image_Url_Utils::normalize_screenshot_size(get_option('fifu_screenshot_size', ''));

        foreach ($results as $row) {
            $postId = (int) ($row->post_id ?? 0);
            $url = (string) ($row->url ?? '');

            if ($postId <= 0 || $url === '') {
                continue;
            }

            $screenshotUrl = $size !== ''
                ? "https://screenshot.fifu.app/{$size}/{$url}"
                : "https://screenshot.fifu.app/{$url}";

            fifu_dev_set_image($postId, $screenshotUrl);
        }
    }
}
