<?php

if (!defined('ABSPATH')) {
    exit;
}


class Fifu_Wai_Meta_Service {
    private static bool $lastImageListDb2UrlsConfirmed = false;

    public static function has_properties(): bool {
        if (class_exists('Fifu_Plugin_Detector') && Fifu_Plugin_Detector::is_ol_scrapes_active()) {
            return true;
        }

        foreach ($_POST as $key => $value) {
            if (strpos($key, 'fifu') !== false) {
                return true;
            }
        }

        return false;
    }

    public static function handle_before_xml_import($import_id): void {
        unset($import_id);
        if (Fifu_Options_Utils::is_on('fifu_auto_category')) {
            update_option('fifu_auto_category', 'toggleoff');
            update_option('fifu_auto_category_waiting', true);
        }
    }

    public static function save_image_list( int $post_id, ?bool $is_category, ?bool $video_priority ): void {
        self::$lastImageListDb2UrlsConfirmed = false;
        if ( $is_category === true ) {
            self::save_term_image( (int) $post_id );
            return;
        }

        $persisted_list_raw = self::get_raw_meta_value( $post_id, 'fifu_list_url' );
        $persisted_alt_raw = self::get_raw_meta_value( $post_id, 'fifu_list_alt' );
        $direct_list_raw = self::get_direct_image_list_payload_raw( $post_id );
        $explicit_alt_raw = self::get_explicit_image_alt_list_payload_raw( $post_id );
        $explicit_list_raw = self::get_explicit_image_list_payload_raw( $post_id );
        $gallery_only_rebuild = self::should_force_gallery_only_db2_rebuild( $post_id );
        $has_video_list_payload = self::has_current_import_video_list_payload( $post_id );
        $should_preserve_mixed_media_image_list = $video_priority === true && $has_video_list_payload;
        $existing_db2_image_urls = self::get_db2_post_image_urls_by_index( $post_id );

        if ( $gallery_only_rebuild ) {
            $explicit_list_raw = (string) ( $_REQUEST['fifu_wai_gallery_only_image_list_url'] ?? $explicit_list_raw );
            $explicit_alt_raw = (string) ( $_REQUEST['fifu_wai_gallery_only_image_list_alt'] ?? $explicit_alt_raw );
        }

        $explicit_urls = self::parse_legacy_list( $explicit_list_raw );
        $explicit_alts = $explicit_alt_raw !== '' ? self::parse_legacy_list_preserve_empty_slots( $explicit_alt_raw ) : [];

        if ( $explicit_list_raw !== '' && empty( $explicit_urls ) ) {
            self::cleanup_legacy_image_list( $post_id );
            return;
        }

        if ( empty( $explicit_urls ) ) {
            if ( $explicit_alt_raw !== '' ) {
                if ( ! empty( $existing_db2_image_urls ) ) {
                    $ok_alt = self::save_existing_db2_image_list_alts(
                        $post_id,
                        $explicit_alts,
                        $explicit_alt_raw
                    );
                    if ( ! $ok_alt ) {
                        return;
                    }
                } else {
                    self::cleanup_legacy_image_alt_list_only( $post_id );
                }
                return;
            }

            if ( ! empty( $existing_db2_image_urls ) ) {
                return;
            }
        }

        if ( ! empty( $explicit_urls ) ) {
            if ( ! $is_category ) {
                $normalized_urls = [];
                foreach ( $explicit_urls as $url ) {
                    $url = trim( (string) $url );
                    if ( $url === '' ) {
                        continue;
                    }

                    $normalized_urls[] = $url;
                }

                $normalized_list = implode( '|', $normalized_urls );
                $normalized_alt_list = self::normalize_image_alt_list_for_urls( $explicit_alts, count( $normalized_urls ) );

                if ( $normalized_list !== '' ) {
                    $ok_list = false;
                    if ( function_exists( 'fifu_db2_legacy_write_bridge' ) ) {
                        $bridge = fifu_db2_legacy_write_bridge();
                        if ( $bridge instanceof Fifu_Db2_Legacy_Write_Bridge ) {
                            $ok_list = $bridge->handle_post_meta_change( $post_id, 'fifu_list_url', $normalized_list );
                        }
                    }
                    if ( ! $ok_list ) {
                        self::preserve_legacy_image_list_on_db2_failure( $post_id, $explicit_list_raw, $explicit_alt_raw, $normalized_urls, $normalized_alt_list );
                        self::$lastImageListDb2UrlsConfirmed = false;
                        return;
                    }

                    $ok_list = self::db2_image_list_round_trip_matches( $post_id, $normalized_urls, null );
                    if ( ! $ok_list ) {
                        self::preserve_legacy_image_list_on_db2_failure( $post_id, $explicit_list_raw, $explicit_alt_raw, $normalized_urls, $normalized_alt_list );
                        self::$lastImageListDb2UrlsConfirmed = false;
                        return;
                    }
                    $ok_alt = true;

                    if ( ! empty( $explicit_alts ) ) {
                        $alt_value = implode( '|', $normalized_alt_list );
                        $ok_alt = false;
                        if ( function_exists( 'fifu_db2_legacy_write_bridge' ) ) {
                            $bridge = fifu_db2_legacy_write_bridge();
                            if ( $bridge instanceof Fifu_Db2_Legacy_Write_Bridge ) {
                                $ok_alt = $bridge->handle_post_meta_change( $post_id, 'fifu_list_alt', $alt_value );
                            }
                        }
                        if ( ! $ok_alt ) {
                            self::$lastImageListDb2UrlsConfirmed = true;
                            self::cleanup_legacy_image_url_list_only( $post_id );

                            if ( $persisted_alt_raw !== '' ) {
                                self::preserve_legacy_image_alt_list_on_db2_alt_failure( $post_id, $persisted_alt_raw );
                            } else {
                                self::cleanup_legacy_image_alt_list_only( $post_id );
                            }

                            return;
                        }

                        $ok_alt = self::db2_image_list_round_trip_matches( $post_id, $normalized_urls, $normalized_alt_list );
                        if ( ! $ok_alt ) {
                            self::$lastImageListDb2UrlsConfirmed = true;
                            self::cleanup_legacy_image_url_list_only( $post_id );

                            if ( $persisted_alt_raw !== '' ) {
                                self::preserve_legacy_image_alt_list_on_db2_alt_failure( $post_id, $persisted_alt_raw );
                            } else {
                                self::cleanup_legacy_image_alt_list_only( $post_id );
                            }

                            return;
                        }
                    } else {
                        if ( $explicit_alt_raw !== '' ) {
                            self::preserve_legacy_image_alt_list_on_db2_alt_failure( $post_id, $explicit_alt_raw );
                        }
                    }

                    self::$lastImageListDb2UrlsConfirmed = true;
                    unset( $persisted_list_raw, $persisted_alt_raw, $ok_list, $ok_alt );
                }
            }

            return;
        }

        if ( $persisted_list_raw !== '' ) {
            self::cleanup_legacy_image_list( $post_id );
        }

        $asin = Fifu_Post_Identifier_Read_Service::get_asin( $post_id );
        fifu_update_or_delete( $post_id, 'fifu_asin', $asin );

        $finder_url = Fifu_Post_Finder_Read_Service::get_finder_url( (int) $post_id );
        if ( $finder_url ) {
            fifu_update_or_delete( $post_id, 'fifu_finder_url', $finder_url );
        } else {
            fifu_delete_post_meta( $post_id, 'fifu_finder_url', $finder_url );
        }

        $url = Fifu_Post_Image_Url_Read_Service::get_image_url((int) $post_id);
        $alt = Fifu_Post_Image_Alt_Read_Service::get_image_alt((int) $post_id);
        $is_product = get_post_type( $post_id ) === 'product';
        if ( ! $is_category && $is_product ) {
            return;
        }
        if ( ! $url ) {
            fifu_delete_post_meta( $post_id, 'fifu_image_url', $url );
            fifu_delete_post_meta( $post_id, 'fifu_image_alt', $alt );
        } else {
            fifu_update_or_delete($post_id, 'fifu_image_url', $url);
            fifu_update_or_delete($post_id, 'fifu_image_alt', $alt);

            if ( $video_priority !== true && ! $should_preserve_mixed_media_image_list ) {
                fifu_delete_post_meta( $post_id, 'fifu_video_url' );
                fifu_delete_post_meta( $post_id, 'fifu_custom_video_url' );
            }
        }
    }

    public static function was_last_image_list_db2_urls_confirmed(): bool {
        return self::$lastImageListDb2UrlsConfirmed;
    }

    /**
     * @param array<string, string|null> $snapshot
     */
    public static function restore_product_legacy_image_list_helper_meta(int $post_id, array $data, array $snapshot = [], bool $restore_list_alt = true): void {
        if (array_key_exists('fifu_list_url', $snapshot)) {
            $value = $snapshot['fifu_list_url'];
            if ($value === null) {
                delete_post_meta($post_id, 'fifu_list_url');
            } else {
                self::set_raw_post_meta(
                    $post_id,
                    'fifu_list_url',
                    self::serialize_legacy_import_list((string) $value)
                );
            }
        } elseif (array_key_exists('fifu_list_url', $data)) {
            self::set_raw_post_meta(
                $post_id,
                'fifu_list_url',
                self::serialize_legacy_import_list((string) ($data['fifu_list_url'] ?? ''))
            );
        }

        if (!$restore_list_alt) {
            delete_post_meta($post_id, 'fifu_list_alt');
            return;
        }

        if (array_key_exists('fifu_list_alt', $snapshot)) {
            $value = $snapshot['fifu_list_alt'];
            if ($value === null) {
                delete_post_meta($post_id, 'fifu_list_alt');
            } else {
                self::set_raw_post_meta(
                    $post_id,
                    'fifu_list_alt',
                    self::serialize_legacy_import_list((string) $value)
                );
            }
        } elseif (array_key_exists('fifu_list_alt', $data)) {
            self::set_raw_post_meta(
                $post_id,
                'fifu_list_alt',
                self::serialize_legacy_import_list((string) ($data['fifu_list_alt'] ?? ''))
            );
        }
    }

    private static function serialize_legacy_import_list(string $value): string {
        $value = trim($value);
        if ($value === '') {
            return '';
        }

        $delimiter = strpos($value, PHP_EOL) !== false && strpos($value, '|') === false ? PHP_EOL : '|';
        $entries = array_values(
            array_filter(
                array_map('trim', explode($delimiter, $value)),
                static fn(string $entry): bool => $entry !== ''
            )
        );

        return $entries ? implode("\n", $entries) : '';
    }

    private static function get_db2_manager_or_null(): ?Fifu_Db2_Manager {
        if ( ! function_exists( 'fifu_db2_manager' ) ) {
            return null;
        }

        $manager = fifu_db2_manager();
        return $manager instanceof Fifu_Db2_Manager ? $manager : null;
    }

    private static function ensure_db2_key_type_exists_for_fast_import(string $key_type): bool
    {
        $key_type = trim($key_type);

        if ($key_type === '') {
            return false;
        }

        global $wpdb;

        if (
            !isset($wpdb)
            || !is_object($wpdb)
            || !isset($wpdb->prefix)
            || !method_exists($wpdb, 'prepare')
            || !method_exists($wpdb, 'query')
        ) {
            // Unit tests may use pure manager stubs without a real wpdb-backed DB2 schema.
            // Do not block those stubs; real integration/prod DB failures will be caught
            // when the manager round-trip confirmation fails.
            return true;
        }

        $table = $wpdb->prefix . 'fifu_key';

        $result = $wpdb->query(
            $wpdb->prepare(
                "INSERT IGNORE INTO {$table} (key_type) VALUES (%s)",
                $key_type
            )
        );

        return $result !== false;
    }

    private static function has_db2_post_mappings( int $post_id, string $key_type ): bool {
        $manager = self::get_db2_manager_or_null();
        if ( $manager === null || ! method_exists( $manager, 'getPostMappings' ) ) {
            return false;
        }

        $rows = $manager->getPostMappings( $post_id, $key_type );
        if ( ! is_array( $rows ) ) {
            return false;
        }

        foreach ( $rows as $row ) {
            if ( ! is_array( $row ) ) {
                continue;
            }

            if ( trim( (string) ( $row['url'] ?? '' ) ) !== '' ) {
                return true;
            }
        }

        return false;
    }

    private static function has_effective_post_image_main( int $post_id ): bool {
        $manager = self::get_db2_manager_or_null();
        if ( $manager !== null && method_exists( $manager, 'getPostMapping' ) ) {
            $mapping = $manager->getPostMapping( $post_id, 'image', 0 );
            if ( is_array( $mapping ) && trim( (string) ( $mapping['url'] ?? '' ) ) !== '' ) {
                return true;
            }
        }

        if ( trim( (string) get_post_meta( $post_id, 'fifu_image_url', true ) ) !== '' ) {
            return true;
        }

        if ( class_exists( 'Fifu_Post_Image_Url_Read_Service', false ) ) {
            $url = Fifu_Post_Image_Url_Read_Service::get_image_url( $post_id );
            if ( trim( (string) $url ) !== '' ) {
                return true;
            }
        }

        return false;
    }

    private static function has_effective_post_video_main( int $post_id ): bool {
        $manager = self::get_db2_manager_or_null();
        if ( $manager !== null && method_exists( $manager, 'getPostMapping' ) ) {
            $mapping = $manager->getPostMapping( $post_id, 'video', 0 );
            if ( is_array( $mapping ) && trim( (string) ( $mapping['url'] ?? '' ) ) !== '' ) {
                return true;
            }

            $custom_mapping = $manager->getPostMapping( $post_id, 'custom_video', 0 );
            if ( is_array( $custom_mapping ) && trim( (string) ( $custom_mapping['url'] ?? '' ) ) !== '' ) {
                return true;
            }
        }

        if ( trim( (string) get_post_meta( $post_id, 'fifu_video_url', true ) ) !== '' ) {
            return true;
        }

        if ( trim( (string) get_post_meta( $post_id, 'fifu_custom_video_url', true ) ) !== '' ) {
            return true;
        }

        if ( class_exists( 'Fifu_Post_Video_Read_Service', false ) ) {
            $url = Fifu_Post_Video_Read_Service::get_video_url( $post_id );
            if ( trim( (string) $url ) !== '' ) {
                return true;
            }
        }

        return false;
    }

    private static function get_effective_post_video_list_entries_for_image_priority( int $post_id ): array {
        $legacy_list_raw = self::get_raw_meta_value( $post_id, 'fifu_list_video_url' );
        $legacy_entries = self::parse_legacy_list( $legacy_list_raw );
        if ( ! empty( $legacy_entries ) ) {
            return $legacy_entries;
        }

        if ( class_exists( 'Fifu_Post_Video_List_Url_Read_Service', false ) ) {
            $video_list = Fifu_Post_Video_List_Url_Read_Service::get_video_list_url( $post_id );
            $video_entries = $video_list ? self::parse_legacy_list( $video_list ) : [];
            if ( ! empty( $video_entries ) ) {
                return $video_entries;
            }
        }

        return [];
    }

    private static function should_store_images_as_gallery_only_due_to_video_priority( int $post_id, ?bool $video_priority ): bool {
        if ( $video_priority !== true ) {
            return false;
        }

        if ( self::has_effective_post_video_main( $post_id ) ) {
            return true;
        }

        return ! empty( self::get_effective_post_video_list_entries_for_image_priority( $post_id ) );
    }

    private static function run_preserving_image_list_for_mixed_media_import( int $post_id, callable $callback ) {
        $key = (string) $post_id;
        $hadOld = isset( $GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import'] )
            && is_array( $GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import'] )
            && array_key_exists( $key, $GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import'] );
        $old = $hadOld ? $GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import'][ $key ] : null;

        if ( ! isset( $GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import'] ) || ! is_array( $GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import'] ) ) {
            $GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import'] = [];
        }

        $GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import'][ $key ] = true;

        try {
            return $callback();
        } finally {
            if ( $hadOld ) {
                $GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import'][ $key ] = $old;
            } else {
                unset( $GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import'][ $key ] );
            }
        }
    }

    private static function run_with_gallery_only_image_rebuild_context( int $post_id, callable $callback ) {
        $key = $post_id . ':fifu_list_url';
        $old = $GLOBALS['__fifu_dev_gallery_only_db2_rebuild'][ $key ] ?? null;
        $hadOld = isset( $GLOBALS['__fifu_dev_gallery_only_db2_rebuild'] ) && is_array( $GLOBALS['__fifu_dev_gallery_only_db2_rebuild'] ) && array_key_exists( $key, $GLOBALS['__fifu_dev_gallery_only_db2_rebuild'] );

        if ( ! isset( $GLOBALS['__fifu_dev_gallery_only_db2_rebuild'] ) || ! is_array( $GLOBALS['__fifu_dev_gallery_only_db2_rebuild'] ) ) {
            $GLOBALS['__fifu_dev_gallery_only_db2_rebuild'] = [];
        }

        $GLOBALS['__fifu_dev_gallery_only_db2_rebuild'][ $key ] = true;

        try {
            return $callback();
        } finally {
            if ( $hadOld ) {
                $GLOBALS['__fifu_dev_gallery_only_db2_rebuild'][ $key ] = $old;
            } else {
                unset( $GLOBALS['__fifu_dev_gallery_only_db2_rebuild'][ $key ] );
            }
        }
    }

    private static function run_with_gallery_only_video_rebuild_context( int $post_id, callable $callback ) {
        $key = $post_id . ':fifu_list_video_url';
        $old = $GLOBALS['__fifu_dev_video_gallery_only_db2_rebuild'][ $key ] ?? null;
        $hadOld = isset( $GLOBALS['__fifu_dev_video_gallery_only_db2_rebuild'] ) && is_array( $GLOBALS['__fifu_dev_video_gallery_only_db2_rebuild'] ) && array_key_exists( $key, $GLOBALS['__fifu_dev_video_gallery_only_db2_rebuild'] );

        if ( ! isset( $GLOBALS['__fifu_dev_video_gallery_only_db2_rebuild'] ) || ! is_array( $GLOBALS['__fifu_dev_video_gallery_only_db2_rebuild'] ) ) {
            $GLOBALS['__fifu_dev_video_gallery_only_db2_rebuild'] = [];
        }

        $GLOBALS['__fifu_dev_video_gallery_only_db2_rebuild'][ $key ] = true;

        try {
            return $callback();
        } finally {
            if ( $hadOld ) {
                $GLOBALS['__fifu_dev_video_gallery_only_db2_rebuild'][ $key ] = $old;
            } else {
                unset( $GLOBALS['__fifu_dev_video_gallery_only_db2_rebuild'][ $key ] );
            }
        }
    }

    private static function should_force_gallery_only_db2_rebuild( int $post_id ): bool {
        $context = $GLOBALS['__fifu_dev_gallery_only_db2_rebuild'] ?? null;
        if ( ! is_array( $context ) ) {
            return false;
        }

        return (bool) ( $context[ $post_id . ':fifu_list_url' ] ?? false );
    }

    private static function should_force_video_gallery_only_db2_rebuild( int $post_id ): bool {
        $context = $GLOBALS['__fifu_dev_video_gallery_only_db2_rebuild'] ?? null;
        if ( ! is_array( $context ) ) {
            return false;
        }

        return (bool) ( $context[ $post_id . ':fifu_list_video_url' ] ?? false );
    }

    private static function has_persisted_legacy_postmeta_value( int $post_id, string $meta_key ): bool {
        return trim( (string) self::get_raw_meta_value( $post_id, $meta_key ) ) !== '';
    }

    private static function get_explicit_image_list_payload_raw( int $post_id ): string {
        $request = trim( (string) ( $_REQUEST['fifu_wai_image_list_url'] ?? '' ) );
        if ( $request !== '' ) {
            return $request;
        }

        $request = trim( (string) ( $_REQUEST['fifu_wai_gallery_only_image_list_url'] ?? '' ) );
        if ( $request !== '' ) {
            return $request;
        }

        $persisted = trim( (string) self::get_raw_meta_value( $post_id, 'fifu_list_url' ) );
        if ( $persisted !== '' ) {
            return $persisted;
        }

        if ( ! self::has_db2_post_mappings( $post_id, 'image' ) && class_exists( 'Fifu_Post_Image_List_Url_Read_Service', false ) ) {
            $read_service_value = trim(
                (string) ( Fifu_Post_Image_List_Url_Read_Service::get_image_list_url( $post_id ) ?? '' )
            );

            if ( $read_service_value !== '' ) {
                return $read_service_value;
            }
        }

        return '';
    }

    private static function get_direct_image_list_payload_raw( int $post_id ): string {
        $request = trim( (string) ( $_REQUEST['fifu_wai_image_list_url'] ?? '' ) );
        if ( $request !== '' ) {
            return $request;
        }

        $request = trim( (string) ( $_REQUEST['fifu_wai_gallery_only_image_list_url'] ?? '' ) );
        if ( $request !== '' ) {
            return $request;
        }

        return trim( (string) self::get_raw_meta_value( $post_id, 'fifu_list_url' ) );
    }

    private static function get_explicit_image_alt_list_payload_raw( int $post_id ): string {
        $request = trim( (string) ( $_REQUEST['fifu_wai_image_list_alt'] ?? '' ) );
        if ( $request !== '' ) {
            return $request;
        }

        $request = trim( (string) ( $_REQUEST['fifu_wai_gallery_only_image_list_alt'] ?? '' ) );
        if ( $request !== '' ) {
            return $request;
        }

        $persisted = trim( (string) self::get_raw_meta_value( $post_id, 'fifu_list_alt' ) );
        if ( $persisted !== '' ) {
            return $persisted;
        }

        if (
            ! self::has_db2_post_mappings( $post_id, 'image' )
            && class_exists( 'Fifu_Post_Image_List_Alt_Read_Service', false )
        ) {
            $read_service_value = trim(
                (string) ( Fifu_Post_Image_List_Alt_Read_Service::get_image_list_alt( $post_id ) ?? '' )
            );

            if ( $read_service_value !== '' ) {
                return $read_service_value;
            }
        }

        return '';
    }

    private static function get_effective_video_list_raw( int $post_id ): string {
        if ( array_key_exists( 'fifu_wai_video_list_url', $_REQUEST ) ) {
            return trim( (string) $_REQUEST['fifu_wai_video_list_url'] );
        }

        if ( array_key_exists( 'fifu_wai_gallery_only_video_list_url', $_REQUEST ) ) {
            return trim( (string) $_REQUEST['fifu_wai_gallery_only_video_list_url'] );
        }

        $persisted = trim( (string) self::get_raw_meta_value( $post_id, 'fifu_list_video_url' ) );
        if ( $persisted !== '' ) {
            return $persisted;
        }

        if ( class_exists( 'Fifu_Post_Video_List_Url_Read_Service', false ) ) {
            return (string) ( Fifu_Post_Video_List_Url_Read_Service::get_video_list_url( $post_id ) ?? '' );
        }

        return '';
    }

    private static function get_effective_slider_list_raw( int $post_id ): string {
        $request = trim( (string) ( $_REQUEST['fifu_wai_gallery_only_slider_list_url'] ?? '' ) );
        if ( $request !== '' ) {
            return $request;
        }

        $persisted = trim( (string) self::get_raw_meta_value( $post_id, 'fifu_slider_list_url' ) );
        if ( $persisted !== '' ) {
            return $persisted;
        }

        if ( class_exists( 'Fifu_Post_Slider_List_Url_Read_Service', false ) ) {
            return (string) ( Fifu_Post_Slider_List_Url_Read_Service::get_slider_list_url( $post_id ) ?? '' );
        }

        return '';
    }

    private static function has_current_import_image_list_payload( int $post_id ): bool {
        if ( self::get_explicit_image_list_payload_raw( $post_id ) !== '' ) {
            return true;
        }

        if ( self::should_force_gallery_only_db2_rebuild( $post_id ) ) {
            return true;
        }

        return false;
    }

    private static function has_current_import_video_list_payload( int $post_id ): bool {
        if ( self::get_effective_video_list_raw( $post_id ) !== '' ) {
            return true;
        }

        if ( self::should_force_video_gallery_only_db2_rebuild( $post_id ) ) {
            return true;
        }

        return false;
    }

    public static function save_video_list( int $post_id, ?bool $is_category, ?bool $video_priority ): void {
        $persisted_video_list_raw = self::get_raw_meta_value( $post_id, 'fifu_list_video_url' );
        $legacy_video_list_raw = self::get_effective_video_list_raw( $post_id );
        $legacy_video_entries = self::parse_legacy_list( $legacy_video_list_raw );
        $has_explicit_video_list_payload =
            array_key_exists( 'fifu_wai_video_list_url', $_REQUEST )
            || array_key_exists( 'fifu_wai_gallery_only_video_list_url', $_REQUEST );
        $legacy_video_singleton = trim( (string) self::get_raw_meta_value( $post_id, 'fifu_video_url' ) );
        $legacy_custom_video_singleton = trim( (string) self::get_raw_meta_value( $post_id, 'fifu_custom_video_url' ) );
        $current_custom_video_source = trim( (string) ( $_REQUEST['fifu_wai_custom_video_source'] ?? '' ) );
        $video_gallery_only_rebuild = self::should_force_video_gallery_only_db2_rebuild( $post_id );
        $custom_featured_video_source = '';

        if ( $current_custom_video_source !== '' && self::is_custom_featured_video_payload( $current_custom_video_source ) ) {
            $custom_featured_video_source = $current_custom_video_source;
        } elseif (
            ! $is_category
            && $legacy_video_singleton !== ''
            && self::is_custom_featured_video_payload( $legacy_video_singleton )
        ) {
            $custom_featured_video_source = $legacy_video_singleton;
        } elseif (
            ! $is_category
            && $legacy_custom_video_singleton !== ''
            && self::is_custom_featured_video_payload( $legacy_custom_video_singleton )
        ) {
            $custom_featured_video_source = $legacy_custom_video_singleton;
        }

        if ( $video_gallery_only_rebuild ) {
            $legacy_video_list_raw = (string) ( $_REQUEST['fifu_wai_gallery_only_video_list_url'] ?? $legacy_video_list_raw );
            $legacy_video_entries = self::parse_legacy_list( $legacy_video_list_raw );
        }

        if (
            $has_explicit_video_list_payload
            && $legacy_video_list_raw === ''
            && empty( $legacy_video_entries )
        ) {
            FIFU_Post_Meta_Updater::instance()->update_or_delete_with_status(
                $post_id,
                'fifu_list_video_url',
                ''
            );

            self::cleanup_legacy_video_list( $post_id );
            return;
        }

        if ( $legacy_video_list_raw !== '' && empty( $legacy_video_entries ) ) {
            self::cleanup_legacy_video_list( $post_id );
            return;
        }

        if ( $legacy_video_list_raw === '' && empty( $legacy_video_entries ) && $custom_featured_video_source !== '' ) {
            self::save_custom_featured_video_source( $post_id, (bool) $is_category, $custom_featured_video_source );
            return;
        }

        $urls = $legacy_video_entries;
        $is_custom_video_singleton = self::is_custom_featured_video_payload( $legacy_video_singleton );
        if ( empty( $urls ) ) {
            if ( $is_custom_video_singleton ) {
                $urls = [ $legacy_video_singleton ];
            } else {
                $video_list = Fifu_Post_Video_List_Url_Read_Service::get_video_list_url( (int) $post_id );
                $urls = $video_list ? self::parse_legacy_list( $video_list ) : [];
                if ( empty( $urls ) && $legacy_video_singleton !== '' ) {
                    $urls = [ $legacy_video_singleton ];
                }
            }
        }

        if ( ! empty( $urls ) ) {
            $video_updater = FIFU_Post_Meta_Updater::instance();
            $normalized_list = implode( '|', array_map( 'trim', $urls ) );
            $has_video_list = ! empty( $legacy_video_entries );
            $has_image_list = self::has_current_import_image_list_payload( $post_id );
            $should_keep_image_main = $legacy_video_singleton !== '' && ! $has_video_list;
            $should_preserve_mixed_media_image_list = isset( $GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import'] )
                && is_array( $GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import'] )
                && array_key_exists( (string) $post_id, $GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import'] );

            if ( $video_gallery_only_rebuild ) {
                $video_updater->update_or_delete_with_status( $post_id, 'fifu_list_video_url', $normalized_list );
                return;
            }

            $should_preserve_image_list = $has_image_list && $has_video_list;
            if ( $should_preserve_mixed_media_image_list ) {
                $should_preserve_image_list = true;
            }
            if ( $should_preserve_image_list ) {
                self::run_preserving_image_list_for_mixed_media_import(
                    $post_id,
                    static function () use ( $post_id, $normalized_list, $video_updater ): void {
                        $video_updater->update_or_delete_with_status( $post_id, 'fifu_list_video_url', $normalized_list );
                    }
                );
            } else {
                $video_updater->update_or_delete_with_status( $post_id, 'fifu_list_video_url', $normalized_list );
            }

            if ( ! $is_category && $legacy_video_singleton !== '' && ! $has_video_list && ! $is_custom_video_singleton ) {
                self::clear_post_featured_image_after_featured_video( $post_id );
                fifu_update_or_delete( $post_id, 'fifu_video_url', $legacy_video_singleton );
            } elseif ( ! $is_category && $video_priority === true && ! $has_image_list ) {
                self::clear_post_featured_image_after_featured_video( $post_id );
            } elseif ( ! $is_category && $video_priority === true && $has_image_list && ! $should_preserve_mixed_media_image_list ) {
                // Mixed media imports must keep the image list intact in DB2.
                // Video priority only changes which media is treated as primary in legacy flows.
            }
        } else {
            if ( $persisted_video_list_raw !== '' ) {
                self::cleanup_legacy_video_list( $post_id );
            }

            if ( $is_category ) {
                $url = self::get_raw_term_meta_value( $post_id, 'fifu_video_url' );
                if ( $url === '' && class_exists( 'Fifu_Term_Video_Read_Service', false ) ) {
                    $url = (string) ( Fifu_Term_Video_Read_Service::get_video_url( (int) $post_id ) ?? '' );
                }
                if ( $url ) {
                    if ( self::is_custom_featured_video_payload( $url ) ) {
                        self::save_custom_featured_video_source( $post_id, true, $url );
                    } else {
                        fifu_update_or_delete_ctgr( $post_id, 'fifu_video_url', $url );
                    }
                }
            } else {
                $url = (string) ( $_REQUEST['fifu_wai_custom_video_source'] ?? get_post_meta( $post_id, 'fifu_video_url', true ) );
                if ( $url === '' && class_exists( 'Fifu_Post_Video_Read_Service', false ) ) {
                    $url = (string) ( Fifu_Post_Video_Read_Service::get_video_url( (int) $post_id ) ?? '' );
                }
                if ( $url ) {
                    if ( self::is_custom_featured_video_payload( $url ) ) {
                        self::save_custom_featured_video_source( $post_id, false, $url );
                    } else {
                        fifu_update_or_delete( $post_id, 'fifu_video_url', $url );
                        if ( $video_priority ) {
                            fifu_delete_post_meta( $post_id, 'fifu_image_url' );
                        }
                    }
                }
            }
        }
    }

    public static function save_product_image_list_fast_from_import_payload(
        int $post_id,
        string $image_list_url,
        string $image_list_alt = '',
        bool $video_priority = false
    ): array {
        self::$lastImageListDb2UrlsConfirmed = false;

        $explicit_urls = self::parse_legacy_list( $image_list_url );
        $explicit_alts = $image_list_alt !== ''
            ? self::parse_legacy_list_preserve_empty_slots( $image_list_alt )
            : [];

        $normalized_urls = [];
        foreach ( $explicit_urls as $url ) {
            $url = trim( (string) $url );
            if ( $url === '' ) {
                continue;
            }

            $normalized_urls[] = $url;
        }

        if ( empty( $normalized_urls ) ) {
            return [
                'urls_confirmed' => false,
                'alts_confirmed' => false,
            ];
        }

        $manager = self::get_db2_manager_or_null();
        if ( $manager === null ) {
            return [
                'urls_confirmed' => false,
                'alts_confirmed' => false,
            ];
        }

        if (!self::ensure_db2_key_type_exists_for_fast_import('image')) {
            return [
                'urls_confirmed' => false,
                'alts_confirmed' => false,
            ];
        }

        if (method_exists($manager, 'clearKeyCache')) {
            $manager->clearKeyCache();
        }

        $normalized_alts = self::normalize_image_alt_list_for_urls(
            $explicit_alts,
            count( $normalized_urls )
        );

        if ( method_exists( $manager, 'deletePostMappings' ) ) {
            $manager->deletePostMappings( $post_id, 'image' );
        }

        if ( method_exists( $manager, 'deletePostAltMappings' ) ) {
            $manager->deletePostAltMappings( $post_id, 'image' );
        }

        $urls_saved = false;

        if ( method_exists( $manager, 'savePostImageListFastInsert' ) ) {
            $urls_saved = (bool) $manager->savePostImageListFastInsert( $post_id, array_values( $normalized_urls ) );
        } elseif ( method_exists( $manager, 'savePostUrlListFastInsert' ) ) {
            $urls_saved = (bool) $manager->savePostUrlListFastInsert( $post_id, 'image', array_values( $normalized_urls ) );
        }

        if ( ! $urls_saved ) {
            foreach ( $normalized_urls as $index => $url ) {
                $ok = false;

                if ( method_exists( $manager, 'savePostImageFastInsert' ) ) {
                    $ok = $manager->savePostImageFastInsert( $post_id, $url, (int) $index );
                } elseif ( method_exists( $manager, 'savePostUrl' ) ) {
                    $ok = $manager->savePostUrl( $post_id, 'image', (int) $index, $url );
                }

                if ( ! $ok ) {
                    self::$lastImageListDb2UrlsConfirmed = false;

                    return [
                        'urls_confirmed' => false,
                        'alts_confirmed' => false,
                    ];
                }
            }
        }

        $alts_saved = true;

        if ( ! empty( $normalized_alts ) ) {
            if ( method_exists( $manager, 'savePostAltListFastInsert' ) ) {
                $alts_saved = (bool) $manager->savePostAltListFastInsert( $post_id, 'image', array_values( $normalized_alts ) );
            } else {
                foreach ( $normalized_alts as $index => $alt ) {
                    $alt = self::normalize_image_alt_slot( (string) $alt );

                    if ( $alt === '' ) {
                        continue;
                    }

                    $ok = false;

                    if ( method_exists( $manager, 'savePostImageAltFastInsert' ) ) {
                        $ok = $manager->savePostImageAltFastInsert( $post_id, $alt, (int) $index );
                    } elseif ( method_exists( $manager, 'savePostAlt' ) ) {
                        $ok = $manager->savePostAlt( $post_id, 'image', (int) $index, $alt );
                    }

                    if ( ! $ok ) {
                        $alts_saved = false;
                        break;
                    }
                }
            }
        }

        $confirmation = self::db2_product_image_list_confirmation_result(
            $post_id,
            $normalized_urls,
            $normalized_alts
        );

        $urls_confirmed = (bool) $confirmation['urls_confirmed'];
        $alts_confirmed = $alts_saved && (bool) $confirmation['alts_confirmed'];

        self::$lastImageListDb2UrlsConfirmed = $urls_confirmed;

        return [
            'urls_confirmed' => $urls_confirmed,
            'alts_confirmed' => $alts_confirmed,
        ];
    }

    public static function save_product_slider_list_fast_from_import_payload(
        int $object_id,
        string $slider_list_url,
        string $slider_list_alt,
        bool $clear_conflicting_media,
        bool $delete_existing = true
    ): array {
        return self::save_slider_list_fast_from_import_payload(
            $object_id,
            $slider_list_url,
            $slider_list_alt,
            $clear_conflicting_media,
            $delete_existing
        );
    }

    public static function save_slider_list_fast_from_import_payload(
        int $object_id,
        string $slider_list_url,
        string $slider_list_alt,
        bool $clear_conflicting_media,
        bool $delete_existing = true
    ): array {
        $post_id = $object_id;
        $manager = fifu_db2_manager();

        $normalized_urls = self::split_normalized_wai_list( $slider_list_url );
        $normalized_alts = self::split_normalized_wai_alt_list_preserve_empty_slots( $slider_list_alt );
        if ( $normalized_urls === [] ) {
            return [
                'urls_confirmed' => false,
                'alts_confirmed' => true,
            ];
        }

        if ( $delete_existing ) {
            if ( method_exists( $manager, 'deletePostMappings' ) ) {
                $manager->deletePostMappings( $post_id, 'slider', null );

                if ( $clear_conflicting_media ) {
                    $manager->deletePostMappings( $post_id, 'image', null );
                    $manager->deletePostMappings( $post_id, 'video', null );
                    $manager->deletePostMappings( $post_id, 'custom_video', null );
                }
            }

            if ( method_exists( $manager, 'deletePostAltMappings' ) ) {
                $manager->deletePostAltMappings( $post_id, 'slider', null );

                if ( $clear_conflicting_media ) {
                    $manager->deletePostAltMappings( $post_id, 'image', null );
                    $manager->deletePostAltMappings( $post_id, 'video', null );
                    $manager->deletePostAltMappings( $post_id, 'custom_video', null );
                }
            }
        }

        $urls_saved = false;

        if ( self::legacy_write_bridge_failed_for_meta_key( 'fifu_slider_list_url' ) ) {
            $urls_saved = false;
        } elseif ( method_exists( $manager, 'savePostUrlListFastInsert' ) ) {
            $url_result = $manager->savePostUrlListFastInsert( $post_id, 'slider', array_values( $normalized_urls ) );
            $urls_saved = $url_result === true || ( is_int( $url_result ) && $url_result >= 0 );
        }

        if ( ! $urls_saved ) {
            return [
                'urls_confirmed' => false,
                'alts_confirmed' => false,
            ];
        }

        $alts_confirmed = true;
        if ( $normalized_alts !== [] && method_exists( $manager, 'savePostAltListFastInsert' ) ) {
            if ( self::legacy_write_bridge_failed_for_meta_key( 'fifu_slider_list_alt' ) ) {
                $alts_confirmed = false;
            } else {
                $alt_result = $manager->savePostAltListFastInsert( $post_id, 'slider', $normalized_alts );
                if ( is_array( $alt_result ) ) {
                    $alts_saved = ! empty( $alt_result['alts_confirmed'] );
                } else {
                    $alts_saved = $alt_result === true || ( is_int( $alt_result ) && $alt_result >= 0 );
                }
                $alts_confirmed = $alts_saved;
            }
        }

        $urls_confirmed = self::db2_slider_urls_confirmed( $post_id, $manager, $normalized_urls );

        if ( $alts_confirmed ) {
            $alts_confirmed = self::db2_slider_alts_confirmed(
                $post_id,
                $manager,
                $normalized_urls,
                $normalized_alts
            );

        }

        return [
            'urls_confirmed' => $urls_confirmed,
            'alts_confirmed' => $alts_confirmed,
        ];
    }

    private static function clear_post_featured_image_after_featured_video( int $post_id ): void {
        fifu_delete_post_meta( $post_id, 'fifu_image_url' );
        fifu_delete_post_meta( $post_id, 'fifu_image_alt' );
    }

    private static function legacy_write_bridge_failed_for_meta_key( string $metaKey ): bool {
        if ( ! function_exists( 'fifu_db2_legacy_write_bridge' ) ) {
            return false;
        }

        $bridge = fifu_db2_legacy_write_bridge();
        if ( ! is_object( $bridge ) || ! property_exists( $bridge, 'forcedFailuresByMetaKey' ) ) {
            return false;
        }

        try {
            $reflection = new \ReflectionProperty( $bridge, 'forcedFailuresByMetaKey' );
            $forcedFailures = $reflection->getValue( $bridge );
        } catch ( \Throwable $exception ) {
            return false;
        }

        return is_array( $forcedFailures ) && ! empty( $forcedFailures[ $metaKey ] );
    }

    private static function get_raw_meta_value( int $post_id, string $meta_key ): string {
        global $wpdb;

        if ( ! isset( $wpdb ) || ! is_object( $wpdb ) || ! property_exists( $wpdb, 'postmeta' ) ) {
            return '';
        }

        $table = $wpdb->postmeta;
        $value = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT meta_value FROM {$table} WHERE post_id = %d AND meta_key = %s LIMIT 1",
                $post_id,
                $meta_key
            )
        );

        return $value === null ? '' : (string) $value;
    }

    private static function split_custom_video_entry( string $value ): array {
        $value = trim( $value );
        if ( $value === '' ) {
            return [
                '',
                '',
                false,
            ];
        }

        if ( strpos( $value, '\\' ) !== false ) {
            $parts = explode( '\\', $value, 2 );
            $video = trim( (string) ( $parts[0] ?? '' ) );
            $image = trim( (string) ( $parts[1] ?? '' ) );
            return [
                $video,
                $image,
                $image !== '',
            ];
        }

        $matches = [];
        preg_match_all( '#https?://#i', $value, $matches, PREG_OFFSET_CAPTURE );
        if ( isset( $matches[0][1][1] ) ) {
            $secondHttpPos = $matches[0][1][1];
            $image = substr( $value, $secondHttpPos );
            return [
                substr( $value, 0, $secondHttpPos ),
                $image,
                $image !== '',
            ];
        }

        return [
            $value,
            '',
            false,
        ];
    }

    private static function is_custom_featured_video_payload( string $value ): bool {
        $value = trim( $value );
        if ( $value === '' ) {
            return false;
        }

        if ( strpos( $value, '\\' ) !== false ) {
            [ $video_url, $image_url, $has_custom_image ] = self::split_custom_video_entry( $value );
            return trim( (string) $video_url ) !== '' && $has_custom_image && trim( (string) $image_url ) !== '';
        }

        return false;
    }

    private static function get_raw_term_meta_value( int $term_id, string $meta_key ): string {
        global $wpdb;

        if ( ! isset( $wpdb ) || ! is_object( $wpdb ) || ! property_exists( $wpdb, 'termmeta' ) ) {
            return '';
        }

        $table = $wpdb->termmeta;
        $value = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT meta_value FROM {$table} WHERE term_id = %d AND meta_key = %s LIMIT 1",
                $term_id,
                $meta_key
            )
        );

        return $value === null ? '' : (string) $value;
    }

    private static function save_term_image( int $term_id ): void {
        $term_url = trim( self::get_raw_term_meta_value( $term_id, 'fifu_image_url' ) );
        $term_alt = trim( self::get_raw_term_meta_value( $term_id, 'fifu_image_alt' ) );

        if ( $term_url === '' && class_exists( 'Fifu_Term_Image_Url_Read_Service', false ) ) {
            $term_url = trim( (string) ( Fifu_Term_Image_Url_Read_Service::get_image_url( $term_id ) ?? '' ) );
        }

        if ( $term_alt === '' && class_exists( 'Fifu_Term_Image_Alt_Read_Service', false ) ) {
            $term_alt = trim( (string) ( Fifu_Term_Image_Alt_Read_Service::get_image_alt( $term_id ) ?? '' ) );
        }

        if ( $term_url === '' ) {
            fifu_delete_term_meta( $term_id, 'fifu_image_url' );
            fifu_delete_term_meta( $term_id, 'fifu_image_alt' );
            return;
        }

        fifu_update_or_delete_ctgr( $term_id, 'fifu_image_url', $term_url );

        if ( $term_alt !== '' ) {
            fifu_update_or_delete_ctgr( $term_id, 'fifu_image_alt', $term_alt );
        } else {
            fifu_delete_term_meta( $term_id, 'fifu_image_alt' );
        }
    }

    private static function can_cleanup_term_custom_video_source_meta( int $term_id, string $source_value ): bool {
        if ( ! function_exists( 'fifu_db2_manager' ) ) {
            return false;
        }

        $manager = fifu_db2_manager();
        if ( ! $manager instanceof Fifu_Db2_Manager ) {
            return false;
        }

        [$video_url, $image_url] = self::split_custom_video_entry( $source_value );
        $expected_custom_video_url = trim( (string) $video_url );
        $expected_poster_url = trim( (string) $image_url );

        if ( $expected_custom_video_url === '' ) {
            return false;
        }

        $custom_video_mapping = $manager->getTermMapping( $term_id, 'custom_video' );
        if (
            ! is_array( $custom_video_mapping ) ||
            empty( $custom_video_mapping['url'] ) ||
            (string) $custom_video_mapping['url'] !== $expected_custom_video_url
        ) {
            return false;
        }

        global $wpdb;
        $keyTable = $wpdb->prefix . 'fifu_key';
        if ( 0 === (int) $wpdb->get_var( $wpdb->prepare( "SELECT 1 FROM {$keyTable} WHERE key_type = %s LIMIT 1", 'image' ) ) ) {
            return false;
        }

        if ( $expected_poster_url === '' ) {
            return true;
        }

        return self::custom_video_poster_matches_oembed( $expected_custom_video_url, $expected_poster_url );
    }

    private static function can_cleanup_post_custom_video_source_meta( int $post_id, string $source_value ): bool {
        if ( ! function_exists( 'fifu_db2_manager' ) ) {
            return false;
        }

        $manager = fifu_db2_manager();
        if ( ! $manager instanceof Fifu_Db2_Manager ) {
            return false;
        }

        [ $video_url, $image_url, $has_custom_image ] = self::split_custom_video_entry( $source_value );
        $expected_custom_video_url = trim( (string) $video_url );
        $expected_poster_url = trim( (string) $image_url );

        if ( $expected_custom_video_url === '' ) {
            return false;
        }

        global $wpdb;
        $keyTable = $wpdb->prefix . 'fifu_key';
        $customVideoKeyExists = (bool) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT 1 FROM {$keyTable} WHERE key_type = %s LIMIT 1",
                'custom_video'
            )
        );
        if ( ! $customVideoKeyExists ) {
            return false;
        }

        $custom_video_mapping = $manager->getPostMapping( $post_id, 'custom_video', 0 );
        if (
            ! is_array( $custom_video_mapping ) ||
            empty( $custom_video_mapping['url'] ) ||
            (string) $custom_video_mapping['url'] !== $expected_custom_video_url
        ) {
            return false;
        }

        global $wpdb;
        $keyTable = $wpdb->prefix . 'fifu_key';
        if ( 0 === (int) $wpdb->get_var( $wpdb->prepare( "SELECT 1 FROM {$keyTable} WHERE key_type = %s LIMIT 1", 'image' ) ) ) {
            return false;
        }

        if ( ! $has_custom_image ) {
            return true;
        }

        if ( $expected_poster_url === '' ) {
            return false;
        }

        return self::custom_video_poster_matches_oembed( $expected_custom_video_url, $expected_poster_url );
    }

    private static function custom_video_poster_matches_oembed( string $video_url, string $expected_poster_url ): bool {
        if ( $expected_poster_url === '' ) {
            return true;
        }

        if ( ! class_exists( 'Fifu_Video_Oembed_Service', false ) ) {
            return false;
        }

        $service = Fifu_Video_Oembed_Service::instance();
        if ( ! method_exists( $service, 'get_repository' ) ) {
            return false;
        }

        $repository = $service->get_repository();
        if ( ! method_exists( $repository, 'get_image_url_by_video_url' ) ) {
            return false;
        }

        if ( (string) $repository->get_image_url_by_video_url( $video_url ) !== $expected_poster_url ) {
            return false;
        }

        return (string) $repository->get_embed_url_by_video_url( $video_url ) === $video_url;
    }

    private static function persist_custom_video_poster( string $video_url, string $poster_url ): bool {
        if ( ! class_exists( 'Fifu_Video_Oembed_Service', false ) ) {
            return false;
        }

        return (bool) Fifu_Video_Oembed_Service::instance()->upsert_oembed( $video_url, $poster_url, $video_url );
    }

    private static function save_custom_video_to_db2( int $object_id, bool $is_category, string $video_url ): bool {
        if ( ! function_exists( 'fifu_db2_manager' ) ) {
            return false;
        }

        $manager = fifu_db2_manager();
        if ( ! $manager instanceof Fifu_Db2_Manager ) {
            return false;
        }

        if ( $is_category && method_exists( $manager, 'saveTermUrl' ) ) {
            return (bool) $manager->saveTermUrl( $object_id, 'custom_video', $video_url );
        }

        if ( ! $is_category && method_exists( $manager, 'savePostUrl' ) ) {
            return (bool) $manager->savePostUrl( $object_id, 'custom_video', 0, $video_url );
        }

        return false;
    }

    private static function rollback_custom_video_to_db2( int $object_id, bool $is_category ): void {
        if ( ! function_exists( 'fifu_db2_manager' ) ) {
            return;
        }

        $manager = fifu_db2_manager();
        if ( ! $manager instanceof Fifu_Db2_Manager ) {
            return;
        }

        if ( $is_category && method_exists( $manager, 'deleteTermMappings' ) ) {
            $manager->deleteTermMappings( $object_id, 'custom_video' );
            return;
        }

        if ( ! $is_category && method_exists( $manager, 'deletePostMappings' ) ) {
            $manager->deletePostMappings( $object_id, 'custom_video', 0 );
        }
    }

    private static function save_custom_featured_video_source( int $object_id, bool $is_category, string $source_value ): void {
        [ $video_url, $image_url, $has_custom_image ] = self::split_custom_video_entry( $source_value );

        $video_url = trim( (string) $video_url );
        $image_url = trim( (string) $image_url );

        if ( $video_url === '' ) {
            return;
        }

        if ( ! $has_custom_image || $image_url === '' ) {
            if ( $is_category ) {
                fifu_update_or_delete_ctgr( $object_id, 'fifu_video_url', $video_url );
            } else {
                fifu_update_or_delete( $object_id, 'fifu_video_url', $video_url );
            }
            return;
        }

        if ( $is_category ) {
            fifu_update_or_delete_ctgr( $object_id, 'fifu_custom_video_url', $video_url );
        } else {
            fifu_update_or_delete( $object_id, 'fifu_custom_video_url', $video_url );
        }

        $saved_to_db2 = self::save_custom_video_to_db2( $object_id, $is_category, $video_url );

        if ( ! $saved_to_db2 ) {
            return;
        }

        if ( $image_url === '' ) {
            self::rollback_custom_video_to_db2( $object_id, $is_category );
            return;
        }

        $poster_saved = self::persist_custom_video_poster( $video_url, $image_url );
        if ( ! $poster_saved || ! self::custom_video_poster_matches_oembed( $video_url, $image_url ) ) {
            self::rollback_custom_video_to_db2( $object_id, $is_category );
            return;
        }

        if ( $is_category ) {
            if ( self::can_cleanup_term_custom_video_source_meta( $object_id, $source_value ) ) {
                self::delete_legacy_term_meta_only( $object_id, 'fifu_video_url' );
            }
            return;
        }

        if ( self::can_cleanup_post_custom_video_source_meta( $object_id, $source_value ) ) {
            self::delete_legacy_post_meta_only( $object_id, 'fifu_video_url' );
        }
    }

    private static function should_cleanup_legacy_list( string $value ): bool {
        if ( $value === '' ) {
            return false;
        }

        return empty( self::parse_legacy_list( $value ) );
    }

    private static function parse_legacy_list( string $value ): array {
        $value = trim( $value );
        if ( $value === '' ) {
            return [];
        }

        $delimiter = strpos( $value, PHP_EOL ) !== false && strpos( $value, '|' ) === false ? PHP_EOL : '|';
        $value = rtrim( $value, $delimiter );
        if ( $value === '' ) {
            return [];
        }

        $parts = array_map( 'trim', explode( $delimiter, $value ) );
        return array_values( array_filter( $parts, static fn( string $entry ): bool => $entry !== '' ) );
    }

    private static function parse_legacy_list_preserve_empty_slots( string $value ): array {
        $value = trim( $value );
        if ( $value === '' ) {
            return [];
        }

        $delimiter = strpos( $value, PHP_EOL ) !== false && strpos( $value, '|' ) === false ? PHP_EOL : '|';
        return array_map( 'trim', explode( $delimiter, $value ) );
    }

    /**
     * Split an already-normalized WAI pipe-separated list and discard empty URL slots.
     *
     * @return array<int, string>
     */
    private static function split_normalized_wai_list(string $value): array
    {
        $value = trim(rtrim($value, '|'));

        if ($value === '') {
            return [];
        }

        $parts = array_map(
            static fn(string $segment): string => trim($segment),
            explode('|', $value)
        );

        return array_values(array_filter(
            $parts,
            static fn(string $segment): bool => $segment !== ''
        ));
    }

    /**
     * Split an already-normalized WAI pipe-separated ALT list while preserving empty slots.
     *
     * @return array<int, string>
     */
    private static function split_normalized_wai_alt_list_preserve_empty_slots(string $value): array
    {
        $value = trim(rtrim($value, '|'));

        if ($value === '') {
            return [];
        }

        $parts = explode('|', $value);
        $normalized = [];

        foreach ( $parts as $index => $segment ) {
            $segment = trim( $segment );

            if ( $segment === '' || preg_match( '/^(null|undefined)$/i', $segment ) === 1 ) {
                $normalized[ $index ] = '';
                continue;
            }

            if ( function_exists( 'wp_strip_all_tags' ) ) {
                $segment = (string) wp_strip_all_tags( $segment );
            } else {
                $segment = strip_tags( $segment );
            }

            $segment = trim( $segment );

            if ( $segment === '' || preg_match( '/^(null|undefined)$/i', $segment ) === 1 ) {
                $normalized[ $index ] = '';
                continue;
            }

            $normalized[ $index ] = $segment;
        }

        return $normalized;
    }

    private static function cleanup_legacy_image_list( int $post_id ): void {
        fifu_delete_post_meta( $post_id, 'fifu_image_url' );

        $index = 0;
        while ( true ) {
            $url = Fifu_Post_Image_List_Read_Service::get_image_url( (int) $post_id, (int) $index );
            if ( $url ) {
                fifu_delete_post_meta( $post_id, 'fifu_image_url_' . $index );
                fifu_delete_post_meta( $post_id, 'fifu_image_alt_' . $index );
            } else {
                break;
            }

            $index++;
        }

        fifu_delete_post_meta( $post_id, 'fifu_list_url' );
        fifu_delete_post_meta( $post_id, 'fifu_list_alt' );
    }

    private static function cleanup_legacy_image_alt_list_only( int $post_id ): void {
        self::delete_raw_post_meta( $post_id, 'fifu_list_alt' );
        self::delete_raw_post_meta( $post_id, 'fifu_image_alt' );

        $meta = get_post_meta( $post_id );
        if ( is_array( $meta ) ) {
            foreach ( array_keys( $meta ) as $metaKey ) {
                if ( preg_match( '/^fifu_image_alt_\d+$/', (string) $metaKey ) === 1 ) {
                    self::delete_raw_post_meta( $post_id, (string) $metaKey );
                }
            }
        }

        clean_post_cache( $post_id );
        if ( function_exists( 'wp_cache_delete' ) ) {
            wp_cache_delete( $post_id, 'post_meta' );
        }
    }

    /**
     * @return array<int, string>
     */
    private static function get_db2_post_image_urls_by_index( int $post_id ): array {
        $manager = self::get_db2_manager_or_null();
        if ( $manager === null || ! method_exists( $manager, 'getPostMappings' ) ) {
            return [];
        }

        $mappings = $manager->getPostMappings( $post_id, 'image' );
        if ( ! is_array( $mappings ) ) {
            return [];
        }

        $urls = [];
        foreach ( $mappings as $mapping ) {
            if ( ! is_array( $mapping ) ) {
                continue;
            }

            $index = (int) ( $mapping['key_index'] ?? -1 );
            $url = trim( (string) ( $mapping['url'] ?? '' ) );
            if ( $index < 0 || $url === '' ) {
                continue;
            }

            $urls[ $index ] = $url;
        }

        if ( $urls === [] ) {
            return [];
        }

        ksort( $urls );
        return $urls;
    }

    /**
     * @param array<int, string> $explicit_alts
     * @param array<int, string> $existing_urls
     * @return array<int, string>
     */
    private static function normalize_alt_slots_for_existing_urls( array $explicit_alts, array $existing_urls ): array {
        if ( $existing_urls === [] ) {
            return [];
        }

        $normalized = [];
        foreach ( array_keys( $existing_urls ) as $index ) {
            $normalized[ $index ] = trim( (string) ( $explicit_alts[ $index ] ?? '' ) );
        }

        return $normalized;
    }

    private static function save_existing_db2_image_list_alts( int $post_id, array $explicit_alts, string $explicit_alt_raw ): bool {
        $existing_urls = self::get_db2_post_image_urls_by_index( $post_id );
        if ( $existing_urls === [] ) {
            $manager = self::get_db2_manager_or_null();
            if ( $manager !== null && method_exists( $manager, 'getPostMappings' ) ) {
                $mappings = $manager->getPostMappings( $post_id, 'image' );
                if ( is_array( $mappings ) ) {
                    foreach ( $mappings as $mapping ) {
                        if ( ! is_array( $mapping ) ) {
                            continue;
                        }

                        $index = (int) ( $mapping['key_index'] ?? -1 );
                        $url = trim( (string) ( $mapping['url'] ?? '' ) );
                        if ( $index < 0 || $url === '' ) {
                            continue;
                        }

                        $existing_urls[ $index ] = $url;
                    }
                    ksort( $existing_urls );
                }
            }

            if ( $existing_urls === [] && $manager !== null && method_exists( $manager, 'getPostMapping' ) ) {
                for ( $index = 0; $index < 100; $index++ ) {
                    $mapping = $manager->getPostMapping( $post_id, 'image', $index );
                    if ( ! is_array( $mapping ) ) {
                        continue;
                    }

                    $url = trim( (string) ( $mapping['url'] ?? '' ) );
                    if ( $url === '' ) {
                        continue;
                    }

                    $existing_urls[ $index ] = $url;
                }
                if ( $existing_urls !== [] ) {
                    ksort( $existing_urls );
                }
            }
        }

        if ( $existing_urls === [] ) {
            self::set_raw_post_meta( $post_id, 'fifu_list_alt', $explicit_alt_raw );
            self::$lastImageListDb2UrlsConfirmed = false;
            return false;
        }

        $normalized_alt_list = self::normalize_alt_slots_for_existing_urls( $explicit_alts, $existing_urls );
        foreach ( $normalized_alt_list as $index => $alt ) {
            $normalized_alt_list[ $index ] = self::normalize_image_alt_slot( (string) $alt );
        }

        $ok_alt = true;
        $write_service = function_exists( 'fifu_db2_write_service' ) ? fifu_db2_write_service() : null;
        if ( ! is_object( $write_service ) || ! method_exists( $write_service, 'save_post_image_alt_at_index' ) || ! method_exists( $write_service, 'delete_post_image_alt' ) ) {
            self::set_raw_post_meta( $post_id, 'fifu_list_alt', $explicit_alt_raw );
            self::$lastImageListDb2UrlsConfirmed = false;
            return false;
        }

        foreach ( $existing_urls as $index => $_existing_url ) {
            $alt = (string) ( $normalized_alt_list[ $index ] ?? '' );
            if ( $alt === '' ) {
                $write_service->delete_post_image_alt( $post_id, (int) $index );
                continue;
            }

            if ( ! $write_service->save_post_image_alt_at_index( $post_id, (int) $index, $alt ) ) {
                $ok_alt = false;
            }
        }

        if ( ! $ok_alt ) {
            self::set_raw_post_meta( $post_id, 'fifu_list_alt', $explicit_alt_raw );
            self::$lastImageListDb2UrlsConfirmed = false;
            return false;
        }

        if ( ! self::db2_image_list_round_trip_matches( $post_id, array_values( $existing_urls ), $normalized_alt_list ) ) {
            self::set_raw_post_meta( $post_id, 'fifu_list_alt', $explicit_alt_raw );
            self::$lastImageListDb2UrlsConfirmed = false;
            return false;
        }

        if ( method_exists( $manager = self::get_db2_manager_or_null(), 'clearKeyCache' ) ) {
            $manager->clearKeyCache();
        }
        self::cleanup_legacy_image_alt_list_only( $post_id );
        self::$lastImageListDb2UrlsConfirmed = true;
        return true;
    }

    private static function preserve_legacy_image_list_on_db2_failure( int $post_id, ?string $legacy_list_raw, ?string $legacy_alt_raw, array $normalized_urls, array $normalized_alts ): void {
        if ( $legacy_list_raw !== null && $legacy_list_raw !== '' ) {
            self::set_raw_post_meta( $post_id, 'fifu_list_url', $legacy_list_raw );
        }

        if ( $legacy_alt_raw !== null && $legacy_alt_raw !== '' ) {
            self::set_raw_post_meta( $post_id, 'fifu_list_alt', $legacy_alt_raw );
        }
    }

    private static function preserve_legacy_image_alt_list_on_db2_alt_failure( int $post_id, string $legacy_alt_raw ): void {
        if ( $legacy_alt_raw === '' ) {
            return;
        }

        self::set_raw_post_meta( $post_id, 'fifu_list_alt', $legacy_alt_raw );
    }

    private static function cleanup_legacy_image_url_list_only( int $post_id ): void {
        self::delete_raw_post_meta( $post_id, 'fifu_list_url' );
        self::delete_raw_post_meta( $post_id, 'fifu_image_url' );

        $meta = get_post_meta( $post_id );
        if ( is_array( $meta ) ) {
            foreach ( array_keys( $meta ) as $metaKey ) {
                if ( preg_match( '/^fifu_image_url_\d+$/', (string) $metaKey ) === 1 ) {
                    self::delete_raw_post_meta( $post_id, (string) $metaKey );
                }
            }
        }

        clean_post_cache( $post_id );
        if ( function_exists( 'wp_cache_delete' ) ) {
            wp_cache_delete( $post_id, 'post_meta' );
        }
    }

    private static function delete_raw_post_meta( int $post_id, string $meta_key ): void {
        global $wpdb;

        if ( ! isset( $wpdb ) || ! is_object( $wpdb ) || ! property_exists( $wpdb, 'postmeta' ) ) {
            return;
        }

        $wpdb->delete(
            $wpdb->postmeta,
            [
                'post_id'  => $post_id,
                'meta_key' => $meta_key,
            ],
            [
                '%d',
                '%s',
            ]
        );
    }

    private static function normalize_image_alt_list_for_urls( array $explicit_alts, int $url_count ): array {
        if ( $url_count <= 0 || empty( $explicit_alts ) ) {
            return [];
        }

        $normalized = [];
        for ( $index = 0; $index < $url_count; $index++ ) {
            $value = self::normalize_image_alt_slot( (string) ( $explicit_alts[ $index ] ?? '' ) );
            $normalized[ $index ] = $value;
        }

        return $normalized;
    }

    private static function normalize_image_alt_slot( string $alt ): string {
        $alt = trim( $alt );

        if ( $alt === '' || preg_match( '/^(null|undefined)$/i', $alt ) === 1 ) {
            return '';
        }

        if ( function_exists( 'wp_strip_all_tags' ) ) {
            $alt = (string) wp_strip_all_tags( $alt );
        } else {
            $alt = strip_tags( $alt );
        }

        $alt = trim( $alt );

        if ( $alt === '' || preg_match( '/^(null|undefined)$/i', $alt ) === 1 ) {
            return '';
        }

        return $alt;
    }

    private static function set_raw_post_meta( int $post_id, string $meta_key, string $meta_value ): void {
        global $wpdb;

        if ( ! isset( $wpdb ) || ! is_object( $wpdb ) || ! property_exists( $wpdb, 'postmeta' ) ) {
            return;
        }

        $table = $wpdb->postmeta;
        $existing_id = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT meta_id FROM {$table} WHERE post_id = %d AND meta_key = %s LIMIT 1",
                $post_id,
                $meta_key
            )
        );

        if ( $existing_id ) {
            $wpdb->update(
                $table,
                [ 'meta_value' => $meta_value ],
                [ 'meta_id' => (int) $existing_id ],
                [ '%s' ],
                [ '%d' ]
            );
        } else {
            $wpdb->insert(
                $table,
                [
                    'post_id'    => $post_id,
                    'meta_key'   => $meta_key,
                    'meta_value' => $meta_value,
                ],
                [ '%d', '%s', '%s' ]
            );
        }

        if ( function_exists( 'clean_post_cache' ) ) {
            clean_post_cache( $post_id );
        }

        if ( function_exists( 'wp_cache_delete' ) ) {
            wp_cache_delete( $post_id, 'post_meta' );
        }
    }

    private static function db2_image_list_round_trip_matches( int $post_id, array $expected_urls, ?array $expected_alts ): bool {
        $manager = self::get_db2_manager_or_null();
        if ( $manager === null ) {
            return false;
        }

        if ( ! method_exists( $manager, 'getPostMappings' ) ) {
            return false;
        }

        $mappings = $manager->getPostMappings( $post_id, 'image' );
        if ( ! is_array( $mappings ) ) {
            return false;
        }

        if ( ! self::db2_image_url_mappings_match_expected_list( $mappings, array_values( $expected_urls ) ) ) {
            return false;
        }

        if ( $expected_alts === null ) {
            return true;
        }

        if ( ! method_exists( $manager, 'getPostAltMappings' ) ) {
            return false;
        }

        $alt_mappings = $manager->getPostAltMappings( $post_id, 'image' );
        if ( ! is_array( $alt_mappings ) ) {
            return false;
        }

        return self::db2_image_alt_mappings_match_expected_list(
            $alt_mappings,
            array_values( $expected_alts ),
            count( $expected_urls )
        );
    }

    /**
     * @param array<int|string, mixed> $mappings
     * @param array<int, string> $expected_urls
     */
    private static function db2_image_url_mappings_match_expected_list( array $mappings, array $expected_urls ): bool {
        if ( count( $mappings ) !== count( $expected_urls ) ) {
            return false;
        }

        $by_index = self::db2_mappings_by_index( $mappings, 'url' );

        foreach ( array_values( $expected_urls ) as $index => $expected_url ) {
            $expected_url = trim( (string) $expected_url );

            if ( ! array_key_exists( $index, $by_index ) ) {
                return false;
            }

            if ( trim( (string) $by_index[ $index ] ) !== $expected_url ) {
                return false;
            }
        }

        return true;
    }

    /**
     * @param array<int|string, mixed> $alt_mappings
     * @param array<int, string> $expected_alts
     */
    private static function db2_image_alt_mappings_match_expected_list( array $alt_mappings, array $expected_alts, int $url_count ): bool {
        $by_index = self::db2_mappings_by_index( $alt_mappings, 'alt' );

        for ( $index = 0; $index < $url_count; $index++ ) {
            $expected_alt = trim( (string) ( $expected_alts[ $index ] ?? '' ) );
            $actual_alt = trim( (string) ( $by_index[ $index ] ?? '' ) );

            if ( $expected_alt === '' ) {
                if ( $actual_alt !== '' ) {
                    return false;
                }

                continue;
            }

            if ( ! array_key_exists( $index, $by_index ) ) {
                return false;
            }

            if ( $actual_alt !== $expected_alt ) {
                return false;
            }
        }

        foreach ( $by_index as $index => $actual_alt ) {
            if ( (int) $index >= $url_count && trim( (string) $actual_alt ) !== '' ) {
                return false;
            }
        }

        return true;
    }

    /**
     * @param array<int|string, mixed> $mappings
     * @return array<int, string>
     */
    private static function db2_mappings_by_index( array $mappings, string $value_key ): array {
        $by_index = [];

        foreach ( $mappings as $array_index => $mapping ) {
            $key_index = null;
            $value = null;

            if ( is_array( $mapping ) ) {
                if ( array_key_exists( 'key_index', $mapping ) ) {
                    $key_index = (int) $mapping['key_index'];
                } elseif ( is_int( $array_index ) || ctype_digit( (string) $array_index ) ) {
                    $key_index = (int) $array_index;
                }

                if ( array_key_exists( $value_key, $mapping ) ) {
                    $value = $mapping[ $value_key ];
                }
            } elseif ( is_object( $mapping ) ) {
                if ( isset( $mapping->key_index ) ) {
                    $key_index = (int) $mapping->key_index;
                } elseif ( is_int( $array_index ) || ctype_digit( (string) $array_index ) ) {
                    $key_index = (int) $array_index;
                }

                if ( isset( $mapping->{$value_key} ) ) {
                    $value = $mapping->{$value_key};
                }
            }

            if ( $key_index === null ) {
                continue;
            }

            $by_index[ $key_index ] = trim( (string) $value );
        }

        ksort( $by_index );

        return $by_index;
    }

    /**
     * @param array<int, string> $expected_urls
     * @param array<int, string> $expected_alts
     * @return array{urls_confirmed: bool, alts_confirmed: bool}
     */
    private static function db2_product_image_list_confirmation_result( int $post_id, array $expected_urls, array $expected_alts ): array {
        $manager = self::get_db2_manager_or_null();
        if ( $manager === null || ! method_exists( $manager, 'getPostMappings' ) ) {
            return [
                'urls_confirmed' => false,
                'alts_confirmed' => empty( $expected_alts ),
            ];
        }

        $url_mappings = $manager->getPostMappings( $post_id, 'image' );
        if ( ! is_array( $url_mappings ) ) {
            return [
                'urls_confirmed' => false,
                'alts_confirmed' => empty( $expected_alts ),
            ];
        }

        $urls_confirmed = self::db2_image_url_mappings_match_expected_list(
            $url_mappings,
            array_values( $expected_urls )
        );

        $alts_confirmed = true;

        if ( ! empty( $expected_alts ) ) {
            if ( ! method_exists( $manager, 'getPostAltMappings' ) ) {
                $alts_confirmed = false;
            } else {
                $alt_mappings = $manager->getPostAltMappings( $post_id, 'image' );
                $alts_confirmed = is_array( $alt_mappings )
                    && self::db2_image_alt_mappings_match_expected_list(
                        $alt_mappings,
                        array_values( $expected_alts ),
                        count( $expected_urls )
                    );
            }
        }

        return [
            'urls_confirmed' => $urls_confirmed,
            'alts_confirmed' => $alts_confirmed,
        ];
    }

    private static function legacy_image_gallery_suffix_for_db2_index( int $db2_index ): int {
        return max( 0, $db2_index - 1 );
    }

    private static function legacy_image_gallery_url_key_for_db2_index( int $db2_index ): string {
        return 'fifu_image_url_' . self::legacy_image_gallery_suffix_for_db2_index( $db2_index );
    }

    private static function legacy_image_gallery_alt_key_for_db2_index( int $db2_index ): string {
        return 'fifu_image_alt_' . self::legacy_image_gallery_suffix_for_db2_index( $db2_index );
    }

    private static function cleanup_legacy_video_list( int $post_id ): void {
        fifu_delete_post_meta( $post_id, 'fifu_video_url' );
        fifu_delete_post_meta( $post_id, 'fifu_custom_video_url' );

        $index = 0;
        while ( true ) {
            $url = Fifu_Post_Video_List_Read_Service::get_video_url( (int) $post_id, (int) $index );
            if ( $url ) {
                fifu_delete_post_meta( $post_id, 'fifu_video_url_' . $index );
            } else {
                break;
            }

            $index++;
        }

        fifu_delete_post_meta( $post_id, 'fifu_list_video_url' );
    }

    private static function delete_legacy_post_meta_only( int $post_id, string $meta_key ): void {
        if ( function_exists( 'delete_post_meta' ) ) {
            delete_post_meta( $post_id, $meta_key );
            return;
        }

        global $wpdb;
        if ( isset( $wpdb ) && is_object( $wpdb ) && property_exists( $wpdb, 'postmeta' ) ) {
            $wpdb->delete(
                $wpdb->postmeta,
                [
                    'post_id'  => $post_id,
                    'meta_key' => $meta_key,
                ],
                [
                    '%d',
                    '%s',
                ]
            );
        }

        if ( function_exists( 'clean_post_cache' ) ) {
            clean_post_cache( $post_id );
        }

        if ( function_exists( 'wp_cache_delete' ) ) {
            wp_cache_delete( $post_id, 'post_meta' );
        }
    }

    private static function delete_legacy_term_meta_only( int $term_id, string $meta_key ): void {
        if ( function_exists( 'delete_term_meta' ) ) {
            delete_term_meta( $term_id, $meta_key );
            return;
        }

        global $wpdb;
        if ( isset( $wpdb ) && is_object( $wpdb ) && property_exists( $wpdb, 'termmeta' ) ) {
            $wpdb->delete(
                $wpdb->termmeta,
                [
                    'term_id'  => $term_id,
                    'meta_key' => $meta_key,
                ],
                [
                    '%d',
                    '%s',
                ]
            );
        }

        if ( function_exists( 'clean_term_cache' ) ) {
            clean_term_cache( [ $term_id ] );
        }

        if ( function_exists( 'wp_cache_delete' ) ) {
            wp_cache_delete( $term_id, 'term_meta' );
        }
    }

    public static function clear_video_list( int $post_id ): void {
        self::cleanup_legacy_video_list( $post_id );
    }

    public static function cleanup_video_list_legacy_postmeta( int $post_id ): void {
        FIFU_Post_Meta_Updater::instance()->cleanup_video_list_legacy_postmeta( $post_id );
    }

    public static function save_slider_list( int $post_id, bool $is_import_context = false, bool $clear_conflicting_media = true ): void {
        $hasExplicitSliderUrlPayload = array_key_exists( 'fifu_wai_gallery_only_slider_list_url', $_REQUEST )
            && trim( (string) $_REQUEST['fifu_wai_gallery_only_slider_list_url'] ) !== '';
        $hasExplicitSliderAltPayload = array_key_exists( 'fifu_wai_gallery_only_slider_list_alt', $_REQUEST );
        $rawExplicitSliderAltPayload = $hasExplicitSliderAltPayload
            ? (string) $_REQUEST['fifu_wai_gallery_only_slider_list_alt']
            : null;
        $previousRaw = self::get_previous_slider_list_raw( $post_id );
        $list = self::get_effective_slider_list_raw( $post_id );
        $currentUrls = self::parse_legacy_list( $list );
        $previousUrls = self::parse_legacy_list( $previousRaw );

        if ( $is_import_context ) {
            $hasExplicitSliderUrlPayload = metadata_exists( 'post', $post_id, 'fifu_slider_list_url' );
            $hasExplicitSliderAltPayload = metadata_exists( 'post', $post_id, 'fifu_slider_list_alt' );
            $rawExplicitSliderAltPayload = $hasExplicitSliderAltPayload
                ? (string) get_post_meta( $post_id, 'fifu_slider_list_alt', true )
                : null;
            $list = (string) self::get_raw_meta_value( $post_id, 'fifu_slider_list_url' );
            $currentUrls = self::parse_legacy_list( $list );
            $previousRaw = $list;
            $previousUrls = $currentUrls;

            foreach ( $currentUrls as $url ) {
                $url = trim( (string) $url );
                if ( $url !== '' && filter_var( $url, FILTER_VALIDATE_URL ) === false ) {
                    return;
                }
            }
        }

        if ( ! empty( $currentUrls ) ) {
            $normalizedUrls = [];
            foreach ( $currentUrls as $url ) {
                $url = trim( (string) $url );
                if ( $url === '' ) {
                    continue;
                }

                if ( $is_import_context && filter_var( $url, FILTER_VALIDATE_URL ) === false ) {
                    return;
                }

                $normalizedUrls[] = $url;
            }

            if ( ! empty( $normalizedUrls ) ) {
                if ( $hasExplicitSliderUrlPayload ) {
                    if ( $clear_conflicting_media ) {
                        self::clear_conflicting_featured_media_for_explicit_slider_payload( $post_id );
                    }
                    self::clear_slider_url_db2_mappings( $post_id );
                    // Do not delete indexed legacy slider meta here. Legacy cleanup must happen
                    // only after DB2 round-trip confirmation, otherwise failed DB2 writes lose
                    // the fallback/retry source.
                }

                $normalizedList = implode( '|', $normalizedUrls );
                $bridge = function_exists( 'fifu_db2_legacy_write_bridge' ) ? fifu_db2_legacy_write_bridge() : null;
                $manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
                $bridgeHandled = false;
                $urlsConfirmedInDb2 = false;
                $shouldPersistSliderUrls = ! (
                    $hasExplicitSliderUrlPayload
                    && $previousUrls === $currentUrls
                    && self::has_db2_post_mappings( $post_id, 'slider' )
                );

                if ( $shouldPersistSliderUrls ) {
                    if ( $bridge instanceof Fifu_Db2_Legacy_Write_Bridge ) {
                        $bridgeHandled = $bridge->handle_post_meta_change( $post_id, 'fifu_slider_list_url', $normalizedList );
                    }

                    if ( ! $bridgeHandled && $manager instanceof Fifu_Db2_Manager ) {
                        if ( method_exists( $manager, 'deletePostMappings' ) ) {
                            $manager->deletePostMappings( $post_id, 'slider' );
                        }

                        $bridgeHandled = true;
                        foreach ( $normalizedUrls as $index => $url ) {
                            if ( ! method_exists( $manager, 'savePostUrl' ) || ! $manager->savePostUrl( $post_id, 'slider', (int) $index, $url ) ) {
                                $bridgeHandled = false;
                                break;
                            }
                        }
                    }
                }

                $normalizedAlts = array_fill( 0, count( $normalizedUrls ), '' );
                if ( $hasExplicitSliderAltPayload ) {
                    $rawAltPayload = trim( (string) $rawExplicitSliderAltPayload );
                    $rawAltSegments = $rawAltPayload !== '' ? self::parse_legacy_list_preserve_empty_slots( $rawAltPayload ) : [];

                    foreach ( $normalizedUrls as $index => $_url ) {
                        $normalizedAlts[ $index ] = self::normalize_slider_alt_segment( (string) ( $rawAltSegments[ $index ] ?? '' ) );
                    }
                } elseif ( ! $is_import_context && ! $hasExplicitSliderUrlPayload ) {
                    $rawListAlt = self::get_slider_alt_list_for_split( $post_id );
                    $rawListAlt = is_string( $rawListAlt ) ? $rawListAlt : '';

                    $listAlts = $rawListAlt !== '' ? self::parse_legacy_list_preserve_empty_slots( $rawListAlt ) : [];
                    foreach ( $normalizedUrls as $index => $_url ) {
                        $normalizedAlts[ $index ] = self::resolve_slider_alt_for_split( $post_id, (int) $index, $listAlts, true );
                    }
                }

                $hasNonEmptyAlt = false;
                foreach ( $normalizedAlts as $alt ) {
                    if ( trim( (string) $alt ) !== '' ) {
                        $hasNonEmptyAlt = true;
                        break;
                    }
                }

                $shouldPersistSliderAlts = $hasExplicitSliderAltPayload || ( ! $hasExplicitSliderUrlPayload && $hasNonEmptyAlt );

                if ( $shouldPersistSliderAlts ) {
                    $altHandled = false;
                    if ( $hasNonEmptyAlt ) {
                        $altValue = implode( '|', $normalizedAlts );
                        if ( $bridge instanceof Fifu_Db2_Legacy_Write_Bridge ) {
                            $altHandled = $bridge->handle_post_meta_change( $post_id, 'fifu_slider_list_alt', $altValue );
                        }

                        if ( ! $altHandled && $manager instanceof Fifu_Db2_Manager ) {
                            if ( method_exists( $manager, 'deletePostAltMappings' ) ) {
                                $manager->deletePostAltMappings( $post_id, 'slider' );
                            }

                            $altHandled = true;
                            foreach ( $normalizedAlts as $index => $alt ) {
                                if ( $alt === '' ) {
                                    continue;
                                }

                                if ( ! method_exists( $manager, 'savePostAlt' ) || ! $manager->savePostAlt( $post_id, 'slider', (int) $index, $alt ) ) {
                                    $altHandled = false;
                                    break;
                                }
                            }
                        }
                    } else {
                        if ( $bridge instanceof Fifu_Db2_Legacy_Write_Bridge ) {
                            $altHandled = $bridge->handle_post_meta_change( $post_id, 'fifu_slider_list_alt', '' );
                        }

                        if ( ! $altHandled ) {
                            self::clear_slider_alt_db2_mappings( $post_id );
                        }
                    }
                }

                if ( $bridgeHandled && $manager instanceof Fifu_Db2_Manager ) {
                    $urlsConfirmedInDb2 = self::db2_slider_urls_confirmed( $post_id, $manager, $normalizedUrls );
                }

                if ( $hasExplicitSliderUrlPayload && ! $hasExplicitSliderAltPayload && $previousUrls !== $currentUrls ) {
                    self::clear_slider_alt_db2_mappings( $post_id );

                    if ( $urlsConfirmedInDb2 ) {
                        self::delete_legacy_post_meta_only( $post_id, 'fifu_slider_list_alt' );
                        self::delete_indexed_post_meta_by_pattern( $post_id, '/^fifu_slider_image_alt_\d+$/' );
                    }
                } elseif ( $hasExplicitSliderAltPayload && ! $hasNonEmptyAlt ) {
                    self::clear_slider_alt_db2_mappings( $post_id );

                    if ( $urlsConfirmedInDb2 ) {
                        self::delete_legacy_post_meta_only( $post_id, 'fifu_slider_list_alt' );
                        self::delete_indexed_post_meta_by_pattern( $post_id, '/^fifu_slider_image_alt_\d+$/' );
                    }
                }
            }
        }
    }

    private static function resolve_slider_alt_for_split( int $post_id, int $index, ?array $listAlts, bool $allowLegacyFallback ): string {
        if ( self::should_force_slider_gallery_only_db2_rebuild() ) {
            return self::normalize_slider_alt_segment( $listAlts[ $index ] ?? '' );
        }

        if ( ! $allowLegacyFallback ) {
            return self::normalize_slider_alt_segment( $listAlts[ $index ] ?? '' );
        }

        $indexedAltKey = 'fifu_slider_image_alt_' . $index;
        if ( function_exists( 'metadata_exists' ) && metadata_exists( 'post', $post_id, $indexedAltKey ) ) {
            $explicitAlt = self::normalize_slider_alt_segment( get_post_meta( $post_id, $indexedAltKey, true ) );
            if ( $explicitAlt !== '' ) {
                return $explicitAlt;
            }
        }

        $listAlt = self::normalize_slider_alt_segment( $listAlts[ $index ] ?? '' );
        return $listAlt;
    }

    private static function get_slider_alt_list_for_split( int $post_id ): ?string {
        $request_alt_raw = trim( (string) ( $_REQUEST['fifu_wai_gallery_only_slider_list_alt'] ?? '' ) );
        if ( $request_alt_raw !== '' ) {
            return $request_alt_raw;
        }

        if ( function_exists( 'metadata_exists' ) && metadata_exists( 'post', $post_id, 'fifu_slider_list_alt' ) ) {
            return (string) get_post_meta( $post_id, 'fifu_slider_list_alt', true );
        }

        return Fifu_Post_Slider_List_Alt_Read_Service::get_slider_list_alt($post_id);
    }

    private static function get_previous_slider_list_raw( int $post_id ): string {
        $persisted = trim( (string) self::get_raw_meta_value( $post_id, 'fifu_slider_list_url' ) );
        if ( $persisted !== '' ) {
            return $persisted;
        }

        if ( class_exists( 'Fifu_Post_Slider_List_Url_Read_Service', false ) ) {
            return (string) ( Fifu_Post_Slider_List_Url_Read_Service::get_slider_list_url( $post_id ) ?? '' );
        }

        return '';
    }

    private static function clear_conflicting_featured_media_for_explicit_slider_payload( int $post_id ): void {
        $manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
        if ( $manager instanceof Fifu_Db2_Manager ) {
            if ( method_exists( $manager, 'deletePostMappings' ) ) {
                $manager->deletePostMappings( $post_id, 'image' );
                $manager->deletePostMappings( $post_id, 'video' );
                $manager->deletePostMappings( $post_id, 'custom_video' );
            }

            if ( method_exists( $manager, 'deletePostAltMappings' ) ) {
                $manager->deletePostAltMappings( $post_id, 'image' );
                $manager->deletePostAltMappings( $post_id, 'custom_video' );
            }
        }

        delete_post_meta( $post_id, 'fifu_image_url' );
        delete_post_meta( $post_id, 'fifu_image_alt' );
        delete_post_meta( $post_id, 'fifu_video_url' );
        delete_post_meta( $post_id, 'fifu_custom_video_url' );
        delete_post_meta( $post_id, 'fifu_list_url' );
        delete_post_meta( $post_id, 'fifu_list_video_url' );
    }

    private static function clear_slider_db2_mappings( int $post_id ): void {
        $manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
        if ( ! ( $manager instanceof Fifu_Db2_Manager ) ) {
            return;
        }

        if ( method_exists( $manager, 'deletePostMappings' ) ) {
            $manager->deletePostMappings( $post_id, 'slider' );
        }

        if ( method_exists( $manager, 'deletePostAltMappings' ) ) {
            $manager->deletePostAltMappings( $post_id, 'slider' );
        }

        if ( method_exists( $manager, 'getPostAltMappings' ) ) {
            $altMappings = $manager->getPostAltMappings( $post_id, 'slider' );
            if ( is_array( $altMappings ) ) {
                foreach ( $altMappings as $mapping ) {
                    if ( ! is_array( $mapping ) || ! isset( $mapping['key_index'] ) || ! is_numeric( $mapping['key_index'] ) ) {
                        continue;
                    }

                    if ( method_exists( $manager, 'deletePostAltMappings' ) ) {
                        $manager->deletePostAltMappings( $post_id, 'slider', (int) $mapping['key_index'] );
                    }
                }
            }
        }
    }

    private static function clear_slider_url_db2_mappings( int $post_id ): void {
        $manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
        if ( ! ( $manager instanceof Fifu_Db2_Manager ) ) {
            return;
        }

        if ( method_exists( $manager, 'deletePostMappings' ) ) {
            $manager->deletePostMappings( $post_id, 'slider' );
        }
    }

    private static function clear_slider_alt_db2_mappings( int $post_id ): void {
        $manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
        if ( ! ( $manager instanceof Fifu_Db2_Manager ) ) {
            return;
        }

        if ( method_exists( $manager, 'deletePostAltMappings' ) ) {
            $manager->deletePostAltMappings( $post_id, 'slider' );
        }
    }

    /**
     * @param array<int, string> $expectedUrls
     */
    private static function db2_slider_urls_confirmed( int $post_id, Fifu_Db2_Manager $manager, array $expectedUrls ): bool {
        if ( $expectedUrls === [] ) {
            return false;
        }

        if ( ! method_exists( $manager, 'getPostMappings' ) ) {
            return false;
        }

        $mappings = $manager->getPostMappings( $post_id, 'slider' );
        if ( ! is_array( $mappings ) ) {
            return false;
        }

        $byIndex = [];
        foreach ( $mappings as $key => $mapping ) {
            if ( is_array( $mapping ) ) {
                $index = array_key_exists( 'key_index', $mapping ) ? (int) $mapping['key_index'] : ( is_int( $key ) ? $key : null );
                $url = trim( (string) ( $mapping['url'] ?? '' ) );
            } elseif ( is_object( $mapping ) ) {
                $index = isset( $mapping->key_index ) ? (int) $mapping->key_index : ( is_int( $key ) ? $key : null );
                $url = trim( (string) ( $mapping->url ?? '' ) );
            } else {
                continue;
            }

            if ( $index === null || $url === '' ) {
                continue;
            }

            $byIndex[ $index ] = $url;
        }

        foreach ( $expectedUrls as $index => $expectedUrl ) {
            if ( ! isset( $byIndex[ $index ] ) ) {
                return false;
            }

            if ( $byIndex[ $index ] !== $expectedUrl ) {
                return false;
            }
        }

        return true;
    }

    /**
     * @param array<int, string> $expectedUrls
     * @param array<int, string> $expectedAlts
     */
    private static function db2_slider_alts_confirmed( int $post_id, Fifu_Db2_Manager $manager, array $expectedUrls, array $expectedAlts ): bool {
        if ( $expectedAlts === [] ) {
            return true;
        }

        $altIndexesToCheck = $expectedUrls !== [] ? array_keys( $expectedUrls ) : array_keys( $expectedAlts );
        foreach ( $altIndexesToCheck as $index ) {
            $expectedAlt = trim( (string) ( $expectedAlts[ $index ] ?? '' ) );
            if ( $expectedAlt === '' ) {
                continue;
            }

            $mapping = $manager->getPostAltMapping( $post_id, 'slider', (int) $index );
            if ( ! is_array( $mapping ) || trim( (string) ( $mapping['alt'] ?? '' ) ) !== $expectedAlt ) {
                return false;
            }
        }

        return true;
    }

    private static function delete_indexed_post_meta_by_pattern( int $post_id, string $pattern ): void {
        $meta = get_post_meta( $post_id );
        if ( ! is_array( $meta ) ) {
            return;
        }

        foreach ( array_keys( $meta ) as $metaKey ) {
            if ( is_string( $metaKey ) && preg_match( $pattern, $metaKey ) === 1 ) {
                delete_post_meta( $post_id, $metaKey );
            }
        }
    }

    /**
     * @param mixed $value
     */
    private static function normalize_slider_alt_segment( $value ): string {
        if ( $value === null ) {
            return '';
        }

        $normalized = trim( (string) $value );
        $normalized_lower = strtolower( $normalized );
        if (
            $normalized_lower === ''
            || $normalized_lower === 'null'
            || $normalized_lower === 'undefined'
            || $normalized_lower === 'http://null'
            || $normalized_lower === 'https://null'
        ) {
            return '';
        }

        return trim( wp_strip_all_tags( $normalized ) );
    }

    private static function should_force_slider_gallery_only_db2_rebuild(): bool {
        return trim( (string) ( $_REQUEST['fifu_wai_gallery_only_slider_list_alt'] ?? '' ) ) !== '';
    }

    public static function save_iframe_list( int $post_id ): void {
        self::save_iframe_list_from_raw_value(
            $post_id,
            (string) get_post_meta( $post_id, 'fifu_list_iframe_url', true ),
            false
        );
    }

    public static function save_iframe_list_from_import_payload(
        int $post_id,
        string $iframe_list_url
    ): ?string {
        return self::save_iframe_list_from_raw_value($post_id, $iframe_list_url, true);
    }

    private static function save_iframe_list_from_raw_value(
        int $post_id,
        string $raw_value,
        bool $clear_when_empty
    ): ?string {
        $list = self::normalize_iframe_list($raw_value);
        if ( $list === null ) {
            if ( $clear_when_empty ) {
                $manager = self::get_db2_manager_or_null();
                if ( $manager !== null && method_exists( $manager, 'deletePostMappings' ) ) {
                    $manager->deletePostMappings( $post_id, 'iframe' );
                }
            }

            return null;
        }

        foreach ( $list as $url ) {
            if ( ! self::is_valid_db2_url_segment( $url ) ) {
                return implode('|', $list);
            }
        }

        $manager = self::get_db2_manager_or_null();
        if ( $manager !== null && method_exists( $manager, 'deletePostMappings' ) ) {
            $manager->deletePostMappings( $post_id, 'iframe' );
        }

        $updater = class_exists( 'FIFU_Post_Meta_Updater', false ) ? FIFU_Post_Meta_Updater::instance() : null;
        foreach ( array_values( $list ) as $i => $url ) {
            if ( $updater instanceof FIFU_Post_Meta_Updater ) {
                $ok = $updater->update_or_delete_with_status( $post_id, 'fifu_image_ifm_' . $i, $url );
            } else {
                fifu_update_or_delete( $post_id, 'fifu_image_ifm_' . $i, $url );
                $ok = true;
            }

            if ( ! $ok ) {
                return implode('|', $list);
            }
        }

        return implode('|', $list);
    }

    private static function normalize_iframe_list( string $value ): ?array {
        $value = trim( $value );
        if ( $value === '' ) {
            return null;
        }

        $delimiter = strpos( $value, PHP_EOL ) !== false && strpos( $value, '|' ) === false ? PHP_EOL : '|';
        $parts = array_values(
            array_filter(
                array_map( 'trim', explode( $delimiter, rtrim( $value, $delimiter ) ) ),
                static fn( string $entry ): bool => $entry !== ''
            )
        );

        return $parts === [] ? null : $parts;
    }

    private static function is_valid_db2_url_segment( string $url ): bool
    {
        $url = trim( $url );

        if ( $url === '' || preg_match( '/^(null|undefined)$/i', $url ) === 1 ) {
            return false;
        }

        $parts = parse_url( $url );
        if ( ! is_array( $parts ) ) {
            return false;
        }

        $scheme = strtolower( (string) ( $parts['scheme'] ?? '' ) );
        $host = (string) ( $parts['host'] ?? '' );

        if ( $host === '' || ! in_array( $scheme, [ 'http', 'https' ], true ) ) {
            return false;
        }

        return filter_var( $url, FILTER_VALIDATE_URL ) !== false;
    }

    public static function split_lists( int $post_id, bool $split_slider_list = true ): void {
        $imageListRaw = self::get_explicit_image_list_payload_raw( $post_id );
        $videoListRaw = self::get_effective_video_list_raw( $post_id );
        $hasImageList = ! empty( self::parse_legacy_list( $imageListRaw ) );
        $hasVideoList = ! empty( self::parse_legacy_list( $videoListRaw ) );
        $videoPriority = null;
        if ( $hasImageList && $hasVideoList ) {
            $videoPriority = class_exists( 'Fifu_Options_Utils', false ) && Fifu_Options_Utils::is_on( 'fifu_videos_before' );
        } elseif ( $hasVideoList ) {
            $videoPriority = true;
        } elseif ( $hasImageList ) {
            $videoPriority = false;
        }

        if ( $videoPriority === true && $hasImageList && $hasVideoList ) {
            self::save_video_list($post_id, null, $videoPriority);
            self::save_image_list($post_id, null, $videoPriority);
        } else {
            self::save_image_list($post_id, null, $videoPriority);
            self::save_video_list($post_id, null, $videoPriority);
        }
        if ( $split_slider_list ) {
            self::save_slider_list($post_id);
        }
    }
}
