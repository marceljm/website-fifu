<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/class-fifu-generic-cron-service.php';

/**
 * Coordinates metadata maintenance, queues, and cron toggles.
 *
 * This controller will call the existing services/repositories and map the legacy
 * admin/db behaviors into a single entry point.
 */
final class Fifu_Meta_Maintenance_Controller
{
    /**
     * Prepares the metadata queue for processing.
     */
    public static function prepare_content_queue(): void
    {
        Fifu_Metadata_Queue_Service::prepare_content_queue();
    }

    /**
     * Clears all stored dimensions metadata for tracked attachments.
     */
    public static function clean_dimensions_all(): void
    {
        Fifu_Media_Maintenance_Service::reset_attachment_metadata_for_author();
    }

    /**
     * Enables the clean metadata job by toggling options and scheduling cron work.
     */
    public static function enable_clean(): void
    {
        if (Fifu_Options_Utils::is_on('fifu_cron_metadata')) {
            update_option('fifu_cron_metadata', 'toggleoff', 'no');
            $request = new \WP_REST_Request();
            $request->set_param('toggle', 'fifu_toggle_cron_metadata');
            Fifu_Rest_Cron_Controller::cron_delete($request);
        }

        Fifu_Metadata_Queue_Service::clear_meta_in();
        Fifu_Media_Maintenance_Service::run_full_cleanup();
    }

    /**
     * Clears the inbound metadata queue.
     */
    public static function clear_meta_in(): void
    {
        Fifu_Metadata_Queue_Service::clear_meta_in();
    }

    /**
     * Clears the outbound metadata queue.
     */
    public static function clear_meta_out(): void
    {
        Fifu_Metadata_Queue_Service::clear_meta_out();
    }

    /**
     * Backfills attachments for posts via the meta gap filler.
     */
    public static function backfill_post_attachments(): void
    {
        Fifu_Meta_Gap_Fill_Service::backfill_post_attachments();
    }

    /**
     * Backfills attachments for terms via the meta gap filler.
     */
    public static function backfill_term_attachments(): void
    {
        Fifu_Meta_Gap_Fill_Service::backfill_term_attachments();
    }

    /**
     * Backfills attachment data for external galleries.
     */
    public static function backfill_external_galleries(): void
    {
        Fifu_Woocommerce_Variation_Attachment_Service::backfill_external_galleries();
    }

    /**
     * Enables the "fake" mode by preparing incoming metadata.
     *
     * This will clear meta-out queues and trigger the "metain" generic cron job.
     *
     * @return void
     */
    public static function enable_fake(): void
    {
        self::clear_meta_out();
        Fifu_Generic_Cron_Service::run('metain');
    }

    /**
     * Stops fake metadata generation without removing existing metadata.
     *
     * Turning Image Metadata off must not trigger MetaOut. Metadata removal belongs
     * to the Clean Metadata flow.
     *
     * @return void
     */
    public static function disable_fake(): void
    {
        // Intentionally no-op. REST/CLI callers own their toggle/stop options.
    }

    /**
     * Runs the outbound metadata cleanup job.
     *
     * This is used by Clean Metadata flows only. Do not call this when merely
     * turning Image Metadata off.
     *
     * @return void
     */
    public static function run_metaout(): void
    {
        Fifu_Generic_Cron_Service::run('metaout');
    }
}
