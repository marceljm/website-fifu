<?php

declare(strict_types=1);

defined('ABSPATH') || exit;

/**
 * Repository responsible for locating posts or terms that have FIFU metadata gaps.
 */
class Fifu_Meta_Gap_Repository {

    /** @var wpdb */
    private wpdb $wpdb;

    /** @var string */
    private string $postmeta_table;

    /** @var string */
    private string $termmeta_table;

    /** @var string */
    private string $term_taxonomy_table;

    /** @var string */
    private string $term_relationships_table;

    /** @var string */
    private string $posts_table;

    /** @var string */
    private string $terms_table;

    /** @var string */
    private string $fifu_term_map_table;

    /** @var string */
    private string $fifu_map_table;

    /** @var string */
    private string $fifu_key_table;

    /** @var string */
    private string $fifu_identifier_table;

    /** @var string */
    private string $fifu_identifier_type_table;

    /** @var string */
    private string $fifu_url_table;

    /** @var string */
    private string $fifu_sent_table;

    /** @var string */
    private string $fifu_sent_event_table;

    /** @var string */
    private string $post_types_in_clause;

    /** @var int */
    private int $author_id;

    /**
     * Constructor.
     *
     * @param wpdb|null $wpdb_instance Optional database abstraction.
     */
    public function __construct(?wpdb $wpdb_instance = null) {
        $this->wpdb = $wpdb_instance ?? $GLOBALS['wpdb'];
        $this->postmeta_table = $this->wpdb->postmeta;
        $this->termmeta_table = $this->wpdb->termmeta;
        $this->term_taxonomy_table = $this->wpdb->term_taxonomy;
        $this->term_relationships_table = $this->wpdb->term_relationships;
        $this->posts_table = $this->wpdb->posts;
        $this->terms_table = $this->wpdb->terms;
        $prefix = $this->wpdb->prefix;
        $this->fifu_term_map_table = $prefix . 'fifu_term_map';
        $this->fifu_map_table = $prefix . 'fifu_map';
        $this->fifu_key_table = $prefix . 'fifu_key';
        $this->fifu_identifier_table = $prefix . 'fifu_identifier';
        $this->fifu_identifier_type_table = $prefix . 'fifu_identifier_type';
        $this->fifu_url_table = $prefix . 'fifu_url';
        $this->fifu_sent_table = $prefix . 'fifu_sent';
        $this->fifu_sent_event_table = $prefix . 'fifu_sent_event';
        $this->post_types_in_clause = $this->build_post_types_clause();
        $this->author_id = (int) Fifu_Options_Utils::get_author();
    }

    /**
     * Build a list of valid post types for metadata gap detection.
     *
     * @return string
     */
    private function build_post_types_clause(): string {
        $raw = (array) Fifu_Post_Type_Utils::get_post_types();
        $registered = get_post_types([], 'names');
        $safe = [];
        foreach ($raw as $pt) {
            $pt = sanitize_key($pt);
            if ($pt !== '' && isset($registered[$pt])) {
                $safe[] = $pt;
            }
        }
        $safe = array_values(array_unique($safe));
        if (!$safe) {
            return "''";
        }
        return "'" . implode("','", $safe) . "'";
    }

    /**
     * Return all category term IDs that have FIFU metadata but no thumbnail meta set.
     *
     * @return array
     */
    public function get_categories_without_meta(): array {
        $mode = fifu_db2_mode();

        if ($mode === Fifu_Db2_Mode::MODE_DB2) {
            return $this->get_categories_without_meta_db2();
        }

        if ($mode === Fifu_Db2_Mode::MODE_HYBRID || $mode === Fifu_Db2_Mode::MODE_LEGACY) {
            $db2Results = $this->get_categories_without_meta_db2();
            $legacyResults = $this->get_categories_without_meta_legacy();
            return Fifu_Db2_Query_Helper::merge_unique_rows_by_int_field(
                $db2Results,
                $legacyResults,
                'post_id'
            );
        }

        return $this->get_categories_without_meta_legacy();
    }

    /**
     * Legacy SQL path for the category metadata gap search.
     *
     * @return array
     */
    private function get_categories_without_meta_legacy(): array {
        $sentClause = $this->get_db2_sent_not_exists_clause('term', 'metadataterm', 'a.term_id');

        $sql = "
            SELECT DISTINCT a.term_id AS post_id
            FROM {$this->termmeta_table} a
            WHERE a.meta_key IN ('fifu_image_url', 'fifu_video_url')
              AND a.meta_value IS NOT NULL
              AND a.meta_value <> ''
              AND NOT EXISTS (
                  SELECT 1
                  FROM {$this->termmeta_table} sent
                  WHERE sent.term_id = a.term_id
                    AND sent.meta_key = 'fifu_metadataterm_sent'
              )
              AND NOT EXISTS (
                  SELECT 1
                  FROM {$this->termmeta_table} thumb
                  INNER JOIN {$this->posts_table} att
                      ON att.ID = CAST(thumb.meta_value AS UNSIGNED)
                     AND att.post_type = 'attachment'
                  INNER JOIN {$this->postmeta_table} attached
                      ON attached.post_id = att.ID
                     AND attached.meta_key = '_wp_attached_file'
                     AND attached.meta_value IS NOT NULL
                     AND attached.meta_value <> ''
                  INNER JOIN {$this->postmeta_table} metadata
                      ON metadata.post_id = att.ID
                     AND metadata.meta_key = '_wp_attachment_metadata'
                     AND metadata.meta_value IS NOT NULL
                     AND metadata.meta_value <> ''
                  WHERE thumb.term_id = a.term_id
                    AND thumb.meta_key = 'thumbnail_id'
                    AND thumb.meta_value IS NOT NULL
                    AND thumb.meta_value <> ''
                    AND thumb.meta_value <> '0'
                    AND (
                        a.meta_key = 'fifu_video_url'
                        OR attached.meta_value = a.meta_value
                    )
              )
              {$sentClause}
        ";

        return $this->wpdb->get_results($sql);
    }

    /**
     * DB2 SQL path for the category metadata gap search.
     *
     * @return array
     */
    private function get_categories_without_meta_db2(): array {
        if (!$this->has_category_db2_tables()) {
            return [];
        }

        $sql = "
            SELECT DISTINCT m.term_id AS post_id
            FROM {$this->fifu_term_map_table} m
            INNER JOIN {$this->fifu_key_table} k ON k.key_id = m.key_id
            INNER JOIN {$this->fifu_url_table} u ON u.hash = m.hash
            WHERE k.key_type IN ('image','video')
              AND u.url IS NOT NULL
              AND u.url <> ''
              AND NOT EXISTS (
                  SELECT 1
                  FROM {$this->termmeta_table} tm
                  INNER JOIN {$this->posts_table} att
                      ON att.ID = CAST(tm.meta_value AS UNSIGNED)
                     AND att.post_type = 'attachment'
                  INNER JOIN {$this->postmeta_table} attached
                      ON attached.post_id = att.ID
                     AND attached.meta_key = '_wp_attached_file'
                     AND attached.meta_value IS NOT NULL
                     AND attached.meta_value <> ''
                  INNER JOIN {$this->postmeta_table} metadata
                      ON metadata.post_id = att.ID
                     AND metadata.meta_key = '_wp_attachment_metadata'
                     AND metadata.meta_value IS NOT NULL
                     AND metadata.meta_value <> ''
                  WHERE tm.term_id = m.term_id
                    AND tm.meta_key = 'thumbnail_id'
                    AND tm.meta_value IS NOT NULL
                    AND tm.meta_value <> ''
                    AND tm.meta_value <> '0'
                    AND (
                        k.key_type = 'video'
                        OR attached.meta_value = u.url
                    )
              )
              {$this->get_db2_sent_not_exists_clause('term', 'metadataterm', 'm.term_id')}
        ";

        return $this->wpdb->get_results($sql);
    }

    /**
     * Return all post IDs that have FIFU metadata but no _thumbnail_id meta entry.
     *
     * @return array
     */
    public function get_posts_without_meta(): array {
        if (!function_exists('fifu_db2_mode')) {
            return $this->get_posts_without_meta_legacy();
        }

        $mode = fifu_db2_mode();

        if ($mode === Fifu_Db2_Mode::MODE_DB2) {
            $db2Results = $this->get_posts_without_meta_db2();
            return $db2Results ?? [];
        }

        if ($mode === Fifu_Db2_Mode::MODE_HYBRID) {
            $db2Results = $this->get_posts_without_meta_db2() ?? [];
            $legacyResults = $this->get_posts_without_meta_legacy();
            return Fifu_Db2_Query_Helper::merge_unique_rows_by_int_field(
                $db2Results,
                $legacyResults,
                'post_id'
            );
        }

        return $this->get_posts_without_meta_legacy();
    }

    /**
     * Legacy SQL path for posts missing thumbnail metadata.
     *
     * @return array
     */
    private function get_posts_without_meta_legacy(): array {
        $sentClause = $this->get_db2_sent_not_exists_clause('post', 'metadatapost', 'a.post_id');

        $sql = "
            SELECT DISTINCT a.post_id
            FROM {$this->postmeta_table} a
            WHERE a.meta_key IN ('fifu_image_url', 'fifu_video_url', 'fifu_slider_image_url_0', 'fifu_custom_video_url')
              AND a.meta_value IS NOT NULL
              AND a.meta_value <> ''
              AND NOT EXISTS (
                  SELECT 1
                  FROM {$this->postmeta_table} b
                  WHERE a.post_id = b.post_id
                    AND (
                        (
                            b.meta_key = '_thumbnail_id'
                            AND b.meta_value IS NOT NULL
                            AND b.meta_value <> ''
                            AND b.meta_value <> '0'
                        )
                        OR b.meta_key IN ('fifu_metadatapost_sent')
                    )
              )
              {$sentClause}
        ";
        return $this->wpdb->get_results($sql);
    }

    /**
     * DB2 SQL path for posts missing thumbnail metadata.
     *
     * @return array|null
     */
    private function get_posts_without_meta_db2(): ?array {
        if (!$this->is_db2_ready()) {
            return null;
        }

        $sentClause = $this->get_db2_sent_not_exists_clause('post', 'metadatapost', 'm.post_id');

        $sql = "
            SELECT DISTINCT m.post_id AS post_id
            FROM {$this->fifu_map_table} AS m
            INNER JOIN {$this->fifu_key_table} k ON k.key_id = m.key_id
            INNER JOIN {$this->fifu_url_table} u ON u.hash = m.hash
            WHERE k.key_type IN ('image','video','slider','custom_video')
              AND m.key_index = 0
              AND u.url IS NOT NULL
              AND u.url <> ''
              {$this->get_db2_no_non_sequential_media_gap_clause('m.post_id')}
              AND NOT EXISTS (
                  SELECT 1
                  FROM {$this->postmeta_table} pm
                  WHERE pm.post_id = m.post_id
                    AND pm.meta_key = '_thumbnail_id'
                    AND pm.meta_value IS NOT NULL
                    AND pm.meta_value <> ''
                    AND pm.meta_value <> '0'
              )
              {$sentClause}
        ";

        $results = $this->wpdb->get_results($sql);
        if ($results === false) {
            return null;
        }

        return $results;
    }

    /**
     * Excludes DB2 media lists that contain non-sequential gaps for the same post and key type.
     */
    private function get_db2_no_non_sequential_media_gap_clause(string $post_id_sql): string {
        return "
              AND NOT EXISTS (
                  SELECT 1
                  FROM {$this->fifu_map_table} gap_m
                  INNER JOIN {$this->fifu_key_table} gap_k ON gap_k.key_id = gap_m.key_id
                  WHERE gap_m.post_id = {$post_id_sql}
                    AND gap_k.key_type IN ('image', 'video', 'slider', 'custom_video')
                    AND gap_m.key_index > 0
                    AND NOT EXISTS (
                        SELECT 1
                        FROM {$this->fifu_map_table} prev_m
                        INNER JOIN {$this->fifu_key_table} prev_k ON prev_k.key_id = prev_m.key_id
                        WHERE prev_m.post_id = gap_m.post_id
                          AND prev_k.key_type = gap_k.key_type
                          AND prev_m.key_index = gap_m.key_index - 1
                    )
              )
        ";
    }

    /**
     * Checks that the required DB2 tables exist before querying.
     */
    private function is_db2_ready(): bool {
        return $this->table_exists($this->fifu_map_table)
            && $this->table_exists($this->fifu_key_table)
            && $this->table_exists($this->fifu_url_table);
    }

    /**
     * Checks if the DB2 tables required for featured image detection exist.
     */
    private function has_featured_image_db2_tables(): bool {
        return $this->table_exists($this->fifu_map_table)
            && $this->table_exists($this->fifu_key_table);
    }

    /**
     * Checks that the DB2 tables used for media + sent detection exist.
     */
    private function has_media_sent_db2_tables(): bool {
        return $this->has_featured_image_db2_tables()
            && $this->table_exists($this->fifu_sent_table)
            && $this->table_exists($this->fifu_sent_event_table);
    }

    private function get_db2_sent_not_exists_clause(string $object_type, string $event_key, string $object_column): string {
        if (!$this->has_media_sent_db2_tables()) {
            return '';
        }

        $sent = $this->fifu_sent_table;
        $event = $this->fifu_sent_event_table;
        if (in_array($event_key, ['metadatapost', 'metadataterm'], true)) {
            $sentCondition = "
                    AND s.sent = 0
                    AND s.last_sent_at IS NOT NULL
                    AND s.last_sent_at >= DATE_SUB(NOW(), INTERVAL 30 MINUTE)";
        } else {
            $sentCondition = "
                    AND s.sent = 1";
        }

        return "
              AND NOT EXISTS (
                  SELECT 1
                  FROM {$sent} s
                  INNER JOIN {$event} e ON e.id = s.event_id
                  WHERE s.object_type = '{$object_type}'
                    AND s.object_id = {$object_column}
                    AND e.event_key = '{$event_key}'{$sentCondition}
              )
        ";
    }

    private function get_db2_attempts_threshold_not_exists_clause(string $object_type, string $event_key, string $object_column, int $threshold): string {
        if (!$this->has_media_sent_db2_tables()) {
            return '';
        }

        $sent = $this->fifu_sent_table;
        $event = $this->fifu_sent_event_table;

        return "
              AND NOT EXISTS (
                  SELECT 1
                  FROM {$sent} s
                  INNER JOIN {$event} e ON e.id = s.event_id
                  WHERE s.object_type = '{$object_type}'
                    AND s.object_id = {$object_column}
                    AND e.event_key = '{$event_key}'
                    AND s.sent = 0
                    AND s.attempts >= {$threshold}
              )
        ";
    }

    /**
     * Checks that the DB2 tables needed for finder queries exist.
     */
    private function has_finder_db2_tables(): bool {
        return $this->has_media_sent_db2_tables();
    }

    /**
     * Build the thumbnail condition fragment used by legacy/DB2 finder logic.
     */
    private function build_thumbnail_condition_sql(string $alias): array {
        $default_attach_id = (int) get_option('fifu_default_attach_id');
        $condition = "{$alias}.meta_key = '_thumbnail_id'";
        $args = [];

        if ($default_attach_id > 0) {
            $condition .= " AND {$alias}.meta_value <> %d";
            $args[] = $default_attach_id;
        }

        return [$condition, $args];
    }

    /**
     * Checks that the DB2 tables needed for ISBN detection exist.
     */
    private function has_identifier_db2_tables(): bool {
        return $this->table_exists($this->fifu_identifier_table)
            && $this->table_exists($this->fifu_identifier_type_table)
            && $this->table_exists($this->fifu_map_table)
            && $this->table_exists($this->fifu_key_table)
            && $this->table_exists($this->fifu_sent_table)
            && $this->table_exists($this->fifu_sent_event_table);
    }

    /**
     * Returns whether the given table exists in the database.
     */
    private function table_exists(string $table): bool {
        $sql = $this->wpdb->prepare("SHOW TABLES LIKE %s", $table);
        $result = $this->wpdb->get_var($sql);
        return $result !== null && $result !== false;
    }


    /**
     * Sanitizes the provided post types string for use in IN(...) clauses.
     */
    private function sanitize_post_types_list(string $post_types): string {
        return Fifu_Db2_Sql_Helper::sanitize_post_types_list(
            $post_types,
            $this->post_types_in_clause
        );
    }

    /**
     * Return every post with FIFU metadata but missing WP thumbnail links.
     *
     * @return array
     */
    public function get_all_posts_without_meta(): array {
        if (!function_exists('fifu_db2_mode')) {
            return $this->get_all_posts_without_meta_legacy();
        }

        $mode = fifu_db2_mode();
        $db2Rows = $this->get_all_posts_without_meta_db2();

        if ($mode === Fifu_Db2_Mode::MODE_DB2) {
            $legacyRows = $this->get_all_posts_without_meta_legacy();

            if ($db2Rows === null) {
                return $legacyRows;
            }

            if (class_exists('Fifu_Db2_Query_Helper')) {
                $mergedRows = Fifu_Db2_Query_Helper::merge_unique_rows_by_int_field(
                    $db2Rows,
                    $legacyRows,
                    'post_id'
                );
                return $mergedRows;
            }

            if (!$db2Rows) {
                return $legacyRows;
            }

            if (!$legacyRows) {
                return $db2Rows;
            }

            $merged = [];
            $seen = [];

            foreach ([$db2Rows, $legacyRows] as $rows) {
                foreach ($rows as $row) {
                    $postId = null;

                    if (is_object($row) && isset($row->post_id)) {
                        $postId = (int) $row->post_id;
                    } elseif (is_array($row) && array_key_exists('post_id', $row)) {
                        $postId = (int) $row['post_id'];
                    }

                    if ($postId === null) {
                        $merged[] = $row;
                        continue;
                    }

                    if (isset($seen[$postId])) {
                        continue;
                    }

                    $seen[$postId] = true;
                    $merged[] = $row;
                }
            }

            $mergedRows = array_values($merged);
            return $mergedRows;
        }

        $legacyRows = $this->get_all_posts_without_meta_legacy();
        if ($db2Rows === null || !class_exists('Fifu_Db2_Query_Helper')) {
            return $legacyRows;
        }

        $mergedRows = Fifu_Db2_Query_Helper::merge_unique_rows_by_int_field(
            $db2Rows,
            $legacyRows,
            'post_id'
        );
        return $mergedRows;
    }

    /**
     * Legacy SQL path for posts missing FIFU metadata.
     *
     * @return array
     */
    private function get_all_posts_without_meta_legacy(): array {
        $sentClause = $this->get_db2_sent_not_exists_clause('post', 'metadatapost', 'a.post_id');

        $results = $this->wpdb->get_results("
            SELECT DISTINCT post_id
            FROM {$this->postmeta_table} a
            WHERE 
            (
                (
                    (
                        a.meta_key LIKE 'fifu_image_url_%'
                        OR a.meta_key LIKE 'fifu_video_url_%'
                        OR a.meta_key LIKE 'fifu_slider_image_url_%'
                        OR (
                            a.meta_key IN ('fifu_list_url', 'fifu_list_video_url', 'fifu_slider_list_url')
                            AND a.meta_value LIKE '%|http%'
                        )
                    )
                    AND NOT EXISTS (
                        SELECT 1 
                        FROM {$this->postmeta_table} b 
                        WHERE a.post_id = b.post_id 
                        AND b.meta_key IN ('_product_image_gallery', 'fifu_metadatapost_sent')
                    )
                )
                OR
                (
                    a.meta_key IN ('fifu_image_url', 'fifu_video_url', 'fifu_slider_image_url_0', 'fifu_list_url', 'fifu_list_video_url')
                    AND NOT EXISTS (
                        SELECT 1 
                        FROM {$this->postmeta_table} b 
                        WHERE a.post_id = b.post_id 
                        AND (
                            (b.meta_key = '_thumbnail_id' AND b.meta_value <> 0)
                            OR b.meta_key IN ('fifu_metadatapost_sent')
                        )
                    )
                )
            )
            AND a.meta_value IS NOT NULL 
            AND a.meta_value <> ''
            {$sentClause}
        ");
        return is_array($results) ? $results : [];
    }

    /**
     * DB2 SQL path for posts missing FIFU metadata.
     *
     * @return array|null
     */
    private function get_all_posts_without_meta_db2(): ?array {
        if (!$this->is_db2_ready()) {
            return null;
        }

        $map = $this->fifu_map_table;
        $key = $this->fifu_key_table;
        $url = $this->fifu_url_table;
        $posts = $this->posts_table;
        $postmeta = $this->postmeta_table;

        $sql = "
            SELECT DISTINCT m.post_id
            FROM {$map} AS m
            INNER JOIN {$key} k ON k.key_id = m.key_id
            INNER JOIN {$url} u ON u.hash = m.hash
            INNER JOIN {$posts} p ON p.ID = m.post_id
            WHERE m.post_id IS NOT NULL
              AND (
                  (
                      k.key_type IN ('image','video')
                      AND m.key_index > 0
                      AND p.post_type NOT IN ('product', 'product_variation')
                      AND NOT EXISTS (
                          SELECT 1
                          FROM {$postmeta} pm
                          WHERE pm.post_id = m.post_id
                            AND pm.meta_key = '_product_image_gallery'
                      )
                  )
                  OR
                  (
                      k.key_type IN ('image','video','slider')
                      AND m.key_index > 0
                      AND p.post_type IN ('product', 'product_variation')
                      AND NOT EXISTS (
                          SELECT 1
                          FROM {$postmeta} pm
                          WHERE pm.post_id = m.post_id
                            AND pm.meta_key = '_product_image_gallery'
                      )
                  )
                  OR
                  (
                      k.key_type IN ('image','video','slider')
                      AND m.key_index = 0
                      AND NOT EXISTS (
                          SELECT 1
                          FROM {$postmeta} pm
                          WHERE pm.post_id = m.post_id
                            AND pm.meta_key = '_thumbnail_id'
                            AND pm.meta_value <> 0
                      )
                  )
              )
              {$this->get_db2_sent_not_exists_clause('post', 'metadatapost', 'm.post_id')}
        ";

        $results = $this->wpdb->get_results($sql);
        if ($results === false) {
            return null;
        }

        return $results;
    }

    /**
     * Return posts whose external galleries exist but thumbnails are missing.
     *
     * @return array
     */
    public function get_posts_with_external_gallery_without_meta(): array {
        if (!function_exists('fifu_db2_mode')) {
            return $this->get_posts_with_external_gallery_without_meta_legacy();
        }

        $mode = fifu_db2_mode();
        $db2Rows = $this->get_posts_with_external_gallery_without_meta_db2();

        if ($mode === Fifu_Db2_Mode::MODE_DB2) {
            return is_array($db2Rows) ? $db2Rows : [];
        }

        $legacyRows = $this->get_posts_with_external_gallery_without_meta_legacy();
        if ($db2Rows === null || !class_exists('Fifu_Db2_Query_Helper')) {
            return $legacyRows;
        }

        return Fifu_Db2_Query_Helper::merge_unique_rows_by_int_field(
            $db2Rows,
            $legacyRows,
            'post_id'
        );
    }

    /**
     * Legacy SQL path for external gallery detection.
     *
     * @return array
     */
    private function get_posts_with_external_gallery_without_meta_legacy(): array {
        return $this->wpdb->get_results("
            SELECT DISTINCT post_id
            FROM {$this->postmeta_table} a
            WHERE (
                a.meta_key LIKE 'fifu_image_url_%'
                OR a.meta_key LIKE 'fifu_video_url_%'
                OR a.meta_key LIKE 'fifu_slider_image_url_%'
            )
            AND a.meta_value IS NOT NULL
            AND a.meta_value <> ''
            AND NOT EXISTS (
                SELECT 1
                FROM (
                    SELECT post_id
                    FROM {$this->postmeta_table}
                    WHERE meta_key IN ('_product_image_gallery', '_wc_additional_variation_images')
                ) AS b
                WHERE a.post_id = b.post_id
            )
        ");
    }

    /**
     * DB2 SQL path for external gallery detection.
     *
     * @return array|null
     */
    private function get_posts_with_external_gallery_without_meta_db2(): ?array {
        if (!$this->is_db2_ready()) {
            return null;
        }

        $map = $this->fifu_map_table;
        $key = $this->fifu_key_table;
        $url = $this->fifu_url_table;
        $postmeta = $this->postmeta_table;

        $sql = "
            SELECT DISTINCT m.post_id AS post_id
            FROM {$map} m
            INNER JOIN {$key} k ON k.key_id = m.key_id
            INNER JOIN {$url} u ON u.hash = m.hash
            WHERE k.key_type IN ('image','video','slider')
              AND m.key_index > 0
              AND NOT EXISTS (
                  SELECT 1
                  FROM {$postmeta} pm
                  WHERE pm.post_id = m.post_id
                    AND pm.meta_key IN ('_product_image_gallery', '_wc_additional_variation_images')
              )
        ";

        $results = $this->wpdb->get_results($sql);
        if ($results === false) {
            return null;
        }

        return $results;
    }

    /**
     * Get posts of the given post types that have no featured image or FIFU URL.
     *
     * @param string $post_types_csv Comma-separated list of post types (already sanitized).
     * @return array List of result objects (id, post_title, etc.).
     */
    public function get_posts_without_featured_image(string $post_types_csv): array
    {
        $default_attach_id = (int) get_option('fifu_default_attach_id');
        $safe = $this->sanitize_post_types_list($post_types_csv);

        if (!function_exists('fifu_db2_mode')) {
            return $this->get_post_types_without_featured_image_legacy($safe, $default_attach_id);
        }

        $mode = fifu_db2_mode();

        if ($mode === Fifu_Db2_Mode::MODE_DB2) {
            $db2 = $this->get_post_types_without_featured_image_db2($safe, $default_attach_id, false);
            if ($db2 !== null) {
                return $db2;
            }
            return $this->get_post_types_without_featured_image_legacy($safe, $default_attach_id);
        }

        if ($mode === Fifu_Db2_Mode::MODE_HYBRID) {
            $db2 = $this->get_post_types_without_featured_image_db2($safe, $default_attach_id, false);
            if ($db2 !== null) {
                return $db2;
            }
            return $this->get_post_types_without_featured_image_legacy($safe, $default_attach_id);
        }

        return $this->get_post_types_without_featured_image_legacy($safe, $default_attach_id);
    }

    /**
     * Legacy SQL path for posts missing featured images.
     *
     * @param string $post_types_csv
     * @param int    $default_attach_id
     * @return array
     */
    private function get_post_types_without_featured_image_legacy(string $post_types_csv, int $default_attach_id): array
    {
        $sent_clause = $this->get_db2_sent_not_exists_clause('post', 'auto_set', 'p.ID');

        return $this->wpdb->get_results("
            (
                SELECT p.ID AS post_id, p.post_title
                FROM {$this->posts_table} p
                WHERE p.post_type IN ({$post_types_csv})
                AND p.post_status IN ('publish', 'draft')
                AND NOT EXISTS (
                    SELECT 1
                    FROM {$this->postmeta_table} pm
                    WHERE pm.post_id = p.ID
                    AND (
                        (
                            pm.meta_key = '_thumbnail_id'
                            AND pm.meta_value IS NOT NULL
                            AND pm.meta_value <> ''
                            AND pm.meta_value <> '0'
                            AND pm.meta_value <> '{$default_attach_id}'
                        )
                        OR (
                            pm.meta_key IN (
                                'fifu_image_url',
                                'fifu_video_url',
                                'fifu_custom_video_url',
                                'fifu_list_url',
                                'fifu_list_video_url',
                                'fifu_slider_list_url',
                                'fifu_slider_image_url_0',
                                'fifu_auto_set_sent'
                            )
                            AND TRIM(pm.meta_value) <> ''
                        )
                        OR (
                            pm.meta_key LIKE 'fifu_image_url_%'
                            AND TRIM(pm.meta_value) <> ''
                        )
                    )
                )
                {$sent_clause}
                ORDER BY p.ID DESC
            )
        ");
    }

    /**
     * DB2 SQL path for posts missing featured images and auto-set status.
     *
     * @param string $post_types_csv
     * @param int    $default_attach_id
     * @return array|null
     */
    private function get_post_types_without_featured_image_db2(
        string $post_types_csv,
        int $default_attach_id,
        bool $include_legacy_fallback_blockers = false
    ): ?array
    {
        if (!$this->has_featured_image_db2_tables()
            || !$this->table_exists($this->fifu_sent_table)
            || !$this->table_exists($this->fifu_sent_event_table)
        ) {
            return null;
        }

        $thumbnail_condition = "
              AND NOT EXISTS (
                  SELECT 1
                  FROM {$this->postmeta_table} pm
                  WHERE pm.post_id = p.ID
                    AND pm.meta_key = '_thumbnail_id'
                    AND TRIM(COALESCE(pm.meta_value, '')) <> ''
                    AND TRIM(COALESCE(pm.meta_value, '')) <> '0'
                    AND TRIM(COALESCE(pm.meta_value, '')) <> '{$default_attach_id}'
              )";

        $legacy_fallback_condition = '';
        if ($include_legacy_fallback_blockers) {
            $legacy_fallback_condition = "
              AND NOT EXISTS (
                  SELECT 1
                  FROM {$this->postmeta_table} legacy_pm
                  WHERE legacy_pm.post_id = p.ID
                    AND (
                        (
                            legacy_pm.meta_key IN (
                                'fifu_image_url',
                                'fifu_video_url',
                                'fifu_custom_video_url',
                                'fifu_list_url',
                                'fifu_list_video_url',
                                'fifu_slider_list_url',
                                'fifu_slider_image_url_0',
                                'fifu_auto_set_sent'
                            )
                            AND TRIM(COALESCE(legacy_pm.meta_value, '')) <> ''
                        )
                        OR (
                            legacy_pm.meta_key LIKE 'fifu_image_url_%'
                            AND TRIM(COALESCE(legacy_pm.meta_value, '')) <> ''
                        )
                    )
              )";
        }

        $sql = "
            SELECT p.ID AS post_id, p.post_title
            FROM {$this->posts_table} p
            WHERE p.post_type IN ({$post_types_csv})
              AND p.post_status IN ('publish', 'draft')
              {$thumbnail_condition}
              AND NOT EXISTS (
                  SELECT 1
                  FROM {$this->fifu_map_table} m
                  INNER JOIN {$this->fifu_key_table} k ON k.key_id = m.key_id
                  WHERE m.post_id = p.ID
                    AND k.key_type IN ('image', 'video', 'slider', 'custom_video')
                    AND m.key_index = 0
              )
              AND NOT EXISTS (
                  SELECT 1
                  FROM {$this->fifu_sent_table} s
                  INNER JOIN {$this->fifu_sent_event_table} e
                      ON e.id = s.event_id
                  WHERE s.object_type = 'post'
                    AND s.object_id = p.ID
                    AND e.event_key = 'auto_set'
              )
              {$legacy_fallback_condition}
            ORDER BY p.ID DESC
        ";

        $results = $this->wpdb->get_results($sql);
        if ($results === false) {
            return null;
        }

        return $results;
    }

    /**
     * Get posts (publish/draft) that have no featured image or FIFU meta, grouped by post type.
     *
     * @param string $post_types_csv Comma-separated list of post types (already sanitized).
     * @return array
     */
    public function get_post_types_without_featured_image(string $post_types_csv): array
    {
        return $this->get_posts_without_featured_image($post_types_csv);
    }

    /**
     * Get ASINs from configured meta keys for posts without FIFU image/thumbnail.
     *
     * @return array
     */
    public function get_asins_without_featured_image(): array
    {
        if (!function_exists('fifu_db2_mode')) {
            return $this->get_asins_without_featured_image_legacy();
        }

        $mode = fifu_db2_mode();

        if ($mode === Fifu_Db2_Mode::MODE_DB2) {
            $db2 = $this->get_asins_without_featured_image_db2(false);
            if ($db2 !== null) {
                return $db2;
            }
            return $this->get_asins_without_featured_image_legacy();
        }

        if ($mode === Fifu_Db2_Mode::MODE_HYBRID) {
            $db2 = $this->get_asins_without_featured_image_db2(true);
            if ($db2 !== null) {
                return $db2;
            }
            return $this->get_asins_without_featured_image_legacy();
        }

        return $this->get_asins_without_featured_image_legacy();
    }

    /**
     * Legacy SQL path for ASINs without FIFU image/thumbnail.
     *
     * @return array
     */
    private function get_asins_without_featured_image_legacy(): array
    {
        [$in, $keys] = Fifu_Db2_Sql_Helper::build_in_from_option_csv('fifu_asin', 'fifu_asin_custom_field');

        $legacy_sent_clause = $this->get_db2_sent_not_exists_clause('post', 'asin', 'pm.post_id');
        $default_attach_id = (int) get_option('fifu_default_attach_id');

        if ($this->has_identifier_db2_tables()) {
            $identifier = $this->fifu_identifier_table;
            $identifierType = $this->fifu_identifier_type_table;
            $db2_sent_clause = $this->get_db2_sent_not_exists_clause('post', 'asin', 'z.post_id');

            $sql = $this->wpdb->prepare(
                "
                SELECT z.post_id, z.asin
                FROM (
                    SELECT i.post_id, i.id_value AS asin
                    FROM {$identifier} i
                    INNER JOIN {$identifierType} t ON t.type_id = i.type_id
                    WHERE t.type_key = 'asin'

                    UNION ALL

                    SELECT pm.post_id, pm.meta_value AS asin
                    FROM {$this->postmeta_table} pm
                    WHERE pm.meta_key IN ($in)
                      AND NOT EXISTS (
                          SELECT 1
                          FROM {$identifier} i2
                          INNER JOIN {$identifierType} t2 ON t2.type_id = i2.type_id
                          WHERE i2.post_id = pm.post_id
                            AND t2.type_key = 'asin'
                      )
                ) z
                INNER JOIN {$this->posts_table} p ON p.ID = z.post_id
                WHERE p.post_status NOT IN ('trash', 'auto-draft')
                  AND p.post_type NOT IN ('attachment', 'revision')
                  AND NOT EXISTS (
                    SELECT 1
                    FROM {$this->postmeta_table} x
                    WHERE x.post_id = z.post_id
                        AND x.meta_key IN ('_thumbnail_id','fifu_image_url','fifu_video_url','fifu_slider_image_url_0','fifu_asin_sent')
                )
                  AND NOT EXISTS (
                      SELECT 1
                      FROM {$this->postmeta_table} thumb_pm
                      WHERE thumb_pm.post_id = z.post_id
                        AND thumb_pm.meta_key = '_thumbnail_id'
                        AND TRIM(COALESCE(thumb_pm.meta_value, '')) <> ''
                        AND TRIM(COALESCE(thumb_pm.meta_value, '')) <> '0'
                        AND TRIM(COALESCE(thumb_pm.meta_value, '')) <> '{$default_attach_id}'
                  )
                  AND NOT EXISTS (
                      SELECT 1
                      FROM {$this->postmeta_table} media_pm
                      WHERE media_pm.post_id = z.post_id
                        AND TRIM(COALESCE(media_pm.meta_value, '')) <> ''
                        AND (
                            media_pm.meta_key IN (
                                'fifu_image_url',
                                'fifu_video_url',
                                'fifu_custom_video_url',
                                'fifu_slider_image_url_0',
                                'fifu_list_url',
                                'fifu_list_video_url',
                                'fifu_slider_list_url',
                                'fifu_asin_sent'
                            )
                            OR media_pm.meta_key LIKE 'fifu_image_url_%'
                            OR media_pm.meta_key LIKE 'fifu_video_url_%'
                            OR media_pm.meta_key LIKE 'fifu_slider_image_url_%'
                        )
                  )
                {$db2_sent_clause}
                ORDER BY z.post_id DESC
            ",
                $keys
            );

            $results = $this->wpdb->get_results($sql);
            if ($results !== false) {
                return $results;
            }
        }

        $sql = $this->wpdb->prepare(
            "SELECT pm.post_id, pm.meta_value AS asin
            FROM {$this->postmeta_table} pm
            INNER JOIN {$this->posts_table} p ON p.ID = pm.post_id
            WHERE pm.meta_key IN ($in)
            AND TRIM(COALESCE(pm.meta_value, '')) <> ''
            AND TRIM(COALESCE(pm.meta_value, '')) NOT LIKE 'not-found:%'
            AND p.post_status NOT IN ('trash', 'auto-draft')
            AND p.post_type NOT IN ('attachment', 'revision')
            AND NOT EXISTS (
                SELECT 1
                FROM {$this->postmeta_table} x
                WHERE x.post_id = pm.post_id
                    AND x.meta_key IN ('_thumbnail_id','fifu_image_url','fifu_video_url','fifu_slider_image_url_0','fifu_asin_sent')
            )
            AND NOT EXISTS (
                SELECT 1
                FROM {$this->postmeta_table} thumb_pm
                WHERE thumb_pm.post_id = pm.post_id
                  AND thumb_pm.meta_key = '_thumbnail_id'
                  AND TRIM(COALESCE(thumb_pm.meta_value, '')) <> ''
                  AND TRIM(COALESCE(thumb_pm.meta_value, '')) <> '0'
                  AND TRIM(COALESCE(thumb_pm.meta_value, '')) <> ?
            )
            AND NOT EXISTS (
                SELECT 1
                FROM {$this->postmeta_table} media_pm
                WHERE media_pm.post_id = pm.post_id
                  AND TRIM(COALESCE(media_pm.meta_value, '')) <> ''
                  AND (
                      media_pm.meta_key IN (
                          'fifu_image_url',
                          'fifu_video_url',
                          'fifu_custom_video_url',
                          'fifu_slider_image_url_0',
                          'fifu_list_url',
                          'fifu_list_video_url',
                          'fifu_slider_list_url',
                          'fifu_asin_sent'
                      )
                      OR media_pm.meta_key LIKE 'fifu_image_url_%'
                      OR media_pm.meta_key LIKE 'fifu_video_url_%'
                      OR media_pm.meta_key LIKE 'fifu_slider_image_url_%'
                  )
            )
            {$legacy_sent_clause}
            ORDER BY post_id DESC",
            array_merge($keys, array($default_attach_id))
        );

        return $this->wpdb->get_results($sql);
    }

    /**
     * DB2 SQL path for ASINs without FIFU image/thumbnail.
     *
     * @return array|null
     */
    private function get_asins_without_featured_image_db2(bool $include_legacy_fallback_blockers = false): ?array
    {
        if (!$this->has_identifier_db2_tables()) {
            return null;
        }

        $identifier = $this->fifu_identifier_table;
        $identifierType = $this->fifu_identifier_type_table;
        $postmeta = $this->postmeta_table;
        $map = $this->fifu_map_table;
        $key = $this->fifu_key_table;
        $sent = $this->fifu_sent_table;
        $sentEvent = $this->fifu_sent_event_table;
        $posts = $this->posts_table;

        [, $customFieldKeys] = Fifu_Db2_Sql_Helper::build_in_from_option_csv('fifu_asin', 'fifu_asin_custom_field', false);

        $fallbackSql = '';
        $args = [];
        if ($customFieldKeys) {
            $inPlaceholder = implode(',', array_fill(0, count($customFieldKeys), '%s'));
            $fallbackSql = "
            UNION ALL
            SELECT pm.post_id, pm.meta_value AS asin
            FROM {$postmeta} pm
            WHERE pm.meta_key IN ({$inPlaceholder})
              AND NOT EXISTS (
                  SELECT 1
                  FROM {$identifier} i2
                  INNER JOIN {$identifierType} t2 ON t2.type_id = i2.type_id
                  WHERE i2.post_id = pm.post_id
                    AND t2.type_key = 'asin'
              )";
            $args = $customFieldKeys;
        }

        $sql = "
            SELECT z.post_id, z.asin
            FROM (
                SELECT i.post_id, i.id_value AS asin
                FROM {$identifier} i
                INNER JOIN {$identifierType} t ON t.type_id = i.type_id
                WHERE t.type_key = 'asin'
                {$fallbackSql}
            ) z
            INNER JOIN {$posts} p ON p.ID = z.post_id
            WHERE NOT EXISTS (
                SELECT 1
                FROM {$postmeta} th
                WHERE th.post_id = z.post_id
                  AND th.meta_key = '_thumbnail_id'
                  AND TRIM(COALESCE(th.meta_value, '')) <> ''
                  AND TRIM(COALESCE(th.meta_value, '')) <> '0'
            )
              AND NOT EXISTS (
                SELECT 1
                FROM {$map} m
                INNER JOIN {$key} k ON k.key_id = m.key_id
                INNER JOIN {$this->fifu_url_table} u ON u.hash = m.hash
                WHERE m.post_id = z.post_id
                  AND m.key_index = 0
                  AND k.key_type IN ('image','video','slider','custom_video')
                  AND TRIM(COALESCE(u.url, '')) <> ''
            )
              AND p.post_status NOT IN ('trash', 'auto-draft')
              AND p.post_type NOT IN ('attachment', 'revision')
              AND NOT EXISTS (
                SELECT 1
                FROM {$sent} s
                INNER JOIN {$sentEvent} e ON e.id = s.event_id
                WHERE s.object_type = 'post'
                  AND s.object_id = z.post_id
                  AND e.event_key = 'asin'
            )
            ORDER BY z.post_id DESC
        ";

        if ($include_legacy_fallback_blockers) {
            $sql = str_replace(
                "            ORDER BY z.post_id DESC\n        ",
                "              AND NOT EXISTS (\n                  SELECT 1\n                  FROM {$postmeta} legacy_pm\n                  WHERE legacy_pm.post_id = z.post_id\n                    AND TRIM(COALESCE(legacy_pm.meta_value, '')) <> ''\n                    AND (\n                        legacy_pm.meta_key IN (\n                            'fifu_image_url',\n                            'fifu_video_url',\n                            'fifu_custom_video_url',\n                            'fifu_slider_image_url_0',\n                            'fifu_list_url',\n                            'fifu_list_video_url',\n                            'fifu_slider_list_url',\n                            'fifu_asin_sent'\n                        )\n                        OR legacy_pm.meta_key LIKE 'fifu_image_url_%'\n                        OR legacy_pm.meta_key LIKE 'fifu_video_url_%'\n                        OR legacy_pm.meta_key LIKE 'fifu_slider_image_url_%'\n                    )\n              )\n            ORDER BY z.post_id DESC\n        ",
                $sql
            );
        }

        if ($args) {
            $sql = $this->wpdb->prepare($sql, ...$args);
        }

        $results = $this->wpdb->get_results($sql);
        if ($results === false) {
            return null;
        }

        return $results;
    }

    /**
     * Get custom fields (post and term) that contain image URLs but do not have FIFU/thumbnail set.
     *
     * @return array
     */
    public function get_customfields_without_featured_image(): array
    {
        if (!function_exists('fifu_db2_mode')) {
            return $this->get_customfields_without_featured_image_legacy();
        }

        $mode = fifu_db2_mode();

        if ($mode === Fifu_Db2_Mode::MODE_DB2 || $mode === Fifu_Db2_Mode::MODE_HYBRID) {
            $db2 = $this->get_customfields_without_featured_image_db2();
            if ($db2 !== null) {
                return $db2;
            }
        }

        return $this->get_customfields_without_featured_image_legacy();
    }

    /**
     * Normalize option keys for custom fields used in the gap check.
     *
     * @return array
     */
    private function build_customfield_keys(): array
    {
        [, $raw] = Fifu_Db2_Sql_Helper::build_in_from_option_csv('', 'fifu_customfield_custom_field');

        $keys = [];
        foreach ($raw as $cf_item) {
            $cf_item = trim((string) $cf_item);
            if ($cf_item === '') {
                continue;
            }
            if (preg_match('/\{(.+?)\}/', $cf_item, $m)) {
                $cf_item = $m[1];
            }
            $keys[] = $cf_item;
        }

        return array_values(array_unique($keys));
    }

    /**
     * Legacy SQL path for custom fields without FIFU/thumbnail metadata.
     *
     * @return array
     */
    private function get_customfields_without_featured_image_legacy(): array
    {
        $keys = $this->build_customfield_keys();
        if (!$keys) {
            return [];
        }

        $postmeta = $this->postmeta_table;
        $termmeta = $this->termmeta_table;
        $map = $this->fifu_map_table;
        $termMap = $this->fifu_term_map_table;
        $keyTable = $this->fifu_key_table;
        $in = implode(',', array_fill(0, count($keys), '%s'));
        $args = array_merge($keys, $keys);

        $sql = $this->wpdb->prepare("
            SELECT post_id AS id, meta_key, meta_value, 0 AS is_ctgr
            FROM {$postmeta} pm
            WHERE pm.meta_key IN ({$in})
            AND NOT EXISTS (
                SELECT 1
                FROM {$postmeta}
                WHERE post_id = pm.post_id
                    AND meta_key IN (CONCAT('_', 'thumbnail_id'),'fifu_image_url','fifu_video_url','fifu_custom_video_url','fifu_slider_image_url_0')
            )

            UNION

            SELECT term_id AS id, meta_key, meta_value, 1 AS is_ctgr
            FROM {$termmeta} tm
            WHERE tm.meta_key IN ({$in})
            AND NOT EXISTS (
                SELECT 1
                FROM {$termmeta}
                WHERE term_id = tm.term_id
                    AND meta_key IN ('thumbnail_id','fifu_image_url','fifu_video_url','fifu_custom_video_url')
            )

            ORDER BY id DESC
        ", $args);

        return $this->wpdb->get_results($sql);
    }

    /**
     * DB2 SQL path for custom fields without FIFU/thumbnail metadata.
     *
     * @return array|null
     */
    private function get_customfields_without_featured_image_db2(): ?array
    {
        if (!$this->has_featured_image_db2_tables()
            || !$this->table_exists($this->fifu_term_map_table)
        ) {
            return null;
        }

        $keys = $this->build_customfield_keys();
        if (!$keys) {
            return [];
        }

        $postmeta = $this->postmeta_table;
        $termmeta = $this->termmeta_table;
        $map = $this->fifu_map_table;
        $termMap = $this->fifu_term_map_table;
        $keyTable = $this->fifu_key_table;
        $in = implode(',', array_fill(0, count($keys), '%s'));
        $args = array_merge($keys, $keys);

        $sql = $this->wpdb->prepare("
            SELECT post_id AS id, meta_key, meta_value, 0 AS is_ctgr
            FROM {$postmeta} pm
            WHERE pm.meta_key IN ({$in})
            AND NOT EXISTS (
                SELECT 1
                FROM {$postmeta} th
                WHERE th.post_id = pm.post_id
                  AND th.meta_key = CONCAT('_', 'thumbnail_id')
            )
            AND NOT EXISTS (
                SELECT 1
                FROM {$map} m
                INNER JOIN {$keyTable} k ON k.key_id = m.key_id
                WHERE m.post_id = pm.post_id
                  AND m.key_index = 0
                  AND k.key_type IN ('video','slider','custom_video')
            )

            UNION

            SELECT term_id AS id, meta_key, meta_value, 1 AS is_ctgr
            FROM {$termmeta} tm
            WHERE tm.meta_key IN ({$in})
            AND NOT EXISTS (
                SELECT 1
                FROM {$termmeta} th
                WHERE th.term_id = tm.term_id
                  AND th.meta_key = 'thumbnail_id'
            )
            AND NOT EXISTS (
                SELECT 1
                FROM {$termMap} mt
                INNER JOIN {$keyTable} tk ON tk.key_id = mt.key_id
                WHERE mt.term_id = tm.term_id
                  AND tk.key_type IN ('video','slider','custom_video')
            )

            ORDER BY id DESC
        ", $args);

        $results = $this->wpdb->get_results($sql);
        if ($results === false) {
            return null;
        }

        return $results;
    }

    /**
     * Get posts that should have screenshots (from configured custom fields) but do not.
     *
     * @return array
     */
    public function get_posts_without_screenshot(): array
    {
        if (!function_exists('fifu_db2_mode')) {
            return $this->get_posts_types_without_screenshot_legacy();
        }

        $mode = fifu_db2_mode();

        if ($mode === Fifu_Db2_Mode::MODE_DB2 || $mode === Fifu_Db2_Mode::MODE_HYBRID) {
            $db2 = $this->get_posts_types_without_screenshot_db2();
            if ($db2 !== null) {
                return $db2;
            }
        }

        return $this->get_posts_types_without_screenshot_legacy();
    }

    /**
     * Normalize screenshots custom field keys.
     *
     * @return array
     */
    private function build_screenshot_customfield_keys(): array
    {
        [, $keys] = Fifu_Db2_Sql_Helper::build_in_from_option_csv('', 'fifu_screenshot_custom_field');
        return array_values(array_filter($keys, static fn($k) => $k !== ''));
    }

    /**
     * Legacy SQL path for posts that should have screenshots.
     *
     * @return array
     */
    private function get_posts_types_without_screenshot_legacy(): array
    {
        $keys = $this->build_screenshot_customfield_keys();
        if (!$keys) {
            return [];
        }

        $postmeta = $this->postmeta_table;
        $in = implode(',', array_fill(0, count($keys), '%s'));

        $sql = $this->wpdb->prepare(
            "SELECT DISTINCT post_id, meta_value AS url
            FROM {$postmeta} pm
            WHERE pm.meta_key IN ({$in})
            AND LEFT(pm.meta_value, 4) = 'http'
            AND NOT EXISTS (
                SELECT 1
                FROM {$postmeta}
                WHERE post_id = pm.post_id
                    AND meta_key IN ('_thumbnail_id','fifu_image_url','fifu_video_url','fifu_custom_video_url','fifu_slider_image_url_0')
            )
            GROUP BY post_id
            ORDER BY post_id DESC",
            $keys
        );

        return $this->wpdb->get_results($sql);
    }

    /**
     * DB2-aware SQL path for posts that should have screenshots.
     *
     * @return array|null
     */
    private function get_posts_types_without_screenshot_db2(): ?array
    {
        if (!$this->has_featured_image_db2_tables()) {
            return null;
        }

        $keys = $this->build_screenshot_customfield_keys();
        if (!$keys) {
            return [];
        }

        $postmeta = $this->postmeta_table;
        $map = $this->fifu_map_table;
        $keyTable = $this->fifu_key_table;
        $in = implode(',', array_fill(0, count($keys), '%s'));

        $sql = $this->wpdb->prepare(
            "SELECT DISTINCT pm.post_id, pm.meta_value AS url
            FROM {$postmeta} pm
            WHERE pm.meta_key IN ({$in})
            AND LEFT(pm.meta_value, 4) = 'http'
            AND NOT EXISTS (
                SELECT 1
                FROM {$postmeta} th
                WHERE th.post_id = pm.post_id
                  AND th.meta_key = '_thumbnail_id'
            )
            AND NOT EXISTS (
                SELECT 1
                FROM {$map} m
                INNER JOIN {$keyTable} k ON k.key_id = m.key_id
                WHERE m.post_id = pm.post_id
                  AND m.key_index = 0
                  AND k.key_type IN ('image','video','slider','custom_video')
            )
            GROUP BY pm.post_id
            ORDER BY pm.post_id DESC",
            $keys
        );

        $results = $this->wpdb->get_results($sql);
        if ($results === false) {
            return null;
        }

        return $results;
    }

    /**
     * Get posts that have FIFU finder URLs but do not yet have FIFU images set or exceeded retries.
     *
     * @return array
     */
    public function get_finders_without_featured_image(): array
    {
        if (!function_exists('fifu_db2_mode')) {
            return $this->get_finders_without_featured_image_legacy();
        }

        $mode = fifu_db2_mode();

        if ($mode === Fifu_Db2_Mode::MODE_DB2 || $mode === Fifu_Db2_Mode::MODE_HYBRID) {
            $db2 = $this->get_finders_without_featured_image_db2();
            if ($db2 !== null) {
                return $db2;
            }
        }

        return $this->get_finders_without_featured_image_legacy();
    }

    /**
     * Legacy SQL path for finders without featured images.
     *
     * @return array
     */
    private function get_finders_without_featured_image_legacy(): array
    {
        [$in, $keys] = Fifu_Db2_Sql_Helper::build_in_from_option_csv('fifu_finder_url', 'fifu_finder_custom_field');

        $postmeta = $this->postmeta_table;

        [$thumbnailCondition, $thumbnailArgs] = $this->build_thumbnail_condition_sql('x');

        $check_default_sql = " OR ({$thumbnailCondition})";
        $args = array_merge($keys, $thumbnailArgs);

        $sent_clause = $this->get_db2_sent_not_exists_clause('post', 'finder', 'pm.post_id');
        $not_found_clause = $this->get_db2_attempts_threshold_not_exists_clause('post', 'finder_not_found', 'pm.post_id', 3);

        if ($this->is_db2_ready()) {
            $map = $this->fifu_map_table;
            $keyTable = $this->fifu_key_table;
            $urlTable = $this->fifu_url_table;
            $posts = $this->posts_table;

            $sent_clause = $this->get_db2_sent_not_exists_clause('post', 'finder', 'source.post_id');
            $not_found_clause = $this->get_db2_attempts_threshold_not_exists_clause('post', 'finder_not_found', 'source.post_id', 3);

            $sql = $this->wpdb->prepare(
                "SELECT source.post_id, MAX(source.webpage_url) AS webpage_url
                FROM (
                    SELECT pm.post_id, pm.meta_value AS webpage_url
                    FROM {$postmeta} pm
                    INNER JOIN {$posts} p ON p.ID = pm.post_id
                    WHERE pm.meta_key IN ($in)
                      AND pm.meta_value LIKE 'http%'
                      AND p.post_status <> 'trash'

                    UNION ALL

                    SELECT m.post_id, u.url AS webpage_url
                    FROM {$map} m
                    INNER JOIN {$keyTable} kf ON kf.key_id = m.key_id
                    INNER JOIN {$urlTable} u ON u.hash = m.hash
                    INNER JOIN {$posts} p ON p.ID = m.post_id
                    WHERE kf.key_type = 'finder'
                      AND m.key_index = 0
                      AND u.url LIKE 'http%'
                      AND p.post_status <> 'trash'
                ) source
                WHERE NOT EXISTS (
                    SELECT 1
                    FROM {$postmeta} x
                    WHERE x.post_id = source.post_id
                      AND (
                          x.meta_key IN ('fifu_image_url','fifu_video_url','fifu_custom_video_url','fifu_slider_image_url_0','fifu_finder_sent')
                          {$check_default_sql}
                          OR (x.meta_key = 'fifu_finder_counter' AND x.meta_value >= 3)
                      )
                )
                {$sent_clause}
                {$not_found_clause}
                GROUP BY source.post_id
                ORDER BY source.post_id DESC",
                $args
            );

            return $this->wpdb->get_results($sql);
        }

        $sql = $this->wpdb->prepare(
            "SELECT post_id, meta_value AS webpage_url
            FROM {$postmeta} pm
            INNER JOIN {$this->posts_table} p ON p.ID = pm.post_id
            WHERE pm.meta_key IN ($in)
            AND pm.meta_value LIKE 'http%'
            AND p.post_status <> 'trash'
            AND NOT EXISTS (
                SELECT 1
                FROM {$postmeta} x
                WHERE x.post_id = pm.post_id
                  AND (
                      x.meta_key IN ('fifu_image_url','fifu_video_url','fifu_custom_video_url','fifu_slider_image_url_0','fifu_finder_sent')
                      {$check_default_sql}
                      OR (x.meta_key = 'fifu_finder_counter' AND x.meta_value >= 3)
                  )
            )
            {$sent_clause}
            {$not_found_clause}
            ORDER BY post_id DESC",
            $args
        );

        return $this->wpdb->get_results($sql);
    }

    /**
     * DB2 SQL path for finders without featured images.
     *
     * @return array|null
     */
    private function get_finders_without_featured_image_db2(): ?array
    {
        if (!$this->has_finder_db2_tables()) {
            return null;
        }

        [$in, $keys] = Fifu_Db2_Sql_Helper::build_in_from_option_csv('fifu_finder_url', 'fifu_finder_custom_field');
        if (!$keys) {
            return [];
        }

        [$thumbnailCondition, $thumbnailArgs] = $this->build_thumbnail_condition_sql('x');
        $args = array_merge($keys, $thumbnailArgs);

        $postmeta  = $this->postmeta_table;
        $map       = $this->fifu_map_table;
        $keyTable  = $this->fifu_key_table;
        $urlTable  = $this->fifu_url_table;
        $sent      = $this->fifu_sent_table;
        $sentEvent = $this->fifu_sent_event_table;
        $posts     = $this->posts_table;

        $sql = $this->wpdb->prepare(
            "SELECT source.post_id, MAX(source.webpage_url) AS webpage_url
            FROM (
                SELECT pm.post_id, pm.meta_value AS webpage_url
                FROM {$postmeta} pm
                INNER JOIN {$posts} p ON p.ID = pm.post_id
                WHERE pm.meta_key IN ($in)
                  AND pm.meta_value LIKE 'http%'
                  AND p.post_status <> 'trash'

                UNION ALL

                SELECT m.post_id, u.url AS webpage_url
                FROM {$map} m
                INNER JOIN {$keyTable} kf ON kf.key_id = m.key_id
                INNER JOIN {$urlTable} u ON u.hash = m.hash
                INNER JOIN {$posts} p ON p.ID = m.post_id
                WHERE kf.key_type = 'finder'
                  AND m.key_index = 0
                  AND u.url LIKE 'http%'
                  AND p.post_status <> 'trash'
            ) source
            WHERE NOT EXISTS (
                SELECT 1
                FROM {$postmeta} x
                WHERE x.post_id = source.post_id
                  AND (
                      ({$thumbnailCondition})
                      OR (x.meta_key = 'fifu_custom_video_url' AND x.meta_value LIKE 'http%')
                  )
            )
            AND NOT EXISTS (
                SELECT 1
                FROM {$map} m
                INNER JOIN {$keyTable} k ON k.key_id = m.key_id
                WHERE m.post_id = source.post_id
                  AND m.key_index = 0
                  AND k.key_type IN ('image','video','custom_video','slider')
            )
            AND NOT EXISTS (
                SELECT 1
                FROM {$sent} s
                INNER JOIN {$sentEvent} e ON e.id = s.event_id
                WHERE s.object_type = 'post'
                  AND s.object_id = source.post_id
                  AND (
                    (e.event_key = 'finder' AND s.sent = 1)
                    OR (e.event_key = 'finder_not_found' AND s.attempts >= 3)
                  )
            )
            GROUP BY source.post_id
            ORDER BY source.post_id DESC",
            $args
        );

        $results = $this->wpdb->get_results($sql);
        if ($results === false) {
            return null;
        }

        return $results;
    }

    /**
     * Return the thumbnail ID stored for a specific category term.
     *
     * @param int $term_id
     * @return int|null
     */
    public function get_category_thumbnail_id(int $term_id): ?int {
        $sql = $this->wpdb->prepare(
            "SELECT meta_value FROM {$this->termmeta_table} WHERE term_id = %d AND meta_key = 'thumbnail_id'",
            $term_id
        );
        $value = $this->wpdb->get_var($sql);
        return $value !== null ? (int) $value : null;
    }

    /**
     * Determine the categories associated with a given post.
     *
     * @param int $post_id
     * @return array
     */
    public function get_category_id_from_post(int $post_id): array {
        $postId = (int) $post_id;

        if (!function_exists('fifu_db2_mode')) {
            return $this->get_category_id_legacy($postId);
        }

        $mode = fifu_db2_mode();

        if ($mode === Fifu_Db2_Mode::MODE_DB2) {
            $db2 = $this->get_category_id_db2($postId);
            if ($db2 !== null) {
                return $db2;
            }
            return $this->get_category_id_legacy($postId);
        }

        if ($mode === Fifu_Db2_Mode::MODE_HYBRID) {
            $db2 = $this->get_category_id_db2($postId) ?? [];
            $legacy = $this->get_category_id_legacy($postId);

            if (class_exists('Fifu_Db2_Query_Helper')) {
                return Fifu_Db2_Query_Helper::merge_unique_rows_by_int_field(
                    $db2,
                    $legacy,
                    'term_id'
                );
            }

            return $this->merge_rows_by_term_id($db2, $legacy);
        }

        return $this->get_category_id_legacy($postId);
    }

    /**
     * Legacy SQL path for the category lookup.
     *
     * @param int $postId
     * @return array
     */
    private function get_category_id_legacy(int $postId): array {
        $sql = $this->wpdb->prepare(
            "SELECT tm.term_id, tt.parent
            FROM {$this->termmeta_table} tm
            INNER JOIN {$this->term_taxonomy_table} tt ON tm.term_id = tt.term_id
            INNER JOIN {$this->term_relationships_table} rs ON tt.term_taxonomy_id = rs.term_taxonomy_id
            INNER JOIN {$this->postmeta_table} pm ON pm.post_id = rs.object_id
            WHERE pm.post_id = %d
              AND pm.meta_key = 'fifu_image_url'
              AND tm.meta_key = pm.meta_key
              AND tm.meta_value = pm.meta_value
              AND pm.meta_value <> ''
              AND tt.taxonomy = 'product_cat'",
            $postId
        );

        return $this->wpdb->get_results($sql);
    }

    /**
     * DB2 SQL path for the category lookup.
     *
     * @param int $postId
     * @return array|null
     */
    private function get_category_id_db2(int $postId): ?array {
        if (!$this->has_category_db2_tables()) {
            return null;
        }

        $sql = $this->wpdb->prepare(
            "SELECT DISTINCT tm.term_id
            FROM {$this->term_relationships_table} tr
            INNER JOIN {$this->term_taxonomy_table} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
            INNER JOIN {$this->fifu_map_table} m ON m.post_id = tr.object_id
            INNER JOIN {$this->fifu_key_table} k_post ON k_post.key_id = m.key_id
            INNER JOIN {$this->fifu_term_map_table} tm ON tm.term_id = tt.term_id
            INNER JOIN {$this->fifu_key_table} k_term ON k_term.key_id = tm.key_id
            INNER JOIN {$this->fifu_url_table} u_post ON u_post.hash = m.hash
            WHERE tr.object_id = %d
              AND tt.taxonomy = 'product_cat'
              AND k_post.key_type = 'image'
              AND k_term.key_type = 'image'
              AND m.key_index = 0
              AND tm.hash = m.hash
              AND u_post.url IS NOT NULL
              AND u_post.url <> ''",
            $postId
        );

        $results = $this->wpdb->get_results($sql);
        if ($results === false) {
            return null;
        }

        return $results;
    }

    /**
     * Determine whether all DB2 tables needed for this lookup are present.
     *
     * @return bool
     */
    private function has_category_db2_tables(): bool {
        $tables = [
            $this->fifu_map_table,
            $this->fifu_term_map_table,
            $this->fifu_key_table,
            $this->fifu_url_table,
        ];

        foreach ($tables as $table) {
            if (!$this->table_exists($table)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Merge primary and secondary rows without duplicates by term_id.
     *
     * @param array $primary
     * @param array $secondary
     * @return array
     */
    private function merge_rows_by_term_id(array $primary, array $secondary): array {
        $merged = [];
        $seen = [];

        foreach ($primary as $row) {
            $termId = $this->extract_term_id($row);
            if ($termId === null || isset($seen[$termId])) {
                continue;
            }
            $seen[$termId] = true;
            $merged[] = $row;
        }

        foreach ($secondary as $row) {
            $termId = $this->extract_term_id($row);
            if ($termId === null || isset($seen[$termId])) {
                continue;
            }
            $seen[$termId] = true;
            $merged[] = $row;
        }

        return array_values($merged);
    }

    /**
     * Extract an integer term_id from a result row.
     *
     * @param mixed $row
     * @return int|null
     */
    private function extract_term_id($row): ?int {
        if (is_array($row)) {
            if (!array_key_exists('term_id', $row)) {
                return null;
            }
            $value = $row['term_id'];
        } elseif (is_object($row)) {
            if (!property_exists($row, 'term_id')) {
                return null;
            }
            $value = $row->term_id;
        } else {
            return null;
        }

        if (is_string($value)) {
            $value = trim($value);
        }

        $integer = filter_var($value, FILTER_VALIDATE_INT);
        if ($integer === false || $integer === null) {
            return null;
        }

        return $integer;
    }

    /**
     * Return every child category that may inherit FIFU metadata.
     *
     * @return array
     */
    public function get_child_categories(): array {
        $sql = "
            SELECT DISTINCT tt.term_id, tt.parent, tt.count
            FROM {$this->term_taxonomy_table} tt
            INNER JOIN {$this->termmeta_table} tm ON tm.term_id = tt.term_id
            WHERE tt.parent <> 0
              AND tt.taxonomy = 'product_cat'
            ORDER BY tt.count DESC
        ";
        return $this->wpdb->get_results($sql);
    }

    /**
     * Check if a child category already has an attachment.
     *
     * @param int $term_id
     * @param int $parent_term_id
     * @return bool
     */
    public function exists_child_with_attachment(int $term_id, int $parent_term_id): bool {
        $sql = $this->wpdb->prepare(
            "SELECT 1
            FROM {$this->termmeta_table}
            WHERE term_id = %d
              AND meta_key = 'thumbnail_id'
              AND meta_value <> 0
              AND NOT EXISTS (
                  SELECT 1
                  FROM {$this->termmeta_table} tm2
                  WHERE tm2.term_id = %d
                    AND tm2.meta_key = 'thumbnail_id'
                    AND tm2.meta_value <> 0
              )",
            $term_id,
            $parent_term_id
        );
        return (bool) $this->wpdb->get_var($sql);
    }
}
