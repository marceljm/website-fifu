<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Provides read access to post finder metadata.
 */
final class Fifu_Post_Finder_Read_Service
{
    /**
     * Returns the finder URL for a post, using db2 first and falling back to postmeta.
     *
     * @param int $postId
     * @return string|null
     */
    public static function get_finder_url(int $postId): ?string
    {
        if (function_exists('fifu_db2_manager')) {
            $manager = fifu_db2_manager();
            if ($manager instanceof Fifu_Db2_Manager) {
                $mapping = $manager->getPostMapping($postId, 'finder', 0);
                if (is_array($mapping) && !empty($mapping['url'])) {
                    return (string) $mapping['url'];
                }
            }
        }

        $legacyUrl = get_post_meta($postId, 'fifu_finder_url', true);
        if ($legacyUrl === '' || $legacyUrl === null) {
            return null;
        }

        return (string) $legacyUrl;
    }
}
