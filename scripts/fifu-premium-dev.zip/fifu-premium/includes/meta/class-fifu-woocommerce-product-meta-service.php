<?php

declare(strict_types=1);

defined('ABSPATH') || exit;

/**
 * Handles future migration targets for WooCommerce product metadata.
 */
class Fifu_Woocommerce_Product_Meta_Service {
    /**
     * Future: returns the default selected variations for a variable product.
     */
    public static function get_default_selected_variations( int $product_id ): array {
        $product = wc_get_product( $product_id );
        if ( ! $product || ! $product->is_type( 'variable' ) ) {
            return [];
        }

        $defaults = $product->get_default_attributes();
        if ( empty( $defaults ) ) {
            return [];
        }

        $selected_values = [];
        foreach ( $defaults as $attribute_key => $attribute_value ) {
            if ( $attribute_value === '' || $attribute_value === null ) {
                continue;
            }

            $attribute_key = strpos( $attribute_key, 'attribute_' ) === 0 ? $attribute_key : 'attribute_' . $attribute_key;
            $selected_values[ $attribute_key ] = $attribute_value;
        }

        return $selected_values;
    }

    /**
     * Future: filters URLs based on the default selected variations.
     */
    public static function get_filtered_urls_by_selected_variations( int $product_id, array $url_map, array $attribute_map ): array {
        $selected_variations = self::get_default_selected_variations( $product_id );

        if ( empty( $selected_variations ) ) {
            return array_values( array_unique( $url_map[ $product_id ] ?? [] ) );
        }

        $matching_variation_ids = [];
        foreach ( $attribute_map as $attr_key => $values ) {
            if ( isset( $selected_variations[ $attr_key ] ) ) {
                $selected_value = $selected_variations[ $attr_key ];
                if ( isset( $values[ $selected_value ] ) ) {
                    if ( empty( $matching_variation_ids ) ) {
                        $matching_variation_ids = $values[ $selected_value ];
                    } else {
                        $matching_variation_ids = array_intersect( $matching_variation_ids, $values[ $selected_value ] );
                    }
                }
            }
        }

        if ( empty( $matching_variation_ids ) ) {
            return array_values( array_unique( $url_map[ $product_id ] ?? [] ) );
        }

        $filtered_urls = [];
        foreach ( $matching_variation_ids as $variation_id ) {
            if ( ! empty( $url_map[ $variation_id ] ) ) {
                $filtered_urls = array_merge( $filtered_urls, $url_map[ $variation_id ] );
            }
        }

        $filtered_urls = array_values( array_unique( $filtered_urls ) );

        if ( empty( $filtered_urls ) ) {
            return array_values( array_unique( $url_map[ $product_id ] ?? [] ) );
        }

        return $filtered_urls;
    }

    /**
     * Future: gathers variation URLs and image lists for a variable product.
     */
    public static function get_variation_data( int $product_id ): array {
        $data = [];

        $product = wc_get_product( $product_id );
        if ( ! $product || ! $product->is_type( 'variable' ) ) {
            return $data;
        }

        $variation_ids = $product->get_children();
        foreach ( $variation_ids as $variation_id ) {
            $variation = wc_get_product( $variation_id );

            if ( ! $variation ) {
                continue;
            }

            $variation_url = get_permalink( $variation_id );

            $image_ids  = [];
            $featured_id = $variation->get_image_id();
            if ( $featured_id ) {
                $image_ids[] = $featured_id;
            }

            $gallery_ids = $variation->get_gallery_image_ids();
            if ( ! empty( $gallery_ids ) ) {
                $image_ids = array_merge( $image_ids, $gallery_ids );
            }

            $image_urls = [];
            foreach ( $image_ids as $id ) {
                $url = wp_get_attachment_url( $id );
                if ( $url ) {
                    $image_urls[] = $url;
                }
            }

            if ( ! empty( $image_urls ) ) {
                $data[ $variation_id ] = [
                    'url'    => $variation_url,
                    'images' => $image_urls,
                ];
            }
        }

        return $data;
    }

    /**
     * Future: determines if the video list takes priority over the image list.
     */
    public static function has_video_list_priority( WC_Product $product ): bool {
        $meta_data = $product->get_meta_data();
        if ( is_array( $meta_data ) ) {
            foreach ( $meta_data as $meta ) {
                if ( ( $meta->key ?? '' ) === 'fifu_list_url' ) {
                    return false;
                }
                if ( ( $meta->key ?? '' ) === 'fifu_list_video_url' ) {
                    return true;
                }
            }
        }
        return false;
    }

    public static function before_product_save( $product ): void {
        if (!($product instanceof WC_Product)) {
            return;
        }

        $product_data = $product->get_data();
        $ids = $product_data['gallery_image_ids'] ?? [];
        $featured_id = method_exists($product, 'get_image_id') ? (int) $product->get_image_id() : 0;
        $ids = self::normalize_gallery_attachment_ids($ids, $featured_id);
        $product_id = method_exists($product, 'get_id') ? (int) $product->get_id() : 0;
        $has_fifu_payload = self::product_has_fifu_image_list_import_payload($product);
        $has_db2_backed_gallery_state = self::product_has_db2_backed_fifu_gallery_state($product_id, $ids);

        if ($ids && !$has_fifu_payload && !$has_db2_backed_gallery_state) {
            update_post_meta($product_id, 'fifu_tmp_product_image_gallery', implode(',', $ids));
        } else {
            delete_post_meta($product_id, 'fifu_tmp_product_image_gallery');
        }
    }

    private static function product_has_fifu_image_list_import_payload($product): bool
    {
        if (!is_object($product) || !method_exists($product, 'get_meta_data')) {
            return false;
        }

        foreach ((array) $product->get_meta_data() as $meta) {
            $key = null;

            if (is_object($meta)) {
                if (method_exists($meta, 'get_data')) {
                    $data = $meta->get_data();
                    if (is_array($data)) {
                        $key = $data['key'] ?? null;
                    }
                } elseif (method_exists($meta, 'get_key')) {
                    $key = $meta->get_key();
                } elseif (isset($meta->key)) {
                    $key = $meta->key;
                }
            } elseif (is_array($meta)) {
                $key = $meta['key'] ?? null;
            }

            if ($key === 'fifu_list_url') {
                return true;
            }
        }

        return false;
    }

    /**
     * Detects DB2-backed FIFU gallery state after imports where legacy payload
     * metadata such as fifu_list_url has already been cleaned up.
     *
     * @param int[] $gallery_attachment_ids
     */
    private static function product_has_db2_backed_fifu_gallery_state(int $product_id, array $gallery_attachment_ids): bool
    {
        if ($product_id <= 0 || empty($gallery_attachment_ids)) {
            return false;
        }

        if (self::post_has_active_legacy_image_list_payload($product_id)) {
            return false;
        }

        $db2_gallery_urls = self::get_db2_gallery_urls($product_id);
        if (empty($db2_gallery_urls)) {
            return false;
        }

        foreach ($gallery_attachment_ids as $attachment_id) {
            $attachment_url = self::get_fifu_attachment_remote_url((int) $attachment_id);
            if ($attachment_url === '') {
                return false;
            }

            if (!in_array($attachment_url, $db2_gallery_urls, true)) {
                return false;
            }
        }

        return true;
    }

    private static function post_has_active_legacy_image_list_payload(int $product_id): bool
    {
        if ($product_id <= 0) {
            return false;
        }

        foreach (['fifu_list_url', 'fifu_image_url', 'fifu_image_url_0', 'fifu_image_url_1'] as $key) {
            $value = trim((string) get_post_meta($product_id, $key, true));
            if ($value !== '') {
                return true;
            }
        }

        return false;
    }

    /**
     * @return string[]
     */
    private static function get_db2_gallery_urls(int $product_id): array
    {
        if (!function_exists('fifu_db2_manager')) {
            return [];
        }

        $manager = fifu_db2_manager();
        if (!is_object($manager) || !method_exists($manager, 'getPostMappings')) {
            return [];
        }

        $rows = $manager->getPostMappings($product_id, 'image');
        if (!is_array($rows) || empty($rows)) {
            return [];
        }

        $urls = [];

        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }

            $key_index = (int) ($row['key_index'] ?? 0);
            if ($key_index <= 0) {
                continue;
            }

            $url = trim((string) ($row['url'] ?? ''));
            if ($url === '') {
                continue;
            }

            $urls[] = $url;
        }

        return array_values(array_unique($urls));
    }

    private static function get_fifu_attachment_remote_url(int $attachment_id): string
    {
        if ($attachment_id <= 0) {
            return '';
        }

        $attachment = get_post($attachment_id);
        if (!$attachment || ($attachment->post_type ?? '') !== 'attachment') {
            return '';
        }

        if (!self::is_fifu_owned_attachment($attachment)) {
            return '';
        }

        $url = trim((string) ($attachment->post_content_filtered ?? ''));
        if ($url === '') {
            $url = trim((string) get_post_meta($attachment_id, '_wp_attached_file', true));
        }

        if ($url === '' || !preg_match('#^https?://#i', $url)) {
            return '';
        }

        return $url;
    }

    private static function is_fifu_owned_attachment($attachment): bool
    {
        $author = (string) ($attachment->post_author ?? '');

        return in_array($author, ['7777777777', '77777'], true);
    }

    /**
     * Removes the featured attachment from the gallery list and de-duplicates IDs.
     */
    private static function normalize_gallery_attachment_ids(array $ids, int $featured_id): array {
        $normalized = [];

        foreach ($ids as $id) {
            $id = (int) $id;
            if ($id <= 0 || $id === $featured_id) {
                continue;
            }

            $normalized[] = $id;
        }

        return array_values(array_unique($normalized));
    }
}
