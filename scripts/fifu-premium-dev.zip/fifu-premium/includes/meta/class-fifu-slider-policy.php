<?php

defined( 'ABSPATH' ) || exit;

/**
 * Handles slider visibility concerns for posts.
 */
class Fifu_Slider_Policy {

    /**
     * Validates whether the current locale allows slider rendering.
     *
     * @return bool
     */
    public static function is_valid_locale(): bool {
        return ! ( class_exists( 'WooCommerce' ) && is_cart() );
    }

    /**
     * Determines if the slider defined for a post is empty.
     *
     * @param int $post_id Post ID to inspect.
     * @return bool
     */
    public static function is_empty( int $post_id ): bool {
        if ( ! class_exists( 'Fifu_Post_Slider_List_Url_Read_Service', false ) ) {
            $service_path = __DIR__ . '/class-fifu-post-slider-list-url-read-service.php';
            if ( is_readable( $service_path ) ) {
                require_once $service_path;
            }
        }

        if ( class_exists( 'Fifu_Post_Slider_List_Url_Read_Service', false ) ) {
            return empty( Fifu_Post_Slider_List_Url_Read_Service::get_slider_list_urls( $post_id ) );
        }

        return true;
    }

    /**
     * Indicates whether a slider image should be shown for a post.
     *
     * @param int         $post_id    Post ID to evaluate.
     * @param string|null $slider_url Slider URL being considered.
     * @return bool
     */
    public static function should_show_slider_image( int $post_id, ?string $slider_url ): bool {
        if ( ! $slider_url ) {
            return false;
        }

        $featured_url = Fifu_Post_Main_Image_Resolver::get_main_image_url( get_queried_object_id(), true );
        $is_featured  = $featured_url && $featured_url === $slider_url;

        if ( ! $is_featured && Fifu_Options_Utils::is_on( 'fifu_slider_single' ) ) {
            return false;
        }

        return self::is_valid_locale();
    }
}
