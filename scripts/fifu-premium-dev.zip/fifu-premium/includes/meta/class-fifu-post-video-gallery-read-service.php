<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Provides read access to video gallery URLs only.
 *
 * This service is exclusive to the admin/UI video gallery semantics.
 * In db2, key_index 0 stores the featured video (fifu_video_url), so gallery
 * items start at key_index 1 and the gallery lookup uses $index + 1.
 */
final class Fifu_Post_Video_Gallery_Read_Service
{
    /**
     * Returns the N-th gallery video URL for a post, using db2 first and falling back to postmeta.
     *
     * @param int $postId
     * @param int $index
     * @return string|null
     */
    public static function get_video_url(int $postId, int $index): ?string
    {
        if ($index < 0) {
            return null;
        }

        if (function_exists('fifu_db2_manager')) {
            $manager = fifu_db2_manager();
            if ($manager instanceof Fifu_Db2_Manager) {
                $mapping = $manager->getPostMapping($postId, 'video', $index + 1);
                if (is_array($mapping) && !empty($mapping['url'])) {
                    return (string) $mapping['url'];
                }
            }
        }

        $legacyUrl = get_post_meta($postId, 'fifu_video_url_' . $index, true);
        if ($legacyUrl === '' || $legacyUrl === null) {
            return null;
        }

        return (string) $legacyUrl;
    }
}
