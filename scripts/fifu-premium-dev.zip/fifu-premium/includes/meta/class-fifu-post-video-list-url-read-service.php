<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Provides export access to the normalized video list.
 */
final class Fifu_Post_Video_List_Url_Read_Service
{
    /**
     * Returns the normalized video list from DB2, falling back to legacy
     * fifu_list_video_url only when DB2 has no exportable entries.
     */
    public static function get_video_list_url(int $postId): ?string
    {
        $db2List = self::get_db2_video_list($postId);

        if ($db2List !== null) {
            return $db2List;
        }

        return self::get_legacy_video_list_url($postId);
    }

    private static function get_db2_video_list(int $postId): ?string
    {
        if (!function_exists('fifu_db2_manager')) {
            return null;
        }

        $manager = fifu_db2_manager();

        if (
            !$manager instanceof Fifu_Db2_Manager
            || !method_exists($manager, 'getPostMappings')
        ) {
            return null;
        }

        try {
            $customVideoRows = $manager->getPostMappings(
                $postId,
                'custom_video'
            );

            $normalVideoRows = $manager->getPostMappings(
                $postId,
                'video'
            );
        } catch (\Throwable $throwable) {
            return null;
        }

        $entries = [];

        $repository = self::get_video_oembed_repository();

        if ($repository !== null) {
            foreach (
                self::sort_mapping_rows($customVideoRows)
                as $row
            ) {
                $videoUrl = self::get_mapping_url($row);

                if ($videoUrl === '') {
                    continue;
                }

                try {
                    $posterUrl = $repository
                        ->get_image_url_by_video_url($videoUrl);
                } catch (\Throwable $throwable) {
                    $posterUrl = null;
                }

                $posterUrl = trim((string) $posterUrl);

                if ($posterUrl === '') {
                    continue;
                }

                $entries[] = $videoUrl . '\\' . $posterUrl;
            }
        }

        foreach (
            self::sort_mapping_rows($normalVideoRows)
            as $row
        ) {
            $videoUrl = self::get_mapping_url($row);

            if ($videoUrl === '') {
                continue;
            }

            $entries[] = $videoUrl;
        }

        return $entries ? implode('|', $entries) : null;
    }

    /**
     * @param mixed $rows
     * @return array<int,array<string,mixed>>
     */
    private static function sort_mapping_rows($rows): array
    {
        if (!is_array($rows)) {
            return [];
        }

        $normalized = array_values(
            array_filter(
                $rows,
                static function ($row): bool {
                    return is_array($row);
                }
            )
        );

        usort(
            $normalized,
            static function (array $left, array $right): int {
                return ((int) ($left['key_index'] ?? 0))
                    <=> ((int) ($right['key_index'] ?? 0));
            }
        );

        return $normalized;
    }

    /**
     * @param array<string,mixed> $row
     */
    private static function get_mapping_url(array $row): string
    {
        return trim((string) ($row['url'] ?? ''));
    }

    /**
     * @return object|null
     */
    private static function get_video_oembed_repository(): ?object
    {
        if (
            !class_exists('Fifu_Video_Oembed_Service')
            || !method_exists(
                'Fifu_Video_Oembed_Service',
                'instance'
            )
        ) {
            return null;
        }

        try {
            $service = Fifu_Video_Oembed_Service::instance();

            if (
                !is_object($service)
                || !method_exists($service, 'get_repository')
            ) {
                return null;
            }

            $repository = $service->get_repository();

            if (
                !is_object($repository)
                || !method_exists(
                    $repository,
                    'get_image_url_by_video_url'
                )
            ) {
                return null;
            }

            return $repository;
        } catch (\Throwable $throwable) {
            return null;
        }
    }

    private static function get_legacy_video_list_url(
        int $postId
    ): ?string {
        $legacy = (string) get_post_meta(
            $postId,
            'fifu_list_video_url',
            true
        );

        $legacy = rtrim(trim($legacy), '|');

        return $legacy === '' ? null : $legacy;
    }
}
