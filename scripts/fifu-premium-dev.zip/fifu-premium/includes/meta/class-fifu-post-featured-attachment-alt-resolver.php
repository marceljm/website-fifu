<?php
declare(strict_types=1);

defined('ABSPATH') || exit;

/**
 * Resolves the logical ALT for a post's featured attachment.
 */
final class Fifu_Post_Featured_Attachment_Alt_Resolver
{
    public static function resolve(int $postId, ?string $resolvedUrl): ?string
    {
        $resolvedUrl = self::normalize_attachment_url($resolvedUrl);
        if ($resolvedUrl === null) {
            return Fifu_Post_Image_Alt_Read_Service::get_image_alt($postId);
        }

        $sliderUrl0 = self::normalize_attachment_url(
            Fifu_Post_Slider_Image_Url_Read_Service::get_slider_image_url($postId, 0)
        );
        if ($sliderUrl0 !== null && $sliderUrl0 === $resolvedUrl) {
            return Fifu_Post_Slider_Image_Alt_Read_Service::get_slider_image_alt($postId, 0);
        }

        return Fifu_Post_Image_Alt_Read_Service::get_image_alt($postId);
    }

    private static function normalize_attachment_url(?string $value): ?string
    {
        if ($value === null) {
            return null;
        }

        $normalized = trim(htmlspecialchars_decode($value));
        return $normalized === '' ? null : $normalized;
    }
}
