<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Provides read access to slider image URL metadata.
 */
final class Fifu_Post_Slider_Image_Url_Read_Service
{
    /**
     * Returns the slider image URL for a post and a given index,
     * using db2 first and falling back to postmeta.
     *
     * @param int $postId
     * @param int $index
     * @return string|null
     */
    public static function get_slider_image_url(int $postId, int $index): ?string
    {
        if ($index < 0) {
            return null;
        }

        if (function_exists('fifu_db2_manager')) {
            $manager = fifu_db2_manager();
            if ($manager instanceof Fifu_Db2_Manager) {
                $mapping = $manager->getPostMapping($postId, 'slider', $index);
                if (is_array($mapping) && !empty($mapping['url'])) {
                    return (string) $mapping['url'];
                }
            }
        }

        $metaKey = 'fifu_slider_image_url_' . $index;
        $legacyUrl = get_post_meta($postId, $metaKey, true);
        if ($legacyUrl === '' || $legacyUrl === null) {
            $indexedLegacyUrls = class_exists('Fifu_Post_Slider_List_Url_Read_Service', false)
                ? Fifu_Post_Slider_List_Url_Read_Service::get_indexed_legacy_slider_urls($postId)
                : [];

            if (isset($indexedLegacyUrls[$index])) {
                return $indexedLegacyUrls[$index];
            }

            $listUrls = class_exists('Fifu_Post_Slider_List_Url_Read_Service', false)
                ? Fifu_Post_Slider_List_Url_Read_Service::get_legacy_slider_list_urls($postId)
                : [];

            return $listUrls[$index] ?? null;
        }

        return (string) $legacyUrl;
    }
}
