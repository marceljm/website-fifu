<?php
declare(strict_types=1);

defined('ABSPATH') || exit;

final class Fifu_Auto_Category_Image_Service
{
    public static array $run_calls = [];

    private static function debug(string $message, array $context = []): void
    {
        if (!function_exists('get_option') || !get_option('fifu_debug_auto_category')) {
            return;
        }

        if (function_exists('wp_json_encode')) {
            error_log('[FIFU Auto Category] ' . $message . ' ' . wp_json_encode($context));
            return;
        }

        error_log('[FIFU Auto Category] ' . $message . ' ' . json_encode($context));
    }

    public static function run(): void
    {
        self::$run_calls[] = true;
        self::debug('run_start', [
            'auto_category' => get_option('fifu_auto_category'),
            'auto_category_created' => get_option('fifu_auto_category_created'),
            'db2_mode_function' => function_exists('fifu_db2_mode'),
            'db2_mode' => function_exists('fifu_db2_mode') ? fifu_db2_mode() : null,
        ]);
        self::cleanup_local_media();
        self::debug('after_cleanup_local_media');
        self::run_speed_up_category_assign();
        self::debug('after_speed_up_category_assign');
        self::run_meta_gap_fill();
        self::debug('after_meta_gap_fill');
        self::propagate_subcategory_thumbnails();
        self::debug('run_end');
    }

    private static function cleanup_local_media(): void
    {
        global $wpdb;

        $cleanup = new Fifu_Local_Media_Cleanup($wpdb, (int) Fifu_Options_Utils::get_author());
        $cleanup->delete_empty_post_urls();
        $cleanup->delete_empty_category_urls();
    }

    private static function run_speed_up_category_assign(): void
    {
        self::debug('speed_up_start', [
            'repository_function_exists_before_bootstrap' => function_exists('fifu_db2_speed_up_repository'),
        ]);
        if (!function_exists('fifu_db2_speed_up_repository') && function_exists('add_action')) {
            $bootstrap = dirname(__DIR__, 2) . '/admin/db2/bootstrap-db2.php';
            if (is_file($bootstrap)) {
                require_once $bootstrap;
            }
        }

        self::debug('speed_up_after_bootstrap', [
            'repository_function_exists' => function_exists('fifu_db2_speed_up_repository'),
            'db2_mode_function_exists' => function_exists('fifu_db2_mode'),
            'db2_mode' => function_exists('fifu_db2_mode') ? fifu_db2_mode() : null,
        ]);

        if (!function_exists('fifu_db2_speed_up_repository')) {
            self::debug('speed_up_abort_missing_repository_function');
            return;
        }

        $repository = fifu_db2_speed_up_repository();
        if (!$repository) {
            self::debug('speed_up_abort_empty_repository');
            return;
        }

        $service = new Fifu_Db2_Speed_Up_Service($repository);
        self::debug('speed_up_before_auto_assign');
        $service->auto_assign_category_images();
        self::debug('speed_up_after_auto_assign');
        self::debug('speed_up_before_auto_update');
        $service->auto_update_category_images();
        self::debug('speed_up_after_auto_update');
    }

    private static function run_meta_gap_fill(): void
    {
        Fifu_Meta_Gap_Fill_Service::backfill_term_attachments();
    }

    private static function propagate_subcategory_thumbnails(): void
    {
        $repository = new Fifu_Meta_Gap_Repository();
        foreach ($repository->get_child_categories() as $child) {
            $termId = isset($child->term_id) ? (int) $child->term_id : 0;
            $parentId = isset($child->parent) ? (int) $child->parent : 0;

            if ($termId <= 0 || $parentId <= 0) {
                continue;
            }

            if (!$repository->exists_child_with_attachment($termId, $parentId)) {
                continue;
            }

            $attachmentId = get_term_meta($termId, 'thumbnail_id', true);
            update_term_meta($parentId, 'thumbnail_id', $attachmentId);
        }
    }

    public static function reset(): void
    {
        self::$run_calls = [];
    }
}
