<?php

declare(strict_types=1);

defined('ABSPATH') || exit;

/**
 * Handles future post image URL aggregation helpers.
 */
class Fifu_Post_Image_Urls {

    /**
     * Future: returns all image URLs for a post (primary and remote entries).
     */
    public static function get_all( int $post_id ): array {
        $image_urls     = [];
        $main_image_url = Fifu_Post_Main_Image_Resolver::get_main_image_url( $post_id, true );
        if ( $main_image_url ) {
            $image_urls[] = $main_image_url;
        }

        $i = 0;
        while ( true ) {
            $url = Fifu_Post_Image_List_Read_Service::get_image_url(
                (int) $post_id,
                (int) $i
            );
            if ( ! $url ) {
                break;
            }
            $image_urls[] = $url;
            $i++;
        }

        return $image_urls;
    }
}
