<?php declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Provides helpers for FIFU cron jobs, including semaphore checks.
 */
final class Fifu_Cron_Job_Service
{
    /**
     * Checks whether a job identified by a semaphore key is still active.
     *
     * @param string $semaphore
     * @param int    $minutes
     * @return bool
     */
    public static function is_active(string $semaphore, int $minutes): bool
    {
        $date = Fifu_Transient_Manager::get($semaphore);
        if (!$date) {
            return false;
        }

        if (!$date instanceof \DateTimeInterface) {
            Fifu_Transient_Manager::set($semaphore, new DateTime(), 0);
            return true;
        }

        $now = new \DateTimeImmutable();
        $startedAt = $date->getTimestamp();

        if ($startedAt > $now->getTimestamp()) {
            return true;
        }

        $windowSeconds = max(0, $minutes) * 60;
        if (($now->getTimestamp() - $startedAt) < $windowSeconds) {
            return true;
        }

        Fifu_Transient_Manager::delete($semaphore);
        return false;
    }

    /**
     * Runs the custom field job that creates FIFU images from arbitrary meta fields.
     *
     * This will use Fifu_Meta_Gap_Repository and Fifu_Developer_Media_Service.
     *
     * @return void
     */
    public static function run_customfield_job(): void
    {
        if (self::is_active('fifu_customfield_semaphore', 5)) {
            return;
        }

        $customFieldConfig = trim((string) get_option('fifu_customfield_custom_field'));
        if ($customFieldConfig === '') {
            return;
        }

        self::refresh_customfield_semaphore();

        try {
            $gapRepo = new Fifu_Meta_Gap_Repository();
            $results = $gapRepo->get_customfields_without_featured_image();
            $processed = [];
            $configItems = array_map('trim', explode(',', $customFieldConfig));

            foreach ($results as $result) {
                $id = (int) ($result->id ?? 0);
                if ($id <= 0) {
                    continue;
                }

                $isTerm = !empty($result->is_ctgr);
                $dedupeKey = ($isTerm ? 'term:' : 'post:') . $id;
                if (isset($processed[$dedupeKey])) {
                    continue;
                }

                $url = '';
                $metaValue = trim((string) ($result->meta_value ?? ''));
                $metaKey = (string) ($result->meta_key ?? '');

                foreach ($configItems as $item) {
                    if ($item === '') {
                        continue;
                    }

                    if (strpos($item, '{') !== false && strpos($item, '}') !== false) {
                        if (preg_match('/{(.+?)}/', $item, $matches)) {
                            $customFieldName = $matches[1] ?? '';
                            if ($customFieldName !== '' && $customFieldName === $metaKey) {
                                $url = str_replace('{' . $customFieldName . '}', $metaValue, $item);
                                break;
                            }
                        }
                        continue;
                    }

                    if ($item === $metaKey) {
                        $url = $metaValue;
                        break;
                    }
                }

                $url = trim((string) $url);
                if ($url === '' || !preg_match('#^https?://#i', $url)) {
                    continue;
                }

                self::refresh_customfield_semaphore();

                if ($isTerm) {
                    if (Fifu_Video_Helper::is_video($url)) {
                        Fifu_Developer_Media_Service::set_category_video($id, $url);
                    } else {
                        Fifu_Developer_Media_Service::set_category_image($id, $url);
                    }
                    $processed[$dedupeKey] = true;
                    continue;
                }

                if (Fifu_Video_Helper::is_video($url)) {
                    Fifu_Developer_Media_Service::set_video($id, $url);
                } else {
                    Fifu_Developer_Media_Service::set_image($id, $url, true);
                }
                $processed[$dedupeKey] = true;
            }
        } finally {
            Fifu_Transient_Manager::delete('fifu_customfield_semaphore');
        }
    }

    private static function refresh_customfield_semaphore(): void
    {
        Fifu_Transient_Manager::set('fifu_customfield_semaphore', new DateTime(), 0);
    }
}
