<?php
declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

/**
 * Product gallery helpers for FIFU Premium.
 */
class Fifu_Product_Gallery_Repository {

    /** @var array<string,bool> */
    private static array $tableExistsCache = [];

    private wpdb $wpdb;

    private string $postmeta_table;

    private string $fifu_map_table;

    private string $fifu_key_table;

    private string $fifu_url_table;

    private string $fifu_alt_table;

    private string $fifu_alt_map_table;

    public function __construct(?wpdb $wpdb = null) {
        $this->wpdb = $wpdb ?? $GLOBALS['wpdb'];
        $this->postmeta_table = $this->wpdb->postmeta;
        $prefix = $this->wpdb->prefix;
        $this->fifu_map_table = $prefix . 'fifu_map';
        $this->fifu_key_table = $prefix . 'fifu_key';
        $this->fifu_url_table = $prefix . 'fifu_url';
        $this->fifu_alt_table = $prefix . 'fifu_alt';
        $this->fifu_alt_map_table = $prefix . 'fifu_alt_map';
    }

    /**
     * Returns slider URLs (meta 'fifu_slider_image_url_%').
     *
     * Mirrors get_slider_urls() used by the grid/product gallery.
     *
     * @return array<object> Raw wpdb result objects.
     */
    public function get_slider_urls(int $post_id): array {
        if (!function_exists('fifu_db2_mode')) {
            return $this->get_slider_urls_legacy($post_id);
        }

        $db2Rows = $this->get_slider_urls_db2($post_id);
        if ($db2Rows !== null && $db2Rows !== []) {
            return $db2Rows;
        }

        return $this->get_slider_urls_legacy($post_id);
    }

    /**
     * Legacy SQL path for slider URLs.
     *
     * @param int $postId
     * @return array<object>
     */
    private function get_slider_urls_legacy(int $postId): array {
        $individual = $this->get_slider_urls_legacy_individual($postId);
        if ($individual !== []) {
            return $individual;
        }

        return $this->get_slider_urls_legacy_list_helper($postId);
    }

    /**
     * Legacy SQL path for individual slider URLs.
     *
     * @param int $postId
     * @return array<object>
     */
    private function get_slider_urls_legacy_individual(int $postId): array {
        $sql = $this->wpdb->prepare(
            "SELECT meta_value, meta_key
            FROM {$this->postmeta_table} a
            WHERE a.post_id = %d
            AND a.meta_key LIKE 'fifu_slider_image_url_%'
            ORDER BY meta_key",
            (int) $postId
        );
        $rows = $this->wpdb->get_results($sql);
        if (!is_array($rows)) {
            return [];
        }

        $filtered = [];
        foreach ($rows as $row) {
            if (!is_object($row)) {
                continue;
            }

            if (trim((string) ($row->meta_value ?? '')) === '') {
                continue;
            }

            $filtered[] = $row;
        }

        return $filtered;
    }

    /**
     * Legacy fallback for fifu_slider_list_url.
     *
     * @param int $postId
     * @return array<object>
     */
    private function get_slider_urls_legacy_list_helper(int $postId): array {
        $sql = $this->wpdb->prepare(
            "SELECT meta_value
            FROM {$this->postmeta_table}
            WHERE post_id = %d
              AND meta_key = 'fifu_slider_list_url'
            LIMIT 1",
            (int) $postId
        );

        $raw = $this->wpdb->get_var($sql);
        if ($raw === null || $raw === false) {
            return [];
        }

        $parts = explode('|', (string) $raw);
        $rows = [];
        $index = 0;

        foreach ($parts as $part) {
            $url = trim((string) $part);
            if ($url === '') {
                continue;
            }

            $rows[] = (object) [
                'meta_key' => 'fifu_slider_list_url',
                'meta_value' => $url,
                'index' => $index,
            ];
            $index++;
        }

        return $rows;
    }

    /**
     * DB2 SQL path for slider URLs.
     *
     * @param int $postId
     * @return array<object>|null
     */
    private function get_slider_urls_db2(int $postId): ?array {
        if (!$this->is_db2_ready()) {
            return null;
        }

        $map = $this->fifu_map_table;
        $key = $this->fifu_key_table;
        $url = $this->fifu_url_table;

        $sql = "
            SELECT
                k.key_type AS key_type,
                m.key_index AS key_index,
                u.url AS url
            FROM {$map} m
            INNER JOIN {$key} k ON k.key_id = m.key_id
            INNER JOIN {$url} u ON u.hash = m.hash
            WHERE m.post_id = %d
              AND k.key_type = 'slider'
              AND m.key_index IS NOT NULL
            ORDER BY m.key_index
        ";

        $sql = $this->wpdb->prepare($sql, (int) $postId);

        $results = $this->wpdb->get_results($sql);
        if ($results === false) {
            return null;
        }

        return $this->normalize_db2_media_rows($results, 'slider');
    }

    /**
     * Returns gallery URLs from external fields (fifu_image_url_*, fifu_video_url_*, slider > 0).
     *
     * Mirrors get_gallery_urls().
     *
     * @return array<object>
     */
    public function get_gallery_urls(int $post_id): array {
        if (!function_exists('fifu_db2_mode')) {
            return $this->get_gallery_urls_legacy($post_id);
        }

        $db2Rows = $this->get_gallery_urls_db2($post_id);
        if ($db2Rows !== null && $db2Rows !== []) {
            return $db2Rows;
        }

        return $this->get_gallery_urls_legacy($post_id);
    }

    /**
     * Legacy SQL path for gallery URLs.
     *
     * @param int $post_id
     * @return array
     */
    private function get_gallery_urls_legacy(int $post_id): array {
        $sql = $this->wpdb->prepare(
            "SELECT meta_value, meta_key
            FROM {$this->postmeta_table} a
            WHERE a.post_id = %d
            AND (
                a.meta_key LIKE 'fifu_image_url_%'
                OR a.meta_key LIKE 'fifu_video_url_%'
                OR a.meta_key IN ('fifu_list_url', 'fifu_list_video_url', 'fifu_slider_list_url')
                OR (
                    a.meta_key LIKE 'fifu_slider_image_url_%'
                    AND a.meta_key <> 'fifu_slider_image_url_0'
                )
            )
            AND a.meta_value <> ''
            ORDER BY meta_key",
            $post_id
        );
        $rows = $this->wpdb->get_results($sql);
        if (!is_array($rows)) {
            return [];
        }

        $expanded = [];
        foreach ($rows as $row) {
            if (!is_object($row)) {
                continue;
            }

            $metaKey = (string) ($row->meta_key ?? '');
            $metaValue = (string) ($row->meta_value ?? '');
            if (in_array($metaKey, ['fifu_list_url', 'fifu_list_video_url', 'fifu_slider_list_url'], true)) {
                $index = 0;
                foreach (explode('|', $metaValue) as $part) {
                    $url = trim((string) $part);
                    if ($url === '') {
                        continue;
                    }

                    $expanded[] = (object) [
                        'meta_key' => $metaKey === 'fifu_slider_list_url'
                            ? 'fifu_slider_image_url_' . $index
                            : ($metaKey === 'fifu_list_video_url' ? 'fifu_video_url_' . $index : 'fifu_image_url_' . $index),
                        'meta_value' => $url,
                        'url' => $url,
                        'type' => $metaKey === 'fifu_list_video_url' ? 'video' : 'image',
                        'scope' => $metaKey === 'fifu_list_video_url' ? 'video' : 'image',
                        'index' => $index,
                    ];
                    $index++;
                }
                continue;
            }

            $expanded[] = $row;
        }

        return $expanded;
    }

    /**
     * DB2 SQL path for gallery URLs.
     *
     * @param int $post_id
     * @return array|null
     */
    private function get_gallery_urls_db2(int $post_id): ?array {
        if (!$this->is_db2_ready()) {
            return null;
        }

        $map = $this->fifu_map_table;
        $key = $this->fifu_key_table;
        $url = $this->fifu_url_table;
        $sql = $this->wpdb->prepare(
            "
            SELECT
                k.key_type AS key_type,
                m.key_index AS key_index,
                u.url AS url
            FROM {$map} m
            INNER JOIN {$key} k ON k.key_id = m.key_id
            INNER JOIN {$url} u ON u.hash = m.hash
            WHERE m.post_id = %d
              AND k.key_type IN ('image','video','slider')
              AND m.key_index IS NOT NULL
              AND u.url <> ''
            ORDER BY FIELD(k.key_type, 'image', 'video', 'slider'), m.key_index
            ",
            $post_id
        );

        $results = $this->wpdb->get_results($sql);
        if ($results === false) {
            return null;
        }

        return $this->normalize_db2_media_rows($results, null, $this->get_featured_media_matcher($post_id));
    }

    /**
     * Returns only the FIFU image gallery URLs (meta_key LIKE 'fifu_image_url_%') for a post.
     *
     * @param int $post_id
     * @return array
     */
    public function get_image_gallery_urls(int $post_id): array {
        $post_id = (int) $post_id;

        if (!function_exists('fifu_db2_mode')) {
            return $this->get_image_gallery_urls_legacy($post_id);
        }

        $db2 = $this->get_image_gallery_urls_db2($post_id);
        if ($db2 !== null && $db2 !== []) {
            return $db2;
        }

        return $this->get_image_gallery_urls_legacy($post_id);
    }

    /**
     * Legacy SQL path for FIFU image gallery URLs.
     *
     * @param int $post_id
     * @return array
     */
    private function get_image_gallery_urls_legacy(int $post_id): array {
        $postmeta = $this->postmeta_table;

        $sql = $this->wpdb->prepare(
            "SELECT meta_key, meta_value
            FROM {$postmeta}
            WHERE post_id = %d
              AND meta_key LIKE 'fifu_image_url_%'
            ORDER BY meta_key",
            $post_id
        );

        return $this->wpdb->get_results($sql);
    }

    /**
     * DB2 SQL path for FIFU image gallery URLs.
     *
     * @param int $post_id
     * @return array|null
     */
    private function get_image_gallery_urls_db2(int $post_id): ?array {
        if (!$this->has_featured_image_db2_tables()) {
            return null;
        }

        $mapTable = $this->fifu_map_table;
        $keyTable = $this->fifu_key_table;
        $urlTable = $this->fifu_url_table;

        $sql = $this->wpdb->prepare(
            "SELECT
                k.key_type AS key_type,
                m.key_index AS key_index,
                u.url AS url
            FROM {$mapTable} m
            INNER JOIN {$keyTable} k ON k.key_id = m.key_id
            INNER JOIN {$urlTable} u ON u.hash = m.hash
            WHERE m.post_id = %d
              AND k.key_type = 'image'
              AND m.key_index > 0
              AND u.url <> ''
            ORDER BY m.key_index",
            $post_id
        );

        $results = $this->wpdb->get_results($sql);
        if ($results === false) {
            return null;
        }

        return $this->normalize_db2_media_rows($results, 'image');
    }

    /**
     * Filters DB2 rows so gallery output excludes only the currently featured main item.
     *
     * @param int $post_id
     * @param array<int,object> $rows
     * @return array<int,object>
     */
    private function normalize_db2_media_rows(array $rows, ?string $scope, ?callable $featured_matcher = null): array {
        $filtered = [];

        foreach ($rows as $row) {
            if (!is_object($row)) {
                continue;
            }

            $type = isset($row->key_type) ? trim((string) $row->key_type) : '';
            $index = isset($row->key_index) ? (int) $row->key_index : null;

            if ($type === '') {
                continue;
            }

            if ($scope !== null && $type !== $scope) {
                continue;
            }

            if ($index < 0) {
                continue;
            }

            $url = trim((string) ($row->url ?? ''));
            if ($url === '') {
                continue;
            }

            if ($featured_matcher !== null && $featured_matcher($row, $url)) {
                continue;
            }

            $record = [
                'scope' => $type,
                'type' => $type,
                'index' => $index,
                'url' => $url,
            ];

            if (isset($row->alt)) {
                $alt = trim((string) $row->alt);
                if ($alt !== '') {
                    $record['alt'] = $alt;
                }
            }

            $filtered[] = (object) $record;
        }

        usort($filtered, static function (object $a, object $b): int {
            $priority = static function (string $type): int {
                return match ($type) {
                    'image' => 0,
                    'video' => 1,
                    'slider' => 2,
                    default => 3,
                };
            };

            $aType = (string) ($a->type ?? $a->scope ?? '');
            $bType = (string) ($b->type ?? $b->scope ?? '');
            $typeCmp = $priority($aType) <=> $priority($bType);
            if ($typeCmp !== 0) {
                return $typeCmp;
            }

            return ((int) ($a->index ?? 0)) <=> ((int) ($b->index ?? 0));
        });
        return $filtered;
    }

    /**
     * Builds a matcher that excludes only the DB2 row corresponding to the current featured attachment.
     *
     * @param int $post_id
     * @return callable(object,string):bool
     */
    private function get_featured_media_matcher(int $post_id): callable {
        $featured_attachment_url = $this->get_featured_attachment_url($post_id);
        $featured_attachment_id = $this->get_featured_attachment_id($post_id);

        return static function (object $row, string $url) use ($featured_attachment_url, $featured_attachment_id): bool {
            $type = isset($row->key_type) ? trim((string) $row->key_type) : '';
            if ($type === '') {
                return false;
            }

            if ($featured_attachment_url !== null && $url === $featured_attachment_url) {
                return true;
            }

            if ($type === 'video' && $featured_attachment_url !== null && class_exists('Fifu_Video_Helper', false)) {
                $video_thumb = (string) (Fifu_Video_Helper::get_thumbnail_large($url) ?? '');
                if ($video_thumb !== '' && $video_thumb === $featured_attachment_url) {
                    return true;
                }
            }

            if ($type === 'slider' && $featured_attachment_id > 0 && $url === $featured_attachment_url) {
                return true;
            }

            return false;
        };
    }

    private function get_featured_attachment_url(int $post_id): ?string {
        $thumbnail_id = $this->get_featured_attachment_id($post_id);
        if ($thumbnail_id <= 0) {
            return null;
        }

        $attachment_url = trim((string) get_post_meta($thumbnail_id, '_wp_attached_file', true));
        if ($attachment_url === '') {
            $attachment_url = trim((string) get_post_field('post_content_filtered', $thumbnail_id));
        }

        $attachment_url = htmlspecialchars_decode($attachment_url);
        return $attachment_url === '' ? null : $attachment_url;
    }

    private function get_featured_attachment_id(int $post_id): int {
        if (!function_exists('get_post_thumbnail_id')) {
            return 0;
        }

        return (int) get_post_thumbnail_id($post_id);
    }

    /**
     * Checks whether the DB2 tables necessary for gallery queries are present.
     *
     * @return bool
     */
    private function is_db2_ready(): bool {
        return $this->table_exists($this->fifu_map_table)
            && $this->table_exists($this->fifu_key_table)
            && $this->table_exists($this->fifu_url_table);
    }

    /**
     * Checks whether the DB2 tables necessary for gallery ALT queries are present.
     *
     * @return bool
     */
    private function is_db2_alt_ready(): bool {
        return $this->table_exists($this->fifu_map_table)
            && $this->table_exists($this->fifu_key_table)
            && $this->table_exists($this->fifu_alt_map_table)
            && $this->table_exists($this->fifu_alt_table);
    }

    /**
     * Checks whether the DB2 tables necessary for featured image queries are present.
     *
     * @return bool
     */
    private function has_featured_image_db2_tables(): bool {
        return $this->is_db2_ready();
    }

    /**
     * Returns whether the given table exists in the database.
     *
     * @param string $table
     * @return bool
     */
    private function table_exists(string $table): bool {
        $cacheKey = spl_object_id($this->wpdb) . '|' . $table;
        if (isset(self::$tableExistsCache[$cacheKey])) {
            return true;
        }

        $sql = $this->wpdb->prepare("SHOW TABLES LIKE %s", $table);
        $result = $this->wpdb->get_var($sql);
        $exists = $result !== null;

        if ($exists) {
            self::$tableExistsCache[$cacheKey] = true;
        }

        return $exists;
    }

    public static function clearRequestCacheForTests(): void
    {
        self::$tableExistsCache = [];
    }

    /**
     * Returns ALT texts for the external gallery (fifu_image_alt_* fields).
     *
     * Mirrors get_gallery_alts().
     *
     * @return array<object>
     */
    public function get_gallery_alts(int $post_id): array {
        if (!function_exists('fifu_db2_mode')) {
            return $this->get_gallery_alts_legacy($post_id);
        }

        $db2Rows = $this->get_gallery_alts_db2($post_id);
        if ($db2Rows !== null && $db2Rows !== []) {
            return $db2Rows;
        }

        return $this->get_gallery_alts_legacy($post_id);
    }

    /**
     * Legacy SQL path for gallery ALT texts.
     *
     * @param int $postId
     * @return array<object>
     */
    private function get_gallery_alts_legacy(int $postId): array {
        $sql = $this->wpdb->prepare(
            "SELECT meta_value, meta_key
            FROM {$this->postmeta_table} a
            WHERE a.post_id = %d
            AND (
                a.meta_key LIKE 'fifu_image_alt_%'
                OR (
                    a.meta_key LIKE 'fifu_slider_image_alt_%'
                    AND a.meta_key <> 'fifu_slider_image_alt_0'
                )
            )
            AND a.meta_value <> ''
            ORDER BY meta_key",
            (int) $postId
        );
        return $this->wpdb->get_results($sql);
    }

    /**
     * DB2 SQL path for gallery ALT texts.
     *
     * @param int $postId
     * @return array<object>|null
     */
    private function get_gallery_alts_db2(int $postId): ?array {
        if (!$this->is_db2_alt_ready()) {
            return null;
        }

        $altMap = $this->fifu_alt_map_table;
        $alt = $this->fifu_alt_table;
        $key = $this->fifu_key_table;

        $sql = "
            SELECT
                k.key_type AS key_type,
                a_map.key_index AS key_index,
                alt.alt AS alt
            FROM {$altMap} a_map
            INNER JOIN {$key} k ON k.key_id = a_map.key_id
            INNER JOIN {$alt} alt ON alt.hash = a_map.hash
            WHERE a_map.post_id = %d
              AND k.key_type IN ('image','slider')
              AND a_map.key_index IS NOT NULL
              AND a_map.key_index > 0
              AND alt.alt <> ''
            ORDER BY FIELD(k.key_type, 'image', 'slider'), a_map.key_index
        ";

        $sql = $this->wpdb->prepare(
            $sql,
            (int) $postId
        );

        $results = $this->wpdb->get_results($sql);
        if ($results === false) {
            return null;
        }

        $filtered = [];
        foreach ($results as $row) {
            if (!is_object($row)) {
                continue;
            }

            $type = trim((string) ($row->key_type ?? ''));
            $index = isset($row->key_index) ? (int) $row->key_index : -1;
            $altText = trim((string) ($row->alt ?? ''));
            if ($type === '' || $index < 0 || $altText === '') {
                continue;
            }

            $filtered[] = (object) [
                'scope' => $type,
                'type' => $type,
                'index' => $index,
                'alt' => $altText,
            ];
        }

        return $filtered;
    }

    /**
     * Get all FIFU image URLs (featured + gallery) for a post as a concatenated string.
     *
     * @param int $post_id
     * @return string|null
     */
    public function get_featured_and_gallery_urls_concat(int $post_id): ?string {
        $rows = $this->get_featured_and_gallery_urls($post_id);
        if ($rows === []) {
            return null;
        }

        $row = reset($rows);
        if (!is_object($row)) {
            return null;
        }

        return $row->urls ?? null;
    }

    /**
     * Get all FIFU image URLs (featured + gallery) for a post.
     *
     * @param int $post_id
     * @return array
     */
    public function get_featured_and_gallery_urls(int $post_id): array {
        $post_id = (int) $post_id;
        $this->wpdb->query("SET SESSION group_concat_max_len = 1048576;");

        if (!function_exists('fifu_db2_mode')) {
            return $this->get_featured_and_gallery_urls_legacy($post_id);
        }

        $db2 = $this->get_featured_and_gallery_urls_db2($post_id);
        if ($db2 !== null && $db2 !== [] && isset($db2[0]->urls) && trim((string) $db2[0]->urls) !== '') {
            return $db2;
        }

        return $this->get_featured_and_gallery_urls_legacy($post_id);
    }

    /**
     * Legacy SQL path for featured / gallery url concatenation.
     *
     * @param int $post_id
     * @return array
     */
    private function get_featured_and_gallery_urls_legacy(int $post_id): array {
        $postmeta = $this->postmeta_table;

        $sql = $this->wpdb->prepare(
            "SELECT GROUP_CONCAT(meta_value SEPARATOR '|') AS urls
            FROM {$postmeta}
            WHERE post_id = %d
              AND meta_key LIKE 'fifu_image_url%%'
            ORDER BY meta_key",
            $post_id
        );

        $results = $this->wpdb->get_results($sql);
        if ($results === false) {
            return [];
        }

        return $results;
    }

    /**
     * DB2 SQL path for featured / gallery url concatenation.
     *
     * @param int $post_id
     * @return array|null
     */
    private function get_featured_and_gallery_urls_db2(int $post_id): ?array {
        if (!$this->has_featured_image_db2_tables()) {
            return null;
        }

        $mapTable = $this->fifu_map_table;
        $keyTable = $this->fifu_key_table;
        $urlTable = $this->fifu_url_table;

        $sql = $this->wpdb->prepare(
            "SELECT GROUP_CONCAT(u.url ORDER BY m.key_index SEPARATOR '|') AS urls
            FROM {$mapTable} m
            INNER JOIN {$keyTable} k ON k.key_id = m.key_id
            INNER JOIN {$urlTable} u ON u.hash = m.hash
            WHERE m.post_id = %d
              AND k.key_type = 'image'",
            $post_id
        );

        $results = $this->wpdb->get_results($sql);
        if ($results === false) {
            return null;
        }

        return $results;
    }

    /**
     * Delete all FIFU image URLs (featured + gallery) for a post.
     *
     * @param int $post_id
     * @return int Number of deleted rows from legacy storage.
     */
    public function delete_featured_and_gallery_urls(int $post_id): int {
        $post_id = (int) $post_id;

        if ( ! function_exists( 'fifu_db2_mode' ) ) {
            return $this->delete_featured_and_gallery_urls_legacy( $post_id );
        }

        $mode = fifu_db2_mode();

        if ( $mode === Fifu_Db2_Mode::MODE_DB2 || $mode === Fifu_Db2_Mode::MODE_HYBRID ) {
            $result = $this->delete_featured_and_gallery_urls_db2( $post_id );
            if ( $result !== null ) {
                return $result;
            }

            if ( $mode === Fifu_Db2_Mode::MODE_DB2 ) {
                return $this->delete_featured_and_gallery_urls_legacy( $post_id );
            }
        }

        return $this->delete_featured_and_gallery_urls_legacy( $post_id );
    }

    /**
     * Legacy delete path (raw postmeta).
     *
     * @param int $post_id
     * @return int
     */
    private function delete_featured_and_gallery_urls_legacy(int $post_id): int {
        $postmeta = $this->postmeta_table;

        if (function_exists('fifu_db2_mode')) {
            $mode = fifu_db2_mode();
            if ($mode !== Fifu_Db2_Mode::MODE_LEGACY) {
                return 0;
            }
        }

        $sql = $this->wpdb->prepare(
            "DELETE FROM {$postmeta}
            WHERE post_id = %d
              AND meta_key LIKE 'fifu_image_url%'",
            $post_id
        );

        $result = $this->wpdb->query( $sql );
        if ( $result === false ) {
            return 0;
        }

        if ( function_exists( 'fifu_db2_write_service' ) ) {
            $write_service = fifu_db2_write_service();
            if ( $write_service instanceof Fifu_Db2_Write_Service ) {
                $write_service->delete_post_image( $post_id );
                $write_service->delete_post_image_alt( $post_id );
            }
        }

        return (int) $result;
    }

    /**
     * DB2 delete path for FIFU image metadata.
     *
     * @param int $post_id
     * @return int|null Legacy rows deleted (or null when DB2 tables are unavailable).
     */
    private function delete_featured_and_gallery_urls_db2(int $post_id): ?int {
        if ( ! $this->has_featured_image_db2_tables() ) {
            return null;
        }

        $mapTable = $this->fifu_map_table;
        $keyTable = $this->fifu_key_table;

        $sql = $this->wpdb->prepare(
            "DELETE m
            FROM {$mapTable} m
            INNER JOIN {$keyTable} k ON k.key_id = m.key_id
            WHERE m.post_id = %d
              AND k.key_type = 'image'",
            $post_id
        );

        $mapDeleted = $this->wpdb->query( $sql );
        if ( $mapDeleted === false ) {
            return null;
        }

        return $this->delete_featured_and_gallery_urls_legacy( $post_id );
    }
}
