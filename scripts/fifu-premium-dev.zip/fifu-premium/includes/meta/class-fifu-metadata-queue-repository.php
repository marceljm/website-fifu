<?php

declare(strict_types=1);

defined('ABSPATH') || exit;

/**
 * Repository for FIFU metadata queue tables (meta in/out, content, import).
 */
class Fifu_Metadata_Queue_Repository {

    /** @var wpdb */
    private wpdb $wpdb;

    /** @var string */
    private string $table_meta_in;

    /** @var string */
    private string $table_meta_out;

    /** @var string */
    private string $table_content;

    /** @var string */
    private string $table_import;

    /** @var string */
    private string $table_sent;

    /** @var string */
    private string $table_sent_event;

    /**
     * Constructor.
     *
     * @param wpdb|null $wpdb_instance Optional database abstraction.
     */
    public function __construct(?wpdb $wpdb_instance = null) {
        $this->wpdb = $wpdb_instance ?? $GLOBALS['wpdb'];
        $this->table_meta_in = $this->wpdb->prefix . 'fifu_meta_in';
        $this->table_meta_out = $this->wpdb->prefix . 'fifu_meta_out';
        $this->table_content = $this->wpdb->prefix . 'fifu_content';
        $this->table_import = $this->wpdb->prefix . 'fifu_import';
        $this->table_sent = $this->wpdb->prefix . 'fifu_sent';
        $this->table_sent_event = $this->wpdb->prefix . 'fifu_sent_event';
    }

    /**
     * Retrieve the pending content rows.
     *
     * @return array
     */
    public function get_content(): array {
        $sql = "SELECT id AS post_id FROM {$this->table_content}";
        return $this->wpdb->get_results($sql);
    }

    /**
     * Retrieve the pending meta_in rows.
     *
     * @return array
     */
    public function get_meta_in(): array {
        $sql = "SELECT id AS post_id FROM {$this->table_meta_in}";
        return $this->wpdb->get_results($sql);
    }

    /**
     * Retrieve the pending meta_out rows.
     *
     * @return array
     */
    public function get_meta_out(): array {
        $sql = "SELECT id AS post_id FROM {$this->table_meta_out}";
        return $this->wpdb->get_results($sql);
    }

    /**
     * Return the last inserted meta_in ID for a specific type.
     *
     * @param string $type
     * @return int|null
     */
    public function get_last_meta_in_id(string $type): ?int {
        $sql = $this->wpdb->prepare(
            "SELECT id FROM {$this->table_meta_in} WHERE type = %s ORDER BY id DESC LIMIT 1",
            $type
        );
        $value = $this->wpdb->get_var($sql);
        return $value !== null ? (int) $value : null;
    }

    /**
     * Return the last inserted meta_out ID for a specific type.
     *
     * @param string $type
     * @return int|null
     */
    public function get_last_meta_out_id(string $type): ?int {
        $sql = $this->wpdb->prepare(
            "SELECT id FROM {$this->table_meta_out} WHERE type = %s ORDER BY id DESC LIMIT 1",
            $type
        );
        $value = $this->wpdb->get_var($sql);
        return $value !== null ? (int) $value : null;
    }

    /**
     * Get the metadata type recorded for a meta_in entry.
     *
     * @param int $id
     * @return string|null
     */
    public function get_meta_in_type(int $id): ?string {
        $sql = $this->wpdb->prepare(
            "SELECT type FROM {$this->table_meta_in} WHERE id = %d",
            $id
        );
        return $this->wpdb->get_var($sql);
    }

    /**
     * Get the metadata type recorded for a meta_out entry.
     *
     * @param int $id
     * @return string|null
     */
    public function get_meta_out_type(int $id): ?string {
        $sql = $this->wpdb->prepare(
            "SELECT type FROM {$this->table_meta_out} WHERE id = %d",
            $id
        );
        return $this->wpdb->get_var($sql);
    }

    /**
     * Log information about a recently inserted queue record.
     *
     * @param int    $last_insert_id
     * @param string $table
     */
    public function log_prepare(int $last_insert_id, string $table): void {
        $inserted_records = $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT id, post_ids, type FROM {$table} WHERE id = %d",
                $last_insert_id
            )
        );

        foreach ($inserted_records as $record) {
            Fifu_File_Logger::plugin([$table => [
                'id' => $record->id,
                'post_ids' => $record->post_ids,
                'type' => $record->type
            ]]);
        }
    }

    /**
     * Return the posts scheduled for import.
     *
     * @return array
     */
    public function get_all_posts_to_import(): array {
        $mode = function_exists('fifu_db2_mode')
            ? fifu_db2_mode()
            : Fifu_Db2_Mode::MODE_LEGACY;

        if ($mode === Fifu_Db2_Mode::MODE_DB2 || $mode === Fifu_Db2_Mode::MODE_HYBRID) {
            $sql = "
                SELECT DISTINCT i.post_id
                FROM {$this->table_import} i
                LEFT JOIN {$this->table_sent_event} e
                  ON e.event_key = 'importpost'
                LEFT JOIN {$this->table_sent} s
                  ON s.object_type = 'post'
                 AND s.object_id = i.post_id
                 AND s.event_id = e.id
                WHERE i.category = 0
                  AND (s.id IS NULL OR s.sent = 0)
            ";
            return $this->wpdb->get_results($sql);
        }

        $sent_clause = $this->get_db2_sent_not_exists_clause('post', 'importpost', 'i.post_id');

        $sql = "
            SELECT DISTINCT post_id
            FROM {$this->table_import} i
            WHERE category = 0
              AND NOT EXISTS (
                  SELECT 1
                  FROM {$this->wpdb->postmeta} pm
                  WHERE pm.post_id = i.post_id
                    AND pm.meta_key = 'fifu_importpost_sent'
              )
        " . $sent_clause;
        return $this->wpdb->get_results($sql);
    }

    /**
     * Return the terms scheduled for import.
     *
     * @return array
     */
    public function get_all_terms_to_import(): array {
        $mode = function_exists('fifu_db2_mode')
            ? fifu_db2_mode()
            : Fifu_Db2_Mode::MODE_LEGACY;

        if ($mode === Fifu_Db2_Mode::MODE_DB2 || $mode === Fifu_Db2_Mode::MODE_HYBRID) {
            $sql = "
                SELECT DISTINCT i.post_id
                FROM {$this->table_import} i
                LEFT JOIN {$this->table_sent_event} e
                  ON e.event_key = 'importterm'
                LEFT JOIN {$this->table_sent} s
                  ON s.object_type = 'term'
                 AND s.object_id = i.post_id
                 AND s.event_id = e.id
                WHERE i.category = 1
                  AND (s.id IS NULL OR s.sent = 0)
            ";
            return $this->wpdb->get_results($sql);
        }

        $sent_clause = $this->get_db2_sent_not_exists_clause('term', 'importterm', 'i.post_id');

        $sql = "
            SELECT DISTINCT post_id
            FROM {$this->table_import} i
            WHERE category = 1
              AND NOT EXISTS (
                  SELECT 1
                  FROM {$this->wpdb->termmeta} tm
                  WHERE tm.term_id = i.post_id
                    AND tm.meta_key = 'fifu_importterm_sent'
              )
        " . $sent_clause;
        return $this->wpdb->get_results($sql);
    }

    private function get_db2_sent_not_exists_clause(string $object_type, string $event_key, string $object_column): string {
        if (!$this->table_exists($this->table_sent) || !$this->table_exists($this->table_sent_event)) {
            return '';
        }

        return "
            AND NOT EXISTS (
                SELECT 1
                FROM {$this->table_sent} s
                INNER JOIN {$this->table_sent_event} e ON e.id = s.event_id
                WHERE s.object_type = '{$object_type}'
                  AND s.object_id = {$object_column}
                  AND e.event_key = '{$event_key}'
                  AND s.sent = 1
            )
        ";
    }

    private function table_exists(string $table): bool {
        $sql = $this->wpdb->prepare("SHOW TABLES LIKE %s", $table);
        $result = $this->wpdb->get_var($sql);
        return $result !== null && $result !== false;
    }
}
