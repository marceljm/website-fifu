<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Provides read access to indexed image URL metadata.
 */
final class Fifu_Post_Image_List_Read_Service
{
    /**
     * Returns the N-th image URL for a post, using db2 first and falling back to postmeta.
     *
     * @param int $postId
     * @param int $index
     * @return string|null
     */
    public static function get_image_url(int $postId, int $index): ?string
    {
        if ($index < 0) {
            return null;
        }

        if (function_exists('fifu_db2_manager')) {
            $manager = fifu_db2_manager();
            if ($manager instanceof Fifu_Db2_Manager) {
                $mapping = $manager->getPostMapping($postId, 'image', $index);
                if (is_array($mapping) && !empty($mapping['url'])) {
                    return (string) $mapping['url'];
                }
            }
        }

        $metaKey = 'fifu_image_url_' . $index;
        $legacyUrl = get_post_meta($postId, $metaKey, true);
        if ($legacyUrl === '' || $legacyUrl === null) {
            return null;
        }

        return (string) $legacyUrl;
    }
}
