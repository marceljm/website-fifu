<?php

/**
 * Duplicates canonical FIFU product gallery state independently
 * from featured-media state.
 */
class Fifu_Product_Gallery_Duplication_Service
{
    public static function duplicate(int $source_post_id, int $duplicate_post_id): bool
    {
        if ($source_post_id <= 0 || $duplicate_post_id <= 0 || $source_post_id === $duplicate_post_id || !function_exists('fifu_db2_manager')) {
            return false;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getPostMappings') || !method_exists($manager, 'getPostAltMappings') || !method_exists($manager, 'deletePostMappings') || !method_exists($manager, 'deletePostAltMappings') || !method_exists($manager, 'savePostUrl') || !method_exists($manager, 'savePostAlt')) {
            return false;
        }

        $images = self::urls($manager->getPostMappings($source_post_id, 'image'));
        $videos = self::urls($manager->getPostMappings($source_post_id, 'video'));
        $alts = self::alts($manager->getPostAltMappings($source_post_id, 'image'));

        self::clear_urls($manager, $duplicate_post_id, 'image');
        self::clear_urls($manager, $duplicate_post_id, 'video');
        self::clear_alts($manager, $duplicate_post_id);

        if (!self::write_urls($manager, $duplicate_post_id, 'image', $images) || !self::write_alts($manager, $duplicate_post_id, $alts) || !self::write_urls($manager, $duplicate_post_id, 'video', $videos)) {
            return false;
        }

        if (method_exists($manager, 'clearKeyCache')) {
            $manager->clearKeyCache();
        }

        Fifu_Post_Attachment_Sync_Service::sync_gallery_attachments($duplicate_post_id, true);
        return true;
    }

    private static function urls($rows): array
    {
        $result = [];
        foreach (is_iterable($rows) ? $rows : [] as $row) {
            if (!is_array($row)) { continue; }
            $index = (int) ($row['key_index'] ?? -1);
            $url = trim((string) ($row['url'] ?? ''));
            if ($index <= 0 || $url === '') { continue; }
            $result[] = ['index' => $index, 'url' => $url, 'width' => $row['width'] === null ? null : (int) ($row['width'] ?? 0), 'height' => $row['height'] === null ? null : (int) ($row['height'] ?? 0)];
        }
        return $result;
    }

    private static function alts($rows): array
    {
        $result = [];
        foreach (is_iterable($rows) ? $rows : [] as $row) {
            if (!is_array($row)) { continue; }
            $index = (int) ($row['key_index'] ?? -1);
            $alt = trim((string) ($row['alt'] ?? ''));
            if ($index > 0 && $alt !== '') { $result[] = ['index' => $index, 'alt' => $alt]; }
        }
        return $result;
    }

    private static function clear_urls(Fifu_Db2_Manager $manager, int $post_id, string $type): void
    {
        foreach ($manager->getPostMappings($post_id, $type) as $row) {
            $index = (int) ($row['key_index'] ?? -1);
            if ($index > 0) { $manager->deletePostMappings($post_id, $type, $index); }
        }
    }

    private static function clear_alts(Fifu_Db2_Manager $manager, int $post_id): void
    {
        foreach ($manager->getPostAltMappings($post_id, 'image') as $row) {
            $index = (int) ($row['key_index'] ?? -1);
            if ($index > 0) { $manager->deletePostAltMappings($post_id, 'image', $index); }
        }
    }

    private static function write_urls(Fifu_Db2_Manager $manager, int $post_id, string $type, array $rows): bool
    {
        foreach ($rows as $row) {
            if (!$manager->savePostUrl($post_id, $type, $row['index'], $row['url'], $row['width'], $row['height'])) { return false; }
        }
        return true;
    }

    private static function write_alts(Fifu_Db2_Manager $manager, int $post_id, array $rows): bool
    {
        foreach ($rows as $row) {
            if (!$manager->savePostAlt($post_id, 'image', $row['index'], $row['alt'])) { return false; }
        }
        return true;
    }
}
