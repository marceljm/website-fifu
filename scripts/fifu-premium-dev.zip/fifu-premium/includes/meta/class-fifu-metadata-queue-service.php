<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

final class Fifu_Metadata_Queue_Service {

    /**
     * Prepares batched content entries in the FIFU content table
     * based on posts that need automatic metadata processing.
     *
     * This method groups posts into chunks (e.g. 100 per row)
     * and logs the preparation in the metadata queue repository.
     *
     * @return void
     */
    public static function prepare_content_queue(): void {
        global $wpdb;

        $posts_table = $wpdb->posts;
        $postmeta_table = $wpdb->postmeta;
        $fifu_content_table = $wpdb->prefix . 'fifu_content';
        $types_clause = self::get_content_post_types_for_in_clause();

        $wpdb->query("SET SESSION group_concat_max_len = 1048576;");

        $wpdb->query("CREATE TEMPORARY TABLE temp_post_content (
            id INT AUTO_INCREMENT PRIMARY KEY,
            post_id INT
        );");

        $map_table = $wpdb->prefix . 'fifu_map';
        $key_table = $wpdb->prefix . 'fifu_key';
        $db2_media_clause = '';
        $overwrite = Fifu_Options_Utils::is_on('fifu_ovw_first');
        if (
            !$overwrite
            && function_exists('fifu_db2_mode')
            && self::table_exists($wpdb, $map_table)
            && self::table_exists($wpdb, $key_table)
        ) {
            $db2_media_clause = "
                AND NOT EXISTS (
                    SELECT 1
                    FROM {$map_table} m
                    INNER JOIN {$key_table} k ON k.key_id = m.key_id
                    WHERE m.post_id = p.ID
                      AND k.key_type IN ('image','video')
                      AND m.key_index = 0
                )
            ";
        }

        if (Fifu_Options_Utils::is_on('fifu_ovw_first')) {
            $author_id = (int) Fifu_Options_Utils::get_author();
            $sql = "
                INSERT INTO temp_post_content (post_id)
                SELECT DISTINCT p.ID AS post_id
                FROM {$posts_table} p
                WHERE p.post_type IN ('{$types_clause}')
                AND post_status NOT IN ('auto-draft', 'trash')
                AND NOT EXISTS (
                    SELECT 1 
                    FROM {$postmeta_table} pm 
                    WHERE p.id = pm.post_id 
                    AND pm.meta_key = '_thumbnail_id'
                    AND pm.meta_value IN (
                        SELECT p2.id
                        FROM {$posts_table} p2
                        WHERE p2.post_author <> %d
                    )
                )
                {$db2_media_clause}
                ORDER BY p.ID
            ";
            $wpdb->query($wpdb->prepare($sql, $author_id));
        } else {
            $wpdb->query("INSERT INTO temp_post_content (post_id)
                SELECT p.ID AS post_id
                FROM {$posts_table} p
                WHERE p.post_type IN ('{$types_clause}')
                AND post_status NOT IN ('auto-draft', 'trash')
                AND NOT EXISTS (
                    SELECT 1 
                    FROM {$postmeta_table} pm 
                    WHERE p.id = pm.post_id 
                    AND pm.meta_key IN ('fifu_image_url', 'fifu_video_url', '_thumbnail_id')
                )
                {$db2_media_clause}
                ORDER BY p.ID");
        }

        $wpdb->query("INSERT INTO {$fifu_content_table} (post_ids, type)
            SELECT GROUP_CONCAT(post_id ORDER BY post_id SEPARATOR ','), 'post'
            FROM temp_post_content
            GROUP BY FLOOR((id - 1) / 100);");

        $wpdb->query("DROP TEMPORARY TABLE temp_post_content;");

        $last_insert_id = $wpdb->insert_id;
        if ($last_insert_id) {
            self::get_metadata_queue_repository()->log_prepare($last_insert_id, $fifu_content_table);
        }
    }

    /**
     * Clears all entries from the FIFU meta_in table.
     *
     * @return void
     */
    public static function clear_meta_in(): void {
        global $wpdb;

        $table = $wpdb->prefix . 'fifu_meta_in';
        $wpdb->query("DELETE FROM {$table} WHERE 1=1");
    }

    /**
     * Clears all entries from the FIFU meta_out table.
     *
     * @return void
     */
    public static function clear_meta_out(): void {
        global $wpdb;

        $table = $wpdb->prefix . 'fifu_meta_out';
        $wpdb->query("DELETE FROM {$table} WHERE 1=1");
    }

    /**
     * @return Fifu_Metadata_Queue_Repository
     */
    private static function get_metadata_queue_repository(): Fifu_Metadata_Queue_Repository {
        return new Fifu_Metadata_Queue_Repository();
    }

    private static function table_exists(wpdb $wpdb, string $table): bool {
        $sql = $wpdb->prepare("SHOW TABLES LIKE %s", $table);
        return $wpdb->get_var($sql) !== null;
    }

    private static function get_content_post_types_for_in_clause(): string
    {
        $types = (string) get_option('fifu_html_cpt', '');
        if (trim($types) === '') {
            return Fifu_Db2_Sql_Helper::get_types_for_in_clause();
        }

        $allowed = Fifu_Post_Type_Utils::get_post_types();
        $allowedLookup = array_fill_keys($allowed, true);
        $filtered = [];
        foreach (explode(',', $types) as $type) {
            $type = sanitize_key(trim($type));
            if ($type === '' || !isset($allowedLookup[$type])) {
                continue;
            }
            $filtered[$type] = true;
        }

        if (!$filtered) {
            return '__fifu_no_matching_post_type__';
        }

        return implode("','", array_keys($filtered));
    }
}
