<?php

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Fifu_Post_Slider_List_Url_Read_Service', false ) ) {
    require_once __DIR__ . '/class-fifu-post-slider-list-url-read-service.php';
}
if ( ! class_exists( 'Fifu_Post_Slider_Image_Url_Read_Service', false ) ) {
    require_once __DIR__ . '/class-fifu-post-slider-image-url-read-service.php';
}

/**
 * Resolves the featured image URL for a given post.
 */
class Fifu_Post_Main_Image_Resolver {

    /**
     * Determines the canonical featured image URL for a post.
     *
     * @param int  $post_id The post ID to resolve.
     * @param bool $front   Whether the resolution is for a front-end request.
     * @return string|null
     */
    /**
     * Determines the canonical featured image URL for a post.
     *
     * @param int    $post_id   The post ID to resolve.
     * @param bool   $front     Whether the resolution is for a front-end request.
     * @param array  $meta_data Optional pre-fetched FIFU meta values keyed by meta_key.
     * @return string|null
     */
    public static function get_main_image_url( int $post_id, bool $front = false, array $meta_data = [] ): ?string {
        $sliderMainUrl = self::resolve_slider_main_url( $post_id, $meta_data );
        if ( $sliderMainUrl !== null ) {
            return $sliderMainUrl;
        }

        if ( class_exists( 'Fifu_Post_Featured_Media_State_Resolver', false ) ) {
            $state = Fifu_Post_Featured_Media_State_Resolver::resolve( $post_id );
            $stateType = is_array( $state ) ? (string) ( $state['type'] ?? '' ) : '';
            $stateUrl = is_array( $state ) ? (string) ( $state['url'] ?? '' ) : '';

            if ( $stateType === 'slider' && $stateUrl !== '' ) {
                return str_replace( "'", '%27', htmlspecialchars_decode( $stateUrl ) );
            }

            if ( $stateType === 'image' && $stateUrl !== '' ) {
                return str_replace( "'", '%27', htmlspecialchars_decode( $stateUrl ) );
            }

            if ( $stateType === 'custom_video' && $stateUrl !== '' ) {
                $thumb = Fifu_Video_Helper::get_thumbnail_large( $stateUrl );
                if ( $thumb ) {
                    return self::normalize_url( $thumb );
                }

                if ( class_exists( 'Fifu_Video_Oembed_Service' ) ) {
                    $poster = Fifu_Video_Oembed_Service::instance()
                        ->get_repository()
                        ->get_image_url_by_video_url( $stateUrl );

                    if ( is_string( $poster ) && trim( $poster ) !== '' ) {
                        return self::normalize_url( $poster );
                    }
                }

                $fallbackImage = self::resolve_meta_value( $post_id, 'fifu_image_url', $meta_data );
                if ( $fallbackImage ) {
                    return self::normalize_url( $fallbackImage );
                }

                return null;
            }

            if ( $stateType === 'video' && $stateUrl !== '' ) {
                $videoUrl = $stateUrl;
                if ( $front && Fifu_Video_Helper::calls_oembed( $videoUrl ) ) {
                    $att_id  = (int) get_post_thumbnail_id( $post_id );
                    $att_url = $att_id > 0 ? get_post_meta( $att_id, '_wp_attached_file', true ) : '';
                    $url     = $att_url ? $att_url : Fifu_Video_Helper::get_thumbnail_large( $videoUrl );
                } else {
                    $url = Fifu_Video_Helper::get_thumbnail_large( $videoUrl );
                }

                if ( $url ) {
                    return str_replace( "'", '%27', htmlspecialchars_decode( $url ) );
                }
            }
        }

        $video_url = null;
        $url = self::resolve_meta_value( $post_id, 'fifu_image_url', $meta_data );
        if ( ! $url ) {
            $video_url = self::resolve_meta_value( $post_id, 'fifu_video_url', $meta_data );
        }

        if ( ! $url ) {
            if ( $front && Fifu_Video_Helper::calls_oembed( $video_url ) ) {
                $att_id  = (int) get_post_thumbnail_id( $post_id );
                $att_url = $att_id > 0 ? get_post_meta( $att_id, '_wp_attached_file', true ) : '';
                $url     = $att_url ? $att_url : Fifu_Video_Helper::get_thumbnail_large( $video_url );
            } else {
                $url = Fifu_Video_Helper::get_thumbnail_large( $video_url );
            }
        }

        if ( ! $url && Fifu_Post_Meta_Utils::has_no_internal_image( $post_id ) && Fifu_Options_Utils::is_on( 'fifu_enable_default_url' ) ) {
            if ( self::has_custom_video_featured_state( $post_id ) ) {
                return null;
            }

            if ( Fifu_Post_Type_Utils::is_valid_default_cpt( $post_id ) ) {
                $url = Fifu_Options_Utils::get_default_image_url();
            }
        }

        if ( ! $url ) {
            return null;
        }

        $url = htmlspecialchars_decode( $url );

        return str_replace( "'", '%27', $url );
    }

    /**
     * Resolve slider main image before featured media state can short-circuit it.
     *
     * @param int   $post_id
     * @param array $meta_data
     * @return string|null
     */
    private static function resolve_slider_main_url( int $post_id, array $meta_data = [] ): ?string {
        $url = self::resolve_meta_value( $post_id, 'fifu_slider_image_url_0', $meta_data );
        if ( ! empty( $url ) && strpos( $url, '#http' ) !== false ) {
            $url = substr( $url, strpos( $url, '#http' ) + 1 );
        }

        if ( ! $url ) {
            $url = self::get_slider_main_image_url( $post_id );
        }

        return self::normalize_url( $url );
    }

    /**
     * Resolve the first usable URL from the canonical slider reader.
     *
     * @param int $post_id
     * @return string|null
     */
    private static function get_slider_main_image_url( int $post_id ): ?string {
        $slider_list_url = Fifu_Post_Slider_List_Url_Read_Service::get_slider_list_url( $post_id );
        if ( ! is_string( $slider_list_url ) ) {
            return null;
        }

        $slider_list_url = trim( $slider_list_url );
        if ( '' === $slider_list_url ) {
            return null;
        }

        $parts = explode( '|', $slider_list_url );
        foreach ( $parts as $part ) {
            $candidate = trim( (string) $part );
            if ( '' !== $candidate ) {
                return htmlspecialchars_decode( $candidate );
            }
        }

        return null;
    }

    /**
     * Retrieve a FIFU meta field value, preferring cached metadata if provided.
     *
     * @param int    $post_id
     * @param string $key
     * @param array  $meta_data
     * @return string|null
     */
    private static function resolve_meta_value( int $post_id, string $key, array $meta_data ): ?string {
        if ( array_key_exists( $key, $meta_data ) ) {
            $value = $meta_data[ $key ];
            return $value !== '' && $value !== null ? (string) $value : null;
        }

        if ( $key === 'fifu_image_url' ) {
            return Fifu_Post_Image_Url_Read_Service::get_image_url( $post_id );
        }

        if ( $key === 'fifu_slider_image_url_0' ) {
            return Fifu_Post_Slider_Image_Url_Read_Service::get_slider_image_url( $post_id, 0 );
        }

        if ( $key === 'fifu_video_url' ) {
            return Fifu_Post_Video_Read_Service::get_video_url( $post_id );
        }

        $value = get_post_meta( $post_id, $key, true );
        return $value !== '' && $value !== null ? (string) $value : null;
    }

    /**
     * Normalize URLs to the canonical representation used by the resolver.
     *
     * @param string|null $url
     * @return string|null
     */
    private static function normalize_url( ?string $url ): ?string {
        if ( $url === null ) {
            return null;
        }

        $url = htmlspecialchars_decode( $url );
        $url = str_replace( "'", '%27', $url );
        $url = trim( $url );

        return $url !== '' ? $url : null;
    }

    private static function has_custom_video_featured_state( int $post_id ): bool {
        $legacy_custom_video = trim( (string) get_post_meta( $post_id, 'fifu_custom_video_url', true ) );

        if ( $legacy_custom_video !== '' ) {
            return true;
        }

        if ( ! class_exists( 'Fifu_Post_Featured_Media_State_Resolver', false ) ) {
            return false;
        }

        $state = Fifu_Post_Featured_Media_State_Resolver::resolve( $post_id );
        return is_array( $state ) && (string) ( $state['type'] ?? '' ) === 'custom_video' && trim( (string) ( $state['url'] ?? '' ) ) !== '';
    }
}
