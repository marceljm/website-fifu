<?php

if (!defined('ABSPATH')) {
    exit;
}

class Fifu_Metadata_Post_Bulk_Sync_Service {

    // Must stay aligned with Fifu_Metadata_Post_Work_Plan_Service legacy media input detection.
    private const LEGACY_MEDIA_INPUT_META_KEYS = array(
        'fifu_image_url',
        'fifu_list_url',
        'fifu_video_url',
        'fifu_list_video_url',
        'fifu_custom_video_url',
        'fifu_slider_list_url',
    );

    /**
     * @var array<int, array<int, array{url:string,alt?:string,key_type?:string,legacy_source?:string,persist_gallery?:bool}>>
     */
    private static array $cached_db2_images_by_post = array();

    /**
     * @var array<int, bool>
     */
    private static array $cached_db2_image_post_ids = array();
    /**
     * @var array<int, string>
     */
    private static array $cached_post_types_by_id = array();

    /**
     * Sync WordPress attachment metadata for clean DB2-only WooCommerce products.
     *
     * Phase 3 intentionally supports only the common DB2 image-list product path.
     *
     * @param array<int, int|string> $post_ids
     * @return array<string, mixed>
     */
    public static function sync_posts(array $post_ids): array {
        $normalized_post_ids = array_values(array_unique(array_filter(array_map('intval', $post_ids))));
        $post_ids = $normalized_post_ids;

        $result = array(
            'requested' => count($post_ids),
            'processed' => 0,
            'failed' => 0,
            'skipped' => 0,
            'processed_ids' => array(),
            'failed_ids' => array(),
            'skipped_ids' => array(),
        );
        $already_materialized_post_ids = array();

        if (isset($GLOBALS['__fifu_metadata_post_test_counters'])) {
            $GLOBALS['__fifu_metadata_post_test_counters']['bulk_sync_calls'] =
                (int) ($GLOBALS['__fifu_metadata_post_test_counters']['bulk_sync_calls'] ?? 0) + 1;
            $GLOBALS['__fifu_metadata_post_test_counters']['bulk_sync_requested_ids'][] = $post_ids;
        }

        $eligible_images_by_post = array();
        $legacy_meta_by_post = array();

            $db2_selection = self::select_clean_db2_product_ids($post_ids);
            $db2_clean_product_ids = $db2_selection['clean_product_ids'];
            $already_materialized_post_ids = $db2_selection['already_materialized_post_ids'];
            $db2_images_by_post = self::get_cached_or_load_db2_images_for_posts($db2_clean_product_ids);

            foreach ($db2_clean_product_ids as $post_id) {
                if (!empty($db2_images_by_post[$post_id][0]['url'])) {
                    $eligible_images_by_post[(int) $post_id] = $db2_images_by_post[$post_id];
                }
            }

            $legacy_selection = self::select_clean_legacy_image_list_products($post_ids);
            foreach ((array) ($legacy_selection['images_by_post'] ?? array()) as $post_id => $images) {
                $post_id = (int) $post_id;
                if (isset($eligible_images_by_post[$post_id])) {
                    continue;
                }

                if (!empty($images[0]['url'])) {
                    $eligible_images_by_post[$post_id] = $images;
                    $legacy_meta_by_post[$post_id] = $legacy_selection['legacy_meta_by_post'][$post_id] ?? array();
                }
            }

            $eligible_id_set = array_fill_keys(array_keys($eligible_images_by_post), true);
            foreach ($post_ids as $post_id) {
                $post_id = (int) $post_id;
                if (empty($eligible_id_set[$post_id])) {
                    $result['skipped']++;
                    $result['skipped_ids'][] = $post_id;
                }
            }


        $already_materialized_post_ids = array_values(array_unique(array_filter(array_map('intval', $already_materialized_post_ids))));
        if (!empty($already_materialized_post_ids)) {
            self::bulk_delete_metadatapost_sent_state($already_materialized_post_ids);
        }

        if (empty($eligible_images_by_post)) {
            return $result;
        }

        $attachments_by_post = array();

        try {
            $attachments_by_post = self::bulk_create_attachments_for_posts($eligible_images_by_post);
            self::migrate_legacy_image_lists_to_db2($legacy_meta_by_post);
            $post_types_by_id = self::get_supported_post_types_by_id(array_keys($eligible_images_by_post));
            self::bulk_persist_metadata($attachments_by_post, $eligible_images_by_post, $post_types_by_id);
            foreach ($eligible_images_by_post as $post_id => $images) {
                if (empty($attachments_by_post[$post_id][0])) {
                    throw new RuntimeException('Failed to create featured attachment.');
                }

                $result['processed']++;
                $result['processed_ids'][] = (int) $post_id;
            }
        } catch (Throwable $throwable) {
            foreach (array_keys($eligible_images_by_post) as $post_id) {
                delete_post_meta((int) $post_id, '_thumbnail_id');
                delete_post_meta((int) $post_id, '_product_image_gallery');
            }
            self::rollback_created_attachments($attachments_by_post);

            $failed_ids = array_keys($eligible_images_by_post);
            $result['failed'] += count($failed_ids);
            $result['failed_ids'] = array_merge($result['failed_ids'], array_map('intval', $failed_ids));

            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[FIFU MetadataPost Bulk Sync] error=' . $throwable->getMessage());
            }
        }

        return $result;
    }

    /**
     * @param array<int, int|string> $post_ids
     * @return array{candidate_ids: array<int, int>, already_materialized_post_ids: array<int, int>}
     */
    public static function select_bulk_candidate_product_ids(array $post_ids): array {
        $post_ids = array_values(array_unique(array_filter(array_map('intval', $post_ids))));
        if (empty($post_ids)) {
            return array(
                'candidate_ids' => array(),
                'already_materialized_post_ids' => array(),
            );
        }

        $db2_selection = self::select_clean_db2_product_ids($post_ids);
        $legacy_selection = self::select_clean_legacy_image_list_products($post_ids);
        $db2_media_post_ids = self::get_post_ids_with_any_db2_media($post_ids);
        $post_types_by_id = self::get_supported_post_types_by_id(array_keys($db2_media_post_ids));
        $already_materialized_post_ids = array();
        foreach ((array) ($db2_selection['already_materialized_post_ids'] ?? array()) as $already_materialized_post_id) {
            $already_materialized_post_ids[(int) $already_materialized_post_id] = true;
        }

        $candidate_set = array();
        foreach ((array) ($db2_selection['clean_product_ids'] ?? array()) as $post_id) {
            $candidate_set[(int) $post_id] = true;
        }
        foreach ((array) ($legacy_selection['clean_product_ids'] ?? array()) as $post_id) {
            $candidate_set[(int) $post_id] = true;
        }
        foreach (array_keys($db2_media_post_ids) as $post_id) {
            $post_id = (int) $post_id;
            if (isset($already_materialized_post_ids[$post_id])) {
                continue;
            }

            $post_type = (string) ($post_types_by_id[$post_id] ?? '');

            if (!in_array($post_type, array('product', 'product_variation'), true)) {
                continue;
            }

            $candidate_set[$post_id] = true;
        }

        $ordered = array();
        foreach ($post_ids as $post_id) {
            if (!empty($candidate_set[(int) $post_id])) {
                $ordered[] = (int) $post_id;
            }
        }

        return array(
            'candidate_ids' => $ordered,
            'already_materialized_post_ids' => (array) ($db2_selection['already_materialized_post_ids'] ?? array()),
        );
    }

    /**
     * @param array<int, int|string> $post_ids
     * @return array<int, int>
     */
    private static function filter_product_ids(array $post_ids): array {
        global $wpdb;

        $post_ids = array_values(array_unique(array_filter(array_map('intval', $post_ids))));
        if (empty($post_ids)) {
            return array();
        }

        $product_ids = array();
        foreach (array_chunk($post_ids, 1000) as $chunk) {
            $placeholders = implode(',', array_fill(0, count($chunk), '%d'));
            $rows = $wpdb->get_col($wpdb->prepare(
                "SELECT ID
                 FROM {$wpdb->posts}
                 WHERE ID IN ({$placeholders})
                   AND post_type = 'product'
                   AND post_status <> 'trash'",
                $chunk
            ));

            foreach ((array) $rows as $row_id) {
                $product_ids[(int) $row_id] = (int) $row_id;
            }
        }

        $ordered = array();
        foreach ($post_ids as $post_id) {
            if (isset($product_ids[$post_id])) {
                $ordered[] = $post_id;
            }
        }

        return $ordered;
    }

    /**
     * @param array<int, int|string> $post_ids
     * @return array<int, string>
     */
    private static function get_supported_post_types_by_id(array $post_ids): array
    {
        global $wpdb;

        $post_ids = array_values(array_unique(array_filter(array_map('intval', $post_ids), static function ($post_id) {
            return $post_id > 0;
        })));

        if (empty($post_ids)) {
            return array();
        }

        $types_by_id = array();

        foreach (array_chunk($post_ids, 1000) as $chunk) {
            $placeholders = implode(',', array_fill(0, count($chunk), '%d'));

            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT ID, post_type
                 FROM {$wpdb->posts}
                 WHERE ID IN ({$placeholders})
                   AND post_type IN ('post', 'product')
                   AND post_status <> 'trash'",
                $chunk
            ), ARRAY_A);

            foreach ((array) $rows as $row) {
                $types_by_id[(int) $row['ID']] = (string) $row['post_type'];
            }
        }

        foreach ($post_ids as $post_id) {
            $post_id = (int) $post_id;
            if (!isset($types_by_id[$post_id])) {
                $post_type = get_post_type($post_id);
                if (in_array($post_type, array('post', 'product'), true)) {
                    $types_by_id[$post_id] = $post_type;
                }
            }
        }

        return $types_by_id;
    }

    /**
     * @param array<int, int|string> $post_ids
     * @return array<int, int>
     */
    private static function filter_supported_post_ids(array $post_ids): array
    {
        $post_ids = array_values(array_unique(array_filter(array_map('intval', $post_ids))));
        if (empty($post_ids)) {
            return array();
        }

        $types_by_id = self::get_supported_post_types_by_id($post_ids);

        $ordered = array();
        foreach ($post_ids as $post_id) {
            if (isset($types_by_id[(int) $post_id])) {
                $ordered[] = (int) $post_id;
            }
        }

        return $ordered;
    }

    /**
     * @param array<int, int|string> $post_ids
     * @return array{clean_product_ids: array<int, int>, already_materialized_post_ids: array<int, int>}
     */
    public static function select_clean_db2_product_ids(array $post_ids): array {
        global $wpdb;

        $post_ids = self::filter_supported_post_ids($post_ids);
        if (empty($post_ids)) {
            return array('clean_product_ids' => array(), 'already_materialized_post_ids' => array());
        }

        $images_by_post = self::get_db2_images_for_posts($post_ids);
        self::$cached_db2_images_by_post = $images_by_post;
        self::$cached_db2_image_post_ids = array_fill_keys(array_keys($images_by_post), true);
        $post_types_by_id = self::get_supported_post_types_by_id(array_keys($images_by_post));
        if (empty($images_by_post)) {
            return array('clean_product_ids' => array(), 'already_materialized_post_ids' => array());
        }

        $candidate_ids = array_keys($images_by_post);
        $candidate_id_set = array_fill_keys($candidate_ids, true);

        $postmeta_table = $wpdb->postmeta;
        $legacy_meta_keys = self::get_legacy_media_input_meta_keys();

        $generated_meta_ids = array();
        foreach (array_chunk($candidate_ids, 1000) as $chunk) {
            $placeholders = implode(',', array_fill(0, count($chunk), '%d'));
            $rows = $wpdb->get_col($wpdb->prepare(
                "SELECT DISTINCT post_id
                 FROM {$postmeta_table}
                 WHERE post_id IN ({$placeholders})
                   AND meta_key IN ('_thumbnail_id', '_product_image_gallery')
                   AND meta_value <> ''",
                $chunk
            ));
            foreach ((array) $rows as $row_id) {
                $generated_meta_ids[(int) $row_id] = true;
            }
        }

        $legacy_meta_ids = array();
        foreach (array_chunk($candidate_ids, 1000) as $chunk) {
            $placeholders = implode(',', array_fill(0, count($chunk), '%s'));
            $params = array_merge($chunk, $legacy_meta_keys);
            $legacy_placeholders = implode(',', array_fill(0, count($legacy_meta_keys), '%s'));
            $rows = $wpdb->get_col($wpdb->prepare(
                "SELECT DISTINCT post_id
                 FROM {$postmeta_table}
                 WHERE post_id IN ({$placeholders})
                   AND (
                        meta_key IN ({$legacy_placeholders})
                     OR meta_key LIKE 'fifu_image_url\\_%'
                     OR meta_key LIKE 'fifu_video_url\\_%'
                     OR meta_key LIKE 'fifu_slider_image_url\\_%'
                   )
                   AND meta_value <> ''",
                $params
            ));
            foreach ((array) $rows as $row_id) {
                $legacy_meta_ids[(int) $row_id] = true;
            }
        }

        $selected = array();
        $already_materialized_post_ids = array();
        foreach ($post_ids as $post_id) {
            if (empty($candidate_id_set[$post_id])) {
                continue;
            }
            if (empty($images_by_post[$post_id][0]['url'])) {
                continue;
            }
            if (($post_types_by_id[$post_id] ?? '') === 'post') {
                $media_type = self::get_loaded_db2_media_type((array) ($images_by_post[$post_id] ?? array()));
                $indexes = array_map('intval', array_keys((array) ($images_by_post[$post_id] ?? array())));

                foreach ($indexes as $index) {
                    if ($index <= 0) {
                        continue;
                    }

                    // Normal DB2 image galleries must remain fallback-only.
                    // Normal DB2 slider lists are allowed because slider index 1+ must create
                    // slider attachment metadata without writing _product_image_gallery.
                    if ($media_type !== 'slider') {
                        continue 2;
                    }
                }
            }
            if (!empty($generated_meta_ids[$post_id])) {
                $already_materialized_post_ids[] = $post_id;
                continue;
            }
            if (!empty($legacy_meta_ids[$post_id])) {
                continue;
            }
            $selected[] = $post_id;
        }

        return array(
            'clean_product_ids' => $selected,
            'already_materialized_post_ids' => $already_materialized_post_ids,
        );
    }

    /**
     * @param array<int, int|string> $post_ids
     * @return array{clean_product_ids: array<int, int>, images_by_post: array<int, array<int, array{url:string,alt?:string}>>, legacy_meta_by_post: array<int, array<string, string>>}
     */
    private static function select_clean_legacy_image_list_products(array $post_ids): array {
        $post_ids = self::filter_supported_post_ids($post_ids);
        $post_types_by_id = self::get_supported_post_types_by_id($post_ids);
        $fifu_debug_legacy_bulk = get_option('fifu_debug_legacy_bulk_selection') === 'toggleon';
        $debug = array(
            'input' => count($post_ids),
            'generated_wp_media' => 0,
            'has_db2_media' => 0,
            'missing_fifu_list_url' => 0,
            'complex_or_non_list' => 0,
            'invalid_image_list' => 0,
            'accepted' => 0,
            'sample_rejections' => array(),
        );

        if (empty($post_ids)) {
            if ($fifu_debug_legacy_bulk) {
                error_log('[FIFU MetadataPost Legacy Bulk Selection] ' . wp_json_encode($debug));
            }
            return array(
                'clean_product_ids' => array(),
                'images_by_post' => array(),
                'legacy_meta_by_post' => array(),
            );
        }

        $generated_meta_ids = self::get_post_ids_with_generated_wordpress_media($post_ids);
        $db2_media_ids = self::get_post_ids_with_any_db2_media($post_ids);
        $legacy_meta_by_post = self::get_legacy_meta_for_posts($post_ids);

        $clean_ids = array();
        $images_by_post = array();
        $clean_legacy_meta_by_post = array();

        foreach ($post_ids as $post_id) {
            if (!empty($generated_meta_ids[$post_id])) {
                $debug['generated_wp_media']++;
                if (count($debug['sample_rejections']) < 5) {
                    $meta = $legacy_meta_by_post[$post_id] ?? array();
                    $debug['sample_rejections'][] = array(
                        'post_id' => (int) $post_id,
                        'reason' => 'generated_wp_media',
                        'meta_keys' => array_keys($meta),
                        'non_empty_meta' => array_filter($meta, static fn($v) => trim((string) $v) !== ''),
                    );
                }
                continue;
            }

            if (!empty($db2_media_ids[$post_id])) {
                $debug['has_db2_media']++;
                if (count($debug['sample_rejections']) < 5) {
                    $meta = $legacy_meta_by_post[$post_id] ?? array();
                    $debug['sample_rejections'][] = array(
                        'post_id' => (int) $post_id,
                        'reason' => 'has_db2_media',
                        'meta_keys' => array_keys($meta),
                        'non_empty_meta' => array_filter($meta, static fn($v) => trim((string) $v) !== ''),
                    );
                }
                continue;
            }

            $meta = $legacy_meta_by_post[$post_id] ?? array();
            $post_type = $post_types_by_id[$post_id] ?? 'product';
            $indexed_slider_images = self::build_indexed_legacy_slider_images_from_meta($meta);
            if (!empty($indexed_slider_images) && !empty($indexed_slider_images[0]['url'])) {
                $clean_ids[] = (int) $post_id;
                $images_by_post[(int) $post_id] = $indexed_slider_images;
                $clean_legacy_meta_by_post[(int) $post_id] = array_merge(
                    array('__fifu_legacy_media_type' => 'indexed_slider'),
                    self::build_indexed_slider_legacy_meta_for_db2_migration($meta)
                );
                $debug['accepted']++;
                continue;
            }
            if ($post_type === 'post') {
                $featured_url = trim((string) ($meta['fifu_image_url'] ?? ''));
                if ($featured_url === '') {
                    $debug['missing_fifu_list_url']++;
                    continue;
                }
                if (trim((string) ($meta['fifu_list_url'] ?? '')) !== '' || self::has_indexed_image_legacy_fields($meta) || self::has_complex_or_non_list_legacy_input($meta)) {
                    $debug['complex_or_non_list']++;
                    continue;
                }
                $images = self::build_featured_only_legacy_image_from_meta($meta);
                if (empty($images) || empty($images[0]['url'])) {
                    $debug['invalid_image_list']++;
                    continue;
                }
                $clean_ids[] = (int) $post_id;
                $images_by_post[(int) $post_id] = $images;
                $clean_legacy_meta_by_post[(int) $post_id] = self::build_canonical_list_meta_from_images($images);
                $debug['accepted']++;
                continue;
            }

            $has_list_url = trim((string) ($meta['fifu_list_url'] ?? '')) !== '';
            $has_indexed_url = trim((string) ($meta['fifu_image_url'] ?? '')) !== '';

            if (!$has_list_url && !$has_indexed_url) {
                $debug['missing_fifu_list_url']++;
                continue;
            }

            if (self::has_complex_or_non_list_legacy_input($meta)) {
                $debug['complex_or_non_list']++;
                continue;
            }

            $images = $has_list_url
                ? self::build_legacy_image_list_from_meta($meta)
                : self::build_indexed_legacy_image_list_from_meta($meta);
            if (empty($images) || empty($images[0]['url'])) {
                $debug['invalid_image_list']++;
                continue;
            }

            $clean_ids[] = (int) $post_id;
            $images_by_post[(int) $post_id] = $images;
            $clean_legacy_meta_by_post[(int) $post_id] = self::build_canonical_list_meta_from_images($images);
            $debug['accepted']++;
        }

        if ($fifu_debug_legacy_bulk) {
            error_log('[FIFU MetadataPost Legacy Bulk Selection] ' . wp_json_encode($debug));
        }

        return array(
            'clean_product_ids' => $clean_ids,
            'images_by_post' => $images_by_post,
            'legacy_meta_by_post' => $clean_legacy_meta_by_post,
        );
    }

    /**
     * @param array<int, int|string> $post_ids
     * @return array<int, bool>
     */
    private static function get_post_ids_with_generated_wordpress_media(array $post_ids): array {
        global $wpdb;

        $post_ids = array_values(array_unique(array_filter(array_map('intval', $post_ids))));
        if (empty($post_ids)) {
            return array();
        }

        $found = array();

        foreach (array_chunk($post_ids, 1000) as $chunk) {
            $placeholders = implode(',', array_fill(0, count($chunk), '%d'));

            $rows = $wpdb->get_col($wpdb->prepare(
                "SELECT DISTINCT post_id
                 FROM {$wpdb->postmeta}
                 WHERE post_id IN ({$placeholders})
                   AND meta_key IN ('_thumbnail_id', '_product_image_gallery')
                   AND meta_value <> ''",
                $chunk
            ));

            foreach ((array) $rows as $row_id) {
                $found[(int) $row_id] = true;
            }
        }

        return $found;
    }

    /**
     * @param array<int, int|string> $post_ids
     * @return array<int, bool>
     */
    private static function get_post_ids_with_any_db2_media(array $post_ids): array
    {
        global $wpdb;

        $post_ids = array_values(array_unique(array_filter(array_map('intval', $post_ids))));
        if (empty($post_ids)) {
            return array();
        }

        $map_table = $wpdb->prefix . 'fifu_map';
        $key_table = $wpdb->prefix . 'fifu_key';

        if (!self::table_exists($map_table) || !self::table_exists($key_table)) {
            return array();
        }

        $found = array();

        foreach (array_chunk($post_ids, 1000) as $chunk) {
            $placeholders = implode(',', array_fill(0, count($chunk), '%d'));

            $rows = $wpdb->get_col($wpdb->prepare(
                "SELECT DISTINCT m.post_id
                 FROM {$map_table} m
                 INNER JOIN {$key_table} k ON k.key_id = m.key_id
                 WHERE m.post_id IN ({$placeholders})
                   AND k.key_type IN ('image', 'video', 'slider', 'custom_video')",
                $chunk
            ));

            foreach ((array) $rows as $row_id) {
                $found[(int) $row_id] = true;
            }
        }

        return $found;
    }

    /**
     * @param array<int, int|string> $post_ids
     * @return array<int, array<string, string>>
     */
    private static function get_legacy_meta_for_posts(array $post_ids): array {
        global $wpdb;

        $post_ids = array_values(array_unique(array_filter(array_map('intval', $post_ids))));
        if (empty($post_ids)) {
            return array();
        }

        $meta_by_post = array();
        $exact_keys = array(
            'fifu_list_url',
            'fifu_list_alt',
            'fifu_video_url',
            'fifu_list_video_url',
            'fifu_custom_video_url',
            'fifu_slider_list_url',
            'fifu_slider_list_alt',
            'fifu_image_url',
            'fifu_image_alt',
        );

        foreach (array_chunk($post_ids, 1000) as $chunk) {
            $id_placeholders = implode(',', array_fill(0, count($chunk), '%d'));
            $key_placeholders = implode(',', array_fill(0, count($exact_keys), '%s'));
            $params = array_merge($chunk, $exact_keys);

            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT post_id, meta_key, meta_value
                 FROM {$wpdb->postmeta}
                 WHERE post_id IN ({$id_placeholders})
                   AND (
                        meta_key IN ({$key_placeholders})
                     OR meta_key LIKE 'fifu_image_url\\_%'
                     OR meta_key LIKE 'fifu_image_alt\\_%'
                     OR meta_key LIKE 'fifu_video_url\\_%'
                     OR meta_key LIKE 'fifu_slider_image_url\\_%'
                     OR meta_key LIKE 'fifu_slider_image_alt\\_%'
                   )",
                $params
            ), ARRAY_A);

            foreach ((array) $rows as $row) {
                $post_id = (int) $row['post_id'];
                $meta_by_post[$post_id][(string) $row['meta_key']] = (string) $row['meta_value'];
            }
        }

        return $meta_by_post;
    }

    private static function has_complex_or_non_list_legacy_input(array $meta): bool
    {
        foreach ($meta as $key => $value) {
            $key = (string) $key;
            $value = trim((string) $value);

            if ($value === '') {
                continue;
            }

            if (
                $key === 'fifu_video_url'
                || $key === 'fifu_list_video_url'
                || $key === 'fifu_custom_video_url'
                || $key === 'fifu_slider_list_url'
                || preg_match('/^fifu_video_url_\\d+$/', $key) === 1
                || preg_match('/^fifu_slider_image_url_\\d+$/', $key) === 1
                || preg_match('/^fifu_slider_image_alt_\\d+$/', $key) === 1
            ) {
                return true;
            }
        }

        return false;
    }

    private static function has_indexed_slider_legacy_fields(array $meta): bool
    {
        foreach ($meta as $key => $value) {
            $key = (string) $key;
            $value = trim((string) $value);

            if ($value === '') {
                continue;
            }

            if (
                preg_match('/^fifu_slider_image_url_\d+$/', $key) === 1
                || preg_match('/^fifu_slider_image_alt_\d+$/', $key) === 1
            ) {
                return true;
            }
        }

        return false;
    }

    private static function has_non_indexed_slider_legacy_input(array $meta): bool
    {
        foreach ($meta as $key => $value) {
            $key = (string) $key;
            $value = trim((string) $value);

            if ($value === '') {
                continue;
            }

            if (
                preg_match('/^fifu_slider_image_url_\d+$/', $key) === 1
                || preg_match('/^fifu_slider_image_alt_\d+$/', $key) === 1
            ) {
                continue;
            }

            if (
                $key === 'fifu_image_url'
                || $key === 'fifu_image_alt'
                || $key === 'fifu_list_url'
                || $key === 'fifu_list_alt'
                || $key === 'fifu_video_url'
                || $key === 'fifu_list_video_url'
                || $key === 'fifu_custom_video_url'
                || $key === 'fifu_slider_list_url'
                || preg_match('/^fifu_image_url_\d+$/', $key) === 1
                || preg_match('/^fifu_image_alt_\d+$/', $key) === 1
                || preg_match('/^fifu_video_url_\d+$/', $key) === 1
            ) {
                return true;
            }
        }

        return false;
    }

    private static function has_indexed_image_legacy_fields(array $meta): bool
    {
        foreach ($meta as $key => $value) {
            $key = (string) $key;
            $value = trim((string) $value);

            if ($value === '') {
                continue;
            }

            if (
                preg_match('/^fifu_image_url_\d+$/', $key) === 1
                || preg_match('/^fifu_image_alt_\d+$/', $key) === 1
            ) {
                return true;
            }
        }

        return false;
    }

    private static function build_featured_only_legacy_image_from_meta(array $meta): array
    {
        $url = trim(htmlspecialchars_decode((string) ($meta['fifu_image_url'] ?? '')));
        if ($url === '') {
            return array();
        }

        if (class_exists('Fifu_Video_Helper', false) && Fifu_Video_Helper::is_video($url)) {
            return array();
        }

        $converted_url = function_exists('fifu_convert') ? fifu_convert($url) : $url;
        $normalized_url = class_exists('Fifu_Db2_Normalizer', false)
            ? Fifu_Db2_Normalizer::normalize_url((string) $converted_url)
            : trim((string) $converted_url);

        if ($normalized_url === null || trim((string) $normalized_url) === '') {
            return array();
        }

        $image = array('url' => (string) $normalized_url);

        $alt_raw = (string) ($meta['fifu_image_alt'] ?? '');
        if (trim($alt_raw) !== '') {
            $normalized_alt = class_exists('Fifu_Db2_Normalizer', false)
                ? Fifu_Db2_Normalizer::normalize_alt($alt_raw)
                : trim($alt_raw);

            if ($normalized_alt === null) {
                return array();
            }

            if (trim((string) $normalized_alt) !== '') {
                $image['alt'] = (string) $normalized_alt;
            }
        }

        return array(0 => $image);
    }

    private static function parse_legacy_pipe_values(string $value): array
    {
        $parts = array_map('trim', explode('|', $value));
        $result = array();

        foreach ($parts as $index => $part) {
            $part = htmlspecialchars_decode((string) $part);
            $part = trim($part);

            if ($part === '') {
                continue;
            }

            $result[(int) $index] = $part;
        }

        return $result;
    }

    private static function build_legacy_image_list_from_meta(array $meta): array
    {
        $urls = self::parse_legacy_pipe_values((string) ($meta['fifu_list_url'] ?? ''));
        if (empty($urls) || empty($urls[0])) {
            return array();
        }

        ksort($urls, SORT_NUMERIC);

        $expected = 0;
        foreach (array_keys($urls) as $index) {
            if ((int) $index !== $expected) {
                return array();
            }
            $expected++;
        }

        $alts = self::parse_legacy_pipe_values((string) ($meta['fifu_list_alt'] ?? ''));
        $images = array();

        foreach ($urls as $index => $url) {
            $url = trim((string) $url);
            if ($url === '') {
                return array();
            }

            if (class_exists('Fifu_Video_Helper', false) && Fifu_Video_Helper::is_video($url)) {
                return array();
            }

            $converted_url = function_exists('fifu_convert') ? fifu_convert($url) : $url;
            $normalized_url = class_exists('Fifu_Db2_Normalizer', false)
                ? Fifu_Db2_Normalizer::normalize_url((string) $converted_url)
                : trim((string) $converted_url);

            if ($normalized_url === null || trim((string) $normalized_url) === '') {
                return array();
            }

            $image = array('url' => (string) $normalized_url);

            $alt_raw = (string) ($alts[(int) $index] ?? '');
            if (trim($alt_raw) !== '') {
                $normalized_alt = class_exists('Fifu_Db2_Normalizer', false)
                    ? Fifu_Db2_Normalizer::normalize_alt($alt_raw)
                    : trim($alt_raw);

                if ($normalized_alt === null) {
                    return array();
                }

                if (trim((string) $normalized_alt) !== '') {
                    $image['alt'] = (string) $normalized_alt;
                }
            }

            $images[(int) $index] = $image;
        }

        return $images;
    }

    private static function build_indexed_legacy_image_list_from_meta(array $meta): array
    {
        $urls = array();

        $main_url = trim(htmlspecialchars_decode((string) ($meta['fifu_image_url'] ?? '')));
        if ($main_url === '') {
            return array();
        }

        $urls[0] = $main_url;

        foreach ($meta as $key => $value) {
            if (preg_match('/^fifu_image_url_(\d+)$/', (string) $key, $matches) !== 1) {
                continue;
            }

            $logical_index = ((int) $matches[1]) + 1;
            $url = trim(htmlspecialchars_decode((string) $value));
            if ($url === '') {
                return array();
            }

            $urls[$logical_index] = $url;
        }

        ksort($urls, SORT_NUMERIC);

        $expected = 0;
        foreach (array_keys($urls) as $index) {
            if ((int) $index !== $expected) {
                return array();
            }
            $expected++;
        }

        $alts = array();
        $main_alt = trim((string) ($meta['fifu_image_alt'] ?? ''));
        if ($main_alt !== '') {
            $alts[0] = $main_alt;
        }

        foreach ($meta as $key => $value) {
            if (preg_match('/^fifu_image_alt_(\d+)$/', (string) $key, $matches) !== 1) {
                continue;
            }

            $logical_index = ((int) $matches[1]) + 1;
            $alt = trim((string) $value);
            if ($alt !== '') {
                $alts[$logical_index] = $alt;
            }
        }

        $images = array();

        foreach ($urls as $index => $url) {
            if (class_exists('Fifu_Video_Helper', false) && Fifu_Video_Helper::is_video($url)) {
                return array();
            }

            $converted_url = function_exists('fifu_convert') ? fifu_convert($url) : $url;
            $normalized_url = class_exists('Fifu_Db2_Normalizer', false)
                ? Fifu_Db2_Normalizer::normalize_url((string) $converted_url)
                : trim((string) $converted_url);

            if ($normalized_url === null || trim((string) $normalized_url) === '') {
                return array();
            }

            $image = array('url' => (string) $normalized_url);

            $alt_raw = (string) ($alts[(int) $index] ?? '');
            if (trim($alt_raw) !== '') {
                $normalized_alt = class_exists('Fifu_Db2_Normalizer', false)
                    ? Fifu_Db2_Normalizer::normalize_alt($alt_raw)
                    : trim($alt_raw);

                if ($normalized_alt === null) {
                    return array();
                }

                if (trim((string) $normalized_alt) !== '') {
                    $image['alt'] = (string) $normalized_alt;
                }
            }

            $images[(int) $index] = $image;
        }

        return $images;
    }

    private static function build_indexed_legacy_slider_images_from_meta(array $meta): array
    {
        if (self::has_non_indexed_slider_legacy_input($meta)) {
            return array();
        }

        $urls = array();

        foreach ($meta as $key => $value) {
            if (preg_match('/^fifu_slider_image_url_(\d+)$/', (string) $key, $matches) !== 1) {
                continue;
            }

            $index = (int) $matches[1];
            $url = trim(htmlspecialchars_decode((string) $value));

            if ($url === '') {
                return array();
            }

            $urls[$index] = $url;
        }

        if (empty($urls) || empty($urls[0])) {
            return array();
        }

        ksort($urls, SORT_NUMERIC);

        $expected = 0;
        foreach (array_keys($urls) as $index) {
            if ((int) $index !== $expected) {
                return array();
            }
            $expected++;
        }

        $alts = array();
        foreach ($meta as $key => $value) {
            if (preg_match('/^fifu_slider_image_alt_(\d+)$/', (string) $key, $matches) !== 1) {
                continue;
            }

            $index = (int) $matches[1];
            $alt = trim((string) $value);

            if ($alt !== '') {
                $alts[$index] = $alt;
            }
        }

        $list_alts = self::parse_legacy_alt_list((string) ($meta['fifu_slider_list_alt'] ?? ''));

        $images = array();

        foreach ($urls as $index => $url) {
            if (class_exists('Fifu_Video_Helper', false) && Fifu_Video_Helper::is_video($url)) {
                return array();
            }

            $converted_url = function_exists('fifu_convert') ? fifu_convert($url) : $url;
            $normalized_url = class_exists('Fifu_Db2_Normalizer', false)
                ? Fifu_Db2_Normalizer::normalize_url((string) $converted_url)
                : trim((string) $converted_url);

            if ($normalized_url === null || trim((string) $normalized_url) === '') {
                return array();
            }

            $image = array(
                'url' => (string) $normalized_url,
                'key_type' => 'slider',
                'legacy_source' => 'indexed_slider',
                'persist_gallery' => true,
            );

            $alt_raw = (string) ($alts[(int) $index] ?? ($list_alts[(int) $index] ?? ''));
            if (trim($alt_raw) !== '') {
                $normalized_alt = class_exists('Fifu_Db2_Normalizer', false)
                    ? Fifu_Db2_Normalizer::normalize_alt($alt_raw)
                    : trim($alt_raw);

                if ($normalized_alt === null) {
                    return array();
                }

                if (trim((string) $normalized_alt) !== '') {
                    $image['alt'] = (string) $normalized_alt;
                }
            }

            $images[(int) $index] = $image;
        }

        return $images;
    }

    private static function parse_legacy_alt_list(string $raw): array
    {
        $raw = trim($raw);
        if ($raw === '') {
            return array();
        }

        $parts = explode('|', $raw);
        $alts = array();

        foreach ($parts as $index => $part) {
            $alt = trim((string) $part);
            if ($alt !== '') {
                $alts[(int) $index] = $alt;
            }
        }

        return $alts;
    }

    private static function build_indexed_slider_legacy_meta_for_db2_migration(array $meta): array
    {
        $clean = array();

        foreach ($meta as $key => $value) {
            $key = (string) $key;

            if (
                preg_match('/^fifu_slider_image_url_\d+$/', $key) === 1
                || preg_match('/^fifu_slider_image_alt_\d+$/', $key) === 1
            ) {
                $clean[$key] = (string) $value;
                continue;
            }

            if ($key === 'fifu_slider_list_alt') {
                $clean[$key] = (string) $value;
            }
        }

        return $clean;
    }

    private static function build_canonical_list_meta_from_images(array $images): array
    {
        ksort($images, SORT_NUMERIC);

        $urls = array();
        $alts = array();

        foreach ($images as $index => $image) {
            $urls[(int) $index] = (string) ($image['url'] ?? '');
            $alts[(int) $index] = (string) ($image['alt'] ?? '');
        }

        $max_index = empty($urls) ? -1 : max(array_keys($urls));
        $url_parts = array();
        $alt_parts = array();

        for ($i = 0; $i <= $max_index; $i++) {
            $url_parts[] = (string) ($urls[$i] ?? '');
            $alt_parts[] = (string) ($alts[$i] ?? '');
        }

        return array(
            'fifu_list_url' => implode('|', $url_parts),
            'fifu_list_alt' => implode('|', $alt_parts),
        );
    }

    /**
     * @param array<int, array<string, string>> $legacy_meta_by_post
     */
    private static function migrate_legacy_image_lists_to_db2(array $legacy_meta_by_post): void
    {
        if (empty($legacy_meta_by_post)) {
            return;
        }

        if (!class_exists('Fifu_Metadata_Import_Service', false)) {
            $path = __DIR__ . '/class-fifu-metadata-import-service.php';
            if (file_exists($path)) {
                require_once $path;
            }
        }

        $image_list_meta_by_post = array();
        $indexed_slider_meta_by_post = array();

        foreach ($legacy_meta_by_post as $post_id => $meta) {
            $meta = (array) $meta;
            $media_type = (string) ($meta['__fifu_legacy_media_type'] ?? 'image_list');
            unset($meta['__fifu_legacy_media_type']);

            if ($media_type === 'indexed_slider') {
                $indexed_slider_meta_by_post[(int) $post_id] = $meta;
            } else {
                $image_list_meta_by_post[(int) $post_id] = $meta;
            }
        }

        if (!empty($image_list_meta_by_post)) {
            if (
                !class_exists('Fifu_Metadata_Import_Service', false)
                || !method_exists('Fifu_Metadata_Import_Service', 'migrate_simple_post_image_list_legacy_meta_to_db2_for_metadata_post_bulk')
            ) {
                throw new RuntimeException('Legacy image-list DB2 migration service is unavailable.');
            }

            $migrated = Fifu_Metadata_Import_Service::migrate_simple_post_image_list_legacy_meta_to_db2_for_metadata_post_bulk($image_list_meta_by_post);

            if ($migrated === false) {
                throw new RuntimeException('Failed to migrate clean legacy image lists to DB2.');
            }

            $missing = array_diff(array_keys($image_list_meta_by_post), array_keys((array) $migrated));
            if (!empty($missing)) {
                throw new RuntimeException('Clean legacy image-list DB2 migration did not confirm all posts.');
            }

            self::bulk_delete_legacy_image_source_meta(array_keys($image_list_meta_by_post));
        }

        if (!empty($indexed_slider_meta_by_post)) {
            if (
                !class_exists('Fifu_Metadata_Import_Service', false)
                || !method_exists('Fifu_Metadata_Import_Service', 'migrate_indexed_slider_legacy_meta_to_db2_for_metadata_post_bulk')
            ) {
                throw new RuntimeException('Legacy indexed-slider DB2 migration service is unavailable.');
            }

            $migrated = Fifu_Metadata_Import_Service::migrate_indexed_slider_legacy_meta_to_db2_for_metadata_post_bulk($indexed_slider_meta_by_post);

            if ($migrated === false) {
                throw new RuntimeException('Failed to migrate clean legacy indexed slider metadata to DB2.');
            }

            $missing = array_diff(array_keys($indexed_slider_meta_by_post), array_keys((array) $migrated));
            if (!empty($missing)) {
                throw new RuntimeException('Clean legacy indexed-slider DB2 migration did not confirm all posts.');
            }
        }
    }

    /**
     * @param array<int> $post_ids
     */
    private static function bulk_delete_legacy_image_source_meta(array $post_ids): void
    {
        global $wpdb;

        $post_ids = array_values(array_unique(array_filter(array_map('intval', $post_ids), static function ($post_id) {
            return $post_id > 0;
        })));

        if (empty($post_ids)) {
            return;
        }

        foreach (array_chunk($post_ids, 1000) as $chunk) {
            $placeholders = implode(',', array_fill(0, count($chunk), '%d'));

            $wpdb->query($wpdb->prepare(
                "DELETE FROM {$wpdb->postmeta}
                 WHERE post_id IN ({$placeholders})
                   AND (
                        meta_key IN ('fifu_list_url', 'fifu_list_alt', 'fifu_image_url', 'fifu_image_alt')
                     OR meta_key LIKE 'fifu_image_url\\_%'
                     OR meta_key LIKE 'fifu_image_alt\\_%'
                   )",
                $chunk
            ));
        }
    }

    /**
     * @return array<int, array<int, array{url:string,alt?:string,key_type?:string}>>
     */
    private static function get_db2_images_for_posts(array $post_ids): array {
        global $wpdb;

        $post_ids = array_values(array_unique(array_filter(array_map('intval', $post_ids))));
        if (empty($post_ids)) {
            return array();
        }

        $map_table = $wpdb->prefix . 'fifu_map';
        $key_table = $wpdb->prefix . 'fifu_key';
        $url_table = $wpdb->prefix . 'fifu_url';

        $alt_map_table = $wpdb->prefix . 'fifu_alt_map';
        $alt_table = $wpdb->prefix . 'fifu_alt';

        $has_alt_tables = self::table_exists($alt_map_table) && self::table_exists($alt_table);
        $media_by_post = array();
        $media_type_by_post = array();
        $mixed_or_unsupported_post_ids = array();

        foreach (array_chunk($post_ids, 1000) as $chunk) {
            $placeholders = implode(',', array_fill(0, count($chunk), '%d'));
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT m.post_id AS post_id, m.key_index AS media_index, k.key_type AS key_type, u.url AS url
                 FROM {$map_table} m
                 INNER JOIN {$key_table} k ON k.key_id = m.key_id
                 INNER JOIN {$url_table} u ON u.hash = m.hash
                 WHERE m.post_id IN ({$placeholders})
                   AND k.key_type IN ('image', 'slider', 'video', 'custom_video')
                   AND u.url IS NOT NULL
                   AND TRIM(u.url) <> ''
                 ORDER BY m.post_id ASC, m.key_index ASC",
                $chunk
            ), ARRAY_A);

            foreach ((array) $rows as $row) {
                $post_id = (int) ($row['post_id'] ?? 0);
                $index = (int) ($row['media_index'] ?? 0);
                $key_type = (string) ($row['key_type'] ?? '');
                $url = trim((string) ($row['url'] ?? ''));

                if ($post_id <= 0 || $url === '') {
                    continue;
                }

                if (!in_array($key_type, array('image', 'slider'), true)) {
                    $mixed_or_unsupported_post_ids[$post_id] = true;
                    continue;
                }

                if (isset($media_type_by_post[$post_id]) && $media_type_by_post[$post_id] !== $key_type) {
                    $mixed_or_unsupported_post_ids[$post_id] = true;
                    continue;
                }

                $media_type_by_post[$post_id] = $key_type;
                $media_by_post[$post_id][$index] = array(
                    'url' => $url,
                    'key_type' => $key_type,
                );
            }

            if (!$has_alt_tables) {
                continue;
            }

            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT am.post_id AS post_id, am.key_index AS media_index, k.key_type AS key_type, a.alt AS alt
                 FROM {$alt_map_table} am
                 INNER JOIN {$key_table} k ON k.key_id = am.key_id
                 INNER JOIN {$alt_table} a ON a.hash = am.hash
                 WHERE am.post_id IN ({$placeholders})
                   AND k.key_type IN ('image', 'slider')
                   AND a.alt IS NOT NULL
                   AND TRIM(a.alt) <> ''
                 ORDER BY am.post_id ASC, am.key_index ASC",
                $chunk
            ), ARRAY_A);

            foreach ((array) $rows as $row) {
                $post_id = (int) ($row['post_id'] ?? 0);
                $index = (int) ($row['media_index'] ?? 0);
                $key_type = (string) ($row['key_type'] ?? '');
                $alt = trim((string) ($row['alt'] ?? ''));

                if ($post_id <= 0 || $alt === '') {
                    continue;
                }

                if (isset($media_type_by_post[$post_id]) && $media_type_by_post[$post_id] !== $key_type) {
                    continue;
                }

                if (empty($media_by_post[$post_id][$index])) {
                    continue;
                }

                $media_by_post[$post_id][$index]['alt'] = $alt;
            }
        }

        foreach (array_keys($mixed_or_unsupported_post_ids) as $post_id) {
            unset($media_by_post[(int) $post_id]);
        }

        foreach ($media_by_post as $post_id => $media_items) {
            ksort($media_items, SORT_NUMERIC);
            if (empty($media_items[0]['url'])) {
                unset($media_by_post[$post_id]);
                continue;
            }

            foreach ($media_items as $index => $media_item) {
                $media_items[$index]['url'] = trim((string) ($media_item['url'] ?? ''));
                if ($media_items[$index]['url'] === '') {
                    unset($media_by_post[$post_id]);
                    continue 2;
                }

                if (empty($media_items[$index]['alt'])) {
                    unset($media_items[$index]['alt']);
                }
            }

            $media_by_post[$post_id] = $media_items;
        }

        return $media_by_post;
    }

    /**
     * @param array<int, int|string> $post_ids
     * @return array<int, array<int, array{url:string,alt:?string}>>
     */
    private static function get_cached_or_load_db2_images_for_posts(array $post_ids): array {
        $post_ids = array_values(array_unique(array_filter(array_map('intval', $post_ids))));
        if (empty($post_ids)) {
            return array();
        }

        $post_id_set = array_fill_keys($post_ids, true);
        if (!empty(self::$cached_db2_image_post_ids) && self::$cached_db2_image_post_ids === $post_id_set) {
            $images_by_post = self::$cached_db2_images_by_post;
            self::$cached_db2_images_by_post = array();
            self::$cached_db2_image_post_ids = array();
            return $images_by_post;
        }

        return self::get_db2_images_for_posts($post_ids);
    }

    /**
     * @param array<int, array{url:string,alt?:string,key_type?:string}> $media_items
     */
    private static function get_loaded_db2_media_type(array $media_items): string
    {
        $media_type = '';

        foreach ($media_items as $media_item) {
            if (!is_array($media_item)) {
                continue;
            }

            $item_type = (string) ($media_item['key_type'] ?? '');

            if ($item_type === '') {
                continue;
            }

            if ($media_type === '') {
                $media_type = $item_type;
                continue;
            }

            if ($media_type !== $item_type) {
                return 'mixed';
            }
        }

        return $media_type;
    }

    /**
     * @return array<int, string>
     */
    private static function get_legacy_media_input_meta_keys(): array {
        $keys = self::LEGACY_MEDIA_INPUT_META_KEYS;
        $keys[] = 'fifu_image_url_0';
        $keys[] = 'fifu_video_url_0';
        $keys[] = 'fifu_slider_image_url_0';

        return array_values(array_unique($keys));
    }

    private static function delete_db2_sent_row(int $post_id): void {
        if (class_exists('Fifu_Sent_Bridge')) {
            Fifu_Sent_Bridge::delete_post_sent_status($post_id, 'metadatapost');
        }
    }

    /**
     * @param array<int, array<int, array{url:string,alt?:string,key_type?:string,legacy_source?:string,persist_gallery?:bool}>> $images_by_post
     * @return array<int, array<int, int>>
     */
    private static function bulk_create_attachments_for_posts(array $images_by_post): array {
        global $wpdb;

        $pending_rows = array();
        $marker_to_target = array();
        $markers_by_post = array();
        $now = current_time('mysql');
        $now_gmt = current_time('mysql', true);

        foreach ($images_by_post as $post_id => $images) {
                foreach ($images as $index => $image) {
                    $url = trim((string) ($image['url'] ?? ''));
                    if ($url === '') {
                        continue;
                    }

                    $marker = 'fifu-bulk-' . md5($post_id . '|' . $index . '|' . $url . '|' . wp_generate_uuid4());
                    $markers_by_post[(int) $post_id][(int) $index] = $marker;
                    $marker_to_target[$marker] = array((int) $post_id, (int) $index);
                    $pending_rows[] = array(
                        'post_author' => self::resolve_fifu_attachment_author(),
                        'post_date' => $now,
                        'post_date_gmt' => $now_gmt,
                        'post_content' => '',
                        'post_title' => self::attachment_title_from_url($url),
                        'post_excerpt' => '',
                        'post_status' => 'inherit',
                        'comment_status' => 'closed',
                        'ping_status' => 'closed',
                        'post_password' => '',
                        'post_name' => $marker,
                        'to_ping' => '',
                        'pinged' => '',
                        'post_modified' => $now,
                        'post_modified_gmt' => $now_gmt,
                        'post_content_filtered' => $url,
                        'post_parent' => (int) $post_id,
                        'guid' => $url,
                        'menu_order' => 0,
                        'post_type' => 'attachment',
                        'post_mime_type' => self::mime_type_from_url($url),
                        'comment_count' => 0,
                    );
                }
        }

        if (empty($pending_rows)) {
            return array();
        }

        $columns = '(post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count)';
        $placeholders = array();
        $values = array();

        foreach ($pending_rows as $row) {
            $placeholders[] = '(%d,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%d,%s,%s,%d)';
            $values[] = $row['post_author'];
            $values[] = $row['post_date'];
            $values[] = $row['post_date_gmt'];
            $values[] = $row['post_content'];
            $values[] = $row['post_title'];
            $values[] = $row['post_excerpt'];
            $values[] = $row['post_status'];
            $values[] = $row['comment_status'];
            $values[] = $row['ping_status'];
            $values[] = $row['post_password'];
            $values[] = $row['post_name'];
            $values[] = $row['to_ping'];
            $values[] = $row['pinged'];
            $values[] = $row['post_modified'];
            $values[] = $row['post_modified_gmt'];
            $values[] = $row['post_content_filtered'];
            $values[] = $row['post_parent'];
            $values[] = $row['guid'];
            $values[] = $row['menu_order'];
            $values[] = $row['post_type'];
            $values[] = $row['post_mime_type'];
            $values[] = $row['comment_count'];
        }

        $sql = "INSERT INTO {$wpdb->posts} {$columns} VALUES " . implode(',', $placeholders);
        $prepared = $wpdb->prepare($sql, $values);
        if ($prepared === false) {
            throw new RuntimeException('Failed to prepare bulk attachment insert.');
        }

        $inserted = $wpdb->query($prepared);
        if ($inserted === false) {
            throw new RuntimeException('Failed to bulk insert attachments.');
        }

        $markers = array_keys($marker_to_target);
        $placeholders = implode(',', array_fill(0, count($markers), '%s'));
        $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT ID, post_name FROM {$wpdb->posts} WHERE post_type = %s AND post_name IN ({$placeholders})",
                array_merge(array('attachment'), $markers)
            ), ARRAY_A);

        $id_by_marker = array();
        foreach ((array) $rows as $row) {
            $id_by_marker[(string) $row['post_name']] = (int) $row['ID'];
        }

        $attachments_by_post = array();
        foreach ($marker_to_target as $marker => $target) {
                if (empty($id_by_marker[$marker])) {
                    throw new RuntimeException('Failed to resolve attachment ID for marker ' . $marker);
                }

                [$post_id, $index] = $target;
                $attachments_by_post[$post_id][$index] = $id_by_marker[$marker];
        }

        foreach ($attachments_by_post as $post_id => $attachments) {
            ksort($attachments, SORT_NUMERIC);
            $attachments_by_post[$post_id] = $attachments;
        }

        return $attachments_by_post;
    }

    /**
     * @param array<int, array<int, int>> $attachments_by_post
     * @param array<int, array<int, array{url:string,alt:?string}>> $images_by_post
     */
    private static function bulk_persist_metadata(array $attachments_by_post, array $images_by_post, array $post_types_by_id): void {
        global $wpdb;

        $rows = array();
        $thumbnail_count = 0;
        $gallery_count = 0;
        foreach ($images_by_post as $post_id => $images) {
                if (empty($attachments_by_post[$post_id][0])) {
                    throw new RuntimeException('Missing featured attachment for post ' . (int) $post_id);
                }

                $post_type = $post_types_by_id[(int) $post_id] ?? '';
                if ($post_type === '') {
                    $resolved_post_type = get_post_type((int) $post_id);
                    if (is_string($resolved_post_type) && $resolved_post_type !== '') {
                        $post_type = $resolved_post_type;
                    }
                }
                if ($post_type === 'post' && count($images) > 1) {
                    $media_type = self::get_loaded_db2_media_type((array) $images);

                    if ($media_type !== 'slider') {
                        throw new RuntimeException('Normal post bulk sync received gallery images.');
                    }
                }

                $attachments = $attachments_by_post[$post_id];
                ksort($attachments, SORT_NUMERIC);

                $rows[] = array((int) $post_id, '_thumbnail_id', (string) (int) $attachments[0]);
                $thumbnail_count++;

                $gallery_ids = array();
                foreach ($images as $index => $image) {
                    if (!isset($attachments[(int) $index])) {
                        throw new RuntimeException('Missing attachment for post ' . (int) $post_id . ' index ' . (int) $index);
                    }

                    $attachment_id = (int) $attachments[(int) $index];
                    $rows[] = array($attachment_id, '_wp_attached_file', trim((string) $image['url']));

                    $alt = isset($image['alt']) ? trim((string) $image['alt']) : '';
                    if ($alt !== '') {
                        $rows[] = array($attachment_id, '_wp_attachment_image_alt', $alt);
                    }

                    if ((int) $index > 0) {
                        $gallery_ids[] = $attachment_id;
                        $gallery_count++;
                    }
                }

                $should_persist_parent_gallery = $post_type === 'product';
                if (!$should_persist_parent_gallery && !empty($gallery_ids)) {
                    foreach ($images as $image) {
                        if (!empty($image['persist_gallery'])) {
                            $should_persist_parent_gallery = true;
                            break;
                        }
                    }
                }

                if ($should_persist_parent_gallery && !empty($gallery_ids)) {
                    $rows[] = array((int) $post_id, '_product_image_gallery', implode(',', $gallery_ids));
                }
        }

        if (empty($rows)) {
            return;
        }

        $chunk_size = 500;
        foreach (array_chunk($rows, $chunk_size) as $chunk) {
            $placeholders = array();
            $values = array();

            foreach ($chunk as $row) {
                $placeholders[] = '(%d,%s,%s)';
                $values[] = $row[0];
                $values[] = $row[1];
                $values[] = $row[2];
            }

            $sql = "INSERT INTO {$wpdb->postmeta} (post_id, meta_key, meta_value) VALUES " . implode(',', $placeholders);
            $prepared = $wpdb->prepare($sql, $values);
            if ($prepared === false) {
                throw new RuntimeException('Failed to prepare bulk postmeta insert.');
            }

            $inserted = $wpdb->query($prepared);
            if ($inserted === false) {
                throw new RuntimeException('Failed to bulk insert postmeta.');
            }
        }

        $post_ids = array_keys($attachments_by_post);
        self::bulk_delete_metadatapost_sent_state($post_ids);

        foreach (array_keys($attachments_by_post) as $post_id) {
            wp_cache_delete((int) $post_id, 'post_meta');
        }
    }

    /**
     * @param array<int, int|string> $post_ids
     */
    private static function bulk_delete_metadatapost_sent_state(array $post_ids): void {
        global $wpdb;

        $post_ids = array_values(array_unique(array_filter(array_map('intval', $post_ids))));
        if (empty($post_ids)) {
            return;
        }

        $sent_table = $wpdb->prefix . 'fifu_sent';
        $event_table = $wpdb->prefix . 'fifu_sent_event';
        $postmeta_table = $wpdb->postmeta;

        foreach (array_chunk($post_ids, 1000) as $chunk) {
            $placeholders = implode(',', array_fill(0, count($chunk), '%d'));

            $sql = "
                DELETE s
                FROM {$sent_table} s
                INNER JOIN {$event_table} e ON e.id = s.event_id
                WHERE s.object_type = 'post'
                  AND e.event_key = 'metadatapost'
                  AND s.object_id IN ({$placeholders})
            ";
            $prepared = $wpdb->prepare($sql, $chunk);
            if ($prepared === false) {
                throw new RuntimeException('Failed to prepare bulk sent-state delete.');
            }
            $deleted = $wpdb->query($prepared);
            if ($deleted === false) {
                throw new RuntimeException('Failed to bulk delete DB2 sent-state rows.');
            }

            $meta_sql = "
                DELETE FROM {$postmeta_table}
                WHERE meta_key = 'fifu_metadatapost_sent'
                  AND post_id IN ({$placeholders})
            ";
            $meta_prepared = $wpdb->prepare($meta_sql, $chunk);
            if ($meta_prepared === false) {
                throw new RuntimeException('Failed to prepare bulk legacy sent-state delete.');
            }
            $meta_deleted = $wpdb->query($meta_prepared);
            if ($meta_deleted === false) {
                throw new RuntimeException('Failed to bulk delete legacy sent-state rows.');
            }
        }
    }

    private static function attachment_title_from_url(string $url): string {
        $path = (string) parse_url($url, PHP_URL_PATH);
        $basename = basename($path);

        if ($basename === '' || $basename === '.' || $basename === '/') {
            return 'FIFU Remote Image';
        }

        return sanitize_text_field($basename);
    }

    private static function mime_type_from_url(string $url): string {
        $path = (string) parse_url($url, PHP_URL_PATH);
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));

        switch ($ext) {
            case 'png':
                return 'image/png';
            case 'gif':
                return 'image/gif';
            case 'webp':
                return 'image/webp';
            case 'avif':
                return 'image/avif';
            case 'svg':
                return 'image/svg+xml';
            case 'jpg':
            case 'jpeg':
            default:
                return 'image/jpeg';
        }
    }

    private static function resolve_fifu_attachment_author(): int {
        if (function_exists('fifu_get_author')) {
            $author = (int) fifu_get_author();
            if ($author > 0) {
                return $author;
            }
        }

        if (class_exists('Fifu_Attachment_Factory') && method_exists('Fifu_Attachment_Factory', 'get_author_id')) {
            $author = (int) Fifu_Attachment_Factory::get_author_id();
            if ($author > 0) {
                return $author;
            }
        }

        if (defined('FIFU_ATTACHMENT_AUTHOR')) {
            $author = (int) FIFU_ATTACHMENT_AUTHOR;
            if ($author > 0) {
                return $author;
            }
        }

        if (defined('FIFU_FAKE_ATTACHMENT_AUTHOR')) {
            $author = (int) FIFU_FAKE_ATTACHMENT_AUTHOR;
            if ($author > 0) {
                return $author;
            }
        }

        if (defined('FIFU_AUTHOR')) {
            $author = (int) FIFU_AUTHOR;
            if ($author > 0) {
                return $author;
            }
        }

        return 7777777777;
    }

    /**
     * @param array<int, array<int, int>> $attachments_by_post
     */
    private static function rollback_created_attachments(array $attachments_by_post): void {
        foreach ($attachments_by_post as $attachments_by_index) {
            foreach ($attachments_by_index as $attachment_id) {
                $attachment_id = (int) $attachment_id;
                if ($attachment_id > 0) {
                    $repository = new Fifu_Attachment_Repository();
                    if (
                        $repository->is_fifu_attachment($attachment_id)
                        && !$repository->get_referenced_attachment_ids([$attachment_id])
                    ) {
                        (new Fifu_Local_Media_Cleanup())->delete_attachments_and_meta([$attachment_id]);
                    }
                }
            }
        }
    }

    private static function table_exists(string $table): bool {
        global $wpdb;

        $found = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));

        return $found === $table;
    }
}
