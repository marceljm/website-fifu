<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Read service for image lists, preferring db2 data.
 */
final class Fifu_Post_Image_List_Url_Read_Service
{
    /**
     * Returns the serialized image URL list, preferring db2 data before falling back to legacy postmeta.
     *
     * @param int $postId
     * @return string|null
     */
    public static function get_image_list_url(int $postId): ?string
    {
        if (function_exists('fifu_db2_manager')) {
            $manager = fifu_db2_manager();
            if ($manager instanceof Fifu_Db2_Manager) {
                $rows = $manager->getPostMappings($postId, 'image');
                if (is_array($rows) && !empty($rows)) {
                    usort(
                        $rows,
                        static fn(array $a, array $b): int =>
                            ((int) ($a['key_index'] ?? 0)) <=> ((int) ($b['key_index'] ?? 0))
                    );

                    $urls = [];

                    foreach ($rows as $row) {
                        $url = trim((string) ($row['url'] ?? ''));
                        if ($url === '') {
                            continue;
                        }

                        $urls[] = $url;
                    }

                    if (!empty($urls)) {
                        return implode('|', $urls);
                    }
                }
            }
        }

        return self::get_legacy_image_list_url($postId);
    }

    /**
     * @param mixed $value
     */
    private static function normalize_legacy_meta_value($value): string
    {
        if (is_array($value)) {
            $value = reset($value);
        }

        return trim((string) $value);
    }

    private static function get_legacy_image_list_url(int $postId): ?string
    {
        $meta = get_post_meta($postId);
        if (!is_array($meta)) {
            return null;
        }

        $urls = [];
        $indexed = [];

        if (array_key_exists('fifu_list_url', $meta)) {
            $legacyList = rtrim(self::normalize_legacy_meta_value($meta['fifu_list_url']), '|');
            return $legacyList === '' ? null : $legacyList;
        }

        foreach ($meta as $key => $value) {
            if (!is_string($key)) {
                continue;
            }

            if (preg_match('/^fifu_image_url_(\d+)$/', $key, $matches) !== 1) {
                continue;
            }

            $url = self::normalize_legacy_meta_value($value);
            if ($url === '') {
                continue;
            }

            $indexed[(int) $matches[1]] = $url;
        }

        if (empty($indexed)) {
            return null;
        }

        ksort($indexed, SORT_NUMERIC);

        if (array_key_exists('fifu_image_url', $meta)) {
            $featured = self::normalize_legacy_meta_value($meta['fifu_image_url']);
            if ($featured !== '') {
                $urls[] = $featured;
            }
        }

        foreach ($indexed as $url) {
            $urls[] = $url;
        }

        return $urls ? implode('|', $urls) : null;
    }
}
