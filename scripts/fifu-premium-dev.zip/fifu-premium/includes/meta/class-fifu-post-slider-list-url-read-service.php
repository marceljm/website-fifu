<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Read service for slider URL lists stored in db2.
 */
final class Fifu_Post_Slider_List_Url_Read_Service
{
    /**
     * Returns the slider URL list for a post, preferring db2 data with a legacy fallback.
     *
     * @param int $postId
     * @return string|null
     */
    public static function get_slider_list_url(int $postId): ?string
    {
        if (function_exists('fifu_db2_manager')) {
            $manager = fifu_db2_manager();
            if ($manager instanceof Fifu_Db2_Manager) {
                $mappings = $manager->getPostMappings($postId, 'slider');
                $urls = self::extract_slider_urls_from_db2_mappings($mappings);
                if ($urls) {
                    return implode('|', $urls);
                }
            }
        }

        $indexedLegacy = self::reconstruct_indexed_legacy_slider_list_url($postId);
        if ($indexedLegacy !== null) {
            return $indexedLegacy;
        }

        $legacy = self::normalize_slider_list_url(get_post_meta($postId, 'fifu_slider_list_url', true));
        if ($legacy !== null) {
            return $legacy;
        }

        return null;
    }

    /**
     * Returns indexed legacy slider URLs as a normalized ordered list.
     *
     * @param int $postId
     * @return array<int, string>
     */
    public static function get_indexed_legacy_slider_urls(int $postId): array
    {
        $meta = self::get_all_post_meta_for_slider_reconstruction($postId);
        if (!is_array($meta) || !$meta) {
            return [];
        }

        $indexed = [];
        foreach ($meta as $metaKey => $value) {
            if (!is_string($metaKey)) {
                continue;
            }

            if (preg_match('/^fifu_slider_image_url_(\d+)$/', $metaKey, $matches) !== 1) {
                continue;
            }

            $index = (int) $matches[1];
            if ($index < 0) {
                continue;
            }

            $url = self::normalize_single_slider_url($value);
            if ($url === null) {
                continue;
            }

            $indexed[$index] = $url;
        }

        if (!$indexed) {
            return [];
        }

        ksort($indexed);
        return array_values($indexed);
    }

    /**
     * Extract a normalized list of DB2 slider URLs ordered by key index.
     *
     * @param mixed $mappings
     * @return array<int, string>
     */
    private static function extract_slider_urls_from_db2_mappings($mappings): array
    {
        if (!is_array($mappings) || !$mappings) {
            return [];
        }

        usort(
            $mappings,
            static function ($a, $b): int {
                $aIndex = is_array($a) ? (int) ($a['key_index'] ?? 0) : 0;
                $bIndex = is_array($b) ? (int) ($b['key_index'] ?? 0) : 0;
                return $aIndex <=> $bIndex;
            }
        );

        $urls = [];
        foreach ($mappings as $mapping) {
            if (!is_array($mapping)) {
                continue;
            }

            $mappingUrl = self::normalize_single_slider_url($mapping['url'] ?? null);
            if ($mappingUrl === null) {
                continue;
            }

            $urls[] = $mappingUrl;
        }

        return $urls;
    }

    /**
     * Rebuild the slider list from indexed legacy meta keys.
     */
    private static function reconstruct_indexed_legacy_slider_list_url(int $postId): ?string
    {
        $indexed = self::get_indexed_legacy_slider_urls($postId);
        if (!$indexed) {
            return null;
        }

        return implode('|', $indexed);
    }

    /**
     * Returns all post meta values available for slider reconstruction.
     *
     * In tests, prefer the in-memory meta store to avoid adding extra get_post_meta() calls.
     *
     * @return array<string, mixed>
     */
    private static function get_all_post_meta_for_slider_reconstruction(int $postId): array
    {
        $meta = get_post_meta($postId);
        if (!is_array($meta) || !$meta) {
            return [];
        }

        $normalized = [];
        foreach ($meta as $metaKey => $metaValue) {
            if (!is_string($metaKey)) {
                continue;
            }

            if (is_array($metaValue)) {
                $firstValue = null;
                foreach ($metaValue as $candidate) {
                    if (is_scalar($candidate) || $candidate === null) {
                        $firstValue = $candidate;
                        break;
                    }
                }

                $normalized[$metaKey] = $firstValue;
                continue;
            }

            $normalized[$metaKey] = $metaValue;
        }

        return $normalized;
    }

    /**
     * Normalize a single slider URL value.
     *
     * @param mixed $value
     */
    private static function normalize_single_slider_url($value): ?string
    {
        if (is_array($value)) {
            foreach ($value as $candidate) {
                $normalized = self::normalize_single_slider_url($candidate);
                if ($normalized !== null) {
                    return $normalized;
                }
            }

            return null;
        }

        if (!is_scalar($value) && $value !== null) {
            return null;
        }

        $value = trim((string) $value);
        if ($value === '' || preg_match('/^(null|undefined)$/i', $value) === 1) {
            return null;
        }

        return $value === '' ? null : $value;
    }

    /**
     * Normalize a legacy pipe-separated slider list.
     *
     * @param mixed $value
     */
    private static function normalize_slider_list_url($value): ?string
    {
        $value = self::normalize_single_slider_url($value);
        if ($value === null) {
            return null;
        }

        $segments = preg_split('/\s*\|\s*/', rtrim($value, '|')) ?: [];
        $urls = [];

        foreach ($segments as $segment) {
            $url = self::normalize_single_slider_url($segment);
            if ($url !== null) {
                $urls[] = $url;
            }
        }

        return $urls ? implode('|', $urls) : null;
    }

    /**
     * Returns the list fallback split into trimmed URLs.
     *
     * @param int $postId
     * @return array<int, string>
     */
    public static function get_slider_list_urls(int $postId): array
    {
        $list = self::get_slider_list_url($postId);
        if ($list === null) {
            return [];
        }

        $urls = array_map('trim', preg_split('/\s*\|\s*/', $list) ?: []);
        $urls = array_values(array_filter($urls, static fn($url): bool => $url !== ''));

        return $urls;
    }

    /**
     * Returns the legacy pipe-separated slider list without DB2 lookup.
     *
     * @param int $postId
     * @return array<int, string>
     */
    public static function get_legacy_slider_list_urls(int $postId): array
    {
        $legacy = self::normalize_slider_list_url(get_post_meta($postId, 'fifu_slider_list_url', true));
        if ($legacy === null) {
            return [];
        }

        $urls = array_map('trim', preg_split('/\s*\|\s*/', $legacy) ?: []);
        return array_values(array_filter($urls, static fn($url): bool => $url !== ''));
    }
}
