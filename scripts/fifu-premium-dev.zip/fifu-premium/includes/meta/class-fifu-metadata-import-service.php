<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/class-fifu-attachment-factory.php';
require_once __DIR__ . '/class-fifu-legacy-meta-repository.php';
require_once __DIR__ . '/class-fifu-metadata-db2-cleanup-guard.php';
require_once __DIR__ . '/class-fifu-metadata-queue-repository.php';

final class Fifu_Metadata_Import_Service {

    /**
     * Insert metadata queue payloads one row at a time and return the exact
     * queue IDs created by this invocation.
     *
     * @param string       $table
     * @param string       $type
     * @param array<mixed> $postIdGroups
     *
     * @return int[]
     */
    private static function insert_metadata_queue_groups(
        string $table,
        string $type,
        array $postIdGroups
    ): array {
        $wpdb = self::get_wpdb();
        $queueRepository = self::get_metadata_queue_repository();
        $queueIds = [];

        foreach ($postIdGroups as $postIds) {
            $postIds = trim((string) $postIds);

            if ($postIds === '') {
                continue;
            }

            $inserted = $wpdb->insert(
                $table,
                [
                    'post_ids' => $postIds,
                    'type' => $type,
                ],
                [
                    '%s',
                    '%s',
                ]
            );

            if ($inserted === false) {
                throw new RuntimeException(
                    sprintf(
                        'Failed to insert metadata queue row for type "%s".',
                        $type
                    )
                );
            }

            $queueId = (int) $wpdb->insert_id;

            if ($queueId <= 0) {
                throw new RuntimeException(
                    sprintf(
                        'Metadata queue insert for type "%s" returned no valid ID.',
                        $type
                    )
                );
            }

            $queueIds[] = $queueId;
            $queueRepository->log_prepare($queueId, $table);
        }

        return $queueIds;
    }

    /**
     * Queue metadata records that should be restored for posts or categories.
     *
     * This method prepares the incoming metadata queue by enqueuing the provided IDs,
     * allowing the import pipeline to later hydrate the correct post or term meta records.
     *
     * @param string $postIdsCsv Comma separated list of IDs that require metadata restoration.
     * @param bool   $isCategory Whether the IDs belong to categories/terms instead of posts.
     *
     * @return array{post:int[],woo:int[],term:int[]}
     */
    public static function prepare_meta_in_queue(
        string $postIdsCsv,
        bool $isCategory
    ): array {
        $wpdb = self::get_wpdb();
        $metaInTable = $wpdb->prefix . 'fifu_meta_in';
        $postsTable = $wpdb->posts;
        $postmetaTable = $wpdb->postmeta;
        $termmetaTable = $wpdb->termmeta;
        $mapTable = $wpdb->prefix . 'fifu_map';
        $keyTable = $wpdb->prefix . 'fifu_key';
        $urlTable = $wpdb->prefix . 'fifu_url';
        $authorId = (int) Fifu_Options_Utils::get_author();

        $wpdb->query("SET SESSION group_concat_max_len = 1048576;");

        $importIds = $postIdsCsv ? "a.post_id IN ({$postIdsCsv}) AND" : "";
        $queueIds = [
            'post' => [],
            'woo' => [],
            'term' => [],
        ];
        $useDb2Meta = self::can_use_db2_post_meta($wpdb, $mapTable, $keyTable, $urlTable);

        if (!$postIdsCsv || ($importIds && !$isCategory)) {
            $wpdb->query("
                CREATE TEMPORARY TABLE temp_post_in (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    post_id INT
                );
            ");
            $wpdb->query("
                INSERT INTO temp_post_in (post_id)
                SELECT DISTINCT a.post_id
                FROM {$postmetaTable} AS a
                WHERE {$importIds}
                a.meta_key IN ('fifu_image_url', 'fifu_video_url', 'fifu_slider_image_url_0')
                AND a.meta_value IS NOT NULL
                AND a.meta_value <> ''
                AND NOT EXISTS (
                    SELECT 1 
                    FROM {$postmetaTable} AS b
                    WHERE a.post_id = b.post_id
                    AND b.meta_key = '_thumbnail_id'
                    AND b.meta_value <> 0
                )
                ORDER BY a.post_id;
            ");

            if ($useDb2Meta) {
                $db2ImportIds = $postIdsCsv ? "m.post_id IN ({$postIdsCsv}) AND" : '';
                $wpdb->query("
                    INSERT IGNORE INTO temp_post_in (post_id)
                    SELECT DISTINCT m.post_id
                    FROM {$mapTable} AS m
                    INNER JOIN {$keyTable} AS k ON k.key_id = m.key_id
                    INNER JOIN {$urlTable} AS u ON u.hash = m.hash
                    WHERE {$db2ImportIds}
                    k.key_type IN ('image', 'video', 'slider')
                    AND m.key_index = 0
                    AND u.url IS NOT NULL
                    AND u.url <> ''
                    AND NOT EXISTS (
                        SELECT 1
                        FROM {$postmetaTable} AS b
                        WHERE m.post_id = b.post_id
                        AND b.meta_key = '_thumbnail_id'
                        AND b.meta_value <> 0
                    )
                    ORDER BY m.post_id;
                ");
            }

            $postGroups = $wpdb->get_col("
                SELECT GROUP_CONCAT(
                    post_id ORDER BY post_id SEPARATOR ','
                )
                FROM temp_post_in
                GROUP BY FLOOR((id - 1) / 5000)
            ");

            $queueIds['post'] = self::insert_metadata_queue_groups(
                $metaInTable,
                'post',
                is_array($postGroups) ? $postGroups : []
            );

            $wpdb->query("DROP TEMPORARY TABLE temp_post_in;");

            $wpdb->query("
                CREATE TEMPORARY TABLE temp_woo_in (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    post_id INT
                );
            ");

            $wpdb->query("
                INSERT INTO temp_woo_in (post_id)
                SELECT a.post_id
                FROM {$postmetaTable} AS a
                WHERE {$importIds}
                (
                    a.meta_key LIKE 'fifu_image_url_%'
                    OR a.meta_key LIKE 'fifu_video_url_%'
                    OR a.meta_key LIKE 'fifu_slider_image_url_%'
                )
                AND a.meta_value IS NOT NULL
                AND a.meta_value <> ''
                GROUP BY a.post_id
                HAVING COUNT(*) > (
                    SELECT COUNT(DISTINCT p.id)
                    FROM {$postsTable} p
                    WHERE p.post_parent = a.post_id
                      AND p.post_type = 'attachment'
                      AND p.post_author = {$authorId}
                      AND NOT EXISTS (
                          SELECT 1
                          FROM {$postmetaTable} pm_thumb
                          WHERE pm_thumb.post_id = a.post_id
                            AND pm_thumb.meta_key = '_thumbnail_id'
                            AND CAST(pm_thumb.meta_value AS UNSIGNED) = p.id
                      )
                )
                ORDER BY a.post_id
            ");

            if ($useDb2Meta) {
                $db2ImportIds = $postIdsCsv ? "m.post_id IN ({$postIdsCsv}) AND" : '';
                $wpdb->query("
                    INSERT IGNORE INTO temp_woo_in (post_id)
                    SELECT m.post_id
                    FROM {$mapTable} AS m
                    INNER JOIN {$keyTable} AS k ON k.key_id = m.key_id
                    INNER JOIN {$urlTable} AS u ON u.hash = m.hash
                    WHERE {$db2ImportIds}
                    k.key_type IN ('image', 'video', 'slider')
                    AND m.key_index > 0
                    AND u.url IS NOT NULL
                    AND u.url <> ''
                    GROUP BY m.post_id
                    HAVING COUNT(*) > (
                        SELECT COUNT(DISTINCT p.id)
                        FROM {$postsTable} p
                        WHERE p.post_parent = m.post_id
                          AND p.post_type = 'attachment'
                          AND p.post_author = {$authorId}
                          AND NOT EXISTS (
                              SELECT 1
                              FROM {$postmetaTable} pm_thumb
                              WHERE pm_thumb.post_id = m.post_id
                                AND pm_thumb.meta_key = '_thumbnail_id'
                                AND CAST(pm_thumb.meta_value AS UNSIGNED) = p.id
                          )
                    )
                    ORDER BY m.post_id
                ");
            }

            $wooGroups = $wpdb->get_col("
                SELECT GROUP_CONCAT(
                    post_id ORDER BY post_id SEPARATOR ','
                )
                FROM temp_woo_in
                GROUP BY FLOOR((id - 1) / 2500)
            ");

            $queueIds['woo'] = self::insert_metadata_queue_groups(
                $metaInTable,
                'woo',
                is_array($wooGroups) ? $wooGroups : []
            );

            $wpdb->query("DROP TEMPORARY TABLE temp_woo_in;");
        }

        $importIds = $postIdsCsv ? "a.term_id IN ({$postIdsCsv}) AND" : "";

        $sentTable = $wpdb->prefix . 'fifu_sent';
        $sentEventTable = $wpdb->prefix . 'fifu_sent_event';

        $useDb2Sent = false;
        if (function_exists('fifu_db2_mode')) {
            $mode = fifu_db2_mode();
            if ($mode === Fifu_Db2_Mode::MODE_DB2 || $mode === Fifu_Db2_Mode::MODE_HYBRID) {
                if (self::table_exists($wpdb, $sentTable) && self::table_exists($wpdb, $sentEventTable)) {
                    $useDb2Sent = true;
                }
            }
        }

        if (!$postIdsCsv || ($importIds && $isCategory)) {
            $wpdb->query("
                CREATE TEMPORARY TABLE temp_term_in (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    term_id INT
                );
            ");
            $wpdb->query("
                INSERT INTO temp_term_in (term_id)
                SELECT DISTINCT a.term_id
                FROM {$termmetaTable} AS a
                WHERE {$importIds}
                a.meta_key IN ('fifu_image_url', 'fifu_video_url')
                AND a.meta_value IS NOT NULL
                AND a.meta_value <> ''
                AND NOT EXISTS (
                    SELECT 1 
                    FROM {$termmetaTable} AS b
                    WHERE a.term_id = b.term_id 
                    AND (
                        (b.meta_key = 'thumbnail_id' AND b.meta_value <> 0)
                        OR b.meta_key IN ('fifu_metadataterm_sent')
                    )
                )
                " . ($useDb2Sent ? "
                AND NOT EXISTS (
                    SELECT 1
                    FROM {$sentTable} s
                    INNER JOIN {$sentEventTable} e ON e.id = s.event_id
                    WHERE s.object_type = 'term'
                      AND s.object_id = a.term_id
                      AND e.event_key = 'metadataterm'
                      AND s.sent = 1
                )
                " : "") . "
                ORDER BY a.term_id;
            ");

            $termMapTable = $wpdb->prefix . 'fifu_term_map';
            if (self::table_exists($wpdb, $termMapTable)) {
                $db2ImportIds = $postIdsCsv ? "tm.term_id IN ({$postIdsCsv}) AND" : '';

                $wpdb->query("
                    INSERT IGNORE INTO temp_term_in (term_id)
                    SELECT DISTINCT tm.term_id
                    FROM {$termMapTable} AS tm
                    INNER JOIN {$keyTable} AS k ON k.key_id = tm.key_id
                    INNER JOIN {$urlTable} AS u ON u.hash = tm.hash
                    WHERE {$db2ImportIds}
                    k.key_type IN ('image', 'video')
                    AND u.url IS NOT NULL
                    AND u.url <> ''
                    AND NOT EXISTS (
                        SELECT 1
                        FROM {$termmetaTable} AS b
                        WHERE b.term_id = tm.term_id
                        AND (
                            (b.meta_key = 'thumbnail_id' AND b.meta_value IS NOT NULL AND b.meta_value <> '' AND b.meta_value <> '0')
                            OR b.meta_key IN ('fifu_metadataterm_sent')
                        )
                    )
                    ORDER BY tm.term_id;
                ");
            }

            $termGroups = $wpdb->get_col("
                SELECT GROUP_CONCAT(
                    term_id ORDER BY term_id SEPARATOR ','
                )
                FROM temp_term_in
                GROUP BY FLOOR((id - 1) / 5000)
            ");

            $queueIds['term'] = self::insert_metadata_queue_groups(
                $metaInTable,
                'term',
                is_array($termGroups) ? $termGroups : []
            );

            $wpdb->query("DROP TEMPORARY TABLE temp_term_in;");
        }

        return $queueIds;
    }

    /**
     * Queue metadata records that should be cleaned for posts or categories.
     *
     * The queued IDs are used later to remove obsolete metadata and attachments
     * with the appropriate handling for posts versus term records.
     *
     * @param string $postIdsCsv Comma separated list of IDs that require metadata cleanup.
     * @param bool   $isCategory Whether the IDs belong to categories/terms instead of posts.
     *
     * @return array{att:int[],woo:int[],term:int[]}
     */
    public static function prepare_meta_out_queue(
        string $postIdsCsv,
        bool $isCategory
    ): array {
        $wpdb = self::get_wpdb();
        $metaOutTable = $wpdb->prefix . 'fifu_meta_out';
        $postsTable = $wpdb->posts;
        $postmetaTable = $wpdb->postmeta;

        $wpdb->query("SET SESSION group_concat_max_len = 1048576;");

        $importIds = $postIdsCsv ? "post_parent IN ({$postIdsCsv}) AND" : "";
        $categoryClause = $isCategory ? "post_name LIKE 'fifu-category%' AND" : "";

        $queueIds = [
            'att' => [],
            'woo' => [],
            'term' => [],
        ];

        $attachmentGroups = $wpdb->get_col(
            $wpdb->prepare(
                "
                SELECT GROUP_CONCAT(
                    DISTINCT id ORDER BY id SEPARATOR ','
                )
                FROM {$postsTable}
                WHERE {$importIds}
                {$categoryClause}
                post_author = %d
                GROUP BY FLOOR(id / 5000)
                ",
                (int) Fifu_Options_Utils::get_author()
            )
        );

        $queueIds['att'] = self::insert_metadata_queue_groups(
            $metaOutTable,
            'att',
            is_array($attachmentGroups) ? $attachmentGroups : []
        );

        $importIds = $postIdsCsv ? "post_id IN ({$postIdsCsv}) AND" : "";

        if (!$postIdsCsv || ($importIds && !$isCategory)) {
            $wpdb->query("
                CREATE TEMPORARY TABLE temp_woo_out (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    post_id BIGINT UNSIGNED NOT NULL,
                    UNIQUE KEY uniq_post_id (post_id)
                ) ENGINE=InnoDB;
            ");

            $wpdb->query("
                INSERT IGNORE INTO temp_woo_out (post_id)
                SELECT DISTINCT post_id
                FROM {$postmetaTable}
                WHERE {$importIds}
                meta_key IN ('_product_image_gallery', '_wc_additional_variation_images')
                AND meta_value IS NOT NULL
                AND meta_value <> ''
                ORDER BY post_id;
            ");

            $wpdb->query("
                INSERT IGNORE INTO temp_woo_out (post_id)
                SELECT DISTINCT post_id
                FROM {$postmetaTable}
                WHERE {$importIds}
                (
                    meta_key LIKE 'fifu_image_url_%' 
                    OR meta_key LIKE 'fifu_video_url_%'
                    OR meta_key LIKE 'fifu_slider_image_url_%'
                )
                ORDER BY post_id;
            ");

            $wooGroups = $wpdb->get_col("
                SELECT GROUP_CONCAT(
                    post_id ORDER BY post_id SEPARATOR ','
                )
                FROM temp_woo_out
                GROUP BY FLOOR((id - 1) / 5000)
            ");

            $queueIds['woo'] = self::insert_metadata_queue_groups(
                $metaOutTable,
                'woo',
                is_array($wooGroups) ? $wooGroups : []
            );

            $wpdb->query("DROP TEMPORARY TABLE temp_woo_out;");
        }

        $importIds = $postIdsCsv ? "term_id IN ({$postIdsCsv}) AND" : "";

        if (!$postIdsCsv || ($importIds && $isCategory)) {
            $wpdb->query("
                CREATE TEMPORARY TABLE temp_term_out (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    term_id INT
                );
            ");

            $wpdb->query("
                INSERT INTO temp_term_out (term_id)
                SELECT DISTINCT term_id
                FROM {$wpdb->termmeta}
                WHERE {$importIds}
                meta_key IN ('fifu_image_url', 'fifu_video_url')
                AND meta_value IS NOT NULL
                AND meta_value <> ''
                ORDER BY term_id;
            ");

            $termGroups = $wpdb->get_col("
                SELECT GROUP_CONCAT(
                    term_id ORDER BY term_id SEPARATOR ','
                )
                FROM temp_term_out
                GROUP BY FLOOR((id - 1) / 5000)
            ");

            $queueIds['term'] = self::insert_metadata_queue_groups(
                $metaOutTable,
                'term',
                is_array($termGroups) ? $termGroups : []
            );

            $wpdb->query("DROP TEMPORARY TABLE temp_term_out;");
        }

        return $queueIds;
    }

    /**
     * Process a single metadata in row for a post.
     *
     * Restores attachment and metadata entries for the queue item identified by the given ID.
     *
     * @param int $queueId Identifier of the metadata in queue row to process.
     *
     * @return bool True if the row was successfully processed, false otherwise.
     */
    public static function process_post_meta_in_row(int $queueId): bool {
        $wpdb = self::get_wpdb();
        $metaInTable = $wpdb->prefix . 'fifu_meta_in';

        $result = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT post_ids FROM {$metaInTable} WHERE id = %d",
                $queueId
            )
        );

        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$metaInTable} WHERE id = %d",
                $queueId
            )
        );

        Fifu_File_Logger::plugin(['insert_postmeta' => ['id' => $queueId]]);

        if (count($result) === 0) {
            return false;
        }

        $ids = $result[0]->post_ids;
        $postIds = explode(',', $ids);
        $legacyRepository = self::get_legacy_meta_repository();
        $metaData = $legacyRepository->get_fifu_fields_for_posts($postIds);
        $legacyMetaData = $legacyRepository->get_legacy_fifu_fields_for_posts($postIds);
        $legacyMetaDataToMigrate = self::filter_non_empty_legacy_rows($legacyMetaData);

        if (!self::has_any_non_empty_legacy_rows($metaData)) {
            self::decrement_metadata_counter(self::count_queue_ids($postIds));

            return true;
        }

        $attachmentFactory = new Fifu_Attachment_Factory();
        $valueArr = [];
        $existingThumbnailPostIds = self::get_existing_thumbnail_post_id_map($postIds);
        foreach ($postIds as $postId) {
            $intPostId = (int) $postId;

            if ($intPostId <= 0) {
                continue;
            }

            if (isset($existingThumbnailPostIds[$intPostId])) {
                continue;
            }

            $postMeta = $metaData[$intPostId] ?? [];
            if (!is_array($postMeta)) {
                continue;
            }

            $url = self::resolve_image_metadata_attachment_url_from_prefetched_meta($postMeta);
            if ($url === null) {
                continue;
            }

            $alt = $postMeta['fifu_image_alt'] ?? null;
            $valueArr[] = $attachmentFactory->build_insert_tuple($url, is_string($alt) ? $alt : null, $intPostId);
        }

        if (!$valueArr) {
            self::decrement_metadata_counter(self::count_queue_ids($postIds));

            return true;
        }

        $value = implode(',', $valueArr);
        wp_cache_flush();
        $service = self::get_speed_up_service();
        if ($service instanceof Fifu_Db2_Speed_Up_Service) {
            $service->restore_post_attachment_meta($value, $ids);
            if ($legacyMetaDataToMigrate) {
                $legacyMetaDataRemaining = $legacyMetaDataToMigrate;
                $indexedSliderBulkPayload = self::load_indexed_slider_bulk_migration_meta_map_for_post_ids(
                    array_keys($legacyMetaDataRemaining)
                );

                $bulkMigratedPostIds = self::migrate_simple_post_image_legacy_meta_to_db2_bulk($legacyMetaDataToMigrate);

                if ($bulkMigratedPostIds === false) {
                    /*
                     * Safety first:
                     * the bulk helper already rolled back and preserved legacy.
                     * Do not fall back to the old per-post path after a bulk transactional failure,
                     * because that could re-enter cleanup semantics for the same batch.
                     */
                    $legacyMetaDataRemaining = [];
                } else {
                    foreach (array_keys($bulkMigratedPostIds) as $migratedPostId) {
                        unset($legacyMetaDataRemaining[(int) $migratedPostId]);
                    }
                }

                $bulkMigratedSliderPostIds = self::migrate_indexed_slider_legacy_meta_to_db2_bulk($indexedSliderBulkPayload);

                if ($bulkMigratedSliderPostIds === false) {
                    // Safety first: preserve legacy and do not enter generic per-post cleanup after a bulk failure.
                    $legacyMetaDataRemaining = [];
                } else {
                    foreach (array_keys($bulkMigratedSliderPostIds) as $migratedPostId) {
                        unset($legacyMetaDataRemaining[(int) $migratedPostId]);
                    }
                }

                if ($legacyMetaDataRemaining) {
                    self::migrate_post_legacy_remote_meta_to_db2(
                        array_keys($legacyMetaDataRemaining),
                        $legacyMetaDataRemaining
                    );
                }
            }
        }

        self::decrement_metadata_counter(self::count_queue_ids($postIds));

        return true;
    }

    /**
     * Process a single metadata in row for a WooCommerce product.
     *
     * This method handles WooCommerce specific metadata restoration using the queue identifier.
     *
     * @param int $queueId Identifier of the WooCommerce metadata in queue row to process.
     *
     * @return bool True if the WooCommerce row was successfully processed, false otherwise.
     */
    public static function process_woo_meta_in_row(int $queueId): bool {
        $wpdb = self::get_wpdb();
        $metaInTable = $wpdb->prefix . 'fifu_meta_in';

        $result = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT post_ids FROM {$metaInTable} WHERE id = %d",
                $queueId
            )
        );

        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$metaInTable} WHERE id = %d",
                $queueId
            )
        );

        Fifu_File_Logger::plugin(['insert_woometa' => ['id' => $queueId]]);

        if (count($result) === 0) {
            return false;
        }

        $ids = $result[0]->post_ids;
        $postIds = self::parse_metadata_post_ids($ids);
        $legacyRepository = self::get_legacy_meta_repository();
        $legacyFeaturedMetaMap = $legacyRepository->get_legacy_fifu_fields_for_posts($postIds);
        $galleryUrlsMap = $legacyRepository->get_gallery_urls_map($postIds);
        $legacyGalleryUrlsMap = $legacyRepository->get_legacy_gallery_urls_map($postIds);
        $legacyGalleryMetaMap = $legacyRepository->get_legacy_gallery_meta_map($postIds);
        $hasIndexedGalleryUrlsMap = $legacyRepository->get_has_indexed_gallery_urls_map($postIds);
        $legacyGalleryAltsMap = $legacyRepository->get_legacy_gallery_alts_map($postIds);
        $legacySliderAltsMap = $legacyRepository->get_legacy_slider_alts_map($postIds);
        $productGallerySnapshots = self::snapshot_non_empty_post_meta($postIds, '_product_image_gallery');
        $indexedSliderFeaturedUrlMap = self::build_clean_indexed_slider_featured_url_map($legacyGalleryMetaMap);
        $hasLegacyWooInput =
            self::has_any_non_empty_legacy_rows($legacyFeaturedMetaMap)
            || self::has_any_non_empty_legacy_rows($legacyGalleryUrlsMap)
            || self::has_any_non_empty_legacy_rows($legacyGalleryMetaMap)
            || self::has_any_non_empty_legacy_rows($legacyGalleryAltsMap)
            || self::has_any_non_empty_legacy_rows($legacySliderAltsMap);
        if (!$hasLegacyWooInput && !empty($galleryUrlsMap)) {
            foreach (array_keys($galleryUrlsMap) as $galleryPostId) {
                $intGalleryPostId = (int) $galleryPostId;
                if (isset($productGallerySnapshots[$intGalleryPostId])) {
                    unset($galleryUrlsMap[$galleryPostId]);
                }
            }
        }
        if (empty($galleryUrlsMap) && !$hasLegacyWooInput) {
            self::decrement_metadata_counter(self::count_queue_ids($postIds));

            return true;
        }

        $missingGalleryPostIds = [];
        foreach ($postIds as $postId) {
            $intPostId = (int) $postId;
            if (!array_key_exists($intPostId, $galleryUrlsMap)) {
                $missingGalleryPostIds[] = $intPostId;
            }
        }

        if ($missingGalleryPostIds) {
            foreach ($legacyRepository->get_legacy_gallery_urls_map($missingGalleryPostIds) as $postId => $urls) {
                if ($urls) {
                    $galleryUrlsMap[(int) $postId] = $urls;
                }
            }
        }
        $attachmentFactory = new Fifu_Attachment_Factory();
        $valueArr = [];
        foreach ($postIds as $postId) {
            $intPostId = (int) $postId;
            if (!array_key_exists($intPostId, $galleryUrlsMap)) {
                continue;
            }
            foreach ($galleryUrlsMap[$intPostId] as $index => $url) {
                $url = Fifu_Video_Helper::is_video($url) ? Fifu_Video_Helper::get_thumbnail_large($url) : $url;
                $url = htmlspecialchars_decode((string) $url);
                $alt = self::resolve_gallery_attachment_alt(
                    $intPostId,
                    (int) $index,
                    $url,
                    $legacyGalleryAltsMap
                );
                $aux = $attachmentFactory->build_insert_tuple($url, $alt, $intPostId);
                $valueArr[] = $aux;
            }
        }
        $value = implode(',', $valueArr);
        wp_cache_flush();
        $service = self::get_speed_up_service();
        if ($service instanceof Fifu_Db2_Speed_Up_Service) {
            if ($valueArr) {
                $service->restore_woocommerce_meta($value, $ids);
                $galleryRepairPostIds = self::build_woocommerce_gallery_meta_repair_post_ids($postIds);
                if ($galleryRepairPostIds) {
                    self::ensure_woocommerce_gallery_meta($galleryRepairPostIds);
                }
            }
            $legacyFeaturedMetaMapToMigrate = $legacyFeaturedMetaMap;
            $legacyGalleryMetaMapToMigrate = $legacyGalleryMetaMap;
            $legacyGalleryAltsMapToMigrate = $legacyGalleryAltsMap;
            $legacySliderAltsMapToMigrate = $legacySliderAltsMap;
            $hasIndexedGalleryUrlsMapToMigrate = $hasIndexedGalleryUrlsMap;

            $imageListBulkPayload = self::build_image_list_bulk_migration_meta_map(
                $legacyFeaturedMetaMap,
                $legacyGalleryMetaMap,
                $legacyGalleryAltsMap
            );

            $imageListBulkMigrationFailed = false;

            if ($imageListBulkPayload) {
                $bulkMigratedPostIds = self::migrate_simple_post_image_list_legacy_meta_to_db2_bulk($imageListBulkPayload);

                if ($bulkMigratedPostIds === false) {
                    $imageListBulkMigrationFailed = true;
                } else {
                    foreach (array_keys($bulkMigratedPostIds) as $migratedPostId) {
                        $migratedPostId = (int) $migratedPostId;
                        unset($legacyFeaturedMetaMapToMigrate[$migratedPostId]);
                        unset($legacyGalleryMetaMapToMigrate[$migratedPostId]);
                        unset($legacyGalleryAltsMapToMigrate[$migratedPostId]);
                        unset($legacySliderAltsMapToMigrate[$migratedPostId]);
                        unset($hasIndexedGalleryUrlsMapToMigrate[$migratedPostId]);
                    }

                }
            }

            $indexedSliderBulkPayload = self::build_indexed_slider_bulk_migration_meta_map(
                $legacyGalleryMetaMapToMigrate,
                $legacySliderAltsMapToMigrate
            );

            if ($indexedSliderBulkPayload) {
                $bulkMigratedSliderPostIds = self::migrate_indexed_slider_legacy_meta_to_db2_bulk($indexedSliderBulkPayload);

                if ($bulkMigratedSliderPostIds === false) {
                    // Preserve legacy and do not enter old per-post cleanup for these clean slider rows.
                    foreach (array_keys($indexedSliderBulkPayload) as $failedPostId) {
                        unset($legacyGalleryMetaMapToMigrate[(int) $failedPostId]);
                        unset($legacyGalleryAltsMapToMigrate[(int) $failedPostId]);
                        unset($legacySliderAltsMapToMigrate[(int) $failedPostId]);
                        unset($hasIndexedGalleryUrlsMapToMigrate[(int) $failedPostId]);
                        unset($legacyFeaturedMetaMapToMigrate[(int) $failedPostId]);
                    }
                } else {
                    foreach (array_keys($bulkMigratedSliderPostIds) as $migratedPostId) {
                        $migratedPostId = (int) $migratedPostId;
                        unset($legacyFeaturedMetaMapToMigrate[$migratedPostId]);
                        unset($legacyGalleryMetaMapToMigrate[$migratedPostId]);
                        unset($legacyGalleryAltsMapToMigrate[$migratedPostId]);
                        unset($legacySliderAltsMapToMigrate[$migratedPostId]);
                        unset($hasIndexedGalleryUrlsMapToMigrate[$migratedPostId]);
                    }

                }
            }

            if (!$imageListBulkMigrationFailed) {
                $remainingWooMigrationPostIds = self::build_remaining_woo_legacy_migration_post_ids(
                    $legacyFeaturedMetaMapToMigrate,
                    $legacyGalleryMetaMapToMigrate,
                    $legacyGalleryAltsMapToMigrate,
                    $legacySliderAltsMapToMigrate,
                    $hasIndexedGalleryUrlsMapToMigrate
                );

                if ($remainingWooMigrationPostIds) {
                    self::migrate_woo_legacy_remote_meta_to_db2(
                        $remainingWooMigrationPostIds,
                        $legacyGalleryMetaMapToMigrate,
                        $legacyGalleryAltsMapToMigrate,
                        $legacySliderAltsMapToMigrate,
                        $hasIndexedGalleryUrlsMapToMigrate,
                        $legacyFeaturedMetaMapToMigrate
                    );
                }
            }
            self::restore_woocommerce_gallery_snapshot_if_empty($postIds, $productGallerySnapshots);
        }

        if ($indexedSliderFeaturedUrlMap && class_exists(Fifu_Post_Attachment_Sync_Service::class, false)) {
            foreach (array_keys($indexedSliderFeaturedUrlMap) as $intPostId) {
                Fifu_Post_Attachment_Sync_Service::sync_featured_attachment((int) $intPostId);
            }
        }

        if ($legacyFeaturedMetaMap && class_exists(Fifu_Post_Attachment_Sync_Service::class, false)) {
            foreach ($legacyFeaturedMetaMap as $intPostId => $featuredMeta) {
                $intPostId = (int) $intPostId;
                if ($intPostId <= 0 || !is_array($featuredMeta)) {
                    continue;
                }

                $hasFeaturedImageInput =
                    trim((string) ($featuredMeta['fifu_image_url'] ?? '')) !== ''
                    || trim((string) ($featuredMeta['fifu_image_alt'] ?? '')) !== '';

                if (!$hasFeaturedImageInput) {
                    continue;
                }

                Fifu_Post_Attachment_Sync_Service::sync_featured_attachment($intPostId);
            }
        }

        self::decrement_metadata_counter(self::count_queue_ids($postIds));

        return true;
    }

    /**
     * Process a single metadata in row for a term.
     *
     * Restores attachment and term metadata entries from the queue entry identified by the provided ID.
     *
     * @param int $queueId Identifier of the term metadata in queue row to process.
     *
     * @return bool True if the term metadata row was successfully processed, false otherwise.
     */
    public static function process_term_meta_in_row(int $queueId): bool {
        $wpdb = self::get_wpdb();
        $metaInTable = $wpdb->prefix . 'fifu_meta_in';

        $result = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT post_ids FROM {$metaInTable} WHERE id = %d",
                $queueId
            )
        );

        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$metaInTable} WHERE id = %d",
                $queueId
            )
        );

        Fifu_File_Logger::plugin(['insert_termmeta' => ['id' => $queueId]]);

        if (count($result) === 0) {
            return false;
        }

        $ids = $result[0]->post_ids;
        $termIds = explode(',', $ids);
        $legacyTermMeta = self::get_legacy_term_fifu_fields($termIds);

        $attachmentFactory = new Fifu_Attachment_Factory();
        $valueArr = [];
        foreach ($termIds as $termId) {
            $intTermId = (int) $termId;
            $termMeta = $legacyTermMeta[$intTermId] ?? array();
            if ($intTermId <= 0) {
                continue;
            }

            if (get_term_meta($intTermId, 'thumbnail_id', true)) {
                continue;
            }

            $url = '';
            $videoUrl = self::get_db2_term_url($intTermId, 'video');
            if ($videoUrl !== '') {
                $thumb = Fifu_Video_Helper::get_thumbnail_large($videoUrl);
                $url = trim((string) $thumb) !== '' ? (string) $thumb : '';
            }

            if ($url === '') {
                $url = self::get_db2_term_url($intTermId, 'image');
            }

            if ($url === '') {
                $legacyImageUrl = trim((string) ($termMeta['fifu_image_url'] ?? get_term_meta($intTermId, 'fifu_image_url', true)));
                if ($legacyImageUrl !== '') {
                    $url = $legacyImageUrl;
                }
            }

            if ($url === '') {
                $legacyVideoUrl = trim((string) ($termMeta['fifu_video_url'] ?? get_term_meta($intTermId, 'fifu_video_url', true)));
                if ($legacyVideoUrl !== '') {
                    $thumb = Fifu_Video_Helper::get_thumbnail_large($legacyVideoUrl);
                    $url = trim((string) $thumb) !== '' ? (string) $thumb : '';
                }
            }

            $url = htmlspecialchars_decode(trim((string) $url));
            if ($url === '') {
                continue;
            }

            $alt = self::get_db2_term_alt($intTermId, 'image');
            if ($alt === '') {
                $alt = trim((string) ($termMeta['fifu_image_alt'] ?? ''));
            }

            if ($alt === '') {
                $legacyAlt = get_term_meta($intTermId, 'fifu_image_alt', true);
                if ($legacyAlt !== '' && $legacyAlt !== null) {
                    $alt = trim((string) $legacyAlt);
                }
            }

            $aux = $attachmentFactory->build_category_insert_tuple(
                $url,
                $alt,
                $intTermId
            );
            $valueArr[] = $aux;
        }

        if (!$valueArr) {
            self::decrement_metadata_counter(self::count_queue_ids($termIds));

            return true;
        }

        $value = implode(',', $valueArr);
        wp_cache_flush();
        $service = self::get_speed_up_service();
        if ($service instanceof Fifu_Db2_Speed_Up_Service) {
            $service->restore_term_attachments($value, $ids);
            self::migrate_term_legacy_remote_meta_to_db2($termIds, $legacyTermMeta);
        }

        self::decrement_metadata_counter(self::count_queue_ids($termIds));

        return true;
    }

    /**
     * @param array<int|string>              $postIds
     * @param array<int,array<string,string>> $metaData
     * @return void
     */
    private static function migrate_post_legacy_remote_meta_to_db2(array $postIds, array $metaData): void {
        $updater = self::get_post_meta_updater();
        if (!$updater) {
            return;
        }

        $preserveKey = 'fifu_preserve_legacy_meta_until_db2_confirmation';
        foreach ($postIds as $postId) {
            $intPostId = (int) $postId;
            $meta = $metaData[$intPostId] ?? null;
            if (!is_array($meta)) {
                continue;
            }

            $allowFeaturedCleanup = !self::has_partial_db2_confirmation_for_post_featured_meta($intPostId, $meta);
            $previousPreserve = array_key_exists($preserveKey, $_REQUEST) ? $_REQUEST[$preserveKey] : null;
            $_REQUEST[$preserveKey] = true;
            try {
                self::sync_post_featured_legacy_meta_to_db2($updater, $intPostId, $meta);
            } finally {
                if ($previousPreserve === null) {
                    unset($_REQUEST[$preserveKey]);
                } else {
                    $_REQUEST[$preserveKey] = $previousPreserve;
                }
            }

            if ($allowFeaturedCleanup) {
                self::cleanup_legacy_featured_postmeta_if_db2_matches($intPostId, $meta);
            }
        }
    }

    /**
     * @param array<int|string>               $postIds
     * @param array<int,array<string,string>> $galleryMetaMap
     * @param array<int,array<string,string>> $galleryAltsMap
     * @return void
     */
    private static function migrate_woo_legacy_remote_meta_to_db2(
        array $postIds,
        array $galleryMetaMap,
        array $galleryAltsMap = [],
        array $sliderAltsMap = [],
        array $hasIndexedGalleryUrlsMap = [],
        array $featuredMetaMap = []
    ): void {
        $updater = self::get_post_meta_updater();
        if (!$updater) {
            return;
        }

        foreach ($postIds as $postId) {
            $intPostId = (int) $postId;
            $allowGalleryCleanup = !self::has_partial_db2_confirmation_for_gallery_list($intPostId, 'fifu_list_url', 'fifu_list_alt', 'image');
            $featuredMeta = $featuredMetaMap[$intPostId] ?? [];
            if (is_array($featuredMeta) && $featuredMeta !== []) {
                self::sync_post_featured_legacy_meta_to_db2($updater, $intPostId, $featuredMeta);
            }
            $galleryMeta = $galleryMetaMap[$intPostId] ?? [];
            $syncStatus = [
                'indexedGallerySynced' => false,
                'imageListSynced' => false,
                'videoListSynced' => false,
            ];
            $sliderUrlsSynced = false;
            $altsSynced = false;
            $sliderAltsSynced = false;
            $allowVideoCleanup = !self::has_partial_db2_confirmation_for_video_list($intPostId);
            $allowSliderCleanup = !self::has_partial_db2_confirmation_for_gallery_list($intPostId, 'fifu_slider_list_url', 'fifu_slider_list_alt', 'slider');
            $allowSliderUrlCleanup = !self::has_partial_db2_confirmation_for_gallery_list($intPostId, 'fifu_slider_list_url', 'fifu_slider_list_alt', 'slider');
            $allowGalleryUrlCleanup = $allowGalleryCleanup;
            if ($galleryMeta) {
                $hasLegacyVideoGalleryMeta = self::has_legacy_video_gallery_meta($galleryMeta);
                $allowIndexedCleanup = !self::has_partial_db2_confirmation_for_indexed_gallery($intPostId, $galleryMeta);
                $preserveKey = 'fifu_preserve_legacy_meta_until_db2_confirmation';
                $previousPreserve = array_key_exists($preserveKey, $_REQUEST) ? $_REQUEST[$preserveKey] : null;
                $_REQUEST[$preserveKey] = true;
                try {
                    $syncStatus = self::sync_post_gallery_legacy_meta_to_db2(
                        $updater,
                        $intPostId,
                        $galleryMeta,
                        !empty($hasIndexedGalleryUrlsMap[$intPostId])
                    );
                } finally {
                    if ($previousPreserve === null) {
                        unset($_REQUEST[$preserveKey]);
                    } else {
                        $_REQUEST[$preserveKey] = $previousPreserve;
                    }
                }
                self::cleanup_legacy_gallery_list_video_url_postmeta($intPostId, true);
                if ($syncStatus['indexedGallerySynced']) {
                    if ($allowIndexedCleanup) {
                        self::cleanup_legacy_indexed_image_video_gallery_url_postmeta($intPostId);
                    }
                    self::cleanup_legacy_gallery_list_url_postmeta($intPostId, $allowGalleryUrlCleanup);
                    if ($hasLegacyVideoGalleryMeta) {
                        self::cleanup_legacy_gallery_list_video_url_postmeta($intPostId, $allowVideoCleanup);
                    }
                }
                if ($syncStatus['imageListSynced']) {
                    self::cleanup_legacy_gallery_list_url_postmeta($intPostId, $allowGalleryUrlCleanup);
                }
                if ($syncStatus['videoListSynced']) {
                    self::cleanup_legacy_gallery_list_video_url_postmeta($intPostId, $allowVideoCleanup);
                }
                $sliderUrlsSynced = self::sync_post_slider_gallery_legacy_meta_to_db2($updater, $intPostId, $galleryMeta);
            }

            $galleryAlts = $galleryAltsMap[$intPostId] ?? [];
            if ($galleryAlts) {
                $imageGalleryAlts = self::build_indexed_gallery_alt_sync_map($galleryMeta, $galleryAlts);

                $altsSynced = $imageGalleryAlts ? self::sync_post_gallery_legacy_alts_to_db2($updater, $intPostId, $imageGalleryAlts) : false;
                if ($altsSynced) {
                    self::cleanup_legacy_gallery_list_alt_postmeta($intPostId, $allowGalleryCleanup);
                    self::cleanup_legacy_gallery_list_url_postmeta($intPostId, $allowGalleryUrlCleanup);
                }
            }

            $sliderAlts = $sliderAltsMap[$intPostId] ?? [];
            $sliderAltsSynced = false;
            $shouldCleanupSliderUrl = false;
            if ($sliderUrlsSynced && is_array($sliderAlts) && $sliderAlts) {
                $sliderOnlyAlts = [];
                foreach ($sliderAlts as $metaKey => $metaValue) {
                    if (preg_match('/^fifu_slider_image_alt_\d+$/', (string) $metaKey) !== 1) {
                        continue;
                    }

                    $sliderOnlyAlts[$metaKey] = $metaValue;
                }

                $sliderAltsSynced = $sliderOnlyAlts ? self::sync_post_slider_legacy_alts_to_db2($updater, $intPostId, $sliderOnlyAlts) : false;
                if ($sliderAltsSynced) {
                    self::cleanup_legacy_slider_list_alt_postmeta($intPostId, true);
                    $shouldCleanupSliderUrl = !empty($galleryMeta) && $sliderUrlsSynced;
                }
            }

            if ($shouldCleanupSliderUrl) {
                self::cleanup_legacy_slider_list_url_postmeta($intPostId, true);
            }

            self::cleanup_post_image_legacy_meta_after_final_db2_sync($intPostId);
        }
    }

    /**
     * @param array<int|string>              $termIds
     * @param array<int,array<string,string>> $metaData
     * @return void
     */
    private static function migrate_term_legacy_remote_meta_to_db2(array $termIds, array $metaData): void {
        $updater = self::get_term_meta_updater();
        if (!$updater) {
            return;
        }

        $preserveKey = 'fifu_preserve_legacy_meta_until_db2_confirmation';
        foreach ($termIds as $termId) {
            $intTermId = (int) $termId;
            $meta = $metaData[$intTermId] ?? null;
            if (!is_array($meta)) {
                continue;
            }

            $allowImageCleanup = !self::has_partial_db2_confirmation_for_term_image($intTermId, $meta);
            $allowVideoCleanup = !self::has_partial_db2_confirmation_for_term_video($intTermId, $meta);
            $previousPreserve = array_key_exists($preserveKey, $_REQUEST) ? $_REQUEST[$preserveKey] : null;
            $_REQUEST[$preserveKey] = true;
            try {
                self::sync_term_legacy_meta_to_db2($updater, $intTermId, $meta);
            } finally {
                if ($previousPreserve === null) {
                    unset($_REQUEST[$preserveKey]);
                } else {
                    $_REQUEST[$preserveKey] = $previousPreserve;
                }
            }

            if ($allowImageCleanup) {
                self::cleanup_legacy_term_image_postmeta_if_db2_matches($intTermId, $meta);
            }

            if ($allowVideoCleanup) {
                self::cleanup_legacy_term_video_postmeta_if_db2_matches($intTermId, $meta);
            }
        }
    }

    /**
     * @param FIFU_Post_Meta_Updater $updater
     * @param int                    $postId
     * @param array<string,string>   $meta
     * @return void
     */
    private static function sync_post_featured_legacy_meta_to_db2(
        FIFU_Post_Meta_Updater $updater,
        int $postId,
        array $meta
    ): void {
        foreach (['fifu_image_url', 'fifu_image_alt', 'fifu_video_url', 'fifu_slider_image_url_0'] as $metaKey) {
            $value = trim((string) ($meta[$metaKey] ?? ''));
            if ($value === '') {
                continue;
            }

            $updater->update_or_delete($postId, $metaKey, $value);
        }
    }

    /**
     * @param FIFU_Post_Meta_Updater $updater
     * @param int                    $postId
     * @param array<string,string>   $galleryMeta
     * @return array{indexedGallerySynced:bool,imageListSynced:bool,videoListSynced:bool}
     */
    private static function sync_post_gallery_legacy_meta_to_db2(
        FIFU_Post_Meta_Updater $updater,
        int $postId,
        array $galleryMeta,
        bool $hasIndexedGalleryUrls
    ): array {
        $syncStatus = [
            'indexedGallerySynced' => false,
            'imageListSynced' => false,
            'videoListSynced' => false,
        ];

        if (!method_exists($updater, 'update_or_delete_with_status')) {
            return $syncStatus;
        }

        if ($hasIndexedGalleryUrls) {
            $hasIndexedGalleryItems = false;
            $allIndexedGalleryItemsSynced = true;

            foreach ($galleryMeta as $metaKey => $metaValue) {
                if (
                    preg_match('/^fifu_image_url_\d+$/', (string) $metaKey) !== 1
                    && preg_match('/^fifu_video_url_\d+$/', (string) $metaKey) !== 1
                ) {
                    continue;
                }

                $value = trim((string) $metaValue);
                if ($value === '') {
                    continue;
                }

                $hasIndexedGalleryItems = true;

                if (!$updater->update_or_delete_with_status($postId, (string) $metaKey, $value)) {
                    $allIndexedGalleryItemsSynced = false;
                }
            }

            $syncStatus['indexedGallerySynced'] = $hasIndexedGalleryItems && $allIndexedGalleryItemsSynced;
            return $syncStatus;
        }

        $imageUrls = [];
        $videoUrls = [];
        foreach ($galleryMeta as $metaKey => $metaValue) {
            $value = trim((string) $metaValue);
            if ($value === '') {
                continue;
            }

            if (preg_match('/^fifu_image_url_\d+$/', (string) $metaKey) === 1) {
                $imageUrls[] = $value;
                continue;
            }

            if (preg_match('/^fifu_video_url_\d+$/', (string) $metaKey) === 1) {
                $videoUrls[] = $value;
            }
        }

        if (!$imageUrls && !$videoUrls) {
            return $syncStatus;
        }

        $imageListSynced = true;
        $videoListSynced = true;

        if ($imageUrls) {
            $imageListSynced = $updater->update_or_delete_with_status($postId, 'fifu_list_url', implode('|', $imageUrls));
        }

        if ($videoUrls) {
            $videoListSynced = $updater->update_or_delete_with_status($postId, 'fifu_list_video_url', implode('|', $videoUrls));
        }

        $syncStatus['imageListSynced'] = !empty($imageUrls) && $imageListSynced;
        $syncStatus['videoListSynced'] = !empty($videoUrls) && $videoListSynced;

        return $syncStatus;
    }

    /**
     * Build indexed gallery alt values using explicit indexed alts first and list alts as fallback.
     *
     * @param array<string,string> $galleryMeta
     * @param array<string,string> $galleryAlts
     * @return array<string,string>
     */
    private static function build_indexed_gallery_alt_sync_map(array $galleryMeta, array $galleryAlts): array {
        $indexedUrls = [];
        foreach ($galleryMeta as $metaKey => $metaValue) {
            if (preg_match('/^fifu_image_url_(\d+)$/', (string) $metaKey, $matches) !== 1) {
                continue;
            }

            $indexedUrls[(int) $matches[1]] = trim((string) $metaValue);
        }
        ksort($indexedUrls, SORT_NUMERIC);

        $explicitAlts = [];
        foreach ($galleryAlts as $metaKey => $metaValue) {
            if (preg_match('/^fifu_image_alt_(\d+)$/', (string) $metaKey, $matches) !== 1) {
                continue;
            }

            $alt = self::normalize_legacy_gallery_alt_value($metaValue);
            if ($alt === '') {
                continue;
            }

            $explicitAlts[(int) $matches[1]] = $alt;
        }

        $listUrls = self::parse_legacy_gallery_pipe_values((string) ($galleryAlts['fifu_list_url'] ?? $galleryMeta['fifu_list_url'] ?? ''));
        $listAlts = self::parse_legacy_gallery_alt_values((string) ($galleryAlts['fifu_list_alt'] ?? ''));
        $consumedListIndexes = [];
        $syncMap = [];

        foreach ($indexedUrls as $index => $url) {
            if (isset($explicitAlts[$index])) {
                $syncMap['fifu_image_alt_' . $index] = $explicitAlts[$index];
                continue;
            }

            $alt = self::find_indexed_gallery_fallback_alt($url, $index, $listUrls, $listAlts, $consumedListIndexes);
            if ($alt !== '') {
                $syncMap['fifu_image_alt_' . $index] = $alt;
            }
        }

        ksort($syncMap, SORT_NATURAL);

        return $syncMap;
    }

    /**
     * @param array<int,string> $listUrls
     * @param array<int,string> $listAlts
     * @param array<int,bool>    $consumedListIndexes
     */
    private static function find_indexed_gallery_fallback_alt(
        string $indexedUrl,
        int $index,
        array $listUrls,
        array $listAlts,
        array &$consumedListIndexes
    ): string {
        foreach ($listUrls as $listIndex => $listUrl) {
            if (isset($consumedListIndexes[$listIndex])) {
                continue;
            }

            if (trim((string) $listUrl) !== $indexedUrl) {
                continue;
            }

            $consumedListIndexes[$listIndex] = true;
            return self::normalize_legacy_gallery_alt_value($listAlts[$listIndex] ?? '');
        }

        return self::normalize_legacy_gallery_alt_value($listAlts[$index] ?? '');
    }

    /**
     * @param string $value
     * @return array<int,string>
     */
    private static function parse_legacy_gallery_alt_values(string $value): array {
        $values = [];

        foreach (explode('|', $value) as $index => $item) {
            $normalized = self::normalize_legacy_gallery_alt_value($item);
            if ($normalized === '') {
                continue;
            }

            $values[$index] = $normalized;
        }

        return $values;
    }

    /**
     * @param string $value
     * @return array<int,string>
     */
    private static function parse_legacy_gallery_pipe_values(string $value): array {
        $values = [];

        foreach (explode('|', $value) as $index => $item) {
            $item = trim((string) $item);
            if ($item === '' || preg_match('/^(null|undefined)$/i', $item) === 1) {
                continue;
            }

            $values[$index] = $item;
        }

        return $values;
    }

    /**
     * Resolve the ALT value for a gallery attachment from legacy Woo meta.
     *
     * @param array<int,array<string,string>> $legacyGalleryAltsMap
     */
    private static function resolve_gallery_attachment_alt_from_legacy_meta(
        int $postId,
        int $logicalIndex,
        array $legacyGalleryAltsMap
    ): string {
        $galleryAlts = $legacyGalleryAltsMap[$postId] ?? [];
        if (!is_array($galleryAlts)) {
            return '';
        }

        $indexedAltKey = 'fifu_image_alt_' . $logicalIndex;
        if (array_key_exists($indexedAltKey, $galleryAlts)) {
            $alt = self::normalize_legacy_gallery_alt_value($galleryAlts[$indexedAltKey]);
            if ($alt !== '') {
                return $alt;
            }
        }

        if (array_key_exists('fifu_list_alt', $galleryAlts)) {
            $listAlts = self::parse_legacy_gallery_alt_values((string) $galleryAlts['fifu_list_alt']);
            return self::normalize_legacy_gallery_alt_value($listAlts[$logicalIndex] ?? '');
        }

        return '';
    }

    private static function resolve_gallery_attachment_alt(
        int $postId,
        int $logicalIndex,
        string $url,
        array $legacyGalleryAltsMap
    ): string {
        $legacyAlt = self::resolve_gallery_attachment_alt_from_legacy_meta(
            $postId,
            $logicalIndex,
            $legacyGalleryAltsMap
        );

        if ($legacyAlt !== '') {
            return $legacyAlt;
        }

        $normalizedUrl = htmlspecialchars_decode(trim($url));
        $sliderUrls = self::get_db2_post_url_map_by_index($postId, 'slider');
        $sliderAlts = self::get_db2_post_alt_map_by_index($postId, 'slider');

        foreach ($sliderUrls as $sliderIndex => $sliderUrl) {
            $sliderIndex = (int) $sliderIndex;
            if ($sliderIndex <= 0) {
                continue;
            }

            if ($normalizedUrl !== htmlspecialchars_decode(trim((string) $sliderUrl))) {
                continue;
            }

            return self::normalize_legacy_gallery_alt_value($sliderAlts[$sliderIndex] ?? '');
        }

        return '';
    }

    private static function normalize_legacy_gallery_alt_value($value): string {
        $text = trim((string) $value);
        if ($text === '') {
            return '';
        }

        if (function_exists('wp_strip_all_tags')) {
            $text = (string) wp_strip_all_tags($text);
        } else {
            $stripped = preg_replace('/<[^>]*>/', '', $text);
            if (is_string($stripped)) {
                $text = $stripped;
            }
        }

        $text = trim($text);
        if ($text === '' || preg_match('/^(null|undefined)$/i', $text) === 1) {
            return '';
        }

        return $text;
    }

    private static function cleanup_post_image_legacy_meta_after_db2_confirmation(int $postId): void {
        if (!function_exists('get_post_meta')) {
            return;
        }

        $legacyUrl = trim((string) get_post_meta($postId, 'fifu_image_url', true));
        $legacyAlt = trim((string) get_post_meta($postId, 'fifu_image_alt', true));
        $db2Urls = self::get_db2_post_pipe_list($postId, 'image');
        $db2Alts = self::get_db2_post_alt_pipe_list($postId, 'image');

        if ($legacyUrl !== '' || $legacyAlt !== '') {
            if (Fifu_Metadata_Db2_Cleanup_Guard::can_cleanup_url_and_alt(
                $legacyUrl,
                $legacyAlt,
                $db2Urls[0] ?? null,
                $db2Alts[0] ?? null
            )) {
                delete_post_meta($postId, 'fifu_image_url');
                delete_post_meta($postId, 'fifu_image_alt');
                clean_post_cache($postId);
                wp_cache_delete($postId, 'post_meta');
            }
        }

        self::cleanup_legacy_indexed_image_gallery_postmeta($postId, true);
        self::cleanup_legacy_indexed_image_gallery_postmeta($postId, false);

        self::cleanup_woo_image_legacy_meta_after_final_db2_confirmation($postId);
    }

    private static function cleanup_woo_image_legacy_meta_after_final_db2_confirmation(int $postId): void
    {
        if (!class_exists('Fifu_Legacy_Image_Meta_Cleanup_Service', false)) {
            return;
        }

        Fifu_Legacy_Image_Meta_Cleanup_Service::cleanup_post_image_meta_after_db2_sync($postId);
    }

    private static function cleanup_post_image_legacy_meta_after_final_db2_sync(int $postId): void {
        if (!class_exists('Fifu_Legacy_Image_Meta_Cleanup_Service')) {
            return;
        }

        if (!method_exists('Fifu_Legacy_Image_Meta_Cleanup_Service', 'cleanup_post_image_meta_after_db2_sync')) {
            return;
        }

        Fifu_Legacy_Image_Meta_Cleanup_Service::cleanup_post_image_meta_after_db2_sync($postId);

        if (function_exists('clean_post_cache')) {
            clean_post_cache($postId);
        }

        if (function_exists('wp_cache_delete')) {
            wp_cache_delete($postId, 'post_meta');
        }
    }

    private static function cleanup_legacy_indexed_image_gallery_postmeta(int $postId, bool $isUrl): void {
        if (!function_exists('get_post_meta')) {
            return;
        }

        $meta = get_post_meta($postId);
        if (!is_array($meta) || $meta === []) {
            return;
        }

        $pattern = $isUrl ? '/^fifu_image_url_(\d+)$/' : '/^fifu_image_alt_(\d+)$/';
        $db2Values = $isUrl ? self::get_db2_post_pipe_list($postId, 'image') : self::get_db2_post_alt_pipe_list($postId, 'image');

        foreach (array_keys($meta) as $metaKey) {
            if (!is_string($metaKey) || preg_match($pattern, $metaKey, $matches) !== 1) {
                continue;
            }

            $legacyValue = trim((string) get_post_meta($postId, $metaKey, true));
            if ($legacyValue === '') {
                continue;
            }

            $legacyIndex = (int) $matches[1];
            $db2Index = $legacyIndex + 1;
            $db2Value = $db2Values[$db2Index] ?? null;
            if ($db2Value === null) {
                continue;
            }

            if (!Fifu_Metadata_Db2_Cleanup_Guard::values_match($legacyValue, $db2Value)) {
                continue;
            }

            delete_post_meta($postId, $metaKey);
            clean_post_cache($postId);
            wp_cache_delete($postId, 'post_meta');
        }
    }

    /**
     * @param FIFU_Post_Meta_Updater $updater
     * @param int                    $postId
     * @param array<string,string>   $galleryMeta
     * @return void
     */
    private static function sync_post_slider_gallery_legacy_meta_to_db2(
        FIFU_Post_Meta_Updater $updater,
        int $postId,
        array $galleryMeta
    ): bool {
        if (!method_exists($updater, 'update_or_delete_with_status')) {
            return false;
        }

        $syncedAny = false;
        foreach ($galleryMeta as $metaKey => $metaValue) {
            if (preg_match('/^fifu_slider_image_url_\d+$/', (string) $metaKey) !== 1) {
                continue;
            }

            $value = trim((string) $metaValue);
            if ($value === '') {
                continue;
            }

            if (!$updater->update_or_delete_with_status($postId, (string) $metaKey, $value)) {
                return false;
            }

            $syncedAny = true;
        }

        return $syncedAny;
    }

    /**
     * @param FIFU_Post_Meta_Updater $updater
     * @param int                    $postId
     * @param array<string,string>   $sliderAlts
     * @return bool
     */
    private static function sync_post_slider_legacy_alts_to_db2(
        FIFU_Post_Meta_Updater $updater,
        int $postId,
        array $sliderAlts
    ): bool {
        if (!method_exists($updater, 'update_or_delete_with_status')) {
            foreach ($sliderAlts as $metaKey => $metaValue) {
                $value = trim((string) $metaValue);
                if ($value === '') {
                    continue;
                }

                $updater->update_or_delete($postId, $metaKey, $value);
            }

            return false;
        }

        $syncedAny = false;
        foreach ($sliderAlts as $metaKey => $metaValue) {
            $value = trim((string) $metaValue);
            if ($value === '') {
                continue;
            }

            if (!$updater->update_or_delete_with_status($postId, $metaKey, $value)) {
                return false;
            }

            $syncedAny = true;
        }

        return $syncedAny;
    }

    /**
     * @param FIFU_Post_Meta_Updater $updater
     * @param int                    $postId
     * @param array<string,string>   $galleryAlts
     * @return bool
     */
    private static function sync_post_gallery_legacy_alts_to_db2(
        FIFU_Post_Meta_Updater $updater,
        int $postId,
        array $galleryAlts
    ): bool {
        if (!method_exists($updater, 'update_or_delete_with_status')) {
            foreach ($galleryAlts as $metaKey => $metaValue) {
                $value = trim((string) $metaValue);
                if ($value === '') {
                    continue;
                }

                $updater->update_or_delete($postId, $metaKey, $value);
            }

            return false;
        }

        foreach ($galleryAlts as $metaKey => $metaValue) {
            $value = trim((string) $metaValue);
            if ($value === '') {
                continue;
            }

            if (!$updater->update_or_delete_with_status($postId, $metaKey, $value)) {
                return false;
            }
        }

        return true;
    }

    /**
     * @param int $postId
     * @return void
     */
    private static function cleanup_legacy_gallery_list_alt_postmeta(int $postId, bool $allowCleanup): void {
        if (!$allowCleanup) {
            return;
        }

        if (!function_exists('get_post_meta')) {
            return;
        }

        $legacyAlts = (string) get_post_meta($postId, 'fifu_list_alt', true);
        if ($legacyAlts === '') {
            return;
        }

        $db2Alts = self::get_db2_post_alt_pipe_list($postId, 'image');

        if (!Fifu_Metadata_Db2_Cleanup_Guard::can_cleanup_pipe_list($legacyAlts, $db2Alts)) {
            return;
        }

        delete_post_meta($postId, 'fifu_list_alt');
        clean_post_cache($postId);
        wp_cache_delete($postId, 'post_meta');
    }

    /**
     * @param int $postId
     * @return void
     */
    private static function cleanup_legacy_gallery_list_url_postmeta(int $postId, bool $allowCleanup): void {
        if (!$allowCleanup) {
            return;
        }

        if (!function_exists('get_post_meta')) {
            return;
        }

        $legacyUrls = (string) get_post_meta($postId, 'fifu_list_url', true);
        if ($legacyUrls === '') {
            return;
        }

        $db2Urls = self::get_db2_post_pipe_list($postId, 'image');

        if (!Fifu_Metadata_Db2_Cleanup_Guard::can_cleanup_pipe_list($legacyUrls, $db2Urls)) {
            return;
        }

        delete_post_meta($postId, 'fifu_list_url');
        delete_post_meta($postId, 'fifu_tmp_product_gallery');
        delete_post_meta($postId, 'fifu_tmp_product_image_gallery');

        clean_post_cache($postId);
        wp_cache_delete($postId, 'post_meta');
    }

    /**
     * @param int $postId
     * @return void
     */
    private static function cleanup_legacy_gallery_list_video_url_postmeta(int $postId, bool $allowCleanup): void {
        if (!$allowCleanup) {
            return;
        }

        if (!function_exists('get_post_meta')) {
            return;
        }

        $legacyValue = (string) get_post_meta($postId, 'fifu_list_video_url', true);
        $db2Value = self::get_db2_post_pipe_list($postId, 'video');

        if (Fifu_Metadata_Db2_Cleanup_Guard::can_cleanup_pipe_list($legacyValue, $db2Value)) {
            delete_post_meta($postId, 'fifu_list_video_url');
            FIFU_Post_Meta_Updater::instance()->cleanup_video_list_legacy_postmeta($postId);
            clean_post_cache($postId);
            wp_cache_delete($postId, 'post_meta');
        }
    }

    /**
     * @param int $postId
     * @return void
     */
    private static function cleanup_legacy_slider_list_url_postmeta(int $postId, bool $allowCleanup): void {
        if (!$allowCleanup) {
            return;
        }

        self::cleanup_legacy_gallery_list_postmeta_if_db2_matches($postId, 'fifu_slider_list_url', 'fifu_slider_list_alt', 'slider');
    }

    /**
     * @param int $postId
     * @return void
     */
    private static function cleanup_legacy_slider_list_alt_postmeta(int $postId, bool $allowCleanup): void {
        if (!$allowCleanup) {
            return;
        }

        self::cleanup_legacy_gallery_list_postmeta_if_db2_matches($postId, 'fifu_slider_list_url', 'fifu_slider_list_alt', 'slider');
    }

    /**
     * @param int $postId
     * @return void
     */
    private static function cleanup_legacy_featured_postmeta_if_db2_matches(int $postId, array $meta): void {
        if (!function_exists('get_post_meta')) {
            return;
        }

        $legacyUrl = (string) ($meta['fifu_image_url'] ?? get_post_meta($postId, 'fifu_image_url', true));
        $legacyAlt = (string) ($meta['fifu_image_alt'] ?? get_post_meta($postId, 'fifu_image_alt', true));
        $legacyVideo = (string) ($meta['fifu_video_url'] ?? get_post_meta($postId, 'fifu_video_url', true));
        $legacySlider0 = (string) ($meta['fifu_slider_image_url_0'] ?? get_post_meta($postId, 'fifu_slider_image_url_0', true));

        $db2ImageUrls = self::get_db2_post_pipe_list($postId, 'image');
        $db2ImageAlts = self::get_db2_post_alt_pipe_list($postId, 'image');
        $db2VideoUrls = self::get_db2_post_pipe_list($postId, 'video');
        $db2SliderUrls = self::get_db2_post_pipe_list($postId, 'slider');

        if (Fifu_Metadata_Db2_Cleanup_Guard::can_cleanup_url_and_alt($legacyUrl, $legacyAlt, $db2ImageUrls[0] ?? null, $db2ImageAlts[0] ?? null)) {
            delete_post_meta($postId, 'fifu_image_url');
            if ($legacyAlt !== '') {
                delete_post_meta($postId, 'fifu_image_alt');
            }
            clean_post_cache($postId);
            wp_cache_delete($postId, 'post_meta');
        }

        if ($legacyVideo !== '' && Fifu_Metadata_Db2_Cleanup_Guard::can_cleanup_pipe_list($legacyVideo, $db2VideoUrls)) {
            delete_post_meta($postId, 'fifu_video_url');
            FIFU_Post_Meta_Updater::instance()->cleanup_video_list_legacy_postmeta($postId);
            clean_post_cache($postId);
            wp_cache_delete($postId, 'post_meta');
        }

        if ($legacySlider0 !== '' && Fifu_Metadata_Db2_Cleanup_Guard::can_cleanup_pipe_list($legacySlider0, $db2SliderUrls)) {
            delete_post_meta($postId, 'fifu_slider_image_url_0');
            clean_post_cache($postId);
            wp_cache_delete($postId, 'post_meta');
        }
    }

    /**
     * @param int $postId
     * @param string $legacyUrlKey
     * @param string $legacyAltKey
     * @param string $keyType
     * @return void
     */
    private static function cleanup_legacy_gallery_list_postmeta_if_db2_matches(int $postId, string $legacyUrlKey, string $legacyAltKey, string $keyType): void {
        if (!function_exists('get_post_meta')) {
            return;
        }

        $legacyUrls = (string) get_post_meta($postId, $legacyUrlKey, true);
        $legacyAlts = (string) get_post_meta($postId, $legacyAltKey, true);
        $db2Urls = self::get_db2_post_pipe_list($postId, $keyType);
        $db2Alts = self::get_db2_post_alt_pipe_list($postId, $keyType);

        if (!Fifu_Metadata_Db2_Cleanup_Guard::can_cleanup_url_list_and_alt_list($legacyUrls, $legacyAlts, $db2Urls, $db2Alts)) {
            return;
        }

        if ($legacyUrls !== '') {
            delete_post_meta($postId, $legacyUrlKey);
        }

        if ($legacyAlts !== '') {
            delete_post_meta($postId, $legacyAltKey);
        }

        delete_post_meta($postId, 'fifu_tmp_product_gallery');
        delete_post_meta($postId, 'fifu_tmp_product_image_gallery');

        clean_post_cache($postId);
        wp_cache_delete($postId, 'post_meta');
    }

    /**
     * @param int $postId
     * @param array<string,string> $meta
     * @return bool
     */
    private static function has_partial_db2_confirmation_for_post_featured_meta(int $postId, array $meta): bool {
        $legacyAlt = trim((string) ($meta['fifu_image_alt'] ?? ''));
        if ($legacyAlt === '') {
            return false;
        }

        $db2Urls = self::get_db2_post_pipe_list($postId, 'image');
        $db2Alts = self::get_db2_post_alt_pipe_list($postId, 'image');

        return ($db2Urls !== [] || $db2Alts !== []) && !Fifu_Metadata_Db2_Cleanup_Guard::can_cleanup_url_and_alt(
            (string) ($meta['fifu_image_url'] ?? ''),
            $legacyAlt,
            $db2Urls[0] ?? null,
            $db2Alts[0] ?? null
        );
    }

    /**
     * @param int $postId
     * @return bool
     */
    private static function has_partial_db2_confirmation_for_gallery_list(int $postId, string $legacyUrlKey, string $legacyAltKey, string $keyType): bool {
        $legacyUrls = (string) get_post_meta($postId, $legacyUrlKey, true);
        $legacyAlts = (string) get_post_meta($postId, $legacyAltKey, true);
        $db2Urls = self::get_db2_post_pipe_list($postId, $keyType);
        $db2Alts = self::get_db2_post_alt_pipe_list($postId, $keyType);

        return ($db2Urls !== [] || $db2Alts !== []) && !Fifu_Metadata_Db2_Cleanup_Guard::can_cleanup_url_list_and_alt_list(
            $legacyUrls,
            $legacyAlts,
            $db2Urls,
            $db2Alts
        );
    }

    /**
     * @param int $postId
     * @return bool
     */
    private static function has_partial_db2_confirmation_for_video_list(int $postId): bool {
        $legacyValue = (string) get_post_meta($postId, 'fifu_list_video_url', true);
        $db2Value = self::get_db2_post_pipe_list($postId, 'video');

        return ($db2Value !== []) && !Fifu_Metadata_Db2_Cleanup_Guard::can_cleanup_pipe_list($legacyValue, $db2Value);
    }

    /**
     * @param int $postId
     * @param array<string,string> $meta
     * @return bool
     */
    private static function has_partial_db2_confirmation_for_indexed_gallery(int $postId, array $meta): bool {
        $legacyImageUrls = [];
        $legacyImageAlts = [];
        $legacyVideoUrls = [];

        foreach ($meta as $metaKey => $metaValue) {
            $value = trim((string) $metaValue);
            if ($value === '' || preg_match('/^(null|undefined)$/i', $value) === 1) {
                continue;
            }

            if (preg_match('/^fifu_image_url_(\d+)$/', (string) $metaKey, $matches) === 1) {
                $legacyImageUrls[(int) $matches[1]] = $value;
                continue;
            }

            if (preg_match('/^fifu_image_alt_(\d+)$/', (string) $metaKey, $matches) === 1) {
                $legacyImageAlts[(int) $matches[1]] = $value;
                continue;
            }

            if (preg_match('/^fifu_video_url_(\d+)$/', (string) $metaKey, $matches) === 1) {
                $legacyVideoUrls[(int) $matches[1]] = $value;
            }
        }

        if ($legacyImageUrls === [] && $legacyImageAlts === [] && $legacyVideoUrls === []) {
            return false;
        }

        $db2ImageUrls = self::get_db2_post_url_map_by_index($postId, 'image');
        $db2ImageAlts = self::get_db2_post_alt_map_by_index($postId, 'image');
        $db2VideoUrls = self::get_db2_post_url_map_by_index($postId, 'video');

        $hasRelevantDb2 = false;
        $allSlotsConfirmed = true;
        $indexes = array_values(array_unique(array_merge(
            array_keys($legacyImageUrls),
            array_keys($legacyImageAlts),
            array_keys($legacyVideoUrls)
        )));

        foreach ($indexes as $index) {
            if (array_key_exists($index, $legacyVideoUrls)) {
                $db2VideoUrl = $db2VideoUrls[$index] ?? null;
                if ($db2VideoUrl === null) {
                    continue;
                }

                $hasRelevantDb2 = true;
                if (!Fifu_Metadata_Db2_Cleanup_Guard::can_cleanup_scalar($legacyVideoUrls[$index], $db2VideoUrl)) {
                    $allSlotsConfirmed = false;
                }

                continue;
            }

            $legacyUrl = $legacyImageUrls[$index] ?? null;
            $legacyAlt = $legacyImageAlts[$index] ?? null;
            $db2Url = $db2ImageUrls[$index] ?? null;
            $db2Alt = $db2ImageAlts[$index] ?? null;

            if ($db2Url === null && $db2Alt === null) {
                continue;
            }

            $hasRelevantDb2 = true;

            if ($legacyUrl !== null) {
                if (!Fifu_Metadata_Db2_Cleanup_Guard::can_cleanup_url_and_alt($legacyUrl, $legacyAlt, $db2Url, $db2Alt)) {
                    $allSlotsConfirmed = false;
                }

                continue;
            }

            if ($legacyAlt === null) {
                continue;
            }

            if ($db2Alt !== null) {
                if (!Fifu_Metadata_Db2_Cleanup_Guard::values_match($legacyAlt, $db2Alt)) {
                    $allSlotsConfirmed = false;
                }
                continue;
            }

            $allSlotsConfirmed = false;
        }

        return $hasRelevantDb2 && !$allSlotsConfirmed;
    }

    /**
     * @param int $termId
     * @param array<string,string> $meta
     * @return bool
     */
    private static function has_partial_db2_confirmation_for_term_image(int $termId, array $meta): bool {
        $legacyAlt = trim((string) ($meta['fifu_image_alt'] ?? ''));
        if ($legacyAlt === '') {
            return false;
        }

        $db2Url = self::get_db2_term_url($termId, 'image');
        $db2Alt = self::get_db2_term_alt($termId, 'image');

        return (($db2Url !== '' || $db2Alt !== '') && !Fifu_Metadata_Db2_Cleanup_Guard::can_cleanup_url_and_alt(
            (string) ($meta['fifu_image_url'] ?? ''),
            $legacyAlt,
            $db2Url,
            $db2Alt
        ));
    }

    /**
     * @param int $termId
     * @param array<string,string> $meta
     * @return bool
     */
    private static function has_partial_db2_confirmation_for_term_video(int $termId, array $meta): bool {
        $legacyValue = trim((string) ($meta['fifu_video_url'] ?? ''));
        $db2Value = self::get_db2_term_url($termId, 'video');

        return ($db2Value !== '') && !Fifu_Metadata_Db2_Cleanup_Guard::can_cleanup_scalar($legacyValue, $db2Value);
    }

    /**
     * @param int $termId
     * @param array<string,string> $meta
     * @return void
     */
    private static function cleanup_legacy_term_image_postmeta_if_db2_matches(int $termId, array $meta): void {
        if (!function_exists('get_term_meta')) {
            return;
        }

        $legacyUrl = (string) ($meta['fifu_image_url'] ?? get_term_meta($termId, 'fifu_image_url', true));
        $legacyAlt = (string) ($meta['fifu_image_alt'] ?? get_term_meta($termId, 'fifu_image_alt', true));
        $db2Url = self::get_db2_term_url($termId, 'image');
        $db2Alt = self::get_db2_term_alt($termId, 'image');

        if (!Fifu_Metadata_Db2_Cleanup_Guard::can_cleanup_url_and_alt($legacyUrl, $legacyAlt, $db2Url, $db2Alt)) {
            return;
        }

        if ($legacyUrl !== '') {
            delete_term_meta($termId, 'fifu_image_url');
        }

        if ($legacyAlt !== '') {
            delete_term_meta($termId, 'fifu_image_alt');
        }

        clean_term_cache($termId);
        wp_cache_delete($termId, 'term_meta');
    }

    /**
     * @param int $termId
     * @param array<string,string> $meta
     * @return void
     */
    private static function cleanup_legacy_term_video_postmeta_if_db2_matches(int $termId, array $meta): void {
        if (!function_exists('get_term_meta')) {
            return;
        }

        $legacyValue = (string) ($meta['fifu_video_url'] ?? get_term_meta($termId, 'fifu_video_url', true));
        $db2Value = self::get_db2_term_url($termId, 'video');

        if (!Fifu_Metadata_Db2_Cleanup_Guard::can_cleanup_scalar($legacyValue, $db2Value)) {
            return;
        }

        if ($legacyValue !== '') {
            delete_term_meta($termId, 'fifu_video_url');
        }

        clean_term_cache($termId);
        wp_cache_delete($termId, 'term_meta');
    }

    /**
     * @param int    $postId
     * @param string $metaKey
     * @return void
     */
    private static function cleanup_legacy_gallery_list_postmeta(int $postId, string $metaKey): void {
        $wpdb = self::get_wpdb();
        $deleted = $wpdb->delete(
            $wpdb->postmeta,
            [
                'post_id' => $postId,
                'meta_key' => $metaKey,
            ],
            [
                '%d',
                '%s',
            ]
        );

        if ($deleted) {
            clean_post_cache($postId);
            wp_cache_delete($postId, 'post_meta');
        }
    }

    /**
     * @param int $postId
     * @param string $keyType
     * @return string[]
     */
    private static function get_db2_post_alt_pipe_list(int $postId, string $keyType): array {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return [];
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return [];
        }

        $mappings = $manager->getPostAltMappings($postId, $keyType);
        if (!is_array($mappings) || $mappings === []) {
            return [];
        }

        $alts = [];
        foreach ($mappings as $mapping) {
            if (!is_array($mapping)) {
                continue;
            }

            if (isset($mapping['key_type']) && (string) $mapping['key_type'] !== $keyType) {
                continue;
            }

            $alt = trim((string) ($mapping['alt'] ?? ''));
            if ($alt === '') {
                continue;
            }

            $index = isset($mapping['key_index']) ? (int) $mapping['key_index'] : 0;
            if ($index < 0) {
                continue;
            }

            $alts[$index] = $alt;
        }

        ksort($alts);

        return $alts;
    }

    /**
     * Returns DB2 post URL mappings indexed by key_index.
     *
     * @param int $postId
     * @param string $keyType
     * @return array<int, string>
     */
    private static function get_db2_post_url_map_by_index(int $postId, string $keyType): array {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return [];
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return [];
        }

        $mappings = $manager->getPostMappings($postId, $keyType);
        if (!is_array($mappings) || $mappings === []) {
            return [];
        }

        $urls = [];
        foreach ($mappings as $mapping) {
            if (!is_array($mapping)) {
                continue;
            }

            if (isset($mapping['key_type']) && (string) $mapping['key_type'] !== $keyType) {
                continue;
            }

            $url = trim((string) ($mapping['url'] ?? ''));
            if ($url === '') {
                continue;
            }

            $index = isset($mapping['key_index']) ? (int) $mapping['key_index'] : 0;
            $urls[$index] = $url;
        }

        ksort($urls);
        return $urls;
    }

    /**
     * Returns DB2 post alt mappings indexed by key_index.
     *
     * @param int $postId
     * @param string $keyType
     * @return array<int, string>
     */
    private static function get_db2_post_alt_map_by_index(int $postId, string $keyType): array {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return [];
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return [];
        }

        $mappings = $manager->getPostAltMappings($postId, $keyType);
        if (!is_array($mappings) || $mappings === []) {
            return [];
        }

        $alts = [];
        foreach ($mappings as $mapping) {
            if (!is_array($mapping)) {
                continue;
            }

            if (isset($mapping['key_type']) && (string) $mapping['key_type'] !== $keyType) {
                continue;
            }

            $alt = trim((string) ($mapping['alt'] ?? ''));
            if ($alt === '') {
                continue;
            }

            $index = isset($mapping['key_index']) ? (int) $mapping['key_index'] : 0;
            $alts[$index] = $alt;
        }

        ksort($alts);
        return $alts;
    }

    /**
     * @param int $termId
     * @param string $keyType
     * @return string
     */
    private static function get_db2_term_url(int $termId, string $keyType): string {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return '';
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return '';
        }

        $mapping = $manager->getTermMapping($termId, $keyType);
        if (!is_array($mapping)) {
            return '';
        }

        return trim((string) ($mapping['url'] ?? ''));
    }

    /**
     * @param int $termId
     * @param string $keyType
     * @return string
     */
    private static function get_db2_term_alt(int $termId, string $keyType): string {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return '';
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return '';
        }

        if (!method_exists($manager, 'getTermAltMapping')) {
            return '';
        }

        $mapping = $manager->getTermAltMapping($termId, $keyType);
        if (!is_array($mapping)) {
            return '';
        }

        return trim((string) ($mapping['alt'] ?? ''));
    }

    /**
     * @param array<int,array<string,string>> $rowsById
     * @return bool
     */
    private static function has_any_non_empty_legacy_rows(array $rowsById): bool {
        foreach ($rowsById as $row) {
            if (!is_array($row)) {
                continue;
            }

            foreach ($row as $value) {
                if (trim((string) $value) !== '') {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Build the remaining post IDs that still need the slow Woo legacy migration fallback.
     *
     * Placeholder rows returned by legacy loaders must not count as work. This keeps
     * DB2-only Image Metadata regeneration from entering migrate_woo_legacy_remote_meta_to_db2()
     * when there are no meaningful legacy values left to migrate.
     *
     * @param array<int,array<string,mixed>> $featuredMetaMap
     * @param array<int,array<string,mixed>> $galleryMetaMap
     * @param array<int,array<string,mixed>> $galleryAltsMap
     * @param array<int,array<string,mixed>> $sliderAltsMap
     * @param array<int,mixed>               $hasIndexedGalleryUrlsMap
     * @return int[]
     */
    private static function build_remaining_woo_legacy_migration_post_ids(
        array $featuredMetaMap,
        array $galleryMetaMap,
        array $galleryAltsMap,
        array $sliderAltsMap,
        array $hasIndexedGalleryUrlsMap
    ): array {
        $postIds = [];

        foreach ([$featuredMetaMap, $galleryMetaMap, $galleryAltsMap, $sliderAltsMap] as $rowsById) {
            foreach ($rowsById as $postId => $row) {
                if (!is_array($row)) {
                    continue;
                }

                foreach ($row as $value) {
                    if (trim((string) $value) !== '') {
                        $postIds[] = (int) $postId;
                        continue 2;
                    }
                }
            }
        }

        foreach ($hasIndexedGalleryUrlsMap as $postId => $hasIndexedGalleryUrls) {
            if ((bool) $hasIndexedGalleryUrls) {
                $postIds[] = (int) $postId;
            }
        }

        $postIds = array_values(array_unique(array_filter(
            $postIds,
            static fn (int $postId): bool => $postId > 0
        )));

        sort($postIds);

        return $postIds;
    }

    /**
     * Return post IDs that already have a thumbnail assigned.
     *
     * This is intentionally bulk-only for Image Metadata batches. Do not replace it
     * with get_post_meta() inside loops.
     *
     * @param array<int|string> $postIds
     * @return array<int,bool>
     */
    private static function get_existing_thumbnail_post_id_map(array $postIds): array {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($postIds);
        if ($idsCsv === '0') {
            return [];
        }

        $wpdb = self::get_wpdb();
        $rows = $wpdb->get_col("
            SELECT DISTINCT post_id
            FROM {$wpdb->postmeta}
            WHERE post_id IN ({$idsCsv})
              AND meta_key = '_thumbnail_id'
              AND meta_value IS NOT NULL
              AND meta_value <> ''
              AND meta_value <> '0'
        ");

        if (!is_array($rows)) {
            return [];
        }

        $map = [];
        foreach ($rows as $postId) {
            $intPostId = (int) $postId;
            if ($intPostId > 0) {
                $map[$intPostId] = true;
            }
        }

        return $map;
    }

    /**
     * Resolve the image URL used to create the Image Metadata attachment using only
     * metadata that was already preloaded for the current batch.
     *
     * Do not call Fifu_Post_Main_Image_Resolver here. That resolver is correct for
     * normal per-post reads, but too expensive inside 5k Image Metadata batches.
     *
     * @param array<string,string|null> $postMeta
     * @return string|null
     */
    private static function resolve_image_metadata_attachment_url_from_prefetched_meta(array $postMeta): ?string {
        $sliderUrl = self::normalize_image_metadata_url($postMeta['fifu_slider_image_url_0'] ?? null);
        if ($sliderUrl !== null) {
            if (strpos($sliderUrl, '#http') !== false) {
                $sliderUrl = substr($sliderUrl, strpos($sliderUrl, '#http') + 1);
                $sliderUrl = self::normalize_image_metadata_url($sliderUrl);
            }

            if ($sliderUrl !== null) {
                return $sliderUrl;
            }
        }

        $imageUrl = self::normalize_image_metadata_url($postMeta['fifu_image_url'] ?? null);
        $customVideoUrl = self::normalize_image_metadata_url($postMeta['fifu_custom_video_url'] ?? null);
        $videoUrl = self::normalize_image_metadata_url($postMeta['fifu_video_url'] ?? null);

        $videoCandidateUrl = null;
        if ($customVideoUrl !== null) {
            $videoCandidateUrl = $customVideoUrl;
        } elseif ($videoUrl !== null) {
            $videoCandidateUrl = $videoUrl;
        }

        if ($imageUrl !== null && $videoCandidateUrl !== null) {
            if (self::is_image_metadata_videos_before_on()) {
                $thumb = Fifu_Video_Helper::get_thumbnail_large($videoCandidateUrl);
                return self::normalize_image_metadata_url($thumb);
            }

            return $imageUrl;
        }

        if ($videoCandidateUrl !== null) {
            $thumb = Fifu_Video_Helper::get_thumbnail_large($videoCandidateUrl);
            return self::normalize_image_metadata_url($thumb);
        }

        return $imageUrl;
    }

    /**
     * @param mixed $url
     * @return string|null
     */
    private static function normalize_image_metadata_url($url): ?string {
        if (!is_string($url) && !is_numeric($url)) {
            return null;
        }

        $url = htmlspecialchars_decode((string) $url);
        $url = str_replace("'", '%27', $url);
        $url = trim($url);

        return $url !== '' ? $url : null;
    }

    private static function is_image_metadata_videos_before_on(): bool {
        if (!class_exists('Fifu_Options_Utils', false) || !method_exists('Fifu_Options_Utils', 'is_on')) {
            return false;
        }

        return (bool) Fifu_Options_Utils::is_on('fifu_videos_before');
    }

    /**
     * Keep only rows that contain at least one non-empty legacy value.
     *
     * @param array<int,array<string,string>> $rowsById
     * @return array<int,array<string,string>>
     */
    private static function filter_non_empty_legacy_rows(array $rowsById): array {
        $filtered = [];

        foreach ($rowsById as $id => $row) {
            if (!is_array($row)) {
                continue;
            }

            foreach ($row as $value) {
                if (trim((string) $value) !== '') {
                    $filtered[(int) $id] = $row;
                    break;
                }
            }
        }

        return $filtered;
    }

    /**
     * Build the payload consumed by the image-list bulk migration fast path.
     *
     * @param array<int,array<string,string>> $featuredMetaMap
     * @param array<int,array<string,string>> $galleryMetaMap
     * @param array<int,array<string,string>> $galleryAltsMap
     * @return array<int,array<string,string>>
     */
    private static function build_image_list_bulk_migration_meta_map(
        array $featuredMetaMap,
        array $galleryMetaMap,
        array $galleryAltsMap
    ): array {
        $postIds = array_unique(array_merge(
            array_keys($featuredMetaMap),
            array_keys($galleryMetaMap),
            array_keys($galleryAltsMap)
        ));

        $payload = [];

        foreach ($postIds as $postId) {
            $intPostId = (int) $postId;
            if ($intPostId <= 0) {
                continue;
            }

            $row = [];

            if (isset($featuredMetaMap[$intPostId]) && is_array($featuredMetaMap[$intPostId])) {
                $row = array_merge($row, $featuredMetaMap[$intPostId]);
            }

            if (isset($galleryMetaMap[$intPostId]) && is_array($galleryMetaMap[$intPostId])) {
                $row = array_merge($row, $galleryMetaMap[$intPostId]);
            }

            if (isset($galleryAltsMap[$intPostId]) && is_array($galleryAltsMap[$intPostId])) {
                $row = array_merge($row, $galleryAltsMap[$intPostId]);
            }

            if (self::has_non_empty_bulk_image_list_candidate($row)) {
                $payload[$intPostId] = $row;
            }
        }

        return $payload;
    }

    /**
     * @param array<string,string> $row
     */
    private static function has_non_empty_bulk_image_list_candidate(array $row): bool {
        foreach ($row as $key => $value) {
            if (
                (
                    $key === 'fifu_image_url'
                    || $key === 'fifu_image_alt'
                    || $key === 'fifu_list_url'
                    || $key === 'fifu_list_alt'
                    || preg_match('/^fifu_image_url_\d+$/', (string) $key) === 1
                    || preg_match('/^fifu_image_alt_\d+$/', (string) $key) === 1
                )
                && trim((string) $value) !== ''
            ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Bulk-migrate simple legacy featured image metadata to DB2 atomically.
     *
     * Fast path only:
     * - fifu_image_url required;
     * - fifu_image_alt optional;
     * - no video;
     * - no slider;
     * - no custom_video.
     *
     * Return values:
     * - array<int,bool>: post IDs migrated by the bulk path;
     * - []: no eligible simple image rows or DB2 fast path unavailable;
     * - false: transactional DB2/cleanup failure; rollback executed and legacy preserved.
     *
     * @param array<int,array<string,string>> $metaData
     * @return array<int,bool>|false
     */
    private static function migrate_simple_post_image_legacy_meta_to_db2_bulk(array $metaData) {
        $rows = self::build_simple_post_image_legacy_bulk_rows($metaData);
        if ($rows === []) {
            return [];
        }

        if (!class_exists('Fifu_Db2_Normalizer', false)) {
            return [];
        }

        $wpdb = self::get_wpdb();
        $prefix = $wpdb->prefix;

        $urlTable = $prefix . 'fifu_url';
        $keyTable = $prefix . 'fifu_key';
        $mapTable = $prefix . 'fifu_map';
        $altTable = $prefix . 'fifu_alt';
        $altMapTable = $prefix . 'fifu_alt_map';

        foreach ([$urlTable, $keyTable, $mapTable] as $requiredTable) {
            if (!self::table_exists($wpdb, $requiredTable)) {
                return [];
            }
        }

        $hasAltRows = false;
        foreach ($rows as $row) {
            if ((string) $row['alt'] !== '') {
                $hasAltRows = true;
                break;
            }
        }

        if ($hasAltRows) {
            foreach ([$altTable, $altMapTable] as $requiredAltTable) {
                if (!self::table_exists($wpdb, $requiredAltTable)) {
                    return [];
                }
            }
        }

        $imageKeyId = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT key_id FROM {$keyTable} WHERE key_type = %s LIMIT 1",
                'image'
            )
        );

        if ($imageKeyId <= 0) {
            return [];
        }

        $tmpTable = 'tmp_fifu_image_meta_migration_' . preg_replace('/[^a-zA-Z0-9_]/', '', uniqid('', true));

        $createTemp = $wpdb->query("
        CREATE TEMPORARY TABLE {$tmpTable} (
            post_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
            url_hash CHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
            url TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
            alt_hash CHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
            alt TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
            KEY idx_url_hash (url_hash),
            KEY idx_alt_hash (alt_hash)
        ) ENGINE=InnoDB
    ");

        if ($createTemp === false) {
            return false;
        }

        if (!self::insert_simple_post_image_legacy_stage_rows($tmpTable, $rows)) {
            $wpdb->query("DROP TEMPORARY TABLE IF EXISTS {$tmpTable}");
            return false;
        }

        $expectedUrlCount = count($rows);
        $expectedAltCount = 0;
        foreach ($rows as $row) {
            if ((string) $row['alt'] !== '') {
                $expectedAltCount++;
            }
        }

        $migratedMap = [];
        foreach ($rows as $row) {
            $migratedMap[(int) $row['post_id']] = true;
        }

        $oldSuppressErrors = $wpdb->suppress_errors();
        $wpdb->suppress_errors(true);
        $wpdb->query('START TRANSACTION');

        try {
            $result = $wpdb->query("
            INSERT INTO {$urlTable} (hash, url, w, h)
            SELECT t.url_hash, t.url, NULL, NULL
            FROM {$tmpTable} t
            ON DUPLICATE KEY UPDATE
                url = VALUES(url)
        ");

            if ($result === false) {
                throw new RuntimeException('Failed to bulk insert DB2 image URLs.');
            }

            $result = $wpdb->query(
                $wpdb->prepare(
                    "
                INSERT INTO {$mapTable} (post_id, key_id, key_index, hash)
                SELECT t.post_id, %d, 0, t.url_hash
                FROM {$tmpTable} t
                ON DUPLICATE KEY UPDATE hash = VALUES(hash)
                ",
                    $imageKeyId
                )
            );

            if ($result === false) {
                throw new RuntimeException('Failed to bulk insert DB2 image mappings.');
            }

            $confirmedUrlCount = (int) $wpdb->get_var(
                $wpdb->prepare(
                "
                SELECT COUNT(*)
                FROM {$tmpTable} t
                INNER JOIN {$mapTable} m
                    ON m.post_id = t.post_id
                   AND m.key_id = %d
                   AND m.key_index = 0
                   AND m.hash COLLATE utf8mb4_general_ci = t.url_hash COLLATE utf8mb4_general_ci
                INNER JOIN {$urlTable} u
                    ON u.hash COLLATE utf8mb4_general_ci = t.url_hash COLLATE utf8mb4_general_ci
                   AND u.url COLLATE utf8mb4_general_ci = t.url COLLATE utf8mb4_general_ci
                ",
                    $imageKeyId
                )
            );

            if ($confirmedUrlCount !== $expectedUrlCount) {
                throw new RuntimeException(
                    sprintf(
                        'DB2 image URL confirmation mismatch. expected=%d actual=%d',
                        $expectedUrlCount,
                        $confirmedUrlCount
                    )
                );
            }

            if ($expectedAltCount > 0) {
                $result = $wpdb->query("
                INSERT IGNORE INTO {$altTable} (hash, alt)
                SELECT DISTINCT t.alt_hash, t.alt
                FROM {$tmpTable} t
                WHERE t.alt <> ''
            ");

                if ($result === false) {
                    throw new RuntimeException('Failed to bulk insert DB2 image ALTs.');
                }

                $result = $wpdb->query(
                    $wpdb->prepare(
                        "
                    INSERT INTO {$altMapTable} (post_id, key_id, key_index, hash)
                    SELECT t.post_id, %d, 0, t.alt_hash
                    FROM {$tmpTable} t
                    WHERE t.alt <> ''
                    ON DUPLICATE KEY UPDATE hash = VALUES(hash)
                    ",
                        $imageKeyId
                    )
                );

                if ($result === false) {
                    throw new RuntimeException('Failed to bulk insert DB2 image ALT mappings.');
                }

                $confirmedAltCount = (int) $wpdb->get_var(
                    $wpdb->prepare(
                        "
                    SELECT COUNT(*)
                    FROM {$tmpTable} t
                    INNER JOIN {$altMapTable} m
                        ON m.post_id = t.post_id
                       AND m.key_id = %d
                       AND m.key_index = 0
                       AND m.hash COLLATE utf8mb4_general_ci = t.alt_hash COLLATE utf8mb4_general_ci
                    INNER JOIN {$altTable} a
                        ON a.hash COLLATE utf8mb4_general_ci = t.alt_hash COLLATE utf8mb4_general_ci
                       AND a.alt COLLATE utf8mb4_general_ci = t.alt COLLATE utf8mb4_general_ci
                    WHERE t.alt <> ''
                    ",
                        $imageKeyId
                    )
                );

                if ($confirmedAltCount !== $expectedAltCount) {
                    throw new RuntimeException(
                        sprintf(
                            'DB2 image ALT confirmation mismatch. expected=%d actual=%d',
                            $expectedAltCount,
                            $confirmedAltCount
                        )
                    );
                }
            }

            /*
             * Legacy cleanup is intentionally inside the same transaction as the DB2 writes.
             * If this delete fails, rollback also reverts the DB2 writes above.
             */
            $result = $wpdb->query("
            DELETE pm
            FROM {$wpdb->postmeta} pm
            INNER JOIN {$tmpTable} t ON t.post_id = pm.post_id
            WHERE pm.meta_key IN ('fifu_image_url', 'fifu_image_alt')
        ");

            if ($result === false) {
                throw new RuntimeException('Failed to bulk delete legacy featured image metadata.');
            }

            $wpdb->query('COMMIT');
        } catch (Throwable $throwable) {
            $wpdb->query('ROLLBACK');
            $wpdb->query("DROP TEMPORARY TABLE IF EXISTS {$tmpTable}");
            $wpdb->suppress_errors($oldSuppressErrors);
            return false;
        }

        $wpdb->query("DROP TEMPORARY TABLE IF EXISTS {$tmpTable}");
        $wpdb->suppress_errors($oldSuppressErrors);

        self::clear_post_meta_cache_for_post_ids(array_keys($migratedMap));
        foreach (array_keys($migratedMap) as $migratedPostId) {
            $altRows = $wpdb->get_results($wpdb->prepare(
                "SELECT m.key_index, a.alt
                 FROM {$altMapTable} m
                 INNER JOIN {$altTable} a ON a.hash = m.hash
                 WHERE m.post_id = %d
                   AND m.key_id = %d
                 ORDER BY m.key_index ASC",
                (int) $migratedPostId,
                $imageKeyId
            ), ARRAY_A);
        }

        return $migratedMap;
    }

    /**
     * Bulk-migrate clean legacy indexed slider metadata to DB2 atomically.
     *
     * @param array<int,array<string,string>> $metaData
     * @return array<int,bool>|false
     */
    private static function migrate_indexed_slider_legacy_meta_to_db2_bulk(array $metaData) {
        foreach ($metaData as $postId => $sourceMeta) {
            $metaData[(int) $postId] = self::apply_indexed_slider_list_alt_fallback((array) $sourceMeta);
        }

        $rows = self::build_indexed_slider_legacy_bulk_rows($metaData);
        if ($rows === []) {
            return [];
        }

        if (!class_exists('Fifu_Db2_Normalizer', false)) {
            return [];
        }

        $wpdb = self::get_wpdb();
        $prefix = $wpdb->prefix;

        $urlTable = $prefix . 'fifu_url';
        $keyTable = $prefix . 'fifu_key';
        $mapTable = $prefix . 'fifu_map';
        $altTable = $prefix . 'fifu_alt';
        $altMapTable = $prefix . 'fifu_alt_map';

        foreach ([$urlTable, $keyTable, $mapTable] as $requiredTable) {
            if (!self::table_exists($wpdb, $requiredTable)) {
                return [];
            }
        }

        $hasAltRows = false;
        foreach ($rows as $row) {
            if ((string) $row['alt'] !== '') {
                $hasAltRows = true;
                break;
            }
        }

        if ($hasAltRows) {
            foreach ([$altTable, $altMapTable] as $requiredAltTable) {
                if (!self::table_exists($wpdb, $requiredAltTable)) {
                    return [];
                }
            }
        }

        $sliderKeyId = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT key_id FROM {$keyTable} WHERE key_type = %s LIMIT 1",
                'slider'
            )
        );

        if ($sliderKeyId <= 0) {
            return [];
        }

        $tmpTable = 'tmp_fifu_slider_meta_migration_' . preg_replace('/[^a-zA-Z0-9_]/', '', uniqid('', true));

        $createTemp = $wpdb->query("
        CREATE TEMPORARY TABLE {$tmpTable} (
            post_id BIGINT UNSIGNED NOT NULL,
            key_index INT UNSIGNED NOT NULL,
            url_hash CHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
            url TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
            alt_hash CHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
            alt TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
            KEY idx_post_id (post_id),
            KEY idx_url_hash (url_hash),
            KEY idx_alt_hash (alt_hash)
        ) ENGINE=InnoDB
    ");

        if ($createTemp === false) {
            return false;
        }

        if (!self::insert_indexed_slider_legacy_stage_rows($tmpTable, $rows)) {
            $wpdb->query("DROP TEMPORARY TABLE IF EXISTS {$tmpTable}");
            return false;
        }

        $expectedUrlCount = count($rows);
        $expectedAltCount = 0;
        foreach ($rows as $row) {
            if ((string) $row['alt'] !== '') {
                $expectedAltCount++;
            }
        }

        $migratedMap = [];
        foreach ($rows as $row) {
            $migratedMap[(int) $row['post_id']] = true;
        }

        $oldSuppressErrors = $wpdb->suppress_errors();
        $wpdb->suppress_errors(true);
        $wpdb->query('START TRANSACTION');

        try {
            $result = $wpdb->query("
            INSERT INTO {$urlTable} (hash, url, w, h)
            SELECT t.url_hash, t.url, NULL, NULL
            FROM {$tmpTable} t
            ON DUPLICATE KEY UPDATE
                url = VALUES(url)
        ");

            if ($result === false) {
                throw new RuntimeException('Failed to bulk insert DB2 slider URLs.');
            }

            $result = $wpdb->query(
                $wpdb->prepare(
                    "
                INSERT INTO {$mapTable} (post_id, key_id, key_index, hash)
                SELECT t.post_id, %d, t.key_index, t.url_hash
                FROM {$tmpTable} t
                ON DUPLICATE KEY UPDATE hash = VALUES(hash)
                ",
                    $sliderKeyId
                )
            );

            if ($result === false) {
                throw new RuntimeException('Failed to bulk insert DB2 slider mappings.');
            }

            $confirmedUrlCount = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "
                SELECT COUNT(*)
                FROM {$tmpTable} t
                INNER JOIN {$mapTable} m
                    ON m.post_id = t.post_id
                   AND m.key_id = %d
                   AND m.key_index = t.key_index
                   AND m.hash COLLATE utf8mb4_general_ci = t.url_hash COLLATE utf8mb4_general_ci
                INNER JOIN {$urlTable} u
                    ON u.hash COLLATE utf8mb4_general_ci = t.url_hash COLLATE utf8mb4_general_ci
                   AND u.url COLLATE utf8mb4_general_ci = t.url COLLATE utf8mb4_general_ci
                ",
                    $sliderKeyId
                )
            );

            if ($confirmedUrlCount !== $expectedUrlCount) {
                throw new RuntimeException(
                    sprintf(
                        'DB2 slider URL confirmation mismatch. expected=%d actual=%d',
                        $expectedUrlCount,
                        $confirmedUrlCount
                    )
                );
            }

            if ($expectedAltCount > 0) {
                $result = $wpdb->query("
                INSERT IGNORE INTO {$altTable} (hash, alt)
                SELECT DISTINCT t.alt_hash, t.alt
                FROM {$tmpTable} t
                WHERE t.alt <> ''
            ");

                if ($result === false) {
                    throw new RuntimeException('Failed to bulk insert DB2 slider ALTs.');
                }

                $result = $wpdb->query(
                    $wpdb->prepare(
                        "
                    INSERT INTO {$altMapTable} (post_id, key_id, key_index, hash)
                    SELECT t.post_id, %d, t.key_index, t.alt_hash
                    FROM {$tmpTable} t
                    WHERE t.alt <> ''
                    ON DUPLICATE KEY UPDATE hash = VALUES(hash)
                    ",
                        $sliderKeyId
                    )
                );

                if ($result === false) {
                    throw new RuntimeException('Failed to bulk insert DB2 slider ALT mappings.');
                }

                $confirmedAltCount = (int) $wpdb->get_var(
                    $wpdb->prepare(
                        "
                    SELECT COUNT(*)
                    FROM {$tmpTable} t
                    INNER JOIN {$altMapTable} m
                        ON m.post_id = t.post_id
                       AND m.key_id = %d
                       AND m.key_index = t.key_index
                       AND m.hash COLLATE utf8mb4_general_ci = t.alt_hash COLLATE utf8mb4_general_ci
                    INNER JOIN {$altTable} a
                        ON a.hash COLLATE utf8mb4_general_ci = t.alt_hash COLLATE utf8mb4_general_ci
                       AND a.alt COLLATE utf8mb4_general_ci = t.alt COLLATE utf8mb4_general_ci
                    WHERE t.alt <> ''
                    ",
                        $sliderKeyId
                    )
                );

                if ($confirmedAltCount !== $expectedAltCount) {
                    throw new RuntimeException(
                        sprintf(
                            'DB2 slider ALT confirmation mismatch. expected=%d actual=%d',
                            $expectedAltCount,
                            $confirmedAltCount
                        )
                    );
                }
            }

            $result = $wpdb->query("
            DELETE pm
            FROM {$wpdb->postmeta} pm
            INNER JOIN (
                SELECT DISTINCT post_id FROM {$tmpTable}
            ) migrated ON migrated.post_id = pm.post_id
            WHERE pm.meta_key REGEXP '^fifu_slider_image_url_[0-9]+$'
               OR pm.meta_key REGEXP '^fifu_slider_image_alt_[0-9]+$'
        ");

            if ($result === false) {
                throw new RuntimeException('Failed to bulk delete legacy slider metadata.');
            }

            $wpdb->query('COMMIT');
        } catch (Throwable $throwable) {
            $wpdb->query('ROLLBACK');
            $wpdb->query("DROP TEMPORARY TABLE IF EXISTS {$tmpTable}");
            $wpdb->suppress_errors($oldSuppressErrors);
            return false;
        }

        $wpdb->query("DROP TEMPORARY TABLE IF EXISTS {$tmpTable}");
        $wpdb->suppress_errors($oldSuppressErrors);

        self::clear_post_meta_cache_for_post_ids(array_keys($migratedMap));
        foreach (array_keys($migratedMap) as $migratedPostId) {
            $altRows = $wpdb->get_results($wpdb->prepare(
                "SELECT m.key_index, a.alt
                 FROM {$altMapTable} m
                 INNER JOIN {$altTable} a ON a.hash = m.hash
                 WHERE m.post_id = %d
                   AND m.key_id = %d
                 ORDER BY m.key_index ASC",
                (int) $migratedPostId,
                $sliderKeyId
            ), ARRAY_A);
        }

        return $migratedMap;
    }

    /**
     * Load indexed slider metadata directly from wp_postmeta for bulk migration.
     *
     * @param array<int> $postIds
     * @return array<int,array<string,string>>
     */
    private static function load_indexed_slider_bulk_migration_meta_map_for_post_ids(array $postIds): array
    {
        global $wpdb;

        $postIds = array_values(array_unique(array_filter(array_map('intval', $postIds), static function ($postId) {
            return $postId > 0;
        })));

        if (!$postIds) {
            return [];
        }

        $map = [];

        foreach (array_chunk($postIds, 1000) as $chunk) {
            $placeholders = implode(',', array_fill(0, count($chunk), '%d'));

            $sql = "
                SELECT post_id, meta_key, meta_value
                FROM {$wpdb->postmeta}
                WHERE post_id IN ({$placeholders})
                  AND (
                       meta_key = 'fifu_slider_list_alt'
                    OR meta_key REGEXP '^fifu_slider_image_url_[0-9]+$'
                    OR meta_key REGEXP '^fifu_slider_image_alt_[0-9]+$'
                  )
            ";

            $rows = $wpdb->get_results($wpdb->prepare($sql, $chunk), ARRAY_A);

            foreach ((array) $rows as $row) {
                $postId = (int) $row['post_id'];
                $key = (string) $row['meta_key'];
                $value = (string) $row['meta_value'];

                if (!isset($map[$postId])) {
                    $map[$postId] = [];
                }

                $map[$postId][$key] = $value;
            }
        }

        return $map;
    }

    /**
     * Hydrate Woo featured metadata from clean indexed slider payloads.
     *
     * @param array<int,array<string,string>> $legacyFeaturedMetaMap
     * @param array<int,array<string,string>> $legacyGalleryMetaMap
     */
    private static function build_clean_indexed_slider_featured_url_map(array $legacyGalleryMetaMap): array
    {
        $payload = self::build_indexed_slider_bulk_migration_meta_map($legacyGalleryMetaMap);
        $map = [];

        foreach ($payload as $postId => $meta) {
            $url = trim((string) ($meta['fifu_slider_image_url_0'] ?? ''));
            if ($url !== '') {
                $map[(int) $postId] = $url;
            }
        }

        return $map;
    }

    /**
     * Bulk-migrate simple legacy image-list metadata to DB2 atomically.
     *
     * Fast path only:
     * - image/indexed image/list image fields;
     * - optional image/indexed/list ALT fields;
     * - no video;
     * - no slider;
     * - no custom video.
     *
     * @param array<int,array<string,string>> $metaData
     * @return array<int,bool>|false
     */
    private static function migrate_simple_post_image_list_legacy_meta_to_db2_bulk(array $metaData) {
        $rows = self::build_simple_post_image_list_legacy_bulk_rows($metaData);
        if ($rows === []) {
            return [];
        }

        if (!class_exists('Fifu_Db2_Normalizer', false)) {
            return [];
        }

        $wpdb = self::get_wpdb();
        $prefix = $wpdb->prefix;

        $urlTable = $prefix . 'fifu_url';
        $keyTable = $prefix . 'fifu_key';
        $mapTable = $prefix . 'fifu_map';
        $altTable = $prefix . 'fifu_alt';
        $altMapTable = $prefix . 'fifu_alt_map';

        foreach ([$urlTable, $keyTable, $mapTable] as $requiredTable) {
            if (!self::table_exists($wpdb, $requiredTable)) {
                return [];
            }
        }

        $hasAltRows = false;
        foreach ($rows as $row) {
            if ((string) $row['alt'] !== '') {
                $hasAltRows = true;
                break;
            }
        }

        if ($hasAltRows) {
            foreach ([$altTable, $altMapTable] as $requiredAltTable) {
                if (!self::table_exists($wpdb, $requiredAltTable)) {
                    return [];
                }
            }
        }

        $imageKeyId = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT key_id FROM {$keyTable} WHERE key_type = %s LIMIT 1",
                'image'
            )
        );

        if ($imageKeyId <= 0) {
            return [];
        }

        $tmpTable = 'tmp_fifu_image_list_meta_migration_' . preg_replace('/[^a-zA-Z0-9_]/', '', uniqid('', true));

        $createTemp = $wpdb->query("
        CREATE TEMPORARY TABLE {$tmpTable} (
            post_id BIGINT UNSIGNED NOT NULL,
            key_index INT UNSIGNED NOT NULL,
            url_hash CHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
            url TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
            alt_hash CHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
            alt TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
            PRIMARY KEY (post_id, key_index),
            KEY idx_url_hash (url_hash),
            KEY idx_alt_hash (alt_hash)
        ) ENGINE=InnoDB
    ");

        if ($createTemp === false) {
            return false;
        }

        if (!self::insert_simple_post_image_list_legacy_stage_rows($tmpTable, $rows)) {
            $wpdb->query("DROP TEMPORARY TABLE IF EXISTS {$tmpTable}");
            return false;
        }

        $expectedUrlCount = count($rows);
        $expectedAltCount = 0;
        $migratedMap = [];

        foreach ($rows as $row) {
            $migratedMap[(int) $row['post_id']] = true;
            if ((string) $row['alt'] !== '') {
                $expectedAltCount++;
            }
        }

        $oldSuppressErrors = $wpdb->suppress_errors();
        $wpdb->suppress_errors(true);
        $wpdb->query('START TRANSACTION');

        try {
            $result = $wpdb->query("
            INSERT INTO {$urlTable} (hash, url, w, h)
            SELECT DISTINCT t.url_hash, t.url, NULL, NULL
            FROM {$tmpTable} t
            ON DUPLICATE KEY UPDATE
                url = VALUES(url)
        ");

            if ($result === false) {
                throw new RuntimeException('Failed to bulk insert DB2 image-list URLs.');
            }

            $result = $wpdb->query(
                $wpdb->prepare(
                    "
                INSERT INTO {$mapTable} (post_id, key_id, key_index, hash)
                SELECT t.post_id, %d, t.key_index, t.url_hash
                FROM {$tmpTable} t
                ON DUPLICATE KEY UPDATE hash = VALUES(hash)
                ",
                    $imageKeyId
                )
            );

            if ($result === false) {
                throw new RuntimeException('Failed to bulk insert DB2 image-list mappings.');
            }

            $confirmedUrlCount = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "
                SELECT COUNT(*)
                FROM {$tmpTable} t
                INNER JOIN {$mapTable} m
                    ON m.post_id = t.post_id
                   AND m.key_id = %d
                   AND m.key_index = t.key_index
                   AND m.hash COLLATE utf8mb4_general_ci = t.url_hash COLLATE utf8mb4_general_ci
                INNER JOIN {$urlTable} u
                    ON u.hash COLLATE utf8mb4_general_ci = t.url_hash COLLATE utf8mb4_general_ci
                   AND u.url COLLATE utf8mb4_general_ci = t.url COLLATE utf8mb4_general_ci
                ",
                    $imageKeyId
                )
            );

            if ($confirmedUrlCount !== $expectedUrlCount) {
                throw new RuntimeException(
                    sprintf(
                        'DB2 image-list URL confirmation mismatch. expected=%d actual=%d',
                        $expectedUrlCount,
                        $confirmedUrlCount
                    )
                );
            }

            if ($expectedAltCount > 0) {
                $result = $wpdb->query("
                INSERT IGNORE INTO {$altTable} (hash, alt)
                SELECT DISTINCT t.alt_hash, t.alt
                FROM {$tmpTable} t
                WHERE t.alt <> ''
            ");

                if ($result === false) {
                    throw new RuntimeException('Failed to bulk insert DB2 image-list ALTs.');
                }

                $result = $wpdb->query(
                    $wpdb->prepare(
                        "
                    INSERT INTO {$altMapTable} (post_id, key_id, key_index, hash)
                    SELECT t.post_id, %d, t.key_index, t.alt_hash
                    FROM {$tmpTable} t
                    WHERE t.alt <> ''
                    ON DUPLICATE KEY UPDATE hash = VALUES(hash)
                    ",
                        $imageKeyId
                    )
                );

                if ($result === false) {
                    throw new RuntimeException('Failed to bulk insert DB2 image-list ALT mappings.');
                }

                $confirmedAltCount = (int) $wpdb->get_var(
                    $wpdb->prepare(
                        "
                    SELECT COUNT(*)
                    FROM {$tmpTable} t
                    INNER JOIN {$altMapTable} m
                        ON m.post_id = t.post_id
                       AND m.key_id = %d
                       AND m.key_index = t.key_index
                       AND m.hash COLLATE utf8mb4_general_ci = t.alt_hash COLLATE utf8mb4_general_ci
                    INNER JOIN {$altTable} a
                        ON a.hash COLLATE utf8mb4_general_ci = t.alt_hash COLLATE utf8mb4_general_ci
                       AND a.alt COLLATE utf8mb4_general_ci = t.alt COLLATE utf8mb4_general_ci
                    WHERE t.alt <> ''
                    ",
                        $imageKeyId
                    )
                );

                if ($confirmedAltCount !== $expectedAltCount) {
                    throw new RuntimeException(
                        sprintf(
                            'DB2 image-list ALT confirmation mismatch. expected=%d actual=%d',
                            $expectedAltCount,
                            $confirmedAltCount
                        )
                    );
                }
            }

            $result = $wpdb->query("
            DELETE pm
            FROM {$wpdb->postmeta} pm
            INNER JOIN (
                SELECT DISTINCT post_id FROM {$tmpTable}
            ) migrated ON migrated.post_id = pm.post_id
            WHERE pm.meta_key IN ('fifu_image_url', 'fifu_image_alt', 'fifu_list_url', 'fifu_list_alt')
               OR pm.meta_key REGEXP '^fifu_image_url_[0-9]+$'
               OR pm.meta_key REGEXP '^fifu_image_alt_[0-9]+$'
        ");

            if ($result === false) {
                throw new RuntimeException('Failed to bulk delete legacy image-list metadata.');
            }

            $wpdb->query('COMMIT');
        } catch (Throwable $throwable) {
            $wpdb->query('ROLLBACK');
            $wpdb->query("DROP TEMPORARY TABLE IF EXISTS {$tmpTable}");
            $wpdb->suppress_errors($oldSuppressErrors);
            return false;
        }

        $wpdb->query("DROP TEMPORARY TABLE IF EXISTS {$tmpTable}");
        $wpdb->suppress_errors($oldSuppressErrors);

        self::clear_post_meta_cache_for_post_ids(array_keys($migratedMap));

        return $migratedMap;
    }

    /**
     * Public wrapper for metadata-post bulk sync callers.
     *
     * @param array<int,array<string,string>> $metaData
     * @return array<int,bool>|false
     */
    public static function migrate_simple_post_image_list_legacy_meta_to_db2_for_metadata_post_bulk(array $metaData) {
        return self::migrate_simple_post_image_list_legacy_meta_to_db2_bulk($metaData);
    }

    /**
     * Public wrapper for metadata-post bulk legacy indexed-slider migration.
     *
     * @param array<int,array<string,string>> $metaData
     * @return array<int,bool>|false
     */
    public static function migrate_indexed_slider_legacy_meta_to_db2_for_metadata_post_bulk(array $metaData) {
        return self::migrate_indexed_slider_legacy_meta_to_db2_bulk($metaData);
    }

    /**
     * Build normalized rows for the atomic simple-image bulk migration.
     *
     * Rows with video/slider/custom video are intentionally excluded and must use
     * the existing old path.
     *
     * @param array<int,array<string,string>> $metaData
     * @return array<int,array{post_id:int,url_hash:string,url:string,alt_hash:string,alt:string}>
     */
    private static function get_post_ids_with_db2_image_mapping(array $postIds): array {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($postIds);
        if ($idsCsv === '0') {
            return [];
        }

        $wpdb = self::get_wpdb();
        $prefix = $wpdb->prefix;

        $mapTable = $prefix . 'fifu_map';
        $keyTable = $prefix . 'fifu_key';

        if (!self::table_exists($wpdb, $mapTable) || !self::table_exists($wpdb, $keyTable)) {
            return [];
        }

        $rows = $wpdb->get_col("
            SELECT DISTINCT m.post_id
            FROM {$mapTable} m
            INNER JOIN {$keyTable} k ON k.key_id = m.key_id
            WHERE m.post_id IN ({$idsCsv})
              AND k.key_type = 'image'
              AND m.key_index = 0
        ");

        if (!is_array($rows)) {
            return [];
        }

        $map = [];
        foreach ($rows as $postId) {
            $intPostId = (int) $postId;
            if ($intPostId > 0) {
                $map[$intPostId] = true;
            }
        }

        return $map;
    }

    private static function get_post_ids_with_db2_image_alt_mapping(array $postIds): array {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($postIds);
        if ($idsCsv === '0') {
            return [];
        }

        $wpdb = self::get_wpdb();
        $prefix = $wpdb->prefix;

        $altMapTable = $prefix . 'fifu_alt_map';
        $keyTable = $prefix . 'fifu_key';

        if (!self::table_exists($wpdb, $altMapTable) || !self::table_exists($wpdb, $keyTable)) {
            return [];
        }

        $rows = $wpdb->get_col("
            SELECT DISTINCT m.post_id
            FROM {$altMapTable} m
            INNER JOIN {$keyTable} k ON k.key_id = m.key_id
            WHERE m.post_id IN ({$idsCsv})
              AND k.key_type = 'image'
              AND m.key_index = 0
        ");

        if (!is_array($rows)) {
            return [];
        }

        $map = [];
        foreach ($rows as $postId) {
            $intPostId = (int) $postId;
            if ($intPostId > 0) {
                $map[$intPostId] = true;
            }
        }

        return $map;
    }

    private static function build_simple_post_image_legacy_bulk_rows(array $metaData): array {
        $rows = [];
        $postIds = array_keys($metaData);
        $postsWithDb2ImageMapping = self::get_post_ids_with_db2_image_mapping($postIds);
        $postsWithDb2ImageAltMapping = self::get_post_ids_with_db2_image_alt_mapping($postIds);

        foreach ($metaData as $postId => $meta) {
            $intPostId = (int) $postId;
            if ($intPostId <= 0 || !is_array($meta)) {
                continue;
            }

            $legacyImageUrl = trim((string) ($meta['fifu_image_url'] ?? ''));
            if ($legacyImageUrl === '') {
                continue;
            }

            /*
             * Keep complex media states out of this fast path.
             */
            if (
                trim((string) ($meta['fifu_video_url'] ?? '')) !== ''
                || trim((string) ($meta['fifu_slider_image_url_0'] ?? '')) !== ''
                || trim((string) ($meta['fifu_custom_video_url'] ?? '')) !== ''
            ) {
                continue;
            }

            $convertedUrl = function_exists('fifu_convert')
                ? fifu_convert($legacyImageUrl)
                : $legacyImageUrl;

            $normalizedUrl = class_exists('Fifu_Db2_Normalizer', false)
                ? Fifu_Db2_Normalizer::normalize_url((string) $convertedUrl)
                : null;

            if ($normalizedUrl === null) {
                continue;
            }

            $legacyAltRaw = (string) ($meta['fifu_image_alt'] ?? '');
            $legacyAltTrimmed = trim($legacyAltRaw);
            $normalizedAlt = '';

            if ($legacyAltTrimmed !== '') {
                $normalizedAltValue = class_exists('Fifu_Db2_Normalizer', false)
                    ? Fifu_Db2_Normalizer::normalize_alt($legacyAltRaw)
                    : null;

                /*
                 * Do not bulk-clean a non-empty legacy ALT that cannot be represented
                 * safely in DB2. Keep this post in the old/safe path instead.
                 */
                if ($normalizedAltValue === null) {
                    continue;
                }

                $normalizedAlt = $normalizedAltValue;
            }

            $hasDb2ImageMapping = isset($postsWithDb2ImageMapping[$intPostId]);
            $hasDb2ImageAltMapping = isset($postsWithDb2ImageAltMapping[$intPostId]);

            if (
                ($hasDb2ImageMapping && !$hasDb2ImageAltMapping)
                || (!$hasDb2ImageMapping && $hasDb2ImageAltMapping)
            ) {
                continue;
            }

            $rows[$intPostId] = [
                'post_id' => $intPostId,
                'url_hash' => md5($normalizedUrl),
                'url' => $normalizedUrl,
                'alt_hash' => $normalizedAlt !== '' ? md5($normalizedAlt) : '',
                'alt' => $normalizedAlt,
            ];
        }

        return $rows;
    }

    /**
     * @param array<int,array<string,string>> $metaData
     * @return array<int,array{post_id:int,key_index:int,url_hash:string,url:string,alt_hash:string,alt:string}>
     */
    private static function build_simple_post_image_list_legacy_bulk_rows(array $metaData): array {
        $rows = [];
        /*
         * Image Metadata may run the featured-image post queue before the Woo/gallery queue.
         * In that runtime sequence, DB2 image index 0 already exists and the legacy payload
         * may contain only gallery fields such as fifu_image_url_0, fifu_image_url_1, etc.
         */
        $postsWithDb2ImageIndexZero = self::get_post_ids_with_db2_image_mapping(array_keys($metaData));

        foreach ($metaData as $postId => $meta) {
            $intPostId = (int) $postId;
            if ($intPostId <= 0 || !is_array($meta)) {
                continue;
            }

            if (self::has_complex_media_for_image_list_bulk_migration($meta)) {
                continue;
            }

            $directUrls = self::extract_direct_image_url_map_for_bulk_migration($meta);
            $usesDirectIndexedFields = $directUrls !== [];

            if ($usesDirectIndexedFields) {
                $urls = $directUrls;
                $alts = self::extract_direct_image_alt_map_for_bulk_migration($meta);
            } else {
                $urls = self::parse_legacy_gallery_pipe_values((string) ($meta['fifu_list_url'] ?? ''));
                $alts = self::parse_legacy_gallery_alt_values((string) ($meta['fifu_list_alt'] ?? ''));
            }

            if ($urls === []) {
                continue;
            }

            ksort($urls, SORT_NUMERIC);

            if ($usesDirectIndexedFields) {
                if (array_key_exists(0, $urls)) {
                    /*
                     * Full direct/indexed payload:
                     * fifu_image_url -> index 0,
                     * fifu_image_url_0 -> index 1, etc.
                     */
                    if (!self::is_sequential_int_map_from_start($urls, 0)) {
                        continue;
                    }
                } else {
                    /*
                     * Runtime Woo/gallery-only payload:
                     * DB2 already has image index 0, and legacy has only gallery fields:
                     * fifu_image_url_0 -> index 1,
                     * fifu_image_url_1 -> index 2, etc.
                     */
                    if (!isset($postsWithDb2ImageIndexZero[$intPostId])) {
                        continue;
                    }

                    if (!self::is_sequential_int_map_from_start($urls, 1)) {
                        continue;
                    }
                }
            } elseif (!self::is_sequential_int_map_from_start($urls, 0)) {
                continue;
            }

            foreach ($urls as $index => $url) {
                $url = htmlspecialchars_decode(trim((string) $url));
                if ($url === '') {
                    continue 2;
                }

                if (class_exists('Fifu_Video_Helper', false) && Fifu_Video_Helper::is_video($url)) {
                    continue 2;
                }

                $convertedUrl = function_exists('fifu_convert') ? fifu_convert($url) : $url;
                $normalizedUrl = class_exists('Fifu_Db2_Normalizer', false)
                    ? Fifu_Db2_Normalizer::normalize_url((string) $convertedUrl)
                    : null;

                if ($normalizedUrl === null) {
                    continue 2;
                }

                $altRaw = (string) ($alts[(int) $index] ?? '');
                $alt = '';

                if (trim($altRaw) !== '') {
                    $normalizedAlt = class_exists('Fifu_Db2_Normalizer', false)
                        ? Fifu_Db2_Normalizer::normalize_alt($altRaw)
                        : null;

                    if ($normalizedAlt === null) {
                        continue 2;
                    }

                    $alt = $normalizedAlt;
                }

                $rows[] = [
                    'post_id' => $intPostId,
                    'key_index' => (int) $index,
                    'url_hash' => md5($normalizedUrl),
                    'url' => $normalizedUrl,
                    'alt_hash' => $alt !== '' ? md5($alt) : '',
                    'alt' => $alt,
                ];
            }
        }

        return $rows;
    }

    /**
     * Build DB2-ready rows for clean legacy indexed slider metadata.
     *
     * @param array<int,array<string,string>> $metaData
     * @return array<int,array{post_id:int,key_index:int,url_hash:string,url:string,alt_hash:string,alt:string}>
     */
    private static function build_indexed_slider_legacy_bulk_rows(array $metaData): array {
        $rows = [];

        foreach ($metaData as $postId => $meta) {
            $intPostId = (int) $postId;
            if ($intPostId <= 0 || !is_array($meta)) {
                continue;
            }

            if (!self::is_clean_indexed_slider_legacy_meta($meta)) {
                continue;
            }

            $urls = self::extract_indexed_legacy_values($meta, 'fifu_slider_image_url_');
            if (!isset($urls[0]) || trim((string) $urls[0]) === '') {
                continue;
            }

            ksort($urls, SORT_NUMERIC);

            $expected = 0;
            foreach (array_keys($urls) as $index) {
                if ((int) $index !== $expected) {
                    continue 2;
                }
                $expected++;
            }

            $indexedAlts = self::extract_indexed_legacy_values($meta, 'fifu_slider_image_alt_');
            $listAlts = self::parse_legacy_alt_list((string) ($meta['fifu_slider_list_alt'] ?? ''));

            foreach ($urls as $index => $url) {
                $url = htmlspecialchars_decode(trim((string) $url));
                if ($url === '') {
                    continue 2;
                }

                if (class_exists('Fifu_Video_Helper', false) && Fifu_Video_Helper::is_video($url)) {
                    $url = Fifu_Video_Helper::get_thumbnail_large($url);
                }

                $convertedUrl = function_exists('fifu_convert') ? fifu_convert($url) : $url;
                $normalizedUrl = class_exists('Fifu_Db2_Normalizer', false)
                    ? Fifu_Db2_Normalizer::normalize_url((string) $convertedUrl)
                    : trim((string) $convertedUrl);

                if ($normalizedUrl === null || trim((string) $normalizedUrl) === '') {
                    continue 2;
                }

                $alt = '';
                $rawAlt = trim((string) ($indexedAlts[(int) $index] ?? ''));
                if ($rawAlt === '') {
                    $rawAlt = trim((string) ($listAlts[(int) $index] ?? ''));
                }
                if (trim($rawAlt) !== '') {
                    $normalizedAlt = class_exists('Fifu_Db2_Normalizer', false)
                        ? Fifu_Db2_Normalizer::normalize_alt($rawAlt)
                        : trim($rawAlt);

                    if ($normalizedAlt === null) {
                        continue 2;
                    }

                    $alt = trim((string) $normalizedAlt);
                }

                $rows[] = [
                    'post_id' => $intPostId,
                    'key_index' => (int) $index,
                    'url_hash' => md5((string) $normalizedUrl),
                    'url' => (string) $normalizedUrl,
                    'alt_hash' => $alt !== '' ? md5($alt) : '',
                    'alt' => $alt,
                ];
            }
        }

        return $rows;
    }

    private static function parse_legacy_alt_list(string $raw): array {
        $raw = trim($raw);
        if ($raw === '') {
            return [];
        }

        $parts = explode('|', $raw);
        $alts = [];
        foreach ($parts as $index => $part) {
            $alt = trim((string) $part);
            if ($alt !== '') {
                $alts[(int) $index] = $alt;
            }
        }

        return $alts;
    }

    private static function extract_indexed_legacy_values(array $meta, string $prefix): array {
        $values = [];

        foreach ($meta as $key => $value) {
            $key = (string) $key;

            if (preg_match('/^' . preg_quote($prefix, '/') . '(\d+)$/', $key, $matches) !== 1) {
                continue;
            }

            $values[(int) $matches[1]] = (string) $value;
        }

        return $values;
    }

    private static function is_clean_indexed_slider_legacy_meta(array $meta): bool {
        $hasSliderUrl0 = trim((string) ($meta['fifu_slider_image_url_0'] ?? '')) !== '';
        if (!$hasSliderUrl0) {
            return false;
        }

        foreach ($meta as $key => $value) {
            $key = (string) $key;
            $value = trim((string) $value);

            if ($value === '') {
                continue;
            }

            if (
                preg_match('/^fifu_slider_image_url_\d+$/', $key) === 1
                || preg_match('/^fifu_slider_image_alt_\d+$/', $key) === 1
            ) {
                continue;
            }

            if ($key === 'fifu_slider_list_alt') {
                continue;
            }

            if ($key === 'fifu_slider_list_url') {
                return false;
            }

            if (
                $key === 'fifu_image_url'
                || $key === 'fifu_image_alt'
                || $key === 'fifu_video_url'
                || $key === 'fifu_custom_video_url'
                || $key === 'fifu_list_url'
                || $key === 'fifu_list_video_url'
                || preg_match('/^fifu_image_url_\d+$/', $key) === 1
                || preg_match('/^fifu_image_alt_\d+$/', $key) === 1
                || preg_match('/^fifu_video_url_\d+$/', $key) === 1
            ) {
                return false;
            }
        }

        return true;
    }

    private static function build_indexed_slider_bulk_migration_meta_map(
        array $legacyGalleryMetaMap,
        array $legacySliderAltsMap = []
    ): array {
        $payload = [];
        $sourceMetaByPost = self::load_slider_source_meta_for_post_ids(array_keys($legacyGalleryMetaMap));

        foreach ($legacyGalleryMetaMap as $postId => $meta) {
            $intPostId = (int) $postId;
            if ($intPostId <= 0 || !is_array($meta)) {
                continue;
            }

            $sourceMeta = $sourceMetaByPost[$intPostId] ?? [];
            $sourceListAlt = trim((string) get_post_meta($intPostId, 'fifu_slider_list_alt', true));
            if ($sourceListAlt !== '') {
                $sourceMeta['fifu_slider_list_alt'] = $sourceListAlt;
            }
            if (trim((string) ($sourceMeta['fifu_slider_list_url'] ?? '')) !== '') {
                continue;
            }

            if (trim((string) ($sourceMeta['fifu_slider_image_url_0'] ?? '')) === '') {
                continue;
            }

            $sourceMeta = self::apply_indexed_slider_list_alt_fallback($sourceMeta);
            $merged = $sourceMeta;

            if (isset($legacySliderAltsMap[$intPostId]) && is_array($legacySliderAltsMap[$intPostId])) {
                foreach ($legacySliderAltsMap[$intPostId] as $key => $value) {
                    $key = (string) $key;
                    $value = (string) $value;
                    if ($value === '') {
                        continue;
                    }

                    if (!array_key_exists($key, $merged) || trim((string) $merged[$key]) === '') {
                        $merged[$key] = $value;
                    }
                }
            }
            if (self::is_clean_indexed_slider_legacy_meta($merged)) {
                $payload[$intPostId] = $merged;
            }
        }

        return $payload;
    }

    private static function apply_indexed_slider_list_alt_fallback(array $sourceMeta): array
    {
        $listAltRaw = trim((string) ($sourceMeta['fifu_slider_list_alt'] ?? ''));

        if ($listAltRaw === '') {
            return $sourceMeta;
        }

        $listAlts = self::parse_legacy_alt_list($listAltRaw);
        if (empty($listAlts)) {
            return $sourceMeta;
        }

        $urls = self::extract_indexed_legacy_values($sourceMeta, 'fifu_slider_image_url_');

        foreach (array_keys($urls) as $index) {
            $altKey = 'fifu_slider_image_alt_' . (int) $index;
            $existingAlt = trim((string) ($sourceMeta[$altKey] ?? ''));
            if ($existingAlt !== '') {
                continue;
            }

            $fallbackAlt = trim((string) ($listAlts[(int) $index] ?? ''));
            if ($fallbackAlt !== '') {
                $sourceMeta[$altKey] = $fallbackAlt;
            }
        }

        return $sourceMeta;
    }

    /**
     * @param array<int> $postIds
     * @return array<int,array<string,string>>
     */
    private static function load_slider_source_meta_for_post_ids(array $postIds): array
    {
        global $wpdb;

        $postIds = array_values(array_unique(array_filter(array_map('intval', $postIds), static function ($postId) {
            return $postId > 0;
        })));

        if (!$postIds) {
            return [];
        }

        $map = [];

        foreach (array_chunk($postIds, 1000) as $chunk) {
            $placeholders = implode(',', array_fill(0, count($chunk), '%d'));

            $rows = $wpdb->get_results($wpdb->prepare(
                "
                SELECT post_id, meta_key, meta_value
                FROM {$wpdb->postmeta}
                WHERE post_id IN ({$placeholders})
                  AND (
                       meta_key = 'fifu_slider_list_url'
                    OR meta_key = 'fifu_slider_list_alt'
                    OR meta_key REGEXP '^fifu_slider_image_url_[0-9]+$'
                    OR meta_key REGEXP '^fifu_slider_image_alt_[0-9]+$'
                  )
                ",
                $chunk
            ), ARRAY_A);

            foreach ((array) $rows as $row) {
                if (is_array($row)) {
                    $postId = (int) ($row['post_id'] ?? 0);
                    $metaKey = (string) ($row['meta_key'] ?? '');
                    $metaValue = (string) ($row['meta_value'] ?? '');
                } elseif (is_object($row)) {
                    $postId = (int) ($row->post_id ?? 0);
                    $metaKey = (string) ($row->meta_key ?? '');
                    $metaValue = (string) ($row->meta_value ?? '');
                } else {
                    continue;
                }

                if ($postId <= 0 || $metaKey === '') {
                    continue;
                }

                if (!isset($map[$postId])) {
                    $map[$postId] = [];
                }

                $map[$postId][$metaKey] = $metaValue;
            }
        }

        return $map;
    }

    /**
     * @param array<string,string> $meta
     */
    private static function has_complex_media_for_image_list_bulk_migration(array $meta): bool {
        foreach ($meta as $key => $value) {
            $key = (string) $key;
            $value = trim((string) $value);

            if ($value === '') {
                continue;
            }

            if (
                $key === 'fifu_video_url'
                || $key === 'fifu_list_video_url'
                || $key === 'fifu_custom_video_url'
                || $key === 'fifu_slider_list_url'
                || $key === 'fifu_slider_image_url_0'
                || preg_match('/^fifu_video_url_\d+$/', $key) === 1
                || preg_match('/^fifu_slider_image_url_\d+$/', $key) === 1
            ) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param array<string,string> $meta
     * @return array<int,string>
     */
    private static function extract_direct_image_url_map_for_bulk_migration(array $meta): array {
        $urls = [];

        $featuredUrl = trim((string) ($meta['fifu_image_url'] ?? ''));
        if ($featuredUrl !== '') {
            $urls[0] = $featuredUrl;
        }

        foreach ($meta as $key => $value) {
            if (preg_match('/^fifu_image_url_(\d+)$/', (string) $key, $matches) !== 1) {
                continue;
            }

            $url = trim((string) $value);
            if ($url === '') {
                continue;
            }

            $urls[((int) $matches[1]) + 1] = $url;
        }

        ksort($urls, SORT_NUMERIC);

        return $urls;
    }

    /**
     * @param array<string,string> $meta
     * @return array<int,string>
     */
    private static function extract_direct_image_alt_map_for_bulk_migration(array $meta): array {
        $alts = [];

        $featuredAlt = self::normalize_legacy_gallery_alt_value((string) ($meta['fifu_image_alt'] ?? ''));
        if ($featuredAlt !== '') {
            $alts[0] = $featuredAlt;
        }

        foreach ($meta as $key => $value) {
            if (preg_match('/^fifu_image_alt_(\d+)$/', (string) $key, $matches) !== 1) {
                continue;
            }

            $alt = self::normalize_legacy_gallery_alt_value($value);
            if ($alt === '') {
                continue;
            }

            $alts[((int) $matches[1]) + 1] = $alt;
        }

        ksort($alts, SORT_NUMERIC);

        return $alts;
    }

    /**
     * @param array<int,string> $values
     */
    private static function is_zero_based_sequential_int_map(array $values): bool {
        if ($values === []) {
            return false;
        }

        $keys = array_keys($values);
        sort($keys, SORT_NUMERIC);

        return $keys === range(0, count($keys) - 1);
    }

    /**
     * @param array<int,string> $values
     */
    private static function is_sequential_int_map_from_start(array $values, int $start): bool {
        if ($values === []) {
            return false;
        }

        $keys = array_map('intval', array_keys($values));
        sort($keys, SORT_NUMERIC);

        return $keys === range($start, $start + count($keys) - 1);
    }

    /**
     * @param string $tmpTable
     * @param array<int,array{post_id:int,url_hash:string,url:string,alt_hash:string,alt:string}> $rows
     * @return bool
     */
    private static function insert_simple_post_image_legacy_stage_rows(string $tmpTable, array $rows): bool {
        if ($rows === []) {
            return true;
        }

        $wpdb = self::get_wpdb();
        $chunks = array_chunk($rows, 500, true);

        foreach ($chunks as $chunk) {
            $valuesSql = [];
            $args = [];

            foreach ($chunk as $row) {
                $valuesSql[] = '(%d, %s, %s, %s, %s)';
                $args[] = (int) $row['post_id'];
                $args[] = (string) $row['url_hash'];
                $args[] = (string) $row['url'];
                $args[] = (string) $row['alt_hash'];
                $args[] = (string) $row['alt'];
            }

            $sql = "
            INSERT INTO {$tmpTable} (post_id, url_hash, url, alt_hash, alt)
            VALUES " . implode(',', $valuesSql) . "
            ON DUPLICATE KEY UPDATE
                url_hash = VALUES(url_hash),
                url = VALUES(url),
                alt_hash = VALUES(alt_hash),
                alt = VALUES(alt)
        ";

            $result = $wpdb->query($wpdb->prepare($sql, ...$args));
            if ($result === false) {
                return false;
            }
        }

        return true;
    }

    /**
     * @param string $tmpTable
     * @param array<int,array{post_id:int,key_index:int,url_hash:string,url:string,alt_hash:string,alt:string}> $rows
     * @return bool
     */
    private static function insert_simple_post_image_list_legacy_stage_rows(string $tmpTable, array $rows): bool {
        if ($rows === []) {
            return true;
        }

        $wpdb = self::get_wpdb();
        $chunks = array_chunk($rows, 500, true);

        foreach ($chunks as $chunk) {
            $valuesSql = [];
            $args = [];

            foreach ($chunk as $row) {
                $valuesSql[] = '(%d, %d, %s, %s, %s, %s)';
                $args[] = (int) $row['post_id'];
                $args[] = (int) $row['key_index'];
                $args[] = (string) $row['url_hash'];
                $args[] = (string) $row['url'];
                $args[] = (string) $row['alt_hash'];
                $args[] = (string) $row['alt'];
            }

            $sql = "
            INSERT INTO {$tmpTable} (post_id, key_index, url_hash, url, alt_hash, alt)
            VALUES " . implode(',', $valuesSql) . "
            ON DUPLICATE KEY UPDATE
                url_hash = VALUES(url_hash),
                url = VALUES(url),
                alt_hash = VALUES(alt_hash),
                alt = VALUES(alt)
        ";

            $result = $wpdb->query($wpdb->prepare($sql, ...$args));
            if ($result === false) {
                return false;
            }
        }

        return true;
    }

    /**
     * @param string $tmpTable
     * @param array<int,array{post_id:int,key_index:int,url_hash:string,url:string,alt_hash:string,alt:string}> $rows
     * @return bool
     */
    private static function insert_indexed_slider_legacy_stage_rows(string $tmpTable, array $rows): bool {
        if ($rows === []) {
            return true;
        }

        $wpdb = self::get_wpdb();
        $chunks = array_chunk($rows, 500, true);

        foreach ($chunks as $chunk) {
            $valuesSql = [];
            $args = [];

            foreach ($chunk as $row) {
                $valuesSql[] = '(%d, %d, %s, %s, %s, %s)';
                $args[] = (int) $row['post_id'];
                $args[] = (int) $row['key_index'];
                $args[] = (string) $row['url_hash'];
                $args[] = (string) $row['url'];
                $args[] = (string) $row['alt_hash'];
                $args[] = (string) $row['alt'];
            }

            $sql = "
            INSERT INTO {$tmpTable} (post_id, key_index, url_hash, url, alt_hash, alt)
            VALUES " . implode(',', $valuesSql) . "
            ON DUPLICATE KEY UPDATE
                url_hash = VALUES(url_hash),
                url = VALUES(url),
                alt_hash = VALUES(alt_hash),
                alt = VALUES(alt)
        ";

            $result = $wpdb->query($wpdb->prepare($sql, ...$args));
            if ($result === false) {
                return false;
            }
        }

        return true;
    }

    /**
     * Clear post meta cache after the DB transaction commits.
     *
     * @param array<int|string> $postIds
     * @return void
     */
    private static function clear_post_meta_cache_for_post_ids(array $postIds): void {
        if (!function_exists('wp_cache_delete')) {
            return;
        }

        foreach ($postIds as $postId) {
            $intPostId = (int) $postId;
            if ($intPostId > 0) {
                wp_cache_delete($intPostId, 'post_meta');
            }
        }
    }
    /**
     * Returns the DB2 URL list for a post/key-type pair, ordered by key index.
     *
     * @param int $postId
     * @param string $keyType
     * @return array<int, string>
     */
    private static function get_db2_post_pipe_list(int $postId, string $keyType): array {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return [];
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return [];
        }

        $urls = [];
        $seenIndexes = [];
        $primaryMapping = $manager->getPostMapping($postId, $keyType, 0);
        if (is_array($primaryMapping)) {
            $primaryUrl = trim((string) ($primaryMapping['url'] ?? ''));
            if ($primaryUrl !== '') {
                $urls[0] = $primaryUrl;
                $seenIndexes[0] = true;
            }
        }

        $mappings = $manager->getPostMappings($postId, $keyType);
        if (!is_array($mappings) || $mappings === []) {
            return $urls;
        }

        usort(
            $mappings,
            static fn(array $left, array $right): int => ((int) ($left['key_index'] ?? 0)) <=> ((int) ($right['key_index'] ?? 0))
        );

        foreach ($mappings as $mapping) {
            if (!is_array($mapping)) {
                continue;
            }

            if (isset($mapping['key_type']) && (string) $mapping['key_type'] !== $keyType) {
                continue;
            }

            $index = isset($mapping['key_index']) ? (int) $mapping['key_index'] : 0;
            if ($index < 0) {
                continue;
            }

            $url = trim((string) ($mapping['url'] ?? ''));
            if ($url === '') {
                continue;
            }

            if ($index === 0 && isset($seenIndexes[0])) {
                continue;
            }

            if (isset($seenIndexes[$index])) {
                continue;
            }

            $urls[$index] = $url;
            $seenIndexes[$index] = true;
        }

        ksort($urls);

        return $urls;
    }

    /**
     * @param string|null $value
     * @return string|null
     */
    private static function normalize_pipe_list(?string $value): ?string {
        if ($value === null) {
            return null;
        }

        $entries = array_values(
            array_filter(
                array_map('trim', explode('|', $value)),
                static fn(string $entry): bool => $entry !== ''
            )
        );

        if (!$entries) {
            return null;
        }

        return implode('|', $entries);
    }

    /**
     * @param array<string,string> $galleryMeta
     * @return bool
     */
    private static function has_legacy_video_gallery_meta(array $galleryMeta): bool {
        foreach (array_keys($galleryMeta) as $metaKey) {
            if ($metaKey === 'fifu_list_video_url' || preg_match('/^fifu_video_url_\d+$/', (string) $metaKey) === 1) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param FIFU_Term_Meta_Updater $updater
     * @param int                    $termId
     * @param array<string,string>   $meta
     * @return void
     */
    private static function sync_term_legacy_meta_to_db2(
        FIFU_Term_Meta_Updater $updater,
        int $termId,
        array $meta
    ): void {
        foreach (['fifu_image_url', 'fifu_image_alt', 'fifu_video_url'] as $metaKey) {
            $value = trim((string) ($meta[$metaKey] ?? ''));
            if ($value === '') {
                continue;
            }

            $updater->update_or_delete_term($termId, $metaKey, $value);
        }
    }

    /**
     * @param array<int|string> $termIds
     * @return array<int,array<string,string>>
     */
    private static function get_legacy_term_fifu_fields(array $termIds): array {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($termIds);
        if ($idsCsv === '0') {
            return [];
        }

        $data = [];
        foreach (array_map('intval', explode(',', $idsCsv)) as $termId) {
            $data[$termId] = [
                'fifu_image_url' => '',
                'fifu_image_alt' => '',
                'fifu_video_url' => '',
            ];
        }

        $wpdb = self::get_wpdb();
        $results = $wpdb->get_results("
            SELECT term_id, meta_key, meta_value
            FROM {$wpdb->termmeta}
            WHERE term_id IN ({$idsCsv})
            AND meta_key IN ('fifu_image_url', 'fifu_image_alt', 'fifu_video_url')
        ");

        foreach ($results as $row) {
            $termId = (int) $row->term_id;
            if (!isset($data[$termId])) {
                continue;
            }

            $data[$termId][$row->meta_key] = $row->meta_value;
        }

        return $data;
    }

    /**
     * @param int $postId
     * @return void
     */
    private static function cleanup_legacy_indexed_image_video_gallery_url_postmeta(int $postId): void {
        $wpdb = self::get_wpdb();
        $metaKeys = $wpdb->get_col($wpdb->prepare("
            SELECT meta_key
            FROM {$wpdb->postmeta}
            WHERE post_id = %d
            AND (
                meta_key LIKE 'fifu_image_url_%%'
                OR meta_key LIKE 'fifu_video_url_%%'
            )
        ", $postId));

        foreach ($metaKeys as $metaKey) {
            $wpdb->delete(
                $wpdb->postmeta,
                [
                    'post_id' => $postId,
                    'meta_key' => $metaKey,
                ],
                [
                    '%d',
                    '%s',
                ]
            );
        }

        if ($metaKeys) {
            clean_post_cache($postId);
            wp_cache_delete($postId, 'post_meta');
        }
    }

    /**
     * @param array<int|string> $postIds
     * @return void
     */
    private static function ensure_woocommerce_gallery_meta(array $postIds): void {
        $wpdb = self::get_wpdb();
        $authorId = (int) Fifu_Options_Utils::get_author();

        foreach ($postIds as $postId) {
            $intPostId = (int) $postId;
            if ($intPostId <= 0) {
                continue;
            }

            if (get_post_type($intPostId) !== 'product') {
                continue;
            }

            $attachmentIds = array_values(array_filter(array_map(
                'intval',
                $wpdb->get_col($wpdb->prepare(
                    "
                    SELECT p.id
                    FROM {$wpdb->posts} p
                    WHERE p.post_parent = %d
                    AND p.post_type = 'attachment'
                    AND p.post_author = %d
                    AND NOT EXISTS (
                        SELECT 1
                        FROM {$wpdb->postmeta} pm_thumb
                        WHERE pm_thumb.post_id = %d
                          AND pm_thumb.meta_key = '_thumbnail_id'
                          AND CAST(pm_thumb.meta_value AS UNSIGNED) = p.id
                    )
                    ORDER BY p.id
                    ",
                    $intPostId,
                    $authorId,
                    $intPostId
                ))
            )));

            if (!$attachmentIds) {
                continue;
            }

            $expectedCsv = implode(',', $attachmentIds);
            $currentCsv = rtrim((string) $wpdb->get_var($wpdb->prepare(
                "
                SELECT meta_value
                FROM {$wpdb->postmeta}
                WHERE post_id = %d
                  AND meta_key = '_product_image_gallery'
                LIMIT 1
                ",
                $intPostId
            )), ',');

            if ($currentCsv === $expectedCsv) {
                continue;
            }

            if ($currentCsv === '') {
                $wpdb->query($wpdb->prepare(
                    "
                    INSERT INTO {$wpdb->postmeta} (post_id, meta_key, meta_value)
                    VALUES (%d, %s, %s)
                    ",
                    $intPostId,
                    '_product_image_gallery',
                    $expectedCsv
                ));
            } else {
                $wpdb->update(
                    $wpdb->postmeta,
                    ['meta_value' => $expectedCsv],
                    [
                        'post_id' => $intPostId,
                        'meta_key' => '_product_image_gallery',
                    ],
                    ['%s'],
                    ['%d', '%s']
                );
            }

            clean_post_cache($intPostId);
            wp_cache_delete($intPostId, 'post_meta');
        }
    }

    /**
     * Bulk-detect product IDs whose WooCommerce gallery meta needs repair.
     *
     * This is a pre-check for ensure_woocommerce_gallery_meta(). It keeps the repair
     * safety net but avoids running the expensive per-product repair pass when the
     * bulk restore already inserted the correct _product_image_gallery value.
     *
     * @param array<int|string> $postIds
     * @return int[]
     */
    private static function build_woocommerce_gallery_meta_repair_post_ids(array $postIds): array {
        $postIds = array_values(array_unique(array_filter(
            array_map('intval', $postIds),
            static fn (int $postId): bool => $postId > 0
        )));

        $postIds = array_values(array_filter(
            $postIds,
            static fn (int $postId): bool => get_post_type($postId) === 'product'
        ));

        if ($postIds === []) {
            return [];
        }

        $wpdb = self::get_wpdb();
        $authorId = (int) Fifu_Options_Utils::get_author();
        $placeholders = implode(',', array_fill(0, count($postIds), '%d'));

        $thumbnailRows = $wpdb->get_results($wpdb->prepare(
            "
            SELECT post_id, meta_value
            FROM {$wpdb->postmeta}
            WHERE post_id IN ({$placeholders})
              AND meta_key = '_thumbnail_id'
            ",
            ...$postIds
        ), ARRAY_A);

        $thumbnailIdsByPostId = [];
        if (is_array($thumbnailRows)) {
            foreach ($thumbnailRows as $row) {
                $postId = (int) ($row['post_id'] ?? 0);
                $thumbnailId = (int) ($row['meta_value'] ?? 0);
                if ($postId > 0 && $thumbnailId > 0) {
                    $thumbnailIdsByPostId[$postId] = $thumbnailId;
                }
            }
        }

        $galleryMetaRows = $wpdb->get_results($wpdb->prepare(
            "
            SELECT post_id, meta_value
            FROM {$wpdb->postmeta}
            WHERE post_id IN ({$placeholders})
              AND meta_key = '_product_image_gallery'
            ",
            ...$postIds
        ), ARRAY_A);

        $currentGalleryByPostId = [];
        if (is_array($galleryMetaRows)) {
            foreach ($galleryMetaRows as $row) {
                $postId = (int) ($row['post_id'] ?? 0);
                if ($postId <= 0) {
                    continue;
                }

                $currentGalleryByPostId[$postId] = rtrim(trim((string) ($row['meta_value'] ?? '')), ',');
            }
        }

        $attachmentRows = $wpdb->get_results($wpdb->prepare(
            "
            SELECT ID, post_parent
            FROM {$wpdb->posts}
            WHERE post_parent IN ({$placeholders})
              AND post_type = 'attachment'
              AND post_author = %d
            ORDER BY post_parent, ID
            ",
            ...array_merge($postIds, [$authorId])
        ), ARRAY_A);

        $expectedGalleryIdsByPostId = [];
        if (is_array($attachmentRows)) {
            foreach ($attachmentRows as $row) {
                $attachmentId = (int) ($row['ID'] ?? 0);
                $postId = (int) ($row['post_parent'] ?? 0);
                if ($attachmentId <= 0 || $postId <= 0) {
                    continue;
                }

                if (($thumbnailIdsByPostId[$postId] ?? 0) === $attachmentId) {
                    continue;
                }

                $expectedGalleryIdsByPostId[$postId][] = $attachmentId;
            }
        }

        $repairPostIds = [];
        foreach ($postIds as $postId) {
            $expectedIds = $expectedGalleryIdsByPostId[$postId] ?? [];
            if ($expectedIds === []) {
                continue;
            }

            $expectedCsv = implode(',', array_map('intval', $expectedIds));
            $currentCsv = $currentGalleryByPostId[$postId] ?? '';

            if ($currentCsv !== $expectedCsv) {
                $repairPostIds[] = $postId;
            }
        }

        sort($repairPostIds);

        return $repairPostIds;
    }

    /**
     * @param array<int|string> $postIds
     * @param string $metaKey
     * @return array<int, string>
     */
    private static function snapshot_non_empty_post_meta(array $postIds, string $metaKey): array {
        return self::get_non_empty_post_meta_from_database(
            $postIds,
            $metaKey
        );
    }

    /**
     * Read post metadata directly from the database, bypassing object-cache state.
     *
     * @param array<int|string> $postIds
     * @param string $metaKey
     * @return array<int, string>
     */
    private static function get_non_empty_post_meta_from_database(array $postIds, string $metaKey): array {
        $ids = array_values(array_unique(array_filter(array_map('intval', $postIds), static function (int $postId): bool {
            return $postId > 0;
        })));

        if ($ids === []) {
            return [];
        }

        $wpdb = self::get_wpdb();
        $placeholders = implode(',', array_fill(0, count($ids), '%d'));
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT post_id, meta_value
                 FROM {$wpdb->postmeta}
                 WHERE post_id IN ({$placeholders})
                   AND meta_key = %s
                 ORDER BY meta_id ASC",
                ...array_merge($ids, [$metaKey])
            )
        );

        if (!is_array($rows)) {
            return [];
        }

        $values = [];
        foreach ($rows as $row) {
            $postId = (int) ($row->post_id ?? 0);
            $value = trim((string) ($row->meta_value ?? ''));
            if ($postId > 0 && $value !== '' && !isset($values[$postId])) {
                $values[$postId] = $value;
            }
        }

        return $values;
    }

    /**
     * @param array<int|string> $postIds
     * @param array<int, string> $snapshots
     * @return void
     */
    private static function restore_woocommerce_gallery_snapshot_if_empty(array $postIds, array $snapshots): void {
        $currentValues = self::get_non_empty_post_meta_from_database(
            $postIds,
            '_product_image_gallery'
        );

        foreach ($postIds as $postId) {
            $intPostId = (int) $postId;
            if ($intPostId <= 0 || !isset($snapshots[$intPostId])) {
                continue;
            }

            if (isset($currentValues[$intPostId])) {
                continue;
            }

            update_post_meta($intPostId, '_product_image_gallery', $snapshots[$intPostId]);
            clean_post_cache($intPostId);
            wp_cache_delete($intPostId, 'post_meta');
        }
    }

    /**
     * Process a single metadata out row for attachments.
     *
     * Cleans up attachments and their metadata when dequeuing the out-flow row identified by the queue ID.
     *
     * @param int $queueId Identifier of the metadata out queue row to process.
     *
     * @return bool True if the attachment cleanup row was successfully processed, false otherwise.
     */
    public static function process_att_meta_out_row(int $queueId): bool {
        return self::process_meta_out_row($queueId, 'att', 'delete_attmeta', 'cleanup_post_attachment_meta');
    }

    /**
     * Process a single metadata out row for WooCommerce products.
     *
     * Handles WooCommerce specific cleanup operations for the queue entry provided.
     *
     * @param int $queueId Identifier of the WooCommerce metadata out queue row to process.
     *
     * @return bool True if the row was successfully processed, false otherwise.
     */
    public static function process_woo_meta_out_row(int $queueId): bool {
        return self::process_meta_out_row($queueId, 'woo', 'delete_woometa', 'cleanup_woocommerce_meta');
    }

    /**
     * Process a single metadata out row for terms.
     *
     * Removes the queued term metadata entries associated with the given queue identifier.
     *
     * @param int $queueId Identifier of the term metadata out queue row to process.
     *
     * @return bool True if the row was successfully processed, false otherwise.
     */
    public static function process_term_meta_out_row(int $queueId): bool {
        return self::process_meta_out_row($queueId, 'term', 'delete_termmeta', 'cleanup_term_attachments');
    }

    /**
     * Clean up orphaned WAI attachments from the queue.
     *
     * This method performs the garbage collection that ensures WAI metadata rows are deleted when no longer needed.
     *
     * @return bool True if the garbage cleanup ran successfully, false otherwise.
     */
    public static function delete_garbage_wai(): bool {
        $wpdb = self::get_wpdb();
        $author = (int) Fifu_Options_Utils::get_author();

        $attachment_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts}
             WHERE post_type = 'attachment' AND post_author = %d AND post_parent = 0",
            $author
        ));
        if (!$attachment_ids) {
            return true;
        }

        $repository = new Fifu_Attachment_Repository();
        $cleanup = new Fifu_Local_Media_Cleanup();
        foreach (array_unique(array_map('intval', $attachment_ids)) as $attachment_id) {
            if ($attachment_id <= 0 || $attachment_id === (int) get_option('fifu_default_attach_id')) {
                continue;
            }
            if (!$repository->is_fifu_attachment($attachment_id)) {
                continue;
            }
            if ($repository->get_referenced_attachment_ids([$attachment_id])) {
                continue;
            }
            $cleanup->delete_attachments_and_meta([$attachment_id]);
        }

        return true;
    }

    /**
     * Execute the full metadata import pipeline for the provided IDs.
     *
     * Coordinates queue preparation, processing, and cleanup for either posts or terms.
     *
     * @param array  $postIds    List of post or term IDs to import metadata for.
     * @param string $metaKey    Meta key that identifies metadata entries being imported.
     * @param bool   $isCategory Whether the incoming IDs represent terms/categories.
     *
     * @return int Number of rows processed during the import.
     */
    public static function run_import(
        array $postIds,
        string $metaKey,
        bool $isCategory
    ): int {
        return self::run_import_pipeline(
            $postIds,
            $isCategory,
            $metaKey
        );
    }

    /**
     * Execute the metadata import pipeline directly for local importers.
     *
     * Unlike the compatibility import worker path, this method does not
     * depend on import sent-state metadata.
     *
     * @param array $objectIds List of post or term IDs to process.
     * @param bool  $isCategory Whether the IDs represent terms/categories.
     *
     * @return int Number of objects processed.
     */
    public static function run_local_import(
        array $objectIds,
        bool $isCategory
    ): int {
        return self::run_import_pipeline(
            $objectIds,
            $isCategory,
            null
        );
    }

    /**
     * Shared implementation for compatibility workers and local importers.
     *
     * @param array       $postIds
     * @param bool        $isCategory
     * @param string|null $legacyMetaKey Compatibility sent-meta key to clean.
     *
     * @return int
     */
    private static function run_import_pipeline(
        array $postIds,
        bool $isCategory,
        ?string $legacyMetaKey
    ): int {
        if (empty($postIds)) {
            return 0;
        }

        $total = count($postIds);
        Fifu_File_Logger::plugin(['import' => ['count' => $total, 'ctgr' => $isCategory]]);

        $postIdsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($postIds);

        $metaOutQueueIds = self::prepare_meta_out_queue(
            $postIdsCsv,
            $isCategory
        );

        foreach ($metaOutQueueIds['att'] as $queueId) {
            self::process_att_meta_out_row((int) $queueId);
        }

        if (!$isCategory) {
            foreach ($metaOutQueueIds['woo'] as $queueId) {
                self::process_woo_meta_out_row((int) $queueId);
            }
        } else {
            foreach ($metaOutQueueIds['term'] as $queueId) {
                self::process_term_meta_out_row((int) $queueId);
            }
        }

        $metaInQueueIds = self::prepare_meta_in_queue(
            $postIdsCsv,
            $isCategory
        );

        if (!$isCategory) {
            foreach ($metaInQueueIds['post'] as $queueId) {
                self::process_post_meta_in_row((int) $queueId);
            }

            foreach ($metaInQueueIds['woo'] as $queueId) {
                self::process_woo_meta_in_row((int) $queueId);
            }
        } else {
            foreach ($metaInQueueIds['term'] as $queueId) {
                self::process_term_meta_in_row((int) $queueId);
            }
        }

        $wpdb = self::get_wpdb();
        $importTable = $wpdb->prefix . 'fifu_import';
        $categoryFlag = (int) $isCategory;
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$importTable} WHERE post_id IN ({$postIdsCsv}) AND category = %d",
                $categoryFlag
            )
        );

        if ($legacyMetaKey !== null && $legacyMetaKey !== '') {
            if (!$isCategory) {
                $wpdb->query(
                    $wpdb->prepare(
                        "DELETE FROM {$wpdb->postmeta} WHERE post_id IN ({$postIdsCsv}) AND meta_key = %s",
                        $legacyMetaKey
                    )
                );
            } else {
                $wpdb->query(
                    $wpdb->prepare(
                        "DELETE FROM {$wpdb->termmeta} WHERE term_id IN ({$postIdsCsv}) AND meta_key = %s",
                        $legacyMetaKey
                    )
                );
            }
        }

        return $total;
    }

    /**
     * Internal helper to execute metadata out operations for a specific type.
     *
     * @param int    $queueId
     * @param string $type
     * @param string $logAction
     * @param string $speedUpAction
     *
     * @return bool
     */
    private static function process_meta_out_row(
        int $queueId,
        string $type,
        string $logAction,
        string $speedUpAction
    ): bool {
        $wpdb = self::get_wpdb();
        $metaOutTable = $wpdb->prefix . 'fifu_meta_out';

        $result = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT post_ids FROM {$metaOutTable} WHERE id = %d",
                $queueId
            )
        );

        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$metaOutTable} WHERE id = %d",
                $queueId
            )
        );

        Fifu_File_Logger::plugin([$logAction => ['id' => $queueId]]);

        if (count($result) === 0) {
            return false;
        }

        $ids = $result[0]->post_ids;
        $postIds = explode(',', $ids);
        wp_cache_flush();
        $service = self::get_speed_up_service();
        if ($service instanceof Fifu_Db2_Speed_Up_Service) {
            $service->{$speedUpAction}($ids);
        }

        self::decrement_metadata_counter(self::count_queue_ids($postIds));

        return true;
    }

    /**
     * @return wpdb
     */
    private static function get_wpdb(): wpdb {
        global $wpdb;
        return $wpdb;
    }

    /**
     * @return Fifu_Metadata_Queue_Repository
     */
    private static function get_metadata_queue_repository(): Fifu_Metadata_Queue_Repository {
        return new Fifu_Metadata_Queue_Repository();
    }

    private static function can_use_db2_post_meta(
        wpdb $wpdb,
        string $mapTable,
        string $keyTable,
        string $urlTable
    ): bool {
        return self::table_exists($wpdb, $mapTable)
            && self::table_exists($wpdb, $keyTable)
            && self::table_exists($wpdb, $urlTable);
    }

    /**
     * Checks if the specified table exists in the database.
     *
     * @param wpdb $wpdb
     * @param string $table
     * @return bool
     */
    private static function table_exists(wpdb $wpdb, string $table): bool {
        $sql = $wpdb->prepare("SHOW TABLES LIKE %s", $table);
        return $wpdb->get_var($sql) !== null;
    }

    /**
     * @return Fifu_Legacy_Meta_Repository
     */
    private static function get_legacy_meta_repository(): Fifu_Legacy_Meta_Repository {
        $wpdb = self::get_wpdb();
        return new Fifu_Legacy_Meta_Repository($wpdb, $wpdb->prefix . 'postmeta');
    }

    /**
     * @return FIFU_Post_Meta_Updater|null
     */
    private static function get_post_meta_updater(): ?FIFU_Post_Meta_Updater {
        if (!class_exists('FIFU_Post_Meta_Updater', false)) {
            return null;
        }

        return FIFU_Post_Meta_Updater::instance();
    }

    /**
     * @return FIFU_Term_Meta_Updater|null
     */
    private static function get_term_meta_updater(): ?FIFU_Term_Meta_Updater {
        if (!class_exists('FIFU_Term_Meta_Updater', false)) {
            return null;
        }

        return FIFU_Term_Meta_Updater::instance();
    }

    /**
     * @return Fifu_Db2_Speed_Up_Service|null
     */
    private static function get_speed_up_service(): ?Fifu_Db2_Speed_Up_Service {
        $repository = self::get_speed_up_repository();
        if (!$repository) {
            return null;
        }

        return new Fifu_Db2_Speed_Up_Service($repository);
    }

    /**
     * @return Fifu_Db2_Speed_Up_Repository|null
     */
    private static function get_speed_up_repository(): ?Fifu_Db2_Speed_Up_Repository {
        if (!function_exists('fifu_db2_speed_up_repository')) {
            return null;
        }

        return fifu_db2_speed_up_repository();
    }

    /**
     * @param array<int|string> $ids
     */
    private static function count_queue_ids(array $ids): int {
        $count = 0;

        foreach ($ids as $id) {
            $id = trim((string) $id);
            if ($id === '') {
                continue;
            }

        if ((int) $id <= 0) {
            continue;
        }

            $count++;
        }

        return $count;
    }

    /**
     * @param array<int|string>|string $postIds
     * @return int[]
     */
    private static function parse_metadata_post_ids($postIds): array {
        $raw = is_array($postIds) ? $postIds : preg_split('/[,|\\s]+/', (string) $postIds);
        $ids = [];

        foreach ($raw ?: [] as $id) {
            $id = (int) trim((string) $id);
            if ($id > 0) {
                $ids[$id] = $id;
            }
        }

        return array_values($ids);
    }

    private static function decrement_metadata_counter(int $processedCount): void {
        $processedCount = max(0, $processedCount);

        $current = Fifu_Transient_Manager::get('fifu_metadata_counter');
        $current = is_numeric($current) ? (int) $current : 0;

        Fifu_Transient_Manager::set(
            'fifu_metadata_counter',
            max(0, $current - $processedCount),
            0
        );
    }

}
