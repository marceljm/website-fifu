<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Provides read access to indexed image ALT metadata.
 */
final class Fifu_Post_Image_List_Alt_Read_Service
{
    /**
     * Returns the N-th image ALT text for a post, using db2 first and falling back to postmeta.
     *
     * @param int $postId
     * @param int $index
     * @return string|null
     */
    public static function get_image_alt(int $postId, int $index): ?string
    {
        if ($index < 0) {
            return null;
        }

        if (function_exists('fifu_db2_manager')) {
            $manager = fifu_db2_manager();
            if ($manager instanceof Fifu_Db2_Manager) {
                $mapping = $manager->getPostAltMapping($postId, 'image', $index);
                if (is_array($mapping)) {
                    $alt = $mapping['alt'] ?? $mapping['value'] ?? null;
                    if ($alt !== null && $alt !== '') {
                        return (string) $alt;
                    }
                }
            }
        }

        $metaKey = 'fifu_image_alt_' . $index;
        $legacyAlt = get_post_meta($postId, $metaKey, true);
        if ($legacyAlt === '' || $legacyAlt === null) {
            return null;
        }

        return (string) $legacyAlt;
    }

    /**
     * Returns the image ALT list for a post, prioritizing db2 data with a legacy fallback.
     *
     * @param int $postId
     * @return string|null
     */
    public static function get_image_list_alt(int $postId): ?string
    {
        if (function_exists('fifu_db2_manager')) {
            $manager = fifu_db2_manager();
            if ($manager instanceof Fifu_Db2_Manager) {
                $mappings = $manager->getPostAltMappings($postId, 'image');
                if ($mappings) {
                    $alts = [];
                    foreach ($mappings as $mapping) {
                        $index = isset($mapping['key_index']) ? (int) $mapping['key_index'] : 0;
                        if ($index < 0) {
                            continue;
                        }

                        $mappingAlt = trim((string) ($mapping['alt'] ?? $mapping['value'] ?? ''));
                        if ($mappingAlt === '') {
                            continue;
                        }

                        $alts[$index] = $mappingAlt;
                    }

                    if ($alts) {
                        ksort($alts);

                        $max_index = max(array_keys($alts));
                        $normalized = [];

                        for ($index = 0; $index <= $max_index; $index++) {
                            $normalized[$index] = $alts[$index] ?? '';
                        }

                        return implode('|', $normalized);
                    }

                    return null;
                }
            }
        }

        $legacy = (string) get_post_meta($postId, 'fifu_list_alt', true);
        $legacy = rtrim(trim($legacy), '|');

        return $legacy === '' ? null : $legacy;
    }
}
