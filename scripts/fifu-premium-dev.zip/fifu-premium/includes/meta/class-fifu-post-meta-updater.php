<?php

if ( ! class_exists( 'Fifu_Legacy_Media_Meta_Cleanup_Service', false ) ) {
    require_once __DIR__ . '/class-fifu-legacy-media-meta-cleanup-service.php';
}

/**
 * Handles updating and deleting FIFU post meta fields.
 */
class FIFU_Post_Meta_Updater {

    /**
     * @var self
     */
    private static $instance;

    /**
     * Runtime suppression counters keyed by derived-meta flow context.
     *
     * @var array<string,int>
     */
    private static $db2_sync_suppression_counts = array(
        'image_list' => 0,
        'slider'     => 0,
        'video_list' => 0,
    );

    /**
     * Removed feature meta keys. Existing data is preserved, but new writes/deletes are ignored.
     *
     * @var string[]
     */
    private const REMOVED_WRITE_META_KEYS = array(
        'fifu_isbn',
    );

    /**
     * Private constructor to prevent direct instantiation.
     */
    private function __construct() {
    }

    /**
     * Gets the singleton instance of this class.
     *
     * @return self
     */
    public static function instance(): self {
        if ( ! self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    

    /**
     * Updates or deletes a post meta field, mirroring the legacy `fifu_update_or_delete` function.
     * Converts image URLs when necessary and mirrors the meta change in the db2 layer (when available).
     *
     * @param int         $post_id The post ID.
     * @param string      $field   The meta field key.
     * @param string|null $url     The URL to save. If null, the meta is deleted.
     * @return void
     */
    public function update_or_delete( int $post_id, string $field, ?string $url ): void {
        $this->update_or_delete_with_status( $post_id, $field, $url );
    }

    /**
     * Updates or deletes a post meta field and reports whether the DB2 sync succeeded.
     *
     * @param int         $post_id
     * @param string      $field
     * @param string|null $url
     * @return bool
     */
    public function update_or_delete_with_status( int $post_id, string $field, ?string $url ): bool {
        if ( self::is_removed_write_field( $field ) ) {
            return true;
        }

        $value = $this->normalize_meta_value( $field, $url );
        $sync_value = $value === '' ? null : $value;
        $is_delete = $value === '';
        $skip_db2_sync = self::should_skip_db2_sync_for_meta( $field );

        if ( $this->maybe_handle_metadata_sent_field( $post_id, $field, $sync_value ) ) {
            return true;
        }

        if ( $this->maybe_handle_upload_sent_field( $post_id, $field, $sync_value ) ) {
            return true;
        }

        if ( $this->is_db2_only_field( $field ) && ! $this->should_preserve_legacy_postmeta( $field ) && ! $skip_db2_sync ) {
            $ok = $this->sync_meta_change_to_db2( $post_id, $field, $sync_value );
            $this->cleanup_db2_only_legacy_postmeta( $post_id, $field, $ok, $is_delete, $sync_value );
            return $ok;
        }

        if ( $value !== '' ) {
            update_post_meta( $post_id, $field, $value );
        } else {
            delete_post_meta( $post_id, $field, $url );
        }

        if ( $skip_db2_sync ) {
            return true;
        }

        $ok = $this->sync_meta_change_to_db2( $post_id, $field, $sync_value );
        $this->cleanup_db2_only_legacy_postmeta( $post_id, $field, $ok, $is_delete, $sync_value );
        return $ok;
    }

    /**
     * Updates or deletes a post meta field based on an arbitrary value.
     * Mirrors the legacy `fifu_update_or_delete_value` function.
     *
     * @param int    $post_id The post ID.
     * @param string $field   The meta field key.
     * @param mixed  $value   The value to save. If falsy, the meta is deleted.
     * @return void
     */
    public function update_or_delete_value( int $post_id, string $field, $value ): void {
        if ( self::is_removed_write_field( $field ) ) {
            return;
        }

        $is_delete = ! $value;
        $sync_value = $is_delete ? null : (string) $value;
        $skip_db2_sync = self::should_skip_db2_sync_for_meta( $field );

        if ( $this->maybe_handle_metadata_sent_field( $post_id, $field, $sync_value ) ) {
            return;
        }

        if ( $this->maybe_handle_upload_sent_field( $post_id, $field, $sync_value ) ) {
            return;
        }

        if ( $this->is_db2_only_field( $field ) && ! $this->should_preserve_legacy_postmeta( $field ) && ! $skip_db2_sync ) {
            $ok = $this->sync_meta_change_to_db2( $post_id, $field, $sync_value );
            $this->cleanup_db2_only_legacy_postmeta( $post_id, $field, $ok, $is_delete, $sync_value );
            return;
        }

        if ( $is_delete ) {
            delete_post_meta( $post_id, $field, $value );
        } else {
            update_post_meta( $post_id, $field, $value );
        }

        if ( $skip_db2_sync ) {
            return;
        }

        // Sync the meta change to db2, passing null when the value is empty.
        $ok = $this->sync_meta_change_to_db2( $post_id, $field, $sync_value );
        $this->cleanup_db2_only_legacy_postmeta( $post_id, $field, $ok, $is_delete, $sync_value );
    }

    /**
     * Deletes a post meta field.
     *
     * @param int    $post_id The post ID.
     * @param string $field   The meta field key.
     * @return void
     */
    public function delete( int $post_id, string $field ): void {
        if ( self::is_removed_write_field( $field ) ) {
            return;
        }

        $skip_db2_sync = self::should_skip_db2_sync_for_meta( $field );

        if ( $this->maybe_handle_metadata_sent_field( $post_id, $field, null ) ) {
            return;
        }

        if ( $this->maybe_handle_upload_sent_field( $post_id, $field, null ) ) {
            return;
        }

        if ( $this->is_db2_only_field( $field ) && ! $skip_db2_sync ) {
            $ok = $this->sync_meta_change_to_db2( $post_id, $field, null );
            $this->cleanup_db2_only_legacy_postmeta( $post_id, $field, $ok, true, null );
            return;
        }

        delete_post_meta( $post_id, $field );

        if ( $skip_db2_sync ) {
            return;
        }

        $ok = $this->sync_meta_change_to_db2( $post_id, $field, null );
        $this->cleanup_db2_only_legacy_postmeta( $post_id, $field, $ok, true, null );
    }

    /**
     * Executes image-list derived meta writes without re-syncing DB2 for those derived keys.
     *
     * @param callable $callback
     * @return mixed
     */
    public static function run_without_db2_sync_for_derived_image_list_meta( callable $callback ) {
        return self::run_with_db2_sync_suppression( 'image_list', $callback );
    }

    /**
     * Executes slider derived meta writes without re-syncing DB2 for those derived keys.
     *
     * @param callable $callback
     * @return mixed
     */
    public static function run_without_db2_sync_for_derived_slider_meta( callable $callback ) {
        return self::run_with_db2_sync_suppression( 'slider', $callback );
    }

    /**
     * Executes video-list derived meta writes without re-syncing DB2 for those derived keys.
     *
     * @param callable $callback
     * @return mixed
     */
    public static function run_without_db2_sync_for_derived_video_list_meta( callable $callback ) {
        return self::run_with_db2_sync_suppression( 'video_list', $callback );
    }

    /**
     * Determines whether DB2 sync should be skipped for a derived meta key in the active context.
     *
     * @param string $field
     * @return bool
     */
    public static function should_skip_db2_sync_for_meta( string $field ): bool {
        if ( self::is_db2_sync_suppressed( 'image_list' ) && self::is_image_list_derived_meta_key( $field ) ) {
            return true;
        }

        if ( self::is_db2_sync_suppressed( 'slider' ) && self::is_slider_derived_meta_key( $field ) ) {
            return true;
        }

        if ( self::is_db2_sync_suppressed( 'video_list' ) && self::is_video_list_derived_meta_key( $field ) ) {
            return true;
        }

        return false;
    }

    /**
     * @param string      $field
     * @param string|null $url
     * @return string
     */
    private function normalize_meta_value( string $field, ?string $url ): string {
        if ( $url === null ) {
            return '';
        }

        if ( $this->is_alt_meta_key( $field ) ) {
            return $this->normalize_alt_meta_value( $url );
        }

        $url = trim( $url );
        if ( $url === '' ) {
            return '';
        }

        if ( strpos( $field, 'fifu_image_url' ) === 0 || strpos( $field, 'fifu_slider_image_url' ) === 0 ) {
            return fifu_convert( $url );
        }

        return $url;
    }

    /**
     * @param string $field
     * @return bool
     */
    private function is_alt_meta_key( string $field ): bool {
        return strpos( $field, 'alt' ) !== false;
    }

    /**
     * @param string $value
     * @return string
     */
    private function normalize_alt_meta_value( string $value ): string {
        if ( $this->is_empty_alt_value( $value ) ) {
            return '';
        }

        if ( function_exists( 'wp_strip_all_tags' ) ) {
            $value = (string) wp_strip_all_tags( $value );
        } else {
            $value = strip_tags( $value );
        }

        if ( $this->is_empty_alt_value( $value ) ) {
            return '';
        }

        return $value;
    }

    private function is_empty_alt_value( string $value ): bool {
        $trimmed = trim( $value );
        if ( $trimmed === '' ) {
            return true;
        }

        return preg_match( '/^(null|undefined)$/i', $trimmed ) === 1;
    }

    /**
     * @param string   $context
     * @param callable $callback
     * @return mixed
     */
    private static function run_with_db2_sync_suppression( string $context, callable $callback ) {
        if ( ! isset( self::$db2_sync_suppression_counts[ $context ] ) ) {
            self::$db2_sync_suppression_counts[ $context ] = 0;
        }

        self::$db2_sync_suppression_counts[ $context ]++;

        try {
            return $callback();
        } finally {
            self::$db2_sync_suppression_counts[ $context ]--;
        }
    }

    /**
     * @param string $context
     * @return bool
     */
    private static function is_db2_sync_suppressed( string $context ): bool {
        return ( self::$db2_sync_suppression_counts[ $context ] ?? 0 ) > 0;
    }

    /**
     * @param string $field
     * @return bool
     */
    private static function is_image_list_derived_meta_key( string $field ): bool {
        if ( $field === 'fifu_image_url' || $field === 'fifu_image_alt' ) {
            return true;
        }

        if ( preg_match( self::DB2_ONLY_IMAGE_URL_SUFFIX_PATTERN, $field ) === 1 ) {
            return true;
        }

        return preg_match( self::DB2_ONLY_IMAGE_ALT_SUFFIX_PATTERN, $field ) === 1;
    }

    /**
     * @param string $field
     * @return bool
     */
    private static function is_video_list_derived_meta_key( string $field ): bool {
        if (
            $field === 'fifu_video_url'
            || $field === 'fifu_custom_video_url'
            || $field === 'fifu_image_url'
        ) {
            return true;
        }

        return preg_match( '/^fifu_video_url_\d+$/', $field ) === 1;
    }

    /**
     * @param string $field
     * @return bool
     */
    private static function is_slider_derived_meta_key( string $field ): bool {
        if ( preg_match( self::DB2_ONLY_SLIDER_URL_SUFFIX_PATTERN, $field ) === 1 ) {
            return true;
        }

        return preg_match( self::DB2_ONLY_SLIDER_ALT_SUFFIX_PATTERN, $field ) === 1;
    }

    /**
     * @param int         $post_id
     * @param string      $field
     * @param string|null $value
     * @return bool
     */
    private function sync_meta_change_to_db2( int $post_id, string $field, ?string $value ): bool {
        if ( ! function_exists( 'fifu_db2_legacy_write_bridge' ) ) {
            return false;
        }

        $bridge = fifu_db2_legacy_write_bridge();
        if ( ! $bridge instanceof Fifu_Db2_Legacy_Write_Bridge ) {
            return false;
        }

        try {
            $result = $bridge->handle_post_meta_change( $post_id, $field, $value );
        } catch ( \Throwable $throwable ) {
            return false;
        }

        return $result === true;
    }

    /**
     * @param string $field
     * @return bool
     */
    private function is_db2_only_video_key( string $field ): bool {
        if ( in_array( $field, self::DB2_ONLY_VIDEO_META_KEYS, true ) ) {
            return true;
        }

        return preg_match( self::DB2_ONLY_VIDEO_SUFFIX_PATTERN, $field ) === 1;
    }

    /**
     * @param string $field
     * @return bool
     */
    private function is_db2_only_slider_key( string $field ): bool {
        if ( preg_match( self::DB2_ONLY_SLIDER_URL_SUFFIX_PATTERN, $field ) === 1 ) {
            return true;
        }

        return preg_match( self::DB2_ONLY_SLIDER_ALT_SUFFIX_PATTERN, $field ) === 1;
    }

    /**
     * @param string $field
     * @return bool
     */
    private function is_db2_only_list_key( string $field ): bool {
        return in_array( $field, self::DB2_ONLY_LIST_META_KEYS, true );
    }

    /**
     * @param string $field
     * @return bool
     */
    private function is_db2_only_singleton_key( string $field ): bool {
        return in_array( $field, self::DB2_ONLY_SINGLETON_META_KEYS, true );
    }

    /**
     * Delete legacy post meta via direct SQL for cleanup-on-write.
     *
     * @param int    $post_id
     * @param string $meta_key
     * @return void
     */
    private function delete_legacy_postmeta_raw( int $post_id, string $meta_key ): void {
        global $wpdb;

        $wpdb->delete(
            $wpdb->postmeta,
            [
                'post_id'  => $post_id,
                'meta_key' => $meta_key,
            ],
            [
                '%d',
                '%s',
            ]
        );

        clean_post_cache( $post_id );
        wp_cache_delete( $post_id, 'post_meta' );
    }

    /**
     * Remove legacy video-list related postmeta after DB2 has already been populated.
     *
     * @param int $post_id
     * @return void
     */
    public function cleanup_video_list_legacy_postmeta( int $post_id ): void {
        Fifu_Legacy_Media_Meta_Cleanup_Service::cleanup_post_video_meta_after_db2_sync( (int) $post_id );
    }

    private function maybe_handle_metadata_sent_field( int $post_id, string $field, ?string $value ): bool {
        if ( ! $this->is_metadata_sent_field( $field ) ) {
            return false;
        }

        $service = $this->get_db2_sent_service();
        if ( ! $service ) {
            return false;
        }

        $sent = (int) $value === 1;
        $ok = $service->set_sent_post_metadata( $post_id, $sent );
        if ( $ok ) {
            $this->delete_legacy_postmeta_raw( $post_id, $field );
        }

        return $ok;
    }

    private function is_metadata_sent_field( string $field ): bool {
        return in_array( $field, self::DB2_ONLY_SENT_META_KEYS, true );
    }

    private function is_upload_sent_field( string $field ): bool {
        return in_array( $field, self::DB2_ONLY_UPLOAD_SENT_META_KEYS, true );
    }

    private function maybe_handle_upload_sent_field( int $post_id, string $field, ?string $value ): bool {
        if ( ! $this->is_upload_sent_field( $field ) ) {
            return false;
        }

        $service = $this->get_db2_sent_service();
        if ( ! $service ) {
            return false;
        }

        $sent = (int) $value === 1;
        $ok = $service->set_sent_post_upload( $post_id, $sent );
        if ( $ok ) {
            $this->delete_legacy_postmeta_raw( $post_id, $field );
        }

        return $ok;
    }

    private function get_db2_sent_service(): ?Fifu_Db2_Sent_Service {
        if ( ! function_exists( 'fifu_db2_sent_service' ) ) {
            return null;
        }

        $service = fifu_db2_sent_service();
        if ( ! $service instanceof Fifu_Db2_Sent_Service ) {
            return null;
        }

        return $service;
    }

    private const DB2_ONLY_IMAGE_ALT_META_KEYS = array(
        'fifu_image_alt',
    );

    private const DB2_ONLY_IMAGE_ALT_SUFFIX_PATTERN = '/^fifu_image_alt_\\d+$/';
    private const DB2_ONLY_IMAGE_URL_SUFFIX_PATTERN = '/^fifu_image_url_\\d+$/';

    private const DB2_ONLY_VIDEO_META_KEYS = array(
        'fifu_video_url',
        'fifu_custom_video_url',
    );

    private const DB2_ONLY_VIDEO_SUFFIX_PATTERN = '/^fifu_video_url_\\d+$/';

    private const DB2_ONLY_SLIDER_URL_SUFFIX_PATTERN = '/^fifu_slider_image_url_\\d+$/';
    private const DB2_ONLY_SLIDER_ALT_SUFFIX_PATTERN = '/^fifu_slider_image_alt_\\d+$/';

    private const DB2_ONLY_LIST_META_KEYS = array(
        'fifu_list_url',
        'fifu_list_alt',
        'fifu_list_video_url',
        'fifu_slider_list_url',
        'fifu_slider_list_alt',
    );

    private const DB2_ONLY_UPLOAD_SENT_META_KEYS = array(
        'fifu_uploadpost_sent',
    );

    private const DB2_ONLY_SENT_META_KEYS = array(
        'fifu_metadatapost_sent',
    );

    private const DB2_ONLY_SINGLETON_META_KEYS = array(
        'fifu_finder_url',
        'fifu_redirection_url',
        'fifu_audio_url',
    );

    private const DB2_ONLY_IDENTIFIER_META_KEYS = array(
        'fifu_asin',
    );

    /**
     * @param string $field
     * @return bool
     */
    private function is_db2_only_field( string $field ): bool {
        static $exact_keys = array(
            'fifu_redirection_url',
            'fifu_finder_url',
            'fifu_audio_url',
            'fifu_video_url',
            'fifu_image_url',
            'fifu_custom_video_url',
            'fifu_list_url',
            'fifu_list_alt',
            'fifu_list_video_url',
            'fifu_slider_list_url',
            'fifu_slider_list_alt',
            'fifu_metadatapost_sent',
            'fifu_uploadpost_sent',
        );

        if ( in_array( $field, $exact_keys, true ) ||
            in_array( $field, self::DB2_ONLY_IMAGE_ALT_META_KEYS, true ) ||
            in_array( $field, self::DB2_ONLY_VIDEO_META_KEYS, true ) ||
            in_array( $field, self::DB2_ONLY_LIST_META_KEYS, true )
        ) {
            return true;
        }

        if ( preg_match( self::DB2_ONLY_IMAGE_ALT_SUFFIX_PATTERN, $field ) === 1 ) {
            return true;
        }

        if ( preg_match( self::DB2_ONLY_VIDEO_SUFFIX_PATTERN, $field ) === 1 ) {
            return true;
        }

        return preg_match( '/^(fifu_slider_image_(alt|url)|fifu_image_ifm|fifu_(video_url|image_url))_\\d+$/', $field ) === 1;
    }

    private function is_db2_only_identifier_key( string $field ): bool {
        return in_array( $field, self::DB2_ONLY_IDENTIFIER_META_KEYS, true );
    }

    private static function is_removed_write_field( string $field ): bool {
        return in_array( $field, self::REMOVED_WRITE_META_KEYS, true );
    }

    private function should_preserve_legacy_postmeta( string $field ): bool {
        /*
         * Legacy mode is now a migration/read-compatibility mode only.
         *
         * FIFU-owned writes for DB2-managed media fields must always behave like
         * hybrid: sync to DB2, then cleanup matching legacy postmeta after DB2
         * confirmation. The old preserve flag must not make indexed gallery fields
         * fall through to update_post_meta().
         *
         * If DB2 sync fails, cleanup_db2_only_legacy_postmeta() already returns
         * early, so externally supplied legacy/import input is still protected.
         */
        return false;
    }

    private function is_db2_only_gallery_field( string $field ): bool {
        return preg_match( '/^(fifu_(image_url|image_alt|image_ifm))_\\d+$/', $field ) === 1;
    }

    private function is_db2_only_image_url_key( string $field ): bool {
        if ( $field === 'fifu_image_url' ) {
            return true;
        }

        return preg_match( self::DB2_ONLY_IMAGE_URL_SUFFIX_PATTERN, $field ) === 1;
    }

    private function is_db2_only_iframe_key( string $field ): bool {
        return preg_match( '/^fifu_image_ifm_\\d+$/', $field ) === 1;
    }

    private function is_db2_only_image_alt_key( string $field ): bool {
        if ( in_array( $field, self::DB2_ONLY_IMAGE_ALT_META_KEYS, true ) ) {
            return true;
        }

        return preg_match( self::DB2_ONLY_IMAGE_ALT_SUFFIX_PATTERN, $field ) === 1;
    }

    private function cleanup_db2_only_legacy_postmeta( int $post_id, string $field, bool $ok, bool $is_delete, ?string $value ): void {
        if ( ! $ok ) {
            return;
        }

        if ( ! empty( $_REQUEST['fifu_preserve_legacy_meta_until_db2_confirmation'] ) ) {
            return;
        }

        if ( $this->should_preserve_legacy_postmeta( $field ) ) {
            return;
        }

        if (
            $field === 'fifu_video_url'
            && ! $this->is_db2_featured_video_post_meta_confirmed( $post_id, $value, $is_delete )
        ) {
            return;
        }

        if (
            ( $field === 'fifu_image_url' || $field === 'fifu_image_alt' )
            && ! $this->is_db2_featured_image_post_meta_confirmed( $post_id, $field, $value, $is_delete )
        ) {
            return;
        }

        if (
            $this->is_db2_only_video_key( $field )
            || $this->is_db2_only_slider_key( $field )
            || $this->is_db2_only_list_key( $field )
            || $this->is_db2_only_singleton_key( $field )
            || $this->is_db2_only_identifier_key( $field )
            || $this->is_db2_only_image_url_key( $field )
            || $this->is_db2_only_iframe_key( $field )
        ) {
            $this->delete_legacy_postmeta_raw( $post_id, $field );
        }

        if ( $this->is_db2_only_image_alt_key( $field ) ) {
            $this->delete_legacy_postmeta_raw( $post_id, $field );
        }
    }

    private function is_db2_featured_image_post_meta_confirmed( int $post_id, string $field, ?string $value, bool $is_delete ): bool {
        if ( ! function_exists( 'fifu_db2_manager' ) || ! class_exists( 'Fifu_Db2_Manager', false ) ) {
            return false;
        }

        $manager = fifu_db2_manager();
        if ( ! $manager instanceof Fifu_Db2_Manager ) {
            return false;
        }

        if ( $field === 'fifu_image_url' ) {
            $mapping = $manager->getPostMapping( $post_id, 'image', 0 );
            if ( $is_delete ) {
                return ! is_array( $mapping ) || (string) ( $mapping['url'] ?? '' ) === '';
            }

            if ( $value === null || $value === '' ) {
                return false;
            }

            return is_array( $mapping ) && (string) ( $mapping['url'] ?? '' ) === $value;
        }

        if ( $field === 'fifu_image_alt' ) {
            $mapping = $manager->getPostAltMapping( $post_id, 'image', 0 );
            if ( $is_delete ) {
                return ! is_array( $mapping ) || (string) ( $mapping['alt'] ?? '' ) === '';
            }

            if ( $value === null || $value === '' ) {
                return false;
            }

            $expected_alt = $this->normalize_alt_meta_value( $value );
            return is_array( $mapping ) && (string) ( $mapping['alt'] ?? '' ) === $expected_alt;
        }

        return true;
    }

    private function is_db2_featured_video_post_meta_confirmed( int $post_id, ?string $value, bool $is_delete ): bool {
        if ( ! function_exists( 'fifu_db2_manager' ) || ! class_exists( 'Fifu_Db2_Manager', false ) ) {
            return false;
        }

        $manager = fifu_db2_manager();
        if ( ! $manager instanceof Fifu_Db2_Manager ) {
            return false;
        }

        $mapping = $manager->getPostMapping( $post_id, 'video', 0 );

        if ( $is_delete ) {
            return ! is_array( $mapping ) || (string) ( $mapping['url'] ?? '' ) === '';
        }

        if ( $value === null || $value === '' ) {
            return false;
        }

        return is_array( $mapping ) && (string) ( $mapping['url'] ?? '' ) === $value;
    }

    private function is_db2_custom_video_source_post_meta_confirmed( int $post_id, string $value ): bool {
        if ( ! function_exists( 'fifu_db2_manager' ) || ! class_exists( 'Fifu_Db2_Manager', false ) ) {
            return false;
        }

        $manager = fifu_db2_manager();
        if ( ! $manager instanceof Fifu_Db2_Manager ) {
            return false;
        }

        [ $video_url, $poster_url, $has_custom_poster ] = $this->split_custom_video_entry( $value );
        $expected_custom_video_url = trim( $video_url );
        $expected_poster_url = trim( $poster_url );

        if ( $expected_custom_video_url === '' ) {
            return false;
        }

        global $wpdb;
        $keyTable = $wpdb->prefix . 'fifu_key';
        $customVideoKeyExists = (bool) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT 1 FROM {$keyTable} WHERE key_type = %s LIMIT 1",
                'custom_video'
            )
        );
        if ( ! $customVideoKeyExists ) {
            return false;
        }

        $custom_video_mapping = $manager->getPostMapping( $post_id, 'custom_video', 0 );
        if (
            ! is_array( $custom_video_mapping ) ||
            empty( $custom_video_mapping['url'] ) ||
            (string) $custom_video_mapping['url'] !== $expected_custom_video_url
        ) {
            return false;
        }

        if ( ! $has_custom_poster ) {
            return true;
        }

        if ( $expected_poster_url === '' ) {
            return false;
        }

        if ( ! class_exists( 'Fifu_Video_Oembed_Service', false ) ) {
            return false;
        }

        $service = Fifu_Video_Oembed_Service::instance();
        if ( ! method_exists( $service, 'get_repository' ) ) {
            return false;
        }

        $repository = $service->get_repository();
        if ( ! method_exists( $repository, 'get_image_url_by_video_url' ) ) {
            return false;
        }

        return (string) $repository->get_image_url_by_video_url( $expected_custom_video_url ) === $expected_poster_url;
    }

    /**
     * @return array{0:string,1:string,2:bool}
     */
    private function split_custom_video_entry( string $value ): array {
        if ( strpos( $value, '\\' ) !== false ) {
            $parts = explode( '\\', $value, 2 );
            $image = trim( (string) ( $parts[1] ?? '' ) );
            return [
                trim( (string) ( $parts[0] ?? '' ) ),
                $image,
                $image !== '',
            ];
        }

        if ( preg_match( '/https?:\\/\\//i', $value, $matches, PREG_OFFSET_CAPTURE ) === 1 ) {
            $firstOffset = (int) ( $matches[0][1] ?? -1 );
            if ( $firstOffset >= 0 && preg_match( '/https?:\\/\\//i', $value, $secondMatch, PREG_OFFSET_CAPTURE, $firstOffset + 1 ) === 1 ) {
                $secondOffset = (int) ( $secondMatch[0][1] ?? -1 );
                if ( $secondOffset > $firstOffset ) {
                    return [
                        trim( substr( $value, 0, $secondOffset ) ),
                        trim( substr( $value, $secondOffset ) ),
                        true,
                    ];
                }
            }
        }

        return [
            trim( $value ),
            '',
            false,
        ];
    }
}
