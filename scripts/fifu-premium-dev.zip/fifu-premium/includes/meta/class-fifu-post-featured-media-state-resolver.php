<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

final class Fifu_Post_Featured_Media_State_Resolver
{
    public static function resolve(int $postId): array
    {
        return self::resolveFromSource(
            $postId,
            static function (string $type, int $index) use ($postId): ?string {
                return self::getMappingUrl($postId, $type, $index);
            }
        );
    }

    public static function resolve_effective(int $postId): array
    {
        return self::resolveFromSource(
            $postId,
            static function (string $type, int $index) use ($postId): ?string {
                switch ($type) {
                    case 'image':
                        return Fifu_Post_Image_Url_Read_Service::get_image_url($postId);

                    case 'video':
                        return Fifu_Post_Video_Read_Service::get_video_url($postId);

                    case 'custom_video':
                        return Fifu_Post_Custom_Video_Read_Service::get_custom_video_url($postId);

                    case 'slider':
                        return Fifu_Post_Slider_Image_Url_Read_Service::get_slider_image_url(
                            $postId,
                            $index
                        );
                }

                return null;
            }
        );
    }

    /**
     * Resolves the initial editor type used by the Featured Media editors.
     *
     * This is editor state only. It does not change the effective frontend
     * media state or persist a selected type.
     */
    public static function resolve_editor_type(int $postId): string
    {
        $state = self::resolve_effective($postId);
        $stateType = is_array($state) ? (string) ($state['type'] ?? '') : '';

        if ($stateType === 'custom_video') {
            return 'video';
        }

        if ($stateType === 'image') {
            $audioUrl = self::normalizeSourceUrl(Fifu_Post_Audio_Read_Service::get_audio_url($postId));
            $videoUrl = self::normalizeSourceUrl(Fifu_Post_Video_Read_Service::get_video_url($postId));
            $customVideoUrl = self::normalizeSourceUrl(Fifu_Post_Custom_Video_Read_Service::get_custom_video_url($postId));

            if ($customVideoUrl !== '') {
                return 'video';
            }

            if ($audioUrl !== '' && $videoUrl === '' && $customVideoUrl === '') {
                return 'audio';
            }
        }

        if (in_array($stateType, ['image', 'video', 'slider'], true)) {
            return $stateType;
        }

        if (self::normalizeSourceUrl(Fifu_Post_Audio_Read_Service::get_audio_url($postId)) !== '') {
            return 'audio';
        }

        return 'image';
    }

    private static function resolveFromSource(int $postId, callable $getUrl): array
    {
        $sliderUrl = self::normalizeSourceUrl($getUrl('slider', 0));
        if ($sliderUrl !== '') {
            return self::state('slider', $sliderUrl);
        }

        $imageUrl = self::normalizeSourceUrl($getUrl('image', 0));
        $videoUrl = self::normalizeSourceUrl($getUrl('video', 0));
        $customVideoUrl = self::normalizeSourceUrl($getUrl('custom_video', 0));

        $videoCandidateType = null;
        $videoCandidateUrl = null;
        if ($customVideoUrl !== '') {
            $videoCandidateType = 'custom_video';
            $videoCandidateUrl = $customVideoUrl;
        } elseif ($videoUrl !== '') {
            $videoCandidateType = 'video';
            $videoCandidateUrl = $videoUrl;
        }

        $hasImage = $imageUrl !== '';
        $hasVideoCandidate = $videoCandidateType !== null && $videoCandidateUrl !== null;

        if ($hasImage && $hasVideoCandidate) {
            if (self::isVideosBeforeOn()) {
                return self::state($videoCandidateType, $videoCandidateUrl);
            }

            return self::state('image', $imageUrl);
        }

        if ($hasVideoCandidate) {
            return self::state($videoCandidateType, $videoCandidateUrl);
        }

        if ($hasImage) {
            return self::state('image', $imageUrl);
        }

        return self::state(null, null);
    }

    private static function normalizeSourceUrl($url): string
    {
        if (!is_string($url) && !is_numeric($url)) {
            return '';
        }

        return trim((string) $url);
    }

    private static function getMappingUrl(int $postId, string $type, int $index): string
    {
        if (!function_exists('fifu_db2_manager')) {
            return '';
        }
        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return '';
        }
        $mapping = $manager->getPostMapping($postId, $type, $index);
        if (!is_array($mapping)) {
            return '';
        }

        $url = $mapping['url'] ?? null;
        if (!is_string($url) && !is_numeric($url)) {
            return '';
        }

        return trim((string) $url);
    }

    private static function isVideosBeforeOn(): bool
    {
        if (!class_exists('Fifu_Options_Utils', false) || !method_exists('Fifu_Options_Utils', 'is_on')) {
            return false;
        }

        return (bool) Fifu_Options_Utils::is_on('fifu_videos_before');
    }

    private static function state(?string $type, ?string $url): array
    {
        $type = $type !== null ? trim($type) : null;
        $url = $url !== null ? trim($url) : null;

        return [
            'type' => $type !== '' ? $type : null,
            'url' => $url !== '' ? $url : null,
        ];
    }
}
