<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Handles editor-based saving for featured media elements.
 */
final class Fifu_Post_Save_Service
{
    /** @var array<int,true> */
    private static array $explicitFeaturedImageChanges = [];

    private static function clear_featured_image_state(int $postId): void
    {
        fifu_delete_post_meta($postId, 'fifu_image_url');
        fifu_delete_post_meta($postId, 'fifu_image_alt');
    }

    private static function sanitize_iframe_input($value): string
    {
        $raw = trim((string) $value);
        if ($raw === '') {
            return '';
        }

        $normalized = strtolower($raw);
        if (
            $normalized === 'null'
            || $normalized === 'undefined'
            || $normalized === 'http://null'
            || $normalized === 'https://null'
        ) {
            return '';
        }

        $sanitized = esc_url_raw($raw);
        $normalizedSanitized = strtolower(trim((string) $sanitized));
        if (
            $normalizedSanitized === 'null'
            || $normalizedSanitized === 'undefined'
            || $normalizedSanitized === 'http://null'
            || $normalizedSanitized === 'https://null'
        ) {
            return '';
        }

        return $sanitized;
    }

    private static function has_non_empty_media_url($value): bool
    {
        if ($value === null || $value === false || is_array($value)) {
            return false;
        }

        return trim((string) $value) !== '';
    }

    private static function has_existing_featured_video(int $postId): bool
    {
        if (self::has_non_empty_media_url(\Fifu_Post_Video_Read_Service::get_video_url($postId))) {
            return true;
        }

        if (!class_exists('Fifu_Post_Custom_Video_Read_Service', false)) {
            return false;
        }

        return self::has_non_empty_media_url(\Fifu_Post_Custom_Video_Read_Service::get_custom_video_url($postId));
    }

    /**
     * @param array<string,mixed> $request
     */
    private static function is_explicit_featured_video_removal(int $postId, array $request): bool
    {
        if (!array_key_exists('fifu_video_input_url', $request)) {
            return false;
        }

        $rawVideoInput = $request['fifu_video_input_url'];
        if (is_array($rawVideoInput)) {
            return false;
        }

        return trim((string) wp_unslash($rawVideoInput)) === ''
            && self::has_existing_featured_video($postId);
    }

    /**
     * Entry point for editor-based post saving.
     * It will replace the legacy fifu_save() callback.
     *
     * @param int $postId
     * @param array $request
     * @param bool $ignore
     */
    public static function save_from_editor(int $postId, array $request, bool $ignore = false): void
    {
        $thrownException = null;
        try {
            $fromDeferredPostSave = !empty($request['fifu_post_save_pending']);
            $featuredImageChanged = false;
            $hasFifuInputUrl = array_key_exists('fifu_input_url', $request);
            $fifuInputUrl = $hasFifuInputUrl ? trim((string) $request['fifu_input_url']) : '';
            $clearFeaturedImageForDefault =
                $hasFifuInputUrl
                && $fifuInputUrl === ''
                && Fifu_Options_Utils::is_on('fifu_enable_default_url')
                && Fifu_Post_Type_Utils::is_valid_default_cpt($postId);
            if ($clearFeaturedImageForDefault) {
                self::clear_featured_image_state($postId);
                $featuredImageChanged = true;
            }

            if ($hasFifuInputUrl && $fifuInputUrl !== '') {
                $url = esc_url_raw(rtrim($fifuInputUrl));
                if (self::featured_media_needs_write($postId, $url, 'url')) {
                    fifu_update_or_delete($postId, 'fifu_image_url', $url);
                    $featuredImageChanged = true;
                }
            }

            self::save_featured_video($postId, $request, $ignore);

            if (get_post_type($postId) === 'product') {
                self::save_video_gallery_for_product($postId, $request);
            }

            $hasSliderPayload = self::has_slider_payload($request);
            $hasInvalidSliderPayload = class_exists('Fifu_Slider_Meta_Service', false)
                && Fifu_Slider_Meta_Service::is_invalid_non_empty_slider_payload($request);
            $sliderSaved = self::save_slider_meta($postId, $request);
            self::cleanup_legacy_slider_list_meta_from_editor($postId, $request);
            $hasGalleryPayload = array_key_exists('inputHiddenImageLength', $request)
                || array_key_exists('inputHiddenImageListIds', $request);
            $hasVideoPayload = array_key_exists('fifu_video_input_url', $request)
                || array_key_exists('inputHiddenVideoLength', $request)
                || array_key_exists('inputHiddenVideoListIds', $request);
            if (
                (!$hasSliderPayload || $sliderSaved || $hasInvalidSliderPayload)
                && ($fromDeferredPostSave || $featuredImageChanged || $hasGalleryPayload || $hasVideoPayload || $hasSliderPayload)
            ) {
                self::sync_attachments($postId);

                $width =
                    Fifu_Meta_Box_Dimensions_Reader::
                        get_main_image_width(
                            $request
                        );

                $height =
                    Fifu_Meta_Box_Dimensions_Reader::
                        get_main_image_height(
                            $request
                        );

                $finalAttachmentId =
                    (int) get_post_thumbnail_id(
                        $postId
                    );

                if (
                    $finalAttachmentId > 0
                    && $width !== null
                    && $height !== null
                    && $width > 0
                    && $height > 0
                ) {
                    Fifu_Attachment_Dimensions_Service::
                        update_dimensions(
                            $finalAttachmentId,
                            (int) $width,
                            (int) $height
                        );
                }
            }
        } catch (\Throwable $throwable) {
            $thrownException = $throwable;
            throw $throwable;
        } finally {
            try {
                self::cleanup_temporary_legacy_gallery_meta($postId, $request);
            } catch (\Throwable $cleanupThrowable) {
                if ($thrownException === null) {
                    throw $cleanupThrowable;
                }
            }
        }

        self::maybe_run_auto_category($postId);
    }

    /**
     * Handles featured video logic (fifu_video_url, fifu_custom_video_url, captured frame).
     * It will replace fifu_video_save_properties().
     *
     * @param int $postId
     * @param array $request
     * @param bool $ignore
     */
    private static function save_featured_video(int $postId, array $request, bool $ignore): void
    {
        if (!isset($request['fifu_video_input_url'])) {
            return;
        }

        if (Fifu_Options_Utils::is_off('fifu_video')) {
            return;
        }

        $rawVideoInput = trim((string) $request['fifu_video_input_url']);
        $url = esc_url_raw(rtrim($rawVideoInput));
        $hasManualVideoInput = $rawVideoInput !== '';
        $isExplicitFeaturedVideoRemoval = self::is_explicit_featured_video_removal($postId, $request);

        if ($isExplicitFeaturedVideoRemoval) {
            $postMetaUpdater = FIFU_Post_Meta_Updater::instance();
            $postMetaUpdater->update_or_delete($postId, 'fifu_video_url', '');
            $postMetaUpdater->update_or_delete($postId, 'fifu_custom_video_url', '');
            return;
        }

        if (
            !$hasManualVideoInput
            && Fifu_Options_Utils::is_on('fifu_get_first')
            && self::get_html_media_type() === 'image'
        ) {
            return;
        }

        $selectedMedia = null;

        if (!$hasManualVideoInput && Fifu_Options_Utils::is_on('fifu_get_first')) {
            $selectedMedia = Fifu_Content_Url_Scanner::find_first_media(
                $postId,
                null,
                self::get_html_media_type()
            );

            if (is_array($selectedMedia) && ($selectedMedia['type'] ?? '') === 'image') {
                return;
            }
        }

        if (
            is_array($selectedMedia)
            && ($selectedMedia['type'] ?? '') === 'video'
            && Fifu_Options_Utils::is_on('fifu_video')
            && Fifu_Options_Utils::is_on('fifu_get_first')
            && (!$url || Fifu_Options_Utils::is_on('fifu_ovw_first'))
            && !$ignore
            && !Fifu_Post_Meta_Utils::has_local_featured_image($postId)
            && Fifu_Post_Type_Utils::is_valid_cpt($postId)
        ) {
            $url = (string) ($selectedMedia['url'] ?? '');
        }

        $postMetaUpdater = FIFU_Post_Meta_Updater::instance();
        $customInput = $request['fifu_input_url'] ?? '';
        if (
            $customInput !== ''
            && (Fifu_Video_Helper::is_custom_video($url) || Fifu_Video_Helper::is_local_video($url))
        ) {
            $postMetaUpdater->update_or_delete($postId, 'fifu_custom_video_url', $url);
            $postMetaUpdater->update_or_delete($postId, 'fifu_video_url', '');
            return;
        }

        $postMetaUpdater->update_or_delete($postId, 'fifu_video_url', $url);
        if ($url !== '') {
            $postMetaUpdater->update_or_delete($postId, 'fifu_image_url', '');
            $postMetaUpdater->update_or_delete($postId, 'fifu_custom_video_url', '');

            $frame = $request['fifu_video_captured_frame'] ?? '';
            $timeFrame = $request['fifu_video_time_frame'] ?? '';
            if ($frame) {
                Fifu_Media_Image_Service::upload_captured_frame($frame, $url, $timeFrame);
            }
        } else {
            $postMetaUpdater->update_or_delete($postId, 'fifu_custom_video_url', $url);
        }
    }

    /**
     * Handles product video gallery custom fields (fifu_video_url_*).
     *
     * @param int $postId
     * @param array $request
     */
    private static function save_video_gallery_for_product(int $postId, array $request): void
    {
        if ( empty( $request ) || Fifu_Options_Utils::is_off( 'fifu_video' ) ) {
            return;
        }

        $postMetaUpdater = FIFU_Post_Meta_Updater::instance();
        $featuredVideoUrl = array_key_exists('fifu_video_input_url', $request)
            ? esc_url_raw(rtrim((string) $request['fifu_video_input_url']))
            : '';
        $hasVideoGalleryPayload = array_key_exists('inputHiddenVideoLength', $request)
            || array_key_exists('inputHiddenVideoListIds', $request);
        $expectedVideoUrls = [];

        $length = isset($request['inputHiddenVideoLength']) ? (int) $request['inputHiddenVideoLength'] : 0;
        for ($i = 0; $i < $length; $i++) {
            $postMetaUpdater->delete($postId, 'fifu_video_url_' . $i);
        }

        $list = $request['inputHiddenVideoListIds'] ?? '';
        if ($list !== '') {
            $indexes = explode('|', (string) $list);
            $metaIndex = 0;
            foreach ($indexes as $index) {
                if ($index === '') {
                    continue;
                }

                $inputKey = 'fifu_video_input_url_' . $index;
                if (!isset($request[$inputKey])) {
                    continue;
                }

                $videoUrl = esc_url_raw(rtrim((string) $request[$inputKey]));
                if (
                    $videoUrl !== ''
                    && $featuredVideoUrl !== ''
                    && self::is_same_editor_video_url($videoUrl, $featuredVideoUrl)
                ) {
                    continue;
                }

                if ($videoUrl !== '') {
                    $expectedVideoUrls[] = $videoUrl;
                }

                $postMetaUpdater->update_or_delete($postId, 'fifu_video_url_' . $metaIndex, $videoUrl);
                $metaIndex++;
            }
        }

        $expectedVideos = $expectedVideoUrls ? implode('|', $expectedVideoUrls) : null;
        self::cleanup_legacy_video_list_meta_after_db2_sync($postId, $expectedVideos, $hasVideoGalleryPayload);
    }

    private static function is_same_editor_video_url(string $firstUrl, string $secondUrl): bool
    {
        $firstUrl = trim($firstUrl);
        $secondUrl = trim($secondUrl);

        if ($firstUrl === '' || $secondUrl === '') {
            return false;
        }

        return $firstUrl === $secondUrl;
    }

    private static function cleanup_legacy_image_list_meta_after_db2_sync(
        int $postId,
        ?string $expectedUrls,
        ?string $expectedAlts,
        bool $hasImageGalleryPayload
    ): void {
        if (!$hasImageGalleryPayload) {
            return;
        }

        $normalizedExpectedUrls = self::normalize_pipe_list($expectedUrls);
        $db2GalleryUrls = self::normalize_pipe_list(self::get_db2_image_gallery_list_url($postId));
        if ($db2GalleryUrls !== $normalizedExpectedUrls) {
            return;
        }

        if (metadata_exists('post', $postId, 'fifu_list_url')) {
            delete_post_meta($postId, 'fifu_list_url');
        }

        $normalizedExpectedAlts = self::normalize_pipe_list($expectedAlts);
        $db2GalleryAlts = self::normalize_pipe_list(self::get_db2_image_gallery_alt_list($postId));
        if ($db2GalleryAlts === $normalizedExpectedAlts) {
            if (metadata_exists('post', $postId, 'fifu_list_alt')) {
                delete_post_meta($postId, 'fifu_list_alt');
            }
        }
    }

    private static function cleanup_legacy_slider_list_meta_after_db2_sync(
        int $postId,
        ?string $expectedUrls,
        ?string $expectedAlts,
        bool $hasSliderPayload
    ): void {
        if (!$hasSliderPayload) {
            return;
        }

        $normalizedExpectedUrls = self::normalize_pipe_list($expectedUrls);
        $db2SliderUrls = self::normalize_pipe_list(self::get_db2_slider_list_url($postId));
        if ($db2SliderUrls !== $normalizedExpectedUrls) {
            return;
        }

        delete_post_meta($postId, 'fifu_slider_list_url');

        $normalizedExpectedAlts = self::normalize_pipe_list($expectedAlts);
        $db2SliderAlts = self::normalize_pipe_list(self::get_db2_slider_alt_list($postId));
        if ($db2SliderAlts === $normalizedExpectedAlts) {
            delete_post_meta($postId, 'fifu_slider_list_alt');
        }
    }

    private static function cleanup_legacy_video_list_meta_after_db2_sync(
        int $postId,
        ?string $expectedVideos,
        bool $hasVideoGalleryPayload
    ): void {
        if (!$hasVideoGalleryPayload) {
            return;
        }

        $normalizedExpectedVideos = self::normalize_pipe_list($expectedVideos);
        $galleryState = self::get_db2_video_list_state($postId, true);
        $allVideoState = self::get_db2_video_list_state($postId, false);

        if ($normalizedExpectedVideos === null) {
            if (
                ($galleryState['known'] && $galleryState['value'] === null)
                || ($allVideoState['known'] && $allVideoState['value'] === null)
            ) {
                delete_post_meta($postId, 'fifu_list_video_url');
            }

            return;
        }

        $matchesExpectedGallery =
            $galleryState['known']
            && self::normalize_pipe_list($galleryState['value']) === $normalizedExpectedVideos;

        if (!$matchesExpectedGallery) {
            $matchesExpectedGallery =
                $allVideoState['known']
                && self::normalize_pipe_list($allVideoState['value']) === $normalizedExpectedVideos;
        }

        if ($matchesExpectedGallery) {
            delete_post_meta($postId, 'fifu_list_video_url');
        }
    }

    /**
     * @return array{known:bool,value:?string}
     */
    private static function get_db2_video_list_state(int $postId, bool $galleryOnly): array
    {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return ['known' => false, 'value' => null];
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getPostMappings')) {
            return ['known' => false, 'value' => null];
        }

        $mappings = $manager->getPostMappings($postId, 'video');
        if (!is_array($mappings)) {
            return ['known' => false, 'value' => null];
        }

        usort(
            $mappings,
            static fn(array $a, array $b): int => ($a['key_index'] ?? 0) <=> ($b['key_index'] ?? 0)
        );

        $items = [];
        foreach ($mappings as $mapping) {
            $index = (int) ($mapping['key_index'] ?? 0);
            $url = trim((string) ($mapping['url'] ?? ''));

            if ($url === '') {
                continue;
            }

            if ($galleryOnly && $index === 0) {
                continue;
            }

            $items[] = $url;
        }

        return [
            'known' => true,
            'value' => $items ? implode('|', $items) : null,
        ];
    }

    private static function get_db2_video_list_url(int $postId, bool $galleryOnly): ?string
    {
        $state = self::get_db2_video_list_state($postId, $galleryOnly);
        return $state['known'] ? $state['value'] : null;
    }

    private static function get_html_media_type(): string
    {
        $type = (string) get_option('fifu_html_media', 'image');
        return in_array($type, ['image', 'video', 'all'], true) ? $type : 'image';
    }

    private static function get_db2_image_gallery_list_url(int $postId): ?string
    {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return null;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getPostMappings')) {
            return null;
        }

        $mappings = $manager->getPostMappings($postId, 'image');
        if (!is_array($mappings) || !$mappings) {
            return null;
        }

        usort(
            $mappings,
            static fn(array $a, array $b): int => ($a['key_index'] ?? 0) <=> ($b['key_index'] ?? 0)
        );

        $items = [];
        foreach ($mappings as $mapping) {
            $index = (int) ($mapping['key_index'] ?? 0);
            if ($index <= 0) {
                continue;
            }

            $url = trim((string) ($mapping['url'] ?? ''));
            if ($url === '') {
                continue;
            }

            $items[] = $url;
        }

        if (!$items) {
            return null;
        }

        return implode('|', $items);
    }

    private static function get_db2_image_gallery_alt_list(int $postId): ?string
    {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return null;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getPostAltMappings')) {
            return null;
        }

        $mappings = $manager->getPostAltMappings($postId, 'image');
        if (!is_array($mappings) || !$mappings) {
            return null;
        }

        usort(
            $mappings,
            static fn(array $a, array $b): int => ($a['key_index'] ?? 0) <=> ($b['key_index'] ?? 0)
        );

        $items = [];
        foreach ($mappings as $mapping) {
            $index = (int) ($mapping['key_index'] ?? 0);
            if ($index <= 0) {
                continue;
            }

            $alt = trim((string) ($mapping['alt'] ?? $mapping['value'] ?? ''));
            if ($alt === '') {
                continue;
            }

            $items[] = $alt;
        }

        if (!$items) {
            return null;
        }

        return implode('|', $items);
    }

    private static function get_db2_slider_list_url(int $postId): ?string
    {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return null;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getPostMappings')) {
            return null;
        }

        $mappings = $manager->getPostMappings($postId, 'slider');
        if (!is_array($mappings) || !$mappings) {
            return null;
        }

        usort(
            $mappings,
            static fn(array $a, array $b): int => ($a['key_index'] ?? 0) <=> ($b['key_index'] ?? 0)
        );

        $items = [];
        foreach ($mappings as $mapping) {
            $url = trim((string) ($mapping['url'] ?? ''));
            if ($url === '') {
                continue;
            }

            $items[] = $url;
        }

        if (!$items) {
            return null;
        }

        return implode('|', $items);
    }

    private static function get_db2_slider_alt_list(int $postId): ?string
    {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return null;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getPostAltMappings')) {
            return null;
        }

        $mappings = $manager->getPostAltMappings($postId, 'slider');
        if (!is_array($mappings) || !$mappings) {
            return null;
        }

        usort(
            $mappings,
            static fn(array $a, array $b): int => ($a['key_index'] ?? 0) <=> ($b['key_index'] ?? 0)
        );

        $items = [];
        foreach ($mappings as $mapping) {
            $alt = trim((string) ($mapping['alt'] ?? $mapping['value'] ?? ''));
            if ($alt === '') {
                continue;
            }

            $items[] = $alt;
        }

        if (!$items) {
            return null;
        }

        return implode('|', $items);
    }

    private static function cleanup_legacy_slider_list_meta_from_editor(int $postId, array $request): void
    {
        $hasSliderPayload = array_key_exists('inputHiddenSliderLength', $request)
            || array_key_exists('inputHiddenSliderListIds', $request);
        if (!$hasSliderPayload) {
            return;
        }

        if (
            class_exists('Fifu_Slider_Meta_Service', false)
            && Fifu_Slider_Meta_Service::is_invalid_non_empty_slider_payload($request)
        ) {
            return;
        }

        $expectedSliderUrls = [];
        $expectedSliderAlts = [];
        $list = (string) ($request['inputHiddenSliderListIds'] ?? '');
        if ($list !== '') {
            $indexes = explode('|', $list);
            foreach ($indexes as $index) {
                if ($index === '') {
                    continue;
                }

                $inputUrl = 'fifu_slider_input_url_' . $index;
                if (!isset($request[$inputUrl])) {
                    continue;
                }

                $url = esc_url_raw(rtrim((string) $request[$inputUrl]));
                $alt = trim(wp_strip_all_tags((string) ($request['fifu_slider_input_alt_' . $index] ?? '')));
                if ($url === '') {
                    continue;
                }

                $expectedSliderUrls[] = $url;
                $expectedSliderAlts[] = $alt;
            }
        }

        if ($list !== '' && !$expectedSliderUrls) {
            return;
        }

        self::cleanup_legacy_slider_list_meta_after_db2_sync(
            $postId,
            $expectedSliderUrls ? implode('|', $expectedSliderUrls) : null,
            $expectedSliderAlts ? implode('|', $expectedSliderAlts) : null,
            $hasSliderPayload
        );
    }

    private static function normalize_pipe_list(?string $value): ?string
    {
        if ($value === null) {
            return null;
        }

        $entries = array_values(
            array_filter(
                array_map('trim', explode('|', $value)),
                static fn(string $entry): bool => $entry !== ''
            )
        );

        if (!$entries) {
            return null;
        }

        return implode('|', $entries);
    }

    private static function cleanup_legacy_main_image_alt_after_db2_sync(int $postId): void
    {
        $legacyAlt = trim((string) get_post_meta($postId, 'fifu_image_alt', true));
        if ($legacyAlt === '') {
            return;
        }

        $db2MainAlt = self::get_db2_main_image_alt($postId);
        if ($db2MainAlt !== null && trim($db2MainAlt) === $legacyAlt) {
            delete_post_meta($postId, 'fifu_image_alt');
        }
    }

    private static function get_db2_main_image_alt(int $postId): ?string
    {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return null;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getPostAltMapping')) {
            return null;
        }

        $mapping = $manager->getPostAltMapping($postId, 'image', 0);
        if (!is_array($mapping)) {
            return null;
        }

        $alt = trim((string) ($mapping['alt'] ?? $mapping['value'] ?? ''));
        return $alt === '' ? null : $alt;
    }

    /**
     * @param array<string,mixed> $request
     * @return array{hasPayload:bool,cleanupLength:int,items:array<int,array{url:?string,alt:?string,ifm:?string}>}
     */
    private static function build_expected_temporary_legacy_gallery_state(array $request): array
    {
        $hasPayload = array_key_exists('inputHiddenImageLength', $request)
            || array_key_exists('inputHiddenImageListIds', $request);
        $cleanupLength = isset($request['inputHiddenImageLength']) ? max(0, (int) $request['inputHiddenImageLength']) : 0;
        $items = [];

        $list = (string) ($request['inputHiddenImageListIds'] ?? '');
        if ($list !== '') {
            $indexes = explode('|', $list);
            $metaIndex = 0;
            foreach ($indexes as $index) {
                if ($index === '') {
                    continue;
                }

                $inputUrl = 'fifu_input_url_' . $index;
                $inputAlt = 'fifu_input_alt_' . $index;
                $inputIfm = 'fifu_input_ifm_' . $index;
                if (!isset($request[$inputUrl], $request[$inputAlt], $request[$inputIfm])) {
                    continue;
                }

                $url = esc_url_raw(rtrim((string) $request[$inputUrl]));
                $alt = trim(wp_strip_all_tags((string) $request[$inputAlt]));
                $ifm = self::sanitize_iframe_input($request[$inputIfm]);

                $items[$metaIndex] = [
                    'url' => $url !== '' ? $url : null,
                    'alt' => $alt !== '' ? $alt : null,
                    'ifm' => $ifm !== '' ? $ifm : null,
                ];
                $metaIndex++;
            }
        }

        return [
            'hasPayload' => $hasPayload,
            'cleanupLength' => max($cleanupLength, count($items)),
            'items' => $items,
        ];
    }

    /**
     * @return array{known:bool,value:?string}
     */
    private static function get_db2_gallery_mapping_state(int $postId, string $keyType, int $index): array
    {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return ['known' => false, 'value' => null];
        }

        try {
            $manager = fifu_db2_manager();
            if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getPostMapping')) {
                return ['known' => false, 'value' => null];
            }

            $mapping = $manager->getPostMapping($postId, $keyType, $index);
            if (!is_array($mapping)) {
                return ['known' => true, 'value' => null];
            }

            $value = trim((string) ($mapping['url'] ?? ''));
            return ['known' => true, 'value' => $value !== '' ? $value : null];
        } catch (\Throwable $throwable) {
            return ['known' => false, 'value' => null];
        }
    }

    /**
     * @return array{known:bool,value:?string}
     */
    private static function get_db2_gallery_alt_mapping_state(int $postId, int $index): array
    {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return ['known' => false, 'value' => null];
        }

        try {
            $manager = fifu_db2_manager();
            if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getPostAltMapping')) {
                return ['known' => false, 'value' => null];
            }

            $mapping = $manager->getPostAltMapping($postId, 'image', $index);
            if (!is_array($mapping)) {
                return ['known' => true, 'value' => null];
            }

            $value = trim((string) ($mapping['alt'] ?? $mapping['value'] ?? ''));
            return ['known' => true, 'value' => $value !== '' ? $value : null];
        } catch (\Throwable $throwable) {
            return ['known' => false, 'value' => null];
        }
    }

    /** @return array{known:bool,value:string} */
    private static function get_db2_featured_state(int $postId, string $field): array
    {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return ['known' => false, 'value' => ''];
        }
        try {
            $manager = fifu_db2_manager();
            $method = $field === 'alt' ? 'getPostAltMapping' : 'getPostMapping';
            if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, $method)) {
                return ['known' => false, 'value' => ''];
            }
            $mapping = $manager->{$method}($postId, 'image', 0);
            if (!is_array($mapping)) {
                return ['known' => true, 'value' => ''];
            }
            $value = $field === 'alt'
                ? ($mapping['alt'] ?? $mapping['value'] ?? '')
                : ($mapping['url'] ?? '');
            return ['known' => true, 'value' => self::normalize_featured_media_value((string) $value, $field)];
        } catch (\Throwable $throwable) {
            return ['known' => false, 'value' => ''];
        }
    }

    private static function normalize_featured_media_value(string $value, string $field): string
    {
        if ($field === 'alt') {
            return trim(wp_strip_all_tags($value));
        }
        return esc_url_raw(rtrim($value));
    }

    private static function record_explicit_featured_image_change(int $postId, string $submittedUrl): void
    {
        $currentState = self::get_db2_featured_state($postId, 'url');
        $currentUrl = $currentState['known'] && $currentState['value'] !== ''
            ? $currentState['value']
            : self::normalize_featured_media_value(
                (string) get_post_meta($postId, 'fifu_image_url', true),
                'url'
            );

        $submittedUrl = self::normalize_featured_media_value($submittedUrl, 'url');

        if ($currentUrl !== $submittedUrl) {
            self::$explicitFeaturedImageChanges[$postId] = true;
        }
    }

    public static function has_explicit_featured_image_change(int $postId): bool
    {
        return isset(self::$explicitFeaturedImageChanges[$postId]);
    }

    private static function featured_media_needs_write(int $postId, string $value, string $field): bool
    {
        $legacyKey = $field === 'alt' ? 'fifu_image_alt' : 'fifu_image_url';
        $state = self::get_db2_featured_state($postId, $field);
        return !$state['known']
            || $state['value'] !== self::normalize_featured_media_value($value, $field)
            || metadata_exists('post', $postId, $legacyKey);
    }

    private static function submitted_product_gallery_matches_db2(int $postId, array $request): bool
    {
        $state = self::build_expected_temporary_legacy_gallery_state($request);
        if (!$state['hasPayload'] || self::has_gallery_legacy_cleanup_debt($postId, $state['cleanupLength'])) {
            return false;
        }
        foreach ($request as $key => $value) {
            if (strpos((string) $key, 'fifu_input_source_') === 0 && $value === 'native-preview') {
                return false;
            }
        }
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return false;
        }
        try {
            $manager = fifu_db2_manager();
            if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getPostMappings') || !method_exists($manager, 'getPostAltMappings')) {
                return false;
            }
            $images = $manager->getPostMappings($postId, 'image');
            $alts = $manager->getPostAltMappings($postId, 'image');
            $iframes = $manager->getPostMappings($postId, 'iframe');
            if (!is_array($images) || !is_array($alts) || !is_array($iframes)) {
                return false;
            }
            $imageMap = [];
            foreach ($images as $row) { if (is_array($row) && isset($row['key_index'])) { $imageMap[(int) $row['key_index']] = esc_url_raw(rtrim((string) ($row['url'] ?? ''))); } }
            $altMap = [];
            foreach ($alts as $row) { if (is_array($row) && isset($row['key_index'])) { $altMap[(int) $row['key_index']] = trim(wp_strip_all_tags((string) ($row['alt'] ?? $row['value'] ?? ''))); } }
            $iframeMap = [];
            foreach ($iframes as $row) { if (is_array($row) && isset($row['key_index'])) { $iframeMap[(int) $row['key_index']] = self::sanitize_iframe_input((string) ($row['url'] ?? '')); } }
            $items = array_values($state['items']);
            foreach ($items as $i => $item) {
                $index = $i + 1;
                if (($imageMap[$index] ?? '') !== (string) ($item['url'] ?? '') || ($altMap[$index] ?? '') !== (string) ($item['alt'] ?? '') || ($iframeMap[$i] ?? '') !== (string) ($item['ifm'] ?? '')) {
                    return false;
                }
                unset($imageMap[$index], $altMap[$index], $iframeMap[$i]);
            }
            unset($imageMap[0], $altMap[0]);
            return $imageMap === [] && $altMap === [] && $iframeMap === [];
        } catch (\Throwable $throwable) {
            return false;
        }
    }

    private static function has_gallery_legacy_cleanup_debt(int $postId, int $length): bool
    {
        if (metadata_exists('post', $postId, 'fifu_list_url') || metadata_exists('post', $postId, 'fifu_list_alt')) {
            return true;
        }
        for ($i = 0; $i < $length; $i++) {
            foreach (['fifu_image_url_', 'fifu_image_alt_', 'fifu_image_ifm_'] as $prefix) {
                if (metadata_exists('post', $postId, $prefix . $i)) { return true; }
            }
        }
        return false;
    }

    private static function normalize_gallery_meta_value(?string $value): ?string
    {
        if ($value === null) {
            return null;
        }

        $normalized = trim($value);
        return $normalized === '' ? null : $normalized;
    }

    /**
     * @param array{known:bool,value:?string} $db2State
     */
    private static function can_cleanup_legacy_gallery_meta(array $db2State, ?string $expectedValue): bool
    {
        if (!$db2State['known']) {
            return false;
        }

        return self::normalize_gallery_meta_value($db2State['value']) === self::normalize_gallery_meta_value($expectedValue);
    }

    /**
     * Delegates slider meta saving to Fifu_Slider_Meta_Service.
     *
     * @param int $postId
     * @param array $request
     */
    private static function save_slider_meta(int $postId, array $request): bool
    {
        if (
            class_exists('Fifu_Slider_Meta_Service', false)
            && Fifu_Slider_Meta_Service::is_invalid_non_empty_slider_payload($request)
        ) {
            return false;
        }

        $saved = Fifu_Slider_Meta_Service::save_slider_properties($postId, $request);
        if ($saved) {
            return true;
        }

        if (!self::has_slider_payload($request)) {
            return true;
        }

        $sliderListIds = trim((string) ($request['inputHiddenSliderListIds'] ?? ''));
        if ($sliderListIds === '') {
            return true;
        }

        return false;
    }

    private static function has_slider_payload(array $request): bool
    {
        return array_key_exists('inputHiddenSliderLength', $request)
            || array_key_exists('inputHiddenSliderListIds', $request);
    }

    /**
     * Syncs featured attachment, gallery attachments and theme property images.
     *
     * @param int $postId
     */
    private static function sync_attachments(int $postId): void
    {
        Fifu_Post_Attachment_Sync_Service::sync_featured_attachment($postId);
        Fifu_Post_Attachment_Sync_Service::sync_gallery_attachments($postId);
        Fifu_Post_Attachment_Sync_Service::sync_theme_property_images($postId);
    }

    /**
     * Removes temporary legacy gallery fields used only to rebuild attachments during editor save.
     *
     * @param int $postId
     * @param array $request
     */
    private static function cleanup_temporary_legacy_gallery_meta(int $postId, array $request): void
    {
        if (
            get_post_type($postId) !== 'product'
            || !class_exists('Fifu_Db2_Mode')
            || !function_exists('fifu_db2_mode')
            || fifu_db2_mode() !== Fifu_Db2_Mode::MODE_LEGACY
            || empty($request['fifu_preserve_legacy_gallery_meta_until_sync'])
        ) {
            return;
        }

        $state = self::build_expected_temporary_legacy_gallery_state($request);
        if (!$state['hasPayload']) {
            return;
        }

        $deletedLegacyMeta = false;
        for ($i = 0; $i < $state['cleanupLength']; $i++) {
            $expectedItem = $state['items'][$i] ?? ['url' => null, 'alt' => null, 'ifm' => null];
            $imageDb2Index = $i + 1;

            if (
                self::can_cleanup_legacy_gallery_meta(
                    self::get_db2_gallery_mapping_state($postId, 'image', $imageDb2Index),
                    $expectedItem['url']
                )
            ) {
                delete_post_meta($postId, 'fifu_image_url_' . $i);
                $deletedLegacyMeta = true;
            }

            if (
                self::can_cleanup_legacy_gallery_meta(
                    self::get_db2_gallery_alt_mapping_state($postId, $imageDb2Index),
                    $expectedItem['alt']
                )
            ) {
                delete_post_meta($postId, 'fifu_image_alt_' . $i);
                $deletedLegacyMeta = true;
            }

            if (
                self::can_cleanup_legacy_gallery_meta(
                    self::get_db2_gallery_mapping_state($postId, 'iframe', $i),
                    $expectedItem['ifm']
                )
            ) {
                delete_post_meta($postId, 'fifu_image_ifm_' . $i);
                $deletedLegacyMeta = true;
            }
        }

        if ($deletedLegacyMeta) {
            clean_post_cache($postId);
            wp_cache_delete($postId, 'post_meta');
        }
    }

    /**
     * Runs automatic category image assignment if enabled.
     *
     * @param int $postId
     */
    private static function maybe_run_auto_category(int $postId): void
    {
        if (!Fifu_Options_Utils::is_on('fifu_auto_category')) {
            return;
        }

        Fifu_Auto_Category_Image_Service::run();
    }

    /**
     * Handles the hooked save_post event, replacing the legacy fifu_save_properties logic.
     *
     * TODO: move all guard clauses (autosave, post type checks, block detection),
     * integrations (WCFM, Toolset, AliPlugin, AAWP, external forms), metadata updates,
     * dimension updates, video helpers, and request flags into this method.
     *
     * @param int $postId
     * @param \WP_Post $post
     * @param bool $update
     */
    public static function on_save_post($postId, $post, $update): void
    {
        $postId = is_numeric($postId) ? (int) $postId : 0;
        if ($postId <= 0 || !$post instanceof \WP_Post) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        $post_type = get_post_type($postId);
        if (!$_POST || $post_type == 'nav_menu_item' || $post_type == 'revision') {
            return;
        }

        $action = $_POST['action'] ?? '';
        if ($action == 'woocommerce_do_ajax_product_import') {
            return;
        }

        if (isset($_POST['dokan_edit_product_nonce'])) {
            return;
        }

        if (
            class_exists('Fifu_Wai_Addon_Integration')
            && method_exists('Fifu_Wai_Addon_Integration', 'should_suppress_generic_post_save_media_sync')
            && Fifu_Wai_Addon_Integration::should_suppress_generic_post_save_media_sync($postId)
        ) {
            return;
        }

        $post_content = get_post_field('post_content', $postId);
        $request_content = '';
        if (isset($_POST['content']) && !is_array($_POST['content'])) {
            $request_content = wp_unslash((string) $_POST['content']);
        } elseif (isset($_POST['post_content']) && !is_array($_POST['post_content'])) {
            $request_content = wp_unslash((string) $_POST['post_content']);
        }

        if (
            has_block('fifu/image', $post_content)
            || ($request_content !== '' && has_block('fifu/image', $request_content))
        ) {
            return;
        }

        if ($action == 'wcfm_ajax_controller') {
            if (Fifu_Plugin_Detector::is_wcfm_active() && isset($_POST['wcfm_products_manage_form'])) {
                $image_url = esc_url_raw(
                    rtrim(
                        Fifu_Plugin_Detector::get_wcfm_image_url_from_content($_POST['wcfm_products_manage_form'])
                    )
                );
                Fifu_Developer_Media_Service::set_image(
                    (int) $postId,
                    (string) $image_url
                );
                return;
            }
        }

        $post_status = $_POST['post_status'] ?? '';
        if ($post_status == 'dp-rewrite-republish') {
            Fifu_Developer_Media_Service::set_image(
                (int) $postId,
                ''
            );
            delete_post_meta($postId, 'fifu_image_url');
            delete_post_meta($postId, 'fifu_image_alt');
            return;
        }

        if (!Fifu_Wai_Meta_Service::has_properties()) {
            return;
        }

        $attachment_repository = fifu_attachment_repository();
        $video_oembed_repository = new Fifu_Db2_Video_Oembed_Repository();
        $requiresDeferredMediaSync = false;
        $has_fifu_input_url = array_key_exists('fifu_input_url', $_POST);
        $raw_fifu_input_url = $has_fifu_input_url ? wp_unslash((string) $_POST['fifu_input_url']) : '';
        $fifu_input_url = trim($raw_fifu_input_url);
        $is_empty_fifu_input_url = $has_fifu_input_url && $fifu_input_url === '';

        if ($has_fifu_input_url) {
            self::record_explicit_featured_image_change($postId, $raw_fifu_input_url);
        }

        $clearFeaturedImageForDefault =
            $is_empty_fifu_input_url
            && Fifu_Options_Utils::is_on('fifu_enable_default_url')
            && Fifu_Post_Type_Utils::is_valid_default_cpt($postId);
        if ($clearFeaturedImageForDefault) {
            self::clear_featured_image_state($postId);
            $requiresDeferredMediaSync = true;
        }

        if (Fifu_Post_Meta_Utils::has_local_featured_image($postId)) {
            $auto_set = false;
        } else {
            if ($is_empty_fifu_input_url) {
                $auto_set = true;
            } else {
                if (has_post_thumbnail($postId)) {
                    if (Fifu_Post_Main_Image_Resolver::get_main_image_url($postId, false) != $fifu_input_url) {
                        $auto_set = true;
                    } else {
                        $auto_set = Fifu_Options_Utils::is_on('fifu_ovw_first');
                    }
                } else {
                    $auto_set = false;
                }
            }
        }

        $isExplicitFeaturedVideoRemoval = self::is_explicit_featured_video_removal($postId, $_POST);

        $url = null;
        if ($has_fifu_input_url) {
            $url = esc_url_raw(rtrim($raw_fifu_input_url));
            if (!$clearFeaturedImageForDefault && $auto_set) {
                $selectedMedia = Fifu_Content_Url_Scanner::find_first_media(
                    $postId,
                    null,
                    self::get_html_media_type()
                );

                if (
                    is_array($selectedMedia)
                    && ($selectedMedia['type'] ?? '') === 'video'
                    && !$isExplicitFeaturedVideoRemoval
                ) {
                    return;
                }

                if (
                    is_array($selectedMedia)
                    && ($selectedMedia['type'] ?? '') === 'image'
                    && Fifu_Options_Utils::is_on('fifu_get_first')
                    && (!$url || Fifu_Options_Utils::is_on('fifu_ovw_first'))
                    && !Fifu_Post_Meta_Utils::has_local_featured_image($postId)
                    && Fifu_Post_Type_Utils::is_valid_cpt($postId)
                ) {
                    $url = (string) ($selectedMedia['url'] ?? '');
                }
            }

            if (!$clearFeaturedImageForDefault && self::featured_media_needs_write($postId, $url, 'url')) {
                fifu_update_or_delete($postId, 'fifu_image_url', $url);
                $requiresDeferredMediaSync = true;
            }
        }

        if (!$clearFeaturedImageForDefault) {
            if (Fifu_Plugin_Detector::is_toolset_forms_active() && isset($_POST['wpcf-fifu_image_url'])) {
                $url = esc_url_raw(rtrim($_POST['wpcf-fifu_image_url']));
                if ($url) {
                    fifu_update_or_delete($postId, 'fifu_image_url', $url);
                }
            }

            if (Fifu_Plugin_Detector::is_aliplugin_active() && isset($_POST['imageUrl'])) {
                $url = esc_url_raw(rtrim($_POST['imageUrl']));
                if ($url) {
                    fifu_update_or_delete($postId, 'fifu_image_url', $url);
                }
            }

            if (class_exists('Fifu_Plugin_Detector') && Fifu_Plugin_Detector::is_aawp_active() && !Fifu_Post_Meta_Utils::has_local_featured_image($postId)) {
                $url = Fifu_Aawp_Integration::get_random_bestseller_image_url($postId);
                if ($url) {
                    fifu_update_or_delete($postId, 'fifu_image_url', $url);
                }
            }

            if (!$url && isset($_POST['fifu_image_url']) && !is_array($_POST['fifu_image_url'])) {
                $url = esc_url_raw(rtrim($_POST['fifu_image_url']));
                if ($url) {
                    fifu_update_or_delete($postId, 'fifu_image_url', $url);
                }
            }

            if (isset($_POST['fifu_input_alt'])) {
                $alt = sanitize_text_field(wp_unslash((string) $_POST['fifu_input_alt']));
                if (self::featured_media_needs_write($postId, $alt, 'alt')) {
                    fifu_update_or_delete_value($postId, 'fifu_image_alt', $alt);
                    self::cleanup_legacy_main_image_alt_after_db2_sync($postId);
                    $requiresDeferredMediaSync = true;
                }
            }
        }


        if (isset($_POST['fifu_input_asin'])) {
            $asin = wp_strip_all_tags(trim($_POST['fifu_input_asin']));
            $asin = str_replace('-', '', $asin);
            fifu_update_or_delete_value($postId, 'fifu_asin', $asin);
        }

        if (isset($_POST['fifu_input_finder'])) {
            $page_url = esc_url_raw(rtrim($_POST['fifu_input_finder']));
            fifu_update_or_delete($postId, 'fifu_finder_url', $page_url);
        }

        if (isset($_POST['fifu_input_audio'])) {
            $audio_url = esc_url_raw(rtrim($_POST['fifu_input_audio']));
            fifu_update_or_delete($postId, 'fifu_audio_url', $audio_url);
        }

        if (isset($_POST['fifu_input_redirection'])) {
            $page_url = esc_url_raw(rtrim($_POST['fifu_input_redirection']));
            fifu_update_or_delete($postId, 'fifu_redirection_url', $page_url);
        }

        if (isset($_POST['fifu_input_popup'])) {
            $popup_html = esc_html(rtrim($_POST['fifu_input_popup']));
            fifu_update_or_delete($postId, 'fifu_popup_html', $popup_html);
        }

        if ($post_type == 'product') {
            $hasImageGalleryPayload = array_key_exists('inputHiddenImageLength', $_POST)
                || array_key_exists('inputHiddenImageListIds', $_POST);
            $galleryChanged = $hasImageGalleryPayload
                && !self::submitted_product_gallery_matches_db2($postId, $_POST);
            if ($galleryChanged) {
                $_REQUEST['fifu_preserve_legacy_gallery_meta_until_sync'] = true;
                $requiresDeferredMediaSync = true;
            }
            $expectedImageUrls = [];
            $expectedImageAlts = [];
            if ($galleryChanged && isset($_POST['inputHiddenImageLength'])) {
                $length = $_POST['inputHiddenImageLength'];
                for ($i = 0; $i < $length; $i++) {
                    fifu_delete_post_meta($postId, 'fifu_image_url_' . $i);
                    fifu_delete_post_meta($postId, 'fifu_image_alt_' . $i);
                    fifu_delete_post_meta($postId, 'fifu_image_ifm_' . $i);
                }
            }
            if ($galleryChanged && isset($_POST['inputHiddenImageListIds'])) {
                $list = $_POST['inputHiddenImageListIds'];
                if (strlen($list) !== 0) {
                    $indexes = explode('|', $list);
                    $i = 0;
                    foreach ($indexes as $index) {
                        $input_url = 'fifu_input_url_' . $index;
                        $input_alt = 'fifu_input_alt_' . $index;
                        $input_ifm = 'fifu_input_ifm_' . $index;
                        if (isset($_POST[$input_url]) && isset($_POST[$input_alt]) && isset($_POST[$input_ifm])) {
                            $url = esc_url_raw(rtrim($_POST[$input_url]));
                            $alt = wp_strip_all_tags($_POST[$input_alt]);
                            $ifm = self::sanitize_iframe_input($_POST[$input_ifm]);
                            if ($url !== '') {
                                $expectedImageUrls[] = $url;
                                $expectedImageAlts[] = $alt;
                            }
                            fifu_update_or_delete($postId, 'fifu_image_url_' . $i, $url);
                            fifu_update_or_delete_value($postId, 'fifu_image_alt_' . $i, $alt);
                            fifu_update_or_delete_value($postId, 'fifu_image_ifm_' . $i, $ifm);
                            $i++;
                        }
                    }
                }
            }

            if ($galleryChanged && isset($_POST['inputHiddenImageLength'])) {
                $length = (int) $_POST['inputHiddenImageLength'];
                for ($i = 0; $i < $length; $i++) {
                    $input_source = 'fifu_input_source_' . $i;
                    $input_attachment_id = 'fifu_input_native_attachment_id_' . $i;
                    $input_alt = 'fifu_input_alt_' . $i;
                    if (
                        !isset($_POST[$input_source], $_POST[$input_attachment_id], $_POST[$input_alt])
                        || $_POST[$input_source] !== 'native-preview'
                    ) {
                        continue;
                    }

                    $attachment_id = (int) $_POST[$input_attachment_id];
                    if ($attachment_id <= 0) {
                        continue;
                    }

                    $alt = wp_strip_all_tags($_POST[$input_alt]);
                    update_post_meta($attachment_id, '_wp_attachment_image_alt', $alt);
                    fifu_update_or_delete_value($postId, 'fifu_image_alt_' . $i, $alt);
                }
            }

            if ($galleryChanged) {
                self::cleanup_legacy_image_list_meta_after_db2_sync(
                    $postId,
                    $expectedImageUrls ? implode('|', $expectedImageUrls) : null,
                    $expectedImageAlts ? implode('|', $expectedImageAlts) : null,
                    $hasImageGalleryPayload
                );
            }
        }

        $hasConservativeMediaPayload = array_key_exists('fifu_video_input_url', $_POST)
            || array_key_exists('inputHiddenVideoLength', $_POST)
            || array_key_exists('inputHiddenVideoListIds', $_POST)
            || array_key_exists('inputHiddenSliderLength', $_POST)
            || array_key_exists('inputHiddenSliderListIds', $_POST);
        $requiresDeferredMediaSync = $requiresDeferredMediaSync || $hasConservativeMediaPayload;
        if ($requiresDeferredMediaSync) {
            $_REQUEST['fifu_post_save_pending'] = true;
            $_REQUEST['fifu_post_save_ignore'] = !$auto_set;
            $_REQUEST['fifu_post_save_id'] = $postId;
        } else {
            unset($_REQUEST['fifu_post_save_pending'], $_REQUEST['fifu_post_save_ignore'], $_REQUEST['fifu_post_save_id']);
        }

        $width = Fifu_Meta_Box_Dimensions_Reader::get_main_image_width($_POST);
        $height = Fifu_Meta_Box_Dimensions_Reader::get_main_image_height($_POST);
        $att_id = get_post_thumbnail_id($postId);
        if ($att_id && $width && $height) {
            Fifu_Attachment_Dimensions_Service::update_dimensions($att_id, (int) $width, (int) $height);
        }

        $width = Fifu_Meta_Box_Dimensions_Reader::get_slider_dimensions($_POST, 'width');
        $height = Fifu_Meta_Box_Dimensions_Reader::get_slider_dimensions($_POST, 'height');
        for ($i = 0; $i < sizeof($width); $i++) {
            $slider_input_url = $_POST['fifu_slider_input_url_' . $i] ?? '';
            $att_id = $attachment_repository->find_attachment_id(
                $postId,
                esc_url_raw(rtrim($slider_input_url)),
                false
            );
            $width_value = $width[$i] ?? null;
            $height_value = $height[$i] ?? null;
            if ($att_id && $width_value && $height_value) {
                Fifu_Attachment_Dimensions_Service::update_dimensions($att_id, (int) $width_value, (int) $height_value);
            }
        }

        $width = Fifu_Meta_Box_Dimensions_Reader::get_image_gallery_dimensions($_POST, 'width');
        $height = Fifu_Meta_Box_Dimensions_Reader::get_image_gallery_dimensions($_POST, 'height');
        if (!isset($galleryChanged) || $galleryChanged) for ($i = 0; $i < sizeof($width); $i++) {
            $input_url = $_POST['fifu_input_url_' . $i] ?? '';
            $att_id = $attachment_repository->find_attachment_id(
                $postId,
                esc_url_raw(rtrim($input_url)),
                false
            );
            $width_value = $width[$i] ?? null;
            $height_value = $height[$i] ?? null;
            if ($att_id && $width_value && $height_value) {
                Fifu_Attachment_Dimensions_Service::update_dimensions($att_id, (int) $width_value, (int) $height_value);
            }
        }

        $width = Fifu_Meta_Box_Dimensions_Reader::get_video_gallery_dimensions($_POST, 'width');
        $height = Fifu_Meta_Box_Dimensions_Reader::get_video_gallery_dimensions($_POST, 'height');
        for ($i = 0; $i < sizeof($width); $i++) {
            $video_input_image_src = $_POST['fifu_video_input_image_src_' . $i] ?? '';
            $image_url = esc_url_raw(rtrim($video_input_image_src));
            $att_id = $attachment_repository->find_attachment_id($postId, $image_url, false);
            if (!$att_id) {
                $att_id = $attachment_repository->find_attachment_id(
                    $postId,
                    str_replace('mqdefault', 'maxresdefault', $image_url),
                    false
                );
            }
            $width_value = $width[$i] ?? null;
            $height_value = $height[$i] ?? null;
            if ($att_id && $width_value && $height_value) {
                Fifu_Attachment_Dimensions_Service::update_dimensions($att_id, (int) $width_value, (int) $height_value);
            }
        }

        if (!$requiresDeferredMediaSync) {
            self::maybe_run_auto_category($postId);
        }

        if (isset($_POST['fifu_video_input_url']) && isset($_POST['fifu_video_input_image_src'])) {
            $video_url = esc_url_raw(rtrim($_POST['fifu_video_input_url']));
            $image_url = esc_url_raw(rtrim($_POST['fifu_video_input_image_src']));
            if (Fifu_Video_Helper::is_youtube_video($video_url)) {
                $att_id = get_post_thumbnail_id($postId);
                Fifu_Video_Attachment_Utils::update_youtube_dimensions($att_id, $image_url);

                $db_image_url = $video_oembed_repository->get_image_url_by_video_url($video_url);
                if ($db_image_url && $image_url && $db_image_url != $image_url) {
                    $embed_url = $video_oembed_repository->get_embed_url_by_video_url($video_url);
                    $video_oembed_repository->upsert_oembed($video_url, $image_url, $embed_url ?? '');
                }
            }
        }

        for ($i = 0; $i < sizeof($width); $i++) {
            $video_url = esc_url_raw(rtrim($_POST['fifu_video_input_url_' . $i] ?? ''));
            $image_url = esc_url_raw(rtrim($_POST['fifu_video_input_image_src_' . $i] ?? ''));
            if (Fifu_Video_Helper::is_youtube_video($video_url)) {
                $att_id = $attachment_repository->find_attachment_id($postId, $image_url, false);
                if (!$att_id) {
                    $att_id = $attachment_repository->find_attachment_id(
                        $postId,
                        str_replace('mqdefault', 'maxresdefault', $image_url),
                        false
                    );
                }
                if ($att_id) {
                    Fifu_Video_Attachment_Utils::update_youtube_dimensions((int) $att_id, $image_url);
                }
            }
        }
    }
}
