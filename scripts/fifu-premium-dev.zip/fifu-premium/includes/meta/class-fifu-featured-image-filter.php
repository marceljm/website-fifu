<?php

defined('ABSPATH') || exit;

/**
 * Replaces featured image HTML with FIFU managed content and sliders.
 */
class Fifu_Featured_Image_Filter {

    /**
     * Filters post thumbnail HTML to inject FIFU managed media.
     *
     * @param string       $html
     * @param int          $post_id
     * @param int|null     $post_thumbnail_id
     * @param array|string|null $size
     * @param array|null   $attr
     * @return string
     */
    public static function filter_post_thumbnail_html($html, $post_id, $post_thumbnail_id, $size = null, $attr = null) {
        global $FIFU_SESSION;

        if (!is_string($html) || $html === '') {
            return $html;
        }

        $post_id = is_numeric($post_id) ? (int) $post_id : 0;

        if ($post_id <= 0) {
            return $html;
        }

        $width = Fifu_Html_Attribute_Utils::get_attribute('width', $html);
        $height = Fifu_Html_Attribute_Utils::get_attribute('height', $html);
        $original_class = Fifu_Html_Attribute_Utils::get_attribute('class', $html);
        $delimiter = Fifu_Html_Attribute_Utils::get_delimiter('src', $html);
        $src = Fifu_Html_Attribute_Utils::get_attribute('src', $html);

        if (Fifu_Options_Utils::is_on('fifu_video')) {
            $videoUrl = Fifu_Post_Video_Read_Service::get_video_url((int) $post_id);
            if ($videoUrl) {
                $alt = esc_attr(strip_tags(get_the_title($post_id)));
                $html = preg_replace('/alt=[\'\"][^\'\"]*[\'\"]/', 'alt=' . $delimiter . $alt . $delimiter . ' title=' . $delimiter . $alt . $delimiter, $html);
                return self::inject_error_url_onerror($html, $post_id, $src);
            }
        }
        if (isset($FIFU_SESSION) && isset($FIFU_SESSION[$src])) {
            $data = $FIFU_SESSION[$src];
            if (strpos($html, 'fifu-replaced') !== false) {
                return $html;
            }
        }

        $directImageUrl = self::get_direct_image_url((int) $post_id);
        if ($directImageUrl !== null && class_exists('Fifu_Url_Validation_Queue')) {
            Fifu_Url_Validation_Queue::enqueue_featured_image_url($directImageUrl);
        }
        $sliderEnabled = Fifu_Options_Utils::is_on('fifu_slider');
        $sliderUrl = null;
        if ($sliderEnabled || !$directImageUrl) {
            $sliderUrl = Fifu_Post_Slider_Image_Url_Read_Service::get_slider_image_url((int) $post_id, 0);
        }
        $hasBlockedSliderTheme = Fifu_Theme_Detector::is_houzez_active() || Fifu_Theme_Detector::is_wpresidence_active();

        if ($sliderUrl && $sliderEnabled) {
            if ($hasBlockedSliderTheme) {
                if (!$directImageUrl) {
                    return $html;
                }
            } else {
                if ($width && (int) $width < 175) {
                    return $html;
                }
                if (class_exists('WooCommerce') && is_product()) {
                    return $html;
                }
                if (Fifu_Slider_Policy::should_show_slider_image($post_id, $sliderUrl) && !Fifu_Wp_Context::on_cpt_page()) {
                    return Fifu_Slider_Renderer::render_slider($post_id, $original_class, null, null, (int) $width, (int) $height);
                }
                return $html;
            }
        }

        $url = $directImageUrl;

        $title = null;
        if (Fifu_Options_Utils::is_on('fifu_redirection') && Fifu_Options_Utils::is_on('fifu_auto_set')) {
            $strings = Fifu_Image_Strings::get_strings();
            $redirection_url = Fifu_Post_Redirection_Read_Service::get_redirection_url((int) $post_id);
            if (!empty($redirection_url)) {
                $redirection_parts = explode('/', $redirection_url);
                $redirection_domain = $redirection_parts[2] ?? null;
                if ($redirection_domain) {
                    $title = $strings['photo']['credit']() . ': ' . $redirection_domain;
                }
            }
        }

        $alt = null;
        if ($directImageUrl) {
            $alt = Fifu_Post_Image_Alt_Read_Service::get_image_alt((int) $post_id);
        }
        if (!$alt) {
            $alt = esc_attr(strip_tags(get_the_title($post_id)));
            $title = esc_attr($title ? $title : $alt);
            $custom_alt = 'alt=' . $delimiter . $alt . $delimiter . ' title=' . $delimiter . $title . $delimiter;
            $html = preg_replace('/alt=[\'\"][^\'\"]*[\'\"]/', $custom_alt, $html);
            $html = Fifu_Html_Attribute_Utils::ensure_alt_attribute($html, $custom_alt);
        } else {
            $alt = esc_attr(strip_tags($alt));
            $title = esc_attr($title ? $title : $alt);
            if ($url && $alt) {
                $html = preg_replace('/alt=[\'\"][^\'\"]*[\'\"]/', 'alt=' . $delimiter . $alt . $delimiter . ' title=' . $delimiter . $title . $delimiter, $html);
            }
        }

        $html = self::inject_error_url_onerror($html, $post_id, $src);

        if ($url) {
            return $html;
        }

        $url = !$sliderUrl ? $url : $sliderUrl;

        if ($sliderUrl) {
            $sliderAlt = null;
            if (class_exists('Fifu_Post_Slider_Image_Alt_Read_Service')) {
                $sliderAlt = Fifu_Post_Slider_Image_Alt_Read_Service::get_slider_image_alt((int) $post_id, 0);
            }
            if ($sliderAlt) {
                $alt = esc_attr(strip_tags($sliderAlt));
            } else {
                $alt = esc_attr(strip_tags(get_the_title($post_id)));
            }
        }

        if (!$url && Fifu_Image_Display_Policy::should_hide_featured_media()) {
            return '';
        }

        return !$url ? $html : Fifu_Image_Html_Renderer::build_img_tag($url, $alt, $width, $height);
    }

    private static function get_direct_image_url(int $post_id): ?string {
        if (!class_exists('Fifu_Post_Image_Url_Read_Service')) {
            return null;
        }

        return Fifu_Post_Image_Url_Read_Service::get_image_url($post_id);
    }

    private static function inject_error_url_onerror(string $html, int $post_id, ?string $src): string {
        $errorUrl = self::get_safe_error_url($post_id, $src);

        if ($errorUrl === '') {
            return $html;
        }

        if (strpos($html, 'onerror=') !== false) {
            return $html;
        }

        return str_replace(
            '/>',
            sprintf(
                ' onerror="this.src=\'%s\'; jQuery(this).removeAttr(\'srcset\');"/>',
                esc_js($errorUrl)
            ),
            $html
        );
    }

    private static function get_safe_error_url(int $post_id, ?string $src): string {
        $errorUrl = trim((string) get_option('fifu_error_url'));

        if ($errorUrl === '' || !filter_var($errorUrl, FILTER_VALIDATE_URL)) {
            return '';
        }

        $errorUrl = esc_url_raw($errorUrl);

        if (Fifu_Options_Utils::is_on('fifu_photon')) {
            $errorUrl = Fifu_Jetpack_Cdn_Service::replace_src(
                html_entity_decode((string) $src),
                $errorUrl,
                get_post_thumbnail_id($post_id)
            );
            $errorUrl = esc_url_raw($errorUrl);
        }

        return filter_var($errorUrl, FILTER_VALIDATE_URL) ? $errorUrl : '';
    }
}
