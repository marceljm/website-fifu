<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Reads legacy identifier meta preferring DB2 data.
 */
class Fifu_Post_Identifier_Read_Service {
    public static function get_isbn(int $postId): string {
        return self::read_identifier($postId, 'isbn', 'fifu_isbn');
    }

    public static function get_asin(int $postId): string {
        return self::read_identifier($postId, 'asin', 'fifu_asin');
    }

    private static function read_identifier(int $postId, string $typeKey, string $metaKey): string {
        if ($postId <= 0) {
            return '';
        }

        $db2Value = self::get_identifier_from_db2($postId, $typeKey);
        if ($db2Value !== null) {
            return $db2Value;
        }

        return (string) get_post_meta($postId, $metaKey, true);
    }

    private static function get_identifier_from_db2(int $postId, string $typeKey): ?string {
        if ( ! function_exists( 'fifu_db2_identifier_repository' ) ) {
            return null;
        }

        $repository = fifu_db2_identifier_repository();
        if ( ! $repository instanceof Fifu_Db2_Identifier_Repository ) {
            return null;
        }

        $record = $repository->get_post_identifier($postId, $typeKey);
        if ($record === null) {
            return null;
        }

        $value = trim($record['value'] ?? '');
        if ($value === '') {
            return null;
        }

        if (!empty($record['invalid'])) {
            return 'invalid:' . $value;
        }

        if (!empty($record['not_found'])) {
            return 'not-found:' . $value;
        }

        return $value;
    }
}
