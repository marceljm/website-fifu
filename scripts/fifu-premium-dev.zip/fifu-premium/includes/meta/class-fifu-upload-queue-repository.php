<?php

declare(strict_types=1);

defined('ABSPATH') || exit;

/**
 * Repository for tracking FIFU uploads pending synchronization.
 */
class Fifu_Upload_Queue_Repository {

    /** @var wpdb */
    private wpdb $wpdb;

    /** @var string */
    private string $posts_table;

    /** @var string */
    private string $postmeta_table;

    /** @var string */
    private string $termmeta_table;

    /** @var string */
    private string $fifu_term_map_table;

    /** @var string */
    private string $fifu_map_table;

    /** @var string */
    private string $fifu_key_table;

    /** @var string */
    private string $fifu_url_table;

    /** @var string */
    private string $fifu_sent_table;

    /** @var string */
    private string $fifu_sent_event_table;

    public function __construct(?wpdb $wpdb_instance = null) {
        $this->wpdb = $wpdb_instance ?? $GLOBALS['wpdb'];
        $this->posts_table = $this->wpdb->posts;
        $this->postmeta_table = $this->wpdb->postmeta;
        $this->termmeta_table = $this->wpdb->termmeta;
        $prefix = $this->wpdb->prefix;
        $this->fifu_term_map_table = $prefix . 'fifu_term_map';
        $this->fifu_map_table = $prefix . 'fifu_map';
        $this->fifu_key_table = $prefix . 'fifu_key';
        $this->fifu_url_table = $prefix . 'fifu_url';
        $this->fifu_sent_table = $prefix . 'fifu_sent';
        $this->fifu_sent_event_table = $prefix . 'fifu_sent_event';
    }

    /**
     * Get posts and post types with FIFU URL to be uploaded.
     *
     * @return array
     */
    public function get_posts_with_url_to_upload(): array {
        if (!function_exists('fifu_db2_mode')) {
            return $this->merge_upload_rows(
                $this->get_posts_with_url_to_upload_legacy(),
                $this->get_posts_with_url_to_upload_db2(),
                'post_id'
            );
        }

        $mode = fifu_db2_mode();

        if ($mode === Fifu_Db2_Mode::MODE_LEGACY) {
            return $this->merge_upload_rows(
                $this->get_posts_with_url_to_upload_legacy(),
                $this->get_posts_with_url_to_upload_db2(),
                'post_id'
            );
        }

        $db2Rows = $this->get_posts_with_url_to_upload_db2();

        if ($mode === Fifu_Db2_Mode::MODE_DB2) {
            if ($db2Rows !== null) {
                return $db2Rows;
            }

            return $this->get_posts_with_url_to_upload_legacy();
        }

        $legacyRows = $this->get_posts_with_url_to_upload_legacy();

        if ($db2Rows === null || !class_exists('Fifu_Db2_Query_Helper')) {
            return $legacyRows;
        }

        return Fifu_Db2_Query_Helper::merge_unique_rows_by_int_field(
            $db2Rows,
            $legacyRows,
            'post_id'
        );
    }

    public function get_posts_with_url_to_upload_legacy(): array {
        $domains = get_option('fifu_upload_domain');
        $tokens = is_array($domains) ? $domains : explode(',', (string) $domains);
        $likes = [];
        $params = [];
        $seen = [];
        foreach ($tokens as $domain) {
            $domain = trim((string) $domain);
            if ($domain === '') {
                continue;
            }
            if (isset($seen[$domain])) {
                continue;
            }
            $seen[$domain] = true;
            $likes[] = 'pm.meta_value LIKE %s';
            $params[] = '%' . $this->wpdb->esc_like($domain) . '%';
        }
        $domain_sql = $likes ? ' AND (' . implode(' OR ', $likes) . ')' : '';
        $sentClause = $this->get_db2_sent_not_exists_clause('post', 'uploadpost', 'pm.post_id');

        $sql = "
            SELECT DISTINCT pm.post_id, p.post_type, pm.meta_value AS fifu_upload_url
            FROM {$this->postmeta_table} pm
            INNER JOIN {$this->posts_table} p ON pm.post_id = p.ID
            WHERE (
                pm.meta_key = 'fifu_image_url'
                OR (
                    pm.meta_key = 'fifu_slider_image_url_0'
                    AND p.post_type IN ('product', 'product_variation')
                )
            )
            {$domain_sql}
            AND NOT EXISTS (
                SELECT 1
                FROM {$this->postmeta_table} pm2
                WHERE pm2.post_id = pm.post_id
                  AND pm2.meta_key = 'fifu_uploadpost_sent'
            )
            {$sentClause}
            LIMIT 1000
        ";
        if ($params) {
            $sql = $this->wpdb->prepare($sql, ...$params);
        }
        $results = $this->wpdb->get_results($sql);
        if (!is_array($results)) {
            return $results ?: [];
        }

        return $this->filter_rows_by_allowed_domains($results, $domains);
    }

    public function get_posts_with_url_to_upload_db2(): ?array {
        if (!$this->is_db2_ready()) {
            return null;
        }

        $domains = get_option('fifu_upload_domain');
        $tokens = is_array($domains) ? $domains : explode(',', (string) $domains);
        $likes = [];
        $params = [];
        $seen = [];
        foreach ($tokens as $domain) {
            $domain = trim((string) $domain);
            if ($domain === '') {
                continue;
            }
            if (isset($seen[$domain])) {
                continue;
            }
            $seen[$domain] = true;
            $likes[] = 'u.url LIKE %s';
            $params[] = '%' . $this->wpdb->esc_like($domain) . '%';
        }
        $domain_sql = $likes ? ' AND (' . implode(' OR ', $likes) . ')' : '';
        $map = $this->fifu_map_table;
        $key = $this->fifu_key_table;
        $url = $this->fifu_url_table;
        $sent = $this->fifu_sent_table;
        $sent_event = $this->fifu_sent_event_table;

        $sql = "
            SELECT DISTINCT m.post_id, p.post_type, u.url AS fifu_upload_url
            FROM {$map} m
            INNER JOIN {$key} k ON k.key_id = m.key_id
            INNER JOIN {$url} u ON u.hash = m.hash
            INNER JOIN {$this->posts_table} p ON p.ID = m.post_id
            WHERE (
                (k.key_type = 'image' AND m.key_index = 0)
                OR (
                    k.key_type = 'slider'
                    AND m.key_index = 0
                    AND p.post_type IN ('product', 'product_variation')
                )
            )
            {$domain_sql}
            AND NOT EXISTS (
                SELECT 1
                FROM {$sent} s
                INNER JOIN {$sent_event} e ON e.id = s.event_id
                WHERE s.object_type = 'post'
                  AND s.object_id = m.post_id
                  AND s.sent = 1
                  AND e.event_key = 'uploadpost'
            )
            LIMIT 1000
        ";
        if ($params) {
            $sql = $this->wpdb->prepare($sql, ...$params);
        }

        $results = $this->wpdb->get_results($sql);
        if ($results === false) {
            return null;
        }

        if (!is_array($results)) {
            return $results ?: [];
        }

        return $this->filter_rows_by_allowed_domains($results, $domains);
    }

    private function is_db2_ready(): bool {
        return $this->table_exists($this->fifu_map_table)
            && $this->table_exists($this->fifu_key_table)
            && $this->table_exists($this->fifu_url_table)
            && $this->table_exists($this->fifu_sent_table)
            && $this->table_exists($this->fifu_sent_event_table);
    }

    private function table_exists(string $table): bool {
        $sql = $this->wpdb->prepare("SHOW TABLES LIKE %s", $table);
        $result = $this->wpdb->get_var($sql);
        return $result !== null;
    }

    private function get_db2_sent_not_exists_clause(string $object_type, string $event_key, string $object_column): string {
        if (!$this->table_exists($this->fifu_sent_table) || !$this->table_exists($this->fifu_sent_event_table)) {
            return '';
        }

        $sentTable = $this->fifu_sent_table;
        $eventTable = $this->fifu_sent_event_table;

        return "
            AND NOT EXISTS (
                SELECT 1
                FROM {$sentTable} s
                INNER JOIN {$eventTable} e ON e.id = s.event_id
                WHERE s.object_type = '{$object_type}'
                  AND s.object_id = {$object_column}
                  AND e.event_key = '{$event_key}'
                  AND s.sent = 1
            )
        ";
    }

    /**
     * Get terms with FIFU URL to be uploaded.
     *
     * @return array
     */
    public function get_terms_with_url_to_upload(): array {
        if (!function_exists('fifu_db2_mode')) {
            return $this->merge_upload_rows(
                $this->get_terms_with_url_to_upload_legacy(),
                $this->get_terms_with_url_to_upload_db2(),
                'post_id'
            );
        }

        $mode = fifu_db2_mode();

        if ($mode === Fifu_Db2_Mode::MODE_LEGACY) {
            return $this->merge_upload_rows(
                $this->get_terms_with_url_to_upload_legacy(),
                $this->get_terms_with_url_to_upload_db2(),
                'post_id'
            );
        }

        $db2Rows = $this->get_terms_with_url_to_upload_db2();

        if ($mode === Fifu_Db2_Mode::MODE_DB2) {
            if ($db2Rows !== null) {
                return $db2Rows;
            }

            return $this->get_terms_with_url_to_upload_legacy();
        }

        $legacyRows = $this->get_terms_with_url_to_upload_legacy();

        if ($db2Rows === null || !class_exists('Fifu_Db2_Query_Helper')) {
            return $legacyRows;
        }

        return Fifu_Db2_Query_Helper::merge_unique_rows_by_int_field(
            $db2Rows,
            $legacyRows,
            'post_id'
        );
    }

    /**
     * Legacy SQL path for terms with FIFU metadata upload URLs.
     *
     * @return array
     */
    public function get_terms_with_url_to_upload_legacy(): array {
        $domains = get_option('fifu_upload_domain');
        $tokens = is_array($domains) ? $domains : explode(',', (string) $domains);
        $likes = [];
        $params = [];
        $seen = [];
        foreach ($tokens as $domain) {
            $domain = trim((string) $domain);
            if ($domain === '') {
                continue;
            }
            if (isset($seen[$domain])) {
                continue;
            }
            $seen[$domain] = true;
            $likes[] = 'tm.meta_value LIKE %s';
            $params[] = '%' . $this->wpdb->esc_like($domain) . '%';
        }
        $domain_sql = $likes ? ' AND (' . implode(' OR ', $likes) . ')' : '';
        $sentClause = $this->get_db2_sent_not_exists_clause('term', 'uploadterm', 'tm.term_id');

        $sql = "
            SELECT DISTINCT tm.term_id AS post_id, tm.meta_value AS fifu_upload_url
            FROM {$this->termmeta_table} tm
            WHERE tm.meta_key = 'fifu_image_url'
            {$domain_sql}
            AND NOT EXISTS (
                SELECT 1
                FROM {$this->termmeta_table} tm2
                WHERE tm2.term_id = tm.term_id
                  AND tm2.meta_key = 'fifu_uploadterm_sent'
            )
            {$sentClause}
            LIMIT 1000
        ";
        if ($params) {
            $sql = $this->wpdb->prepare($sql, ...$params);
        }
        $results = $this->wpdb->get_results($sql);
        if (!is_array($results)) {
            return $results ?: [];
        }

        return $this->filter_rows_by_allowed_domains($results, $domains);
    }

    /**
     * DB2 SQL path for terms with FIFU metadata upload URLs.
     *
     * @return array|null
     */
    public function get_terms_with_url_to_upload_db2(): ?array {
        if (!$this->is_term_db2_ready()) {
            return null;
        }

        $domains = get_option('fifu_upload_domain');
        $tokens = is_array($domains) ? $domains : explode(',', (string) $domains);
        $likes = [];
        $params = [];
        $seen = [];
        foreach ($tokens as $domain) {
            $domain = trim((string) $domain);
            if ($domain === '') {
                continue;
            }
            if (isset($seen[$domain])) {
                continue;
            }
            $seen[$domain] = true;
            $likes[] = 'u.url LIKE %s';
            $params[] = '%' . $this->wpdb->esc_like($domain) . '%';
        }
        $domain_sql = $likes ? ' AND (' . implode(' OR ', $likes) . ')' : '';
        $map = $this->fifu_term_map_table;
        $key = $this->fifu_key_table;
        $url = $this->fifu_url_table;
        $sent = $this->fifu_sent_table;
        $sent_event = $this->fifu_sent_event_table;

        $sql = "
            SELECT DISTINCT m.term_id AS post_id, u.url AS fifu_upload_url
            FROM {$map} m
            INNER JOIN {$key} k ON k.key_id = m.key_id
            INNER JOIN {$url} u ON u.hash = m.hash
            WHERE k.key_type = 'image'
            {$domain_sql}
            AND NOT EXISTS (
                SELECT 1
                FROM {$sent} s
                INNER JOIN {$sent_event} e ON e.id = s.event_id
                WHERE s.object_type = 'term'
                  AND s.object_id = m.term_id
                  AND s.sent = 1
                  AND e.event_key = 'uploadterm'
            )
            LIMIT 1000
        ";
        if ($params) {
            $sql = $this->wpdb->prepare($sql, ...$params);
        }

        $results = $this->wpdb->get_results($sql);
        if ($results === false) {
            return null;
        }

        if (!is_array($results)) {
            return $results ?: [];
        }

        return $this->filter_rows_by_allowed_domains($results, $domains);
    }

    /**
     * Ensures DB2 tables required for term lookups exist.
     *
     * @return bool
     */
    private function is_term_db2_ready(): bool {
        return $this->is_db2_ready()
            && $this->table_exists($this->fifu_term_map_table);
    }

    /**
     * Upload-job discovery must continue to see DB2-backed URLs even when the site still runs in legacy mode.
     */
    private function merge_upload_rows(array $legacyRows, ?array $db2Rows, string $field): array {
        if ($db2Rows === null) {
            return $legacyRows;
        }

        if (class_exists('Fifu_Db2_Query_Helper')) {
            return Fifu_Db2_Query_Helper::merge_unique_rows_by_int_field(
                $db2Rows,
                $legacyRows,
                $field
            );
        }

        $merged = [];
        foreach (array_merge($db2Rows, $legacyRows) as $row) {
            if (!is_object($row) || !isset($row->{$field})) {
                continue;
            }

            $id = (int) $row->{$field};
            if ($id <= 0 || isset($merged[$id])) {
                continue;
            }

            $merged[$id] = $row;
        }

        return array_values($merged);
    }

    /**
     * @param mixed $domains
     * @return string[]
     */
    private function normalize_domain_tokens($domains): array {
        $tokens = is_array($domains) ? $domains : explode(',', (string) $domains);
        $normalized = [];

        foreach ($tokens as $domain) {
            $domain = trim((string) $domain);
            if ($domain === '') {
                continue;
            }

            if (strpos($domain, '://') === false) {
                $domain = 'http://' . $domain;
            }

            $host = parse_url($domain, PHP_URL_HOST);
            $host = is_string($host) ? strtolower(rtrim($host, '.')) : '';
            if ($host !== '') {
                $normalized[$host] = true;
            }
        }

        return array_keys($normalized);
    }

    /**
     * @param mixed $url
     */
    private function row_url_matches_allowed_domains($url, array $domains): bool {
        $url = trim((string) $url);
        if ($url === '') {
            return false;
        }

        $host = parse_url($url, PHP_URL_HOST);
        $host = is_string($host) ? strtolower(rtrim($host, '.')) : '';
        if ($host === '') {
            return false;
        }

        foreach ($domains as $domain) {
            $domain = strtolower(rtrim(trim((string) $domain), '.'));
            if ($domain === '') {
                continue;
            }

            if ($host === $domain) {
                return true;
            }

            $suffix = '.' . $domain;
            if (strlen($host) > strlen($suffix) && substr($host, -strlen($suffix)) === $suffix) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param array<int, object> $rows
     * @param mixed $domains
     * @param string $urlField
     * @return array<int, object>
     */
    private function filter_rows_by_allowed_domains(array $rows, $domains, string $urlField = 'fifu_upload_url'): array {
        $domains = $this->normalize_domain_tokens($domains);
        if (!$domains) {
            return array_values($rows);
        }

        $filtered = [];
        foreach ($rows as $row) {
            if (!is_object($row) || !property_exists($row, $urlField)) {
                $filtered[] = $row;
                continue;
            }

            $url = $row->{$urlField} ?? '';
            if ($this->row_url_matches_allowed_domains($url, $domains)) {
                $filtered[] = $row;
            }
        }

        return array_values($filtered);
    }
}
