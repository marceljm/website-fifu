<?php
declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

/**
 * Product variation meta helpers for FIFU Premium.
 */
class Fifu_Product_Variation_Meta_Repository {

    private wpdb $wpdb;

    private string $posts_table;

    private string $postmeta_table;

    public function __construct(?wpdb $wpdb = null) {
        $this->wpdb = $wpdb ?? $GLOBALS['wpdb'];
        $this->posts_table = $this->wpdb->posts;
        $this->postmeta_table = $this->wpdb->postmeta;
    }

    /**
     * Returns attribute metadata for a parent's product variations.
     *
     * Mirrors get_variation_attributes().
     *
     * @return array<object>
     */
    public function get_variation_attributes(int $parent_post_id): array {
        $sql = $this->wpdb->prepare(
            "SELECT *
            FROM {$this->postmeta_table} pm
            WHERE post_id IN (
                SELECT id
                FROM {$this->posts_table} p
                WHERE p.post_parent = %d
                  AND p.post_type = 'product_variation'
            )
            AND pm.meta_key LIKE 'attribute_%'",
            $parent_post_id
        );
        return $this->wpdb->get_results($sql);
    }

    /**
     * Returns thumbnail and gallery IDs for product variations.
     *
     * Mirrors get_variation_att_ids().
     *
     * @return array<object>
     */
    public function get_variation_attachment_ids(int $parent_post_id): array {
        $sql = $this->wpdb->prepare(
            "SELECT post_id, GROUP_CONCAT(meta_value) AS att_ids
            FROM {$this->postmeta_table} pm
            WHERE post_id IN (
                SELECT id
                FROM {$this->posts_table} p
                WHERE p.post_parent = %d
                  AND p.post_type = 'product_variation'
            )
            AND pm.meta_key IN ('_thumbnail_id', '_product_image_gallery')
            GROUP BY post_id",
            $parent_post_id
        );
        return $this->wpdb->get_results($sql);
    }

    /**
     * Returns raw attribute metadata for a set of variation IDs.
     *
     * @param int[] $variation_ids Variation post IDs.
     * @return array<int, array<string, string>>
     */
    public function get_variation_attributes_by_ids(array $variation_ids): array {
        if (empty($variation_ids)) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($variation_ids), '%d'));
        $sql = "SELECT post_id, meta_key, meta_value
            FROM {$this->postmeta_table}
            WHERE post_id IN ({$placeholders})
              AND meta_key LIKE 'attribute_%'";

        $results = $this->wpdb->get_results($this->wpdb->prepare($sql, $variation_ids), ARRAY_A);
        $attributes = [];
        foreach ($results as $result) {
            $attributes[ $result['post_id'] ][ $result['meta_key'] ] = $result['meta_value'];
        }

        return $attributes;
    }
}
