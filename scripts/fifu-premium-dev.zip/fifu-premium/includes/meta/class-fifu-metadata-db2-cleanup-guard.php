<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

final class Fifu_Metadata_Db2_Cleanup_Guard
{
    /**
     * Normalize a scalar value into a trimmed string.
     *
     * @param mixed $value
     */
    private static function normalize_scalar_value($value): ?string
    {
        if ($value === null || $value === false) {
            return null;
        }

        if (is_array($value)) {
            $normalized = self::normalize_pipe_list($value);
            return $normalized === [] ? null : implode('|', $normalized);
        } elseif (!is_scalar($value)) {
            return null;
        }

        $value = trim((string) $value);
        if ($value === '') {
            return null;
        }

        if (preg_match('/^(null|undefined)$/i', $value) === 1) {
            return null;
        }

        $value = self::strip_html_tags($value);
        $value = trim($value);
        if ($value === '') {
            return null;
        }

        if (preg_match('/^(null|undefined)$/i', $value) === 1) {
            return null;
        }

        return $value;
    }

    /**
     * @param mixed $value
     * @return array<int, string>
     */
    public static function normalize_pipe_list($value): array
    {
        if ($value === null || $value === false || $value === '') {
            return [];
        }

        if (is_array($value)) {
            $normalized = [];
            foreach ($value as $item) {
                $itemValue = self::normalize_scalar_value($item);
                if ($itemValue === null) {
                    continue;
                }

                $normalized[] = $itemValue;
            }

            return $normalized;
        }

        if (!is_scalar($value)) {
            return [];
        }

        $segments = explode('|', (string) $value);
        $normalized = [];
        foreach ($segments as $segment) {
            $segmentValue = self::normalize_scalar_value($segment);
            if ($segmentValue === null) {
                continue;
            }

            $normalized[] = $segmentValue;
        }

        return $normalized;
    }

    /**
     * @param mixed $legacyValue
     * @param mixed $db2Value
     */
    public static function values_match($legacyValue, $db2Value): bool
    {
        $legacy = self::normalize_scalar_value($legacyValue);
        $db2 = self::normalize_scalar_value($db2Value);

        return $legacy !== null && $db2 !== null && $legacy === $db2;
    }

    /**
     * @param mixed $legacyValue
     * @param mixed $db2Value
     */
    public static function pipe_lists_match($legacyValue, $db2Value): bool
    {
        $legacy = self::normalize_pipe_list($legacyValue);
        $db2 = self::normalize_pipe_list($db2Value);

        if ($legacy === [] || $db2 === []) {
            return false;
        }

        if (count($legacy) !== count($db2)) {
            return false;
        }

        foreach ($legacy as $index => $legacyItem) {
            if (!array_key_exists($index, $db2) || $legacyItem !== $db2[$index]) {
                return false;
            }
        }

        return true;
    }

    /**
     * @param mixed $legacyValue
     * @param mixed $db2Value
     */
    public static function can_cleanup_scalar($legacyValue, $db2Value): bool
    {
        return self::values_match($legacyValue, $db2Value);
    }

    /**
     * @param mixed $legacyValue
     * @param mixed $db2Value
     */
    public static function can_cleanup_pipe_list($legacyValue, $db2Value): bool
    {
        return self::pipe_lists_match($legacyValue, $db2Value);
    }

    /**
     * @param mixed $legacyUrl
     * @param mixed $legacyAlt
     * @param mixed $db2Url
     * @param mixed $db2Alt
     */
    public static function can_cleanup_url_and_alt($legacyUrl, $legacyAlt, $db2Url, $db2Alt): bool
    {
        if (!self::values_match($legacyUrl, $db2Url)) {
            return false;
        }

        $legacyAltValue = self::normalize_scalar_value($legacyAlt);
        if ($legacyAltValue === null) {
            return true;
        }

        return self::values_match($legacyAltValue, $db2Alt);
    }

    /**
     * @param mixed $legacyUrls
     * @param mixed $legacyAlts
     * @param mixed $db2Urls
     * @param mixed $db2Alts
     */
    public static function can_cleanup_url_list_and_alt_list($legacyUrls, $legacyAlts, $db2Urls, $db2Alts): bool
    {
        $legacyUrlList = self::normalize_pipe_list($legacyUrls);
        $db2UrlList = self::normalize_pipe_list($db2Urls);

        if ($legacyUrlList === [] || $db2UrlList === []) {
            return false;
        }

        if (count($legacyUrlList) !== count($db2UrlList)) {
            return false;
        }

        foreach ($legacyUrlList as $index => $legacyUrl) {
            if (!array_key_exists($index, $db2UrlList) || $legacyUrl !== $db2UrlList[$index]) {
                return false;
            }
        }

        $legacyAltList = self::normalize_pipe_list($legacyAlts);
        if ($legacyAltList === []) {
            return true;
        }

        $db2AltList = self::normalize_pipe_list($db2Alts);
        if ($db2AltList === [] || count($legacyAltList) !== count($db2AltList)) {
            return false;
        }

        foreach ($legacyAltList as $index => $legacyAlt) {
            if (!array_key_exists($index, $db2AltList) || $legacyAlt !== $db2AltList[$index]) {
                return false;
            }
        }

        return true;
    }

    /**
     * Strip HTML tags using WordPress helpers when available.
     */
    private static function strip_html_tags(string $value): string
    {
        if (function_exists('wp_strip_all_tags')) {
            return (string) wp_strip_all_tags($value);
        }

        return strip_tags($value);
    }
}
