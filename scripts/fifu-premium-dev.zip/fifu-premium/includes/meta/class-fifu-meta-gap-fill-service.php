<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

final class Fifu_Meta_Gap_Fill_Service {
    /**
     * Creates local attachments for terms that have FIFU external image/video meta
     * but no internal thumbnail_id, and links the new attachment to the term.
     *
     * @return void
     */
    public static function backfill_term_attachments(): void
    {
        $meta_gap_repository = new Fifu_Meta_Gap_Repository();

        foreach ($meta_gap_repository->get_categories_without_meta() as $res) {
            $term_id = (int) ($res->post_id ?? 0);

            if ($term_id <= 0) {
                continue;
            }

            Fifu_Post_Attachment_Sync_Service::sync_category_attachment(
                $term_id,
                true
            );
        }
    }

    /**
     * Creates local attachments for posts that have FIFU external image meta
     * but no internal _thumbnail_id, and sets the new attachment as featured image.
     *
     * @return void
     */
    public static function backfill_post_attachments(): void {
        $meta_gap_repository = new Fifu_Meta_Gap_Repository();
        $gapRows = $meta_gap_repository->get_posts_without_meta();

        foreach ($gapRows as $res) {
            self::backfill_post_attachment((int) $res->post_id);
        }
    }

    /**
     * Creates local featured attachments for a specific list of posts.
     *
     * @param int[] $postIds
     * @return void
     */
    public static function backfill_post_attachments_for_posts(array $postIds): void
    {
        $postIds = array_values(array_unique(array_filter(array_map('intval', $postIds), static fn(int $postId): bool => $postId > 0)));

        foreach ($postIds as $postId) {
            self::backfill_post_attachment($postId);
        }
    }

    /**
     * Backfill a featured attachment for a single post ID.
     *
     * @param int $post_id
     * @return void
     */
    private static function backfill_post_attachment(int $post_id): void
    {
        $attachment_factory = new Fifu_Attachment_Factory();
        $alt = Fifu_Post_Image_Alt_Read_Service::get_image_alt($post_id);
        $url = Fifu_Post_Main_Image_Resolver::get_main_image_url($post_id, false);

        if ($url === null || $url === '') {
            return;
        }

        $att_id = $attachment_factory->create_attachment_for_url($url, $alt, $post_id);
        if ($att_id) {
            update_post_meta($post_id, '_thumbnail_id', $att_id);
            update_post_meta($att_id, '_wp_attached_file', $url);
            if ($alt) {
                update_post_meta($att_id, '_wp_attachment_image_alt', $alt);
            }
        }
    }

    /**
     * Resolve DB2 dimensions for a term attachment URL when available.
     *
     * @param int $term_id
     * @param string $url
     * @return array{width:int|null,height:int|null}
     */
    private static function get_term_attachment_dimensions(int $term_id, string $url, string $preferred_key_type = 'image'): array
    {
        $empty = [
            'width' => null,
            'height' => null,
        ];

        if ($term_id <= 0 || trim($url) === '' || !function_exists('fifu_db2_manager')) {
            return $empty;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getTermMapping')) {
            return $empty;
        }

        $target_url = self::normalize_term_dimension_url($url);

        $key_types = $preferred_key_type === 'video' ? ['video', 'image'] : ['image', 'video'];

        foreach ($key_types as $key_type) {
            $mapping = $manager->getTermMapping($term_id, $key_type);
            if (!is_array($mapping)) {
                continue;
            }

            $mapping_url = self::normalize_term_dimension_url((string) ($mapping['url'] ?? ''));
            if ($key_type !== 'video' && $mapping_url !== '' && $target_url !== '' && $mapping_url !== $target_url) {
                continue;
            }

            $width = isset($mapping['width']) ? (int) $mapping['width'] : 0;
            $height = isset($mapping['height']) ? (int) $mapping['height'] : 0;

            if ($width > 0 && $height > 0) {
                return [
                    'width' => $width,
                    'height' => $height,
                ];
            }
        }

        return $empty;
    }

    /**
     * Normalize remote URLs for DB2 dimension matching.
     *
     * @param string $url
     * @return string
     */
    private static function normalize_term_dimension_url(string $url): string
    {
        return trim(htmlspecialchars_decode($url));
    }
}
