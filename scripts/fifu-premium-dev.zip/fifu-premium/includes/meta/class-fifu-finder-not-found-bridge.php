<?php

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Mirrors the legacy finder counter meta with the DB2 sent infrastructure.
 */
class Fifu_Finder_Not_Found_Bridge {

	private const EVENT_KEY = 'finder_not_found';
	private const LEGACY_META_KEY = 'fifu_finder_counter';

	/**
	 * Returns the attempts count from DB2 when available, falling back to the legacy meta.
	 */
	public static function get_post_attempts( int $post_id ): ?int {
		if ( $post_id <= 0 ) {
			return null;
		}

		$status = self::try_db2_get_status( $post_id );
		if ( $status !== null ) {
			if ( isset( $status['sent'] ) && (int) $status['sent'] === 1 ) {
				return null;
			}

			if ( isset( $status['attempts'] ) ) {
				return (int) $status['attempts'];
			}
		}

		return self::legacy_get_attempts( $post_id );
	}

	/**
	 * Updates the counter in DB2 and keeps the legacy value for DB2-less installs.
	 */
	public static function set_post_attempts( int $post_id, int $attempts, ?string $last_error = null ): bool {
		if ( $post_id <= 0 ) {
			return false;
		}

		$attempts = max( 0, $attempts );

		if ( self::db2_service() === null ) {
			return update_post_meta( $post_id, self::LEGACY_META_KEY, $attempts ) !== false;
		}

		$ok = self::try_db2_set_attempts( $post_id, $attempts, $last_error );
		if ( $ok ) {
			self::delete_legacy_counter_raw( $post_id );
		}

		return $ok;
	}

	/**
	 * Deletes the legacy counter and marks the DB2 event as sent.
	 */
	public static function delete_post_counter( int $post_id ): bool {
		if ( $post_id <= 0 ) {
			return false;
		}

		if ( self::db2_service() === null ) {
			return delete_post_meta( $post_id, self::LEGACY_META_KEY );
		}

		$ok = self::try_db2_mark_sent_ok( $post_id );
		if ( $ok ) {
			self::delete_legacy_counter_raw( $post_id );
		}

		return $ok;
	}

	private static function legacy_get_attempts( int $post_id ): ?int {
		$value = get_post_meta( $post_id, self::LEGACY_META_KEY, true );

		return self::normalize_legacy_attempts( $value );
	}

	/**
	 * Clears out values that can not be interpreted as a valid attempt count.
	 */
	private static function normalize_legacy_attempts( $value ): ?int {
		if ( $value === '' || $value === null || $value === false || is_array( $value ) ) {
			return null;
		}

		$attempts = filter_var( $value, FILTER_VALIDATE_INT, [ 'options' => [ 'min_range' => 0 ] ] );
		if ( $attempts === false ) {
			return null;
		}

		return $attempts;
	}

	private static function try_db2_get_status( int $post_id ): ?array {
		$service = self::db2_service();
		if ( $service === null ) {
			return null;
		}

		try {
			return $service->get_status( 'post', $post_id, self::EVENT_KEY );
		} catch ( \Throwable $exception ) {
			return null;
		}
	}

	private static function try_db2_set_attempts( int $post_id, int $attempts, ?string $last_error ): bool {
		$service = self::db2_service();
		if ( $service === null ) {
			return false;
		}

		try {
			$service->set_attempts( 'post', $post_id, self::EVENT_KEY, $attempts, $last_error );
			return true;
		} catch ( \Throwable $exception ) {
			// Silently ignore DB2 failures so the legacy flow continues.
			return false;
		}
	}

	private static function try_db2_mark_sent_ok( int $post_id ): bool {
		$service = self::db2_service();
		if ( $service === null ) {
			return false;
		}

		try {
			$service->mark_sent_ok( 'post', $post_id, self::EVENT_KEY );
			return true;
		} catch ( \Throwable $exception ) {
			// Silently ignore DB2 failures so the legacy flow continues.
			return false;
		}
	}

	private static function delete_legacy_counter_raw( int $post_id ): void {
		if ( $post_id <= 0 ) {
			return;
		}

		global $wpdb;

		$wpdb->delete(
			$wpdb->postmeta,
			[
				'post_id'  => $post_id,
				'meta_key' => self::LEGACY_META_KEY,
			],
			[
				'%d',
				'%s',
			]
		);

		clean_post_cache( $post_id );
		wp_cache_delete( $post_id, 'post_meta' );
	}

	private static function db2_service(): ?Fifu_Db2_Sent_Service {
		if ( ! function_exists( 'fifu_db2_sent_service' ) ) {
			return null;
		}

		return fifu_db2_sent_service();
	}
}
