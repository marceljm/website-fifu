<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

final class Fifu_Legacy_Media_Meta_Cleanup_Service
{
    /**
     * @param array<int,string> $skip_meta_keys
     */
    public static function cleanup_post_image_meta_after_db2_sync(int $post_id, array $skip_meta_keys = []): void
    {
        self::ensure_image_cleanup_service_loaded();
        if (class_exists('Fifu_Legacy_Image_Meta_Cleanup_Service', false)) {
            Fifu_Legacy_Image_Meta_Cleanup_Service::cleanup_post_image_meta_after_db2_sync($post_id, $skip_meta_keys);
        }
    }

    private static function ensure_image_cleanup_service_loaded(): void
    {
        if (!class_exists('Fifu_Metadata_Db2_Cleanup_Guard', false)) {
            $guardPath = __DIR__ . '/class-fifu-metadata-db2-cleanup-guard.php';
            if (is_readable($guardPath)) {
                require_once $guardPath;
            }
        }

        if (!class_exists('Fifu_Legacy_Image_Meta_Cleanup_Service', false)) {
            $cleanupServicePath = __DIR__ . '/class-fifu-legacy-image-meta-cleanup-service.php';
            if (is_readable($cleanupServicePath)) {
                require_once $cleanupServicePath;
            }
        }
    }

    public static function cleanup_post_slider_meta_after_db2_sync(int $post_id): void
    {
        $manager = self::get_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return;
        }

        self::cleanup_single_slider_meta($post_id, 'fifu_slider_list_url', true);
        self::cleanup_single_slider_meta($post_id, 'fifu_slider_list_alt', false);
        self::cleanup_indexed_slider_meta($post_id, true);
        self::cleanup_indexed_slider_meta($post_id, false);
    }

    public static function cleanup_post_video_meta_after_db2_sync(
        int $post_id,
        bool $indexed_video_meta_starts_at_zero = false
    ): void
    {
        $manager = self::get_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return;
        }

        $had_legacy_featured_video = self::has_legacy_meta($post_id, 'fifu_video_url');
        $had_legacy_video_list = self::has_legacy_meta($post_id, 'fifu_list_video_url');
        $indexed_video_offset = (
            $indexed_video_meta_starts_at_zero
            && !$had_legacy_featured_video
            && !$had_legacy_video_list
        ) ? 0 : 1;

        self::cleanup_single_video_meta($post_id, 'fifu_video_url', 0, 'video');
        self::cleanup_single_video_meta($post_id, 'fifu_custom_video_url', 0, 'custom_video');
        $db2_video_by_index = self::get_db2_video_urls_by_index($post_id);
        if ($db2_video_by_index !== []) {
            self::cleanup_indexed_video_meta_confirmed_by_db2(
                $post_id,
                $db2_video_by_index,
                $indexed_video_offset
            );
        }

        $db2_video_list = self::get_db2_video_list_contiguous($post_id);
        if ($db2_video_list !== []) {
            self::cleanup_video_list_meta_confirmed_by_db2(
                $post_id,
                $db2_video_list,
                $db2_video_by_index,
                $indexed_video_offset
            );
        }
    }

    private static function cleanup_single_video_meta(int $post_id, string $meta_key, int $db2_index, string $key_type): void
    {
        if (!self::has_legacy_meta($post_id, $meta_key)) {
            return;
        }

        $legacy_value = self::normalize_scalar_value(self::get_raw_meta_value($post_id, $meta_key));
        if ($legacy_value === null) {
            return;
        }

        $db2_value = self::get_db2_video_value($post_id, $key_type, $db2_index);
        if ($db2_value === null || $db2_value !== $legacy_value) {
            return;
        }

        self::delete_legacy_postmeta_raw($post_id, $meta_key);
    }

    /**
     * @return array<int, string>
     */
    private static function get_db2_video_urls_by_index(int $post_id): array
    {
        $manager = self::get_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return [];
        }

        try {
            $rows = $manager->getPostMappings($post_id, 'video');
        } catch (Throwable $exception) {
            return [];
        }

        if (!is_array($rows) || $rows === []) {
            return [];
        }

        $by_index = [];
        foreach ($rows as $row) {
            $index = (int) ($row['key_index'] ?? -1);
            $value = self::normalize_scalar_value((string) ($row['url'] ?? ''));
            if ($index < 0 || $value === null) {
                return [];
            }

            $by_index[$index] = $value;
        }

        ksort($by_index);
        return $by_index;
    }

    /**
     * @return array<int, string>
     */
    private static function get_db2_video_list_contiguous(int $post_id): array
    {
        $db2_by_index = self::get_db2_video_urls_by_index($post_id);
        if ($db2_by_index === [] || !array_key_exists(0, $db2_by_index)) {
            return [];
        }

        $list = [];
        foreach ($db2_by_index as $index => $value) {
            if ($index !== count($list)) {
                return [];
            }

            $list[] = $value;
        }

        return $list;
    }

    /**
     * @param array<int, string> $db2_video_by_index
     */
    private static function cleanup_indexed_video_meta_confirmed_by_db2(
        int $post_id,
        array $db2_video_by_index,
        int $indexed_video_offset
    ): void
    {
        $meta_keys = self::get_post_meta_keys($post_id);
        if ($meta_keys === []) {
            return;
        }

        foreach ($meta_keys as $meta_key) {
            if (preg_match('/^fifu_video_url_(\d+)$/', $meta_key, $matches) !== 1) {
                continue;
            }

            $legacy_value = self::normalize_scalar_value(self::get_raw_meta_value($post_id, $meta_key));
            if ($legacy_value === null) {
                continue;
            }

            $legacy_index = (int) $matches[1];
            $db2_index = $legacy_index + $indexed_video_offset;
            $db2_value = $db2_video_by_index[$db2_index] ?? null;
            if ($db2_value === null || $db2_value !== $legacy_value) {
                continue;
            }

            self::delete_legacy_postmeta_raw($post_id, $meta_key);
        }
    }

    /**
     * @param array<int, string> $db2_video_list
     * @param array<int, string> $db2_video_by_index
     */
    private static function cleanup_video_list_meta_confirmed_by_db2(
        int $post_id,
        array $db2_video_list,
        array $db2_video_by_index,
        int $indexed_video_offset
    ): void
    {
        if (!self::has_legacy_meta($post_id, 'fifu_list_video_url')) {
            return;
        }

        $legacy_raw = self::get_raw_meta_value($post_id, 'fifu_list_video_url');
        $legacy_items = self::parse_pipe_list($legacy_raw);
        if ($legacy_items === []) {
            return;
        }

        if (!self::pipe_lists_match($legacy_items, $db2_video_list)) {
            return;
        }

        self::delete_legacy_postmeta_raw($post_id, 'fifu_list_video_url');

        $meta_keys = self::get_post_meta_keys($post_id);
        if ($meta_keys === []) {
            return;
        }

        foreach ($meta_keys as $meta_key) {
            if (preg_match('/^fifu_video_url_(\d+)$/', $meta_key, $matches) !== 1) {
                continue;
            }

            $legacy_value = self::normalize_scalar_value(self::get_raw_meta_value($post_id, $meta_key));
            if ($legacy_value === null) {
                continue;
            }

            $legacy_index = (int) $matches[1];
            $db2_index = $legacy_index + $indexed_video_offset;
            $db2_value = $db2_video_by_index[$db2_index] ?? null;
            if ($db2_value === null || $db2_value !== $legacy_value) {
                continue;
            }

            self::delete_legacy_postmeta_raw($post_id, $meta_key);
        }
    }

    private static function cleanup_single_slider_meta(int $post_id, string $meta_key, bool $is_url): void
    {
        if (!self::has_legacy_meta($post_id, $meta_key)) {
            return;
        }

        $legacy_value = $is_url
            ? self::normalize_pipe_list(self::get_raw_meta_value($post_id, $meta_key))
            : self::normalize_slider_alt_list_for_cleanup(self::get_raw_meta_value($post_id, $meta_key));

        if ($legacy_value === null) {
            return;
        }

        $db2_value = $is_url
            ? self::normalize_pipe_list(self::get_db2_slider_list_url($post_id))
            : self::get_db2_slider_list_alt($post_id);

        if ($db2_value === null || $db2_value !== $legacy_value) {
            return;
        }

        self::delete_legacy_postmeta_raw($post_id, $meta_key);
    }

    private static function cleanup_indexed_slider_meta(int $post_id, bool $is_url): void
    {
        $meta_keys = self::get_post_meta_keys($post_id);
        if ($meta_keys === []) {
            return;
        }

        $pattern = $is_url
            ? '/^fifu_slider_image_url_(\d+)$/'
            : '/^fifu_slider_image_alt_(\d+)$/';

        foreach ($meta_keys as $meta_key) {
            if (preg_match($pattern, $meta_key, $matches) !== 1) {
                continue;
            }

            $legacy_value = $is_url
                ? self::normalize_scalar_value(self::get_raw_meta_value($post_id, $meta_key))
                : self::normalize_slider_alt_segment(self::get_raw_meta_value($post_id, $meta_key));

            if ($legacy_value === null) {
                continue;
            }

            $index = (int) $matches[1];
            $db2_value = $is_url
                ? self::get_db2_slider_value($post_id, $index)
                : self::get_db2_slider_alt_value($post_id, $index);

            if ($db2_value === null || $db2_value !== $legacy_value) {
                continue;
            }

            self::delete_legacy_postmeta_raw($post_id, $meta_key);
        }
    }

    private static function get_db2_slider_list_url(int $post_id): ?string
    {
        $rows = self::get_db2_slider_list_rows($post_id, true);
        if ($rows === null || $rows === []) {
            return null;
        }

        return implode('|', $rows);
    }

    private static function get_db2_slider_list_alt(int $post_id): ?string
    {
        $rows = self::get_db2_slider_list_rows($post_id, false);
        if ($rows === null || $rows === []) {
            return null;
        }

        return self::normalize_slider_alt_list_for_cleanup(implode('|', $rows));
    }

    /**
     * @return array<int, string>|null
     */
    private static function get_db2_slider_list_rows(int $post_id, bool $is_url): ?array
    {
        $manager = self::get_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return null;
        }

        try {
            $rows = $is_url
                ? $manager->getPostMappings($post_id, 'slider')
                : $manager->getPostAltMappings($post_id, 'slider');
        } catch (Throwable $exception) {
            return null;
        }

        if (!is_array($rows) || $rows === []) {
            return null;
        }

        usort(
            $rows,
            static fn(array $left, array $right): int => ((int) ($left['key_index'] ?? 0)) <=> ((int) ($right['key_index'] ?? 0))
        );

        $items = [];
        foreach ($rows as $position => $row) {
            if ((int) ($row['key_index'] ?? -1) !== $position) {
                return null;
            }

            if ($is_url) {
                $value = self::normalize_scalar_value((string) ($row['url'] ?? ''));
                if ($value === null) {
                    return null;
                }
            } else {
                $value = self::normalize_slider_alt_segment($row['alt'] ?? null);
            }

            $items[] = $value;
        }

        return $items;
    }

    private static function get_db2_slider_value(int $post_id, int $index): ?string
    {
        $manager = self::get_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return null;
        }

        try {
            $mapping = $manager->getPostMapping($post_id, 'slider', $index);
        } catch (Throwable $exception) {
            return null;
        }

        if (!is_array($mapping)) {
            return null;
        }

        return self::normalize_scalar_value((string) ($mapping['url'] ?? ''));
    }

    private static function get_db2_slider_alt_value(int $post_id, int $index): ?string
    {
        $manager = self::get_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return null;
        }

        try {
            $mapping = $manager->getPostAltMapping($post_id, 'slider', $index);
        } catch (Throwable $exception) {
            return null;
        }

        if (!is_array($mapping)) {
            return null;
        }

        return self::normalize_slider_alt_segment($mapping['alt'] ?? null);
    }

    private static function get_db2_video_value(int $post_id, string $key_type, int $key_index): ?string
    {
        $manager = self::get_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return null;
        }

        try {
            $mapping = $manager->getPostMapping($post_id, $key_type, $key_index);
        } catch (Throwable $exception) {
            return null;
        }

        if (!is_array($mapping)) {
            return null;
        }

        return self::normalize_scalar_value((string) ($mapping['url'] ?? ''));
    }

    private static function has_legacy_meta(int $post_id, string $meta_key): bool
    {
        if (function_exists('metadata_exists') && metadata_exists('post', $post_id, $meta_key)) {
            return true;
        }

        $meta = get_post_meta($post_id);
        if (!is_array($meta)) {
            return false;
        }

        return array_key_exists($meta_key, $meta);
    }

    private static function get_raw_meta_value(int $post_id, string $meta_key): string
    {
        $value = get_post_meta($post_id, $meta_key, true);
        if (is_array($value)) {
            return '';
        }

        return (string) $value;
    }

    /**
     * @return array<int, string>
     */
    private static function get_post_meta_keys(int $post_id): array
    {
        $meta = get_post_meta($post_id);
        if (!is_array($meta)) {
            return [];
        }

        return array_values(array_filter(
            array_map('strval', array_keys($meta)),
            static fn(string $value): bool => $value !== ''
        ));
    }

    private static function normalize_scalar_value(?string $value): ?string
    {
        if ($value === null) {
            return null;
        }

        $value = trim($value);
        return $value === '' ? null : $value;
    }

    /**
     * @param mixed $value
     */
    private static function normalize_slider_alt_segment($value): string
    {
        if ($value === null) {
            return '';
        }

        $normalized = trim((string) $value);
        $normalized_lower = strtolower($normalized);
        if (
            $normalized_lower === ''
            || $normalized_lower === 'null'
            || $normalized_lower === 'undefined'
            || $normalized_lower === 'http://null'
            || $normalized_lower === 'https://null'
        ) {
            return '';
        }

        return wp_strip_all_tags($normalized);
    }

    /**
     * @return array<int, string>
     */
    private static function parse_pipe_list(?string $value): array
    {
        if ($value === null) {
            return [];
        }

        $entries = array_values(
            array_filter(
                array_map('trim', explode('|', rtrim(trim($value), '|'))),
                static fn(string $entry): bool => $entry !== ''
            )
        );

        return $entries;
    }

    private static function normalize_pipe_list(?string $value): ?string
    {
        if ($value === null) {
            return null;
        }

        $entries = array_values(
            array_filter(
                array_map('trim', explode('|', $value)),
                static fn(string $entry): bool => $entry !== ''
            )
        );

        if ($entries === []) {
            return null;
        }

        return implode('|', $entries);
    }

    /**
     * @param mixed $value
     */
    private static function normalize_slider_alt_list_for_cleanup($value): ?string
    {
        if ($value === null) {
            return null;
        }

        $segments = array_map(
            static fn($segment): string => self::normalize_slider_alt_segment($segment),
            explode('|', (string) $value)
        );

        $normalized = implode('|', $segments);
        foreach ($segments as $segment) {
            if ($segment !== '') {
                return $normalized;
            }
        }

        return null;
    }

    /**
     * @param array<int, string> $legacyList
     * @param array<int, string> $db2List
     */
    private static function pipe_lists_match(array $legacyList, array $db2List): bool
    {
        if ($legacyList === [] || $db2List === []) {
            return false;
        }

        if (count($legacyList) !== count($db2List)) {
            return false;
        }

        foreach ($legacyList as $index => $legacyValue) {
            if (!array_key_exists($index, $db2List) || $legacyValue !== $db2List[$index]) {
                return false;
            }
        }

        return true;
    }

    private static function delete_legacy_postmeta_raw(int $post_id, string $meta_key): void
    {
        delete_post_meta($post_id, $meta_key);
        clean_post_cache($post_id);
        wp_cache_delete($post_id, 'post_meta');
    }

    private static function get_db2_manager(): ?Fifu_Db2_Manager
    {
        if (!function_exists('fifu_db2_manager')) {
            return null;
        }

        $manager = fifu_db2_manager();
        return $manager instanceof Fifu_Db2_Manager ? $manager : null;
    }
}
