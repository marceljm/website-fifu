<?php

if (!defined('ABSPATH')) {
    exit;
}

class Fifu_Metadata_Post_Work_Plan_Service {

    /**
     * Build a metadata-post work plan for a post/product.
     *
     * Return shape:
     * - source: 'db2', 'legacy', 'mixed', or 'none'
     * - has_db2_media: bool
     * - has_legacy_media_input: bool
     * - has_generated_wordpress_metadata: bool
     * - should_split_lists: bool
     * - should_run_legacy_cleanup: bool
     * - should_sync_metadata: bool
     * - should_fallback_to_legacy_per_post_sync: bool
     *
     * @param int $post_id
     * @return array<string, mixed>
     */
    public static function build_for_post(int $post_id): array {
        $post_id = (int) $post_id;
        $post_type = get_post_type($post_id);

        $has_db2_media = self::has_db2_media($post_id);
        $has_legacy_media_input = self::has_legacy_media_input($post_id);
        $has_generated_wordpress_metadata = self::has_generated_wordpress_metadata($post_id);

        if ($has_db2_media && $has_legacy_media_input) {
            $source = 'mixed';
        } elseif ($has_db2_media) {
            $source = 'db2';
        } elseif ($has_legacy_media_input) {
            $source = 'legacy';
        } else {
            $source = 'none';
        }

        $is_clean_featured_only_normal_post = $post_type === 'post' && self::is_clean_featured_only_normal_post($post_id);

        $should_split_lists = $has_legacy_media_input && !$is_clean_featured_only_normal_post;
        $should_run_legacy_cleanup = $has_legacy_media_input && !$is_clean_featured_only_normal_post;
        $should_sync_metadata = ($has_db2_media || $has_legacy_media_input) && !$has_generated_wordpress_metadata;

        // For Phase 2, only clean DB2-only media is eligible for the future fast path.
        // Legacy and mixed states remain on the existing safe per-post path.
        $should_fallback_to_legacy_per_post_sync = $has_legacy_media_input || $source === 'none';

        return array(
            'source' => $source,
            'has_db2_media' => $has_db2_media,
            'has_legacy_media_input' => $has_legacy_media_input,
            'has_generated_wordpress_metadata' => $has_generated_wordpress_metadata,
            'should_split_lists' => $should_split_lists,
            'should_run_legacy_cleanup' => $should_run_legacy_cleanup,
            'should_sync_metadata' => $should_sync_metadata,
            'should_fallback_to_legacy_per_post_sync' => $should_fallback_to_legacy_per_post_sync,
        );
    }

    private static function is_clean_featured_only_normal_post(int $post_id): bool {
        global $wpdb;

        $postmeta_table = $wpdb->postmeta;

        $count = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(1)
             FROM {$postmeta_table}
             WHERE post_id = %d
               AND (
                    meta_key = 'fifu_image_url'
                 OR meta_key = 'fifu_image_alt'
                 OR meta_key = 'fifu_list_url'
                 OR meta_key = 'fifu_list_alt'
                 OR meta_key = 'fifu_video_url'
                 OR meta_key = 'fifu_list_video_url'
                 OR meta_key = 'fifu_custom_video_url'
                 OR meta_key = 'fifu_slider_list_url'
                 OR meta_key LIKE 'fifu_image_url\\_%'
                 OR meta_key LIKE 'fifu_image_alt\\_%'
                 OR meta_key LIKE 'fifu_video_url\\_%'
                 OR meta_key LIKE 'fifu_slider_image_url\\_%'
                 OR meta_key LIKE 'fifu_slider_image_alt\\_%'
               )
               AND meta_value IS NOT NULL
               AND TRIM(meta_value) <> ''
               AND meta_key <> 'fifu_image_url'
               AND meta_key <> 'fifu_image_alt'",
            $post_id
        ));

        return $count === 0;
    }

    private static function has_db2_media(int $post_id): bool {
        global $wpdb;

        $map_table = $wpdb->prefix . 'fifu_map';
        $key_table = $wpdb->prefix . 'fifu_key';
        $url_table = $wpdb->prefix . 'fifu_url';

        if (!self::table_exists($map_table) || !self::table_exists($key_table) || !self::table_exists($url_table)) {
            return false;
        }

        $count = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(1)
             FROM {$map_table} m
             INNER JOIN {$key_table} k ON k.key_id = m.key_id
             INNER JOIN {$url_table} u ON u.hash = m.hash
             WHERE m.post_id = %d
               AND k.key_type IN ('image', 'video', 'slider', 'custom_video')
               AND u.url IS NOT NULL
               AND TRIM(u.url) <> ''",
            $post_id
        ));

        return $count > 0;
    }

    private static function has_legacy_media_input(int $post_id): bool {
        global $wpdb;

        $postmeta_table = $wpdb->postmeta;

        $count = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(1)
             FROM {$postmeta_table}
             WHERE post_id = %d
               AND (
                    meta_key = 'fifu_image_url'
                 OR meta_key LIKE 'fifu_image_url\\_%'
                 OR meta_key = 'fifu_list_url'
                 OR meta_key = 'fifu_video_url'
                 OR meta_key LIKE 'fifu_video_url\\_%'
                 OR meta_key = 'fifu_list_video_url'
                 OR meta_key = 'fifu_custom_video_url'
                 OR meta_key = 'fifu_slider_list_url'
                 OR meta_key LIKE 'fifu_slider_image_url\\_%'
               )
               AND meta_value IS NOT NULL
               AND TRIM(meta_value) <> ''",
            $post_id
        ));

        return $count > 0;
    }

    private static function has_generated_wordpress_metadata(int $post_id): bool {
        $thumbnail_id = get_post_meta($post_id, '_thumbnail_id', true);
        if ($thumbnail_id !== '' && $thumbnail_id !== null && (string) $thumbnail_id !== '0') {
            return true;
        }

        $gallery = get_post_meta($post_id, '_product_image_gallery', true);
        if ($gallery !== '' && $gallery !== null) {
            return true;
        }

        return false;
    }

    private static function table_exists(string $table): bool {
        global $wpdb;

        $found = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));

        return $found === $table;
    }
}
