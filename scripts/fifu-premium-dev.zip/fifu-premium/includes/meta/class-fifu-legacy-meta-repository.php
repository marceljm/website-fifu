<?php

declare(strict_types=1);

/**
 * Legacy metadata repository that mirrors previous admin/db functions.
 */
class Fifu_Legacy_Meta_Repository {

    private wpdb $wpdb;
    private string $postmeta_table;
    private string $fifu_map_table;
    private string $fifu_key_table;
    private string $fifu_url_table;
    private string $fifu_alt_table;
    private string $fifu_alt_map_table;

    public function __construct(wpdb $wpdb, string $postmeta_table) {
        $this->wpdb = $wpdb;
        $this->postmeta_table = $postmeta_table;
        $prefix = $wpdb->prefix;
        $this->fifu_map_table = $prefix . 'fifu_map';
        $this->fifu_key_table = $prefix . 'fifu_key';
        $this->fifu_url_table = $prefix . 'fifu_url';
        $this->fifu_alt_table = $prefix . 'fifu_alt';
        $this->fifu_alt_map_table = $prefix . 'fifu_alt_map';
    }

    public function get_fifu_fields_for_posts(array $postIds): array {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($postIds);
        if ($idsCsv === '0') {
            return [];
        }

        /*
         * Start with legacy direct fields. This must stay legacy-only because
         * process_post_meta_in_row() also uses get_legacy_fifu_fields_for_posts()
         * to decide whether legacy -> DB2 migration is needed.
         */
        $data = $this->get_legacy_fifu_fields_for_posts($postIds);

        /*
         * Preserve the old slider read-service fallback for fifu_slider_list_url,
         * but do it in bulk and only for index 0.
         */
        $legacySliderZeroRows = $this->get_legacy_slider_zero_fields_for_posts($postIds);
        foreach ($legacySliderZeroRows as $postId => $url) {
            if (!isset($data[$postId])) {
                continue;
            }

            if (
                trim((string) ($data[$postId]['fifu_slider_image_url_0'] ?? '')) === ''
                && trim((string) $url) !== ''
            ) {
                $data[$postId]['fifu_slider_image_url_0'] = (string) $url;
            }
        }

        /*
         * Fill remaining empty fields from DB2 using bulk queries scoped to this batch.
         */
        $db2Data = $this->get_db2_fifu_fields_for_posts($postIds);
        foreach ($db2Data as $postId => $fields) {
            if (!isset($data[$postId])) {
                $data[$postId] = [
                    'fifu_image_url' => '',
                    'fifu_image_alt' => '',
                    'fifu_slider_image_url_0' => '',
                    'fifu_video_url' => '',
                    'fifu_custom_video_url' => '',
                ];
            }

            foreach ($fields as $key => $value) {
                if (!array_key_exists($key, $data[$postId])) {
                    continue;
                }

                if (
                    trim((string) $data[$postId][$key]) === ''
                    && trim((string) $value) !== ''
                ) {
                    $data[$postId][$key] = (string) $value;
                }
            }
        }

        return $data;
    }

    /**
     * Retrieve only legacy FIFU metadata for the provided posts.
     */
    public function get_legacy_fifu_fields_for_posts(array $postIds): array {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($postIds);
        if ($idsCsv === '0') {
            return [];
        }

        $results = $this->wpdb->get_results("
            SELECT post_id, meta_key, meta_value
            FROM {$this->postmeta_table}
            WHERE post_id IN ({$idsCsv})
            AND meta_key IN ('fifu_image_url', 'fifu_image_alt', 'fifu_slider_image_url_0', 'fifu_video_url', 'fifu_custom_video_url')
        ");

        $data = [];
        foreach (array_map('intval', explode(',', $idsCsv)) as $id) {
            $data[$id] = [
                'fifu_image_url' => '',
                'fifu_image_alt' => '',
                'fifu_slider_image_url_0' => '',
                'fifu_video_url' => '',
                'fifu_custom_video_url' => '',
            ];
        }

        if (!is_array($results)) {
            return $data;
        }

        foreach ($results as $row) {
            $postId = (int) $row->post_id;
            if (isset($data[$postId])) {
                $data[$postId][$row->meta_key] = $row->meta_value;
            }
        }

        return $data;
    }

    /**
     * Load main FIFU fields from DB2 in bulk for the current Image Metadata batch.
     *
     * @param array<int|string> $postIds
     * @return array<int,array<string,string>>
     */
    private function get_db2_fifu_fields_for_posts(array $postIds): array {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($postIds);
        if ($idsCsv === '0') {
            return [];
        }

        if (
            !$this->table_exists($this->fifu_map_table)
            || !$this->table_exists($this->fifu_key_table)
            || !$this->table_exists($this->fifu_url_table)
        ) {
            return [];
        }

        $data = [];

        $urlRows = $this->wpdb->get_results("
            SELECT
                m.post_id,
                k.key_type,
                u.url
            FROM {$this->fifu_map_table} m
            INNER JOIN {$this->fifu_key_table} k ON k.key_id = m.key_id
            INNER JOIN {$this->fifu_url_table} u ON u.hash = m.hash
            WHERE m.post_id IN ({$idsCsv})
              AND m.key_index = 0
              AND k.key_type IN ('image', 'slider', 'video', 'custom_video')
              AND u.url IS NOT NULL
              AND u.url <> ''
            ORDER BY
                m.post_id,
                CASE k.key_type
                    WHEN 'image' THEN 0
                    WHEN 'slider' THEN 1
                    WHEN 'custom_video' THEN 2
                    WHEN 'video' THEN 3
                    ELSE 4
                END
        ");

        if (is_array($urlRows)) {
            foreach ($urlRows as $row) {
                $postId = (int) $row->post_id;
                $url = trim((string) $row->url);
                if ($postId <= 0 || $url === '') {
                    continue;
                }

                if (!isset($data[$postId])) {
                    $data[$postId] = [];
                }

                switch ((string) $row->key_type) {
                    case 'image':
                        $data[$postId]['fifu_image_url'] = $url;
                        break;

                    case 'slider':
                        $data[$postId]['fifu_slider_image_url_0'] = $url;
                        break;

                    case 'custom_video':
                        $data[$postId]['fifu_custom_video_url'] = $url;
                        break;

                    case 'video':
                        $data[$postId]['fifu_video_url'] = $url;
                        break;
                }
            }
        }

        if (
            !$this->table_exists($this->fifu_alt_map_table)
            || !$this->table_exists($this->fifu_alt_table)
        ) {
            return $data;
        }

        $altRows = $this->wpdb->get_results("
            SELECT
                m.post_id,
                k.key_type,
                a.alt
            FROM {$this->fifu_alt_map_table} m
            INNER JOIN {$this->fifu_key_table} k ON k.key_id = m.key_id
            INNER JOIN {$this->fifu_alt_table} a ON a.hash = m.hash
            WHERE m.post_id IN ({$idsCsv})
              AND m.key_index = 0
              AND k.key_type IN ('image', 'slider')
              AND a.alt IS NOT NULL
              AND a.alt <> ''
            ORDER BY m.post_id
        ");

        $imageAlts = [];
        $sliderAlts = [];

        if (is_array($altRows)) {
            foreach ($altRows as $row) {
                $postId = (int) $row->post_id;
                $alt = trim((string) $row->alt);
                $keyType = (string) $row->key_type;
                if ($postId <= 0 || $alt === '') {
                    continue;
                }

                if ($keyType === 'slider') {
                    $sliderAlts[$postId] = $alt;
                    continue;
                }

                if ($keyType === 'image') {
                    $imageAlts[$postId] = $alt;
                }
            }
        }

        foreach ($data as $postId => &$fields) {
            $hasSlider = trim((string) ($fields['fifu_slider_image_url_0'] ?? '')) !== '';

            if ($hasSlider) {
                if (isset($sliderAlts[$postId])) {
                    $fields['fifu_image_alt'] = $sliderAlts[$postId];
                }

                continue;
            }

            if (isset($imageAlts[$postId])) {
                $fields['fifu_image_alt'] = $imageAlts[$postId];
            }
        }
        unset($fields);

        return $data;
    }

    /**
     * Build a map of gallery URLs stored in post meta for the requested posts.
     */
    public function get_gallery_urls_map(array $postIds): array {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($postIds);
        if ($idsCsv === '0') {
            return [];
        }

        $map = [];
        $mode = function_exists('fifu_db2_mode') ? fifu_db2_mode() : Fifu_Db2_Mode::MODE_LEGACY;
        $useDb2 = $this->table_exists($this->fifu_map_table)
            && $this->table_exists($this->fifu_key_table)
            && $this->table_exists($this->fifu_url_table);

        if ($useDb2) {
            $sql = "
                SELECT m.post_id, u.url
                FROM {$this->fifu_map_table} m
                INNER JOIN {$this->fifu_key_table} k ON k.key_id = m.key_id
                INNER JOIN {$this->fifu_url_table} u ON u.hash = m.hash
                WHERE m.post_id IN ({$idsCsv})
                  AND k.key_type IN ('image','video','slider')
                  AND m.key_index > 0
                ORDER BY
                    m.post_id,
                    CASE k.key_type
                        WHEN 'image' THEN 0
                    WHEN 'slider' THEN 1
                    WHEN 'video' THEN 2
                        ELSE 3
                    END,
                    m.key_index
            ";
            $results = $this->wpdb->get_results($sql);
            foreach ($results as $row) {
                if (!isset($map[$row->post_id])) {
                    $map[$row->post_id] = [];
                }
                $map[$row->post_id][] = $row->url;
            }
        }

        if ($map) {
            return $map;
        }

        if ($mode === Fifu_Db2_Mode::MODE_DB2) {
            return [];
        }

        // fallback to legacy query (used in HYBRID or when DB2 returned nothing)
        return $this->get_legacy_gallery_urls_map($postIds);
    }

    /**
     * Build a gallery URL map using only legacy postmeta.
     */
    public function get_legacy_gallery_urls_map(array $postIds): array {
        $results = $this->get_legacy_gallery_rows($postIds);
        if (!is_array($results)) {
            return [];
        }

        $map = [];
        foreach ($results as $result) {
            $postId = (int) $result->post_id;
            if (!isset($map[$postId])) {
                $map[$postId] = [];
            }
            $map[$postId][] = $result->meta_value;
        }

        return $map;
    }

    /**
     * Build a gallery meta map using only legacy postmeta, preserving meta keys.
     *
     * @return array<int,array<string,string>>
     */
    public function get_legacy_gallery_meta_map(array $postIds): array {
        $results = $this->get_legacy_gallery_rows($postIds);
        if (!is_array($results)) {
            return [];
        }

        $map = [];
        foreach ($results as $result) {
            $postId = (int) $result->post_id;
            if (!isset($map[$postId])) {
                $map[$postId] = [];
            }
            $map[$postId][$result->meta_key] = $result->meta_value;
        }

        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($postIds);
        if ($idsCsv === '0') {
            return $map;
        }

        $sliderZeroRows = $this->wpdb->get_results("
            SELECT post_id, meta_key, meta_value
            FROM {$this->postmeta_table}
            WHERE post_id IN ({$idsCsv})
              AND meta_key = 'fifu_slider_image_url_0'
              AND meta_value <> ''
            ORDER BY post_id
        ");

        if (is_array($sliderZeroRows)) {
            foreach ($sliderZeroRows as $result) {
                $postId = (int) $result->post_id;
                if (!isset($map[$postId])) {
                    $map[$postId] = [];
                }

                $map[$postId][$result->meta_key] = $result->meta_value;
            }
        }

        return $map;
    }

    /**
     * @return array<int,bool>
     */
    public function get_has_indexed_gallery_urls_map(array $postIds): array {
        $indexedMap = $this->get_indexed_legacy_gallery_url_indexes_map($postIds);
        $presenceMap = [];

        foreach ($postIds as $postId) {
            $intPostId = (int) $postId;
            if ($intPostId <= 0) {
                continue;
            }

            $presenceMap[$intPostId] = !empty($indexedMap[$intPostId]);
        }

        return $presenceMap;
    }

    /**
     * Build a gallery alt map using only legacy postmeta.
     *
     * @return array<int,array<string,string>>
     */
    public function get_legacy_gallery_alts_map(array $postIds): array {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($postIds);
        if ($idsCsv === '0') {
            return [];
        }

        $results = $this->wpdb->get_results("
            SELECT post_id, meta_key, meta_value
            FROM {$this->postmeta_table} a
            WHERE a.post_id IN ({$idsCsv})
            AND (
                a.meta_key LIKE 'fifu_image_alt_%'
                OR a.meta_key = 'fifu_list_alt'
                OR (
                    a.meta_key LIKE 'fifu_slider_image_alt_%'
                    AND a.meta_key <> 'fifu_slider_image_alt_0'
                )
            )
            AND a.meta_value <> ''
            ORDER BY a.post_id, CAST(SUBSTRING_INDEX(a.meta_key, '_', -1) AS UNSIGNED), a.meta_key
        ");

        if (!is_array($results)) {
            return [];
        }

        $map = [];
        $indexedAltIndexes = [];
        $listAltsByPost = [];
        $indexedGalleryIndexes = $this->get_indexed_legacy_gallery_url_indexes_map($postIds);
        foreach ($results as $result) {
            $postId = (int) $result->post_id;
            $metaKey = (string) $result->meta_key;

            if ($metaKey === 'fifu_list_alt') {
                if (!isset($map[$postId])) {
                    $map[$postId] = [];
                }

                $map[$postId]['fifu_list_alt'] = (string) $result->meta_value;
                $listAltsByPost[$postId] = $this->parse_legacy_list_values((string) $result->meta_value, true);
                continue;
            }

            if (!isset($map[$postId])) {
                $map[$postId] = [];
            }

            $map[$postId][$metaKey] = $result->meta_value;

            $index = $this->extract_legacy_gallery_index($metaKey);
            if ($index !== null) {
                $indexedAltIndexes[$postId][$index] = true;
            }
        }

        if (!$listAltsByPost) {
            return $map;
        }

        $listUrlRows = $this->wpdb->get_results("
            SELECT post_id, meta_value
            FROM {$this->postmeta_table}
            WHERE post_id IN ({$idsCsv})
              AND meta_key = 'fifu_list_url'
              AND meta_value <> ''
            ORDER BY post_id
        ");

        if (is_array($listUrlRows)) {
            foreach ($listUrlRows as $result) {
                $postId = (int) $result->post_id;
                if (!isset($map[$postId])) {
                    $map[$postId] = [];
                }

                $map[$postId]['fifu_list_url'] = (string) $result->meta_value;
            }
        }

        $urlIndexesMap = $this->get_legacy_gallery_url_indexes_map($postIds);
        foreach ($listAltsByPost as $postId => $listAlts) {
            $urlIndexes = $urlIndexesMap[$postId] ?? [];
            if (!$urlIndexes) {
                continue;
            }

            sort($urlIndexes);
            if (!isset($map[$postId])) {
                $map[$postId] = [];
            }

            if (isset($map[$postId]['fifu_list_url'])) {
                continue;
            }

            foreach ($urlIndexes as $index) {
                if (isset($indexedAltIndexes[$postId][$index])) {
                    continue;
                }

                $map[$postId]['fifu_image_alt_' . $index] = $listAlts[$index] ?? '';
            }
        }

        return $map;
    }

    /**
     * Build a slider alt map using only legacy postmeta.
     *
     * @return array<int,array<string,string>>
     */
    public function get_legacy_slider_alts_map(array $postIds): array {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($postIds);
        if ($idsCsv === '0') {
            return [];
        }

        $results = $this->wpdb->get_results("
            SELECT post_id, meta_key, meta_value
            FROM {$this->postmeta_table} a
            WHERE a.post_id IN ({$idsCsv})
            AND (
                a.meta_key LIKE 'fifu_slider_image_alt_%'
                OR a.meta_key = 'fifu_slider_list_alt'
            )
            AND a.meta_value <> ''
            ORDER BY a.post_id, CAST(SUBSTRING_INDEX(a.meta_key, '_', -1) AS UNSIGNED), a.meta_key
        ");

        if (!is_array($results)) {
            return [];
        }

        $map = [];
        $indexedAltIndexes = [];
        $listAltsByPost = [];
        foreach ($results as $result) {
            $postId = (int) $result->post_id;
            $metaKey = (string) $result->meta_key;

            if ($metaKey === 'fifu_slider_list_alt') {
                $listAltsByPost[$postId] = $this->parse_legacy_list_values((string) $result->meta_value, true);
                continue;
            }

            if (!isset($map[$postId])) {
                $map[$postId] = [];
            }

            $map[$postId][$metaKey] = $result->meta_value;

            $index = $this->extract_legacy_gallery_index($metaKey);
            if ($index !== null) {
                $indexedAltIndexes[$postId][$index] = true;
            }
        }

        if (!$listAltsByPost) {
            return $map;
        }

        $urlIndexesMap = $this->get_legacy_slider_url_indexes_map_for_alt_expansion($postIds);
        foreach ($listAltsByPost as $postId => $listAlts) {
            $urlIndexes = $urlIndexesMap[$postId] ?? [];
            if (!$urlIndexes) {
                continue;
            }

            sort($urlIndexes);
            if (!isset($map[$postId])) {
                $map[$postId] = [];
            }

            foreach ($urlIndexes as $index) {
                if (isset($indexedAltIndexes[$postId][$index])) {
                    continue;
                }

                $map[$postId]['fifu_slider_image_alt_' . $index] = $listAlts[$index] ?? '';
            }
        }

        return $map;
    }

    /**
     * @return array<int,object>
     */
    private function get_legacy_gallery_rows(array $postIds): array {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($postIds);
        if ($idsCsv === '0') {
            return [];
        }

        $results = $this->wpdb->get_results("
            SELECT post_id, meta_key, meta_value
            FROM {$this->postmeta_table} a
            WHERE a.post_id IN ({$idsCsv})
            AND (
                a.meta_key LIKE 'fifu_image_url_%'
                OR a.meta_key LIKE 'fifu_video_url_%'
                OR a.meta_key = 'fifu_list_url'
                OR a.meta_key = 'fifu_list_video_url'
                OR a.meta_key = 'fifu_slider_list_url'
                OR (
                    a.meta_key LIKE 'fifu_slider_image_url_%'
                    AND a.meta_key <> 'fifu_slider_image_url_0'
                )
            )
            AND a.meta_value <> ''
            ORDER BY a.post_id, CAST(SUBSTRING_INDEX(a.meta_key, '_', -1) AS UNSIGNED), a.meta_key
        ");

        if (!is_array($results)) {
            return [];
        }

        $rows = [];
        $indexedGalleryIndexes = [];
        $expandedGalleryIndexes = [];
        $hasIndexedGalleryRows = [];

        foreach ($results as $result) {
            $postId = (int) $result->post_id;
            $metaKey = (string) $result->meta_key;
            if (!$this->is_legacy_gallery_media_meta_key($metaKey)) {
                continue;
            }

            $index = $this->extract_legacy_gallery_index($metaKey);
            if ($index === null) {
                continue;
            }

            $group = $this->get_legacy_gallery_meta_group($metaKey);
            if ($group === null) {
                continue;
            }

            $indexedGalleryIndexes[$postId][$group][$index] = true;
            $hasIndexedGalleryRows[$postId][$group] = true;
        }

        foreach ($results as $result) {
            $postId = (int) $result->post_id;
            $metaKey = (string) $result->meta_key;

            if (
                $metaKey === 'fifu_list_url'
                || $metaKey === 'fifu_list_video_url'
                || $metaKey === 'fifu_slider_list_url'
            ) {
                $group = $metaKey === 'fifu_list_video_url'
                    ? 'video'
                    : ($metaKey === 'fifu_slider_list_url' ? 'slider' : 'image');

                if (!empty($hasIndexedGalleryRows[$postId][$group])) {
                    continue;
                }

                if ($metaKey === 'fifu_list_video_url') {
                    $prefix = 'fifu_video_url_';
                } elseif ($metaKey === 'fifu_slider_list_url') {
                    $prefix = 'fifu_slider_image_url_';
                } else {
                    $prefix = 'fifu_image_url_';
                }

                foreach ($this->parse_legacy_list_values((string) $result->meta_value) as $index => $url) {
                    if (
                        isset($indexedGalleryIndexes[$postId][$group][$index])
                        || isset($expandedGalleryIndexes[$postId][$group][$index])
                    ) {
                        continue;
                    }

                    $rows[] = (object) [
                        'post_id' => $postId,
                        'meta_key' => $prefix . $index,
                        'meta_value' => $url,
                    ];
                    $expandedGalleryIndexes[$postId][$group][$index] = true;
                }
                continue;
            }

            $rows[] = $result;

        }

        usort($rows, function (object $left, object $right): int {
            $postCompare = ((int) $left->post_id) <=> ((int) $right->post_id);
            if ($postCompare !== 0) {
                return $postCompare;
            }

            $leftIndex = $this->extract_legacy_gallery_index((string) $left->meta_key) ?? 0;
            $rightIndex = $this->extract_legacy_gallery_index((string) $right->meta_key) ?? 0;
            $indexCompare = $leftIndex <=> $rightIndex;

            if ($indexCompare !== 0) {
                return $indexCompare;
            }

            return strcmp((string) $left->meta_key, (string) $right->meta_key);
        });

        return $rows;
    }

    /**
     * @return array<int,array<int,string>>
     */
    private function get_legacy_gallery_url_indexes_map(array $postIds): array {
        $rows = $this->get_legacy_gallery_rows($postIds);
        if (!$rows) {
            return [];
        }

        $map = [];
        foreach ($rows as $row) {
            $metaKey = (string) $row->meta_key;
            if (!$this->is_legacy_gallery_media_meta_key($metaKey)) {
                continue;
            }

            $index = $this->extract_legacy_gallery_index($metaKey);
            if ($index === null) {
                continue;
            }

            $postId = (int) $row->post_id;
            if (!isset($map[$postId])) {
                $map[$postId] = [];
            }

            $map[$postId][$index] = $index;
        }

        return $map;
    }

    /**
     * @return array<int,array<int,int>>
     */
    private function get_legacy_slider_url_indexes_map_for_alt_expansion(array $postIds): array {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($postIds);
        if ($idsCsv === '0') {
            return [];
        }

        $results = $this->wpdb->get_results("
            SELECT post_id, meta_key, meta_value
            FROM {$this->postmeta_table}
            WHERE post_id IN ({$idsCsv})
              AND (
                meta_key = 'fifu_slider_list_url'
                OR meta_key LIKE 'fifu_slider_image_url_%'
              )
              AND meta_value <> ''
            ORDER BY post_id, CAST(SUBSTRING_INDEX(meta_key, '_', -1) AS UNSIGNED), meta_key
        ");

        if (!is_array($results)) {
            return [];
        }

        $map = [];
        $listRows = [];

        foreach ($results as $result) {
            $postId = (int) $result->post_id;
            $metaKey = (string) $result->meta_key;

            if ($metaKey === 'fifu_slider_list_url') {
                $listRows[$postId] = (string) $result->meta_value;
                continue;
            }

            if (preg_match('/^fifu_slider_image_url_(\d+)$/', $metaKey, $matches) !== 1) {
                continue;
            }

            if (trim((string) $result->meta_value) === '') {
                continue;
            }

            $index = (int) $matches[1];
            if (!isset($map[$postId])) {
                $map[$postId] = [];
            }

            $map[$postId][$index] = $index;
        }

        if (function_exists('get_post_meta')) {
            foreach ($postIds as $postId) {
                $intPostId = (int) $postId;
                if ($intPostId <= 0) {
                    continue;
                }

                $meta = get_post_meta($intPostId);
                if (!is_array($meta) || $meta === []) {
                    continue;
                }

                if (!isset($map[$intPostId])) {
                    $map[$intPostId] = [];
                }

                $indexedRows = [];
                foreach ($meta as $metaKey => $metaValue) {
                    if (is_array($metaValue)) {
                        $metaValue = reset($metaValue);
                    }

                    if ($metaKey === 'fifu_slider_list_url') {
                        $listRows[$intPostId] = (string) $metaValue;
                        continue;
                    }

                    if (preg_match('/^fifu_slider_image_url_(\d+)$/', (string) $metaKey, $matches) !== 1) {
                        continue;
                    }

                    $index = (int) $matches[1];
                    if (trim((string) $metaValue) === '') {
                        continue;
                    }

                    $indexedRows[$index] = $index;
                }

                foreach ($indexedRows as $index => $value) {
                    $map[$intPostId][$index] = $value;
                }
            }
        }

        foreach ($listRows as $postId => $listValue) {
            foreach ($this->parse_legacy_list_values($listValue) as $index => $url) {
                if (trim((string) $url) === '') {
                    continue;
                }

                if (isset($map[$postId][$index])) {
                    continue;
                }

                if (!isset($map[$postId])) {
                    $map[$postId] = [];
                }

                $map[$postId][$index] = $index;
            }
        }

        foreach ($map as $postId => $indexes) {
            ksort($indexes, SORT_NUMERIC);
            $map[$postId] = $indexes;
        }

        return $map;
    }

    /**
     * Preserve the old slider read-service fallback for fifu_slider_list_url,
     * but without per-post get_post_meta() calls.
     *
     * @param array<int|string> $postIds
     * @return array<int,string>
     */
    private function get_legacy_slider_zero_fields_for_posts(array $postIds): array {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($postIds);
        if ($idsCsv === '0') {
            return [];
        }

        $results = $this->wpdb->get_results("
            SELECT post_id, meta_value
            FROM {$this->postmeta_table}
            WHERE post_id IN ({$idsCsv})
              AND meta_key = 'fifu_slider_list_url'
              AND meta_value <> ''
            ORDER BY post_id
        ");

        if (!is_array($results)) {
            return [];
        }

        $map = [];
        foreach ($results as $row) {
            $postId = (int) $row->post_id;
            if ($postId <= 0) {
                continue;
            }

            $values = $this->parse_legacy_list_values((string) $row->meta_value);
            if (!isset($values[0])) {
                continue;
            }

            $url = trim((string) $values[0]);
            if ($url === '') {
                continue;
            }

            $map[$postId] = $url;
        }

        return $map;
    }

    /**
     * @return array<int,array<int,int>>
     */
    private function get_legacy_slider_url_indexes_map(array $postIds): array {
        $rows = $this->get_legacy_gallery_rows($postIds);
        if (!$rows) {
            return [];
        }

        $map = [];
        foreach ($rows as $row) {
            $metaKey = (string) $row->meta_key;
            if (preg_match('/^fifu_slider_image_url_\d+$/', $metaKey) !== 1) {
                continue;
            }

            $index = $this->extract_legacy_gallery_index($metaKey);
            if ($index === null) {
                continue;
            }

            $postId = (int) $row->post_id;
            if (!isset($map[$postId])) {
                $map[$postId] = [];
            }

            $map[$postId][$index] = $index;
        }

        return $map;
    }

    /**
     * @return array<int,array<int,int>>
     */
    private function get_indexed_legacy_gallery_url_indexes_map(array $postIds): array {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($postIds);
        if ($idsCsv === '0') {
            return [];
        }

        $results = $this->wpdb->get_results("
            SELECT post_id, meta_key
            FROM {$this->postmeta_table}
            WHERE post_id IN ({$idsCsv})
            AND (
                meta_key LIKE 'fifu_image_url_%'
                OR meta_key LIKE 'fifu_video_url_%'
            )
            AND meta_value <> ''
        ");

        if (!is_array($results)) {
            return [];
        }

        $map = [];
        foreach ($results as $result) {
            $index = $this->extract_legacy_gallery_index((string) $result->meta_key);
            if ($index === null) {
                continue;
            }

            $postId = (int) $result->post_id;
            $map[$postId][$index] = $index;
        }

        return $map;
    }

    /**
     * @return array<int,string>
     */
    private function parse_legacy_list_values(string $value, bool $sanitize = false): array {
        $values = [];

        foreach (explode('|', $value) as $index => $item) {
            $item = trim($item);
            if ($sanitize) {
                $item = sanitize_text_field($item);
            }

            if ($item === '' || preg_match('/^(null|undefined)$/i', $item) === 1) {
                continue;
            }

            $values[$index] = $item;
        }

        return $values;
    }

    private function extract_legacy_gallery_index(string $metaKey): ?int {
        if (preg_match('/_(\d+)$/', $metaKey, $matches) !== 1) {
            return null;
        }

        return (int) $matches[1];
    }

    private function is_legacy_gallery_media_meta_key(string $metaKey): bool {
        return preg_match('/^fifu_(image|video|slider_image)_url_\d+$/', $metaKey) === 1;
    }

    private function get_legacy_gallery_meta_group(string $metaKey): ?string {
        if (preg_match('/^fifu_image_url_\d+$/', $metaKey) === 1) {
            return 'image';
        }

        if (preg_match('/^fifu_video_url_\d+$/', $metaKey) === 1) {
            return 'video';
        }

        if (preg_match('/^fifu_slider_image_url_\d+$/', $metaKey) === 1) {
            return 'slider';
        }

        return null;
    }

    /**
     * Checks whether a table exists in the database.
     *
     * @param string $table
     * @return bool
     */
    private function table_exists(string $table): bool {
        $sql = $this->wpdb->prepare("SHOW TABLES LIKE %s", $table);
        return $this->wpdb->get_var($sql) !== null;
    }

    /**
     * Return a comma-separated list of thumbnail attachment IDs for the given posts.
     */
    public function get_thumbnail_ids_csv(array $postIds): string {
        $idsCsv = Fifu_Db2_Sql_Helper::sanitize_ids_csv($postIds);
        if ($idsCsv === '0') {
            return '';
        }

        $results = $this->wpdb->get_results("
            SELECT meta_value
            FROM {$this->postmeta_table}
            WHERE post_id IN ({$idsCsv})
            AND meta_key = '_thumbnail_id'
        ", ARRAY_A);

        return implode(',', array_column($results, 'meta_value'));
    }
}
