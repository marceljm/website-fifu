<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Provides read access to slider image ALT metadata.
 */
final class Fifu_Post_Slider_Image_Alt_Read_Service
{
    /**
     * Returns the slider image ALT text for a post and a given index.
     *
     * Priority:
     * 1. DB2 mapping.
     * 2. Legacy indexed ALT meta.
     * 3. Positional fallback from fifu_slider_list_alt.
     *
     * @param int $postId
     * @param int $index
     * @return string|null
     */
    public static function get_slider_image_alt(int $postId, int $index): ?string
    {
        if ($index < 0) {
            return null;
        }

        if (!self::has_slider_image_url_at_index($postId, $index)) {
            return null;
        }

        $db2Alt = self::get_db2_slider_alt($postId, $index);
        if ($db2Alt !== null && $db2Alt !== '') {
            return $db2Alt;
        }

        $legacyAlt = self::get_legacy_indexed_slider_alt($postId, $index);
        if ($legacyAlt !== null && $legacyAlt !== '') {
            return $legacyAlt;
        }

        $listAlt = self::get_slider_list_alt_segment($postId, $index);
        if ($listAlt !== null && $listAlt !== '') {
            return $listAlt;
        }

        return null;
    }

    private static function has_slider_image_url_at_index(int $postId, int $index): bool
    {
        $url = null;

        if (class_exists('Fifu_Post_Slider_Image_Url_Read_Service', false)) {
            $url = Fifu_Post_Slider_Image_Url_Read_Service::get_slider_image_url($postId, $index);
        }

        if (self::normalize_slider_url_value($url) !== '') {
            return true;
        }

        $legacyUrl = get_post_meta($postId, 'fifu_slider_image_url_' . $index, true);
        if (self::normalize_slider_url_value($legacyUrl) !== '') {
            return true;
        }

        if (class_exists('Fifu_Post_Slider_List_Url_Read_Service', false)) {
            $listUrls = Fifu_Post_Slider_List_Url_Read_Service::get_slider_list_urls($postId);
            if (isset($listUrls[$index]) && self::normalize_slider_url_value($listUrls[$index]) !== '') {
                return true;
            }
        }

        return false;
    }

    private static function get_db2_slider_alt(int $postId, int $index): ?string
    {
        if (!function_exists('fifu_db2_manager')) {
            return null;
        }

        $manager = fifu_db2_manager();
        if (!is_object($manager) || !method_exists($manager, 'getPostAltMapping')) {
            return null;
        }

        $mapping = $manager->getPostAltMapping($postId, 'slider', $index);
        if (!is_array($mapping)) {
            return null;
        }

        if (array_key_exists('alt', $mapping)) {
            $alt = self::normalize_slider_alt_segment($mapping['alt']);
            return $alt !== '' ? $alt : null;
        }

        if (array_key_exists('value', $mapping)) {
            $value = self::normalize_slider_alt_segment($mapping['value']);
            return $value !== '' ? $value : null;
        }

        return null;
    }

    private static function get_legacy_indexed_slider_alt(int $postId, int $index): ?string
    {
        $metaKey = 'fifu_slider_image_alt_' . $index;
        $legacyAlt = self::normalize_slider_alt_segment(get_post_meta($postId, $metaKey, true));

        return $legacyAlt === '' ? null : $legacyAlt;
    }

    private static function get_slider_list_alt_segment(int $postId, int $index): ?string
    {
        $listAlt = (string) get_post_meta($postId, 'fifu_slider_list_alt', true);
        if ($listAlt === '' && class_exists('Fifu_Post_Slider_List_Alt_Read_Service', false)) {
            $listAlt = (string) (Fifu_Post_Slider_List_Alt_Read_Service::get_slider_list_alt($postId) ?? '');
        }

        if ($listAlt === '') {
            return null;
        }

        if (strpos($listAlt, '|') === false) {
            if ($index === 0) {
                return null;
            }

            return self::normalize_slider_alt_segment($listAlt);
        }

        $segments = $listAlt === '' ? [] : preg_split('/\s*\|\s*/', $listAlt);
        $segment = $segments[$index] ?? '';
        $normalized = self::normalize_slider_alt_segment($segment);

        return $normalized === '' ? null : $normalized;
    }

    /**
     * @param mixed $value
     */
    private static function normalize_slider_alt_segment($value): string
    {
        if ($value === null) {
            return '';
        }

        $normalized = trim((string) $value);
        $normalizedLower = strtolower($normalized);
        if (
            $normalizedLower === ''
            || $normalizedLower === 'null'
            || $normalizedLower === 'undefined'
            || $normalizedLower === 'http://null'
            || $normalizedLower === 'https://null'
        ) {
            return '';
        }

        if (function_exists('wp_strip_all_tags')) {
            $normalized = (string) wp_strip_all_tags($normalized);
        } else {
            $normalized = strip_tags($normalized);
        }

        return trim($normalized);
    }

    /**
     * @param mixed $value
     */
    private static function normalize_slider_url_value($value): string
    {
        if ($value === null) {
            return '';
        }

        $normalized = trim((string) $value);
        if ($normalized === '') {
            return '';
        }

        $decoded = htmlspecialchars_decode($normalized);
        return trim($decoded);
    }
}
