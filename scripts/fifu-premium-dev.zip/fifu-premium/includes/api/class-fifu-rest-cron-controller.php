<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

final class Fifu_Rest_Cron_Controller
{
    /**
     * Registers cron-related REST routes.
     */
    public static function register_routes(): void
    {
        register_rest_route(
            'fifu-premium/v2',
            '/cron-add/',
            [
                'methods' => 'POST',
                'callback' => [self::class, 'cron_add'],
                'permission_callback' => [Fifu_Rest_Permissions::class, 'private_data'],
                'args' => [
                    'toggle' => [
                        'required' => true,
                        'validate_callback' => [self::class, 'validate_feature'],
                    ],
                ],
            ]
        );
        register_rest_route(
            'fifu-premium/v2',
            '/cron-delete/',
            [
                'methods' => 'POST',
                'callback' => [self::class, 'cron_delete'],
                'permission_callback' => [Fifu_Rest_Permissions::class, 'private_data'],
                'args' => [
                    'toggle' => [
                        'required' => true,
                        'validate_callback' => [self::class, 'validate_feature'],
                    ],
                ],
            ]
        );
        register_rest_route(
            'fifu-premium/v2',
            '/cron-run/',
            [
                'methods' => 'POST',
                'callback' => [self::class, 'cron_run'],
                'permission_callback' => [self::class, 'check_cron_run_token'],
                'args' => [
                    'feature' => [
                        'required' => true,
                        'validate_callback' => [self::class, 'validate_feature'],
                    ],
                ],
            ]
        );
    }

    /**
     * Handles cron-add REST callback.
     *
     * @return \WP_REST_Response
     */
    public static function cron_add(\WP_REST_Request $request)
    {
        $toggle = (string) ($request['toggle'] ?? '');
        return new \WP_REST_Response('', self::cron_add_feature($toggle));
    }

    /**
     * Registers the external cron for a feature toggle.
     */
    public static function cron_add_feature(string $toggle): int
    {
        if (!self::is_allowed_feature($toggle)) {
            return 400;
        }

        if (self::is_local_import_toggle($toggle)) {
            $service = $toggle === 'fifu_toggle_importterm'
                ? 'importterm'
                : 'importpost';

            $scheduled = Fifu_Generic_Cron_Service::schedule_local_import(
                $service
            );

            $status = $scheduled ? 200 : 500;

            self::log_cron_event(
                'cron-add',
                $scheduled ? 'INFO' : 'ERROR',
                $status,
                $toggle
            );

            return $status;
        }

        $data = [
            'site' => self::get_site_url(),
            'route' => self::get_rest_url_value(),
            'plugin' => self::get_client_identifier(),
            'version' => self::get_plugin_version(),
            'key' => Fifu_Options_Utils::partial_key(),
            'feature' => $toggle,
        ];

        $url = 'https://plugin.featuredimagefromurl.com/api/cron_add/?' . http_build_query($data);

        $args = [
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => get_option('fifu_ws_key_ddg'),
            ],
            'timeout' => 60,
        ];

        $response = self::remote_get($url, $args);

        if (self::is_wp_error_value($response)) {
            $error_message = $response->get_error_message();
            self::log_cron_event('cron-add', 'ERROR', $error_message, $toggle);
            return 500;
        }

        $status_code = self::remote_get_response_code($response);
        self::log_cron_event('cron-add', 'INFO', $status_code, $toggle);
        return $status_code;
    }

    /**
     * Handles cron-delete REST callback.
     *
     * @return \WP_REST_Response
     */
    public static function cron_delete(\WP_REST_Request $request)
    {
        $toggle = (string) ($request['toggle'] ?? '');
        return new \WP_REST_Response('', self::cron_delete_feature($toggle));
    }

    /**
     * Removes the external cron for a feature toggle.
     */
    public static function cron_delete_feature(string $toggle): int
    {
        if (!self::is_allowed_feature($toggle)) {
            return 400;
        }

        if (self::is_local_import_toggle($toggle)) {
            $service = $toggle === 'fifu_toggle_importterm'
                ? 'importterm'
                : 'importpost';

            Fifu_Generic_Cron_Service::clear_local_import_schedule(
                $service
            );

            Fifu_Transient_Manager::delete(
                self::local_import_cron_token_key($toggle)
            );

            return 200;
        }

        $data = [
            'site' => self::get_site_url(),
            'feature' => $toggle,
        ];

        $url = 'https://plugin.featuredimagefromurl.com/api/cron_delete/?' . http_build_query($data);

        $args = [
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => get_option('fifu_ws_key_ddg'),
            ],
            'timeout' => 60,
        ];

        $response = self::remote_get($url, $args);

        if (self::is_wp_error_value($response)) {
            $error_message = $response->get_error_message();
            self::log_cron_event('cron-delete', 'ERROR', $error_message, $toggle);
            return 500;
        }

        $status_code = self::remote_get_response_code($response);
        self::log_cron_event('cron-delete', 'INFO', $status_code, $toggle);

        return $status_code;
    }

    /**
     * Handles cron-run REST callback.
     *
     * @return \WP_REST_Response
     */
    public static function cron_run(\WP_REST_Request $request)
    {
        $toggle = (string) $request->get_param('feature');
        $option = str_replace('toggle_', '', $toggle);
        $id = str_replace('fifu_toggle_', '', $toggle);

        if (Fifu_Options_Utils::is_off($option)) {
            return new \WP_REST_Response('', 403);
        }

        switch ($id) {
            case 'asin':
            case 'finder':
            case 'auto_set':
            case 'importpost':
            case 'importterm':
                Fifu_Generic_Cron_Service::run($id);
                break;

            case 'upload_job':
                Fifu_Generic_Cron_Service::run('uploadpost');
                Fifu_Generic_Cron_Service::run('uploadterm');
                break;

            case 'cron_metadata':
                if (!Fifu_Transient_Manager::get('fifu_import_running')) {
                    Fifu_Generic_Cron_Service::run('metadatapost');
                    Fifu_Generic_Cron_Service::run('metadataterm');
                }
                break;

            case 'customfield':
                Fifu_Cron_Job_Service::run_customfield_job();
                break;

            case 'screenshot':
                Fifu_Screenshot_Cron_Service::run();
                break;

            case 'cloud_upload_auto':
                Fifu_Cloud_Media_Service::run_upload_auto_job();
                break;

            case 'cloud_delete_auto':
                Fifu_Cloud_Media_Service::run_delete_auto_job();
                break;

            default:
                break;
        }

        return new \WP_REST_Response('', 200);
    }

    /**
     * Validates the cron authorization token per the legacy permission callback.
     */
    public static function check_cron_run_token(\WP_REST_Request $request): bool
    {
        $feature = (string) $request->get_param('feature');
        if (self::is_local_import_toggle($feature)) {
            $token = (string) $request->get_header('X-FIFU-Authorization');
            if ($token === '') {
                return false;
            }

            $tokenKey = self::local_import_cron_token_key($feature);
            $storedToken = Fifu_Transient_Manager::get($tokenKey);
            if ($storedToken === false || !is_scalar($storedToken)) {
                return false;
            }

            $storedToken = (string) $storedToken;
            if ($storedToken === '' || !hash_equals($storedToken, $token)) {
                return false;
            }

            Fifu_Transient_Manager::delete($tokenKey);
            return true;
        }

        $token = (string) $request->get_header('X-FIFU-Authorization');
        if ($token === '') {
            $token = (string) $request->get_header('Authorization');
        }
        return $token === get_option('fifu_ws_key_ddg');
    }

    private static function is_local_import_toggle(string $toggle): bool
    {
        return in_array($toggle, [
            'fifu_toggle_importpost',
            'fifu_toggle_importterm',
        ], true);
    }

    private static function local_import_cron_token_key(string $toggle): string
    {
        return $toggle === 'fifu_toggle_importterm'
            ? 'fifu_api_importterm_cron_auth_token'
            : 'fifu_api_importpost_cron_auth_token';
    }

    /**
     * Validates supported cron feature names coming from REST arguments.
     *
     * @param mixed $param
     * @param \WP_REST_Request $request
     * @param string $key
     */
    public static function validate_feature($param, \WP_REST_Request $request, $key): bool
    {
        return is_scalar($param) && self::is_allowed_feature((string) $param);
    }

    private static function is_allowed_feature(string $feature): bool
    {
        return in_array($feature, self::allowed_features(), true);
    }

    /**
     * @return string[]
     */
    private static function allowed_features(): array
    {
        return [
            'fifu_toggle_screenshot',
            'fifu_toggle_asin',
            'fifu_toggle_customfield',
            'fifu_toggle_finder',
            'fifu_toggle_auto_set',
            'fifu_toggle_upload_job',
            'fifu_toggle_cloud_upload_auto',
            'fifu_toggle_cloud_delete_auto',
            'fifu_toggle_cron_metadata',
            'fifu_toggle_importpost',
            'fifu_toggle_importterm',
        ];
    }

    private static function get_site_url(): string
    {
        if (isset($GLOBALS['__wp_home_url'])) {
            return (string) $GLOBALS['__wp_home_url'];
        }

        if (function_exists('get_home_url')) {
            return (string) get_home_url();
        }

        if (function_exists('get_option')) {
            return (string) get_option('home', '');
        }

        return '';
    }

    private static function get_rest_url_value(): string
    {
        if (function_exists('get_rest_url')) {
            return (string) get_rest_url();
        }

        if (function_exists('rest_url')) {
            return (string) rest_url();
        }

        return '';
    }

    /**
     * @param array<string,mixed> $args
     * @return mixed
     */
    private static function remote_get(string $url, array $args)
    {
        if (function_exists('wp_remote_get')) {
            return wp_remote_get($url, $args);
        }

        if (!isset($GLOBALS['__wp_remote_get_calls'])) {
            $GLOBALS['__wp_remote_get_calls'] = [];
        }

        $GLOBALS['__wp_remote_get_calls'][] = compact('url', 'args');

        $callback = $GLOBALS['__wp_remote_get_callback'] ?? null;
        if (is_callable($callback)) {
            return $callback($url, $args);
        }

        if (isset($GLOBALS['__wp_remote_get_next_response'])) {
            $response = $GLOBALS['__wp_remote_get_next_response'];
            unset($GLOBALS['__wp_remote_get_next_response']);
            return $response;
        }

        return ['response' => ['code' => 200]];
    }

    private static function get_client_identifier(): string
    {
        return defined('FIFU_CLIENT') ? (string) FIFU_CLIENT : 'FIFU_CLIENT';
    }

    private static function is_wp_error_value($value): bool
    {
        if (function_exists('is_wp_error')) {
            return is_wp_error($value);
        }

        return $value instanceof \WP_Error;
    }

    private static function get_plugin_version(): string
    {
        if (class_exists('Fifu_Plugin_Info', false) && method_exists('Fifu_Plugin_Info', 'get_version')) {
            return (string) Fifu_Plugin_Info::get_version();
        }

        return (string) ($GLOBALS['fifu_stub_version'] ?? '0.0-test');
    }

    /**
     * @param mixed $response
     */
    private static function remote_get_response_code($response): int
    {
        if (function_exists('wp_remote_retrieve_response_code')) {
            return (int) wp_remote_retrieve_response_code($response);
        }

        if (is_array($response) && isset($response['response']['code'])) {
            return (int) $response['response']['code'];
        }

        return 0;
    }

    /**
     * @param int|string $value
     */
    private static function log_cron_event(string $channel, string $level, $value, string $toggle): void
    {
        if (!class_exists('Fifu_File_Logger', false) || !method_exists('Fifu_File_Logger', 'plugin')) {
            return;
        }

        Fifu_File_Logger::plugin([
            $channel => [
                $level => $value,
                'toggle' => $toggle,
            ],
        ]);
    }

}
