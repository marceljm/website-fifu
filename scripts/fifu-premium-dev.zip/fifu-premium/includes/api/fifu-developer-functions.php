<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Public developer API: set FIFU image for a post.
 *
 * @param int    $post_id   Post ID.
 * @param string $image_url Remote image URL.
 * @return bool Result from delegated service call.
 */
function fifu_dev_set_image( $post_id, $image_url ) {
	return Fifu_Developer_Media_Service::set_image(
		(int) $post_id,
		$image_url,
		true
	);
}

/**
 * Public developer API: set FIFU video for a post.
 *
 * @param int    $post_id   Post ID.
 * @param string $video_url Remote video URL.
 * @return bool Result from delegated service call.
 */
function fifu_dev_set_video( $post_id, $video_url ) {
	return Fifu_Developer_Media_Service::set_video(
		(int) $post_id,
		$video_url,
		true
	);
}

/**
 * Public developer API: set FIFU image list for a post.
 *
 * @param int    $post_id        Post ID.
 * @param string $image_url_list Serialized image URL list.
 * @return bool Result from delegated service call.
 */
function fifu_dev_set_image_list( $post_id, $image_url_list ) {
	return Fifu_Developer_Media_Service::set_image_list(
		(int) $post_id,
		$image_url_list,
		null,
		true
	);
}

/**
 * Public developer API: set FIFU video list for a post.
 *
 * @param int    $post_id        Post ID.
 * @param string $video_url_list Serialized video URL list.
 * @return bool Result from delegated service call.
 */
function fifu_dev_set_video_list( $post_id, $video_url_list ) {
	return Fifu_Developer_Media_Service::set_video_list(
		(int) $post_id,
		$video_url_list,
		true
	);
}

/**
 * Public developer API: set slider entries for a post.
 *
 * @param int    $post_id Post ID.
 * @param string $url_list Serialized slider URL list.
 * @param string $alt_list Serialized slider alt text list.
 * @return bool Result from delegated service call.
 */
function fifu_dev_set_slider( $post_id, $url_list, $alt_list ) {
	return Fifu_Developer_Media_Service::set_slider(
		(int) $post_id,
		$url_list,
		$alt_list,
		true
	);
}

/**
 * Public developer API: set FIFU image for a term.
 *
 * @param int    $term_id   Term ID.
 * @param string $image_url Remote image URL.
 * @return bool Result from delegated service call.
 */
function fifu_dev_set_category_image( $term_id, $image_url ) {
	return Fifu_Developer_Media_Service::set_category_image(
		(int) $term_id,
		$image_url
	);
}

/**
 * Public developer API: set FIFU video for a term.
 *
 * @param int    $term_id   Term ID.
 * @param string $video_url Remote video URL.
 * @return bool Result from delegated service call.
 */
function fifu_dev_set_category_video( $term_id, $video_url ) {
	return Fifu_Developer_Media_Service::set_category_video(
		(int) $term_id,
		$video_url
	);
}
