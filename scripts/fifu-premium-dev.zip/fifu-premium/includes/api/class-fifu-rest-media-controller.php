<?php
declare(strict_types=1);

final class Fifu_Rest_Media_Controller {

    /**
     * Register REST API routes for media-related endpoints.
     */
    public static function register_routes(): void {
        $permission = [Fifu_Rest_Permissions::class, 'private_data'];
        register_rest_route('fifu-premium/v2', '/create_thumbnails_list/', array(
            'methods' => 'POST',
            'callback' => [self::class, 'create_thumbnails_list'],
            'permission_callback' => $permission,
        ));
        register_rest_route('fifu-premium/v2', '/video_image_thumbnail/', array(
            'methods' => 'POST',
            'callback' => [self::class, 'video_image_thumbnail'],
            'permission_callback' => $permission,
        ));
        register_rest_route('fifu-premium/v2', '/video_src/', array(
            'methods' => 'POST',
            'callback' => [self::class, 'video_src'],
            'permission_callback' => $permission,
        ));

        register_rest_route('fifu-premium/v2', '/upload_images/', [
            'methods' => 'POST',
            'callback' => [self::class, 'upload_images'],
            'permission_callback' => $permission,
        ]);
        register_rest_route('fifu-premium/v2', '/list_all_media_library/', [
            'methods' => 'POST',
            'callback' => [self::class, 'list_all_media_library'],
            'permission_callback' => $permission,
        ]);
        register_rest_route('fifu-premium/v2', '/convert_to_fifu/', [
            'methods' => 'POST',
            'callback' => [self::class, 'convert_to_fifu'],
            'permission_callback' => $permission,
        ]);
    }

    /**
     * REST callback: create a thumbnails list from selected images.
     */
    public static function create_thumbnails_list(\WP_REST_Request $request) {
        if (!Fifu_Admin_Menu::is_su_sign_up_complete()) {
            return Fifu_Cloud_Config::get_no_credentials_payload();
        }

        $images = $request['selected'] ?? [];
        return Fifu_Cloud_Media_Service::create_thumbnails_list($images, false);
    }

    /**
     * REST callback: retrieve a large thumbnail URL for a given video URL.
     */
    public static function video_image_thumbnail(\WP_REST_Request $request) {
        $video_url = $request['url'] ?? '';
        $image_url = Fifu_Video_Helper::get_thumbnail_large($video_url);
        $response = new \WP_REST_Response(['image_url' => $image_url]);
        $response->set_status(200);
        $response->header('Content-Type', 'application/json');
        return $response;
    }

    /**
     * REST callback: retrieve an embeddable video source URL.
     */
    public static function video_src(\WP_REST_Request $request) {
        $video_url = $request['url'] ?? '';
        return Fifu_Video_Helper::get_embed_url($video_url);
    }

    /**
     * Handles remote image uploads coming from the admin UI.
     *
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response
     */
    public static function upload_images(\WP_REST_Request $request): \WP_REST_Response
    {
        $postId = (int) ($request['post_id'] ?? 0);
        $termId = (int) ($request['term_id'] ?? 0);
        $metaBox = filter_var($request['meta_box'] ?? false, FILTER_VALIDATE_BOOLEAN);
        $fromSlider = filter_var($request['from_slider'] ?? false, FILTER_VALIDATE_BOOLEAN);
        $taxonomy = (string) ($request['taxonomy'] ?? '');
        $isCategory = $taxonomy === 'product_cat';
        $targetId = $isCategory ? ($termId > 0 ? $termId : $postId) : $postId;
        $featuredUrl = trim((string) ($request['url'] ?? ''));
        $featuredAlt = wp_strip_all_tags($request['alt'] ?? '');

        $galleryUrls = rtrim((string) ($request['urls'] ?? ''));
        $galleryUrls = $galleryUrls ? explode('|', $galleryUrls) : [];
        $galleryUrls = array_values(array_map('trim', $galleryUrls));

        $galleryAlts = wp_strip_all_tags($request['alts'] ?? '');
        $galleryAlts = $galleryAlts ? explode('|', $galleryAlts) : [];
        $galleryAlts = array_values(array_map('trim', $galleryAlts));

        $result = Fifu_Media_Upload_Service::upload_via_rest(
            $targetId,
            $featuredUrl,
            $featuredAlt,
            $galleryUrls,
            $galleryAlts,
            $metaBox,
            $isCategory,
            $fromSlider
        );

        $responseData = $metaBox
            ? ['att_ids' => $result['attachment_ids'], 'local_url' => $result['local_url']]
            : ['local_url' => $result['local_url']];

        $response = new \WP_REST_Response($responseData);
        $response->set_status(200);
        $response->header('Content-Type', 'application/json');

        return $response;
    }

    /**
     * Returns a sanitized list of posts that rely on the internal media library.
     *
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response
     */
    public static function list_all_media_library(\WP_REST_Request $request)
    {
        $page = (int) ($request['page'] ?? 0);
        $type = $request['type'] ?? null;
        $keyword = $request['keyword'] ?? null;
        $repository = function_exists('fifu_db2_speed_up_repository') ? fifu_db2_speed_up_repository() : null;
        $results = $repository ? $repository->get_posts_with_internal_featured_image($page, $type, $keyword) : [];

        if (is_array($results)) {
            foreach ($results as $item) {
                if (!is_object($item)) {
                    continue;
                }

                $item->url = esc_url_raw($item->url ?? '');
                $item->post_title = sanitize_text_field($item->post_title ?? '');
                $item->post_name = sanitize_text_field($item->post_name ?? '');
                $item->post_date = sanitize_text_field($item->post_date ?? '');
                $item->gallery_ids = isset($item->gallery_ids) ? sanitize_text_field($item->gallery_ids) : null;
                $item->post_id = intval($item->post_id ?? 0);
                $item->thumbnail_id = intval($item->thumbnail_id ?? 0);
                $item->category = isset($item->category) ? (int) (!!$item->category) : 0;
            }
        }

        return new \WP_REST_Response($results);
    }

    /**
     * Converts internal media selections into FIFU remote URL metadata.
     *
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response
     */
    public static function convert_to_fifu(\WP_REST_Request $request): \WP_REST_Response
    {
        $selected = $request['selected'] ?? [];
        if (!is_array($selected)) {
            $selected = [];
        }

        Fifu_Media_Conversion_Service::convert_to_fifu($selected);

        return new \WP_REST_Response([
            'success' => true,
            'selected_count' => count($selected),
        ]);
    }
}
