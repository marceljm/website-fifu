<?php

declare(strict_types=1);

/**
 * HTTP client abstraction for the FIFU PAAPI worker.
 */
class Fifu_Asin_Image_Service {

    /**
     * Fetch image payloads for a given ASIN.
     */
    public function fetch_images_for_asin(string $asin): ?array {
        return $this->call_worker($asin);
    }

    /**
     * Fetch a normalized result for the worker flow.
     *
     * @return array{ok:bool,not_found:bool,data:?array,error:?string}
     */
    public function fetch_images_for_asin_result(string $asin): array {
        $response = $this->call_raw_worker($asin);
        if ($response === null) {
            return [
                'ok' => false,
                'not_found' => false,
                'data' => null,
                'error' => 'transport_error',
            ];
        }

        if (is_wp_error($response)) {
            return [
                'ok' => false,
                'not_found' => false,
                'data' => null,
                'error' => 'transport_error',
            ];
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            return [
                'ok' => false,
                'not_found' => false,
                'data' => null,
                'error' => 'transport_error',
            ];
        }

        $body = (string) wp_remote_retrieve_body($response);
        if ($body === '') {
            return [
                'ok' => false,
                'not_found' => false,
                'data' => null,
                'error' => 'invalid_response',
            ];
        }

        $data = json_decode($body, true);
        if (!is_array($data)) {
            return [
                'ok' => false,
                'not_found' => false,
                'data' => null,
                'error' => 'invalid_response',
            ];
        }

        $images = $this->normalize_media_list($data['images'] ?? $data['image'] ?? []);
        $videos = $this->normalize_media_list($data['videos'] ?? $data['video'] ?? []);
        $hasMedia = !empty($images) || !empty($videos);

        return [
            'ok' => true,
            'not_found' => !$hasMedia,
            'data' => $data,
            'error' => null,
        ];
    }

    /**
     * Delegate the remote call to the PAAPI worker.
     */
    private function call_worker(string $asin): ?array {
        $response = $this->call_raw_worker($asin);
        if (is_wp_error($response) || $response === null) {
            return null;
        }

        if (wp_remote_retrieve_response_code($response) != 200) {
            return null;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (!empty($data['images'] ?? [])) {
            return $data;
        }

        return null;
    }

    /**
     * @return array|\WP_Error|null
     */
    private function call_raw_worker(string $asin) {
        $queryParams = [
            'site' => Fifu_Image_Url_Utils::get_home_url_no_scheme(),
            'partial_key' => Fifu_Options_Utils::partial_key(),
            'asin' => $asin,
            'partner_tag' => get_option('fifu_asin_credentials_partner') ?: '',
            'access_key' => get_option('fifu_asin_credentials_access') ?: '',
            'secret_key' => get_option('fifu_asin_credentials_secret') ?: '',
            'locale' => get_option('fifu_asin_credentials_locale') ?: '',
        ];

        $workerUrl = "https://paapi5.fifu.workers.dev";

        try {
            $response = wp_remote_post($workerUrl, [
                'body' => json_encode($queryParams),
                'headers' => [
                    'Content-Type' => 'application/json',
                ],
                'timeout' => 10,
            ]);
            return $response;
        } catch (Exception $e) {
            // Swallow errors to avoid printing during tests.
        }

        return null;
    }

    /**
     * @param mixed $value
     * @return array<int, string>
     */
    private function normalize_media_list($value): array {
        $values = is_array($value) ? $value : explode('|', (string) $value);
        $normalized = [];

        foreach ($values as $item) {
            $url = '';

            if (is_string($item)) {
                $url = trim($item);
            } elseif (is_array($item) && isset($item['url']) && is_string($item['url'])) {
                $url = trim($item['url']);
            } elseif (is_object($item) && isset($item->url) && is_string($item->url)) {
                $url = trim($item->url);
            }

            if ($url === '') {
                continue;
            }

            if (!filter_var($url, FILTER_VALIDATE_URL)) {
                continue;
            }

            if (!preg_match('#^https?://#i', $url)) {
                continue;
            }

            $normalized[] = $url;
        }

        return array_values(array_unique($normalized));
    }
}
