<?php
declare(strict_types=1);

final class Fifu_Rest_Controller {

    /**
     * Register REST API routes for general FIFU Cloud and license operations.
     */
    public static function register_routes(): void {
        register_rest_route('fifu-premium/v1', '/url/(?P<post_id>\d+)', array(
            'methods' => 'GET',
            'callback' => [self::class, 'image_url'],
            'permission_callback' => [Fifu_Rest_Permissions::class, 'private_data'],
            'args' => array(
                'post_id' => array(
                    'required' => true,
                    'validate_callback' => function ($param) {
                        return is_numeric($param);
                    },
                ),
            ),
        ));

        $private_permissions = [Fifu_Rest_Permissions::class, 'private_data'];

        register_rest_route('fifu-premium/v2', '/sign_up/', array(
            'methods' => 'POST',
            'callback' => [self::class, 'sign_up'],
            'permission_callback' => $private_permissions,
        ));
        register_rest_route('fifu-premium/v2', '/connected/', array(
            'methods' => 'POST',
            'callback' => [self::class, 'connected'],
            'permission_callback' => $private_permissions,
        ));
        register_rest_route('fifu-premium/v2', '/cancel/', array(
            'methods' => 'POST',
            'callback' => [self::class, 'cancel'],
            'permission_callback' => $private_permissions,
        ));
        register_rest_route('fifu-premium/v2', '/payment_info/', array(
            'methods' => 'POST',
            'callback' => [self::class, 'payment_info'],
            'permission_callback' => $private_permissions,
        ));
        register_rest_route('fifu-premium/v2', '/check_for_updates_api/', array(
            'methods' => 'POST',
            'callback' => [self::class, 'check_for_updates'],
            'permission_callback' => $private_permissions,
        ));
        register_rest_route('fifu-premium/v2', '/disable_default_api/', array(
            'methods' => 'POST',
            'callback' => [self::class, 'disable_default'],
            'permission_callback' => $private_permissions,
        ));
        register_rest_route('fifu-premium/v2', '/none_default_api/', array(
            'methods' => 'POST',
            'callback' => [self::class, 'none_default'],
            'permission_callback' => $private_permissions,
        ));
        register_rest_route('fifu-premium/v2', '/otfcdn-api/', array(
            'methods' => 'POST',
            'callback' => [self::class, 'otfcdn'],
            'permission_callback' => $private_permissions,
        ));
        register_rest_route('fifu-premium/v2', '/test_server_api/', array(
            'methods' => 'POST',
            'callback' => [self::class, 'api_test_server'],
            'permission_callback' => $private_permissions,
        ));
        register_rest_route('fifu-premium/v2', '/test_key_api/', array(
            'methods' => 'POST',
            'callback' => [self::class, 'test_key'],
            'permission_callback' => $private_permissions,
        ));
        register_rest_route('fifu-premium/v2', '/test-server/', array(
            'methods' => 'POST',
            'callback' => [self::class, 'test_server'],
            'permission_callback' => function ($request) {
                $token = $request->get_header('X-FIFU-Authorization');
                return $token === Fifu_Plugin_Info::get_version();
            },
        ));

        register_rest_route('fifu-premium/v2', '/rest_url_api/', array(
            'methods' => array('GET', 'POST'),
            'callback' => [self::class, 'rest_url'],
            'permission_callback' => [Fifu_Rest_Permissions::class, 'public_access'],
        ));
        register_rest_route('fifu-premium/v2', '/custom-proxy-handler/', array(
            'methods' => 'GET',
            'callback' => [self::class, 'custom_proxy'],
            'permission_callback' => [Fifu_Rest_Permissions::class, 'public_access'],
        ));
    }

    /**
     * REST callback: return the direct FIFU featured-image URL for a post.
     */
    public static function image_url(\WP_REST_Request $request) {
        $post_id = (int) ($request['post_id'] ?? 0);
        if ($post_id <= 0) {
            return null;
        }
        return Fifu_Post_Image_Url_Read_Service::get_image_url($post_id) ?? '';
    }

    /**
     * REST callback: handle signup.
     */
    public static function sign_up(\WP_REST_Request $request) {
        $email = self::string_param($request, 'email');
        return Fifu_Cloud_License_Service::sign_up($email);
    }

    private static function string_param(\WP_REST_Request $request, string $key): string {
        $value = $request[$key] ?? '';
        return is_scalar($value) ? (string) $value : '';
    }

    /**
     * REST callback: cancel subscription.
     */
    public static function cancel(\WP_REST_Request $request) {
        return Fifu_Cloud_License_Service::cancel();
    }

    /**
     * REST callback: get payment info.
     */
    public static function payment_info(\WP_REST_Request $request) {
        return Fifu_Cloud_License_Service::payment_info();
    }

    /**
     * REST callback: check if the site is connected to FIFU Cloud.
     */
    public static function connected(\WP_REST_Request $request) {
        return Fifu_Cloud_License_Service::connected();
    }

    /**
     * REST callback: check for plugin updates using the license key.
     */
    public static function check_for_updates(\WP_REST_Request $request) {
        $key = sanitize_text_field($request->get_param('key'));
        $network = filter_var($request->get_param('network'), FILTER_VALIDATE_BOOLEAN);
        $response = Fifu_Admin_Menu::update_license_key($key, $network);
        return wp_send_json(array('status' => (bool) $response));
    }

    /**
     * REST callback: disable the default URL.
     */
    public static function disable_default(\WP_REST_Request $request) {
        Fifu_Default_Image_Service::delete_default_image();
        return json_encode(array());
    }

    /**
     * REST callback: mark plugin server as healthy from the external callback.
     */
    public static function test_server(\WP_REST_Request $request) {
        Fifu_Cloud_Test_Service::mark_plugin_server_healthy();
        return json_encode(array());
    }

    /**
     * REST callback: test license key against the worker endpoint.
     */
    public static function test_key(\WP_REST_Request $request) {
        return Fifu_Cloud_License_Service::test_key();
    }

    /**
     * REST callback: fire a short test against the plugin server.
     */
    public static function api_test_server(\WP_REST_Request $request) {
        Fifu_Cloud_Test_Service::test_plugin_server();
        return json_encode(array());
    }

    /**
     * REST callback: toggle OTF CDN feature.
     */
    public static function otfcdn(\WP_REST_Request $request) {
        $enabled = ($request['toggle'] ?? '') === 'toggleon';
        $result = Fifu_Cloud_Otfcdn_Service::toggle($enabled);

        $success = Fifu_Options_Utils::is_on('fifu_otfcdn') === $enabled;

        if (is_array($result)) {
            $result['success'] = $success;
            return $result;
        }

        return [
            'success' => $success,
        ];
    }

    /**
     * REST callback: no-op endpoint used in some admin flows.
     */
    public static function none_default(\WP_REST_Request $request) {
        return json_encode(array());
    }

    /**
     * REST callback: return the site REST URL.
     */
    public static function rest_url(\WP_REST_Request $request) {
        return get_rest_url();
    }

    /**
     * REST callback: proxy an arbitrary URL when the proper secret is configured.
     */
    public static function custom_proxy(\WP_REST_Request $request) {
        $aux = get_option(base64_decode("ZmlmdV9rZXk="));
        if (preg_match('/^[\*]+$/', $aux, $values)) {
            $url = $request->get_param('url');
            if (empty($url)) {
                return new \WP_Error('no_url', 'No URL provided', array('status' => 400));
            }
            $url = esc_url_raw($url);
            $response = wp_remote_get($url);
            if (is_wp_error($response)) {
                return $response;
            }
            return wp_remote_retrieve_body($response);
        }
    }
}
