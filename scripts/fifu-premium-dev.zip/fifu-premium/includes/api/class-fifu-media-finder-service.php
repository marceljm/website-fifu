<?php

declare(strict_types=1);

/**
 * Facade for the legacy media finder worker integration.
 */
class Fifu_Media_Finder_Service {

    /**
     * Locate the featured image or video for the provided URL.
     */
    public function find_featured_image(string $url, bool $findVideo): ?string {
        $queryParams = http_build_query([
            'site' => Fifu_Image_Url_Utils::get_home_url_no_scheme(),
            'partial_key' => Fifu_Options_Utils::partial_key(),
            'url' => $url,
            'find_video' => $findVideo
        ]);
        $workerUrl = "https://find-media.fifu.app?" . $queryParams;

        $response = wp_remote_get($workerUrl);
        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) != 200) {
            return null;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (empty($data['url'] ?? null)) {
            return null;
        }

        if (count($data['url']) === 1) {
            return $data['url'][0];
        }

        return $this->find_largest_image($data['url']);
    }

    /**
     * Retrieve Amazon media assets for a post.
     */
    public function find_amazon_media(string $url, int $postId) {
        $queryParams = http_build_query([
            'site' => Fifu_Image_Url_Utils::get_home_url_no_scheme(),
            'partial_key' => Fifu_Options_Utils::partial_key(),
            'url' => $url,
        ]);
        $workerUrl = "https://find-media-amazon.fifu.workers.dev?" . $queryParams;

        $response = wp_remote_get($workerUrl);
        $this->sleep_seconds(6);

        $counter = Fifu_Finder_Not_Found_Bridge::get_post_attempts($postId);
        $counter = $counter === null ? 1 : $counter + 1;
        Fifu_Finder_Not_Found_Bridge::set_post_attempts($postId, $counter);
        $this->log_message('[' . $postId . '] (' . $counter . '): ' . $url);

        if (is_wp_error($response)) {
            Fifu_Finder_Not_Found_Bridge::set_post_attempts($postId, $counter, 'request_failed');
            return null;
        }

        $statusCode = (int) wp_remote_retrieve_response_code($response);
        if ($statusCode !== 200) {
            Fifu_Finder_Not_Found_Bridge::set_post_attempts($postId, $counter, 'http_status_' . $statusCode);
            return null;
        }

        $body = wp_remote_retrieve_body($response);
        $arrUrls = json_decode($body, true);

        if (!$arrUrls) {
            Fifu_Finder_Not_Found_Bridge::set_post_attempts($postId, $counter, 'invalid_json');
            return null;
        }

        $this->log_message('[' . $postId . '] Images found: ' . count($arrUrls['image'] ?? []));
        $this->log_message('[' . $postId . '] Videos found: ' . count($arrUrls['video'] ?? []));
        Fifu_Finder_Not_Found_Bridge::delete_post_counter($postId);

        return $arrUrls;
    }

    /**
     * Determine the largest image in a set of candidates.
     */
    private function find_largest_image(array $urls): ?string {
        $largest = null;
        $largestArea = 0;

        foreach ($urls as $imgUrl) {
            $imgUrl = html_entity_decode($imgUrl);
            $size = @getimagesize($imgUrl);
            if ($size) {
                $width = $size[0] ?? 0;
                $height = $size[1] ?? 0;
                $area = $width * $height;
                if ($area > $largestArea) {
                    $largest = $imgUrl;
                    $largestArea = $area;
                }
            }
        }

        return $largest;
    }

    /**
     * @internal Test seam to avoid real sleeping in unit tests.
     */
    protected function sleep_seconds(int $seconds): void {
        sleep($seconds);
    }

    /**
     * @internal Test seam to avoid emitting logs in unit tests.
     */
    protected function log_message(string $message): void {
        error_log($message);
    }
}
