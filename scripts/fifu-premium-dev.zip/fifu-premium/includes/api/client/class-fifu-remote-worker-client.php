<?php

class Fifu_Remote_Worker_Client {

    private const BASE_URL = 'https://plugin.featuredimagefromurl.com/api';

    /**
     * Mirrors fifu_next_register_from_server() with a dedicated HTTP client.
     */
    public static function register_next(string $service): void {
        $url = self::BASE_URL . "/next/{$service}/";
        $body = json_encode(array('route' => get_rest_url()));
        wp_remote_post($url, array(
            'method'   => 'POST',
            'body'     => $body,
            'headers'  => self::get_headers(),
            'blocking' => true,
            'timeout'  => 0.001,
        ));
    }

    /**
     * Mirrors fifu_delete_register_from_server(), including logging via Fifu_File_Logger.
     *
     * @param array<int> $post_ids
     * @param string $service
     */
    public static function delete_registers(array $post_ids, string $service): void {
        Fifu_File_Logger::plugin(array(
            'fifu-delete-register-from-server' => array(
                'SERVICE' => $service,
                'COUNT'   => count($post_ids),
            ),
        ));
        $url = self::BASE_URL . "/delete/{$service}/";
        $body = json_encode(array(
            'post_ids' => $post_ids,
            'route'    => get_rest_url(),
        ));
        wp_remote_post($url, array(
            'method'   => 'POST',
            'body'     => $body,
            'headers'  => self::get_headers(),
            'blocking' => true,
            'timeout'  => 0.001,
        ));
    }

    /**
     * Returns the common headers used in FIFU remote requests.
     */
    private static function get_headers(): array {
        return array(
            'Content-Type'  => 'application/json',
            'Authorization' => get_option('fifu_ws_key_ddg'),
        );
    }
}
