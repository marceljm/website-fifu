<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

class Fifu_Auto_Share_X_Service {

    public static function auth_start(\WP_REST_Request $request) {
        $body = Fifu_Auto_Share_Common::read_json($request);
        $intent = isset($body['intent']) ? sanitize_text_field($body['intent']) : 'login';
        $client_id = self::get_client_id();
        if ($client_id === '') {
            return new \WP_Error('fifu_as_x_client_id_missing', 'X Client ID is required', ['status' => 400]);
        }
        $payload = [
            'provider' => 'x',
            'site_id' => Fifu_Auto_Share_Common::get_site_id(),
            'user_id' => Fifu_Auto_Share_Common::get_user_id(),
            'intent' => $intent,
            'version' => Fifu_Auto_Share_Common::get_version(),
            'clientId' => $client_id,
        ];
        $worker = Fifu_Auto_Share_Common::worker_request('POST', '/v2/oauth/x/start', $payload);
        if (is_wp_error($worker)) {
            return $worker;
        }
        return Fifu_Auto_Share_Common::json_response([
            'authUrl' => isset($worker['authUrl']) ? esc_url_raw($worker['authUrl']) : '',
            'state' => isset($worker['state']) ? sanitize_text_field($worker['state']) : '',
            'popupOrigin' => isset($worker['popupOrigin']) ? esc_url_raw($worker['popupOrigin']) : '',
        ]);
    }

    public static function auth_finalize(\WP_REST_Request $request) {
        $body = Fifu_Auto_Share_Common::read_json($request);
        $token = isset($body['tempToken']) ? sanitize_text_field($body['tempToken']) : '';
        $state = isset($body['state']) ? sanitize_text_field($body['state']) : '';
        $user_id = Fifu_Auto_Share_Common::get_user_id();
        if (!$token) {
            return new \WP_Error('fifu_as_bad_request', 'Missing tempToken', ['status' => 400]);
        }
        $client_id = self::get_client_id();
        if ($client_id === '') {
            return new \WP_Error('fifu_as_x_client_id_missing', 'X Client ID is required', ['status' => 400]);
        }
        $payload = [
            'provider' => 'x',
            'site_id' => Fifu_Auto_Share_Common::get_site_id(),
            'user_id' => $user_id,
            'tempToken' => $token,
            'state' => $state,
            'version' => Fifu_Auto_Share_Common::get_version(),
            'clientId' => $client_id,
        ];
        $worker = Fifu_Auto_Share_Common::worker_request('POST', '/v2/oauth/x/finalize', $payload);
        if (is_wp_error($worker)) {
            return $worker;
        }
        $accounts_raw = [];
        foreach (['accounts', 'profiles', 'pages', 'tenants'] as $key) {
            if (!empty($worker[$key]) && is_array($worker[$key])) {
                $accounts_raw = $worker[$key];
                break;
            }
        }
        $token_payload = [];
        foreach (['token', 'tokens', 'credentials'] as $key) {
            if (!empty($worker[$key]) && is_array($worker[$key])) {
                $token_payload = $worker[$key];
                break;
            }
        }
        $normalized_accounts = Fifu_Auto_Share_Common::normalize_pages($accounts_raw);
        $normalized_token = Fifu_Auto_Share_Common::normalize_token($token_payload);
        $account_name = '';
        if (isset($worker['accountName']) && is_string($worker['accountName'])) {
            $account_name = sanitize_text_field($worker['accountName']);
        }
        if (!$account_name && !empty($worker['account']) && is_array($worker['account'])) {
            $maybe = $worker['account'];
            $account_name = isset($maybe['name']) ? sanitize_text_field($maybe['name']) : '';
            if (!$account_name && isset($maybe['username'])) {
                $account_name = sanitize_text_field($maybe['username']);
            }
        }
        if (!$account_name && !empty($normalized_accounts)) {
            $first = $normalized_accounts[0];
            if (!empty($first['name'])) {
                $account_name = sanitize_text_field($first['name']);
            } elseif (!empty($first['username'])) {
                $account_name = sanitize_text_field($first['username']);
            } elseif (!empty($first['handle'])) {
                $account_name = sanitize_text_field($first['handle']);
            }
        }
        $store = [
            'accountName' => $account_name,
            'pages' => $accounts_raw,
            'token' => $token_payload,
            'userId' => $user_id,
        ];
        $store['connected'] = !empty($worker['connected']);
        if (!$store['connected'] && (Fifu_Auto_Share_Common::token_has_credential($normalized_token) || Fifu_Auto_Share_Common::pages_have_credentials($normalized_accounts))) {
            $store['connected'] = true;
        }
        Fifu_Auto_Share_Common::store_connection('x', $store);
        $connection = Fifu_Auto_Share_Common::get_status_snapshot('x');
        return Fifu_Auto_Share_Common::json_response([
            'connected' => !empty($connection['connected']),
            'accountName' => $connection['accountName'],
            'pages' => $connection['pages'],
        ]);
    }

    public static function status(\WP_REST_Request $request) {
        $status = Fifu_Auto_Share_Common::get_status_snapshot('x');
        $status['clientId'] = self::get_client_id();
        return Fifu_Auto_Share_Common::json_response($status);
    }

    public static function disconnect(\WP_REST_Request $request) {
        Fifu_Auto_Share_Common::clear_connection('x');
        return Fifu_Auto_Share_Common::json_response([
            'connected' => false,
            'accountName' => null,
            'pages' => [],
        ]);
    }

    public static function share_post(\WP_REST_Request $request) {
        $body = Fifu_Auto_Share_Common::read_json($request);
        $user_id = Fifu_Auto_Share_Common::get_user_id();
        $post_id = isset($body['postId']) ? absint($body['postId']) : 0;
        if (!$post_id && isset($body['post_id'])) {
            $post_id = absint($body['post_id']);
        }
        if ($post_id <= 0) {
            return new \WP_Error('fifu_as_missing_post', 'Post ID is required', ['status' => 400]);
        }
        $post_payload = Fifu_Auto_Share_Common::build_post_share_payload($post_id);
        if (!$post_payload) {
            return new \WP_Error('fifu_as_post_not_found', 'Post not found', ['status' => 404]);
        }
        $connection = Fifu_Auto_Share_Common::get_connection_details('x');
        if (empty($connection['connected'])) {
            return new \WP_Error('fifu_as_x_not_connected', 'X connection required', ['status' => 409]);
        }
        if (Fifu_Auto_Share_Service::has_shared_on_provider($post_id, 'x')) {
            return Fifu_Auto_Share_Common::json_response([
                'ok' => true,
                'already_shared' => true,
                'provider' => 'x',
            ]);
        }
        $accounts = [];
        if (!empty($connection['pages']) && is_array($connection['pages'])) {
            foreach ($connection['pages'] as $candidate) {
                if (is_array($candidate)) {
                    $accounts[] = $candidate;
                }
            }
        }
        $requested_account_id = '';
        foreach (['accountId', 'account_id', 'account'] as $key) {
            if (!empty($body[$key]) && is_string($body[$key])) {
                $requested_account_id = trim((string) $body[$key]);
                break;
            }
        }
        $selected_account = null;
        if ($requested_account_id !== '') {
            foreach ($accounts as $account) {
                if (!is_array($account)) {
                    continue;
                }
                foreach (['id', 'handle', 'username'] as $field) {
                    if (isset($account[$field]) && (string) $account[$field] === $requested_account_id) {
                        $selected_account = $account;
                        break 2;
                    }
                }
            }
        }
        if (!$selected_account && !empty($accounts)) {
            foreach ($accounts as $account) {
                if (!is_array($account)) {
                    continue;
                }
                if (!empty($account['connected'])) {
                    $selected_account = $account;
                    break;
                }
            }
            if (!$selected_account) {
                $selected_account = $accounts[0];
            }
        }
        if (!$selected_account && !empty($connection['accountName'])) {
            $selected_account = [
                'name' => (string) $connection['accountName'],
            ];
        }
        $site_origin = set_url_scheme(home_url('/'), 'https');
        $site_origin = rtrim($site_origin, '/');
        $message = '';
        foreach (['message', 'text', 'caption'] as $msg_key) {
            if (!empty($body[$msg_key]) && is_string($body[$msg_key])) {
                $message = trim(wp_strip_all_tags((string) $body[$msg_key]));
                break;
            }
        }
        if ($message === '' && !empty($post_payload['excerpt'])) {
            $message = trim(wp_strip_all_tags((string) $post_payload['excerpt']));
        }
        if ($message !== '') {
            $message = preg_replace('/\s+/', ' ', $message);
            if (function_exists('mb_substr')) {
                $message = mb_substr($message, 0, 280);
            } else {
                $message = substr($message, 0, 280);
            }
        }
        $permalink = get_permalink($post_id);
        $link = $permalink ? set_url_scheme($permalink, 'https') : '';
        $media = null;
        if (parse_url($site_origin, PHP_URL_SCHEME) === 'https') {
            $media = self::prepare_instagram_media($post_id, $site_origin);
        }
        $payload = [
            'provider' => 'x',
            'site_id' => Fifu_Auto_Share_Common::get_site_id(),
            'user_id' => $user_id,
            'version' => Fifu_Auto_Share_Common::get_version(),
            'postId' => $post_id,
            'post' => $post_payload,
            'account' => $selected_account ?: [],
            'accounts' => $accounts,
            'token' => is_array($connection['token']) ? $connection['token'] : [],
            'clientId' => self::get_client_id(),
            'requestedBy' => [
                'user_id' => $user_id,
                'timestamp' => gmdate('c', current_time('timestamp', true)),
            ],
        ];
        if (!empty($connection['accountName']) && empty($payload['account']['name'])) {
            $payload['account']['name'] = (string) $connection['accountName'];
        }
        if ($message !== '') {
            $payload['message'] = $message;
        }
        if ($link) {
            $payload['link'] = $link;
        }
        if ($media) {
            $payload['media'] = $media;
        }
        if (method_exists('Fifu_Image_Url_Utils', 'get_home_url_no_scheme')) {
            $payload['site'] = Fifu_Image_Url_Utils::get_home_url_no_scheme();
        }
        $payload['site_origin'] = $site_origin;
        $payload['partial_key'] = Fifu_Options_Utils::partial_key();
        $worker = Fifu_Auto_Share_Common::worker_request('POST', '/share/x', $payload);
        if (is_wp_error($worker)) {
            $extra = [
                'ERROR' => $worker->get_error_message(),
            ];
            $code = $worker->get_error_code();
            if ($code) {
                $extra['ERROR_CODE'] = $code;
            }
            Fifu_Auto_Share_Service::append_log_entry($post_id, 'x', 'error', $extra);
            return $worker;
        }
        $assessment = Fifu_Auto_Share_Service::assess_worker_response('x', $worker);
        $extra = [
            'RESPONSE' => $assessment['normalized'],
        ];
        if ($assessment['error'] instanceof \WP_Error) {
            $extra['ERROR'] = $assessment['error']->get_error_message();
            Fifu_Auto_Share_Service::append_log_entry($post_id, 'x', 'error', $extra);
            return $assessment['error'];
        }
        Fifu_Auto_Share_Service::append_log_entry($post_id, 'x', 'success', $extra);
        self::maybe_persist_refreshed_token(
            $worker,
            is_string($connection['accountName'] ?? null) ? $connection['accountName'] : '',
            $accounts ?: (is_array($connection['pages']) ? $connection['pages'] : []),
            $user_id
        );
        Fifu_Auto_Share_Service::mark_shared_on_provider($post_id, 'x');
        return Fifu_Auto_Share_Common::json_response([
            'ok' => true,
            'account' => $payload['account'],
            'worker' => $worker,
            'provider' => 'x',
        ]);
    }

    private static function prepare_instagram_media(int $post_id, string $site_origin): ?array {
        $candidates = [];
        $featured = get_the_post_thumbnail_url($post_id, 'full');
        if ($featured) {
            $candidates[] = ['url' => $featured];
        }
        $main = Fifu_Post_Main_Image_Resolver::get_main_image_url($post_id, true);
        if ($main) {
            $candidates[] = ['url' => $main];
        }
        foreach ($candidates as $candidate) {
            if (!isset($candidate['url']) || !is_string($candidate['url'])) {
                continue;
            }
            $normalized = Fifu_Auto_Share_Common::normalize_https_url(trim($candidate['url']));
            if (!$normalized) {
                continue;
            }
            return [
                'type' => 'image',
                'image_url' => $normalized,
                'imageUrl' => $normalized,
                'media_url' => $normalized,
                'mediaUrl' => $normalized,
                'url' => $normalized,
            ];
        }
        return null;
    }

    private static function normalize_client_id($value): string {
        if (!is_string($value)) {
            if (is_numeric($value)) {
                $value = (string) $value;
            } else {
                return '';
            }
        }
        $trimmed = trim($value);
        if ($trimmed === '') {
            return '';
        }
        return sanitize_text_field($trimmed);
    }

    private static function get_client_id(): string {
        $raw = get_option('fifu_auto_share_x_clientid');
        if (!is_string($raw) && !is_numeric($raw)) {
            return '';
        }
        return self::normalize_client_id((string) $raw);
    }

    private static function maybe_persist_refreshed_token(array $worker_response, $account_name_hint, array $pages_hint, int $user_id): bool {
        $token = self::find_refresh_token_array($worker_response);
        if (!$token) {
            return false;
        }
        $refresh_section = isset($worker_response['refresh']) && is_array($worker_response['refresh']) ? $worker_response['refresh'] : null;
        if ($refresh_section) {
            $refresh_ok = null;
            if (isset($refresh_section['ok'])) {
                $value = $refresh_section['ok'];
                if (is_bool($value)) {
                    $refresh_ok = $value;
                } else {
                    $refresh_ok = in_array(strtolower((string) $value), ['1', 'true', 'yes', 'ok', 'success'], true);
                }
            }
            if ($refresh_ok === false) {
                return false;
            }
        }
        $account_name = self::extract_account_name_from_worker($worker_response);
        if ($account_name === '' && is_string($account_name_hint)) {
            $account_name = $account_name_hint;
        }
        $pages = self::extract_accounts_from_worker($worker_response);
        if ($pages === null) {
            $pages = $pages_hint;
        }
        Fifu_Auto_Share_Common::store_connection('x', [
            'accountName' => $account_name,
            'pages' => $pages,
            'token' => $token,
            'connected' => true,
            'userId' => $user_id,
        ]);
        return true;
    }

    private static function find_refresh_token_array($data, int $depth = 0) {
        if ($depth > 6 || !is_array($data)) {
            return null;
        }
        if (isset($data['refresh_token']) && is_string($data['refresh_token'])) {
            $trimmed = trim($data['refresh_token']);
            if ($trimmed !== '') {
                return $data;
            }
        }
        foreach ($data as $value) {
            if (is_array($value)) {
                $found = self::find_refresh_token_array($value, $depth + 1);
                if ($found !== null) {
                    return $found;
                }
            }
        }
        return null;
    }

    private static function extract_account_name_from_worker(array $worker_response): string {
        if (isset($worker_response['accountName']) && is_string($worker_response['accountName'])) {
            $name = trim($worker_response['accountName']);
            if ($name !== '') {
                return $name;
            }
        }
        if (!empty($worker_response['account']) && is_array($worker_response['account'])) {
            $account = $worker_response['account'];
            foreach (['name', 'username', 'handle'] as $field) {
                if (!empty($account[$field]) && is_string($account[$field])) {
                    $candidate = trim($account[$field]);
                    if ($candidate !== '') {
                        return $candidate;
                    }
                }
            }
        }
        $accounts = self::extract_accounts_from_worker($worker_response);
        if (is_array($accounts) && !empty($accounts)) {
            $primary = $accounts[0];
            if (is_array($primary)) {
                foreach (['name', 'username', 'handle'] as $field) {
                    if (!empty($primary[$field]) && is_string($primary[$field])) {
                        $candidate = trim($primary[$field]);
                        if ($candidate !== '') {
                            return $candidate;
                        }
                    }
                }
            }
        }
        return '';
    }

    private static function extract_accounts_from_worker(array $worker_response): ?array {
        foreach (['accounts', 'pages', 'profiles', 'tenants'] as $key) {
            if (!empty($worker_response[$key]) && is_array($worker_response[$key])) {
                return array_values(array_filter($worker_response[$key], 'is_array'));
            }
        }
        if (!empty($worker_response['account']) && is_array($worker_response['account'])) {
            return [$worker_response['account']];
        }
        return null;
    }
}
