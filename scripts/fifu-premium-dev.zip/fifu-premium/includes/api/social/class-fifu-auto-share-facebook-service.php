<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

class Fifu_Auto_Share_Facebook_Service {

    public static function auth_start(\WP_REST_Request $request) {
        $body = Fifu_Auto_Share_Common::read_json($request);
        $payload = [
            'provider' => 'facebook',
            'site_id' => Fifu_Auto_Share_Common::get_site_id(),
            'user_id' => Fifu_Auto_Share_Common::get_user_id(),
            'intent' => $body['intent'] ?? 'login',
            'version' => Fifu_Auto_Share_Common::get_version(),
        ];
        $worker = Fifu_Auto_Share_Common::worker_request('POST', '/v2/oauth/facebook/start', $payload);
        if (is_wp_error($worker)) {
            return $worker;
        }
        return Fifu_Auto_Share_Common::json_response([
            'authUrl' => isset($worker['authUrl']) ? esc_url_raw($worker['authUrl']) : '',
            'state' => isset($worker['state']) ? sanitize_text_field($worker['state']) : '',
            'popupOrigin' => isset($worker['popupOrigin']) ? esc_url_raw($worker['popupOrigin']) : '',
        ]);
    }

    public static function auth_finalize(\WP_REST_Request $request) {
        $body = Fifu_Auto_Share_Common::read_json($request);
        $token = isset($body['tempToken']) ? sanitize_text_field($body['tempToken']) : '';
        $state = isset($body['state']) ? sanitize_text_field($body['state']) : '';
        $user_id = Fifu_Auto_Share_Common::get_user_id();
        if (!$token) {
            return new \WP_Error('fifu_as_bad_request', 'Missing tempToken', ['status' => 400]);
        }
        $payload = [
            'provider' => 'facebook',
            'site_id' => Fifu_Auto_Share_Common::get_site_id(),
            'user_id' => $user_id,
            'tempToken' => $token,
            'state' => $state,
            'version' => Fifu_Auto_Share_Common::get_version(),
        ];
        $worker = Fifu_Auto_Share_Common::worker_request('POST', '/v2/oauth/facebook/finalize', $payload);
        if (is_wp_error($worker)) {
            return $worker;
        }
        $raw_pages = Fifu_Auto_Share_Common::normalize_pages($worker['pages'] ?? []);
        $inferred_pages = empty($raw_pages)
            ? Fifu_Auto_Share_Common::extract_pages_from_granular_scopes($worker['granular_scopes'] ?? [])
            : [];
        $pages_to_store = !empty($raw_pages) ? $raw_pages : $inferred_pages;
        $store = [
            'accountName' => isset($worker['accountName']) ? (string) $worker['accountName'] : '',
            'pages' => Fifu_Auto_Share_Common::normalize_pages($pages_to_store),
            'token' => $worker['token'] ?? [],
            'userId' => $user_id,
        ];
        Fifu_Auto_Share_Common::store_connection('facebook', $store);
        return Fifu_Auto_Share_Common::json_response([
            'connected' => !empty($store['token']['access_token']),
            'accountName' => $store['accountName'],
            'pages' => Fifu_Auto_Share_Common::normalize_pages($store['pages']),
        ]);
    }

    public static function status(\WP_REST_Request $request) {
        return Fifu_Auto_Share_Common::json_response(Fifu_Auto_Share_Common::get_status_snapshot('facebook'));
    }

    public static function disconnect(\WP_REST_Request $request) {
        Fifu_Auto_Share_Common::clear_connection('facebook');
        return Fifu_Auto_Share_Common::json_response([
            'connected' => false,
            'accountName' => null,
            'pages' => [],
        ]);
    }

    public static function share_post(\WP_REST_Request $request) {
        $body = Fifu_Auto_Share_Common::read_json($request);
        $post_id = isset($body['postId']) ? absint($body['postId']) : 0;
        if (!$post_id && isset($body['post_id'])) {
            $post_id = absint($body['post_id']);
        }
        if (!$post_id) {
            return new \WP_Error('fifu_as_missing_post', 'Post ID is required', ['status' => 400]);
        }
        $post_payload = Fifu_Auto_Share_Common::build_post_share_payload($post_id);
        if (!$post_payload) {
            return new \WP_Error('fifu_as_post_not_found', 'Post not found', ['status' => 404]);
        }
        $connection = Fifu_Auto_Share_Common::get_connection_details('facebook');
        if (empty($connection['connected'])) {
            return new \WP_Error('fifu_as_facebook_not_connected', 'Facebook connection required', ['status' => 409]);
        }
        if (Fifu_Auto_Share_Service::has_shared_on_provider($post_id, 'facebook')) {
            return Fifu_Auto_Share_Common::json_response([
                'ok' => true,
                'already_shared' => true,
                'provider' => 'facebook',
            ]);
        }
        $requested_page_id = '';
        if (!empty($body['pageId'])) {
            $requested_page_id = sanitize_text_field((string) $body['pageId']);
        } elseif (!empty($body['page_id'])) {
            $requested_page_id = sanitize_text_field((string) $body['page_id']);
        }
        $token_pages_raw = isset($connection['token']['pages']) ? Fifu_Auto_Share_Common::normalize_pages($connection['token']['pages']) : [];
        $token_page_raw = [];
        if (!empty($connection['token']['page']) && is_array($connection['token']['page'])) {
            $token_page_raw = Fifu_Auto_Share_Common::normalize_pages([$connection['token']['page']]);
        }
        $selected_page = null;
        foreach ($connection['pages'] as $page) {
            if (!empty($requested_page_id) && isset($page['id']) && (string) $page['id'] === $requested_page_id) {
                $selected_page = $page;
                break;
            }
            if (!$selected_page && !empty($page['connected'])) {
                $selected_page = $page;
            }
        }
        if (!$selected_page && !empty($connection['pages'])) {
            $selected_page = $connection['pages'][0];
        }
        if (!$selected_page && !empty($token_pages_raw)) {
            $selected_page = $token_pages_raw[0];
        }
        if (!$selected_page && !empty($token_page_raw)) {
            $selected_page = $token_page_raw[0];
        }
        $tokenPageId = '';
        foreach (['page_id', 'pageId', 'page', 'id'] as $tokenKey) {
            if (!empty($connection['token'][$tokenKey]) && !is_array($connection['token'][$tokenKey])) {
                $tokenPageId = sanitize_text_field((string) $connection['token'][$tokenKey]);
                break;
            }
        }
        if (!$selected_page || empty($selected_page['id'])) {
            if ($tokenPageId !== '') {
                $selected_page = [
                    'id' => $tokenPageId,
                    'name' => $connection['accountName'] ?: '',
                    'connected' => true,
                ];
            }
        }
        $token_pages_payload = array_values(array_filter(array_map(static function ($page) {
            if (empty($page['page_access_token']) || empty($page['id'])) {
                return null;
            }
            return [
                'page_id' => (string) $page['id'],
                'page_access_token' => (string) $page['page_access_token'],
            ];
        }, $token_pages_raw)));
        if (!empty($token_page_raw)) {
            $tp = $token_page_raw[0];
            if (!empty($tp['page_access_token']) && !empty($tp['id'])) {
                $candidate = [
                    'page_id' => (string) $tp['id'],
                    'page_access_token' => (string) $tp['page_access_token'],
                ];
                $exists = false;
                foreach ($token_pages_payload as $entry) {
                    if ($entry['page_id'] === $candidate['page_id']) {
                        $exists = true;
                        break;
                    }
                }
                if (!$exists) {
                    $token_pages_payload[] = $candidate;
                }
            }
        }
        $selected_page_token = '';
        if ($selected_page) {
            foreach (['page_access_token', 'access_token', 'token', 'page_token'] as $field) {
                if (!empty($selected_page[$field]) && is_string($selected_page[$field])) {
                    $candidate_token = sanitize_text_field($selected_page[$field]);
                    if ($candidate_token !== '') {
                        $selected_page_token = $candidate_token;
                        break;
                    }
                }
            }
            if ($selected_page_token === '' && !empty($token_pages_payload)) {
                foreach ($token_pages_payload as $entry) {
                    if ($entry['page_id'] === (string) $selected_page['id']) {
                        $selected_page_token = (string) $entry['page_access_token'];
                        break;
                    }
                }
            }
            if ($selected_page_token === '' && isset($connection['token']['page_access_token'])) {
                $candidate_token = sanitize_text_field((string) $connection['token']['page_access_token']);
                if ($candidate_token !== '') {
                    $selected_page_token = $candidate_token;
                }
            }
        }
        if ($selected_page_token !== '' && $selected_page && !empty($selected_page['id'])) {
            $has_entry = false;
            foreach ($token_pages_payload as $entry) {
                if ($entry['page_id'] === (string) $selected_page['id']) {
                    $has_entry = true;
                    break;
                }
            }
            if (!$has_entry) {
                $token_pages_payload[] = [
                    'page_id' => (string) $selected_page['id'],
                    'page_access_token' => $selected_page_token,
                ];
            }
        }
        if (!$selected_page || empty($selected_page['id'])) {
            return new \WP_Error('fifu_as_facebook_page_missing', 'No Facebook page available', ['status' => 409]);
        }
        $message = '';
        foreach (['message', 'caption', 'text'] as $msg_key) {
            if (!empty($body[$msg_key]) && is_string($body[$msg_key])) {
                $message = wp_strip_all_tags((string) $body[$msg_key]);
                break;
            }
        }
        if ($message) {
            $message = trim(preg_replace('/\s+/', ' ', $message));
            if (function_exists('mb_substr')) {
                $message = mb_substr($message, 0, 5000);
            } else {
                $message = substr($message, 0, 5000);
            }
        }
        $site_origin = set_url_scheme(home_url('/'), 'https');
        $site_origin = rtrim($site_origin, '/');
        if (parse_url($site_origin, PHP_URL_SCHEME) !== 'https') {
            return new \WP_Error('fifu_as_site_not_https', 'Facebook sharing requires the site to be served over HTTPS', ['status' => 409]);
        }
        $permalink = get_permalink($post_id);
        $link = $permalink ? set_url_scheme($permalink, 'https') : '';
        $payload = [
            'provider' => 'facebook',
            'site_id' => Fifu_Auto_Share_Common::get_site_id(),
            'user_id' => Fifu_Auto_Share_Common::get_user_id(),
            'version' => Fifu_Auto_Share_Common::get_version(),
            'postId' => $post_id,
            'post' => $post_payload,
            'page' => [
                'id' => (string) $selected_page['id'],
                'name' => isset($selected_page['name']) ? (string) $selected_page['name'] : '',
            ],
            'token' => $connection['token'],
            'requestedBy' => [
                'user_id' => get_current_user_id(),
                'timestamp' => gmdate('c', current_time('timestamp', true)),
            ],
        ];
        if ($selected_page_token !== '') {
            $payload['page']['page_access_token'] = $selected_page_token;
            $payload['page']['access_token'] = $selected_page_token;
        }
        if (!empty($token_pages_payload)) {
            $payload['token_pages'] = $token_pages_payload;
            foreach ($token_pages_payload as $entry) {
                if ($entry['page_id'] === (string) $selected_page['id']) {
                    $payload['token_page'] = $entry;
                    break;
                }
            }
            if (!isset($payload['token_page'])) {
                $payload['token_page'] = $token_pages_payload[0];
            }
        }
        if ($message) {
            $payload['message'] = $message;
        }
        if ($link) {
            $payload['link'] = $link;
        }
        if (method_exists('Fifu_Image_Url_Utils', 'get_home_url_no_scheme')) {
            $payload['site'] = Fifu_Image_Url_Utils::get_home_url_no_scheme();
        }
        $payload['site_origin'] = $site_origin;
        $payload['partial_key'] = Fifu_Options_Utils::partial_key();
        $worker = Fifu_Auto_Share_Common::worker_request('POST', '/share/facebook', $payload);
        if (is_wp_error($worker)) {
            $extra = [
                'ERROR' => $worker->get_error_message(),
            ];
            $code = $worker->get_error_code();
            if ($code) {
                $extra['ERROR_CODE'] = $code;
            }
            Fifu_Auto_Share_Service::append_log_entry($post_id, 'facebook', 'error', $extra);
            return $worker;
        }
        $assessment = Fifu_Auto_Share_Service::assess_worker_response('facebook', $worker);
        $log_extra = [
            'RESPONSE' => $assessment['normalized'],
        ];
        if ($assessment['error'] instanceof \WP_Error) {
            $log_extra['ERROR'] = $assessment['error']->get_error_message();
            Fifu_Auto_Share_Service::append_log_entry($post_id, 'facebook', 'error', $log_extra);
            return $assessment['error'];
        }
        Fifu_Auto_Share_Service::append_log_entry($post_id, 'facebook', 'success', $log_extra);
        Fifu_Auto_Share_Service::mark_shared_on_provider($post_id, 'facebook');
        return Fifu_Auto_Share_Common::json_response([
            'ok' => true,
            'page' => $payload['page'],
            'worker' => $worker,
            'provider' => 'facebook',
        ]);
    }
}
