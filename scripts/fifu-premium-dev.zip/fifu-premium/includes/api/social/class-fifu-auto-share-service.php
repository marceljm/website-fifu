<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}


class Fifu_Auto_Share_Service {

    private const PROVIDER_ID_MAP = [
        'facebook' => 1,
        'instagram' => 2,
        'x' => 3,
        'twitter' => 3,
    ];

    private const LOG_META_KEY = 'fifu_auto_share_log';
    private const SHARED_META_KEY = 'fifu_shared_on';
    private const AUTO_SHARE_HOOK = 'fifu_as_run_auto_share';

    public static function init(): void {
        add_action('save_post', [self::class, 'handle_save_post'], 999, 3);
        add_action(self::AUTO_SHARE_HOOK, [self::class, 'handle_auto_share_execute'], 10, 1);
    }

    public static function handle_save_post($post_id, $post, $update): void {
        $post_id = is_numeric($post_id) ? (int) $post_id : 0;
        if ($post_id <= 0) {
            return;
        }
        if (
            class_exists('Fifu_Wai_Addon_Integration')
            && method_exists('Fifu_Wai_Addon_Integration', 'should_suppress_generic_post_save_media_sync')
            && Fifu_Wai_Addon_Integration::should_suppress_generic_post_save_media_sync((int) $post_id)
        ) {
            return;
        }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        if (wp_is_post_autosave($post_id) || wp_is_post_revision($post_id)) {
            return;
        }
        if (!($post instanceof WP_Post)) {
            $post = get_post($post_id);
            if (!($post instanceof WP_Post)) {
                return;
            }
        }
        if ($post->post_type !== 'post') {
            return;
        }
        if ($post->post_status !== 'publish') {
            return;
        }
        $prepared_post = self::get_post_ready_for_auto_share($post_id, $post);
        if (!($prepared_post instanceof WP_Post)) {
            return;
        }
        static $processed = [];
        if (isset($processed[$post_id])) {
            return;
        }
        $processed[$post_id] = true;
        if (!wp_next_scheduled(self::AUTO_SHARE_HOOK, [$post_id])) {
            wp_schedule_single_event(time() + 5, self::AUTO_SHARE_HOOK, [$post_id]);
        }
    }

    public static function get_post_ready_for_auto_share(int $post_id, ?WP_Post $post = null): ?WP_Post {
        if ($post_id <= 0) {
            return null;
        }
        if (!($post instanceof WP_Post)) {
            $post = get_post($post_id);
            if (!($post instanceof WP_Post)) {
                return null;
            }
        }
        if ($post->post_type !== 'post') {
            return null;
        }
        if ($post->post_status !== 'publish') {
            return null;
        }
        if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) {
            return null;
        }
        if (!self::post_has_shareable_media($post_id)) {
            return null;
        }
        if (!class_exists('WP_REST_Request')) {
            return null;
        }
        return $post;
    }

    public static function handle_auto_share_execute(int $post_id): void {
        if (Fifu_Options_Utils::is_off('fifu_auto_share')) {
            return;
        }
        $post = self::get_post_ready_for_auto_share($post_id);
        if (!($post instanceof WP_Post)) {
            return;
        }
        $post_id = (int) $post->ID;
        $providers = [
            'facebook' => [Fifu_Auto_Share_Facebook_Service::class, 'share_post'],
            'instagram' => [Fifu_Auto_Share_Instagram_Service::class, 'share_post'],
            'x' => [Fifu_Auto_Share_X_Service::class, 'share_post'],
        ];
        foreach ($providers as $provider => $callback) {
            if (Fifu_Options_Utils::is_off('fifu_auto_share_' . $provider)) {
                continue;
            }
            $connection = Fifu_Auto_Share_Common::get_connection_details($provider);
            if (empty($connection['connected'])) {
                continue;
            }
            if (self::has_shared_on_provider($post_id, $provider)) {
                continue;
            }
            $request = new WP_REST_Request('POST', '/fifu-premium/v2/share/' . $provider);
            $request->set_body(wp_json_encode([
                'postId' => $post_id,
                'post_id' => $post_id,
            ]));
            $request->set_header('Content-Type', 'application/json');
            $result = call_user_func($callback, $request);
            if (is_wp_error($result)) {
                continue;
            }
        }
    }

    public static function provider_to_id(string $provider): int {
        $provider = self::normalize_provider($provider);
        return self::PROVIDER_ID_MAP[$provider] ?? 0;
    }

    private static function normalize_provider(string $provider): string {
        $provider = strtolower(trim((string) $provider));
        if ($provider === 'twitter') {
            return 'x';
        }
        return $provider;
    }

    public static function get_shared_on_state(int $post_id): array {
        $post_id = (int) $post_id;
        $current_slug = self::get_post_slug($post_id);
        $current_permalink = self::get_post_permalink($post_id);
        if ($post_id <= 0) {
            return ['slug' => $current_slug, 'permalink' => $current_permalink, 'ids' => []];
        }
        $raw = get_post_meta($post_id, self::SHARED_META_KEY, true);
        if ($raw === '' || $raw === null) {
            return ['slug' => $current_slug, 'permalink' => $current_permalink, 'ids' => []];
        }
        $stored_slug = '';
        $stored_permalink = '';
        $ids = [];
        if (is_array($raw)) {
            $stored_slug = isset($raw['slug']) ? (string) $raw['slug'] : '';
            $stored_permalink = isset($raw['permalink']) ? (string) $raw['permalink'] : '';
            $ids = self::parse_shared_ids(isset($raw['ids']) ? $raw['ids'] : []);
        } else {
            $raw = trim((string) $raw);
            if ($raw !== '' && strpos($raw, ':') !== false) {
                list($maybe_slug, $list) = explode(':', $raw, 2);
                $stored_slug = (string) $maybe_slug;
                $ids = self::parse_shared_ids($list);
            } else {
                $ids = self::parse_shared_ids($raw);
            }
        }
        if (function_exists('sanitize_title')) {
            $stored_slug = sanitize_title($stored_slug);
        } else {
            $stored_slug = trim($stored_slug);
        }
        $stored_permalink = trim($stored_permalink);
        if ($stored_permalink !== '') {
            if ($current_permalink !== '' && $stored_permalink !== $current_permalink) {
                delete_post_meta($post_id, self::SHARED_META_KEY);
                return ['slug' => $current_slug, 'permalink' => $current_permalink, 'ids' => []];
            }
            return [
                'slug' => $current_slug !== '' ? $current_slug : $stored_slug,
                'permalink' => $current_permalink !== '' ? $current_permalink : $stored_permalink,
                'ids' => array_values(array_unique(array_map('intval', $ids))),
            ];
        }
        if ($stored_slug !== '' && $current_slug !== '' && $stored_slug !== $current_slug) {
            delete_post_meta($post_id, self::SHARED_META_KEY);
            return ['slug' => $current_slug, 'permalink' => $current_permalink, 'ids' => []];
        }
        if ($stored_slug === '') {
            $stored_slug = $current_slug;
        }
        return [
            'slug' => $current_slug !== '' ? $current_slug : $stored_slug,
            'permalink' => $current_permalink !== '' ? $current_permalink : $stored_permalink,
            'ids' => array_values(array_unique(array_map('intval', $ids))),
        ];
    }

    public static function store_shared_on_state(int $post_id, array $state): bool {
        $post_id = (int) $post_id;
        if ($post_id <= 0) {
            return false;
        }
        $slug = isset($state['slug']) ? (string) $state['slug'] : '';
        $permalink = isset($state['permalink']) ? (string) $state['permalink'] : '';
        $ids = isset($state['ids']) ? $state['ids'] : [];
        if (function_exists('sanitize_title')) {
            $slug = sanitize_title($slug);
        } else {
            $slug = trim($slug);
        }
        if ($slug === '') {
            $slug = self::get_post_slug($post_id);
        }
        if (trim($permalink) === '') {
            $permalink = self::get_post_permalink($post_id);
        } else {
            $permalink = trim($permalink);
        }
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids), fn ($value) => $value > 0)));
        if ($ids === []) {
            delete_post_meta($post_id, self::SHARED_META_KEY);
            return true;
        }
        update_post_meta($post_id, self::SHARED_META_KEY, [
            'slug' => $slug,
            'permalink' => $permalink,
            'ids' => $ids,
        ]);
        return true;
    }

    public static function get_shared_on_ids(int $post_id): array {
        $state = self::get_shared_on_state($post_id);
        return $state['ids'];
    }

    public static function has_shared_on_provider(int $post_id, string $provider): bool {
        $provider_id = self::provider_to_id($provider);
        if ($provider_id <= 0) {
            return false;
        }
        $ids = self::get_shared_on_ids($post_id);
        return in_array($provider_id, $ids, true);
    }

    public static function mark_shared_on_provider(int $post_id, string $provider): bool {
        $post_id = (int) $post_id;
        if ($post_id <= 0) {
            return false;
        }
        $provider_id = self::provider_to_id($provider);
        if ($provider_id <= 0) {
            return false;
        }
        $state = self::get_shared_on_state($post_id);
        if (in_array($provider_id, $state['ids'], true)) {
            return true;
        }
        $state['ids'][] = $provider_id;
        return self::store_shared_on_state($post_id, $state);
    }

    private static function get_post_slug(int $post_id): string {
        $post_id = (int) $post_id;
        if ($post_id <= 0) {
            return '';
        }
        $slug = (string) get_post_field('post_name', $post_id);
        if (function_exists('sanitize_title')) {
            $slug = sanitize_title($slug);
        } else {
            $slug = trim($slug);
        }
        if ($slug === '') {
            $slug = 'post-' . $post_id;
        }
        return $slug;
    }

    private static function get_post_permalink(int $post_id): string {
        $post_id = (int) $post_id;
        if ($post_id <= 0) {
            return '';
        }
        $permalink = get_permalink($post_id);
        return is_string($permalink) ? trim($permalink) : '';
    }

    private static function parse_shared_ids($value): array {
        $ids = [];
        if (is_array($value)) {
            foreach ($value as $item) {
                if (!is_numeric($item)) {
                    continue;
                }
                $id = (int) $item;
                if ($id > 0) {
                    $ids[$id] = $id;
                }
            }
            return array_values($ids);
        }
        $parts = preg_split('/[^0-9]+/', (string) $value);
        if (!is_array($parts)) {
            return [];
        }
        foreach ($parts as $part) {
            if ($part === '') {
                continue;
            }
            $id = (int) $part;
            if ($id > 0) {
                $ids[$id] = $id;
            }
        }
        return array_values($ids);
    }

    public static function post_has_shareable_media(int $post_id): bool {
        if (has_post_thumbnail($post_id)) {
            return true;
        }
        $main_url = Fifu_Post_Main_Image_Resolver::get_main_image_url($post_id, true);
        if (is_string($main_url) && trim($main_url) !== '') {
            return true;
        }
        $urls = Fifu_Post_Image_Urls::get_all($post_id);
        if (is_array($urls)) {
            foreach ($urls as $url) {
                if (is_string($url) && trim($url) !== '') {
                    return true;
                }
            }
        }
        $meta_url = Fifu_Post_Image_Url_Read_Service::get_image_url((int) $post_id);
        if (is_string($meta_url) && trim($meta_url) !== '') {
            return true;
        }
        return false;
    }

    public static function normalize_log_value($value, int $depth = 0) {
        if ($depth > 6) {
            return '[depth-exceeded]';
        }
        if (is_string($value)) {
            $trimmed = trim($value);
            if ($trimmed !== '' && in_array($trimmed[0], ['{', '['], true)) {
                $decoded = json_decode($trimmed, true);
                if (json_last_error() === JSON_ERROR_NONE) {
                    return self::normalize_log_value($decoded, $depth + 1);
                }
            }
            return $value;
        }
        if (is_null($value) || is_bool($value) || is_numeric($value)) {
            return $value;
        }
        if ($value instanceof WP_Error) {
            $data = $value->get_error_data();
            return [
                'code' => $value->get_error_code(),
                'message' => $value->get_error_message(),
                'data' => self::normalize_log_value($data, $depth + 1),
            ];
        }
        if ($value instanceof JsonSerializable) {
            return self::normalize_log_value($value->jsonSerialize(), $depth + 1);
        }
        if ($value instanceof Traversable) {
            $normalized = [];
            foreach ($value as $k => $v) {
                $normalized[$k] = self::normalize_log_value($v, $depth + 1);
            }
            return $normalized;
        }
        if (is_array($value)) {
            $normalized = [];
            foreach ($value as $k => $v) {
                $normalized[$k] = self::normalize_log_value($v, $depth + 1);
            }
            return $normalized;
        }
        if (is_object($value)) {
            if (method_exists($value, 'toArray')) {
                return self::normalize_log_value($value->toArray(), $depth + 1);
            }
            if (method_exists($value, 'to_array')) {
                return self::normalize_log_value($value->to_array(), $depth + 1);
            }
            if (method_exists($value, '__toString')) {
                return (string) $value;
            }
            $vars = get_object_vars($value);
            if (!empty($vars)) {
                return self::normalize_log_value($vars, $depth + 1);
            }
            $encoded = function_exists('wp_json_encode')
                ? wp_json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR)
                : json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR);
            if (is_string($encoded)) {
                $decoded = json_decode($encoded, true);
                if (is_array($decoded)) {
                    return self::normalize_log_value($decoded, $depth + 1);
                }
                return $encoded;
            }
            return sprintf('[object %s]', get_class($value));
        }
        return function_exists('wp_json_encode')
            ? wp_json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR)
            : json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR);
    }

    public static function assess_worker_response(string $provider, $worker): array {
        $normalized = self::normalize_log_value($worker);
        if (!is_array($normalized)) {
            $error = new \WP_Error(
                'fifu_as_publish_invalid',
                sprintf('Unexpected response from %s worker.', ucfirst($provider)),
                [
                    'status' => 502,
                    'provider' => $provider,
                    'worker_response' => $normalized,
                ]
            );
            return [
                'normalized' => $normalized,
                'error' => $error,
            ];
        }
        $status_flag = '';
        if (isset($normalized['status']) && is_string($normalized['status'])) {
            $status_flag = strtolower($normalized['status']);
        }
        $publish = [];
        if (isset($normalized['publish']) && is_array($normalized['publish'])) {
            $publish = $normalized['publish'];
        }
        $failed = false;
        if (in_array($status_flag, ['error', 'fail', 'failed'], true)) {
            $failed = true;
        }
        if (!$failed && isset($normalized['error_code']) && $normalized['error_code']) {
            $failed = true;
        }
        if (!$failed && $publish) {
            if (array_key_exists('ok', $publish) && $publish['ok'] === false) {
                $failed = true;
            }
            if (!$failed && isset($publish['status']) && is_numeric($publish['status']) && (int) $publish['status'] >= 400) {
                $failed = true;
            }
            if (!$failed && isset($publish['error_code']) && $publish['error_code']) {
                $failed = true;
            }
            if (!$failed && isset($publish['stage']) && in_array(strtolower((string) $publish['stage']), ['error', 'fail', 'failed'], true)) {
                $failed = true;
            }
        }
        if (!$failed) {
            return [
                'normalized' => $normalized,
                'error' => null,
            ];
        }
        $message = self::extract_worker_error_message($normalized);
        if ($message === '') {
            $message = sprintf('Failed to share on %s.', ucfirst($provider));
        }
        $status_code = 409;
        if ($publish && isset($publish['status']) && is_numeric($publish['status'])) {
            $status_code = max(400, (int) $publish['status']);
        } elseif (isset($normalized['status_code']) && is_numeric($normalized['status_code'])) {
            $status_code = max(400, (int) $normalized['status_code']);
        }
        $error = new \WP_Error(
            'fifu_as_publish_failed',
            $message,
            [
                'status' => $status_code,
                'provider' => $provider,
                'worker_response' => $normalized,
            ]
        );
        return [
            'normalized' => $normalized,
            'error' => $error,
        ];
    }

    public static function extract_worker_error_message(array $data): string {
        $queue = [$data];
        $message_keys = [
            'error_user_msg',
            'error_message',
            'message',
            'detail',
            'description',
            'reason',
            'error',
            'body',
        ];
        while (!empty($queue)) {
            $current = array_shift($queue);
            if (!is_array($current)) {
                continue;
            }
            foreach ($message_keys as $key) {
                if (!array_key_exists($key, $current)) {
                    continue;
                }
                $value = $current[$key];
                if (is_string($value)) {
                    $trimmed = trim($value);
                    if ($trimmed !== '') {
                        return $trimmed;
                    }
                    continue;
                }
                if (is_array($value)) {
                    $queue[] = $value;
                }
            }
            foreach ($current as $value) {
                if (is_array($value)) {
                    $queue[] = $value;
                }
            }
        }
        return '';
    }

    public static function append_log_entry(int $post_id, string $provider, string $status, array $data = [], string $link = ''): void {
        $entries = get_post_meta($post_id, self::LOG_META_KEY, true);
        if (!is_array($entries)) {
            $entries = [];
        }
        $entries[] = [
            'timestamp' => time(),
            'provider' => $provider,
            'status' => $status,
            'link' => $link,
            'data' => self::normalize_log_value($data),
        ];
        update_post_meta($post_id, self::LOG_META_KEY, $entries);
    }

    public static function get_log_entries(int $post_id, string $provider = ''): array {
        $entries = get_post_meta($post_id, self::LOG_META_KEY, true);
        if (!is_array($entries)) {
            return [];
        }
        if ($provider === '') {
            return $entries;
        }
        $provider = self::normalize_provider($provider);
        return array_values(array_filter($entries, static function ($entry) use ($provider) {
            return isset($entry['provider']) && $entry['provider'] === $provider;
        }));
    }
}

Fifu_Auto_Share_Service::init();
