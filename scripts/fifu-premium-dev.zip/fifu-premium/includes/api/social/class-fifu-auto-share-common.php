<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

class Fifu_Auto_Share_Common {

    public static function can_manage(\WP_REST_Request $request): bool {
        $nonce = $request->get_header('x-wp-nonce');
        return current_user_can('manage_options') && wp_verify_nonce($nonce, 'wp_rest');
    }

    public static function json_response(array $data, int $status = 200): \WP_REST_Response {
        return new \WP_REST_Response($data, $status, [
            'Content-Type' => 'application/json; charset=utf-8',
        ]);
    }

    public static function read_json(\WP_REST_Request $request): array {
        $raw = $request->get_body();
        if (!$raw) {
            return [];
        }
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }

    public static function get_site_id(): string {
        if (is_multisite()) {
            $network = get_network();
            if ($network) {
                return $network->id . ':' . get_current_blog_id();
            }
        }
        $host = (string) parse_url(home_url(), PHP_URL_HOST);
        return $host !== '' ? $host : '';
    }

    public static function get_user_id(): int {
        $user_id = get_current_user_id();
        return $user_id ? (int) $user_id : 0;
    }

    public static function get_version(): string {
        $version = Fifu_Plugin_Info::get_version();
        return $version ? $version : 'dev';
    }

    public static function get_worker_base_url(): string {
        return 'https://auto-share.fifu.workers.dev';
    }

    public static function worker_request(string $method, string $path, array $payload = []): array|\WP_Error {
        $base = rtrim(self::get_worker_base_url(), '/') . '/' . ltrim($path, '/');
        $query = [
            'site' => method_exists('Fifu_Image_Url_Utils', 'get_home_url_no_scheme')
                ? Fifu_Image_Url_Utils::get_home_url_no_scheme()
                : home_url(),
            'partial_key' => Fifu_Options_Utils::partial_key(),
        ];
        $url = add_query_arg($query, $base);
        $args = [
            'method' => strtoupper($method),
            'timeout' => 20,
            'headers' => [
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
                'X-FIFU-Site' => self::get_site_id(),
                'X-FIFU-User' => (string) self::get_user_id(),
                'X-FIFU-Version' => self::get_version(),
            ],
            'body' => $payload ? wp_json_encode($payload) : null,
        ];
        $res = wp_remote_request($url, $args);
        if (is_wp_error($res)) {
            return new \WP_Error('fifu_worker_http', $res->get_error_message(), ['status' => 502]);
        }
        $code = (int) wp_remote_retrieve_response_code($res);
        $body = (string) wp_remote_retrieve_body($res);
        $json = json_decode($body, true);
        if ($code >= 400) {
            return new \WP_Error('fifu_worker_bad_status', "Worker HTTP $code", ['status' => 502, 'body' => $body]);
        }
        return is_array($json) ? $json : [];
    }

    private static function meta_key(string $provider, string $suffix): string {
        return 'fifu_as_' . sanitize_key($provider) . '_' . sanitize_key($suffix);
    }

    private static function option_key(string $provider, string $suffix): string {
        return 'fifu_as_' . sanitize_key($provider) . '_' . sanitize_key($suffix);
    }

    private static function resolve_connection_user_id(array $data): int {
        $uid = self::get_user_id();
        if ($uid > 0) {
            return $uid;
        }

        foreach (['userId', 'user_id'] as $key) {
            if (!isset($data[$key])) {
                continue;
            }

            $candidate = is_numeric($data[$key]) ? absint($data[$key]) : 0;
            if ($candidate > 0) {
                return $candidate;
            }
        }

        return 0;
    }

    private static function has_global_connection_storage(string $provider): bool {
        $keys = ['account', 'pages', 'token', 'connected', 'updated'];
        foreach ($keys as $suffix) {
            $value = get_option(self::option_key($provider, $suffix), null);
            if ($value !== null && $value !== '' && $value !== []) {
                return true;
            }
        }
        return false;
    }

    public static function store_connection(string $provider, array $data): void {
        $uid = self::resolve_connection_user_id($data);
        $account = sanitize_text_field($data['accountName'] ?? '');
        $pages = self::normalize_pages($data['pages'] ?? []);
        $token = self::normalize_token($data['token'] ?? []);
        $connected = isset($data['connected']) ? (bool) $data['connected'] : false;
        if (!$connected && (self::token_has_credential($token) || self::pages_have_credentials($pages))) {
            $connected = true;
        }
        update_option(self::option_key($provider, 'account'), $account, false);
        update_option(self::option_key($provider, 'pages'), wp_json_encode($pages), false);
        update_option(self::option_key($provider, 'token'), wp_json_encode($token), false);
        update_option(self::option_key($provider, 'connected'), $connected ? 1 : 0, false);
        update_option(self::option_key($provider, 'updated'), time(), false);
        if ($uid > 0) {
            update_user_meta($uid, self::meta_key($provider, 'account'), $account);
            update_user_meta($uid, self::meta_key($provider, 'pages'), wp_json_encode($pages));
            update_user_meta($uid, self::meta_key($provider, 'token'), wp_json_encode($token));
            update_user_meta($uid, self::meta_key($provider, 'connected'), $connected ? 1 : 0);
            update_user_meta($uid, self::meta_key($provider, 'updated'), time());
        }
    }

    public static function clear_connection(string $provider): void {
        $uid = self::get_user_id();
        delete_option(self::option_key($provider, 'account'));
        delete_option(self::option_key($provider, 'pages'));
        delete_option(self::option_key($provider, 'token'));
        delete_option(self::option_key($provider, 'connected'));
        delete_option(self::option_key($provider, 'updated'));
        delete_user_meta($uid, self::meta_key($provider, 'account'));
        delete_user_meta($uid, self::meta_key($provider, 'pages'));
        delete_user_meta($uid, self::meta_key($provider, 'token'));
        delete_user_meta($uid, self::meta_key($provider, 'connected'));
        delete_user_meta($uid, self::meta_key($provider, 'updated'));
    }

    public static function get_status_snapshot(string $provider): array {
        $uid = self::get_user_id();
        if (self::has_global_connection_storage($provider)) {
            $account = (string) get_option(self::option_key($provider, 'account'), '');
            $pages = json_decode((string) get_option(self::option_key($provider, 'pages'), ''), true) ?: [];
            $tok_raw = json_decode((string) get_option(self::option_key($provider, 'token'), ''), true) ?: [];
            $stored_connected_raw = get_option(self::option_key($provider, 'connected'), null);
            $upd = (int) get_option(self::option_key($provider, 'updated'), 0);
        } else {
            $account = (string) get_user_meta($uid, self::meta_key($provider, 'account'), true);
            $pages = json_decode((string) get_user_meta($uid, self::meta_key($provider, 'pages'), true), true) ?: [];
            $tok_raw = json_decode((string) get_user_meta($uid, self::meta_key($provider, 'token'), true), true) ?: [];
            $stored_connected_raw = get_user_meta($uid, self::meta_key($provider, 'connected'), true);
            $upd = (int) get_user_meta($uid, self::meta_key($provider, 'updated'), true);
        }
        $stored_connected = $stored_connected_raw !== '' && $stored_connected_raw !== null && $stored_connected_raw !== '0' && $stored_connected_raw !== 0;
        $normalized_pages = self::normalize_pages($pages);
        $tok = self::normalize_token($tok_raw);
        $connected = self::token_has_credential($tok);
        if (!$connected && self::pages_have_credentials($normalized_pages)) {
            $connected = true;
        }
        if (!$connected && $stored_connected) {
            $connected = true;
        }
        if (!$connected && $account) {
            $connected = true;
        }
        return [
            'connected' => $connected,
            'accountName' => $account ?: null,
            'pages' => array_values(array_map(function ($p) {
                return [
                    'id' => isset($p['id']) ? (string) $p['id'] : null,
                    'name' => isset($p['name']) ? (string) $p['name'] : null,
                    'connected' => !empty($p['connected']),
                ];
            }, $normalized_pages)),
            'lastChecked' => $upd ?: time(),
        ];
    }

    public static function normalize_pages($pages): array {
        if (!is_array($pages)) {
            return [];
        }
        if (isset($pages['data']) && is_array($pages['data'])) {
            $pages = $pages['data'];
        } elseif (isset($pages['pages']) && is_array($pages['pages'])) {
            $pages = $pages['pages'];
        }
        if (isset($pages['page']) && is_array($pages['page'])) {
            $pages = [$pages['page']];
        }
        $is_numeric_indexed = !empty($pages) && array_keys($pages) === range(0, count($pages) - 1);
        if (!$is_numeric_indexed && (isset($pages['id']) || isset($pages['page_id']) || isset($pages['pageId']))) {
            $pages = [$pages];
        }
        $normalized = [];
        foreach ($pages as $page) {
            if (!is_array($page)) {
                continue;
            }
            if (isset($page['page']) && is_array($page['page'])) {
                $page = array_merge($page, $page['page']);
            }
            $structures = self::collect_nested_arrays($page);
            $id = self::find_first_value_in_nested($structures, [
                'id',
                'page_id',
                'pageId',
                'ig_user_id',
                'igUserId',
                'instagram_user_id',
                'instagramUserId',
                'instagram_business_account_id',
                'instagramBusinessAccountId',
                'instagram_id',
                'instagramId',
                'user_id',
                'account_id',
                'profile_id',
            ]);
            $ig_user_id_value = self::find_first_value_in_nested($structures, [
                'ig_user_id',
                'igUserId',
                'instagram_user_id',
                'instagramUserId',
                'instagram_id',
                'instagramId',
                'user_id',
                'profile_id',
            ]);
            $instagram_business_account_id = self::find_first_value_in_nested($structures, [
                'instagram_business_account_id',
                'instagramBusinessAccountId',
                'business_account_id',
                'businessAccountId',
                'instagram_business_id',
                'instagramBusinessId',
                'instagram_busines_account_id',
            ]);
            if ($id === '' && $instagram_business_account_id !== '') {
                $id = $instagram_business_account_id;
            }
            if ($id === '' && $ig_user_id_value !== '') {
                $id = $ig_user_id_value;
            }
            $name = self::find_first_value_in_nested($structures, [
                'name',
                'page_name',
                'pageName',
                'account_name',
                'accountName',
                'title',
                'username',
                'instagram_username',
                'instagramUsername',
                'handle',
            ]);
            $username = self::find_first_value_in_nested($structures, [
                'username',
                'instagram_username',
                'instagramUsername',
                'handle',
            ]);
            $connected = self::nested_flag_is_true($structures, [
                'connected',
                'selected',
                'is_primary',
                'is_connected',
                'isConnected',
            ]);
            if ($id === '' && $name === '' && $username === '') {
                continue;
            }
            $page_data = [
                'id' => $id !== '' ? $id : null,
                'name' => $name !== '' ? $name : null,
                'connected' => $connected,
            ];
            if ($ig_user_id_value !== '') {
                $page_data['ig_user_id'] = $ig_user_id_value;
            } elseif ($id !== '') {
                $page_data['ig_user_id'] = $id;
            }
            if ($instagram_business_account_id !== '') {
                $page_data['instagram_business_account_id'] = $instagram_business_account_id;
            }
            if ($username !== '') {
                $page_data['username'] = $username;
            }
            $token_fields = [
                'page_access_token',
                'access_token',
                'token',
                'pageToken',
                'page_token',
            ];
            $page_token = '';
            foreach ($structures as $structure) {
                foreach ($token_fields as $field) {
                    if (!isset($structure[$field])) {
                        continue;
                    }
                    $candidate_token = $structure[$field];
                    if (!is_string($candidate_token) && !is_numeric($candidate_token)) {
                        continue;
                    }
                    $candidate_token = sanitize_text_field((string) $candidate_token);
                    if ($candidate_token !== '') {
                        $page_token = $candidate_token;
                        break 2;
                    }
                }
            }
            if ($page_token !== '') {
                $page_data['page_access_token'] = $page_token;
                $page_data['access_token'] = $page_token;
                $page_data['connected'] = true;
            }
            $category = self::find_first_value_in_nested($structures, ['category', 'page_category', 'pageCategory']);
            if ($category !== '') {
                $page_data['category'] = $category;
            }
            $perms = [];
            foreach ($structures as $structure) {
                if (!isset($structure['perms']) || !is_array($structure['perms'])) {
                    continue;
                }
                foreach ($structure['perms'] as $perm) {
                    if (!is_string($perm) && !is_numeric($perm)) {
                        continue;
                    }
                    $perm_value = sanitize_text_field((string) $perm);
                    if ($perm_value !== '') {
                        $perms[] = $perm_value;
                    }
                }
            }
            if (!empty($perms)) {
                $page_data['perms'] = array_values(array_unique($perms));
            }
            $normalized[] = $page_data;
        }
        return array_values($normalized);
    }

    public static function normalize_token($token, int $depth = 0): array {
        if (is_string($token)) {
            $token = ['access_token' => $token];
        }
        if (!is_array($token)) {
            return [];
        }
        $mapped = $token;
        $aliases = [
            'accessToken' => 'access_token',
            'userAccessToken' => 'user_access_token',
            'user_access_token' => 'user_access_token',
            'pageAccessToken' => 'page_access_token',
            'page_access_token' => 'page_access_token',
            'longLivedAccessToken' => 'long_lived_access_token',
            'instagramToken' => 'access_token',
            'value' => 'access_token',
        ];
        foreach ($aliases as $from => $to) {
            if (isset($mapped[$from]) && empty($mapped[$to])) {
                $mapped[$to] = $mapped[$from];
            }
        }
        if ($depth < 3) {
            foreach ($mapped as $key => $value) {
                if (is_array($value)) {
                    $nested = self::normalize_token($value, $depth + 1);
                    foreach ($nested as $nested_key => $nested_value) {
                        if (!isset($mapped[$nested_key]) || $mapped[$nested_key] === '' || $mapped[$nested_key] === null) {
                            $mapped[$nested_key] = $nested_value;
                        }
                    }
                }
            }
        }
        foreach ($mapped as $key => $value) {
            if (is_string($value)) {
                $mapped[$key] = sanitize_text_field($value);
            }
        }
        return $mapped;
    }

    public static function token_has_credential(array $token, int $depth = 0): bool {
        $keys = [
            'access_token',
            'user_access_token',
            'page_access_token',
            'long_lived_access_token',
            'token',
        ];
        foreach ($keys as $key) {
            if (!empty($token[$key]) && is_string($token[$key])) {
                return true;
            }
        }
        if ($depth >= 3) {
            return false;
        }
        foreach ($token as $value) {
            if (is_array($value) && self::token_has_credential($value, $depth + 1)) {
                return true;
            }
        }
        return false;
    }

    public static function pages_have_credentials(array $pages): bool {
        foreach ($pages as $page) {
            if (!is_array($page)) {
                continue;
            }
            if (!empty($page['connected'])) {
                return true;
            }
            foreach (['page_access_token', 'access_token', 'token', 'ig_user_token'] as $field) {
                if (!empty($page[$field]) && is_string($page[$field])) {
                    return true;
                }
            }
        }
        return false;
    }

    public static function get_connection_details(string $provider): array {
        $uid = self::get_user_id();
        if (self::has_global_connection_storage($provider)) {
            $account = (string) get_option(self::option_key($provider, 'account'), '');
            $pages_raw = json_decode((string) get_option(self::option_key($provider, 'pages'), ''), true) ?: [];
            $token_raw = json_decode((string) get_option(self::option_key($provider, 'token'), ''), true) ?: [];
            $stored_connected_raw = get_option(self::option_key($provider, 'connected'), null);
            $last_updated = (int) get_option(self::option_key($provider, 'updated'), 0);
        } else {
            $account = (string) get_user_meta($uid, self::meta_key($provider, 'account'), true);
            $pages_raw = json_decode((string) get_user_meta($uid, self::meta_key($provider, 'pages'), true), true) ?: [];
            $token_raw = json_decode((string) get_user_meta($uid, self::meta_key($provider, 'token'), true), true) ?: [];
            $stored_connected_raw = get_user_meta($uid, self::meta_key($provider, 'connected'), true);
            $last_updated = (int) get_user_meta($uid, self::meta_key($provider, 'updated'), true);
        }
        $stored_connected = $stored_connected_raw !== '' && $stored_connected_raw !== null && $stored_connected_raw !== '0' && $stored_connected_raw !== 0;
        $pages = self::normalize_pages($pages_raw);
        $token = self::normalize_token($token_raw);
        $connected = self::token_has_credential($token);
        if (!$connected && self::pages_have_credentials($pages)) {
            $connected = true;
        }
        if (!$connected && $stored_connected) {
            $connected = true;
        }
        if (!$connected && $account) {
            $connected = true;
        }
        return [
            'accountName' => $account ?: null,
            'pages' => $pages,
            'token' => $token,
            'connected' => $connected,
            'lastUpdated' => $last_updated,
        ];
    }

    public static function normalize_https_url($url): string {
        if (!is_string($url)) {
            return '';
        }

        $candidate = trim($url);
        if ($candidate === '') {
            return '';
        }

        $parts = wp_parse_url($candidate);
        if (!is_array($parts) || empty($parts['scheme']) || empty($parts['host'])) {
            return '';
        }

        $scheme = strtolower((string) $parts['scheme']);
        if ($scheme !== 'http' && $scheme !== 'https') {
            return '';
        }

        $sanitized = esc_url_raw($candidate, ['http', 'https']);
        if (!$sanitized) {
            return '';
        }

        $sanitized_parts = wp_parse_url($sanitized);
        if (!is_array($sanitized_parts) || empty($sanitized_parts['host'])) {
            return '';
        }

        return set_url_scheme($sanitized, 'https');
    }

    public static function is_same_host(string $url, string $origin): bool {
        $a = wp_parse_url($url);
        $b = wp_parse_url($origin);
        if (!$a || !$b || empty($a['host']) || empty($b['host'])) {
            return false;
        }
        return strtolower($a['host']) === strtolower($b['host']);
    }

    public static function build_post_share_payload(int $post_id): ?array {
        $post = get_post($post_id);
        if (!$post) {
            return null;
        }
        $permalink = get_permalink($post);
        $content = apply_filters('the_content', $post->post_content);
        $excerpt = $post->post_excerpt;
        if (!$excerpt) {
        $excerpt = wp_trim_words(wp_strip_all_tags($post->post_content), 55, '...');
        }
        $author = get_userdata($post->post_author);
        return [
            'id' => $post->ID,
            'type' => $post->post_type,
            'status' => $post->post_status,
            'title' => html_entity_decode(get_the_title($post), ENT_QUOTES | ENT_HTML5, get_bloginfo('charset') ?: 'UTF-8'),
            'excerpt' => $excerpt,
            'content' => $content,
            'permalink' => $permalink,
            'date_gmt' => mysql_to_rfc3339($post->post_date_gmt ?: $post->post_date),
            'modified_gmt' => mysql_to_rfc3339($post->post_modified_gmt ?: $post->post_modified),
            'author' => $author ? [
                'id' => $author->ID,
                'display_name' => $author->display_name,
                'user_login' => $author->user_login,
            ] : null,
        ];
    }

    public static function extract_pages_from_granular_scopes($granular_scopes): array {
        if (!is_array($granular_scopes)) {
            return [];
        }
        $pages = [];
        foreach ($granular_scopes as $scope_entry) {
            if (!is_array($scope_entry)) {
                continue;
            }
            $targets = $scope_entry['target_ids'] ?? [];
            if (!is_array($targets)) {
                continue;
            }
            foreach ($targets as $target_id) {
                if (!is_string($target_id) && !is_numeric($target_id)) {
                    continue;
                }
                $id = sanitize_text_field((string) $target_id);
                if ($id === '') {
                    continue;
                }
                if (!isset($pages[$id])) {
                    $pages[$id] = [
                        'id' => $id,
                        'name' => null,
                        'connected' => true,
                    ];
                }
            }
        }
        return array_values($pages);
    }

    public static function collect_nested_arrays($input): array {
        $collected = [];
        $queue = [$input];
        while (!empty($queue)) {
            $current = array_shift($queue);
            if (!is_array($current)) {
                continue;
            }
            $collected[] = $current;
            foreach ($current as $value) {
                if (is_array($value)) {
                    $queue[] = $value;
                }
            }
        }
        return $collected;
    }

    public static function find_first_value_in_nested(array $structures, array $keys): string {
        foreach ($structures as $structure) {
            foreach ($keys as $key) {
                if (!isset($structure[$key])) {
                    continue;
                }
                $value = $structure[$key];
                if (is_string($value) || is_numeric($value)) {
                    $value = sanitize_text_field((string) $value);
                    if ($value !== '') {
                        return $value;
                    }
                }
            }
        }
        return '';
    }

    public static function nested_flag_is_true(array $structures, array $keys): bool {
        foreach ($structures as $structure) {
            foreach ($keys as $key) {
                if (!empty($structure[$key])) {
                    return true;
                }
            }
        }
        return false;
    }
}
