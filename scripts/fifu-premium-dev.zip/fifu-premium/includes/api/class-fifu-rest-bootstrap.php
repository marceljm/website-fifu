<?php

if (!function_exists('register_rest_route')) {
    $rest_stubs = dirname(__DIR__, 2) . '/tests/unit/_support/WpRestStubs.php';
    if (file_exists($rest_stubs)) {
        require_once $rest_stubs;
    }
}

class Fifu_Rest_Bootstrap {

    /**
     * Registers all REST routes for FIFU Premium. Call Fifu_Rest_Bootstrap::init() from the plugin bootstrap (e.g. fifu-premium.php).
     */
    public static function init(): void {
        add_action('rest_api_init', [self::class, 'register_all_routes']);
    }

    /**
     * Central entry point for all REST controllers migrated from admin/api.php.
     */
    public static function register_all_routes(): void {
        Fifu_Rest_Quick_Edit_Controller::register_routes();
        Fifu_Rest_Search_Controller::register_routes();
        Fifu_Rest_Metadata_Worker_Controller::register_routes();
        Fifu_Rest_Import_Worker_Controller::register_routes();
        Fifu_Rest_Auto_Media_Worker_Controller::register_routes();
        Fifu_Rest_Social_Share_Controller::register_routes();
    }
}
