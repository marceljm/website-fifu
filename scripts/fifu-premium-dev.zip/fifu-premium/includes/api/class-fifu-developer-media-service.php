<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles developer-only media operations for FIFU Premium.
 */
class Fifu_Developer_Media_Service {
	/**
	 * Set a remote image URL for a post and synchronize media attachments.
	 *
	 * @param int    $post_id   Post ID.
	 * @param string $image_url Remote image URL.
	 * @param bool   $force_featured_attachment_sync Whether to bypass generic post-save suppression while syncing the featured attachment.
	 * @return bool True on success, false on failure.
	 */
	public static function set_image( int $post_id, $image_url, bool $force_featured_attachment_sync = false, bool $preserve_inactive_media = false ): bool {
		try {
			$post_id = (int) $post_id;
			$normalized = self::normalize_single_image_url( $image_url, true );
			if ( $normalized === null ) {
				return false;
			}

			self::ensure_db2_runtime_schema_ready();
			$is_delete = $normalized === '';
			$current_url = self::get_current_featured_image_url( $post_id );
			$current_alt = self::get_current_featured_image_alt( $post_id );
			$previous_thumbnail_id = (int) get_post_thumbnail_id( $post_id );
			$was_featured_video = self::has_featured_video_state( $post_id );
			$legacy_snapshot = self::snapshot_featured_legacy_state( $post_id );
			$db2_snapshot = self::snapshot_db2_featured_image_state( $post_id );
			$preserved_alt = self::resolve_preserved_alt_for_image_url(
				$post_id,
				$normalized,
				(string) $current_url,
				(string) $current_alt,
				$legacy_snapshot,
				$db2_snapshot
			);
			if ( $is_delete ) {
				if ( $preserve_inactive_media ) {
					return self::clear_featured_image_only( $post_id );
				}

				if ( ! self::clear_all_featured_media_state( $post_id ) ) {
					return false;
				}
				self::sync_post_media( $post_id, false, $force_featured_attachment_sync );
				return true;
			}

			if ( ! self::is_valid_http_url( $normalized ) ) {
				return false;
			}

			if ( self::is_exact_canonical_simple_featured_image_state( $post_id, $normalized, $preserved_alt ) ) {
				self::sync_post_media( $post_id, false, $force_featured_attachment_sync );
				return true;
			}

			$bridge = function_exists( 'fifu_db2_legacy_write_bridge' ) ? fifu_db2_legacy_write_bridge() : null;
			if ( ! $bridge instanceof Fifu_Db2_Legacy_Write_Bridge ) {
				return false;
			}
			if ( ! $bridge->replace_with_simple_featured_image( $post_id, $normalized, $preserved_alt, $preserve_inactive_media ) ) {
				self::restore_featured_legacy_state( $post_id, $legacy_snapshot );
				self::restore_db2_featured_image_state( $post_id, $db2_snapshot );
				return false;
			}
			if ( ! self::db2_featured_image_matches( $post_id, $normalized, $preserved_alt ) ) {
				self::restore_featured_legacy_state( $post_id, $legacy_snapshot );
				self::restore_db2_featured_image_state( $post_id, $db2_snapshot );
				return false;
			}
			if ( ! $preserve_inactive_media && ! self::clear_conflicts_for_featured_image( $post_id ) ) {
				self::restore_featured_legacy_state( $post_id, $legacy_snapshot );
				self::restore_db2_featured_image_state( $post_id, $db2_snapshot );
				return false;
			}
			if ( ! $preserve_inactive_media && method_exists( $bridge, 'handle_post_meta_change' ) ) {
				$bridge->handle_post_meta_change( $post_id, 'fifu_video_url', null );
			}

			if ( $was_featured_video && ! $preserve_inactive_media ) {
				self::detach_previous_video_thumbnail( $post_id, $previous_thumbnail_id );
			}

			self::sync_post_media( $post_id, false, $force_featured_attachment_sync );
			if ( ! self::is_effectively_empty_alt_value( $preserved_alt ) ) {
				$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
				if ( ! $manager instanceof Fifu_Db2_Manager ) {
					self::restore_featured_legacy_state( $post_id, $legacy_snapshot );
					self::restore_db2_featured_image_state( $post_id, $db2_snapshot );
					return false;
				}

				if ( ! $manager->savePostAlt( $post_id, 'image', 0, $preserved_alt ) ) {
					self::restore_featured_legacy_state( $post_id, $legacy_snapshot );
					self::restore_db2_featured_image_state( $post_id, $db2_snapshot );
					return false;
				}

				$confirmed_alt = $manager->getPostAltMapping( $post_id, 'image', 0 );
				$confirmed_value = is_array( $confirmed_alt ) ? trim( (string) ( $confirmed_alt['alt'] ?? $confirmed_alt['value'] ?? '' ) ) : '';
				if ( $confirmed_value !== trim( (string) $preserved_alt ) ) {
					self::restore_featured_legacy_state( $post_id, $legacy_snapshot );
					self::restore_db2_featured_image_state( $post_id, $db2_snapshot );
					return false;
				}

				self::delete_legacy_post_meta_exact_and_prefixed_raw(
					$post_id,
					array( 'fifu_image_alt' ),
					array( 'fifu_image_alt_' )
				);
				clean_post_cache( $post_id );
				wp_cache_delete( $post_id, 'post_meta' );
			}
			return true;
		} catch ( \Throwable $e ) {
			error_log( $e->getMessage() );
			return false;
		}
	}

	private static function ensure_db2_runtime_schema_ready(): void {
		if ( ! function_exists( 'fifu_db2_manager' ) ) {
			return;
		}

		$manager = fifu_db2_manager();
		if ( $manager instanceof Fifu_Db2_Manager && method_exists( $manager, 'ensureRuntimeSchemaReady' ) ) {
			$manager->ensureRuntimeSchemaReady();
		}
	}

	private static function snapshot_featured_legacy_state( int $post_id ): array {
		return array(
			'fifu_image_url' => self::snapshot_post_meta_value( $post_id, 'fifu_image_url' ),
			'fifu_image_alt' => self::snapshot_post_meta_value( $post_id, 'fifu_image_alt' ),
			'fifu_image_alt_0' => self::snapshot_post_meta_value( $post_id, 'fifu_image_alt_0' ),
			'fifu_list_url' => self::snapshot_post_meta_value( $post_id, 'fifu_list_url' ),
			'fifu_list_alt' => self::snapshot_post_meta_value( $post_id, 'fifu_list_alt' ),
			'fifu_video_url' => self::snapshot_post_meta_value( $post_id, 'fifu_video_url' ),
			'fifu_list_video_url' => self::snapshot_post_meta_value( $post_id, 'fifu_list_video_url' ),
			'fifu_slider_list_url' => self::snapshot_post_meta_value( $post_id, 'fifu_slider_list_url' ),
		);
	}

	private static function snapshot_post_meta_value( int $post_id, string $meta_key ): ?string {
		$value = get_post_meta( $post_id, $meta_key, true );
		if ( null === $value ) {
			return null;
		}

		$value = trim( (string) $value );
		return '' === $value ? null : $value;
	}

	private static function resolve_preserved_alt_for_image_url(
		int $post_id,
		string $normalized_url,
		string $current_url,
		string $current_alt,
		array $legacy_snapshot,
		array $db2_snapshot
	): ?string {
		$current_normalized_url = self::normalize_single_image_url( $current_url );
		if ( $current_normalized_url === $normalized_url && ! self::is_effectively_empty_alt_value( $current_alt ) ) {
			return trim( $current_alt );
		}

		$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
		if ( $manager instanceof Fifu_Db2_Manager && method_exists( $manager, 'getPostMappings' ) && method_exists( $manager, 'getPostAltMapping' ) ) {
			$mappings = $manager->getPostMappings( $post_id, 'image' );
			foreach ( $mappings as $index => $mapping ) {
				if ( ! is_array( $mapping ) ) {
					continue;
				}

				$url = self::normalize_single_image_url( (string) ( $mapping['url'] ?? '' ) );
				if ( $url !== $normalized_url ) {
					continue;
				}

				$alt_mapping = $manager->getPostAltMapping( $post_id, 'image', (int) $index );
				$alt = self::extract_alt_value_from_mapping( $alt_mapping );
				if ( ! self::is_effectively_empty_alt_value( $alt ) ) {
					return trim( (string) $alt );
				}
			}
		}

		$db2_url = isset( $db2_snapshot['url'] ) ? self::normalize_single_image_url( (string) $db2_snapshot['url'] ) : '';
		$db2_alt = isset( $db2_snapshot['alt'] ) ? (string) $db2_snapshot['alt'] : '';
		if ( $db2_url === $normalized_url && ! self::is_effectively_empty_alt_value( $db2_alt ) ) {
			return trim( $db2_alt );
		}

		foreach ( array( 'fifu_image_url', 'fifu_image_url_0' ) as $url_key ) {
			$legacy_url = isset( $legacy_snapshot[ $url_key ] ) ? self::normalize_single_image_url( (string) $legacy_snapshot[ $url_key ] ) : '';
			if ( $legacy_url !== $normalized_url ) {
				continue;
			}

			$alt_key = 'fifu_image_url' === $url_key ? 'fifu_image_alt' : 'fifu_image_alt_0';
			$legacy_alt = isset( $legacy_snapshot[ $alt_key ] ) ? (string) $legacy_snapshot[ $alt_key ] : '';
			if ( ! self::is_effectively_empty_alt_value( $legacy_alt ) ) {
				return trim( $legacy_alt );
			}
		}

		$meta = get_post_meta( $post_id );
		if ( is_array( $meta ) ) {
			foreach ( $meta as $meta_key => $values ) {
				if ( ! is_string( $meta_key ) || strpos( $meta_key, 'fifu_image_url_' ) !== 0 ) {
					continue;
				}

				$legacy_url = '';
				if ( is_array( $values ) ) {
					$legacy_url = self::normalize_single_image_url( (string) ( $values[0] ?? '' ) );
				} else {
					$legacy_url = self::normalize_single_image_url( (string) $values );
				}

				if ( $legacy_url !== $normalized_url ) {
					continue;
				}

				$suffix = substr( $meta_key, strlen( 'fifu_image_url_' ) );
				$legacy_alt = (string) get_post_meta( $post_id, 'fifu_image_alt_' . $suffix, true );
				if ( ! self::is_effectively_empty_alt_value( $legacy_alt ) ) {
					return trim( $legacy_alt );
				}
			}
		}

		$list_url = isset( $legacy_snapshot['fifu_list_url'] ) ? (string) $legacy_snapshot['fifu_list_url'] : '';
		$list_alt = isset( $legacy_snapshot['fifu_list_alt'] ) ? (string) $legacy_snapshot['fifu_list_alt'] : '';
		if ( $list_url !== '' ) {
			$urls = array_map( 'trim', explode( '|', $list_url ) );
			$alts = array_map( 'trim', explode( '|', $list_alt ) );
			foreach ( $urls as $index => $url ) {
				if ( self::normalize_single_image_url( $url ) !== $normalized_url ) {
					continue;
				}

				$alt = (string) ( $alts[ $index ] ?? '' );
				if ( ! self::is_effectively_empty_alt_value( $alt ) ) {
					return trim( $alt );
				}
			}
		}

		return null;
	}

	/**
	 * Extract a normalized ALT value from a DB2 mapping record.
	 *
	 * @param mixed $mapping Mapping data.
	 * @return string|null
	 */
	private static function extract_alt_value_from_mapping( $mapping ): ?string {
		if ( ! is_array( $mapping ) ) {
			return null;
		}

		$alt = $mapping['alt'] ?? $mapping['value'] ?? null;
		if ( self::is_effectively_empty_alt_value( $alt ) ) {
			return null;
		}

		return trim( (string) $alt );
	}

	private static function restore_featured_legacy_state( int $post_id, array $snapshot ): void {
		foreach ( $snapshot as $meta_key => $value ) {
			if ( null === $value ) {
				delete_post_meta( $post_id, $meta_key );
				continue;
			}

			update_post_meta( $post_id, $meta_key, $value );
		}
	}

	private static function snapshot_db2_featured_image_state( int $post_id ): array {
		$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
		if ( ! $manager instanceof Fifu_Db2_Manager ) {
			return array(
				'url' => null,
				'alt' => null,
			);
		}

		$url = null;
		$alt = null;
		if ( method_exists( $manager, 'getPostMapping' ) ) {
			$mapping = $manager->getPostMapping( $post_id, 'image', 0 );
			if ( is_array( $mapping ) ) {
				$url = isset( $mapping['url'] ) ? trim( (string) $mapping['url'] ) : null;
				$url = '' === $url ? null : $url;
			}
		}

		if ( method_exists( $manager, 'getPostAltMapping' ) ) {
			$mapping = $manager->getPostAltMapping( $post_id, 'image', 0 );
			if ( is_array( $mapping ) ) {
				$alt_value = trim( (string) ( $mapping['alt'] ?? $mapping['value'] ?? '' ) );
				$alt = '' === $alt_value ? null : $alt_value;
			}
		}

		return array(
			'url' => $url,
			'alt' => $alt,
		);
	}

	private static function restore_db2_featured_image_state( int $post_id, array $snapshot ): void {
		$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
		if ( ! $manager instanceof Fifu_Db2_Manager ) {
			return;
		}

		if ( method_exists( $manager, 'deletePostMappings' ) ) {
			$manager->deletePostMappings( $post_id, 'image', 0 );
		}
		if ( method_exists( $manager, 'deletePostAltMappings' ) ) {
			$manager->deletePostAltMappings( $post_id, 'image', 0 );
		}

		$original_url = isset( $snapshot['url'] ) ? trim( (string) $snapshot['url'] ) : '';
		if ( $original_url !== '' && method_exists( $manager, 'savePostUrl' ) ) {
			$manager->savePostUrl( $post_id, 'image', 0, $original_url );
		}

		$original_alt = isset( $snapshot['alt'] ) ? trim( (string) $snapshot['alt'] ) : '';
		if ( $original_alt !== '' && method_exists( $manager, 'savePostAlt' ) ) {
			$manager->savePostAlt( $post_id, 'image', 0, $original_alt );
		}
	}

	private static function db2_featured_image_matches( int $post_id, string $expected_url, ?string $expected_alt ): bool {
		$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
		if ( ! $manager instanceof Fifu_Db2_Manager ) {
			return false;
		}

		$mapping = method_exists( $manager, 'getPostMapping' ) ? $manager->getPostMapping( $post_id, 'image', 0 ) : null;
		if ( ! is_array( $mapping ) ) {
			return false;
		}

		$actual_url = trim( (string) ( $mapping['url'] ?? '' ) );
		if ( $actual_url !== $expected_url ) {
			return false;
		}

		$alt_mapping = method_exists( $manager, 'getPostAltMapping' ) ? $manager->getPostAltMapping( $post_id, 'image', 0 ) : null;
		$actual_alt = null;
		if ( is_array( $alt_mapping ) ) {
			$alt_value = trim( (string) ( $alt_mapping['alt'] ?? $alt_mapping['value'] ?? '' ) );
			$actual_alt = '' === $alt_value ? null : $alt_value;
		}

		$expected_alt = self::is_effectively_empty_alt_value( $expected_alt ) ? null : trim( (string) $expected_alt );
		return $actual_alt === $expected_alt;
	}

	private static function is_exact_canonical_simple_featured_image_state( int $post_id, string $expected_url, ?string $expected_alt ): bool {
		if ( ! self::db2_featured_image_matches( $post_id, $expected_url, $expected_alt ) ) {
			return false;
		}

		$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
		if (
			! $manager instanceof Fifu_Db2_Manager
			|| ! method_exists( $manager, 'getPostMappings' )
			|| ! method_exists( $manager, 'getPostAltMappings' )
		) {
			return false;
		}

		try {
			$image_mappings = $manager->getPostMappings( $post_id, 'image' );
			if ( ! is_array( $image_mappings ) || count( $image_mappings ) !== 1 ) {
				return false;
			}

			$image_mapping = reset( $image_mappings );
			if (
				! is_array( $image_mapping )
				|| (int) ( $image_mapping['key_index'] ?? -1 ) !== 0
				|| self::normalize_single_image_url( (string) ( $image_mapping['url'] ?? '' ) ) !== $expected_url
			) {
				return false;
			}

			$image_alt_mappings = $manager->getPostAltMappings( $post_id, 'image' );
			if ( ! is_array( $image_alt_mappings ) || count( $image_alt_mappings ) > 1 ) {
				return false;
			}
			foreach ( $image_alt_mappings as $alt_mapping ) {
				if ( ! is_array( $alt_mapping ) || (int) ( $alt_mapping['key_index'] ?? -1 ) !== 0 ) {
					return false;
				}
			}

			foreach ( array( 'video', 'custom_video', 'slider' ) as $key_type ) {
				$mappings = $manager->getPostMappings( $post_id, $key_type );
				if ( ! is_array( $mappings ) ) {
					return false;
				}
				foreach ( $mappings as $mapping ) {
					if ( is_array( $mapping ) && trim( (string) ( $mapping['url'] ?? '' ) ) !== '' ) {
						return false;
					}
				}
			}
		} catch ( \Throwable $e ) {
			return false;
		}

		return ! self::has_featured_video_state( $post_id ) && ! self::has_featured_image_legacy_cleanup_debt( $post_id );
	}

	private static function has_featured_image_legacy_cleanup_debt( int $post_id ): bool {
		$meta = get_post_meta( $post_id );
		if ( ! is_array( $meta ) ) {
			return true;
		}

		$exact_keys = array(
			'fifu_image_url', 'fifu_image_alt', 'fifu_video_url', 'fifu_custom_video_url',
			'fifu_list_url', 'fifu_list_alt', 'fifu_list_video_url',
			'fifu_slider_list_url', 'fifu_slider_list_alt',
		);
		$prefixes = array(
			'fifu_image_url_', 'fifu_image_alt_', 'fifu_video_url_',
			'fifu_slider_image_url_', 'fifu_slider_image_alt_',
		);

		foreach ( array_keys( $meta ) as $meta_key ) {
			if ( in_array( $meta_key, $exact_keys, true ) ) {
				return true;
			}
			foreach ( $prefixes as $prefix ) {
				if ( strpos( $meta_key, $prefix ) === 0 ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Remove all slider state for a post without triggering media sync.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	private static function clear_slider_state( int $post_id ): void {
		fifu_update_or_delete( $post_id, 'fifu_slider_list_url', '' );
		fifu_update_or_delete( $post_id, 'fifu_slider_list_alt', '' );

		$meta = get_post_meta( $post_id );
		if ( ! is_array( $meta ) ) {
			return;
		}

		foreach ( array_keys( $meta ) as $meta_key ) {
			if (
				strpos( $meta_key, 'fifu_slider_image_url_' ) === 0
				|| strpos( $meta_key, 'fifu_slider_image_alt_' ) === 0
			) {
				fifu_delete_post_meta( $post_id, $meta_key );
			}
		}
	}

	private static function normalize_single_video_url( $video_url ): ?string {
		if ( null === $video_url ) {
			return '';
		}

		$raw = trim( (string) $video_url );
		if ( '' === $raw ) {
			return '';
		}

		if ( ! self::is_valid_http_url( $raw ) ) {
			return null;
		}

		$sanitized = esc_url_raw( $raw );
		return '' === $sanitized ? null : $sanitized;
	}

	private static function get_current_featured_image_url( int $post_id ): string {
		$current_url = Fifu_Post_Image_Url_Read_Service::get_image_url( $post_id );
		if ( is_string( $current_url ) && trim( $current_url ) !== '' ) {
			return $current_url;
		}

		$current_url = (string) get_post_meta( $post_id, 'fifu_image_url', true );
		if ( trim( $current_url ) !== '' ) {
			return $current_url;
		}

		$current_url = (string) get_post_meta( $post_id, 'fifu_image_url_0', true );
		if ( trim( $current_url ) !== '' ) {
			return $current_url;
		}

		$thumbnail_id = (int) get_post_thumbnail_id( $post_id );
		if ( $thumbnail_id > 0 ) {
			$attached_file = (string) get_post_meta( $thumbnail_id, '_wp_attached_file', true );
			if ( trim( $attached_file ) !== '' ) {
				return $attached_file;
			}
		}

		if ( function_exists( 'fifu_db2_manager' ) && class_exists( 'Fifu_Db2_Manager' ) ) {
			$manager = fifu_db2_manager();
			if ( $manager instanceof Fifu_Db2_Manager && method_exists( $manager, 'getPostMapping' ) ) {
				$mapping = $manager->getPostMapping( $post_id, 'image', 0 );
				if ( is_array( $mapping ) && ! empty( $mapping['url'] ) ) {
					return (string) $mapping['url'];
				}
			}
		}

		return '';
	}

	private static function get_current_featured_image_alt( int $post_id ): string {
		$current_alt = Fifu_Post_Image_Alt_Read_Service::get_image_alt( $post_id );
		if ( is_string( $current_alt ) && ! self::is_effectively_empty_alt_value( $current_alt ) ) {
			return $current_alt;
		}

		if ( function_exists( 'fifu_db2_manager' ) && class_exists( 'Fifu_Db2_Manager' ) ) {
			$manager = fifu_db2_manager();
			if ( $manager instanceof Fifu_Db2_Manager && method_exists( $manager, 'getPostAltMapping' ) ) {
				$mapping = $manager->getPostAltMapping( $post_id, 'image', 0 );
				if ( is_array( $mapping ) ) {
					$alt = $mapping['alt'] ?? $mapping['value'] ?? null;
					if ( is_string( $alt ) && ! self::is_effectively_empty_alt_value( $alt ) ) {
						return $alt;
					}
				}
			}
		}

		$legacy_alt = (string) get_post_meta( $post_id, 'fifu_image_alt_0', true );
		if ( ! self::is_effectively_empty_alt_value( $legacy_alt ) ) {
			return $legacy_alt;
		}

		$legacy_alt = (string) get_post_meta( $post_id, 'fifu_image_alt', true );
		return self::is_effectively_empty_alt_value( $legacy_alt ) ? '' : $legacy_alt;
	}

	private static function is_effectively_empty_alt_value( $value ): bool {
		if ( $value === null ) {
			return true;
		}

		$value = (string) $value;
		$trimmed = trim( $value );
		if ( $trimmed === '' ) {
			return true;
		}

		return preg_match( '/^(null|undefined)$/i', $trimmed ) === 1;
	}

	private static function clear_all_featured_media_state( int $post_id ): bool {
		$attachment_ids = self::collect_featured_media_attachment_ids( $post_id );

		if ( ! self::clear_db2_featured_media_state( $post_id ) ) {
			return false;
		}

		self::delete_legacy_post_meta_keys(
			$post_id,
			array(
				'fifu_image_url',
				'fifu_image_alt',
				'fifu_video_url',
				'fifu_custom_video_url',
				'fifu_audio_url',
				'fifu_list_url',
				'fifu_list_alt',
				'fifu_list_video_url',
				'fifu_slider_list_url',
				'fifu_slider_list_alt',
			),
			array(
				'fifu_image_url_',
				'fifu_image_alt_',
				'fifu_video_url_',
				'fifu_slider_image_url_',
				'fifu_slider_image_alt_',
			)
		);

		self::delete_fifu_managed_attachment_references( $post_id, $attachment_ids );
		self::delete_featured_media_attachments( $post_id, $attachment_ids );
		return true;
	}

	private static function clear_conflicts_for_featured_image( int $post_id ): bool {
		self::delete_db2_image_gallery_only( $post_id );
		self::delete_db2_image_gallery_only_alt( $post_id );

		return self::clear_db2_and_legacy_conflicts(
			$post_id,
			array( 'video', 'custom_video', 'slider' ),
			array(
				'fifu_image_url',
				'fifu_image_alt',
				'fifu_video_url',
				'fifu_custom_video_url',
				'fifu_list_url',
				'fifu_list_alt',
				'fifu_list_video_url',
				'fifu_slider_list_url',
				'fifu_slider_list_alt',
			),
			array(
				'fifu_video_url_',
				'fifu_image_url_',
				'fifu_image_alt_',
				'fifu_slider_image_url_',
				'fifu_slider_image_alt_',
			),
			false,
			false
		);
	}

	private static function clear_featured_image_only( int $post_id ): bool {
		$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
		if ( $manager instanceof Fifu_Db2_Manager ) {
			$manager->deletePostMappings( $post_id, 'image', 0 );
			$manager->deletePostAltMappings( $post_id, 'image', 0 );
		}

		self::delete_legacy_post_meta_exact_and_prefixed_raw(
			$post_id,
			array( 'fifu_image_url', 'fifu_image_alt' ),
			array()
		);
		self::sync_post_media( $post_id, false, false );
		return true;
	}

	private static function has_featured_video_state( int $post_id ): bool {
		if ( trim( (string) Fifu_Post_Video_Read_Service::get_video_url( $post_id ) ) !== '' ) {
			return true;
		}

		if ( trim( (string) Fifu_Post_Custom_Video_Read_Service::get_custom_video_url( $post_id ) ) !== '' ) {
			return true;
		}

		if ( trim( (string) get_post_meta( $post_id, 'fifu_video_url', true ) ) !== '' ) {
			return true;
		}

		if ( trim( (string) get_post_meta( $post_id, 'fifu_custom_video_url', true ) ) !== '' ) {
			return true;
		}

		if ( function_exists( 'fifu_db2_manager' ) && class_exists( 'Fifu_Db2_Manager' ) ) {
			$manager = fifu_db2_manager();
			if ( $manager instanceof Fifu_Db2_Manager && method_exists( $manager, 'getPostMapping' ) ) {
				$video = $manager->getPostMapping( $post_id, 'video', 0 );
				if ( is_array( $video ) && trim( (string) ( $video['url'] ?? '' ) ) !== '' ) {
					return true;
				}

				$custom_video = $manager->getPostMapping( $post_id, 'custom_video', 0 );
				if ( is_array( $custom_video ) && trim( (string) ( $custom_video['url'] ?? '' ) ) !== '' ) {
					return true;
				}
			}
		}

		return false;
	}

	private static function detach_previous_video_thumbnail( int $post_id, int $thumbnail_id ): void {
		if ( $thumbnail_id <= 0 ) {
			return;
		}

		$attachment_repo = self::get_attachment_repository_for_cleanup();
		$is_managed = self::is_fifu_managed_attachment( $attachment_repo, $thumbnail_id, $post_id );
		if ( ! $is_managed ) {
			return;
		}

		if ( (int) get_post_meta( $post_id, '_thumbnail_id', true ) === $thumbnail_id ) {
			delete_post_thumbnail( $post_id );
		}
		self::remove_attachment_ids_from_post_meta_list( $post_id, '_product_image_gallery', array( $thumbnail_id ) );
		clean_post_cache( $post_id );
		wp_cache_delete( $post_id, 'post_meta' );

		self::delete_owned_remote_attachment_if_unreferenced( $thumbnail_id, $post_id );
	}

	private static function delete_db2_image_gallery_only( int $post_id ): void {
		if ( ! function_exists( 'fifu_db2_manager' ) || ! class_exists( 'Fifu_Db2_Manager', false ) ) {
			return;
		}

		$manager = fifu_db2_manager();
		if ( ! $manager instanceof Fifu_Db2_Manager ) {
			return;
		}

		$mappings = $manager->getPostMappings( $post_id, 'image' );
		if ( ! is_array( $mappings ) ) {
			return;
		}

		foreach ( $mappings as $mapping ) {
			if ( ! is_array( $mapping ) ) {
				continue;
			}

			$index = isset( $mapping['key_index'] ) ? (int) $mapping['key_index'] : null;
			if ( $index === null || $index <= 0 ) {
				continue;
			}

			$manager->deletePostMappings( $post_id, 'image', $index );
		}
	}

	private static function delete_db2_image_gallery_only_alt( int $post_id ): void {
		if ( ! function_exists( 'fifu_db2_manager' ) || ! class_exists( 'Fifu_Db2_Manager', false ) ) {
			return;
		}

		$manager = fifu_db2_manager();
		if ( ! $manager instanceof Fifu_Db2_Manager ) {
			return;
		}

		$mappings = $manager->getPostAltMappings( $post_id, 'image' );
		if ( ! is_array( $mappings ) ) {
			return;
		}

		foreach ( $mappings as $mapping ) {
			if ( ! is_array( $mapping ) ) {
				continue;
			}

			$index = isset( $mapping['key_index'] ) ? (int) $mapping['key_index'] : null;
			if ( $index === null || $index <= 0 ) {
				continue;
			}

			$manager->deletePostAltMappings( $post_id, 'image', $index );
		}
	}

	private static function clear_conflicts_for_featured_video( int $post_id ): bool {
		return self::clear_db2_and_legacy_conflicts(
			$post_id,
			array( 'image', 'custom_video', 'slider' ),
			array( 'fifu_image_url', 'fifu_image_alt', 'fifu_list_url', 'fifu_list_alt', 'fifu_slider_list_url', 'fifu_slider_list_alt' ),
			array( 'fifu_image_url_', 'fifu_image_alt_', 'fifu_slider_image_url_', 'fifu_slider_image_alt_' ),
			false,
			false
		);
	}

	private static function clear_featured_video_only( int $post_id ): bool {
		$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
		if ( $manager instanceof Fifu_Db2_Manager ) {
			$manager->deletePostMappings( $post_id, 'video', null );
			$manager->deletePostMappings( $post_id, 'custom_video', null );
		}

		self::delete_legacy_post_meta_exact_and_prefixed_raw(
			$post_id,
			array( 'fifu_video_url', 'fifu_custom_video_url', 'fifu_list_video_url' ),
			array( 'fifu_video_url_' )
		);
		self::sync_post_media( $post_id, true );
		return true;
	}

	private static function clear_conflicts_for_custom_video( int $post_id, bool $preserve_image = false ): bool {
		$db2_key_types = $preserve_image ? array( 'video', 'slider' ) : array( 'image', 'video', 'slider' );
		$exact_meta_keys = array(
			'fifu_image_url',
			'fifu_image_alt',
			'fifu_list_url',
			'fifu_list_alt',
			'fifu_list_video_url',
			'fifu_slider_list_url',
			'fifu_slider_list_alt',
		);

		$prefixes = array(
			'fifu_image_url_',
			'fifu_image_alt_',
			'fifu_video_url_',
			'fifu_slider_image_url_',
			'fifu_slider_image_alt_',
		);

		return self::clear_db2_and_legacy_conflicts(
			$post_id,
			$db2_key_types,
			$exact_meta_keys,
			$prefixes,
			false,
			false
		);
	}

	private static function normalize_custom_video_input( $video_url ): array {
		$raw = trim( (string) $video_url );
		if ( $raw === '' ) {
			return array( null, null );
		}

		[ $video_part, $image_part ] = array_pad( explode( '\\', $raw, 2 ), 2, '' );
		$video_part = trim( $video_part );
		$image_part = trim( $image_part );

		if ( $video_part === '' ) {
			return array( null, null );
		}

		$normalized_video = self::normalize_single_video_url( $video_part );
		if ( $normalized_video === null ) {
			return array( null, null );
		}

		$normalized_image = null;
		if ( $image_part !== '' ) {
			$normalized_image = self::normalize_single_image_url( $image_part, true );
			if ( $normalized_image === null ) {
				return array( null, null );
			}
		}

		return array( $normalized_video, $normalized_image );
	}

	private static function snapshot_custom_video_legacy_state( int $post_id ): array {
		return array(
			'fifu_custom_video_url' => self::snapshot_post_meta_value( $post_id, 'fifu_custom_video_url' ),
			'fifu_video_url' => self::snapshot_post_meta_value( $post_id, 'fifu_video_url' ),
			'fifu_list_video_url' => self::snapshot_post_meta_value( $post_id, 'fifu_list_video_url' ),
			'fifu_list_url' => self::snapshot_post_meta_value( $post_id, 'fifu_list_url' ),
			'fifu_list_alt' => self::snapshot_post_meta_value( $post_id, 'fifu_list_alt' ),
			'fifu_slider_list_url' => self::snapshot_post_meta_value( $post_id, 'fifu_slider_list_url' ),
			'fifu_slider_list_alt' => self::snapshot_post_meta_value( $post_id, 'fifu_slider_list_alt' ),
			'fifu_image_url' => self::snapshot_post_meta_value( $post_id, 'fifu_image_url' ),
			'fifu_image_alt' => self::snapshot_post_meta_value( $post_id, 'fifu_image_alt' ),
		);
	}

	private static function restore_custom_video_legacy_state( int $post_id, array $snapshot ): void {
		self::restore_featured_legacy_state( $post_id, $snapshot );
	}

	private static function snapshot_custom_video_db2_state( int $post_id ): array {
		$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
		if ( ! $manager instanceof Fifu_Db2_Manager ) {
			return array(
				'video' => null,
				'poster' => null,
				'embed' => null,
			);
		}

		$video = null;
		$poster = null;
		$embed = null;

		if ( method_exists( $manager, 'getPostMapping' ) ) {
			$video_mapping = $manager->getPostMapping( $post_id, 'custom_video', 0 );
			if ( is_array( $video_mapping ) ) {
				$video = trim( (string) ( $video_mapping['url'] ?? '' ) );
				$video = '' === $video ? null : $video;
			}
		}

		if ( $video !== null && class_exists( 'Fifu_Video_Oembed_Service' ) ) {
			$repo = Fifu_Video_Oembed_Service::instance()->get_repository();
			$poster = $repo->get_image_url_by_video_url( $video );
			$embed = $repo->get_embed_url_by_video_url( $video );
			$poster = trim( (string) $poster );
			$poster = '' === $poster ? null : $poster;
			$embed = trim( (string) $embed );
			$embed = '' === $embed ? null : $embed;
		}

		return array(
			'video' => $video,
			'poster' => $poster,
			'embed' => $embed,
		);
	}

	private static function restore_custom_video_db2_state( int $post_id, array $snapshot ): void {
		$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
		if ( ! $manager instanceof Fifu_Db2_Manager ) {
			return;
		}

		if ( method_exists( $manager, 'deletePostMappings' ) ) {
			$manager->deletePostMappings( $post_id, 'custom_video', 0 );
		}

		if ( ! empty( $snapshot['video'] ) && method_exists( $manager, 'savePostUrl' ) ) {
			$manager->savePostUrl( $post_id, 'custom_video', 0, (string) $snapshot['video'] );
		}
		if ( ! empty( $snapshot['poster'] ) && class_exists( 'Fifu_Video_Oembed_Service' ) ) {
			$embed = ! empty( $snapshot['embed'] ) ? (string) $snapshot['embed'] : (string) $snapshot['video'];
			Fifu_Video_Oembed_Service::instance()->upsert_oembed( (string) $snapshot['video'], (string) $snapshot['poster'], $embed );
		}
	}

	private static function snapshot_video_oembed_state( string $video_url ): array {
		if ( ! class_exists( 'Fifu_Video_Oembed_Service' ) ) {
			return array(
				'exists' => false,
				'image_url' => null,
				'embed_url' => null,
			);
		}

		$repo = Fifu_Video_Oembed_Service::instance()->get_repository();
		$image_url = $repo->get_image_url_by_video_url( $video_url );
		$embed_url = $repo->get_embed_url_by_video_url( $video_url );

		return array(
			'exists' => method_exists( $repo, 'exists' ) ? $repo->exists( $video_url ) : trim( (string) $image_url ) !== '',
			'image_url' => $image_url,
			'embed_url' => $embed_url,
		);
	}

	private static function restore_video_oembed_state( string $video_url, array $snapshot ): void {
		if ( ! class_exists( 'Fifu_Video_Oembed_Service' ) ) {
			return;
		}

		$repo = Fifu_Video_Oembed_Service::instance()->get_repository();
		$had_row = ! empty( $snapshot['exists'] );
		$image_url = isset( $snapshot['image_url'] ) ? trim( (string) $snapshot['image_url'] ) : '';
		$embed_url = isset( $snapshot['embed_url'] ) ? trim( (string) $snapshot['embed_url'] ) : '';

		if ( $had_row && $image_url !== '' && $embed_url !== '' ) {
			$repo->upsert_oembed( $video_url, $image_url, $embed_url );
			return;
		}

		if ( method_exists( $repo, 'delete_by_video_url' ) ) {
			$repo->delete_by_video_url( $video_url );
		}
	}

	private static function rollback_custom_video_save(
		int $post_id,
		array $legacy_snapshot,
		array $db2_snapshot,
		string $target_video_url,
		array $target_oembed_snapshot
	): void {
		self::restore_custom_video_legacy_state( $post_id, $legacy_snapshot );
		self::restore_custom_video_db2_state( $post_id, $db2_snapshot );
		self::restore_video_oembed_state( $target_video_url, $target_oembed_snapshot );
	}

	private static function custom_video_db2_matches( int $post_id, string $video_url, ?string $image_url ): bool {
		$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
		if ( ! $manager instanceof Fifu_Db2_Manager ) {
			return false;
		}

		$video_mapping = method_exists( $manager, 'getPostMapping' ) ? $manager->getPostMapping( $post_id, 'custom_video', 0 ) : null;
		if ( ! is_array( $video_mapping ) || trim( (string) ( $video_mapping['url'] ?? '' ) ) !== $video_url ) {
			return false;
		}

		if ( $image_url === null ) {
			return true;
		}

		if ( ! class_exists( 'Fifu_Video_Oembed_Service' ) ) {
			return false;
		}

		$poster = Fifu_Video_Oembed_Service::instance()->get_repository()->get_image_url_by_video_url( $video_url );
		return trim( (string) $poster ) === $image_url;
	}

	private static function save_custom_video_db2_state( int $post_id, string $video_url, ?string $image_url ): bool {
		if ( ! function_exists( 'fifu_db2_manager' ) || ! class_exists( 'Fifu_Db2_Manager', false ) ) {
			return false;
		}

		$manager = fifu_db2_manager();
		if ( ! $manager instanceof Fifu_Db2_Manager ) {
			return false;
		}

		if ( $image_url === null || trim( $image_url ) === '' ) {
			return false;
		}

		$legacy_snapshot = self::snapshot_custom_video_legacy_state( $post_id );
		$db2_snapshot = self::snapshot_custom_video_db2_state( $post_id );
		$target_oembed_snapshot = self::snapshot_video_oembed_state( $video_url );

		if ( ! $manager->savePostUrl( $post_id, 'custom_video', 0, $video_url ) ) {
			return false;
		}

		if ( class_exists( 'Fifu_Video_Oembed_Service' ) ) {
			if ( ! Fifu_Video_Oembed_Service::instance()->upsert_oembed( $video_url, $image_url, $video_url ) ) {
				self::rollback_custom_video_save( $post_id, $legacy_snapshot, $db2_snapshot, $video_url, $target_oembed_snapshot );
				return false;
			}
		}

		$bridge = function_exists( 'fifu_db2_legacy_write_bridge' ) ? fifu_db2_legacy_write_bridge() : null;
		if ( $bridge instanceof Fifu_Db2_Legacy_Write_Bridge && method_exists( $bridge, 'handle_post_meta_change' ) ) {
			if ( ! $bridge->handle_post_meta_change( $post_id, 'fifu_custom_video_url', $video_url ) ) {
				self::rollback_custom_video_save( $post_id, $legacy_snapshot, $db2_snapshot, $video_url, $target_oembed_snapshot );
				return false;
			}
		}

		if ( class_exists( 'FIFU_Post_Meta_Updater' ) ) {
			if ( ! FIFU_Post_Meta_Updater::instance()->update_or_delete_with_status( $post_id, 'fifu_custom_video_url', $video_url ) ) {
				self::rollback_custom_video_save( $post_id, $legacy_snapshot, $db2_snapshot, $video_url, $target_oembed_snapshot );
				return false;
			}
		} elseif ( function_exists( 'fifu_update_or_delete' ) ) {
			fifu_update_or_delete( $post_id, 'fifu_custom_video_url', $video_url );
		}

		if ( ! self::custom_video_db2_matches( $post_id, $video_url, $image_url ) ) {
			self::rollback_custom_video_save( $post_id, $legacy_snapshot, $db2_snapshot, $video_url, $target_oembed_snapshot );
			return false;
		}

		return true;
	}

	private static function clear_conflicts_for_slider( int $post_id ): bool {
		return self::clear_db2_and_legacy_conflicts(
			$post_id,
			array( 'image', 'video', 'custom_video', 'audio' ),
			array( 'fifu_image_url', 'fifu_image_alt', 'fifu_list_url', 'fifu_list_alt', 'fifu_video_url', 'fifu_custom_video_url', 'fifu_list_video_url', 'fifu_audio_url' ),
			array( 'fifu_image_url_', 'fifu_image_alt_', 'fifu_video_url_' ),
			false,
			false
		);
	}

	private static function clear_conflicts_for_video_list( int $post_id ): bool {
		return self::clear_db2_and_legacy_conflicts(
			$post_id,
			array( 'slider', 'custom_video' ),
			array( 'fifu_slider_list_url', 'fifu_slider_list_alt', 'fifu_custom_video_url' ),
			array( 'fifu_slider_image_url_', 'fifu_slider_image_alt_' ),
			false,
			false
		);
	}

	private static function clear_conflicts_for_image_list( int $post_id ): bool {
		return self::clear_db2_and_legacy_conflicts(
			$post_id,
			array( 'slider' ),
			array( 'fifu_slider_list_url', 'fifu_slider_list_alt' ),
			array( 'fifu_slider_image_url_', 'fifu_slider_image_alt_' ),
			false,
			false
		);
	}

	private static function clear_db2_and_legacy_conflicts( int $post_id, array $db2_key_types, array $exact_meta_keys, array $prefixes, bool $delete_thumbnail_id, bool $delete_product_gallery ): bool {
		$manager = self::get_db2_manager_for_cleanup();
		if ( $manager instanceof Fifu_Db2_Manager ) {
			foreach ( $db2_key_types as $key_type ) {
				if ( method_exists( $manager, 'deletePostMappings' ) ) {
					try {
						$manager->deletePostMappings( $post_id, $key_type );
					} catch ( \Throwable $e ) {
						return false;
					}
				}

				if ( method_exists( $manager, 'deletePostAltMappings' ) && in_array( $key_type, array( 'image', 'slider' ), true ) ) {
					try {
						$manager->deletePostAltMappings( $post_id, $key_type );
					} catch ( \Throwable $e ) {
						return false;
					}
				}
			}
		}

		$keys = $exact_meta_keys;
		if ( $delete_thumbnail_id ) {
			$keys[] = '_thumbnail_id';
		}
		if ( $delete_product_gallery ) {
			$keys[] = '_product_image_gallery';
		}

		self::delete_legacy_post_meta_keys( $post_id, $keys, $prefixes );
		return true;
	}

	private static function clear_image_gallery_state( int $post_id ): void {
		$meta = get_post_meta( $post_id );
		if ( ! is_array( $meta ) ) {
			return;
		}

		foreach ( array_keys( $meta ) as $meta_key ) {
			if (
				strpos( $meta_key, 'fifu_image_url_' ) === 0
				|| strpos( $meta_key, 'fifu_image_alt_' ) === 0
				|| strpos( $meta_key, 'fifu_video_url_' ) === 0
				|| strpos( $meta_key, 'fifu_slider_image_url_' ) === 0
				|| strpos( $meta_key, 'fifu_slider_image_alt_' ) === 0
			) {
				fifu_delete_post_meta( $post_id, $meta_key );
			}
		}
	}

	private static function clear_video_gallery_state( int $post_id ): void {
		$meta = get_post_meta( $post_id );
		if ( ! is_array( $meta ) ) {
			return;
		}

		foreach ( array_keys( $meta ) as $meta_key ) {
			if ( 0 === strpos( (string) $meta_key, 'fifu_video_url_' ) && 'fifu_video_url' !== $meta_key ) {
				fifu_delete_post_meta( $post_id, $meta_key );
			}
		}
	}

	public static function set_custom_video_with_poster( int $post_id, $video_url, $image_url, ?string $alt = null, bool $preserve_inactive_media = false ): bool {
		try {
			$post_id = (int) $post_id;
			[ $normalized_video, $normalized_image ] = self::normalize_custom_video_input( $video_url . '\\' . $image_url );
			if ( $normalized_video === null ) {
				return false;
			}

			$normalized_image = self::normalize_single_image_url( $image_url, true );
			if ( $normalized_image === null ) {
				return false;
			}

			if ( ! self::save_custom_video_db2_state( $post_id, $normalized_video, $normalized_image ) ) {
				return false;
			}

			if ( ! $preserve_inactive_media && ! self::clear_conflicts_for_custom_video( $post_id, false ) ) {
				return false;
			}

			self::sync_post_media( $post_id );
			return true;
		} catch ( \Throwable $e ) {
			error_log( $e->getMessage() );
			return false;
		}
	}

	public static function set_custom_video( int $post_id, $video_url, bool $preserve_inactive_media = false ): bool {
		try {
			$post_id = (int) $post_id;
			[ $normalized_video, $normalized_image ] = self::normalize_custom_video_input( $video_url );
			if ( $normalized_video === null ) {
				return false;
			}

			if ( ! self::save_custom_video_db2_state( $post_id, $normalized_video, $normalized_image ) ) {
				return false;
			}

			if ( ! $preserve_inactive_media && ! self::clear_conflicts_for_custom_video( $post_id, false ) ) {
				return false;
			}

			self::sync_post_media( $post_id );
			return true;
		} catch ( \Throwable $e ) {
			error_log( $e->getMessage() );
			return false;
		}
	}

	/**
	 * Associate a developer-provided video URL with a post and refresh media.
	 *
	 * @param int    $post_id   Post ID.
	 * @param string $video_url Remote video URL.
	 * @param bool   $force_featured_attachment_sync Whether to bypass generic post-save suppression while syncing the featured attachment.
	 * @return bool True on success, false on failure.
	 */
	public static function set_video( int $post_id, $video_url, bool $force_featured_attachment_sync = false, bool $preserve_inactive_media = false ): bool {
		try {
			$post_id = (int) $post_id;
			$raw_video_input = trim( (string) $video_url );
			if ( $raw_video_input !== '' && strpos( $raw_video_input, '\\' ) !== false ) {
				return self::set_custom_video( $post_id, $raw_video_input, $preserve_inactive_media );
			}

			$normalized = self::normalize_single_video_url( $video_url );
			if ( $normalized === null ) {
				return false;
			}

			if ( $normalized === '' ) {
				if ( $preserve_inactive_media ) {
					return self::clear_featured_video_only( $post_id );
				}

				if ( ! self::clear_all_featured_media_state( $post_id ) ) {
					return false;
				}
				self::sync_post_media( $post_id, true );
				return true;
			}

			$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
			if ( ! $manager instanceof Fifu_Db2_Manager || ! method_exists( $manager, 'savePostUrl' ) ) {
				return false;
			}

			if ( ! $manager->savePostUrl( $post_id, 'video', 0, $normalized ) ) {
				return false;
			}

			$confirmed = $manager->getPostMapping( $post_id, 'video', 0 );
			$video_confirmed = is_array( $confirmed ) && trim( (string) ( $confirmed['url'] ?? '' ) ) === $normalized;
			if ( ! $video_confirmed ) {
				return false;
			}

			if ( class_exists( 'FIFU_Post_Meta_Updater' ) ) {
				FIFU_Post_Meta_Updater::instance()->update_or_delete_with_status( $post_id, 'fifu_video_url', $normalized );
			}

			if ( function_exists( 'fifu_db2_legacy_write_bridge' ) ) {
				$bridge = fifu_db2_legacy_write_bridge();
				if ( $bridge instanceof Fifu_Db2_Legacy_Write_Bridge && method_exists( $bridge, 'handle_post_meta_change' ) ) {
					$bridge->handle_post_meta_change( $post_id, 'fifu_video_url', $normalized );
				}
			}

			if ( ! $preserve_inactive_media && ! self::clear_conflicts_for_featured_video( $post_id ) ) {
				return false;
			}

			$video_mapping = $manager->getPostMapping( $post_id, 'video', 0 );
			$image_mapping = $manager->getPostMapping( $post_id, 'image', 0 );
			$custom_video_mapping = $manager->getPostMapping( $post_id, 'custom_video', 0 );
			$slider_mapping = $manager->getPostMapping( $post_id, 'slider', 0 );

			$has_effective_mapping = static function ( $mapping ): bool {
				return is_array( $mapping ) && trim( (string) ( $mapping['url'] ?? '' ) ) !== '';
			};

			if (
				! ( is_array( $video_mapping ) && trim( (string) ( $video_mapping['url'] ?? '' ) ) === $normalized ) ||
				( ! $preserve_inactive_media && (
					$has_effective_mapping( $image_mapping ) ||
					$has_effective_mapping( $custom_video_mapping ) ||
					$has_effective_mapping( $slider_mapping )
				) )
			) {
				return false;
			}

			if ( ! $preserve_inactive_media ) {
				self::delete_legacy_post_meta_exact_and_prefixed_raw(
					$post_id,
					array( 'fifu_video_url', 'fifu_list_video_url' ),
					array( 'fifu_video_url_' )
				);

				self::delete_legacy_post_meta_exact_and_prefixed_raw(
					$post_id,
					array( 'fifu_image_url', 'fifu_custom_video_url', 'fifu_list_url', 'fifu_list_alt', 'fifu_slider_list_url', 'fifu_slider_list_alt' ),
					array( 'fifu_image_url_', 'fifu_image_alt_', 'fifu_slider_image_url_', 'fifu_slider_image_alt_' )
				);
			}
			self::sync_post_media( $post_id, false, $force_featured_attachment_sync );
			clean_post_cache( $post_id );
			wp_cache_delete( $post_id, 'post_meta' );
			return true;
		} catch ( \Throwable $e ) {
			error_log( $e->getMessage() );
			return false;
		}
	}

	/**
	 * Store a list of developer supplied image URLs and keep attachments in sync.
	 *
	 * @param int    $post_id        Post ID.
	 * @param string $image_url_list Serialized image URL list.
	 * @param mixed  $image_alt_list  Serialized image ALT list.
	 * @param bool   $force_featured_attachment_sync Whether to bypass generic post-save suppression while syncing the featured attachment.
	 * @return bool True on success, false on failure.
	 */
	public static function set_image_list( int $post_id, $image_url_list, $image_alt_list = null, bool $force_featured_attachment_sync = false ): bool {
		try {
			$urls = self::normalize_image_list_input( $image_url_list );
			$alts = null !== $image_alt_list ? self::normalize_alt_list_input( $image_alt_list ) : null;
			if ( null !== $alts && count( $alts ) > count( $urls ) ) {
				$alts = array_slice( $alts, 0, count( $urls ) );
			}
			$url_snapshot = self::capture_db2_list_snapshot( $post_id, 'image', false );
			$alt_snapshot = self::capture_db2_list_snapshot( $post_id, 'image', true );
			$alts_confirmed = null === $alts;

			if ( ! FIFU_Post_Meta_Updater::instance()->update_or_delete_with_status( $post_id, 'fifu_list_url', empty( $urls ) ? null : implode( '|', $urls ) ) ) {
				self::restore_db2_list_snapshot( $post_id, 'image', false, $url_snapshot );
				self::restore_db2_list_snapshot( $post_id, 'image', true, $alt_snapshot );
				return false;
			}

			if ( ! self::db2_list_matches( $post_id, 'image', $urls, false ) ) {
				self::restore_db2_list_snapshot( $post_id, 'image', false, $url_snapshot );
				self::restore_db2_list_snapshot( $post_id, 'image', true, $alt_snapshot );
				return false;
			}

			if ( null !== $alts ) {
				if ( ! FIFU_Post_Meta_Updater::instance()->update_or_delete_with_status( $post_id, 'fifu_list_alt', empty( $alts ) ? null : implode( '|', $alts ) ) ) {
					self::restore_db2_list_snapshot( $post_id, 'image', true, $alt_snapshot );
				} elseif ( ! self::db2_list_matches( $post_id, 'image', $alts, true ) ) {
					self::restore_db2_list_snapshot( $post_id, 'image', true, $alt_snapshot );
				} else {
					$alts_confirmed = true;
				}
			}

			if ( empty( $urls ) ) {
				self::delete_all_db2_post_image_state( $post_id );
				self::promote_first_video_to_featured_after_image_removal( $post_id );
				self::delete_legacy_image_list_meta_after_confirmation( $post_id, $alts_confirmed, false );
				if ( ! self::has_featured_video_state( $post_id ) ) {
					delete_post_meta( $post_id, '_thumbnail_id' );
					delete_post_meta( $post_id, '_product_image_gallery' );
					clean_post_cache( $post_id );
					wp_cache_delete( $post_id, 'post_meta' );
				}
				self::sync_post_media( $post_id, false, $force_featured_attachment_sync );
				return true;
			}

			$has_featured_video = self::has_featured_video_state( $post_id );
			if ( ! empty( $urls ) ) {
				FIFU_Post_Meta_Updater::run_without_db2_sync_for_derived_image_list_meta(
					static function () use ( $post_id, $urls ): void {
						FIFU_Post_Meta_Updater::instance()->update_or_delete_with_status( $post_id, 'fifu_image_url', $urls[0] );
					}
				);
			}

			if ( null === $alts ) {
				self::reconcile_db2_image_alts_from_url_snapshot( $post_id, $url_snapshot, $alt_snapshot, $urls );
				self::delete_legacy_post_meta_exact_and_prefixed_raw(
					$post_id,
					array( 'fifu_image_alt', 'fifu_list_alt' ),
					array( 'fifu_image_alt_' )
				);
			}

			if ( ! self::clear_conflicts_for_image_list( $post_id ) ) {
				self::restore_db2_list_snapshot( $post_id, 'image', false, $url_snapshot );
				self::restore_db2_list_snapshot( $post_id, 'image', true, $alt_snapshot );
				return false;
			}

			if ( ! $has_featured_video ) {
				delete_post_meta( $post_id, '_thumbnail_id' );
				clean_post_cache( $post_id );
				wp_cache_delete( $post_id, 'post_meta' );
			}

			if ( $has_featured_video ) {
				$previous_gallery_request = $_REQUEST['fifu_wai_image_list_url'] ?? null;
				$_REQUEST['fifu_wai_image_list_url'] = implode( '|', $urls );
				try {
                    Fifu_Post_Attachment_Sync_Service::sync_gallery_attachments( $post_id, $force_featured_attachment_sync );
					Fifu_Post_Attachment_Sync_Service::sync_theme_property_images( $post_id );
				} finally {
					if ( null === $previous_gallery_request ) {
						unset( $_REQUEST['fifu_wai_image_list_url'] );
					} else {
						$_REQUEST['fifu_wai_image_list_url'] = $previous_gallery_request;
					}
				}
			} else {
				$previous_gallery_request = $_REQUEST['fifu_wai_image_list_url'] ?? null;
				$_REQUEST['fifu_wai_image_list_url'] = implode( '|', $urls );
				try {
					self::sync_post_media( $post_id, false, $force_featured_attachment_sync );
				} finally {
					if ( null === $previous_gallery_request ) {
						unset( $_REQUEST['fifu_wai_image_list_url'] );
					} else {
						$_REQUEST['fifu_wai_image_list_url'] = $previous_gallery_request;
					}
				}
			}
			self::delete_legacy_image_list_meta_after_confirmation( $post_id, $alts_confirmed, $has_featured_video );
			return true;
		} catch ( \Throwable $e ) {
			error_log( $e->getMessage() );
			return false;
		}
	}

	/**
	 * Store a list of developer supplied video URLs and keep attachments in sync.
	 *
	 * @param int    $post_id        Post ID.
	 * @param string $video_url_list Serialized video URL list.
	 * @param bool   $force_featured_attachment_sync Whether to bypass generic post-save suppression while syncing the featured attachment.
	 * @return bool True on success, false on failure.
	 */
	public static function set_video_list( int $post_id, $video_url_list, bool $force_featured_attachment_sync = false ): bool {
		try {
			$is_empty_video_list = trim( (string) $video_url_list ) === '';
			$urls = self::normalize_video_list_input( $video_url_list );
			$raw_list = empty( $urls ) ? '' : implode( '|', $urls );
			$existing_image_url = (string) Fifu_Post_Image_Url_Read_Service::get_image_url( $post_id );
			$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
			$image_db2_snapshot = $manager instanceof Fifu_Db2_Manager ? self::capture_db2_list_snapshot( $post_id, 'image', false ) : array();
			$image_db2_alt_snapshot = $manager instanceof Fifu_Db2_Manager ? self::capture_db2_list_snapshot( $post_id, 'image', true ) : array();
			$has_image_db2_snapshot = false;
			foreach ( $image_db2_snapshot as $row ) {
				if ( is_array( $row ) && trim( (string) ( $row['url'] ?? '' ) ) !== '' ) {
					$has_image_db2_snapshot = true;
					break;
				}
			}
			$preserve_image_db2_state = $has_image_db2_snapshot || self::has_existing_featured_image_slot( $post_id ) || self::should_preserve_existing_local_thumbnail( $post_id, $urls );
			$image_legacy_snapshot = $preserve_image_db2_state ? self::snapshot_legacy_image_state( $post_id ) : array();

			if ( empty( $urls ) ) {
				$attachment_ids = self::collect_featured_media_attachment_ids( $post_id );
				$existing_video_urls = self::get_existing_video_urls_for_video_list_clear( $post_id );
				$video_thumbnail_urls = self::resolve_video_thumbnail_urls( $existing_video_urls );
				$has_existing_image_list = self::has_real_image_state_excluding_video_thumbnails( $post_id, $video_thumbnail_urls );
				if ( ! $has_existing_image_list ) {
					self::delete_video_only_image_thumbnail_state( $post_id, $video_thumbnail_urls );
				}
				if ( $is_empty_video_list ) {
					fifu_dev_clear_fifu_thumbnail_if_no_image_media( $post_id );
				}
				if ( ! self::clear_conflicts_for_video_list( $post_id ) ) {
					return false;
				}
				self::delete_all_db2_post_video_state( $post_id );
				self::delete_legacy_video_list_meta_after_confirmation( $post_id, $urls );
				self::remove_video_thumbnail_attachment_references(
					$post_id,
					$video_thumbnail_urls,
					$attachment_ids,
					true
				);
				if ( $has_existing_image_list ) {
					self::promote_first_image_to_featured_after_video_removal( $post_id );
					self::sync_post_media( $post_id, false, $force_featured_attachment_sync );
					self::remove_current_thumbnail_from_gallery( $post_id );
					return true;
				} else {
					self::delete_all_db2_post_image_state( $post_id );
					self::delete_featured_media_attachments( $post_id, $attachment_ids );
					self::remove_video_thumbnail_attachment_references(
						$post_id,
						$video_thumbnail_urls,
						$attachment_ids,
						true
					);
					self::delete_fifu_managed_attachment_references( $post_id, $attachment_ids );
					self::clear_video_thumbnail_wp_attachment_state( $post_id, $video_thumbnail_urls, $attachment_ids );
					delete_post_meta( $post_id, '_thumbnail_id' );
					delete_post_meta( $post_id, '_product_image_gallery' );
					clean_post_cache( $post_id );
					wp_cache_delete( $post_id, 'posts' );
					wp_cache_delete( $post_id, 'post_meta' );
					return true;
				}
			}

			$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
			if ( ! $manager instanceof Fifu_Db2_Manager ) {
				return false;
			}

			if ( ! self::clear_conflicts_for_video_list( $post_id ) ) {
				return false;
			}
			$bridge = function_exists( 'fifu_db2_legacy_write_bridge' ) ? fifu_db2_legacy_write_bridge() : null;
			if ( ! $bridge instanceof Fifu_Db2_Legacy_Write_Bridge || ! method_exists( $bridge, 'handle_post_meta_change' ) ) {
				return false;
			}

			if ( ! $bridge->handle_post_meta_change( $post_id, 'fifu_list_video_url', $raw_list ) ) {
				return false;
			}

			FIFU_Post_Meta_Updater::run_without_db2_sync_for_derived_video_list_meta(
				static function () use ( $post_id, $raw_list ): void {
					FIFU_Post_Meta_Updater::instance()->update_or_delete_with_status( $post_id, 'fifu_list_video_url', $raw_list );
				}
			);

			if ( ! self::db2_video_list_matches( $post_id, $urls ) ) {
				return false;
			}
			$skip_featured_attachment_sync = false;
			$used_video_only_fake_attachments = false;
			if ( ! $preserve_image_db2_state ) {
				$thumbnail_urls = self::resolve_complete_video_thumbnail_list( $urls );
				self::delete_all_db2_post_image_state( $post_id );
				self::delete_legacy_image_list_meta_after_confirmation( $post_id, true, true );
				if ( null === $thumbnail_urls ) {
					$skip_featured_attachment_sync = true;
				}
			}
			if ( $preserve_image_db2_state && $manager instanceof Fifu_Db2_Manager ) {
				self::restore_db2_list_snapshot( $post_id, 'image', false, $image_db2_snapshot );
				self::restore_db2_list_snapshot( $post_id, 'image', true, $image_db2_alt_snapshot );
				self::restore_legacy_image_state( $post_id, $image_legacy_snapshot );
			}
			$has_existing_image_featured = '' !== (string) Fifu_Post_Image_Url_Read_Service::get_image_url( $post_id );
			if ( ! $preserve_image_db2_state && null !== $thumbnail_urls ) {
				$has_existing_image_featured = false;
			}
			if ( $has_existing_image_featured ) {
				self::persist_featured_image_legacy_state( $post_id, $existing_image_url );
				$previous_gallery_request = $_REQUEST['fifu_wai_video_list_url'] ?? null;
				$_REQUEST['fifu_wai_video_list_url'] = $raw_list;
				try {
                    Fifu_Post_Attachment_Sync_Service::sync_gallery_attachments( $post_id, $force_featured_attachment_sync );
					Fifu_Post_Attachment_Sync_Service::sync_theme_property_images( $post_id );
				} finally {
					if ( null === $previous_gallery_request ) {
						unset( $_REQUEST['fifu_wai_video_list_url'] );
					} else {
						$_REQUEST['fifu_wai_video_list_url'] = $previous_gallery_request;
					}
				}
				self::remove_current_thumbnail_from_gallery( $post_id );
			} elseif ( self::should_preserve_existing_local_thumbnail( $post_id, $urls ) ) {
				$previous_gallery_request = $_REQUEST['fifu_wai_video_list_url'] ?? null;
				$_REQUEST['fifu_wai_video_list_url'] = $raw_list;
				try {
                    Fifu_Post_Attachment_Sync_Service::sync_gallery_attachments( $post_id, $force_featured_attachment_sync );
					Fifu_Post_Attachment_Sync_Service::sync_theme_property_images( $post_id );
				} finally {
					if ( null === $previous_gallery_request ) {
						unset( $_REQUEST['fifu_wai_video_list_url'] );
					} else {
						$_REQUEST['fifu_wai_video_list_url'] = $previous_gallery_request;
					}
				}
				self::remove_current_thumbnail_from_gallery( $post_id );
			} else {
				if ( $skip_featured_attachment_sync ) {
					$previous_gallery_request = $_REQUEST['fifu_wai_video_list_url'] ?? null;
					$_REQUEST['fifu_wai_video_list_url'] = $raw_list;
					try {
                        Fifu_Post_Attachment_Sync_Service::sync_gallery_attachments( $post_id, $force_featured_attachment_sync );
						Fifu_Post_Attachment_Sync_Service::sync_theme_property_images( $post_id );
					} finally {
						if ( null === $previous_gallery_request ) {
							unset( $_REQUEST['fifu_wai_video_list_url'] );
						} else {
							$_REQUEST['fifu_wai_video_list_url'] = $previous_gallery_request;
						}
					}
				} elseif ( ! $preserve_image_db2_state && null !== $thumbnail_urls ) {
					self::sync_post_media( $post_id, false, $force_featured_attachment_sync );
					self::ensure_video_only_fake_attachments( $post_id, $urls );
					$used_video_only_fake_attachments = true;
				} else {
					self::sync_post_media( $post_id, false, $force_featured_attachment_sync );
				}
				if ( $skip_featured_attachment_sync ) {
					delete_post_thumbnail( $post_id );
					self::delete_all_db2_post_image_state( $post_id );
					delete_post_meta( $post_id, 'fifu_image_url' );
					delete_post_meta( $post_id, 'fifu_image_alt' );
					delete_post_meta( $post_id, 'fifu_image_alt_0' );
				}
				self::remove_current_thumbnail_from_gallery( $post_id );
			}
			if ( ! $preserve_image_db2_state && ! $used_video_only_fake_attachments ) {
				self::ensure_video_only_fake_attachments( $post_id, $urls );
			}
			if ( $preserve_image_db2_state && $manager instanceof Fifu_Db2_Manager ) {
				self::restore_db2_list_snapshot( $post_id, 'image', false, $image_db2_snapshot );
				self::restore_db2_list_snapshot( $post_id, 'image', true, $image_db2_alt_snapshot );
				self::restore_legacy_image_state( $post_id, $image_legacy_snapshot );
			}
			self::delete_legacy_video_list_meta_after_confirmation( $post_id, $urls );
			return true;
		} catch ( \Throwable $e ) {
			error_log( $e->getMessage() );
			return false;
		}
	}

	/**
	 * Persist slider entries provided by a developer and refresh attachments.
	 *
	 * @param int    $post_id  Post ID.
	 * @param string $url_list Serialized slider URL list.
	 * @param string $alt_list Serialized slider alt text list.
	 * @param bool   $force_featured_attachment_sync Whether to bypass generic post-save suppression while syncing the featured attachment.
	 * @return bool True on success, false on failure.
	 */
	public static function set_slider( int $post_id, $url_list, $alt_list, bool $force_featured_attachment_sync = false ): bool {
		try {
			$urls = self::normalize_image_list_input( $url_list );
			$alts = self::normalize_alt_list_input( $alt_list );
			if ( count( $alts ) > count( $urls ) ) {
				$alts = array_slice( $alts, 0, count( $urls ) );
			}
			FIFU_Post_Meta_Updater::run_without_db2_sync_for_derived_slider_meta( static function () use ( $post_id, $urls, $alts ): void {
				self::persist_list_source_meta( $post_id, 'fifu_slider_list_url', $urls );
				self::persist_list_source_meta( $post_id, 'fifu_slider_list_alt', $alts );
			} );
			if ( ! self::db2_list_matches( $post_id, 'slider', $urls, false ) || ! self::db2_list_matches( $post_id, 'slider', $alts, true ) ) {
				return false;
			}
			$existing_thumbnail_id = (int) get_post_thumbnail_id( $post_id );
			if ( empty( $urls ) ) {
				if ( ! self::clear_all_featured_media_state( $post_id ) ) {
					return false;
				}

				self::sync_post_media( $post_id, false, $force_featured_attachment_sync );
				self::delete_legacy_slider_meta_after_confirmation( $post_id, $urls, $alts );
				return true;
			}

			if ( ! self::clear_conflicts_for_slider( $post_id ) ) {
				return false;
			}

			$previous_slider_request = $_REQUEST['fifu_wai_gallery_only_slider_list_url'] ?? null;
			$_REQUEST['fifu_wai_gallery_only_slider_list_url'] = implode( '|', $urls );
			try {
				Fifu_Post_Attachment_Sync_Service::sync_featured_attachment( $post_id, $force_featured_attachment_sync );
                Fifu_Post_Attachment_Sync_Service::sync_gallery_attachments( $post_id, $force_featured_attachment_sync );
				Fifu_Post_Attachment_Sync_Service::sync_theme_property_images( $post_id );
			} finally {
				if ( null === $previous_slider_request ) {
					unset( $_REQUEST['fifu_wai_gallery_only_slider_list_url'] );
				} else {
					$_REQUEST['fifu_wai_gallery_only_slider_list_url'] = $previous_slider_request;
				}
			}
			if ( 0 === (int) get_post_thumbnail_id( $post_id ) ) {
				$first_url = (string) ( $urls[0] ?? '' );
				$first_alt = $alts[0] ?? null;
				$attachment_repo = new Fifu_Attachment_Repository();
				$new_att_id = $attachment_repo->find_attachment_id( $post_id, $first_url, false );
				if ( ! $new_att_id ) {
					$factory = new Fifu_Attachment_Factory();
					$new_att_id = $factory->create_attachment_for_url( $first_url, $first_alt, $post_id );
					if ( $new_att_id ) {
						Fifu_Attachment_Update_Service::initialize_remote_attachment( (int) $new_att_id, $first_url, $first_alt );
					}
				} else {
					Fifu_Attachment_Update_Service::update_attachment_alt_only( (int) $new_att_id, $first_alt );
				}

				if ( $new_att_id && Fifu_Attachment_Update_Service::has_remote_file_metadata( (int) $new_att_id, $first_url ) ) {
					set_post_thumbnail( $post_id, (int) $new_att_id );
					if (
						$existing_thumbnail_id > 0
						&& $existing_thumbnail_id !== (int) $new_att_id
						&& $existing_thumbnail_id !== (int) get_option( 'fifu_default_attach_id' )
						&& Fifu_Attachment_Update_Service::is_fifu_owned( $existing_thumbnail_id )
					) {
						self::delete_owned_remote_attachment_if_unreferenced( $existing_thumbnail_id, $post_id );
					}
				} elseif ( $new_att_id ) {
					return false;
				}
			}
			self::delete_legacy_slider_meta_after_confirmation( $post_id, $urls, $alts );
			return true;
		} catch ( \Throwable $e ) {
			error_log( $e->getMessage() );
			return false;
		}
	}

	/**
	 * Assign a developer image URL to a term and refresh its attachments.
	 *
	 * @param int    $term_id   Term ID.
	 * @param string $image_url Remote image URL.
	 * @return bool True on success, false on failure.
	 */
	public static function set_category_image( int $term_id, $image_url ): bool {
		try {
			$term_id = (int) $term_id;
			$normalized = self::normalize_single_category_url( $image_url );
			if ( $normalized === null ) {
				return false;
			}

			if ( $normalized === '' ) {
				if ( ! self::clear_category_image_state( $term_id ) ) {
					return false;
				}

				self::sync_category_media( $term_id );
				delete_term_meta( $term_id, 'thumbnail_id' );
				return true;
			}

			$current_url = self::get_current_category_image_url( $term_id );
			$current_alt = self::get_current_category_image_alt( $term_id );
			$final_url = fifu_convert( $normalized );
			$current_normalized_url = self::normalize_single_category_url( $current_url );
			$preserve_alt = $current_normalized_url !== null && fifu_convert( $current_normalized_url ) === $final_url
				&& ! self::is_effectively_empty_alt_value( $current_alt )
				? trim( $current_alt )
				: null;

			$updater = class_exists( 'FIFU_Term_Meta_Updater', false ) ? FIFU_Term_Meta_Updater::instance() : null;
			if ( ! $updater instanceof FIFU_Term_Meta_Updater ) {
				return false;
			}

			$updater->update_or_delete_term( $term_id, 'fifu_image_url', $final_url );
			$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
			if ( ! $manager instanceof Fifu_Db2_Manager ) {
				return false;
			}

			$confirmed = $manager->getTermMapping( $term_id, 'image' );
			if ( ! is_array( $confirmed ) || trim( (string) ( $confirmed['url'] ?? '' ) ) !== $final_url ) {
				return false;
			}

			if ( $preserve_alt !== null ) {
				$updater->update_or_delete_term( $term_id, 'fifu_image_alt', $preserve_alt );
				$confirmed_alt = $manager->getTermAltMapping( $term_id, 'image' );
				$confirmed_alt_value = is_array( $confirmed_alt ) ? trim( (string) ( $confirmed_alt['alt'] ?? $confirmed_alt['value'] ?? '' ) ) : '';
				if ( $confirmed_alt_value !== $preserve_alt ) {
					return false;
				}
				self::delete_legacy_term_meta_raw( $term_id, 'fifu_image_alt' );
			} elseif ( method_exists( $manager, 'deleteTermAltMappings' ) ) {
				$manager->deleteTermAltMappings( $term_id, 'image' );
				$updater->update_or_delete_term( $term_id, 'fifu_image_alt', '' );
			}

			if ( method_exists( $manager, 'deleteTermMappings' ) ) {
				$manager->deleteTermMappings( $term_id, 'video' );
				$manager->deleteTermMappings( $term_id, 'custom_video' );
			}
			if ( method_exists( $manager, 'deleteTermAltMappings' ) ) {
				$manager->deleteTermAltMappings( $term_id, 'video' );
				$manager->deleteTermAltMappings( $term_id, 'custom_video' );
			}

			self::delete_category_video_state( $term_id );
			self::delete_legacy_term_meta_raw( $term_id, 'fifu_custom_video_url' );
			self::delete_legacy_term_meta_raw( $term_id, 'fifu_image_url' );
			self::delete_legacy_term_meta_raw( $term_id, 'fifu_image_alt' );

			self::sync_category_media( $term_id );
			return true;
		} catch ( \Throwable $e ) {
			error_log( $e->getMessage() );
			return false;
		}
	}

	/**
	 * Assign a developer video URL to a term and refresh its attachments.
	 *
	 * @param int    $term_id   Term ID.
	 * @param string $video_url Remote video URL.
	 * @return bool True on success, false on failure.
	 */
	public static function set_category_video( int $term_id, $video_url, bool $sync_media = true ): bool {
		try {
			$term_id = (int) $term_id;
			$normalized = self::normalize_single_category_url( $video_url );
			if ( $normalized === null ) {
				return false;
			}

			$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
			if ( ! $manager instanceof Fifu_Db2_Manager ) {
				return false;
			}

			if ( $normalized === '' ) {
				$current_thumbnail_id = (int) get_term_meta( $term_id, 'thumbnail_id', true );
				if ( method_exists( $manager, 'deleteTermMappings' ) ) {
					$manager->deleteTermMappings( $term_id, 'video' );
					$manager->deleteTermMappings( $term_id, 'custom_video' );
					$manager->deleteTermMappings( $term_id, 'image' );
				}
				if ( method_exists( $manager, 'deleteTermAltMappings' ) ) {
					$manager->deleteTermAltMappings( $term_id, 'video' );
					$manager->deleteTermAltMappings( $term_id, 'custom_video' );
					$manager->deleteTermAltMappings( $term_id, 'image' );
				}
				self::delete_category_video_state( $term_id );
				self::delete_category_custom_video_state( $term_id );
				self::delete_category_image_state( $term_id );
				delete_term_meta( $term_id, 'thumbnail_id' );
				if ( $current_thumbnail_id > 0 && (int) get_term_meta( $term_id, 'product_attribute_image', true ) === $current_thumbnail_id ) {
					delete_term_meta( $term_id, 'product_attribute_image' );
				}
				self::cleanup_category_thumbnail_attachment_if_owned( $term_id, $current_thumbnail_id );
				return true;
			}

			$legacy_snapshot = array(
				'fifu_video_url' => self::snapshot_term_meta_state( $term_id, 'fifu_video_url' ),
				'fifu_image_url' => self::snapshot_term_meta_state( $term_id, 'fifu_image_url' ),
				'fifu_image_alt' => self::snapshot_term_meta_state( $term_id, 'fifu_image_alt' ),
				'fifu_custom_video_url' => self::snapshot_term_meta_state( $term_id, 'fifu_custom_video_url' ),
			);
			$db2_snapshot = self::snapshot_db2_category_video_state( $term_id );

			if ( ! self::save_category_video_db2_state( $term_id, $normalized, $manager ) ) {
				self::restore_db2_category_video_state( $term_id, $db2_snapshot );
				self::restore_category_video_legacy_state( $term_id, $legacy_snapshot );
				return false;
			}

			if ( ! self::delete_category_image_state( $term_id ) || ! self::delete_category_custom_video_state( $term_id ) ) {
				self::restore_db2_category_video_state( $term_id, $db2_snapshot );
				self::restore_category_video_legacy_state( $term_id, $legacy_snapshot );
				return false;
			}

			self::clear_category_video_legacy_state( $term_id );

			$confirmed = $manager->getTermMapping( $term_id, 'video' );
			$image_mapping = $manager->getTermMapping( $term_id, 'image' );
			$custom_video_mapping = $manager->getTermMapping( $term_id, 'custom_video' );

			$has_effective_mapping = static function ( $mapping ): bool {
				return is_array( $mapping ) && trim( (string) ( $mapping['url'] ?? '' ) ) !== '';
			};

			if (
				! ( is_array( $confirmed ) && trim( (string) ( $confirmed['url'] ?? '' ) ) === $normalized ) ||
				self::term_meta_exists( $term_id, 'fifu_video_url' ) ||
				$has_effective_mapping( $image_mapping ) ||
				$has_effective_mapping( $custom_video_mapping )
			) {
				self::restore_db2_category_video_state( $term_id, $db2_snapshot );
				self::restore_category_video_legacy_state( $term_id, $legacy_snapshot );
				return false;
			}

			if ( $sync_media ) {
				self::sync_category_media( $term_id );
			}
			return true;
		} catch ( \Throwable $e ) {
			error_log( $e->getMessage() );
			return false;
		}
	}

	/**
	 * Associate a category custom video with a poster image and refresh media.
	 *
	 * @param int    $term_id Term ID.
	 * @param string $video_url Custom or local video URL.
	 * @param string $poster_url Poster image URL.
	 * @return bool True on success, false on failure.
	 */
	public static function set_category_custom_video_with_poster( int $term_id, $video_url, $poster_url, bool $sync_media = true ): bool {
		try {
			$term_id = (int) $term_id;
			$normalized_video = self::normalize_single_category_url( $video_url );
			$normalized_poster = self::normalize_single_category_url( $poster_url );
			if ( $normalized_video === null || $normalized_poster === null || $normalized_video === '' || $normalized_poster === '' ) {
				return false;
			}

			$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
			if ( ! $manager instanceof Fifu_Db2_Manager ) {
				return false;
			}

			$legacy_snapshot = array(
				'fifu_video_url' => self::snapshot_term_meta_state( $term_id, 'fifu_video_url' ),
				'fifu_custom_video_url' => self::snapshot_term_meta_state( $term_id, 'fifu_custom_video_url' ),
				'fifu_image_url' => self::snapshot_term_meta_state( $term_id, 'fifu_image_url' ),
				'fifu_image_alt' => self::snapshot_term_meta_state( $term_id, 'fifu_image_alt' ),
			);
			$db2_snapshot = self::snapshot_db2_category_custom_video_state( $term_id );

			if ( ! method_exists( $manager, 'saveTermUrl' ) || ! method_exists( $manager, 'getTermMapping' ) ) {
				return false;
			}

			if ( ! $manager->saveTermUrl( $term_id, 'custom_video', $normalized_video ) ) {
				self::restore_db2_category_custom_video_state( $term_id, $db2_snapshot );
				self::restore_category_video_legacy_state( $term_id, $legacy_snapshot );
				return false;
			}

			$confirmed = $manager->getTermMapping( $term_id, 'custom_video' );
			if ( ! is_array( $confirmed ) || trim( (string) ( $confirmed['url'] ?? '' ) ) !== $normalized_video ) {
				self::restore_db2_category_custom_video_state( $term_id, $db2_snapshot );
				self::restore_category_video_legacy_state( $term_id, $legacy_snapshot );
				return false;
			}

			if ( ! Fifu_Video_Oembed_Service::instance()->upsert_oembed( $normalized_video, $normalized_poster, $normalized_video ) ) {
				self::restore_db2_category_custom_video_state( $term_id, $db2_snapshot );
				self::restore_category_video_legacy_state( $term_id, $legacy_snapshot );
				return false;
			}

			if ( ! self::delete_category_image_state( $term_id ) || ! self::delete_category_video_state( $term_id ) ) {
				self::restore_db2_category_custom_video_state( $term_id, $db2_snapshot );
				self::restore_category_video_legacy_state( $term_id, $legacy_snapshot );
				return false;
			}

			self::delete_legacy_term_meta_raw_if_exists( $term_id, 'fifu_image_url' );
			self::delete_legacy_term_meta_raw_if_exists( $term_id, 'fifu_image_alt' );
			self::delete_legacy_term_meta_raw_if_exists( $term_id, 'fifu_video_url' );
			self::delete_legacy_term_meta_raw_if_exists( $term_id, 'fifu_custom_video_url' );

			if ( $sync_media ) {
				self::sync_category_media( $term_id );
			}
			return true;
		} catch ( \Throwable $e ) {
			error_log( $e->getMessage() );
			return false;
		}
	}

	/**
	 * Synchronize post related attachments.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	private static function sync_post_media( int $post_id, bool $preserve_existing_local_thumbnail = false, bool $force_featured_attachment_sync = false ): void {
		if ( ! $preserve_existing_local_thumbnail ) {
			Fifu_Post_Attachment_Sync_Service::sync_featured_attachment( $post_id, $force_featured_attachment_sync );
		}
		Fifu_Post_Attachment_Sync_Service::sync_gallery_attachments( $post_id, $force_featured_attachment_sync );
		Fifu_Post_Attachment_Sync_Service::sync_theme_property_images( $post_id );
	}

	private static function should_preserve_existing_local_thumbnail( int $post_id, array $urls ): bool {
		if ( empty( $urls ) ) {
			return false;
		}

		if ( ! function_exists( 'get_post_thumbnail_id' ) ) {
			return false;
		}

		$thumbnail_id = (int) get_post_thumbnail_id( $post_id );
		if ( $thumbnail_id <= 0 ) {
			return false;
		}

		$thumbnail_post = get_post( $thumbnail_id );
		if ( ! $thumbnail_post || 'attachment' !== (string) $thumbnail_post->post_type ) {
			return false;
		}

		if ( ! class_exists( 'Fifu_Post_Meta_Utils', false ) || ! method_exists( 'Fifu_Post_Meta_Utils', 'has_local_featured_image' ) ) {
			return false;
		}

		return Fifu_Post_Meta_Utils::has_local_featured_image( $post_id );
	}

	private static function remove_current_thumbnail_from_gallery( int $post_id ): void {
		$thumbnail_id = (int) get_post_thumbnail_id( $post_id );
		if ( $thumbnail_id <= 0 ) {
			return;
		}

		$gallery_csv = trim( (string) get_post_meta( $post_id, '_product_image_gallery', true ) );
		if ( '' === $gallery_csv ) {
			return;
		}

		$gallery_ids = array_values( array_filter(
			array_map( 'intval', explode( ',', $gallery_csv ) ),
			static fn( int $attachment_id ): bool => $attachment_id > 0 && $attachment_id !== $thumbnail_id
		) );

		$new_gallery_csv = implode( ',', $gallery_ids );
		if ( $new_gallery_csv === $gallery_csv ) {
			return;
		}

		if ( '' === $new_gallery_csv ) {
			delete_post_meta( $post_id, '_product_image_gallery' );
		} else {
			update_post_meta( $post_id, '_product_image_gallery', $new_gallery_csv );
		}

		clean_post_cache( $post_id );
		wp_cache_delete( $post_id, 'post_meta' );
	}

	private static function get_attachment_remote_file_url( int $attachment_id ): string {
		if ( $attachment_id <= 0 ) {
			return '';
		}

		$remote_file = trim( (string) get_post_meta( $attachment_id, '_wp_attached_file', true ) );
		if ( '' === $remote_file ) {
			$remote_file = trim( (string) get_post_field( 'post_content_filtered', $attachment_id ) );
		}

		if ( '' === $remote_file ) {
			return '';
		}

		return htmlspecialchars_decode( $remote_file, ENT_QUOTES );
	}

	private static function video_thumbnail_urls_match( string $actual_url, string $expected_url ): bool {
		$actual = trim( htmlspecialchars_decode( $actual_url, ENT_QUOTES ) );
		$expected = trim( htmlspecialchars_decode( $expected_url, ENT_QUOTES ) );
		if ( '' === $actual || '' === $expected ) {
			return false;
		}

		if ( $actual === $expected ) {
			return true;
		}

		if ( function_exists( 'fifu_convert' ) ) {
			$actual_converted = trim( (string) fifu_convert( $actual ) );
			$expected_converted = trim( (string) fifu_convert( $expected ) );
			if ( '' !== $actual_converted && $actual_converted === $expected ) {
				return true;
			}
			if ( '' !== $expected_converted && $actual === $expected_converted ) {
				return true;
			}
			if ( '' !== $actual_converted && '' !== $expected_converted && $actual_converted === $expected_converted ) {
				return true;
			}
		}

		if ( class_exists( 'Fifu_Attachment_Update_Service', false ) && method_exists( 'Fifu_Attachment_Update_Service', 'is_youtube_thumbnail_quality_fallback' ) ) {
			if ( Fifu_Attachment_Update_Service::is_youtube_thumbnail_quality_fallback( $actual, $expected ) ) {
				return true;
			}
			if ( Fifu_Attachment_Update_Service::is_youtube_thumbnail_quality_fallback( $expected, $actual ) ) {
				return true;
			}
		}

		return false;
	}

	private static function url_matches_video_thumbnail_set( string $url, array $video_thumbnail_urls ): bool {
		foreach ( array_keys( $video_thumbnail_urls ) as $candidate_url ) {
			if ( self::video_thumbnail_urls_match( $url, (string) $candidate_url ) ) {
				return true;
			}
		}

		return false;
	}

	private static function remove_video_thumbnail_attachment_references(
		int $post_id,
		array $video_thumbnail_urls,
		array $candidate_attachment_ids,
		bool $delete_owned_attachments
	): void {
		if ( empty( $video_thumbnail_urls ) ) {
			return;
		}

		$thumbnail_id = (int) get_post_meta( $post_id, '_thumbnail_id', true );
		if ( $thumbnail_id > 0 ) {
			$thumbnail_url = self::get_attachment_remote_file_url( $thumbnail_id );
			if ( '' !== $thumbnail_url && self::url_matches_video_thumbnail_set( $thumbnail_url, $video_thumbnail_urls ) ) {
				delete_post_thumbnail( $post_id );
				delete_post_meta( $post_id, '_thumbnail_id' );
			}
		}

		$gallery_csv = trim( (string) get_post_meta( $post_id, '_product_image_gallery', true ) );
		if ( '' !== $gallery_csv ) {
			$gallery_ids = array_values(
				array_filter(
					array_map( 'intval', explode( ',', $gallery_csv ) ),
					static fn( int $attachment_id ): bool => $attachment_id > 0
				)
			);
			$kept_gallery_ids = array();

			foreach ( $gallery_ids as $gallery_attachment_id ) {
				$gallery_url = self::get_attachment_remote_file_url( $gallery_attachment_id );
				if ( '' !== $gallery_url && self::url_matches_video_thumbnail_set( $gallery_url, $video_thumbnail_urls ) ) {
					continue;
				}

				$kept_gallery_ids[] = $gallery_attachment_id;
			}

			if ( $kept_gallery_ids !== $gallery_ids ) {
				if ( empty( $kept_gallery_ids ) ) {
					delete_post_meta( $post_id, '_product_image_gallery' );
				} else {
					update_post_meta( $post_id, '_product_image_gallery', implode( ',', $kept_gallery_ids ) );
				}
			}
		}

		if ( $delete_owned_attachments ) {
			$attachment_repo = self::get_attachment_repository_for_cleanup();
			foreach ( $candidate_attachment_ids as $attachment_id ) {
				$attachment_id = (int) $attachment_id;
				if ( $attachment_id <= 0 ) {
					continue;
				}

				if ( ! self::is_fifu_managed_attachment( $attachment_repo, $attachment_id, $post_id ) ) {
					continue;
				}

				$attachment_url = self::get_attachment_remote_file_url( $attachment_id );
				if ( '' === $attachment_url || ! self::url_matches_video_thumbnail_set( $attachment_url, $video_thumbnail_urls ) ) {
					continue;
				}

				self::delete_owned_remote_attachment_if_unreferenced( $attachment_id, $post_id );
			}
		}
		clean_post_cache( $post_id );
		wp_cache_delete( $post_id, 'post_meta' );
	}

	/**
	 * Normalize a developer-provided single image URL.
	 *
	 * @param mixed $image_url Raw input.
	 * @return string|null Empty string for delete, normalized URL for valid values, null when invalid.
	 */
	private static function normalize_single_image_url( $image_url, bool $convert = false ): ?string {
		if ( null === $image_url ) {
			return '';
		}

		$raw = trim( (string) $image_url );
		if ( '' === $raw ) {
			return '';
		}

		if ( ! self::is_valid_http_url( $raw ) ) {
			return null;
		}

		$sanitized = esc_url_raw( $raw );
		if ( '' === $sanitized ) {
			return null;
		}

		return $convert ? fifu_convert( $sanitized ) : $sanitized;
	}

	/**
	 * Normalize a pipe-delimited or newline-delimited list of URLs into ordered array values.
	 *
	 * @param mixed $value Raw input.
	 * @return string[]
	 */
	private static function normalize_list_input( $value ): array {
		if ( null === $value ) {
			return array();
		}

		$raw = trim( (string) $value );
		if ( '' === $raw ) {
			return array();
		}

		$entries = preg_split( '/\r\n|\r|\n|\|/', $raw );
		if ( ! is_array( $entries ) ) {
			return array();
		}

		$normalized = array();
		foreach ( $entries as $entry ) {
			$item = trim( (string) $entry );
			if ( '' === $item ) {
				continue;
			}

			if ( ! self::is_valid_http_url( $item ) ) {
				throw new \RuntimeException( 'Invalid URL in list input' );
			}
			$item = esc_url_raw( $item );
			if ( '' === $item || ! self::is_valid_http_url( $item ) ) {
				throw new \RuntimeException( 'Invalid URL in list input' );
			}

			$normalized[] = $item;
		}

		return $normalized;
	}

	private static function normalize_image_list_input( $value ): array {
		$normalized = array();
		foreach ( self::normalize_list_input( $value ) as $url ) {
			$converted = fifu_convert( $url );
			$converted = trim( (string) $converted );
			if ( '' === $converted || ! self::is_valid_http_url( $converted ) ) {
				throw new \RuntimeException( 'Invalid URL in list input' );
			}

			$normalized[] = esc_url_raw( $converted );
		}

		return $normalized;
	}

	private static function normalize_video_list_input( $value ): array {
		if ( null === $value ) {
			return array();
		}

		$raw = trim( (string) $value );
		if ( '' === $raw ) {
			return array();
		}

		$entries = preg_split( '/\r\n|\r|\n|\|/', $raw );
		if ( ! is_array( $entries ) ) {
			return array();
		}

		$normalized = array();

		foreach ( $entries as $entry ) {
			$item = trim( (string) $entry );

			if ( '' === $item ) {
				continue;
			}

			if ( false !== strpos( $item, '\\' ) ) {
				[ $video_url, $poster_url ] = self::normalize_custom_video_input( $item );

				if (
					null === $video_url
					|| null === $poster_url
					|| '' === trim( $poster_url )
				) {
					throw new \RuntimeException( 'Invalid custom video entry in list input' );
				}

				$normalized[] = $video_url . '\\' . $poster_url;
				continue;
			}

			$video_url = self::normalize_single_video_url( $item );
			if ( null === $video_url || '' === trim( $video_url ) ) {
				throw new \RuntimeException( 'Invalid URL in video list input' );
			}

			$normalized[] = $video_url;
		}

		return $normalized;
	}

	/**
	 * Normalize ALT list values while preserving positional pairing.
	 *
	 * @param mixed $value Raw input.
	 * @return string[]
	 */
	private static function normalize_alt_list_input( $value ): array {
		if ( null === $value ) {
			return array();
		}

		$raw = trim( (string) $value );
		if ( '' === $raw ) {
			return array();
		}

		$entries = preg_split( '/\r\n|\r|\n|\|/', $raw );
		if ( ! is_array( $entries ) ) {
			return array();
		}

		$normalized = array();
		foreach ( $entries as $entry ) {
			$item = trim( wp_strip_all_tags( (string) $entry ) );
			if ( '' === $item ) {
				$normalized[] = '';
				continue;
			}

			$lower = strtolower( $item );
			if ( in_array( $lower, array( 'null', 'undefined', 'http://null', 'https://null' ), true ) ) {
				$normalized[] = '';
				continue;
			}

			$normalized[] = $item;
		}

		return $normalized;
	}

	/**
	 * Persist list source meta through the updater without saving nulls.
	 *
	 * @param int      $post_id Post ID.
	 * @param string   $meta_key Meta key.
	 * @param string[] $values Normalized values.
	 * @return void
	 */
	private static function persist_list_source_meta( int $post_id, string $meta_key, array $values ): void {
		$value = empty( $values ) ? null : implode( '|', $values );
		FIFU_Post_Meta_Updater::instance()->update_or_delete( $post_id, $meta_key, $value );
	}

	/**
	 * Compare the DB2 list state with the normalized list input.
	 *
	 * @param int      $post_id Post ID.
	 * @param string   $key_type DB2 key type.
	 * @param string[] $values Expected values.
	 * @param bool     $is_alt Whether to compare alt rows.
	 * @return bool
	 */
	private static function db2_list_matches( int $post_id, string $key_type, array $values, bool $is_alt ): bool {
		if ( ! function_exists( 'fifu_db2_manager' ) || ! class_exists( 'Fifu_Db2_Manager', false ) ) {
			return true;
		}

		$manager = fifu_db2_manager();
		if ( ! $manager instanceof Fifu_Db2_Manager ) {
			return true;
		}

		$rows = $is_alt ? $manager->getPostAltMappings( $post_id, $key_type ) : $manager->getPostMappings( $post_id, $key_type );
		if ( ! is_array( $rows ) ) {
			return false;
		}

		$actual = array();
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$index = array_key_exists( 'key_index', $row ) ? (int) $row['key_index'] : count( $actual );
			$actual[ $index ] = $is_alt ? trim( wp_strip_all_tags( (string) ( $row['alt'] ?? '' ) ) ) : (string) ( $row['url'] ?? '' );
		}

		if ( $is_alt ) {
			$expected = array();
			foreach ( $values as $index => $value ) {
				$item = trim( wp_strip_all_tags( (string) $value ) );
				if ( '' === $item ) {
					continue;
				}
				$lower = strtolower( $item );
				if ( in_array( $lower, array( 'null', 'undefined', 'http://null', 'https://null' ), true ) ) {
					continue;
				}
				$expected[ (int) $index ] = $item;
			}

			ksort( $expected );
			ksort( $actual );
			return $expected === $actual;
		}

		return array_values( $values ) === array_values( $actual );
	}

	private static function db2_video_list_matches( int $post_id, array $urls ): bool {
		if (
			! function_exists( 'fifu_db2_manager' )
			|| ! class_exists( 'Fifu_Db2_Manager', false )
		) {
			return true;
		}

		$manager = fifu_db2_manager();
		if ( ! $manager instanceof Fifu_Db2_Manager ) {
			return true;
		}

		$expected_custom = array();
		$expected_normal = array();

		foreach ( $urls as $entry ) {
			$entry = trim( (string) $entry );

			if ( '' === $entry ) {
				continue;
			}

			if ( false !== strpos( $entry, '\\' ) ) {
				[ $video_url, $poster_url ] = self::normalize_custom_video_input( $entry );

				if (
					null === $video_url
					|| null === $poster_url
					|| '' === trim( $poster_url )
				) {
					return false;
				}

				$expected_custom[] = array(
					'video'  => $video_url,
					'poster' => $poster_url,
				);
				continue;
			}

			$expected_normal[] = $entry;
		}

		$normal_rows = $manager->getPostMappings( $post_id, 'video' );
		$custom_rows = $manager->getPostMappings( $post_id, 'custom_video' );

		if ( ! is_array( $normal_rows ) || ! is_array( $custom_rows ) ) {
			return false;
		}

		$sort_rows = static function ( array $rows ): array {
			$rows = array_values(
				array_filter(
					$rows,
					static function ( $row ): bool {
						return is_array( $row );
					}
				)
			);

			usort(
				$rows,
				static function ( array $left, array $right ): int {
					return ( (int) ( $left['key_index'] ?? 0 ) ) <=> ( (int) ( $right['key_index'] ?? 0 ) );
				}
			);

			return $rows;
		};

		$normal_rows = $sort_rows( $normal_rows );
		$custom_rows = $sort_rows( $custom_rows );

		if (
			count( $normal_rows ) !== count( $expected_normal )
			|| count( $custom_rows ) !== count( $expected_custom )
		) {
			return false;
		}

		foreach ( $expected_normal as $index => $expected_url ) {
			$actual_url = trim( (string) ( $normal_rows[ $index ]['url'] ?? '' ) );
			if ( $actual_url !== $expected_url ) {
				return false;
			}
		}

		if ( ! empty( $expected_custom ) && ! class_exists( 'Fifu_Video_Oembed_Service' ) ) {
			return false;
		}

		$repository = ! empty( $expected_custom ) ? Fifu_Video_Oembed_Service::instance()->get_repository() : null;

		foreach ( $expected_custom as $index => $expected ) {
			$actual_video = trim( (string) ( $custom_rows[ $index ]['url'] ?? '' ) );
			if ( $actual_video !== $expected['video'] ) {
				return false;
			}

			if ( ! is_object( $repository ) || ! method_exists( $repository, 'get_image_url_by_video_url' ) ) {
				return false;
			}

			$actual_poster = trim( (string) $repository->get_image_url_by_video_url( $expected['video'] ) );
			if ( $actual_poster !== $expected['poster'] ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Resolve a complete thumbnail list for video URLs.
	 *
	 * @param string[] $video_urls Video URLs.
	 * @return string[]|null Returns thumbnail URLs by index only when every video has a thumbnail.
	 */
	private static function resolve_complete_video_thumbnail_list( array $video_urls ): ?array {
		$thumbnail_urls = array();

		foreach ( $video_urls as $index => $video_url ) {
			$thumbnail_url = (string) ( Fifu_Video_Helper::get_thumbnail_large( $video_url ) ?? '' );
			if ( '' === trim( $thumbnail_url ) ) {
				return null;
			}

			$thumbnail_urls[ (int) $index ] = $thumbnail_url;
		}

		return $thumbnail_urls;
	}

	private static function ensure_video_only_fake_attachments( int $post_id, array $video_urls ): void {
		$thumbnail_ids = array();
		$attachment_repo = new Fifu_Attachment_Repository();
		$factory = new Fifu_Attachment_Factory();

		foreach ( $video_urls as $index => $video_url ) {
			$thumbnail_url = (string) ( Fifu_Video_Helper::get_thumbnail_large( $video_url ) ?? '' );
			if ( '' === $thumbnail_url ) {
				continue;
			}

			$attachment_id = $attachment_repo->find_attachment_id( $post_id, $thumbnail_url, false );
			if ( ! $attachment_id ) {
				$attachment_id = $factory->create_attachment_for_url( $thumbnail_url, null, $post_id );
				if ( $attachment_id ) {
					Fifu_Attachment_Update_Service::initialize_remote_attachment( (int) $attachment_id, $thumbnail_url, null );
				}
			}

			if ( $attachment_id ) {
				$thumbnail_ids[ (int) $index ] = (int) $attachment_id;
			}
		}

		if ( empty( $thumbnail_ids ) ) {
			return;
		}

		ksort( $thumbnail_ids );
		$thumbnail_ids = array_values( $thumbnail_ids );
		$featured_id = (int) ( $thumbnail_ids[0] ?? 0 );
		if ( $featured_id > 0 ) {
			set_post_thumbnail( $post_id, $featured_id );
			clean_post_cache( $featured_id );
			wp_cache_delete( $featured_id, 'post_meta' );
		}

		$gallery_ids = array_slice( $thumbnail_ids, 1 );
		if ( empty( $gallery_ids ) ) {
			delete_post_meta( $post_id, '_product_image_gallery' );
		} else {
			update_post_meta( $post_id, '_product_image_gallery', implode( ',', $gallery_ids ) );
		}

		clean_post_cache( $post_id );
		wp_cache_delete( $post_id, 'post_meta' );
	}

	private static function has_existing_featured_image_slot( int $post_id ): bool {
		$image_url = Fifu_Post_Image_Url_Read_Service::get_image_url( $post_id );
		if ( is_string( $image_url ) && trim( $image_url ) !== '' ) {
			return true;
		}

		if ( trim( (string) get_post_meta( $post_id, 'fifu_image_url', true ) ) !== '' ) {
			return true;
		}

		if ( function_exists( 'fifu_db2_manager' ) && class_exists( 'Fifu_Db2_Manager', false ) ) {
			$manager = fifu_db2_manager();
			if ( $manager instanceof Fifu_Db2_Manager && method_exists( $manager, 'getPostMapping' ) ) {
				$mapping = $manager->getPostMapping( $post_id, 'image', 0 );
				if ( is_array( $mapping ) && ! empty( $mapping['url'] ) ) {
					return true;
				}
			}
		}

		if (
			class_exists( 'Fifu_Post_Meta_Utils', false )
			&& method_exists( 'Fifu_Post_Meta_Utils', 'has_local_featured_image' )
			&& Fifu_Post_Meta_Utils::has_local_featured_image( $post_id )
		) {
			return true;
		}

		$thumbnail_id = (int) get_post_thumbnail_id( $post_id );
		if ( $thumbnail_id <= 0 ) {
			return false;
		}

		if ( class_exists( 'Fifu_Post_Meta_Utils', false ) && method_exists( 'Fifu_Post_Meta_Utils', 'is_remote_image' ) ) {
			return ! Fifu_Post_Meta_Utils::is_remote_image( $thumbnail_id );
		}

		return false;
	}

	private static function has_existing_image_list( int $post_id ): bool {
		if ( function_exists( 'fifu_db2_manager' ) && class_exists( 'Fifu_Db2_Manager', false ) ) {
			$manager = fifu_db2_manager();
			if ( $manager instanceof Fifu_Db2_Manager ) {
				if ( method_exists( $manager, 'getPostMappings' ) ) {
					$rows = $manager->getPostMappings( $post_id, 'image' );
					if ( is_array( $rows ) ) {
						foreach ( $rows as $row ) {
							if ( ! is_array( $row ) ) {
								continue;
							}

							if ( trim( (string) ( $row['url'] ?? '' ) ) !== '' ) {
								return true;
							}
						}
					}
				}

				if ( method_exists( $manager, 'getPostMapping' ) ) {
					$mapping = $manager->getPostMapping( $post_id, 'image', 0 );
					if ( is_array( $mapping ) && ! empty( $mapping['url'] ) ) {
						return true;
					}
				}
			}
		}

		$image_url_0 = Fifu_Post_Image_List_Read_Service::get_image_url( $post_id, 0 );
		if ( is_string( $image_url_0 ) && trim( $image_url_0 ) !== '' ) {
			return true;
		}

		$image_url = Fifu_Post_Image_Url_Read_Service::get_image_url( $post_id );
		if ( is_string( $image_url ) && trim( $image_url ) !== '' ) {
			return true;
		}

		if ( trim( (string) get_post_meta( $post_id, 'fifu_list_url', true ) ) !== '' ) {
			return true;
		}

		if ( trim( (string) get_post_meta( $post_id, 'fifu_image_url', true ) ) !== '' ) {
			return true;
		}

		return false;
	}

	private static function get_existing_video_urls_for_video_list_clear( int $post_id ): array {
		$video_urls = array();

		if ( function_exists( 'fifu_db2_manager' ) && class_exists( 'Fifu_Db2_Manager', false ) ) {
			$manager = fifu_db2_manager();
			if ( $manager instanceof Fifu_Db2_Manager && method_exists( $manager, 'getPostMappings' ) ) {
				$rows = $manager->getPostMappings( $post_id, 'video' );
				if ( is_array( $rows ) ) {
					$indexed_rows = array();
					foreach ( $rows as $row ) {
						if ( ! is_array( $row ) ) {
							continue;
						}

						$url = trim( (string) ( $row['url'] ?? '' ) );
						if ( '' === $url ) {
							continue;
						}

						$index = array_key_exists( 'key_index', $row ) ? (int) $row['key_index'] : count( $indexed_rows );
						$indexed_rows[ $index ] = $url;
					}

					if ( ! empty( $indexed_rows ) ) {
						ksort( $indexed_rows );
						return array_values( $indexed_rows );
					}
				}
			}
		}

		if ( class_exists( 'Fifu_Post_Video_List_Read_Service', false ) ) {
			$index = 0;
			while ( true ) {
				$url = (string) Fifu_Post_Video_List_Read_Service::get_video_url( $post_id, $index );
				$url = trim( $url );
				if ( '' === $url ) {
					break;
				}

				$video_urls[] = $url;
				$index++;
			}

			if ( ! empty( $video_urls ) ) {
				return $video_urls;
			}
		}

		$legacy_list = trim( (string) get_post_meta( $post_id, 'fifu_list_video_url', true ) );
		if ( '' !== $legacy_list ) {
			$video_urls = array_values( array_filter(
				array_map( 'trim', explode( '|', $legacy_list ) ),
				static fn( string $url ): bool => '' !== $url
			) );
		}

		if ( ! empty( $video_urls ) ) {
			return $video_urls;
		}

		$legacy_video = trim( (string) get_post_meta( $post_id, 'fifu_video_url', true ) );
		return '' === $legacy_video ? array() : array( $legacy_video );
	}

	private static function resolve_video_thumbnail_urls( array $video_urls ): array {
		$thumbnails = array();
		foreach ( $video_urls as $video_url ) {
			$thumbnail = trim( (string) ( Fifu_Video_Helper::get_thumbnail_large( $video_url ) ?? '' ) );
			if ( '' !== $thumbnail ) {
				$thumbnails[ $thumbnail ] = true;
				if ( function_exists( 'fifu_convert' ) ) {
					$converted = trim( (string) fifu_convert( $thumbnail ) );
					if ( '' !== $converted ) {
						$thumbnails[ $converted ] = true;
					}
				}
			}
		}

		return $thumbnails;
	}

	private static function has_real_image_state_excluding_video_thumbnails( int $post_id, array $video_thumbnail_urls ): bool {
		$thumbnail_set = $video_thumbnail_urls;

		if ( function_exists( 'fifu_db2_manager' ) && class_exists( 'Fifu_Db2_Manager', false ) ) {
			$manager = fifu_db2_manager();
			if ( $manager instanceof Fifu_Db2_Manager && method_exists( $manager, 'getPostMappings' ) ) {
				$rows = $manager->getPostMappings( $post_id, 'image' );
				if ( is_array( $rows ) ) {
					foreach ( $rows as $row ) {
						if ( ! is_array( $row ) ) {
							continue;
						}

						$url = trim( (string) ( $row['url'] ?? '' ) );
						if ( '' === $url ) {
							continue;
						}

						if ( ! self::url_matches_video_thumbnail_set( $url, $thumbnail_set ) ) {
							return true;
						}
					}
				}

				if ( method_exists( $manager, 'getPostMapping' ) ) {
					$mapping = $manager->getPostMapping( $post_id, 'image', 0 );
					if ( is_array( $mapping ) ) {
						$url = trim( (string) ( $mapping['url'] ?? '' ) );
						if ( '' !== $url && ! self::url_matches_video_thumbnail_set( $url, $thumbnail_set ) ) {
							return true;
						}
					}
				}
			}
		}

			$legacy_url = trim( (string) get_post_meta( $post_id, 'fifu_list_url', true ) );
		if ( '' !== $legacy_url ) {
			foreach ( array_map( 'trim', explode( '|', $legacy_url ) ) as $url ) {
				if ( '' !== $url && ! self::url_matches_video_thumbnail_set( $url, $thumbnail_set ) ) {
					return true;
				}
			}
		}

		foreach ( array( 'fifu_image_url', 'fifu_image_url_0' ) as $meta_key ) {
			$url = trim( (string) get_post_meta( $post_id, $meta_key, true ) );
			if ( '' !== $url && ! self::url_matches_video_thumbnail_set( $url, $thumbnail_set ) ) {
				return true;
			}
		}

		if (
			class_exists( 'Fifu_Post_Meta_Utils', false )
			&& method_exists( 'Fifu_Post_Meta_Utils', 'has_local_featured_image' )
			&& Fifu_Post_Meta_Utils::has_local_featured_image( $post_id )
		) {
			return true;
		}

		$thumbnail_id = (int) get_post_thumbnail_id( $post_id );
		if ( $thumbnail_id > 0 && class_exists( 'Fifu_Post_Meta_Utils', false ) && method_exists( 'Fifu_Post_Meta_Utils', 'is_remote_image' ) ) {
			return ! Fifu_Post_Meta_Utils::is_remote_image( $thumbnail_id );
		}

		return false;
	}

	private static function delete_video_only_image_thumbnail_state( int $post_id, array $video_thumbnail_urls ): void {
		if ( empty( $video_thumbnail_urls ) ) {
			return;
		}

		if ( ! function_exists( 'fifu_db2_manager' ) || ! class_exists( 'Fifu_Db2_Manager', false ) ) {
			return;
		}

		$manager = fifu_db2_manager();
		if ( ! $manager instanceof Fifu_Db2_Manager || ! method_exists( $manager, 'getPostMappings' ) ) {
			return;
		}

		$rows = $manager->getPostMappings( $post_id, 'image' );
		if ( ! is_array( $rows ) || empty( $rows ) ) {
			return;
		}

		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$url = trim( (string) ( $row['url'] ?? '' ) );
			$index = isset( $row['key_index'] ) ? (int) $row['key_index'] : null;
			if ( $url === '' || $index === null || ! self::url_matches_video_thumbnail_set( $url, $video_thumbnail_urls ) ) {
				continue;
			}

			if ( method_exists( $manager, 'deletePostMappings' ) ) {
				$manager->deletePostMappings( $post_id, 'image', $index );
			}
			if ( method_exists( $manager, 'deletePostAltMappings' ) ) {
				$manager->deletePostAltMappings( $post_id, 'image', $index );
			}
		}
	}

	private static function delete_legacy_image_list_meta_after_confirmation( int $post_id, bool $delete_alts, bool $delete_featured_image ): void {
		delete_post_meta( $post_id, 'fifu_list_url' );
		delete_post_meta( $post_id, 'fifu_image_url' );
		if ( $delete_alts ) {
			delete_post_meta( $post_id, 'fifu_list_alt' );
			if ( $delete_featured_image ) {
				delete_post_meta( $post_id, 'fifu_image_alt' );
			}
			foreach ( array_keys( get_post_meta( $post_id ) ) as $meta_key ) {
				if ( 0 === strpos( (string) $meta_key, 'fifu_image_alt_' ) ) {
					delete_post_meta( $post_id, $meta_key );
				}
			}
		}
		foreach ( array_keys( get_post_meta( $post_id ) ) as $meta_key ) {
			if ( 0 === strpos( (string) $meta_key, 'fifu_image_url_' ) ) {
				delete_post_meta( $post_id, $meta_key );
			}
		}
		delete_post_meta( $post_id, 'fifu_slider_list_url' );
		delete_post_meta( $post_id, 'fifu_slider_list_alt' );
		foreach ( array_keys( get_post_meta( $post_id ) ) as $meta_key ) {
			if ( 0 === strpos( (string) $meta_key, 'fifu_slider_image_url_' ) || 0 === strpos( (string) $meta_key, 'fifu_slider_image_alt_' ) ) {
				delete_post_meta( $post_id, $meta_key );
			}
		}

		if ( function_exists( 'fifu_db2_manager' ) && class_exists( 'Fifu_Db2_Manager', false ) ) {
			$manager = fifu_db2_manager();
			if ( $manager instanceof Fifu_Db2_Manager ) {
				if ( method_exists( $manager, 'deletePostMappings' ) ) {
					$manager->deletePostMappings( $post_id, 'slider' );
				}
				if ( method_exists( $manager, 'deletePostAltMappings' ) ) {
					$manager->deletePostAltMappings( $post_id, 'slider' );
				}
			}
		}
	}

	/**
	 * Capture a DB2 list snapshot for rollback.
	 *
	 * @param int $post_id Post ID.
	 * @param string $key_type DB2 key type.
	 * @param bool $is_alt Whether to capture alt rows.
	 * @return array<int,array<string,mixed>>
	 */
	private static function capture_db2_list_snapshot( int $post_id, string $key_type, bool $is_alt ): array {
		if ( ! function_exists( 'fifu_db2_manager' ) || ! class_exists( 'Fifu_Db2_Manager', false ) ) {
			return array();
		}

		$manager = fifu_db2_manager();
		if ( ! $manager instanceof Fifu_Db2_Manager ) {
			return array();
		}

		$rows = $is_alt ? $manager->getPostAltMappings( $post_id, $key_type ) : $manager->getPostMappings( $post_id, $key_type );
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Reconcile DB2 image alt rows after the URL list is updated without a new ALT list.
	 *
	 * @param int $post_id Post ID.
	 * @param array<int,array<string,mixed>> $url_snapshot Previous URL rows.
	 * @param array<int,array<string,mixed>> $alt_snapshot Previous ALT rows.
	 * @param string[] $new_urls Normalized URLs.
	 * @return void
	 */
	private static function reconcile_db2_image_alts_from_url_snapshot( int $post_id, array $url_snapshot, array $alt_snapshot, array $new_urls ): void {
		$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
		if ( ! $manager instanceof Fifu_Db2_Manager ) {
			return;
		}

		$old_urls = self::snapshot_urls_by_index( $url_snapshot );
		$old_alts = self::snapshot_alts_by_index( $alt_snapshot );

		if ( method_exists( $manager, 'deletePostAltMappings' ) ) {
			$manager->deletePostAltMappings( $post_id, 'image' );
		}

		foreach ( $new_urls as $index => $new_url ) {
			$old_url = isset( $old_urls[ $index ] ) ? trim( (string) $old_urls[ $index ] ) : '';
			$old_alt = isset( $old_alts[ $index ] ) ? (string) $old_alts[ $index ] : '';
			if ( $old_url !== $new_url || self::is_effectively_empty_alt_value( $old_alt ) ) {
				continue;
			}

			if ( method_exists( $manager, 'savePostAlt' ) ) {
				$manager->savePostAlt( $post_id, 'image', (int) $index, $old_alt );
			}
		}
	}

	/**
	 * Convert DB2 URL rows into an index-based map.
	 *
	 * @param array<int,array<string,mixed>> $snapshot Snapshot rows.
	 * @return array<int,string>
	 */
	private static function snapshot_urls_by_index( array $snapshot ): array {
		$urls = array();
		foreach ( $snapshot as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$index = isset( $row['key_index'] ) ? (int) $row['key_index'] : count( $urls );
			$urls[ $index ] = (string) ( $row['url'] ?? '' );
		}

		return $urls;
	}

	/**
	 * Convert DB2 ALT rows into an index-based map.
	 *
	 * @param array<int,array<string,mixed>> $snapshot Snapshot rows.
	 * @return array<int,string>
	 */
	private static function snapshot_alts_by_index( array $snapshot ): array {
		$alts = array();
		foreach ( $snapshot as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$index = isset( $row['key_index'] ) ? (int) $row['key_index'] : count( $alts );
			$alt = trim( wp_strip_all_tags( (string) ( $row['alt'] ?? $row['value'] ?? '' ) ) );
			if ( '' === $alt ) {
				continue;
			}

			$alts[ $index ] = $alt;
		}

		return $alts;
	}

	/**
	 * Capture legacy image meta so a video-list rebuild does not discard a pre-existing featured image.
	 *
	 * @param int $post_id Post ID.
	 * @return array<string, ?string>
	 */
	private static function snapshot_legacy_image_state( int $post_id ): array {
		return array(
			'fifu_image_url' => self::snapshot_post_meta_value( $post_id, 'fifu_image_url' ),
			'fifu_image_alt' => self::snapshot_post_meta_value( $post_id, 'fifu_image_alt' ),
			'fifu_image_url_0' => self::snapshot_post_meta_value( $post_id, 'fifu_image_url_0' ),
			'fifu_image_alt_0' => self::snapshot_post_meta_value( $post_id, 'fifu_image_alt_0' ),
		);
	}

	/**
	 * Restore legacy image meta captured before a video-list rebuild.
	 *
	 * @param int $post_id Post ID.
	 * @param array<string, ?string> $snapshot Snapshot values.
	 * @return void
	 */
	private static function restore_legacy_image_state( int $post_id, array $snapshot ): void {
		foreach ( $snapshot as $meta_key => $value ) {
			if ( null === $value ) {
				delete_post_meta( $post_id, $meta_key );
				continue;
			}

			update_post_meta( $post_id, $meta_key, $value );
		}

		clean_post_cache( $post_id );
		wp_cache_delete( $post_id, 'post_meta' );
	}

	/**
	 * Restore a DB2 list snapshot or clear the channel if the snapshot was empty.
	 *
	 * @param int $post_id Post ID.
	 * @param string $key_type DB2 key type.
	 * @param bool $is_alt Whether the channel stores alt rows.
	 * @param array<int,array<string,mixed>> $snapshot Snapshot rows.
	 * @return void
	 */
	private static function restore_db2_list_snapshot( int $post_id, string $key_type, bool $is_alt, array $snapshot ): void {
		if ( ! function_exists( 'fifu_db2_manager' ) || ! class_exists( 'Fifu_Db2_Manager', false ) ) {
			return;
		}

		$manager = fifu_db2_manager();
		if ( ! $manager instanceof Fifu_Db2_Manager ) {
			return;
		}

		if ( $is_alt ) {
			if ( method_exists( $manager, 'deletePostAltMappings' ) ) {
				$manager->deletePostAltMappings( $post_id, $key_type );
			}
		} else {
			if ( method_exists( $manager, 'deletePostMappings' ) ) {
				$manager->deletePostMappings( $post_id, $key_type );
			}
		}

		foreach ( $snapshot as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$index = (int) ( $row['key_index'] ?? 0 );
			if ( $is_alt ) {
				$alt = trim( wp_strip_all_tags( (string) ( $row['alt'] ?? '' ) ) );
				if ( '' === $alt ) {
					continue;
				}

				if ( method_exists( $manager, 'upsertPostAltMapping' ) ) {
					$manager->upsertPostAltMapping( $post_id, $key_type, $index, $alt );
					continue;
				}

				if ( method_exists( $manager, 'savePostAlt' ) ) {
					$manager->savePostAlt( $post_id, $key_type, $index, $alt );
				}
				continue;
			}

			$url = trim( (string) ( $row['url'] ?? '' ) );
			if ( '' === $url ) {
				continue;
			}

			if ( method_exists( $manager, 'upsertPostMapping' ) ) {
				$manager->upsertPostMapping( $post_id, $key_type, $index, $url );
				continue;
			}

			if ( method_exists( $manager, 'savePostUrl' ) ) {
				$manager->savePostUrl( $post_id, $key_type, $index, $url );
			}
		}
	}

	/**
	 * Reindex DB2 image list rows so an existing featured video keeps index 0 reserved.
	 *
	 * @param int $post_id Post ID.
	 * @param array<int,string> $urls Normalized image URLs.
	 * @param array<int,string>|null $alts Normalized alts, if provided.
	 * @return void
	 */
	private static function delete_legacy_video_list_meta_after_confirmation( int $post_id, array $urls ): void {
		delete_post_meta( $post_id, 'fifu_list_video_url' );
		delete_post_meta( $post_id, 'fifu_video_url' );
		delete_post_meta( $post_id, 'fifu_custom_video_url' );
		foreach ( array_keys( get_post_meta( $post_id ) ) as $meta_key ) {
			if ( 0 === strpos( (string) $meta_key, 'fifu_video_url_' ) ) {
				delete_post_meta( $post_id, $meta_key );
			}
		}
	}

	private static function persist_featured_image_legacy_state( int $post_id, string $url ): void {
		if ( '' === $url ) {
			return;
		}

		FIFU_Post_Meta_Updater::run_without_db2_sync_for_derived_image_list_meta(
			static function () use ( $post_id, $url ): void {
				FIFU_Post_Meta_Updater::instance()->update_or_delete_with_status( $post_id, 'fifu_image_url', $url );
			}
		);
	}

	private static function persist_featured_video_legacy_state( int $post_id, string $url ): void {
		if ( '' === $url ) {
			return;
		}

		FIFU_Post_Meta_Updater::run_without_db2_sync_for_derived_video_list_meta(
			static function () use ( $post_id, $url ): void {
				FIFU_Post_Meta_Updater::instance()->update_or_delete_with_status( $post_id, 'fifu_video_url', $url );
			}
		);
	}


	private static function delete_legacy_slider_meta_after_confirmation( int $post_id, array $urls, array $alts ): void {
		delete_post_meta( $post_id, 'fifu_slider_list_url' );
		delete_post_meta( $post_id, 'fifu_slider_list_alt' );
		foreach ( array_keys( get_post_meta( $post_id ) ) as $meta_key ) {
			if ( 0 === strpos( (string) $meta_key, 'fifu_slider_image_url_' ) || 0 === strpos( (string) $meta_key, 'fifu_slider_image_alt_' ) ) {
				delete_post_meta( $post_id, $meta_key );
			}
		}
	}

	/**
	 * Check whether a URL is a valid HTTP(S) URL.
	 *
	 * @param string $url URL to validate.
	 * @return bool
	 */
	private static function is_valid_http_url( string $url ): bool {
		if ( ! preg_match( '#^https?://#i', $url ) ) {
			return false;
		}

		$parts = wp_parse_url( $url );
		if ( ! is_array( $parts ) || empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
			return false;
		}

		if ( false === filter_var( $url, FILTER_VALIDATE_URL ) ) {
			return false;
		}

		$scheme = strtolower( (string) ( $parts['scheme'] ?? '' ) );
		return in_array( $scheme, array( 'http', 'https' ), true );
	}

	/**
	 * Delete exact and prefixed legacy post meta keys without triggering DB2 sync.
	 *
	 * @param int      $post_id    Post ID.
	 * @param string[] $exact_keys  Exact keys to delete.
	 * @param string[] $prefixes    Key prefixes to delete.
	 * @return void
	 */
	private static function delete_legacy_post_meta_exact_and_prefixed_raw( int $post_id, array $exact_keys, array $prefixes ): void {
		global $wpdb;

		foreach ( $exact_keys as $meta_key ) {
			$wpdb->delete(
				$wpdb->postmeta,
				array(
					'post_id'  => $post_id,
					'meta_key' => (string) $meta_key,
				),
				array( '%d', '%s' )
			);
		}

		$meta = get_post_meta( $post_id );
		if ( ! is_array( $meta ) ) {
			return;
		}

		foreach ( array_keys( $meta ) as $meta_key ) {
			foreach ( $prefixes as $prefix ) {
				if ( 0 === strpos( (string) $meta_key, $prefix ) ) {
					$wpdb->delete(
						$wpdb->postmeta,
						array(
							'post_id'    => $post_id,
							'meta_key'   => (string) $meta_key,
						),
						array( '%d', '%s' )
					);
					break;
				}
			}
		}
	}

	/**
	 * Synchronize category related attachments.
	 *
	 * @param int $term_id Term ID.
	 * @return void
	 */
	private static function sync_category_media( int $term_id ): void {
		Fifu_Post_Attachment_Sync_Service::sync_category_attachment( $term_id );
	}

	/**
	 * Remove all canonical and legacy post meta for the featured media state.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	private static function clear_post_featured_media_legacy_state( int $post_id ): void {
		self::delete_legacy_post_meta_exact_and_prefixed_raw(
			$post_id,
			array(
				'fifu_image_url',
				'fifu_image_alt',
				'fifu_list_url',
				'fifu_list_alt',
				'fifu_video_url',
				'fifu_custom_video_url',
				'fifu_list_video_url',
				'fifu_slider_list_url',
				'fifu_slider_list_alt',
				'_thumbnail_id',
				'_product_image_gallery',
			),
			array(
				'fifu_image_url_',
				'fifu_image_alt_',
				'fifu_video_url_',
				'fifu_slider_image_url_',
				'fifu_slider_image_alt_',
			)
		);
	}

	/**
	 * Delete the developer simple featured image DB2 state if the bridge is available.
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	private static function delete_simple_featured_image_state( int $post_id ): bool {
		if ( ! function_exists( 'fifu_db2_legacy_write_bridge' ) ) {
			return true;
		}

		$bridge = fifu_db2_legacy_write_bridge();
		if ( ! $bridge instanceof Fifu_Db2_Legacy_Write_Bridge ) {
			return true;
		}

		return $bridge->clear_simple_featured_image_state( $post_id );
	}

	/**
	 * Normalize and validate a category URL while keeping delete semantics distinct from invalid URLs.
	 *
	 * @param mixed $url Raw input.
	 * @return string|null
	 */
	private static function normalize_single_category_url( $url ): ?string {
		if ( null === $url ) {
			return '';
		}

		$raw = trim( (string) $url );
		if ( '' === $raw ) {
			return '';
		}

		if ( ! self::is_valid_http_url( $raw ) ) {
			return null;
		}

		$sanitized = esc_url_raw( $raw );
		if ( '' === $sanitized ) {
			return null;
		}

		return $sanitized;
	}

	/**
	 * Return the current canonical category image URL from DB2 or legacy meta.
	 *
	 * @param int $term_id Term ID.
	 * @return string
	 */
	private static function get_current_category_image_url( int $term_id ): string {
		$current_url = Fifu_Term_Image_Url_Read_Service::get_image_url( $term_id );
		return is_string( $current_url ) ? $current_url : '';
	}

	/**
	 * Return the current canonical category image ALT from DB2 or legacy meta.
	 *
	 * @param int $term_id Term ID.
	 * @return string
	 */
	private static function get_current_category_image_alt( int $term_id ): string {
		$current_alt = Fifu_Term_Image_Alt_Read_Service::get_image_alt( $term_id );
		return is_string( $current_alt ) ? $current_alt : '';
	}

	/**
	 * Clear category image state across DB2, legacy meta and thumbnail attachment.
	 *
	 * @param int $term_id Term ID.
	 * @return bool
	 */
	private static function clear_category_image_state( int $term_id ): bool {
		$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
		if ( ! $manager instanceof Fifu_Db2_Manager ) {
			return false;
		}

		if ( method_exists( $manager, 'deleteTermMappings' ) ) {
			$manager->deleteTermMappings( $term_id, 'image' );
		}
		if ( method_exists( $manager, 'deleteTermAltMappings' ) ) {
			$manager->deleteTermAltMappings( $term_id, 'image' );
		}
		if ( method_exists( $manager, 'deleteTermMappings' ) ) {
			$manager->deleteTermMappings( $term_id, 'video' );
			$manager->deleteTermMappings( $term_id, 'custom_video' );
		}
		if ( method_exists( $manager, 'deleteTermAltMappings' ) ) {
			$manager->deleteTermAltMappings( $term_id, 'video' );
			$manager->deleteTermAltMappings( $term_id, 'custom_video' );
		}

		self::clear_category_image_legacy_state( $term_id );
		FIFU_Term_Meta_Updater::instance()->delete( $term_id, 'fifu_image_alt' );
		self::clear_category_video_legacy_state( $term_id );
		FIFU_Term_Meta_Updater::instance()->delete( $term_id, 'fifu_custom_video_url' );

		return true;
	}

	/**
	 * Remove legacy term meta related to the category image state.
	 *
	 * @param int $term_id Term ID.
	 * @return void
	 */
	private static function clear_category_image_legacy_state( int $term_id ): void {
		self::delete_legacy_term_meta_raw( $term_id, 'fifu_image_url' );
	}

	/**
	 * Remove legacy term meta related to the category video state.
	 *
	 * @param int $term_id Term ID.
	 * @return void
	 */
	private static function clear_category_video_legacy_state( int $term_id ): void {
		self::delete_legacy_term_meta_raw( $term_id, 'fifu_video_url' );
	}

	/**
	 * Remove the opposite category video state after a successful image update.
	 *
	 * @param int $term_id Term ID.
	 * @return void
	 */
	private static function delete_category_video_state( int $term_id ): bool {
		$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
		$has_legacy_video = '' !== trim( (string) get_term_meta( $term_id, 'fifu_video_url', true ) );
		$has_db2_video = false;
		if ( $manager instanceof Fifu_Db2_Manager ) {
			$video_mapping = method_exists( $manager, 'getTermMapping' ) ? $manager->getTermMapping( $term_id, 'video' ) : null;
			$video_alt_mapping = method_exists( $manager, 'getTermAltMapping' ) ? $manager->getTermAltMapping( $term_id, 'video' ) : null;
			$has_db2_video = self::has_effective_category_mapping( $video_mapping ) || self::has_effective_category_mapping( $video_alt_mapping );
		}

		if ( ! $has_legacy_video && ! $has_db2_video ) {
			return true;
		}

		if ( ! $manager instanceof Fifu_Db2_Manager ) {
			return false;
		}

		if ( $has_db2_video ) {
			if ( method_exists( $manager, 'deleteTermMappings' ) ) {
				$manager->deleteTermMappings( $term_id, 'video' );
			}
			if ( method_exists( $manager, 'deleteTermAltMappings' ) ) {
				$manager->deleteTermAltMappings( $term_id, 'video' );
			}
		}

		if ( $has_legacy_video ) {
			self::delete_legacy_term_meta_raw( $term_id, 'fifu_video_url' );
		}

		$video_mapping = method_exists( $manager, 'getTermMapping' ) ? $manager->getTermMapping( $term_id, 'video' ) : null;
		$video_alt_mapping = method_exists( $manager, 'getTermAltMapping' ) ? $manager->getTermAltMapping( $term_id, 'video' ) : null;

		return ! self::has_effective_category_mapping( $video_mapping )
			&& ! self::has_effective_category_mapping( $video_alt_mapping )
			&& '' === trim( (string) get_term_meta( $term_id, 'fifu_video_url', true ) );
	}

	/**
	 * Remove the opposite category image state after a successful video update.
	 *
	 * @param int $term_id Term ID.
	 * @return void
	 */
	private static function delete_category_image_state( int $term_id ): bool {
		$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
		$has_legacy_image = '' !== trim( (string) get_term_meta( $term_id, 'fifu_image_url', true ) )
			|| '' !== trim( (string) get_term_meta( $term_id, 'fifu_image_alt', true ) );
		$has_db2_image = false;
		if ( $manager instanceof Fifu_Db2_Manager ) {
			$image_mapping = method_exists( $manager, 'getTermMapping' ) ? $manager->getTermMapping( $term_id, 'image' ) : null;
			$image_alt_mapping = method_exists( $manager, 'getTermAltMapping' ) ? $manager->getTermAltMapping( $term_id, 'image' ) : null;
			$has_db2_image = self::has_effective_category_mapping( $image_mapping ) || self::has_effective_category_mapping( $image_alt_mapping );
		}

		if ( ! $has_legacy_image && ! $has_db2_image ) {
			return true;
		}

		if ( function_exists( 'fifu_db2_manager' ) && class_exists( 'Fifu_Db2_Manager', false ) ) {
			$manager = fifu_db2_manager();
			if ( $manager instanceof Fifu_Db2_Manager && method_exists( $manager, 'deleteTermMappings' ) ) {
				$manager->deleteTermMappings( $term_id, 'image' );
			}
			if ( $manager instanceof Fifu_Db2_Manager && method_exists( $manager, 'deleteTermAltMappings' ) ) {
				$manager->deleteTermAltMappings( $term_id, 'image' );
			}
		}

		self::clear_category_image_legacy_state( $term_id );
		FIFU_Term_Meta_Updater::instance()->delete( $term_id, 'fifu_image_alt' );
		if ( ! $manager instanceof Fifu_Db2_Manager ) {
			return false;
		}

		$image_mapping = method_exists( $manager, 'getTermMapping' ) ? $manager->getTermMapping( $term_id, 'image' ) : null;
		$image_alt_mapping = method_exists( $manager, 'getTermAltMapping' ) ? $manager->getTermAltMapping( $term_id, 'image' ) : null;

		return ! self::has_effective_category_mapping( $image_mapping )
			&& ! self::has_effective_category_mapping( $image_alt_mapping )
			&& '' === trim( (string) get_term_meta( $term_id, 'fifu_image_url', true ) )
			&& '' === trim( (string) get_term_meta( $term_id, 'fifu_image_alt', true ) );
	}

	/**
	 * Remove the opposite category custom video state after a successful video update.
	 *
	 * @param int $term_id Term ID.
	 * @return bool
	 */
	private static function delete_category_custom_video_state( int $term_id ): bool {
		$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
		$has_legacy_custom_video = '' !== trim( (string) get_term_meta( $term_id, 'fifu_custom_video_url', true ) );
		$has_db2_custom_video = false;
		if ( $manager instanceof Fifu_Db2_Manager ) {
			$custom_video_mapping = method_exists( $manager, 'getTermMapping' ) ? $manager->getTermMapping( $term_id, 'custom_video' ) : null;
			$custom_video_alt_mapping = method_exists( $manager, 'getTermAltMapping' ) ? $manager->getTermAltMapping( $term_id, 'custom_video' ) : null;
			$has_db2_custom_video = self::has_effective_category_mapping( $custom_video_mapping ) || self::has_effective_category_mapping( $custom_video_alt_mapping );
		}

		if ( ! $has_legacy_custom_video && ! $has_db2_custom_video ) {
			return true;
		}

		if ( function_exists( 'fifu_db2_manager' ) && class_exists( 'Fifu_Db2_Manager', false ) ) {
			$manager = fifu_db2_manager();
			if ( ! $manager instanceof Fifu_Db2_Manager ) {
				return false;
			}

			if ( method_exists( $manager, 'deleteTermMappings' ) ) {
				$manager->deleteTermMappings( $term_id, 'custom_video' );
			}
			if ( method_exists( $manager, 'deleteTermAltMappings' ) ) {
				$manager->deleteTermAltMappings( $term_id, 'custom_video' );
			}
		}

		FIFU_Term_Meta_Updater::instance()->delete( $term_id, 'fifu_custom_video_url' );
		if ( ! $manager instanceof Fifu_Db2_Manager ) {
			return false;
		}

		$custom_video_mapping = method_exists( $manager, 'getTermMapping' ) ? $manager->getTermMapping( $term_id, 'custom_video' ) : null;
		$custom_video_alt_mapping = method_exists( $manager, 'getTermAltMapping' ) ? $manager->getTermAltMapping( $term_id, 'custom_video' ) : null;

		return ! self::has_effective_category_mapping( $custom_video_mapping )
			&& ! self::has_effective_category_mapping( $custom_video_alt_mapping )
			&& '' === trim( (string) get_term_meta( $term_id, 'fifu_custom_video_url', true ) );
	}

	private static function has_effective_category_mapping( $mapping ): bool {
		if ( ! is_array( $mapping ) ) {
			return false;
		}

		return trim( (string) ( $mapping['url'] ?? $mapping['alt'] ?? $mapping['value'] ?? '' ) ) !== '';
	}

	/**
	 * Detach a category thumbnail reference and clean up only if the attachment is FIFU-owned.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @return void
	 */
	private static function cleanup_category_thumbnail_attachment_if_owned( int $term_id, int $attachment_id ): void {
		if ( $attachment_id <= 0 ) {
			return;
		}

		if ( ! class_exists( 'Fifu_Attachment_Update_Service', false ) ) {
			return;
		}

		$attachment = get_post( $attachment_id );
		$term = get_term( $term_id );
		if ( ! $attachment || ! $term || 'attachment' !== $attachment->post_type ) {
			return;
		}
		$category_name = 'fifu-category-' . $term_id;
		if (
			(int) $attachment->post_parent !== $term_id
			|| (string) $attachment->post_name !== $category_name
			|| ! Fifu_Attachment_Update_Service::is_fifu_owned( $attachment_id )
		) {
			return;
		}
		self::delete_owned_remote_attachment_if_unreferenced( $attachment_id, $term_id );
	}

	/**
	 * Store the canonical DB2 category video mapping.
	 *
	 * @param int $term_id Term ID.
	 * @param string $video_url Normalized video URL.
	 * @param Fifu_Db2_Manager $manager DB2 manager.
	 * @return bool
	 */
	private static function save_category_video_db2_state( int $term_id, string $video_url, Fifu_Db2_Manager $manager ): bool {
		if ( ! method_exists( $manager, 'saveTermUrl' ) || ! method_exists( $manager, 'getTermMapping' ) ) {
			return false;
		}

		if ( ! $manager->saveTermUrl( $term_id, 'video', $video_url ) ) {
			return false;
		}

		$confirmed = $manager->getTermMapping( $term_id, 'video' );
		return is_array( $confirmed ) && trim( (string) ( $confirmed['url'] ?? '' ) ) === $video_url;
	}

	/**
	 * Snapshot legacy category term meta used by the video setter.
	 *
	 * @param int $term_id Term ID.
	 * @param string $meta_key Meta key.
	 * @return string|null
	 */
	private static function snapshot_term_meta_state( int $term_id, string $meta_key ): array {
		$exists = self::term_meta_exists( $term_id, $meta_key );
		$value = $exists ? get_term_meta( $term_id, $meta_key, true ) : null;
		$value = is_scalar( $value ) ? trim( (string) $value ) : '';

		return array(
			'exists' => $exists,
			'value' => $value === '' ? null : $value,
		);
	}

	/**
	 * Snapshot DB2 category video state for rollback.
	 *
	 * @param int $term_id Term ID.
	 * @return array
	 */
	private static function snapshot_db2_category_video_state( int $term_id ): array {
		$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
		if ( ! $manager instanceof Fifu_Db2_Manager || ! method_exists( $manager, 'getTermMapping' ) ) {
			return array(
				'video' => null,
			);
		}

		$mapping = $manager->getTermMapping( $term_id, 'video' );
		return array(
			'video' => is_array( $mapping ) ? trim( (string) ( $mapping['url'] ?? '' ) ) : null,
		);
	}

	/**
	 * Restore legacy category video state after a failed update.
	 *
	 * @param int $term_id Term ID.
	 * @param array $snapshot Snapshot data.
	 * @return void
	 */
	private static function restore_category_video_legacy_state( int $term_id, array $snapshot ): void {
		foreach ( $snapshot as $meta_key => $entry ) {
			if ( is_array( $entry ) && array_key_exists( 'exists', $entry ) ) {
				if ( ! $entry['exists'] ) {
					continue;
				}

				$value = $entry['value'] ?? null;
				if ( null === $value ) {
					if ( self::term_meta_exists( $term_id, $meta_key ) ) {
						delete_term_meta( $term_id, $meta_key );
					}
					continue;
				}

				$current_value = trim( (string) get_term_meta( $term_id, $meta_key, true ) );
				if ( $current_value !== $value ) {
					update_term_meta( $term_id, $meta_key, $value );
				}
				continue;
			}

			if ( null === $entry ) {
				continue;
			}

			update_term_meta( $term_id, $meta_key, $entry );
		}
	}

	/**
	 * Restore DB2 category video state after a failed update.
	 *
	 * @param int $term_id Term ID.
	 * @param array $snapshot Snapshot data.
	 * @return void
	 */
	private static function restore_db2_category_video_state( int $term_id, array $snapshot ): void {
		$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
		if ( ! $manager instanceof Fifu_Db2_Manager ) {
			return;
		}

		if ( method_exists( $manager, 'deleteTermMappings' ) ) {
			$manager->deleteTermMappings( $term_id, 'video' );
		}

		$video = isset( $snapshot['video'] ) ? trim( (string) $snapshot['video'] ) : '';
		if ( $video !== '' && method_exists( $manager, 'saveTermUrl' ) ) {
			$manager->saveTermUrl( $term_id, 'video', $video );
		}
	}

	/**
	 * Delete a term meta row without invoking the public updater bridge.
	 *
	 * @param int $term_id Term ID.
	 * @param string $meta_key Meta key.
	 * @return void
	 */
	private static function delete_legacy_term_meta_raw( int $term_id, string $meta_key ): void {
		if ( function_exists( 'delete_term_meta' ) ) {
			delete_term_meta( $term_id, $meta_key );
		} else {
			global $wpdb;
			$wpdb->delete(
				$wpdb->termmeta,
				array(
					'term_id' => $term_id,
					'meta_key' => $meta_key,
				),
				array( '%d', '%s' )
			);
		}

		if ( function_exists( 'clean_term_cache' ) ) {
			clean_term_cache( $term_id );
		}
		if ( function_exists( 'wp_cache_delete' ) ) {
			wp_cache_delete( $term_id, 'term_meta' );
		}
	}

	private static function delete_legacy_term_meta_raw_if_exists( int $term_id, string $meta_key ): void {
		if ( ! self::term_meta_exists( $term_id, $meta_key ) ) {
			return;
		}

		self::delete_legacy_term_meta_raw( $term_id, $meta_key );
	}

	private static function term_meta_exists( int $term_id, string $meta_key ): bool {
		if ( function_exists( 'metadata_exists' ) ) {
			return metadata_exists( 'term', $term_id, $meta_key );
		}

		return '' !== trim( (string) get_term_meta( $term_id, $meta_key, true ) );
	}

	private static function snapshot_db2_category_custom_video_state( int $term_id ): array {
		$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
		if ( ! $manager instanceof Fifu_Db2_Manager || ! method_exists( $manager, 'getTermMapping' ) ) {
			return array( 'custom_video' => null );
		}

		$mapping = $manager->getTermMapping( $term_id, 'custom_video' );
		return array(
			'custom_video' => is_array( $mapping ) ? trim( (string) ( $mapping['url'] ?? '' ) ) : null,
		);
	}

	private static function restore_db2_category_custom_video_state( int $term_id, array $snapshot ): void {
		$manager = function_exists( 'fifu_db2_manager' ) ? fifu_db2_manager() : null;
		if ( ! $manager instanceof Fifu_Db2_Manager ) {
			return;
		}

		if ( method_exists( $manager, 'deleteTermMappings' ) ) {
			$manager->deleteTermMappings( $term_id, 'custom_video' );
		}

		$video = isset( $snapshot['custom_video'] ) ? trim( (string) $snapshot['custom_video'] ) : '';
		if ( $video !== '' && method_exists( $manager, 'saveTermUrl' ) ) {
			$manager->saveTermUrl( $term_id, 'custom_video', $video );
		}
	}

	/**
	 * Remove derived legacy image-list URL meta keys from wp_postmeta only after DB2 URL confirmation.
	 *
	 * @param int $post_id Post ID.
	 * @param string $expected_url_list Normalized expected image URL list.
	 * @param bool $has_featured_video Whether the image list was rebuilt with a preserved featured video.
	 * @return void
	 */
	private static function cleanup_legacy_image_list_url_meta_after_db2_sync( int $post_id, string $expected_url_list, bool $has_featured_video ): void {
		$expected_urls = self::parse_cleanup_pipe_list( $expected_url_list );
		$db2_urls = self::get_db2_post_mapping_urls_for_cleanup( $post_id, 'image' );
		if ( null === $db2_urls || $db2_urls !== $expected_urls ) {
			return;
		}

		$image_meta = get_post_meta( $post_id );
		if ( ! is_array( $image_meta ) ) {
			return;
		}

		self::delete_legacy_post_meta_keys(
			$post_id,
			array( 'fifu_list_url' ),
			array()
		);

		$main_mapping = self::get_db2_post_mapping_value_for_cleanup( $post_id, 'image', 0 );
		$expected_main_url = $has_featured_video ? null : ( $expected_urls[0] ?? null );
		if ( self::cleanup_values_match( $main_mapping, $expected_main_url ) ) {
			self::delete_legacy_post_meta_keys(
				$post_id,
				array( 'fifu_image_url' ),
				array()
			);
		}

		foreach ( array_keys( $image_meta ) as $meta_key ) {
			if ( preg_match( '/^fifu_image_url_(\d+)$/', $meta_key, $matches ) !== 1 ) {
				continue;
			}

			$legacy_index = (int) $matches[1];
			$db2_index = $legacy_index + 1;
			$expected_position = $legacy_index + ( $has_featured_video ? 0 : 1 );
			$expected_value = $expected_urls[ $expected_position ] ?? null;
			$db2_value = self::get_db2_post_mapping_value_for_cleanup( $post_id, 'image', $db2_index );
			if ( ! self::cleanup_values_match( $db2_value, $expected_value ) ) {
				continue;
			}

			self::delete_legacy_post_meta_keys(
				$post_id,
				array( $meta_key ),
				array()
			);
		}
	}

	/**
	 * Remove derived legacy image-list ALT meta keys from wp_postmeta only after DB2 ALT confirmation.
	 *
	 * @param int $post_id Post ID.
	 * @param string $expected_alt_list Normalized expected image ALT list.
	 * @param bool $has_featured_video Whether the image list was rebuilt with a preserved featured video.
	 * @return void
	 */
	private static function cleanup_legacy_image_list_alt_meta_after_db2_sync( int $post_id, string $expected_alt_list, bool $has_featured_video ): void {
		$expected_alts = self::parse_cleanup_alt_pipe_list( $expected_alt_list );
		$db2_alts = self::get_db2_post_alt_mappings_for_cleanup( $post_id, 'image' );
		if ( null === $db2_alts ) {
			return;
		}

		$image_meta = get_post_meta( $post_id );
		if ( ! is_array( $image_meta ) ) {
			return;
		}

		$offset = $has_featured_video ? 1 : 0;
		$expected_non_empty_count = 0;
		foreach ( $expected_alts as $expected_alt ) {
			if ( null !== $expected_alt ) {
				$expected_non_empty_count++;
			}
		}

		$actual_non_empty_count = 0;
		foreach ( $db2_alts as $mapping ) {
			if ( null !== ( $mapping['alt'] ?? null ) ) {
				$actual_non_empty_count++;
			}
		}

		if ( $actual_non_empty_count !== $expected_non_empty_count ) {
			return;
		}

		foreach ( $expected_alts as $index => $expected_alt ) {
			$db2_index = $index + $offset;
			$db2_alt = self::get_db2_post_alt_mapping_value_for_cleanup( $post_id, 'image', $db2_index );
			if ( ! self::cleanup_values_match( $db2_alt, $expected_alt ) ) {
				return;
			}
		}

		foreach ( $db2_alts as $mapping ) {
			$key_index = (int) ( $mapping['key_index'] ?? -1 );
			if ( $key_index < $offset ) {
				if ( null !== ( $mapping['alt'] ?? null ) ) {
					return;
				}
				continue;
			}

			if ( $key_index <= $offset + count( $expected_alts ) - 1 ) {
				continue;
			}

			if ( null !== ( $mapping['alt'] ?? null ) ) {
				return;
			}
		}

		self::delete_legacy_post_meta_keys(
			$post_id,
			array( 'fifu_list_alt' ),
			array()
		);

		$featured_alt = self::get_db2_post_alt_mapping_value_for_cleanup( $post_id, 'image', $has_featured_video ? 0 : 0 );
		if ( $has_featured_video ) {
			if ( self::cleanup_values_match( $featured_alt, null ) ) {
				self::delete_legacy_post_meta_keys(
					$post_id,
					array( 'fifu_image_alt' ),
					array()
				);
			}
		} else {
			$expected_featured_alt = $expected_alts[0] ?? null;
			if ( self::cleanup_values_match( $featured_alt, $expected_featured_alt ) ) {
				self::delete_legacy_post_meta_keys(
					$post_id,
					array( 'fifu_image_alt' ),
					array()
				);
			}
		}

		foreach ( array_keys( $image_meta ) as $meta_key ) {
			if ( preg_match( '/^fifu_image_alt_(\d+)$/', $meta_key, $matches ) !== 1 ) {
				continue;
			}

			$legacy_index = (int) $matches[1];
			$db2_index = $legacy_index + 1 + ( $has_featured_video ? 0 : 0 );
			$expected_position = $legacy_index + 1;
			$expected_value = $expected_alts[ $expected_position ] ?? null;
			if ( $has_featured_video ) {
				$expected_value = $expected_alts[ $legacy_index ] ?? null;
				$db2_index = $legacy_index + 1;
			}

			$db2_value = self::get_db2_post_alt_mapping_value_for_cleanup( $post_id, 'image', $db2_index );
			if ( ! self::cleanup_values_match( $db2_value, $expected_value ) ) {
				continue;
			}

			self::delete_legacy_post_meta_keys(
				$post_id,
				array( $meta_key ),
				array()
			);
		}
	}

	/**
	 * Remove derived legacy slider URL/ALT meta keys from wp_postmeta only after DB2 confirmation.
	 *
	 * @param int $post_id Post ID.
	 * @param string $expected_url_list Normalized expected slider URL list.
	 * @param string $expected_alt_list Normalized expected slider ALT list.
	 * @return void
	 */
	private static function cleanup_legacy_slider_meta_after_db2_sync( int $post_id, string $expected_url_list, string $expected_alt_list ): void {
		$meta = get_post_meta( $post_id );
		if ( ! is_array( $meta ) ) {
			return;
		}

		$expected_urls = self::parse_cleanup_pipe_list( $expected_url_list );
		$url_group_confirmed = false;
		$db2_urls = self::get_db2_post_mapping_urls_for_cleanup( $post_id, 'slider' );
		if ( null !== $db2_urls && $db2_urls === $expected_urls ) {
			$url_group_confirmed = true;
			self::delete_legacy_post_meta_keys(
				$post_id,
				array( 'fifu_slider_list_url' ),
				array()
			);
		}

		$expected_alts = self::parse_cleanup_alt_pipe_list( $expected_alt_list );
		$alt_group_confirmed = self::has_confirmed_db2_slider_alt_state( $post_id, $expected_alts );
		if ( $alt_group_confirmed ) {
			self::delete_legacy_post_meta_keys(
				$post_id,
				array( 'fifu_slider_list_alt' ),
				array()
			);
		}

		foreach ( array_keys( $meta ) as $meta_key ) {
			if ( preg_match( '/^fifu_slider_image_url_(\d+)$/', $meta_key, $url_matches ) === 1 ) {
				if ( ! $url_group_confirmed ) {
					continue;
				}

				$index = (int) $url_matches[1];
				$expected_value = $expected_urls[ $index ] ?? null;
				$db2_value = self::get_db2_post_mapping_value_for_cleanup( $post_id, 'slider', $index );
				if ( self::cleanup_values_match( $db2_value, $expected_value ) ) {
					self::delete_legacy_post_meta_keys(
						$post_id,
						array( $meta_key ),
						array()
					);
				}
				continue;
			}

			if ( preg_match( '/^fifu_slider_image_alt_(\d+)$/', $meta_key, $alt_matches ) !== 1 ) {
				continue;
			}

			if ( ! $alt_group_confirmed ) {
				continue;
			}

			$index = (int) $alt_matches[1];
			$expected_value = $expected_alts[ $index ] ?? null;
			$db2_value = self::get_db2_post_alt_mapping_value_for_cleanup( $post_id, 'slider', $index );
			if ( ! self::cleanup_values_match( $db2_value, $expected_value ) ) {
				continue;
			}

			self::delete_legacy_post_meta_keys(
				$post_id,
				array( $meta_key ),
				array()
			);
		}
	}

	/**
	 * Remove the provided exact meta keys and prefixed derived keys from a post.
	 * This helper is low-level only and must be called after DB2 persistence has been confirmed.
	 *
	 * @param int      $post_id      Post ID.
	 * @param string[] $exact_keys   Exact meta keys to remove.
	 * @param string[] $key_prefixes Derived meta key prefixes to remove.
	 * @return void
	 */
	private static function delete_legacy_post_meta_keys( int $post_id, array $exact_keys, array $key_prefixes ): void {
		$meta = get_post_meta( $post_id );
		if ( ! is_array( $meta ) ) {
			return;
		}

		foreach ( array_keys( $meta ) as $meta_key ) {
			if ( in_array( $meta_key, $exact_keys, true ) ) {
				delete_post_meta( $post_id, $meta_key );
				continue;
			}

			foreach ( $key_prefixes as $prefix ) {
				if ( strpos( $meta_key, $prefix ) === 0 ) {
					delete_post_meta( $post_id, $meta_key );
					break;
				}
			}
		}
	}

	/**
	 * Collect attachment IDs related to featured media before their state is removed.
	 *
	 * @param int $post_id Post ID.
	 * @return int[]
	 */
	private static function collect_featured_media_attachment_ids( int $post_id ): array {
		$ids = array();

		$thumbnail_id = (int) get_post_meta( $post_id, '_thumbnail_id', true );
		if ( $thumbnail_id > 0 ) {
			$ids[] = $thumbnail_id;
		}

		$gallery_csv = trim( (string) get_post_meta( $post_id, '_product_image_gallery', true ) );
		if ( '' !== $gallery_csv ) {
			foreach ( explode( ',', $gallery_csv ) as $gallery_id ) {
				$attachment_id = (int) trim( (string) $gallery_id );
				if ( $attachment_id > 0 ) {
					$ids[] = $attachment_id;
				}
			}
		}

		return array_values( array_unique( array_filter( $ids ) ) );
	}

	/**
	 * Delete DB2 featured-media mappings and tolerate already-empty state.
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	private static function clear_db2_featured_media_state( int $post_id ): bool {
		$manager = self::get_db2_manager_for_cleanup();
		if ( ! $manager instanceof Fifu_Db2_Manager ) {
			return true;
		}

		foreach ( array( 'image', 'video', 'custom_video', 'slider', 'audio' ) as $key_type ) {
			if ( method_exists( $manager, 'deletePostMappings' ) ) {
				try {
					$manager->deletePostMappings( $post_id, $key_type );
				} catch ( \Throwable $e ) {
					return false;
				}
			}

			if ( method_exists( $manager, 'deletePostAltMappings' ) && in_array( $key_type, array( 'image', 'slider' ), true ) ) {
				try {
					$manager->deletePostAltMappings( $post_id, $key_type );
				} catch ( \Throwable $e ) {
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Delete FIFU-managed attachments associated with the post when clearing featured media.
	 *
	 * @param int   $post_id Post ID.
	 * @param int[] $attachment_ids Attachment IDs captured before cleanup.
	 * @return void
	 */
	private static function delete_featured_media_attachments( int $post_id, array $attachment_ids ): void {
		if ( empty( $attachment_ids ) ) {
			return;
		}

		$attachment_repo = self::get_attachment_repository_for_cleanup();
		foreach ( $attachment_ids as $attachment_id ) {
			$attachment_id = (int) $attachment_id;
			if ( $attachment_id <= 0 ) {
				continue;
			}

			if ( ! self::is_fifu_managed_attachment( $attachment_repo, $attachment_id, $post_id ) ) {
				continue;
			}

			self::delete_owned_remote_attachment_if_unreferenced( $attachment_id, $post_id );
		}
	}

	private static function delete_fifu_managed_attachment_references( int $post_id, array $attachment_ids ): void {
		$attachment_repo = self::get_attachment_repository_for_cleanup();
		$fifu_attachment_ids = array();

		foreach ( $attachment_ids as $attachment_id ) {
			$attachment_id = (int) $attachment_id;
			if ( $attachment_id <= 0 ) {
				continue;
			}

			if ( self::is_fifu_managed_attachment( $attachment_repo, $attachment_id, $post_id ) ) {
				$fifu_attachment_ids[] = $attachment_id;
			}
		}

		$fifu_attachment_ids = array_values( array_unique( array_filter( $fifu_attachment_ids ) ) );
		if ( empty( $fifu_attachment_ids ) ) {
			return;
		}

		$thumbnail_id = (int) get_post_meta( $post_id, '_thumbnail_id', true );
		if ( $thumbnail_id > 0 && in_array( $thumbnail_id, $fifu_attachment_ids, true ) ) {
			delete_post_meta( $post_id, '_thumbnail_id' );
		}

		$gallery_csv = trim( (string) get_post_meta( $post_id, '_product_image_gallery', true ) );
		if ( '' !== $gallery_csv ) {
			$gallery_ids = array_values(
				array_filter(
					array_map(
						static fn( $value ): int => (int) trim( (string) $value ),
						explode( ',', $gallery_csv )
					)
				)
			);

			$kept_gallery_ids = array_values(
				array_filter(
					$gallery_ids,
					static fn( int $attachment_id ): bool => ! in_array( $attachment_id, $fifu_attachment_ids, true )
				)
			);

			if ( $kept_gallery_ids !== $gallery_ids ) {
				if ( empty( $kept_gallery_ids ) ) {
					delete_post_meta( $post_id, '_product_image_gallery' );
				} else {
					update_post_meta( $post_id, '_product_image_gallery', implode( ',', $kept_gallery_ids ) );
				}
			}
		}
		clean_post_cache( $post_id );
		wp_cache_delete( $post_id, 'post_meta' );
	}

	/**
	 * Clear WordPress attachment state left behind by video thumbnails when no real image remains.
	 *
	 * @param int   $post_id Post ID.
	 * @param array $video_thumbnail_urls Video thumbnail URL set.
	 * @param array $candidate_attachment_ids Candidate attachment IDs captured before cleanup.
	 * @return void
	 */
	private static function clear_video_thumbnail_wp_attachment_state( int $post_id, array $video_thumbnail_urls, array $candidate_attachment_ids ): void {
		$attachment_repo = self::get_attachment_repository_for_cleanup();
		$candidate_attachment_ids = array_values(
			array_unique(
				array_filter(
					array_map( 'intval', $candidate_attachment_ids ),
					static fn( int $attachment_id ): bool => $attachment_id > 0
				)
			)
		);

		$thumbnail_id = (int) get_post_thumbnail_id( $post_id );
		if ( $thumbnail_id > 0 ) {
			$thumbnail_url = self::get_attachment_remote_file_url( $thumbnail_id );
			if ( '' !== $thumbnail_url && self::url_matches_video_thumbnail_set( $thumbnail_url, $video_thumbnail_urls ) ) {
				delete_post_thumbnail( $post_id );
			}
		}

		$gallery_csv = trim( (string) get_post_meta( $post_id, '_product_image_gallery', true ) );
		if ( '' !== $gallery_csv ) {
			$gallery_ids = array_values(
				array_filter(
					array_map(
						static fn( $value ): int => (int) trim( (string) $value ),
						explode( ',', $gallery_csv )
					),
					static fn( int $attachment_id ): bool => $attachment_id > 0
				)
			);

			$kept_gallery_ids = array_values(
				array_filter(
					$gallery_ids,
					static function ( int $attachment_id ) use ( $video_thumbnail_urls ): bool {
						$attachment_url = self::get_attachment_remote_file_url( $attachment_id );
						if ( '' !== $attachment_url && self::url_matches_video_thumbnail_set( $attachment_url, $video_thumbnail_urls ) ) {
							return false;
						}

						return true;
					}
				)
			);

			if ( empty( $kept_gallery_ids ) ) {
				global $wpdb;
				$wpdb->delete( $wpdb->postmeta, array( 'post_id' => $post_id, 'meta_key' => '_product_image_gallery' ), array( '%d', '%s' ) );
			} elseif ( $kept_gallery_ids !== $gallery_ids ) {
				update_post_meta( $post_id, '_product_image_gallery', implode( ',', $kept_gallery_ids ) );
			}
		}
		foreach ( $candidate_attachment_ids as $attachment_id ) {
			if ( ! self::is_fifu_managed_attachment( $attachment_repo, $attachment_id, $post_id ) ) {
				continue;
			}

			$attachment_url = self::get_attachment_remote_file_url( $attachment_id );
			if ( '' === $attachment_url || ! self::url_matches_video_thumbnail_set( $attachment_url, $video_thumbnail_urls ) ) {
				continue;
			}

			self::delete_owned_remote_attachment_if_unreferenced( $attachment_id, $post_id );
		}

		clean_post_cache( $post_id );
		wp_cache_delete( $post_id, 'post_meta' );
	}

	/**
	 * Determine whether an attachment should be treated as FIFU-managed for cleanup.
	 *
	 * @param Fifu_Attachment_Repository|null $attachment_repo Attachment repository.
	 * @param int $attachment_id Attachment ID.
	 * @param int $post_id Parent post ID.
	 * @return bool
	 */
	private static function is_fifu_managed_attachment( ?Fifu_Attachment_Repository $attachment_repo, int $attachment_id, int $post_id ): bool {
		$attachment = get_post( $attachment_id );
		if ( ! $attachment || 'attachment' !== get_post_type( $attachment_id ) ) {
			return false;
		}

		if ( ! ( $attachment_repo instanceof Fifu_Attachment_Repository && method_exists( $attachment_repo, 'is_fifu_attachment' ) && $attachment_repo->is_fifu_attachment( $attachment_id ) ) ) {
			return false;
		}

		if ( $post_id !== (int) get_post_field( 'post_parent', $attachment_id ) ) {
			return false;
		}

		$attached_file = trim( (string) get_post_meta( $attachment_id, '_wp_attached_file', true ) );
		return '' !== $attached_file && preg_match( '#^https?://#i', $attached_file ) === 1;
	}

	/** Delete an owned remote attachment only when it is safe and has no remaining consumers. */
	private static function delete_owned_remote_attachment_if_unreferenced( int $attachment_id, int $parent_id ): void {
		if ( $attachment_id <= 0 || $attachment_id === (int) get_option( 'fifu_default_attach_id' ) ) {
			return;
		}
		$repo = self::get_attachment_repository_for_cleanup();
		if ( ! self::is_fifu_managed_attachment( $repo, $attachment_id, $parent_id ) ) {
			return;
		}
		if ( $repo instanceof Fifu_Attachment_Repository && $repo->get_referenced_attachment_ids( array( $attachment_id ) ) ) {
			return;
		}
		$cleanup = new Fifu_Local_Media_Cleanup();
		$cleanup->delete_attachments_and_meta( array( $attachment_id ) );
	}

	/** Remove selected attachment IDs from a comma-separated post reference. */
	private static function remove_attachment_ids_from_post_meta_list( int $post_id, string $meta_key, array $attachment_ids ): void {
		$ids = array_values( array_unique( array_filter( array_map( 'intval', $attachment_ids ) ) ) );
		if ( ! $ids ) {
			return;
		}
		$csv = trim( (string) get_post_meta( $post_id, $meta_key, true ) );
		if ( '' === $csv ) {
			return;
		}
		$values = array_values(
			array_filter(
				array_map( static fn( $value ): int => (int) trim( (string) $value ), explode( ',', $csv ) )
			)
		);
		$kept = array_values( array_filter( $values, static fn( int $id ): bool => ! in_array( $id, $ids, true ) ) );
		if ( $kept === $values ) {
			return;
		}
		if ( $kept ) {
			update_post_meta( $post_id, $meta_key, implode( ',', $kept ) );
		} else {
			delete_post_meta( $post_id, $meta_key );
		}
	}

	/**
	 * Create the attachment repository used during cleanup.
	 *
	 * @return Fifu_Attachment_Repository|null
	 */
	private static function get_attachment_repository_for_cleanup(): ?Fifu_Attachment_Repository {
		if ( ! class_exists( 'Fifu_Attachment_Repository', false ) ) {
			return null;
		}

		try {
			return new Fifu_Attachment_Repository();
		} catch ( \Throwable $e ) {
			return null;
		}
	}

	/**
	 * @param string|null $value
	 * @return string[]
	 */
	private static function parse_cleanup_pipe_list( ?string $value ): array {
		if ( null === $value ) {
			return array();
		}

		$value = trim( $value );
		if ( '' === $value ) {
			return array();
		}

		$entries = array_map( 'trim', explode( '|', $value ) );
		return array_values(
			array_filter(
				$entries,
				static fn( string $entry ): bool => '' !== $entry
			)
		);
	}

	/**
	 * @param string|null $value
	 * @return array<int,string|null>
	 */
	private static function parse_cleanup_alt_pipe_list( ?string $value ): array {
		if ( null === $value ) {
			return array();
		}

		if ( '' === trim( $value ) ) {
			return array();
		}

		return array_map(
			static function ( string $entry ): ?string {
				$entry = trim( $entry );
				return '' === $entry ? null : $entry;
			},
			explode( '|', $value )
		);
	}

	/**
	 * @param int $post_id
	 * @param string $key_type
	 * @return string[]|null
	 */
	private static function get_db2_post_mapping_urls_for_cleanup( int $post_id, string $key_type ): ?array {
		$manager = self::get_db2_manager_for_cleanup();
		if ( null === $manager ) {
			return null;
		}

		try {
			$rows = $manager->getPostMappings( $post_id, $key_type );
		} catch ( \Throwable $e ) {
			return null;
		}

		if ( ! is_array( $rows ) ) {
			return null;
		}

		usort(
			$rows,
			static fn( array $a, array $b ): int => ( $a['key_index'] ?? 0 ) <=> ( $b['key_index'] ?? 0 )
		);

		$urls = array();
		foreach ( $rows as $row ) {
			$url = trim( (string) ( $row['url'] ?? '' ) );
			if ( '' === $url ) {
				continue;
			}

			$urls[] = $url;
		}

		return $urls;
	}

	/**
	 * @param int $post_id
	 * @param string $key_type
	 * @return array<int,array{key_index:int,alt:?string}>|null
	 */
	private static function get_db2_post_alt_mappings_for_cleanup( int $post_id, string $key_type ): ?array {
		$manager = self::get_db2_manager_for_cleanup();
		if ( null === $manager ) {
			return null;
		}

		try {
			$rows = $manager->getPostAltMappings( $post_id, $key_type );
		} catch ( \Throwable $e ) {
			return null;
		}

		if ( ! is_array( $rows ) ) {
			return null;
		}

		usort(
			$rows,
			static fn( array $a, array $b ): int => ( $a['key_index'] ?? 0 ) <=> ( $b['key_index'] ?? 0 )
		);

		return array_map(
			static function ( array $row ): array {
				$alt = trim( (string) ( $row['alt'] ?? $row['value'] ?? '' ) );
				return array(
					'key_index' => (int) ( $row['key_index'] ?? 0 ),
					'alt' => '' === $alt ? null : $alt,
				);
			},
			$rows
		);
	}

	/**
	 * @param int $post_id
	 * @param string $key_type
	 * @param int $key_index
	 * @return string|null
	 */
	private static function get_db2_post_mapping_value_for_cleanup( int $post_id, string $key_type, int $key_index ): ?string {
		$manager = self::get_db2_manager_for_cleanup();
		if ( null === $manager ) {
			return null;
		}

		try {
			$mapping = $manager->getPostMapping( $post_id, $key_type, $key_index );
		} catch ( \Throwable $e ) {
			return null;
		}

		if ( ! is_array( $mapping ) ) {
			return null;
		}

		$value = trim( (string) ( $mapping['url'] ?? '' ) );
		return '' === $value ? null : $value;
	}

	/**
	 * @param int $post_id
	 * @param string $key_type
	 * @param int $key_index
	 * @return string|null
	 */
	private static function get_db2_post_alt_mapping_value_for_cleanup( int $post_id, string $key_type, int $key_index ): ?string {
		$manager = self::get_db2_manager_for_cleanup();
		if ( null === $manager ) {
			return null;
		}

		try {
			$mapping = $manager->getPostAltMapping( $post_id, $key_type, $key_index );
		} catch ( \Throwable $e ) {
			return null;
		}

		if ( ! is_array( $mapping ) ) {
			return null;
		}

		$value = trim( (string) ( $mapping['alt'] ?? $mapping['value'] ?? '' ) );
		return '' === $value ? null : $value;
	}

	/**
	 * @param int $post_id
	 * @param array<int,string|null> $expected_alts
	 * @return bool
	 */
	private static function has_confirmed_db2_slider_alt_state( int $post_id, array $expected_alts ): bool {
		$mappings = self::get_db2_post_alt_mappings_for_cleanup( $post_id, 'slider' );
		if ( null === $mappings ) {
			return false;
		}

		$expected_non_empty_count = 0;
		foreach ( $expected_alts as $expected_alt ) {
			if ( null !== $expected_alt ) {
				$expected_non_empty_count++;
			}
		}

		$actual_non_empty_count = 0;
		foreach ( $mappings as $mapping ) {
			if ( null !== ( $mapping['alt'] ?? null ) ) {
				$actual_non_empty_count++;
			}
		}

		if ( $actual_non_empty_count !== $expected_non_empty_count ) {
			return false;
		}

		$max_index = max(
			count( $expected_alts ) - 1,
			-1
		);

		foreach ( $expected_alts as $index => $expected_alt ) {
			$db2_alt = self::get_db2_post_alt_mapping_value_for_cleanup( $post_id, 'slider', (int) $index );
			if ( ! self::cleanup_values_match( $db2_alt, $expected_alt ) ) {
				return false;
			}
		}

		foreach ( $mappings as $mapping ) {
			$key_index = (int) ( $mapping['key_index'] ?? -1 );
			if ( $key_index <= $max_index ) {
				continue;
			}

			if ( null !== ( $mapping['alt'] ?? null ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * @param string|null $actual
	 * @param string|null $expected
	 * @return bool
	 */
	private static function cleanup_values_match( ?string $actual, ?string $expected ): bool {
		$actual = null === $actual ? null : trim( $actual );
		$expected = null === $expected ? null : trim( $expected );

		if ( '' === $actual ) {
			$actual = null;
		}

		if ( '' === $expected ) {
			$expected = null;
		}

		return $actual === $expected;
	}

	/**
	 * @return Fifu_Db2_Manager|null
	 */
	private static function get_db2_manager_for_cleanup(): ?Fifu_Db2_Manager {
		if ( ! function_exists( 'fifu_db2_manager' ) || ! class_exists( 'Fifu_Db2_Manager', false ) ) {
			return null;
		}

		$manager = fifu_db2_manager();
		if ( ! $manager instanceof Fifu_Db2_Manager ) {
			return null;
		}

		return $manager;
	}

	/**
	 * Normalize a pipe-delimited URL list into the DB2-ready format used by developer flows.
	 *
	 * @param string $url_list
	 * @return string
	 */
	private static function normalize_url_list( string $url_list ): string {
		$url_list = trim( $url_list );
		if ( $url_list === '' ) {
			return '';
		}

		$urls = self::normalize_delimited_list(
			$url_list,
			static function ( string $url ): string {
				if ( ! preg_match( '#^(https?:)?//#i', $url ) ) {
					return $url;
				}

				$url = esc_url_raw( rtrim( $url ) );
				return $url === '' ? '' : fifu_convert( $url );
			}
		);

		return implode( '|', $urls );
	}

	/**
	 * Normalize a pipe/newline-delimited image ALT list while preserving index positions.
	 *
	 * @param string $alt_list
	 * @return string
	 */
	private static function normalize_image_alt_list( string $alt_list ): string {
		$alt_list = trim( $alt_list );
		if ( $alt_list === '' ) {
			return '';
		}

		$alts = self::normalize_delimited_list(
			$alt_list,
			static fn( string $alt ): string => self::normalize_slider_alt_value( $alt ),
			true
		);

		return implode( '|', $alts );
	}

	/**
	 * Normalize a pipe-delimited slider alt list while preserving index positions.
	 *
	 * @param string $alt_list
	 * @return string
	 */
	private static function normalize_slider_alt_list( string $alt_list ): string {
		$alt_list = rtrim( $alt_list );
		if ( trim( $alt_list ) === '' ) {
			return '';
		}

		$alts = self::normalize_delimited_list(
			$alt_list,
			static fn( string $alt ): string => self::normalize_slider_alt_value( $alt ),
			true
		);

		return implode( '|', $alts );
	}

	/**
	 * Normalize a delimited list from pipe or line breaks.
	 *
	 * @param string   $value
	 * @param callable $normalizer
	 * @return string[]
	 */
	private static function normalize_delimited_list( string $value, callable $normalizer, bool $preserve_empty_entries = false ): array {
		$entries = preg_split( '/\r\n|\r|\n|\|/', $value );
		if ( ! is_array( $entries ) ) {
			return array();
		}

		$entries = array_map(
			static function ( string $entry ) use ( $normalizer ): string {
				return (string) $normalizer( trim( $entry ) );
			},
			$entries
		);

		if ( $preserve_empty_entries ) {
			return $entries;
		}

		return array_values( array_filter( $entries, static fn( string $entry ): bool => $entry !== '' ) );
	}

	/**
	 * Normalize slider alt text so invalid sentinels are treated as empty.
	 *
	 * @param mixed $value
	 * @return string
	 */
	private static function normalize_slider_alt_value( $value ): string {
		if ( null === $value ) {
			return '';
		}

		$raw = trim( (string) $value );
		if ( '' === $raw ) {
			return '';
		}

		$normalized = strtolower( $raw );
		if (
			'null' === $normalized
			|| 'undefined' === $normalized
			|| 'http://null' === $normalized
			|| 'https://null' === $normalized
		) {
			return '';
		}

		return wp_strip_all_tags( (string) $value );
	}

	/**
	 * Check whether the post currently has an effective featured video in DB2/legacy state.
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	private static function has_effective_featured_video( int $post_id ): bool {
		$video_url = Fifu_Post_Video_Read_Service::get_video_url( $post_id );
		if ( is_string( $video_url ) && trim( $video_url ) !== '' ) {
			return true;
		}

		$custom_video_url = Fifu_Post_Custom_Video_Read_Service::get_custom_video_url( $post_id );
		return is_string( $custom_video_url ) && trim( $custom_video_url ) !== '';
	}

	/**
	 * Check whether the post currently has an effective featured image in DB2/legacy/native state.
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	private static function has_effective_featured_image( int $post_id ): bool {
		if ( self::has_effective_featured_video( $post_id ) ) {
			return false;
		}

		$image_url = Fifu_Post_Image_Url_Read_Service::get_image_url( $post_id );
		if ( is_string( $image_url ) && trim( $image_url ) !== '' ) {
			return true;
		}

		if (
			! class_exists( 'Fifu_Post_Meta_Utils', false )
			|| ! method_exists( 'Fifu_Post_Meta_Utils', 'has_local_featured_image' )
			|| ! Fifu_Post_Meta_Utils::has_local_featured_image( $post_id )
		) {
			return function_exists( 'get_post_thumbnail_id' ) && get_post_thumbnail_id( $post_id ) > 0;
		}

		return ! method_exists( 'Fifu_Post_Meta_Utils', 'has_no_internal_image' )
			|| ! Fifu_Post_Meta_Utils::has_no_internal_image( $post_id );
	}

	/**
	 * Update a developer list source meta and optionally force a gallery-only DB2 rebuild.
	 *
	 * @param int    $post_id            Post ID.
	 * @param string $meta_key           Source meta key.
	 * @param string $meta_value         Source meta value.
	 * @param bool   $force_gallery_only Whether DB2 rebuild must preserve opposite featured media.
	 * @return void
	 */
	private static function update_developer_list_source_meta( int $post_id, string $meta_key, string $meta_value, bool $force_gallery_only ): bool {
		if ( $meta_value === '' || ! $force_gallery_only ) {
			return FIFU_Post_Meta_Updater::instance()->update_or_delete_with_status( $post_id, $meta_key, $meta_value === '' ? null : $meta_value );
		}

		$ok = false;
		self::run_with_gallery_only_db2_rebuild_context(
			$post_id,
			$meta_key,
			static function () use ( $post_id, $meta_key, $meta_value, &$ok ): void {
				$ok = FIFU_Post_Meta_Updater::instance()->update_or_delete_with_status( $post_id, $meta_key, $meta_value );
			}
		);

		return $ok;
	}

	/**
	 * Execute a callback while marking a developer list rebuild as gallery-only.
	 *
	 * @param int      $post_id  Post ID.
	 * @param string   $meta_key Source meta key.
	 * @param callable $callback Callback to run.
	 * @return void
	 */
	private static function run_with_gallery_only_db2_rebuild_context( int $post_id, string $meta_key, callable $callback ): void {
		$context_key = self::build_gallery_only_context_key( $post_id, $meta_key );
		if ( ! isset( $GLOBALS['__fifu_dev_gallery_only_db2_rebuild'] ) || ! is_array( $GLOBALS['__fifu_dev_gallery_only_db2_rebuild'] ) ) {
			$GLOBALS['__fifu_dev_gallery_only_db2_rebuild'] = array();
		}
		$GLOBALS['__fifu_dev_gallery_only_db2_rebuild'][ $context_key ] = true;

		try {
			$callback();
		} finally {
			unset( $GLOBALS['__fifu_dev_gallery_only_db2_rebuild'][ $context_key ] );
		}
	}

	/**
	 * Execute a callback while marking a developer video list rebuild as gallery-only in DB2.
	 *
	 * @param int      $post_id  Post ID.
	 * @param string   $meta_key Source meta key.
	 * @param callable $callback Callback to run.
	 * @return void
	 */
	private static function run_with_video_gallery_only_db2_rebuild_context( int $post_id, string $meta_key, callable $callback ): void {
		$context_key = self::build_video_gallery_only_context_key( $post_id, $meta_key );
		if ( ! isset( $GLOBALS['__fifu_dev_video_gallery_only_db2_rebuild'] ) || ! is_array( $GLOBALS['__fifu_dev_video_gallery_only_db2_rebuild'] ) ) {
			$GLOBALS['__fifu_dev_video_gallery_only_db2_rebuild'] = array();
		}
		$GLOBALS['__fifu_dev_video_gallery_only_db2_rebuild'][ $context_key ] = true;

		try {
			$callback();
		} finally {
			unset( $GLOBALS['__fifu_dev_video_gallery_only_db2_rebuild'][ $context_key ] );
		}
	}

	/**
	 * Build the runtime context key for a post/meta pair.
	 *
	 * @param int    $post_id  Post ID.
	 * @param string $meta_key Meta key.
	 * @return string
	 */
	private static function build_gallery_only_context_key( int $post_id, string $meta_key ): string {
		return $post_id . ':' . $meta_key;
	}

	/**
	 * Build the runtime context key for a video list rebuild.
	 *
	 * @param int    $post_id  Post ID.
	 * @param string $meta_key Meta key.
	 * @return string
	 */
	private static function build_video_gallery_only_context_key( int $post_id, string $meta_key ): string {
		return $post_id . ':' . $meta_key;
	}

	/**
	 * Run a callback while exposing a temporary request payload, preserving any previous value.
	 *
	 * @param string   $key
	 * @param string   $value
	 * @param callable $callback
	 * @return mixed
	 */
	private static function run_with_temporary_request_value( string $key, string $value, callable $callback ) {
		$had_previous = array_key_exists( $key, $_REQUEST );
		$previous = $had_previous ? $_REQUEST[ $key ] : null;

		$_REQUEST[ $key ] = $value;

		try {
			return $callback();
		} finally {
			if ( $had_previous ) {
				$_REQUEST[ $key ] = $previous;
			} else {
				unset( $_REQUEST[ $key ] );
			}
		}
	}

	/**
	 * If images were removed and videos remain only as gallery rows, promote the first video to featured.
	 *
	 * @param int $post_id
	 * @return void
	 */
	private static function promote_first_video_to_featured_after_image_removal( int $post_id ): void {
		if ( ! function_exists( 'fifu_db2_manager' ) || ! class_exists( 'Fifu_Db2_Manager', false ) ) {
			return;
		}

		$manager = fifu_db2_manager();
		if ( ! $manager instanceof Fifu_Db2_Manager || ! method_exists( $manager, 'getPostMappings' ) ) {
			return;
		}

		$rows = $manager->getPostMappings( $post_id, 'video' );
		if ( ! is_array( $rows ) || empty( $rows ) ) {
			return;
		}

		$has_video = false;
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$url = trim( (string) ( $row['url'] ?? '' ) );
			if ( $url !== '' ) {
				$has_video = true;
				break;
			}
		}

		if ( ! $has_video ) {
			return;
		}

		self::sync_post_media( $post_id );
	}

	/**
	 * If videos were removed and images remain only as gallery rows, promote the first image to featured.
	 *
	 * @param int $post_id
	 * @return void
	 */
	private static function promote_first_image_to_featured_after_video_removal( int $post_id ): void {
		if ( ! function_exists( 'fifu_db2_manager' ) || ! class_exists( 'Fifu_Db2_Manager', false ) ) {
			return;
		}

		$manager = fifu_db2_manager();
		if ( ! $manager instanceof Fifu_Db2_Manager || ! method_exists( $manager, 'getPostMappings' ) ) {
			return;
		}

		if ( class_exists( 'Fifu_Post_Custom_Video_Read_Service', false ) ) {
			$custom_video = Fifu_Post_Custom_Video_Read_Service::get_custom_video_url( $post_id );
			if ( is_string( $custom_video ) && trim( $custom_video ) !== '' ) {
				return;
			}
		}

		$rows = $manager->getPostMappings( $post_id, 'image' );
		if ( ! is_array( $rows ) || empty( $rows ) ) {
			return;
		}

		$urls_by_index = array();
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$url = trim( (string) ( $row['url'] ?? '' ) );
			if ( $url === '' ) {
				continue;
			}

			$index = array_key_exists( 'key_index', $row ) ? (int) $row['key_index'] : count( $urls_by_index );
			$urls_by_index[ $index ] = $url;
		}

		if ( empty( $urls_by_index ) ) {
			return;
		}

		ksort( $urls_by_index );
		$urls = array_values( $urls_by_index );
		$first_url = (string) ( $urls[0] ?? '' );
		if ( '' === $first_url ) {
			return;
		}

		$alts_by_index = array();
		if ( method_exists( $manager, 'getPostAltMappings' ) ) {
			$alt_rows = $manager->getPostAltMappings( $post_id, 'image' );
			if ( is_array( $alt_rows ) ) {
				foreach ( $alt_rows as $row ) {
					if ( ! is_array( $row ) ) {
						continue;
					}

					$alt = trim( wp_strip_all_tags( (string) ( $row['alt'] ?? '' ) ) );
					if ( $alt === '' ) {
						continue;
					}

					$index = array_key_exists( 'key_index', $row ) ? (int) $row['key_index'] : count( $alts_by_index );
					$alts_by_index[ $index ] = $alt;
				}
			}
		}

		$first_alt = '';
		if ( array_key_exists( 0, $alts_by_index ) ) {
			$first_alt = (string) $alts_by_index[0];
		}

		self::persist_featured_image_legacy_state( $post_id, $first_url );
		if ( ! self::is_effectively_empty_alt_value( $first_alt ) ) {
			FIFU_Post_Meta_Updater::instance()->update_or_delete_with_status( $post_id, 'fifu_image_alt', $first_alt );
		}

		Fifu_Post_Attachment_Sync_Service::sync_featured_attachment( $post_id );
		Fifu_Post_Attachment_Sync_Service::sync_gallery_attachments( $post_id );
		Fifu_Post_Attachment_Sync_Service::sync_theme_property_images( $post_id );
	}

	/**
	 * Remove all DB2 video state for a post.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	private static function delete_all_db2_post_video_state( int $post_id ): void {
		if ( ! function_exists( 'fifu_db2_manager' ) || ! class_exists( 'Fifu_Db2_Manager', false ) ) {
			return;
		}

		$manager = fifu_db2_manager();
		if ( ! $manager instanceof Fifu_Db2_Manager ) {
			return;
		}

		if ( method_exists( $manager, 'deletePostMappings' ) ) {
			$manager->deletePostMappings( $post_id, 'video' );
			$manager->deletePostMappings( $post_id, 'custom_video' );
		}
	}

	/**
	 * Remove all DB2 image state for a post.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	private static function delete_all_db2_post_image_state( int $post_id ): void {
		if ( ! function_exists( 'fifu_db2_manager' ) || ! class_exists( 'Fifu_Db2_Manager', false ) ) {
			return;
		}

		$manager = fifu_db2_manager();
		if ( ! $manager instanceof Fifu_Db2_Manager ) {
			return;
		}

		if ( method_exists( $manager, 'deletePostMappings' ) ) {
			$manager->deletePostMappings( $post_id, 'image' );
		}

		if ( method_exists( $manager, 'deletePostAltMappings' ) ) {
			$manager->deletePostAltMappings( $post_id, 'image' );
		}
	}
}
