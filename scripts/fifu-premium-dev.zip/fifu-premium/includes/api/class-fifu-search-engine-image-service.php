<?php

declare(strict_types=1);

/**
 * Encapsulates the DuckDuckGo worker interaction used by the legacy finder.
 */
class Fifu_Search_Engine_Image_Service {

    /**
     * Search for images via the DDG worker using keywords and optional context.
     */
    public function search(string $keywords, ?int $postId, bool $many) {
        $width = get_option('fifu_auto_set_width');
        $height = get_option('fifu_auto_set_height');
        $blocklist = (string) get_option('fifu_auto_set_blocklist');
        $blocklistArr = $blocklist !== '' ? explode(PHP_EOL, $blocklist) : null;
        $sources = str_replace(' ', '', (string) get_option('fifu_auto_set_source'));
        $layout = (string) get_option('fifu_auto_set_layout');

        $siteUrl = get_site_url();
        $urlComponents = parse_url($siteUrl);
        $domain = $urlComponents['host'] ?? '';

        $newMd5 = md5($this->concatenate_variables($keywords, $width, $height, $blocklistArr, $sources, $layout));
        $jsonArr = $postId ? get_post_meta($postId, 'fifu_search_proxy', true) : null;

        if ($jsonArr) {
            $arr = json_decode($jsonArr, true);
            $oldMd5 = $arr[0] ?? null;
            $attemptsProxy = ($oldMd5 === $newMd5) ? ($arr[1] ?? 1) : 1;
        } else {
            $attemptsProxy = 1;
        }

        if ($attemptsProxy > 3) {
            return null;
        }

        Fifu_File_Logger::plugin(['fifu-ddg' => ['INFO' => $keywords]]);
        Fifu_File_Logger::plugin(['fifu-ddg' => ['INFO' => 'Attempts proxy: ' . $attemptsProxy]]);

        $res = $this->get_results($sources, $keywords, $layout, $domain, $blocklistArr, $width, $height);
        $data = $res ? json_decode($res) : null;

        if (!$data) {
            if ($postId) {
                $this->update_search_meta($jsonArr, $newMd5, $postId);
            }

            Fifu_File_Logger::plugin(['fifu-ddg' => ['WARNING' => 'not found']]);
            return null;
        }

        if ($postId) {
            delete_post_meta($postId, 'fifu_search_proxy');
        }

        if (!$many) {
            foreach ($data as $img) {
                if (Fifu_Image_Url_Utils::is_valid_image_url($img->url ?? '')) {
                    Fifu_File_Logger::plugin(['fifu-ddg' => ['INFO' => $img->url]]);
                    return $img;
                }
            }

            return null;
        }

        return $data;
    }

    /**
     * Build the worker query string based on the provided arguments.
     */
    private function concatenate_variables(string $keywords, $width, $height, ?array $blocklist, string $sources, string $layout): string {
        $concatenatedValues = $keywords . $width . $height . $sources . $layout;

        if (is_array($blocklist)) {
            foreach ($blocklist as $item) {
                $concatenatedValues .= $item;
            }
        }

        return $concatenatedValues;
    }

    /**
     * Update the stored search metadata for a specific post.
     */
    private function update_search_meta(?string $json_arr, string $new_md5, int $post_id): void {
        if ($json_arr) {
            $arr = json_decode($json_arr, true);
            if (is_array($arr) && count($arr) >= 2) {
                $old_md5 = $arr[0] ?? null;
                $attempts = ($old_md5 == $new_md5) ? (($arr[1] ?? 0) + 1) : 1;
            } else {
                $attempts = 1;
            }
        } else {
            $attempts = 1;
        }

        $new_arr = [$new_md5, $attempts];
        $json_arr = json_encode($new_arr);
        update_post_meta($post_id, 'fifu_search_proxy', $json_arr);
    }

    /**
     * Execute the configured search request and return the filtered payload.
     */
    private function get_results(string $sources, string $keywords, string $layout, string $domain, ?array $blocklist, $width, $height): ?string {
        $queryParams = http_build_query([
            'site' => Fifu_Image_Url_Utils::get_home_url_no_scheme(),
            'partial_key' => Fifu_Options_Utils::partial_key(),
            'sources' => $sources,
            'keywords' => $keywords,
            'layout' => $layout,
            'domain' => $domain,
            'blocklist' => $blocklist ? implode(',', $blocklist) : '',
            'width' => $width,
            'height' => $height,
        ]);

        $workerEndpoint = 'https://search-engine-image.fifu.app';
        $url = "{$workerEndpoint}?{$queryParams}";

        $response = wp_safe_remote_get($url, ['timeout' => 30]);

        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) != 200) {
            Fifu_File_Logger::plugin(['fifu-ddg' => ['ERROR' => $response]]);
            return null;
        }

        $body = wp_remote_retrieve_body($response);
        return $body;
    }
}
