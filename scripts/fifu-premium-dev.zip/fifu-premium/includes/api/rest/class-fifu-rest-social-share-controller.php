<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

class Fifu_Rest_Social_Share_Controller {

    protected static string $namespace = 'fifu-premium/v2';
    protected static string $rest_base = 'social';

    public static function register_routes(): void {
        $permission = [Fifu_Auto_Share_Common::class, 'can_manage'];
        register_rest_route(self::$namespace, '/' . self::$rest_base . '/(?P<provider>[a-z0-9_-]+)/auth/start', [
            'methods' => 'POST',
            'callback' => [self::class, 'handle_auth_start'],
            'permission_callback' => $permission,
        ]);
        register_rest_route(self::$namespace, '/' . self::$rest_base . '/(?P<provider>[a-z0-9_-]+)/auth/finalize', [
            'methods' => 'POST',
            'callback' => [self::class, 'handle_auth_finalize'],
            'permission_callback' => $permission,
        ]);
        register_rest_route(self::$namespace, '/' . self::$rest_base . '/(?P<provider>[a-z0-9_-]+)/status', [
            'methods' => 'GET',
            'callback' => [self::class, 'handle_status'],
            'permission_callback' => $permission,
        ]);
        register_rest_route(self::$namespace, '/' . self::$rest_base . '/(?P<provider>[a-z0-9_-]+)/disconnect', [
            'methods' => 'POST',
            'callback' => [self::class, 'handle_disconnect'],
            'permission_callback' => $permission,
        ]);
        register_rest_route(self::$namespace, '/share/facebook', [
            'methods' => 'POST',
            'callback' => [self::class, 'share_facebook'],
            'permission_callback' => $permission,
        ]);
        register_rest_route(self::$namespace, '/share/instagram', [
            'methods' => 'POST',
            'callback' => [self::class, 'share_instagram'],
            'permission_callback' => $permission,
        ]);
        register_rest_route(self::$namespace, '/share/x', [
            'methods' => 'POST',
            'callback' => [self::class, 'share_x'],
            'permission_callback' => $permission,
        ]);
    }

    public static function handle_auth_start(\WP_REST_Request $request) {
        $provider = self::normalize_provider($request->get_param('provider'));
        $service = self::get_provider_service($provider);
        if (!$service) {
            return self::unknown_provider_error();
        }
        return $service::auth_start($request);
    }

    public static function handle_auth_finalize(\WP_REST_Request $request) {
        $provider = self::normalize_provider($request->get_param('provider'));
        $service = self::get_provider_service($provider);
        if (!$service) {
            return self::unknown_provider_error();
        }
        return $service::auth_finalize($request);
    }

    public static function handle_status(\WP_REST_Request $request) {
        $provider = self::normalize_provider($request->get_param('provider'));
        $service = self::get_provider_service($provider);
        if (!$service) {
            return self::unknown_provider_error();
        }
        return $service::status($request);
    }

    public static function handle_disconnect(\WP_REST_Request $request) {
        $provider = self::normalize_provider($request->get_param('provider'));
        $service = self::get_provider_service($provider);
        if (!$service) {
            return self::unknown_provider_error();
        }
        return $service::disconnect($request);
    }

    public static function share_facebook(\WP_REST_Request $request) {
        return Fifu_Auto_Share_Facebook_Service::share_post($request);
    }

    public static function share_instagram(\WP_REST_Request $request) {
        return Fifu_Auto_Share_Instagram_Service::share_post($request);
    }

    public static function share_x(\WP_REST_Request $request) {
        return Fifu_Auto_Share_X_Service::share_post($request);
    }

    private static function normalize_provider($provider): string {
        $provider = sanitize_key((string) $provider);
        if ($provider === 'twitter') {
            return 'x';
        }
        return $provider;
    }

    private static function get_provider_service(string $provider): ?string {
        switch ($provider) {
            case 'facebook':
                return Fifu_Auto_Share_Facebook_Service::class;
            case 'instagram':
                return Fifu_Auto_Share_Instagram_Service::class;
            case 'x':
                return Fifu_Auto_Share_X_Service::class;
            default:
                return null;
        }
    }

    private static function unknown_provider_error() {
        return new \WP_Error('fifu_as_unknown_provider', 'Provider not supported', ['status' => 400]);
    }
}
