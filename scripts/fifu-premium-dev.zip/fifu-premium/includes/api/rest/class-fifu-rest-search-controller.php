<?php

class Fifu_Rest_Search_Controller {

    /**
     * Registers the DuckDuckGo search REST endpoint migrated from fifu_api_ddg_search().
     */
    public static function register_routes(): void {
        register_rest_route('fifu-premium/v2', '/ddg_search/', array(
            'methods'             => 'POST',
            'callback'            => array(self::class, 'ddg_search'),
            'permission_callback' => [self::class, 'search_permission'],
        ));
        register_rest_route('fifu-premium/v2', '/unsplash_search/', array(
            'methods'             => 'POST',
            'callback'            => array(self::class, 'unsplash_search'),
            'permission_callback' => [self::class, 'search_permission'],
        ));
    }

    /**
     * Authorizes image searches and protects DDG's implicit post/term keyword sources.
     */
    public static function search_permission(\WP_REST_Request $request) {
        if (!current_user_can('upload_files')) {
            return self::authorization_error();
        }

        $nonce = (string) $request->get_header('X-WP-Nonce');
        if ($nonce !== '' && !wp_verify_nonce($nonce, 'wp_rest')) {
            return self::authorization_error();
        }

        $is_ddg_search = rtrim($request->get_route(), '/') === '/fifu-premium/v2/ddg_search';
        if (!$is_ddg_search || $request->get_param('keywords')) {
            return true;
        }

        $object_id = absint($request->get_param('post_id'));
        if ($object_id <= 0) {
            return self::authorization_error();
        }

        if ($request->get_param('is_ctgr')) {
            $term = get_term($object_id, 'product_cat');
            if (is_wp_error($term) || !$term || $term->taxonomy !== 'product_cat' || !current_user_can('edit_term', $object_id)) {
                return self::authorization_error();
            }

            return true;
        }

        if (!get_post($object_id) || !current_user_can('edit_post', $object_id)) {
            return self::authorization_error();
        }

        return true;
    }

    private static function authorization_error(): \WP_Error {
        return new \WP_Error(
            'rest_forbidden',
            __('Sorry, you are not allowed to do that.'),
            array('status' => rest_authorization_required_code())
        );
    }

    /**
     * Executes the legacy ddg search logic via Fifu_Search_Engine_Image_Service.
     */
    public static function ddg_search(WP_REST_Request $request): WP_REST_Response {
        $keywords = $request->get_param('keywords');
        if (!$keywords) {
            $post_id = $request->get_param('post_id');
            $is_category = $request->get_param('is_ctgr');
            if ($is_category) {
                $category = get_term($post_id, 'product_cat');
                $keywords = $category->name ?? '';
            } else {
                $keywords = strip_tags(get_the_title($post_id));
            }
        }
        $search_service = new Fifu_Search_Engine_Image_Service();
        $results = $search_service->search($keywords, null, true);
        return new WP_REST_Response($results, 200);
    }

    public static function unsplash_search(WP_REST_Request $request): WP_REST_Response {
        $keywords = trim((string) $request->get_param('keywords'));
        if ($keywords === '') {
            return new WP_REST_Response([], 200);
        }

        $page = absint($request->get_param('page'));
        if ($page <= 0) {
            $page = 1;
        }

        $search_service = new Fifu_Unsplash_Image_Service();
        $results = $search_service->search($keywords, $page);

        if (!is_array($results)) {
            $results = [];
        }

        return new WP_REST_Response($results, 200);
    }
}
