<?php

if ( ! class_exists( 'Fifu_Legacy_Media_Meta_Cleanup_Service', false ) ) {
    require_once __DIR__ . '/../../meta/class-fifu-legacy-media-meta-cleanup-service.php';
}

class Fifu_Rest_Import_Worker_Controller {

    /**
     * Registers import and metadata batch endpoints migrated from admin/api.php.
     */
    public static function register_routes(): void {
        register_rest_route('fifu-premium/v2', '/import-term/', array(
            'methods'             => 'POST',
            'callback'            => array(self::class, 'import_term'),
            'permission_callback' => array(self::class, 'import_permission_check'),
            'args'                => array(
                'post_ids' => array(
                    'required'          => true,
                    'validate_callback' => array(self::class, 'validate_numeric_id_array'),
                ),
            ),
        ));

        register_rest_route('fifu-premium/v2', '/import-post/', array(
            'methods'             => 'POST',
            'callback'            => array(self::class, 'import_post'),
            'permission_callback' => array(self::class, 'import_permission_check'),
            'args'                => array(
                'post_ids' => array(
                    'required'          => true,
                    'validate_callback' => array(self::class, 'validate_numeric_id_array'),
                ),
            ),
        ));

        register_rest_route('fifu-premium/v2', '/metadata-term/', array(
            'methods'             => 'POST',
            'callback'            => array(self::class, 'sync_metadata_term'),
            'permission_callback' => array(self::class, 'metadata_permission_check'),
            'args'                => array(
                'post_ids' => array(
                    'required'          => true,
                    'validate_callback' => array(self::class, 'validate_numeric_id_array'),
                ),
            ),
        ));

        register_rest_route('fifu-premium/v2', '/metadata-post/', array(
            'methods'             => 'POST',
            'callback'            => array(self::class, 'sync_metadata_post'),
            'permission_callback' => array(self::class, 'metadata_permission_check'),
            'args'                => array(
                'post_ids' => array(
                    'required'          => true,
                    'validate_callback' => array(self::class, 'validate_numeric_id_array'),
                ),
            ),
        ));
    }

    /**
     * Handles legacy import-term behavior using Fifu_Metadata_Import_Service and cron toggles.
     */
    public static function import_term(WP_REST_Request $request): WP_REST_Response {
        $term_ids = $request->get_param('post_ids');
        $meta_key = 'fifu_importterm_sent';
        $import_service = fifu_db2_import_service();
        $valid_ids = $import_service->get_valid_term_ids($term_ids, $meta_key);
        if ($valid_ids) {
            Fifu_Metadata_Import_Service::run_import($valid_ids, $meta_key, true);
        }
        foreach ($term_ids as $term_id) {
            $fail = !$valid_ids || !in_array($term_id, $valid_ids);

            if ($fail) {
                $attempts = Fifu_Sent_Bridge::get_term_sent_attempts($term_id, 'importterm');
                $attempts = $attempts ?? 0;
                Fifu_Sent_Bridge::set_term_sent_attempts($term_id, 'importterm', $attempts + 1);
            }

            $attempts = isset($attempts) && is_numeric($attempts) ? (int) $attempts : 0;
            if (!$fail || $attempts >= 5) {
                if ($fail) {
                    Fifu_Sent_Bridge::delete_term_sent($term_id, 'importterm');
                }
            }
        }

        return new WP_REST_Response('', 200);
    }

    /**
     * Handles legacy import-post behavior using Fifu_Metadata_Import_Service and cron toggles.
     */
    public static function import_post(WP_REST_Request $request): WP_REST_Response {
        $post_ids = $request->get_param('post_ids');
        $meta_key = 'fifu_importpost_sent';
        $import_service = fifu_db2_import_service();
        $valid_ids = $import_service->get_valid_post_ids($post_ids, $meta_key);
        if ($valid_ids) {
            Fifu_Metadata_Import_Service::run_import($valid_ids, $meta_key, false);
        }
        foreach ($post_ids as $post_id) {
            $fail = !$valid_ids || !in_array($post_id, $valid_ids);

            if ($fail) {
                $attempts = Fifu_Sent_Bridge::get_post_sent_attempts($post_id, 'importpost');
                $attempts = $attempts ?? 0;
                Fifu_Sent_Bridge::set_post_sent_attempts($post_id, 'importpost', $attempts + 1);
            }

            $attempts = isset($attempts) && is_numeric($attempts) ? (int) $attempts : 0;
            if (!$fail || $attempts >= 5) {
                if ($fail) {
                    Fifu_Sent_Bridge::delete_post_sent($post_id, 'importpost');
                }
            }
        }

        return new WP_REST_Response('', 200);
    }

    /**
     * Handles metadata-term batch updates migrated from fifu_api_metadata_term().
     */
    public static function sync_metadata_term(WP_REST_Request $request): WP_REST_Response {
        $term_ids = $request->get_param('post_ids');
        $to_delete = array();
        $had_failure = false;

        foreach ($term_ids as $term_id) {
            $existing_attempts = Fifu_Sent_Bridge::get_term_sent_attempts($term_id, 'metadataterm');
            $fail = $existing_attempts === null;

            if (!$fail && self::term_featured_media_legacy_meta_requires_migration((int) $term_id)) {
                if (!self::migrate_term_featured_media_legacy_meta_to_db2((int) $term_id)) {
                    $fail = true;
                }
            }

            if (!$fail) {
                Fifu_Post_Attachment_Sync_Service::sync_category_attachment($term_id);
            }

            if ($fail) {
                $attempts = $existing_attempts ?? 0;
                Fifu_Sent_Bridge::set_term_sent_attempts($term_id, 'metadataterm', $attempts + 1);
                $had_failure = true;
                continue;
            }

            $to_delete[] = $term_id;
            Fifu_Sent_Bridge::delete_term_sent($term_id, 'metadataterm');
        }

        if (!empty($to_delete)) {
            Fifu_Remote_Worker_Client::delete_registers($to_delete, 'metadataterm');
        }

        if ($had_failure) {
            return new WP_REST_Response(array('code' => 'fifu_metadata_term_sync_failed'), 500);
        }

        return new WP_REST_Response('', 200);
    }

    /**
     * Handles metadata-post batch updates migrated from fifu_api_metadata_post().
     */
    public static function sync_metadata_post(WP_REST_Request $request): WP_REST_Response {
        $post_ids = $request->get_param('post_ids');
        $meta_key = 'fifu_metadatapost_sent';
        $to_delete = array();
        $bulk_processed_ids = array();
        $bulk_candidate_count = 0;
        $bulk_processed_count = 0;
        $fallback_count = 0;
        $failure_count = 0;
        $post_ids_count = is_array($post_ids) ? count($post_ids) : 0;

        if (class_exists('Fifu_Metadata_Post_Bulk_Sync_Service')) {
            // Method name is historical; it now returns clean product candidates and clean featured-image-only normal post candidates.
            $selection = Fifu_Metadata_Post_Bulk_Sync_Service::select_bulk_candidate_product_ids((array) $post_ids);
            $bulk_candidate_ids = (array) ($selection['candidate_ids'] ?? array());
            $bulk_candidate_count = count($bulk_candidate_ids);

            if (get_option('fifu_debug_legacy_bulk_selection') === 'toggleon') {
                error_log(sprintf(
                    '[FIFU MetadataPost Bulk Candidate Debug] input=%d bulk_candidates=%d fallback=%d',
                    count($post_ids),
                    count($bulk_candidate_ids),
                    count(array_diff((array) $post_ids, $bulk_candidate_ids))
                ));
            }

            if (!empty($bulk_candidate_ids)) {
                $bulk_result = Fifu_Metadata_Post_Bulk_Sync_Service::sync_posts($bulk_candidate_ids);
                foreach ((array) ($bulk_result['processed_ids'] ?? array()) as $processed_id) {
                    $bulk_processed_ids[(int) $processed_id] = true;
                }
                $bulk_processed_count = count($bulk_processed_ids);
            }
        }

        foreach ($post_ids as $post_id) {
                $fail = false;
                if (isset($bulk_processed_ids[(int) $post_id])) {
                    $to_delete[] = (int) $post_id;
                    continue;
                }

                $existing_attempts = Fifu_Sent_Bridge::get_post_sent_attempts($post_id, 'metadatapost');

                if ($existing_attempts === null) {
                    $fail = true;
                } else {
                    $plan = class_exists('Fifu_Metadata_Post_Work_Plan_Service')
                        ? Fifu_Metadata_Post_Work_Plan_Service::build_for_post((int) $post_id)
                        : array(
                            'should_split_lists' => true,
                            'should_run_legacy_cleanup' => true,
                            'should_sync_metadata' => true,
                        );

                    if (!empty($plan['should_split_lists'])) {
                        if (isset($GLOBALS['__fifu_metadata_post_test_counters'])) {
                            $GLOBALS['__fifu_metadata_post_test_counters']['split_lists'] =
                                (int) ($GLOBALS['__fifu_metadata_post_test_counters']['split_lists'] ?? 0) + 1;
                        }

                        Fifu_Wai_Meta_Service::split_lists($post_id);
                    }

                    if (!empty($plan['should_sync_metadata'])) {
                        Fifu_Post_Attachment_Sync_Service::sync_featured_attachment($post_id);

                        $post_type = get_post_type((int) $post_id);
                        $has_legacy_slider_media_input = self::has_legacy_slider_media_input((int) $post_id);
                        if (in_array($post_type, array('product', 'product_variation'), true) || $has_legacy_slider_media_input) {
                            Fifu_Post_Attachment_Sync_Service::sync_gallery_attachments($post_id);
                        }
                    }

                    if (!empty($plan['should_run_legacy_cleanup'])) {
                        if (isset($GLOBALS['__fifu_metadata_post_test_counters'])) {
                            $GLOBALS['__fifu_metadata_post_test_counters']['legacy_cleanup_featured_image'] =
                                (int) ($GLOBALS['__fifu_metadata_post_test_counters']['legacy_cleanup_featured_image'] ?? 0) + 1;
                        }
                        self::cleanup_confirmed_featured_image_legacy_meta($post_id);

                        if (isset($GLOBALS['__fifu_metadata_post_test_counters'])) {
                            $GLOBALS['__fifu_metadata_post_test_counters']['legacy_cleanup_image'] =
                                (int) ($GLOBALS['__fifu_metadata_post_test_counters']['legacy_cleanup_image'] ?? 0) + 1;
                        }
                        Fifu_Legacy_Media_Meta_Cleanup_Service::cleanup_post_image_meta_after_db2_sync($post_id);

                        if (isset($GLOBALS['__fifu_metadata_post_test_counters'])) {
                            $GLOBALS['__fifu_metadata_post_test_counters']['legacy_cleanup_video'] =
                                (int) ($GLOBALS['__fifu_metadata_post_test_counters']['legacy_cleanup_video'] ?? 0) + 1;
                        }
                        Fifu_Legacy_Media_Meta_Cleanup_Service::cleanup_post_video_meta_after_db2_sync($post_id);

                        if (isset($GLOBALS['__fifu_metadata_post_test_counters'])) {
                            $GLOBALS['__fifu_metadata_post_test_counters']['legacy_cleanup_slider'] =
                                (int) ($GLOBALS['__fifu_metadata_post_test_counters']['legacy_cleanup_slider'] ?? 0) + 1;
                        }
                        Fifu_Legacy_Media_Meta_Cleanup_Service::cleanup_post_slider_meta_after_db2_sync($post_id);
                    }

                    Fifu_Post_Attachment_Sync_Service::sync_theme_property_images($post_id);
                }

                if ($fail) {
                    $attempts = $existing_attempts ?? 0;
                    Fifu_Sent_Bridge::set_post_sent_attempts($post_id, 'metadatapost', $attempts + 1);
                    $failure_count++;
                } else {
                    $fallback_count++;
                }

                $attempts = isset($attempts) && is_numeric($attempts) ? (int) $attempts : 0;
                if (!$fail || $attempts >= 5) {
                    $to_delete[] = $post_id;
                    Fifu_Sent_Bridge::delete_post_sent($post_id, 'metadatapost');
                }

            }

        $to_delete = array_values(array_unique(array_map('intval', $to_delete)));

        if (!empty($to_delete)) {
            Fifu_Remote_Worker_Client::delete_registers($to_delete, 'metadatapost');
        }

        return new WP_REST_Response('', 200);
    }

    private static function cleanup_confirmed_featured_image_legacy_meta(int $post_id): void
    {
        if (!function_exists('get_post_meta') || !function_exists('fifu_db2_manager')) {
            return;
        }

        $legacy_url = trim((string) get_post_meta($post_id, 'fifu_image_url', true));
        $legacy_alt = trim((string) get_post_meta($post_id, 'fifu_image_alt', true));
        if ($legacy_url === '' && $legacy_alt === '') {
            return;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return;
        }

        $db2_url_mapping = $manager->getPostMapping($post_id, 'image', 0);
        $db2_alt_mapping = $manager->getPostAltMapping($post_id, 'image', 0);
        $db2_url = is_array($db2_url_mapping) ? trim((string) ($db2_url_mapping['url'] ?? '')) : '';
        $db2_alt = is_array($db2_alt_mapping) ? trim((string) ($db2_alt_mapping['alt'] ?? $db2_alt_mapping['value'] ?? '')) : '';

        if (!Fifu_Metadata_Db2_Cleanup_Guard::can_cleanup_url_and_alt($legacy_url, $legacy_alt, $db2_url, $db2_alt)) {
            return;
        }

        delete_post_meta($post_id, 'fifu_image_url');
        delete_post_meta($post_id, 'fifu_image_alt');
        clean_post_cache($post_id);
        wp_cache_delete($post_id, 'post_meta');
    }

    /**
     * Requires an authorization token and import-capable plugins for import endpoints.
     */
    public static function import_permission_check(WP_REST_Request $request): bool {
        $can_import = class_exists('WooCommerce') || (class_exists('Fifu_Plugin_Detector') && Fifu_Plugin_Detector::is_wp_all_import_active());
        if (!$can_import) {
            return false;
        }

        $route = rtrim((string) $request->get_route(), '/');
        $tokenKey = null;
        if ($route === '/fifu-premium/v2/import-post') {
            $tokenKey = 'fifu_api_importpost_auth_token';
        } elseif ($route === '/fifu-premium/v2/import-term') {
            $tokenKey = 'fifu_api_importterm_auth_token';
        }

        if ($tokenKey !== null) {
            $localToken = (string) $request->get_header('X-FIFU-Authorization');
            $storedToken = Fifu_Transient_Manager::get($tokenKey);
            if (
                $localToken !== ''
                && is_scalar($storedToken)
                && (string) $storedToken !== ''
                && hash_equals((string) $storedToken, $localToken)
            ) {
                Fifu_Transient_Manager::delete($tokenKey);
                return true;
            }
        }

        $token = self::get_remote_token($request);
        return $token === get_option('fifu_ws_key_ddg');
    }

    /**
     * Requires the metadata cron option and valid authorization token for metadata batches.
     */
    public static function metadata_permission_check(WP_REST_Request $request): bool {
        $token = self::get_remote_token($request);
        $metadata_cron_allowed = Fifu_Options_Utils::is_on('fifu_cron_metadata');
        return $metadata_cron_allowed && $token === get_option('fifu_ws_key_ddg');
    }

    private static function get_remote_token(WP_REST_Request $request): string {
        $token = (string) $request->get_header('X-FIFU-Authorization');
        if ($token !== '') {
            return $token;
        }

        return (string) $request->get_header('Authorization');
    }

    private static function term_featured_media_legacy_meta_requires_migration(int $term_id): bool {
        $legacy_image_url = trim((string) get_term_meta($term_id, 'fifu_image_url', true));
        if ($legacy_image_url !== '') {
            return true;
        }

        $legacy_video_url = trim((string) get_term_meta($term_id, 'fifu_video_url', true));
        if ($legacy_video_url !== '') {
            return true;
        }

        $legacy_image_alt = trim((string) get_term_meta($term_id, 'fifu_image_alt', true));
        if ($legacy_image_alt === '') {
            return false;
        }

        return self::term_has_db2_image_mapping($term_id);
    }

    private static function migrate_term_featured_media_legacy_meta_to_db2(int $term_id): bool {
        $legacy_image_url = trim((string) get_term_meta($term_id, 'fifu_image_url', true));
        $legacy_image_alt = trim((string) get_term_meta($term_id, 'fifu_image_alt', true));
        $legacy_video_url = trim((string) get_term_meta($term_id, 'fifu_video_url', true));

        $legacy_image_alt_should_migrate = $legacy_image_alt !== '' && ($legacy_image_url !== '' || self::term_has_db2_image_mapping($term_id));

        if ($legacy_image_url !== '' && !self::migrate_term_image_url_to_db2($term_id, $legacy_image_url)) {
            return false;
        }

        if ($legacy_image_alt_should_migrate && !self::migrate_term_image_alt_to_db2($term_id, $legacy_image_alt)) {
            return false;
        }

        if ($legacy_video_url !== '' && !self::migrate_term_video_url_to_db2($term_id, $legacy_video_url)) {
            return false;
        }

        if ($legacy_image_url !== '' && !self::is_term_featured_image_migrated_to_db2($term_id, $legacy_image_url)) {
            return false;
        }

        if ($legacy_image_alt_should_migrate && !self::is_term_featured_alt_migrated_to_db2($term_id, $legacy_image_alt)) {
            return false;
        }

        if ($legacy_video_url !== '' && !self::is_term_featured_video_migrated_to_db2($term_id, $legacy_video_url)) {
            return false;
        }

        if ($legacy_image_url !== '') {
            delete_term_meta($term_id, 'fifu_image_url');
        }

        if ($legacy_image_alt_should_migrate) {
            delete_term_meta($term_id, 'fifu_image_alt');
        }

        if ($legacy_video_url !== '') {
            delete_term_meta($term_id, 'fifu_video_url');
        }

        return true;
    }

    private static function migrate_term_image_url_to_db2(int $term_id, string $legacy_image_url): bool {
        $manager = self::get_db2_manager();
        if (!$manager) {
            return false;
        }

        $image_url = function_exists('fifu_convert') ? fifu_convert($legacy_image_url) : $legacy_image_url;
        return $manager->saveTermUrl($term_id, 'image', $image_url);
    }

    private static function migrate_term_image_alt_to_db2(int $term_id, string $legacy_image_alt): bool {
        $manager = self::get_db2_manager();
        if (!$manager) {
            return false;
        }

        return $manager->saveTermAlt($term_id, 'image', $legacy_image_alt);
    }

    private static function migrate_term_video_url_to_db2(int $term_id, string $legacy_video_url): bool {
        $manager = self::get_db2_manager();
        if (!$manager) {
            return false;
        }

        return $manager->saveTermUrl($term_id, 'video', $legacy_video_url);
    }

    private static function is_term_featured_image_migrated_to_db2(int $term_id, string $legacy_image_url): bool {
        $manager = self::get_db2_manager();
        if (!$manager || !method_exists($manager, 'getTermMapping')) {
            return false;
        }

        $mapping = $manager->getTermMapping($term_id, 'image');
        if (!is_array($mapping)) {
            return false;
        }

        $expected_url = function_exists('fifu_convert') ? fifu_convert($legacy_image_url) : $legacy_image_url;
        return trim((string) ($mapping['url'] ?? '')) === trim((string) $expected_url);
    }

    private static function is_term_featured_alt_migrated_to_db2(int $term_id, string $legacy_image_alt): bool {
        $manager = self::get_db2_manager();
        if (!$manager || !method_exists($manager, 'getTermAltMapping')) {
            return false;
        }

        $mapping = $manager->getTermAltMapping($term_id, 'image');
        if (!is_array($mapping)) {
            return false;
        }

        return trim((string) ($mapping['alt'] ?? '')) === trim($legacy_image_alt);
    }

    private static function is_term_featured_video_migrated_to_db2(int $term_id, string $legacy_video_url): bool {
        $manager = self::get_db2_manager();
        if (!$manager || !method_exists($manager, 'getTermMapping')) {
            return false;
        }

        $mapping = $manager->getTermMapping($term_id, 'video');
        if (!is_array($mapping)) {
            return false;
        }

        return trim((string) ($mapping['url'] ?? '')) === trim($legacy_video_url);
    }

    private static function term_has_db2_image_mapping(int $term_id): bool {
        $manager = self::get_db2_manager();
        if (!$manager || !method_exists($manager, 'getTermMapping')) {
            return false;
        }

        return is_array($manager->getTermMapping($term_id, 'image'));
    }

    private static function has_legacy_slider_media_input(int $post_id): bool
    {
        global $wpdb;

        if (
            !isset($wpdb)
            || !is_object($wpdb)
            || !method_exists($wpdb, 'get_var')
            || !method_exists($wpdb, 'prepare')
            || empty($wpdb->postmeta)
        ) {
            return false;
        }

        $count = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(1)
             FROM {$wpdb->postmeta}
             WHERE post_id = %d
               AND meta_value IS NOT NULL
               AND TRIM(meta_value) <> ''
               AND (
                    meta_key = 'fifu_slider_list_url'
                 OR meta_key LIKE 'fifu_slider_image_url\\_%'
                 OR meta_key LIKE 'fifu_slider_image_alt\\_%'
               )",
            $post_id
        ));

        return $count > 0;
    }

    /**
     * @return Fifu_Db2_Manager|null
     */
    private static function get_db2_manager() {
        if (!function_exists('fifu_db2_manager')) {
            return null;
        }

        if (!class_exists('Fifu_Db2_Manager', false)) {
            return null;
        }

        $manager = fifu_db2_manager();
        return $manager instanceof Fifu_Db2_Manager ? $manager : null;
    }

    /**
     * Validates that the provided value is an array of numerics.
     */
    public static function validate_numeric_id_array($param, WP_REST_Request $request, $key): bool {
        if (!is_array($param)) {
            return false;
        }
        foreach ($param as $id) {
            if (!is_numeric($id)) {
                return false;
            }
        }
        return true;
    }
}
