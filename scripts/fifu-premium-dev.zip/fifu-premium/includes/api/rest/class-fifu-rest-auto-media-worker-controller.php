<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

class Fifu_Rest_Auto_Media_Worker_Controller {

    public static function register_routes(): void {
        $common_args = array(
            'post_id' => array(
                'required'          => true,
                'validate_callback' => array(self::class, 'validate_numeric_id'),
            ),
        );
        $upload_term_args = array(
            'post_id' => array(
                'required'          => false,
                'validate_callback' => array(self::class, 'validate_numeric_id'),
            ),
            'term_id' => array(
                'required'          => false,
                'validate_callback' => array(self::class, 'validate_numeric_id'),
            ),
        );

        register_rest_route('fifu-premium/v2', '/search-title/', array(
            'methods'             => 'POST',
            'callback'            => array(self::class, 'handle_search_title'),
            'permission_callback' => array(self::class, 'permission_auto_set'),
            'args'                => $common_args,
        ));
        register_rest_route('fifu-premium/v2', '/finder/', array(
            'methods'             => 'POST',
            'callback'            => array(self::class, 'handle_finder'),
            'permission_callback' => array(self::class, 'permission_finder'),
            'args'                => $common_args,
        ));
        register_rest_route('fifu-premium/v2', '/asin/', array(
            'methods'             => 'POST',
            'callback'            => array(self::class, 'handle_asin'),
            'permission_callback' => array(self::class, 'permission_asin'),
            'args'                => $common_args,
        ));
        register_rest_route('fifu-premium/v2', '/upload-post/', array(
            'methods'             => 'POST',
            'callback'            => array(self::class, 'handle_upload_post'),
            'permission_callback' => array(self::class, 'permission_upload_job'),
            'args'                => $common_args,
        ));
        register_rest_route('fifu-premium/v2', '/upload-term/', array(
            'methods'             => 'POST',
            'callback'            => array(self::class, 'handle_upload_term'),
            'permission_callback' => array(self::class, 'permission_upload_job'),
            'args'                => $upload_term_args,
        ));
    }

    public static function handle_search_title(\WP_REST_Request $request): \WP_REST_Response {
        $post_id = (int) $request->get_param('post_id');
        $meta_key = 'fifu_auto_set_sent';
        $fail = false;

        do {
            $thumbnail_id = get_post_thumbnail_id($post_id);
            if ($thumbnail_id && $thumbnail_id != get_option('fifu_default_attach_id')) {
                break;
            }

            if (Fifu_Sent_Bridge::get_post_sent_attempts($post_id, 'auto_set') === null) {
                $fail = true;
                break;
            }

            $post_title = strip_tags(get_the_title($post_id));
            $search_service = new Fifu_Search_Engine_Image_Service();
            $image = $search_service->search($post_title, $post_id, false);
            if (!$image) {
                $fail = true;
                break;
            }

            if (empty($image->url)) {
                $fail = true;
                break;
            }

            $image_saved = Fifu_Developer_Media_Service::set_image(
                (int) $post_id,
                (string) $image->url
            );

            if (!$image_saved) {
                $fail = true;
                break;
            }

            delete_post_meta($post_id, 'fifu_search');
            delete_post_meta($post_id, 'fifu_search_sent');

            $imageWidth = $image->width ?? null;
            $imageHeight = $image->height ?? null;
            if ($imageWidth && $imageHeight) {
                $thumbnailId = get_post_thumbnail_id($post_id);
                if ($thumbnailId) {
                    Fifu_Attachment_Dimensions_Service::update_dimensions(
                        (int) $thumbnailId,
                        (int) $imageWidth,
                        (int) $imageHeight
                    );
                }
            }

            FIFU_Post_Meta_Updater::instance()->update_or_delete(
                (int) $post_id,
                'fifu_redirection_url',
                $image->author_url ?? null
            );
        } while (false);

        return self::finalize_worker_attempt($post_id, $meta_key, $fail, 'title');
    }

    public static function handle_finder(\WP_REST_Request $request): \WP_REST_Response {
        $post_id = (int) $request->get_param('post_id');
        $meta_key = 'fifu_finder_sent';
        $fail = false;

        do {
            if (Fifu_Sent_Bridge::get_post_sent_attempts($post_id, 'finder') === null) {
                $fail = true;
                break;
            }

            $webpage_url = self::get_finder_source_url($post_id);

            if (empty($webpage_url)) {
                $fail = true;
                break;
            }

            $find_video = Fifu_Options_Utils::is_on('fifu_video_finder');
            $is_amazon = self::is_amazon_url($webpage_url);
            $use_amazon_worker = $is_amazon && Fifu_Options_Utils::is_on('fifu_amazon_finder');

            $finder_service = new Fifu_Media_Finder_Service();
            if (!$use_amazon_worker) {
                $url = $finder_service->find_featured_image($webpage_url, $find_video);
                if (!$url) {
                    $fail = true;
                    break;
                }

                $saved = $find_video && Fifu_Video_Helper::is_video($url)
                    ? Fifu_Developer_Media_Service::set_video((int) $post_id, (string) $url)
                    : Fifu_Developer_Media_Service::set_image((int) $post_id, (string) $url);

                if (!$saved) {
                    $fail = true;
                    break;
                }
            } else {
                $arr_urls = $finder_service->find_amazon_media($webpage_url, $post_id);
                if (empty($arr_urls)) {
                    $fail = true;
                    break;
                }

                $videos = self::normalize_worker_url_list($arr_urls['video'] ?? []);
                $images = self::normalize_worker_url_list($arr_urls['image'] ?? []);

                if (!$videos && !$images) {
                    $fail = true;
                    break;
                }

                if ($videos && !$images) {
                    if (!Fifu_Developer_Media_Service::set_video_list((int) $post_id, implode('|', $videos))) {
                        $fail = true;
                        break;
                    }
                } elseif (!self::save_amazon_finder_media((int) $post_id, $videos, $images)) {
                    $fail = true;
                    break;
                }
            }

            self::persist_finder_source_after_success($post_id, $webpage_url);
        } while (false);

        return self::finalize_worker_attempt($post_id, $meta_key, $fail, 'finder');
    }

    private static function save_amazon_finder_media(int $post_id, array $videos, array $images): bool {
        if (!$videos && !$images) {
            return false;
        }

        if ($images) {
            if (!Fifu_Developer_Media_Service::set_image_list($post_id, implode('|', $images))) {
                return false;
            }
        }

        if ($videos) {
            if (!Fifu_Developer_Media_Service::set_video_list($post_id, implode('|', $videos))) {
                return false;
            }
        }

        if (class_exists('Fifu_Post_Attachment_Sync_Service', false)) {
            Fifu_Post_Attachment_Sync_Service::sync_featured_attachment($post_id);
            Fifu_Post_Attachment_Sync_Service::sync_gallery_attachments($post_id);
            Fifu_Post_Attachment_Sync_Service::sync_theme_property_images($post_id);
        }

        return true;
    }

    public static function handle_asin(\WP_REST_Request $request): \WP_REST_Response {
        $post_id = (int) $request->get_param('post_id');
        $meta_key = 'fifu_asin_sent';
        $fail = false;

        do {
            if (Fifu_Sent_Bridge::get_post_sent_attempts($post_id, 'asin') === null) {
                $fail = true;
                break;
            }

            $asin = trim((string) Fifu_Post_Identifier_Read_Service::get_asin($post_id));
            if ($asin === '') {
                $asin = trim(self::get_first_post_meta_from_option_csv($post_id, 'fifu_asin_custom_field'));
                if ($asin !== '') {
                    FIFU_Post_Meta_Updater::instance()->update_or_delete_value(
                        (int) $post_id,
                        'fifu_asin',
                        $asin
                    );
                }
            }

            if ($asin === '' || strpos($asin, 'not-found:') === 0) {
                $fail = true;
                break;
            }

            $asin_service = new Fifu_Asin_Image_Service();
            $result = $asin_service->fetch_images_for_asin_result($asin);
            if (!$result['ok']) {
                $fail = true;
                break;
            }

            $data = is_array($result['data'] ?? null) ? $result['data'] : [];
            $images = self::normalize_asin_media_urls($data['images'] ?? $data['image'] ?? []);
            $videos = self::normalize_asin_media_urls($data['videos'] ?? $data['video'] ?? []);

            if (!empty($result['not_found'])) {
                FIFU_Post_Meta_Updater::instance()->update_or_delete_value(
                    (int) $post_id,
                    'fifu_asin',
                    'not-found:' . $asin
                );
                $fail = false;
                break;
            }

            $urls = !empty($images) ? $images : $videos;
            if (empty($urls)) {
                FIFU_Post_Meta_Updater::instance()->update_or_delete_value(
                    (int) $post_id,
                    'fifu_asin',
                    'not-found:' . $asin
                );
                $fail = false;
                break;
            }

            $urls_str = implode('|', $urls);
            $save_result = false;

            if (get_post_type($post_id) === 'product') {
                $save_result = Fifu_Developer_Media_Service::set_image_list(
                    (int) $post_id,
                    (string) $urls_str
                );
            } else {
                update_option('fifu_slider', 'toggleon', 'no');
                $save_result = Fifu_Developer_Media_Service::set_slider(
                    (int) $post_id,
                    (string) $urls_str,
                    ''
                );
            }

            if ($save_result === false) {
                $fail = true;
                break;
            }

            $product_link = isset($data['product_link']) && is_string($data['product_link'])
                ? trim($data['product_link'])
                : '';
            if ($product_link !== '' && filter_var($product_link, FILTER_VALIDATE_URL)) {
                update_post_meta($post_id, 'fifu_redirection_url', $product_link);
            }
        } while (false);

        return self::finalize_worker_attempt($post_id, $meta_key, $fail, 'asin');
    }

    public static function handle_upload_post(\WP_REST_Request $request): \WP_REST_Response {
        $post_id = (int) $request->get_param('post_id');
        $meta_key = 'fifu_uploadpost_sent';
        $fail = false;

        do {
            if (Fifu_Sent_Bridge::get_post_sent_attempts($post_id, 'uploadpost') === null) {
                $fail = true;
                break;
            }

            $fail = !Fifu_Media_Upload_Service::upload_post($post_id);
        } while (false);

        return self::finalize_worker_attempt($post_id, $meta_key, $fail, 'uploadpost');
    }

    public static function handle_upload_term(\WP_REST_Request $request): \WP_REST_Response {
        $term_id = (int) ($request->get_param('term_id') ?: $request->get_param('post_id'));
        if ($term_id <= 0) {
            $response = new \WP_REST_Response(array(
                'success' => false,
                'error'   => 'invalid_term_id',
            ));
            $response->set_status(400);
            return $response;
        }
        $meta_key = 'fifu_uploadterm_sent';
        $fail = false;

        do {
            if (Fifu_Sent_Bridge::get_term_sent_attempts($term_id, 'uploadterm') === null) {
                $fail = true;
                break;
            }

            $fail = !Fifu_Media_Upload_Service::upload_term($term_id);
        } while (false);

        return self::finalize_worker_attempt($term_id, $meta_key, $fail, 'uploadterm', true);
    }

    public static function permission_auto_set(\WP_REST_Request $request) {
        return Fifu_Options_Utils::is_on('fifu_auto_set') && self::validate_remote_token($request);
    }

    public static function permission_finder(\WP_REST_Request $request) {
        return Fifu_Options_Utils::is_on('fifu_finder') && self::validate_remote_token($request);
    }

    public static function permission_asin(\WP_REST_Request $request) {
        return Fifu_Options_Utils::is_on('fifu_asin') && self::validate_remote_token($request);
    }

    public static function permission_upload_job(\WP_REST_Request $request) {
        return Fifu_Options_Utils::is_on('fifu_upload_job') && self::validate_remote_token($request);
    }

    public static function validate_numeric_id($param, \WP_REST_Request $request, $key): bool {
        if (!is_scalar($param)) {
            return false;
        }

        return preg_match('/^[1-9][0-9]*$/', (string) $param) === 1;
    }

    private static function get_first_post_meta_from_option_csv(int $post_id, string $option_name): string {
        $csv = (string) get_option($option_name);
        if ($csv === '') {
            return '';
        }

        foreach (explode(',', $csv) as $key) {
            $key = trim((string) $key);
            if ($key === '') {
                continue;
            }

            $value = trim((string) get_post_meta($post_id, $key, true));
            if ($value !== '') {
                return $value;
            }
        }

        return '';
    }

    private static function get_finder_source_url(int $post_id): string {
        $webpage_url = trim((string) Fifu_Post_Finder_Read_Service::get_finder_url($post_id));
        if ($webpage_url !== '') {
            return $webpage_url;
        }

        return trim(self::get_first_post_meta_from_option_csv($post_id, 'fifu_finder_custom_field'));
    }

    private static function is_amazon_url(string $url): bool {
        $url = trim($url);
        if ($url === '') {
            return false;
        }

        $host = (string) (wp_parse_url($url, PHP_URL_HOST) ?? '');
        if ($host === '') {
            return (bool) preg_match('/(^|[.])amazon[.]/i', $url) || (bool) preg_match('/amzn[.]to/i', $url);
        }

        return (bool) preg_match('/(^|[.])amazon[.]/i', $host) || (bool) preg_match('/(^|[.])amzn[.]to$/i', $host);
    }

    private static function persist_finder_source_after_success(int $post_id, string $webpage_url): void {
        FIFU_Post_Meta_Updater::instance()->update_or_delete_with_status(
            $post_id,
            'fifu_finder_url',
            $webpage_url
        );
    }

    private static function normalize_worker_url_list($value): array {
        $values = is_array($value) ? $value : explode('|', (string) $value);
        $normalized = array();

        foreach ($values as $item) {
            $item = trim((string) $item);
            if ($item === '') {
                continue;
            }
            $normalized[] = $item;
        }

        return $normalized;
    }

    private static function normalize_asin_media_urls($images): array
    {
        if (!is_array($images)) {
            return array();
        }

        $urls = array();

        foreach ($images as $image) {
            $url = '';

            if (is_string($image)) {
                $url = trim($image);
            } elseif (is_array($image) && isset($image['url']) && is_string($image['url'])) {
                $url = trim($image['url']);
            } elseif (is_object($image) && isset($image->url) && is_string($image->url)) {
                $url = trim($image->url);
            }

            if ($url === '') {
                continue;
            }

            if (!filter_var($url, FILTER_VALIDATE_URL)) {
                continue;
            }

            if (!preg_match('#^https?://#i', $url)) {
                continue;
            }

            $urls[] = $url;
        }

        return array_values(array_unique($urls));
    }

    private static function validate_remote_token(\WP_REST_Request $request): bool {
        $token = (string) $request->get_header('X-FIFU-Authorization');
        if ($token === '') {
            $token = (string) $request->get_header('Authorization');
        }
        return !empty($token) && $token === get_option('fifu_ws_key_ddg');
    }

    private static function finalize_worker_attempt(
        int $entity_id,
        string $meta_key,
        bool $fail,
        string $worker_type,
        bool $is_term = false
    ): \WP_REST_Response {
        if ($is_term) {
            if ($meta_key === 'fifu_uploadterm_sent') {
                $attempts = Fifu_Sent_Bridge::get_term_sent_attempts($entity_id, 'uploadterm');
                $attempts = $attempts ?? 0;
                if ($fail) {
                    Fifu_Sent_Bridge::set_term_sent_attempts($entity_id, 'uploadterm', $attempts + 1);
                }
                if (!$fail || $attempts >= 5) {
                    Fifu_Remote_Worker_Client::delete_registers(array($entity_id), $worker_type);
                    Fifu_Sent_Bridge::delete_term_sent($entity_id, 'uploadterm');
                }
            } else {
                $attempts = get_term_meta($entity_id, $meta_key, true);
                $attempts = is_numeric($attempts) ? (int) $attempts : 0;
                if ($fail) {
                    update_term_meta($entity_id, $meta_key, $attempts + 1);
                }
                if (!$fail || $attempts >= 5) {
                    Fifu_Remote_Worker_Client::delete_registers(array($entity_id), $worker_type);
                    delete_term_meta($entity_id, $meta_key);
                }
            }
        } else {
            if ($meta_key === 'fifu_finder_sent') {
                $attempts = Fifu_Sent_Bridge::get_post_sent_attempts($entity_id, 'finder');
                $attempts = $attempts ?? 0;
                if ($fail) {
                    Fifu_Sent_Bridge::set_post_sent_attempts($entity_id, 'finder', $attempts + 1);
                }
                $terminal_failure = $fail && $attempts >= 5;
                if (!$fail) {
                    Fifu_Remote_Worker_Client::delete_registers(array($entity_id), $worker_type);
                    Fifu_Sent_Bridge::delete_post_sent_status($entity_id, 'finder');
                } elseif ($terminal_failure) {
                    Fifu_Remote_Worker_Client::delete_registers(array($entity_id), $worker_type);
                    Fifu_Sent_Bridge::delete_post_sent($entity_id, 'finder');
                }
            } elseif ($meta_key === 'fifu_asin_sent') {
                $attempts = Fifu_Sent_Bridge::get_post_sent_attempts($entity_id, 'asin');
                $attempts = $attempts ?? 0;
                if ($fail) {
                    Fifu_Sent_Bridge::set_post_sent_attempts($entity_id, 'asin', $attempts + 1);
                }
                $terminal_failure = $fail && $attempts >= 5;
                if (!$fail || $terminal_failure) {
                    Fifu_Remote_Worker_Client::delete_registers(array($entity_id), $worker_type);
                    if ($terminal_failure) {
                        Fifu_Sent_Bridge::delete_post_sent_status($entity_id, 'asin');
                    } else {
                        Fifu_Sent_Bridge::delete_post_sent($entity_id, 'asin');
                    }
                }
            } elseif ($meta_key === 'fifu_uploadpost_sent') {
                $attempts = Fifu_Sent_Bridge::get_post_sent_attempts($entity_id, 'uploadpost');
                $attempts = $attempts ?? 0;
                if ($fail) {
                    Fifu_Sent_Bridge::set_post_sent_attempts($entity_id, 'uploadpost', $attempts + 1);
                }
                if (!$fail || $attempts >= 5) {
                    Fifu_Remote_Worker_Client::delete_registers(array($entity_id), $worker_type);
                    Fifu_Sent_Bridge::delete_post_sent($entity_id, 'uploadpost');
                }
            } elseif ($meta_key === 'fifu_auto_set_sent') {
                $attempts = Fifu_Sent_Bridge::get_post_sent_attempts($entity_id, 'auto_set');
                $attempts = $attempts ?? 0;
                if ($fail) {
                    Fifu_Sent_Bridge::set_post_sent_attempts($entity_id, 'auto_set', $attempts + 1);
                }
                $terminal_failure = $fail && $attempts >= 5;
                if (!$fail) {
                    Fifu_Remote_Worker_Client::delete_registers(array($entity_id), $worker_type);
                    Fifu_Sent_Bridge::delete_post_sent_status($entity_id, 'auto_set');
                } elseif ($terminal_failure) {
                    Fifu_Remote_Worker_Client::delete_registers(array($entity_id), $worker_type);
                    Fifu_Sent_Bridge::delete_post_sent($entity_id, 'auto_set');
                }
            } else {
                $attempts = get_post_meta($entity_id, $meta_key, true);
                $attempts = is_numeric($attempts) ? (int) $attempts : 0;
                if ($fail) {
                    if (!self::is_db2_only_legacy_key($meta_key)) {
                        update_post_meta($entity_id, $meta_key, $attempts + 1);
                    }
                }
                if (!$fail || $attempts >= 5) {
                    Fifu_Remote_Worker_Client::delete_registers(array($entity_id), $worker_type);
                    if (!self::is_db2_only_legacy_key($meta_key)) {
                        delete_post_meta($entity_id, $meta_key);
                    }
                }
            }
        }

        return new \WP_REST_Response('', 200);
    }

    /**
     * @param string $meta_key
     * @return bool
     */
    private static function is_db2_only_legacy_key(string $meta_key): bool {
        $db2_exact = array(
            'fifu_image_url',
            'fifu_image_alt',
            'fifu_video_url',
            'fifu_custom_video_url',
        );

        if (in_array($meta_key, $db2_exact, true)) {
            return true;
        }

        if (preg_match('/^(fifu_image_url|fifu_image_alt|fifu_video_url)_\\d+$/', $meta_key)) {
            return true;
        }

        return false;
    }
}
