<?php

require_once dirname(__DIR__, 3) . '/admin/columns/class-fifu-quick-edit-read-service.php';

class Fifu_Rest_Quick_Edit_Controller {

    private const QUICK_EDIT_DEBUG_MAX_FIELD_CHARS = 2048;

    /**
     * Registers the quick edit REST endpoint that replaces fifu_api_quick_edit_save().
     */
    public static function register_routes(): void {
        register_rest_route('fifu-premium/v2', '/quick_edit_save_api/', array(
            'methods'             => 'POST',
            'callback'            => array(self::class, 'handle_quick_edit_save'),
            'permission_callback' => [Fifu_Rest_Permissions::class, 'private_data'],
        ));
        register_rest_route('fifu-premium/v2', '/quick_edit_debug_data_api/', array(
            'methods'             => 'GET',
            'callback'            => [self::class, 'handle_quick_edit_debug_data'],
            'permission_callback' => [Fifu_Rest_Permissions::class, 'private_data'],
        ));
        register_rest_route('fifu-premium/v2', '/quick_edit_variations_api/', array(
            'methods'             => 'GET',
            'callback'            => [self::class, 'handle_quick_edit_variations'],
            'permission_callback' => [Fifu_Rest_Permissions::class, 'quick_edit_read'],
            'args'                => array(
                'parent_id' => array(
                    'required' => true,
                    'sanitize_callback' => 'absint',
                ),
            ),
        ));
        register_rest_route('fifu-premium/v2', '/quick_edit_item_api/', array(
            'methods'             => 'GET',
            'callback'            => [self::class, 'handle_quick_edit_item'],
            'permission_callback' => [Fifu_Rest_Permissions::class, 'quick_edit_read'],
            'args'                => array(
                'post_id' => array(
                    'required' => true,
                    'sanitize_callback' => 'absint',
                ),
            ),
        ));
    }

    public static function handle_quick_edit_variations(WP_REST_Request $request): WP_REST_Response {
        $parent_id = absint($request->get_param('parent_id'));
        $post = $parent_id > 0 ? get_post($parent_id) : null;
        $product = $parent_id > 0 && function_exists('wc_get_product') ? wc_get_product($parent_id) : null;

        if (!$post || !$product) {
            return new WP_REST_Response([
                'code' => 'fifu_quick_edit_parent_not_found',
                'message' => 'The variable product could not be found.',
            ], 404);
        }

        $is_variable = method_exists($product, 'is_type') && $product->is_type('variable');
        if (!$is_variable && method_exists($product, 'get_type')) {
            $is_variable = $product->get_type() === 'variable';
        }

        if (!$is_variable) {
            return new WP_REST_Response([
                'code' => 'fifu_quick_edit_parent_not_variable',
                'message' => 'The post is not a variable product.',
            ], 400);
        }

        $variation_ids = array_values(array_filter(array_map('intval', (array) $product->get_children())));
        $attribute_map = Fifu_Product_Variation_Attributes_Service::get_pretty_variation_attributes_map($parent_id);
        $variations = [];

        foreach ($variation_ids as $variation_id) {
            $variations[] = [
                'post_id' => $variation_id,
                'attributes' => $attribute_map[$variation_id] ?? [],
                'display' => Fifu_Quick_Edit_Read_Service::get_display($variation_id),
            ];
        }

        return new WP_REST_Response([
            'parent_id' => $parent_id,
            'title' => method_exists($product, 'get_title') ? (string) $product->get_title() : '',
            'variations' => $variations,
        ], 200);
    }

    public static function handle_quick_edit_item(WP_REST_Request $request): WP_REST_Response {
        $post_id = absint($request->get_param('post_id'));
        $post = $post_id > 0 ? get_post($post_id) : null;

        if (!$post) {
            return new WP_REST_Response([
                'code' => 'fifu_quick_edit_item_not_found',
                'message' => 'The Quick Edit item could not be found.',
            ], 404);
        }

        return new WP_REST_Response(Fifu_Quick_Edit_Read_Service::get_item_response($post_id), 200);
    }

    /**
     * Handles the quick edit request body and mirrors the behavior of fifu_api_quick_edit_save().
     */
    public static function handle_quick_edit_save(WP_REST_Request $request): WP_REST_Response {
        $post_id = $request->get_param('post_id');
        $is_ctgr = $request->get_param('is_ctgr');
        $width = $request->get_param('width');
        $height = $request->get_param('height');
        $request_params = $request->get_params();

        $gallery_length = intval($request->get_param('gallery_length') ?? 0);
        $gallery_urls = $request->get_param('gallery_urls');
        $gallery_alts = $request->get_param('gallery_alts');
        $gallery_ifms = $request->get_param('gallery_ifms');
        $has_gallery_payload = array_key_exists('gallery_length', $request_params)
            || array_key_exists('gallery_urls', $request_params)
            || array_key_exists('gallery_alts', $request_params)
            || array_key_exists('gallery_ifms', $request_params);

        $gallery_video_length = intval($request->get_param('gallery_video_length') ?? 0);
        $gallery_video_urls = $request->get_param('gallery_video_urls');
        $has_gallery_video_payload = array_key_exists('gallery_video_length', $request_params)
            || array_key_exists('gallery_video_urls', $request_params);

        $slider_length = intval($request->get_param('slider_length') ?? 0);
        $slider_urls = $request->get_param('slider_urls');
        $slider_alts = $request->get_param('slider_alts');
        $has_slider_payload = array_key_exists('slider_length', $request_params)
            || array_key_exists('slider_urls', $request_params)
            || array_key_exists('slider_alts', $request_params);
        $has_non_empty_slider_payload = $has_slider_payload && self::has_non_empty_url_payload($slider_urls);

        $has_image_url = array_key_exists('image_url', $request_params);
        $image_url_raw = $request->get_param('image_url');
        $image_url = is_string($image_url_raw) ? trim($image_url_raw) : trim((string) $image_url_raw);
        $has_non_empty_image_url = $has_image_url && $image_url !== '';
        $has_video_url = array_key_exists('video_url', $request_params);
        $video_url_raw = $request->get_param('video_url');
        $video_url = is_string($video_url_raw) ? trim($video_url_raw) : trim((string) $video_url_raw);
        $has_non_empty_video_url = $has_video_url && $video_url !== '';
        $has_audio_url = array_key_exists('audio_url', $request_params);
        $audio_url_raw = $request->get_param('audio_url');
        $audio_url = is_string($audio_url_raw) ? trim($audio_url_raw) : trim((string) $audio_url_raw);
        $has_image_alt = array_key_exists('image_alt', $request_params);
        $image_alt_raw = $request->get_param('image_alt');
        $image_alt = trim(wp_strip_all_tags(is_string($image_alt_raw) ? $image_alt_raw : (string) $image_alt_raw));
        $video_thumb_url = $request->get_param('video_thumb_url');
        $clear_all_media = $request->get_param('fifu_quick_edit_clear_all_media');
        $clear_all_media = $clear_all_media === true || $clear_all_media === 1 || $clear_all_media === '1' || $clear_all_media === 'true';
        $has_media_state_payload = $has_image_url || $has_video_url || $has_audio_url || $has_slider_payload;
        $preserve_inactive_media = !$is_ctgr && !$clear_all_media && $has_media_state_payload;
        $is_custom_video_url = $has_non_empty_video_url && Fifu_Video_Helper::is_custom_video($video_url);
        $custom_video_poster_url = is_string($video_thumb_url) && trim($video_thumb_url) !== ''
            ? trim($video_thumb_url)
            : $image_url;
        $should_process_standalone_image = $has_image_url && !$is_custom_video_url;

        if ($should_process_standalone_image) {
            if ($is_ctgr) {
                $term_id = $post_id;
                $image_synced = Fifu_Developer_Media_Service::set_category_image(
                    (int) $term_id,
                    (string) $image_url
                );
                if ($image_synced && $width && $height) {
                    $attachmentId = get_term_meta($term_id, 'thumbnail_id', true);
                    if ($attachmentId) {
                        Fifu_Attachment_Dimensions_Service::update_dimensions(
                            (int) $attachmentId,
                            (int) $width,
                            (int) $height
                        );
                    }
                }
                if ($image_synced) {
                    self::cleanup_legacy_category_image_meta_after_db2_sync(
                        (int) $term_id,
                        self::normalize_pipe_list($image_url !== null ? trim((string) $image_url) : null)
                    );
                }
            } else {
                $image_synced = Fifu_Developer_Media_Service::set_image(
                    (int) $post_id,
                    (string) $image_url,
                    false,
                    $preserve_inactive_media
                );

                if (!$image_synced) {
                    return self::quick_edit_error_response(
                        'fifu_quick_edit_image_save_failed',
                        'FIFU Quick Edit could not save the featured image for this post.',
                        500
                    );
                }

                if ($width && $height) {
                    $attachmentId = get_post_thumbnail_id($post_id);
                    if ($attachmentId) {
                        Fifu_Attachment_Dimensions_Service::update_dimensions(
                            (int) $attachmentId,
                            (int) $width,
                            (int) $height
                        );
                    }
                }
            }

            if (!$is_ctgr && isset($image_synced) && $image_synced) {
                self::cleanup_legacy_main_image_alt_after_db2_sync((int) $post_id);
            }
        }

        if ($has_non_empty_video_url || ($has_video_url && !$is_ctgr)) {
            if (Fifu_Video_Helper::is_custom_video($video_url)) {
                if ($is_ctgr) {
                    $term_id = $post_id;
                    fifu_update_or_delete_ctgr($term_id, 'fifu_image_url', '');
                    fifu_update_or_delete_ctgr($term_id, 'fifu_custom_video_url', $video_url);
                    self::clear_quick_edit_provider_video_meta((int) $term_id, true);
                } else {
                    if ($custom_video_poster_url !== '') {
                        $custom_synced = Fifu_Developer_Media_Service::set_custom_video_with_poster(
                            (int) $post_id,
                            (string) $video_url,
                            (string) $custom_video_poster_url,
                            null,
                            $preserve_inactive_media
                        );

                        if ($custom_synced) {
                            if (class_exists('FIFU_Post_Meta_Updater', false)) {
                                FIFU_Post_Meta_Updater::instance()->update_or_delete($post_id, 'fifu_custom_video_url', $video_url);
                            } else {
                                fifu_update_or_delete($post_id, 'fifu_custom_video_url', $video_url);
                            }
                            self::clear_quick_edit_provider_video_meta((int) $post_id, false);
                        }
                    } else {
                        if (class_exists('FIFU_Post_Meta_Updater', false)) {
                            FIFU_Post_Meta_Updater::instance()->update_or_delete($post_id, 'fifu_custom_video_url', $video_url);
                        } else {
                            fifu_update_or_delete($post_id, 'fifu_custom_video_url', $video_url);
                        }
                        self::clear_quick_edit_provider_video_meta((int) $post_id, false);
                    }
                }
            } else {
                if ($is_ctgr) {
                    $term_id = $post_id;
                    $video_synced = Fifu_Developer_Media_Service::set_category_video(
                        (int) $term_id,
                        (string) $video_url
                    );
                    $att_id = get_term_meta($term_id, 'thumbnail_id', true);
                    if ($video_synced) {
                        self::clear_quick_edit_custom_video_meta((int) $term_id, true);
                        self::cleanup_legacy_category_video_meta_after_db2_sync(
                            (int) $term_id,
                            self::normalize_pipe_list($video_url)
                        );
                    }
                } else {
                    $video_synced = Fifu_Developer_Media_Service::set_video(
                        (int) $post_id,
                        (string) $video_url,
                        false,
                        $preserve_inactive_media
                    );
                    $att_id = get_post_thumbnail_id($post_id);
                    if ($video_synced) {
                        self::clear_quick_edit_custom_video_meta((int) $post_id, false);
                    }
                }
                if (!empty($video_synced) && $att_id && $video_url && $video_thumb_url && $width && $height) {
                    Fifu_Attachment_Dimensions_Service::update_dimensions($att_id, (int) $width, (int) $height);
                    if (Fifu_Video_Helper::is_youtube_video($video_url)) {
                        Fifu_Video_Attachment_Utils::update_youtube_dimensions($att_id, $video_thumb_url);
                    }
                }
            }
        }

        if ($has_audio_url && !$is_ctgr) {
            fifu_update_or_delete(
                (int) $post_id,
                'fifu_audio_url',
                esc_url_raw(rtrim($audio_url))
            );
        }

        if ($has_image_alt) {
            if ($is_ctgr) {
                fifu_update_or_delete_ctgr((int) $post_id, 'fifu_image_alt', $image_alt);
            } else {
                fifu_update_or_delete((int) $post_id, 'fifu_image_alt', $image_alt);
                self::cleanup_legacy_main_image_alt_after_db2_sync((int) $post_id);
            }
        }

        if ($has_non_empty_video_url) {
            if (!$has_non_empty_image_url) {
                $image_url = Fifu_Video_Helper::get_thumbnail_large((string) $video_url);
                if (Fifu_Video_Helper::is_custom_video((string) $video_url)) {
                    if ($is_ctgr) {
                        $term_id = $post_id;
                        $image_url = Fifu_Term_Image_Url_Read_Service::get_image_url((int) $term_id);
                    } else {
                        $image_url = Fifu_Post_Main_Image_Resolver::get_main_image_url($post_id, true);
                    }
                }
            }
        }

        if ($is_custom_video_url && $custom_video_poster_url !== '') {
            $image_url = $custom_video_poster_url;
        }

        if ($has_gallery_payload) {
            if (!$preserve_inactive_media && !$has_slider_payload) {
                self::clear_quick_edit_slider_state((int) $post_id);
            }
            self::clear_quick_edit_image_gallery_state((int) $post_id);

            for ($i = 0; $i < $gallery_length; $i++) {
                fifu_delete_post_meta($post_id, 'fifu_image_url_' . $i);
                fifu_delete_post_meta($post_id, 'fifu_image_alt_' . $i);
                fifu_delete_post_meta($post_id, 'fifu_image_ifm_' . $i);
            }

            $i = 0;
            $expected_image_urls = [];
            $expected_image_alts = [];
            foreach ($gallery_urls ?? [] as $url) {
                $url = esc_url_raw(rtrim($url));
                $alt = wp_strip_all_tags($gallery_alts[$i] ?? '');
                $ifm = trim((string) ($gallery_ifms[$i] ?? ''));
                $ifm = in_array(strtolower($ifm), ['null', 'undefined', 'http://null', 'https://null'], true)
                    ? ''
                    : esc_url_raw($ifm);

                if ($url !== '') {
                    $expected_image_urls[] = $url;
                    $expected_image_alts[] = $alt;

                    if (!self::save_quick_edit_image_gallery_item_to_db2((int) $post_id, $i + 1, $url, $alt)) {
                        return self::quick_edit_error_response(
                            'fifu_quick_edit_gallery_save_failed',
                            'FIFU Quick Edit could not save the product image gallery.',
                            500
                        );
                    }
                }

                fifu_update_or_delete($post_id, 'fifu_image_url_' . $i, $url);
                fifu_update_or_delete_value($post_id, 'fifu_image_alt_' . $i, $alt);
                fifu_update_or_delete_value($post_id, 'fifu_image_ifm_' . $i, $ifm);
                $i++;
            }
            if ($expected_image_urls !== []) {
                foreach (array_values($expected_image_urls) as $galleryIndex => $galleryUrl) {
                    $galleryAlt = $expected_image_alts[$galleryIndex] ?? '';
                    self::save_quick_edit_image_gallery_item_to_db2((int) $post_id, $galleryIndex + 1, $galleryUrl, $galleryAlt);
                }
            }
            Fifu_Post_Attachment_Sync_Service::sync_featured_attachment($post_id);
            Fifu_Post_Attachment_Sync_Service::sync_gallery_attachments($post_id);
            Fifu_Post_Attachment_Sync_Service::sync_theme_property_images($post_id);

            self::cleanup_legacy_image_list_meta_after_db2_sync(
                (int) $post_id,
                $expected_image_urls ? implode('|', $expected_image_urls) : null,
                $expected_image_alts ? implode('|', $expected_image_alts) : null,
                true
            );

            if ($expected_image_urls !== []) {
                foreach (array_values($expected_image_urls) as $galleryIndex => $galleryUrl) {
                    $galleryAlt = $expected_image_alts[$galleryIndex] ?? '';
                    self::save_quick_edit_image_gallery_item_to_db2((int) $post_id, $galleryIndex + 1, $galleryUrl, $galleryAlt);
                }
            }
        }

        if ($has_gallery_video_payload) {
            for ($i = 0; $i < $gallery_video_length; $i++) {
                fifu_delete_post_meta($post_id, 'fifu_video_url_' . $i);
            }

            $i = 0;
            $expected_video_urls = [];
            foreach ($gallery_video_urls ?? [] as $url) {
                $url = esc_url_raw(rtrim($url));
                if ($url !== '') {
                    $expected_video_urls[] = $url;
                }

                fifu_update_or_delete($post_id, 'fifu_video_url_' . $i, $url);
                $i++;
            }
            Fifu_Post_Attachment_Sync_Service::sync_featured_attachment($post_id);
            Fifu_Post_Attachment_Sync_Service::sync_gallery_attachments($post_id);
            Fifu_Post_Attachment_Sync_Service::sync_theme_property_images($post_id);

            self::cleanup_legacy_video_list_meta_after_db2_sync(
                (int) $post_id,
                $expected_video_urls ? implode('|', $expected_video_urls) : null,
                true
            );
        }

        if ($has_slider_payload) {
            if ($has_non_empty_slider_payload) {
                self::clear_quick_edit_image_gallery_state((int) $post_id);
            }
            $sliderServiceRequest = $request_params;
            $sliderServiceRequest['inputHiddenSliderLength'] = $slider_length;
            $sliderServiceRequest['inputHiddenSliderListIds'] = '';
            $sliderServiceRequest['fifu_slider_input_ratio'] = $request->get_param('fifu_slider_input_ratio') ?? '';
            $sliderServiceRequest['fifu_quick_edit_preserve_inactive_media'] = $preserve_inactive_media;

            $sliderServiceIds = [];
            $sliderServiceIndex = 0;
            foreach ((array) $slider_urls as $sourceIndex => $url) {
                if (trim((string) $url) === '') {
                    continue;
                }

                $sliderServiceIds[] = (string) $sliderServiceIndex;
                $sliderServiceRequest['fifu_slider_input_url_' . $sliderServiceIndex] = $url;
                $sliderServiceRequest['fifu_slider_input_alt_' . $sliderServiceIndex] = is_array($slider_alts)
                    ? ($slider_alts[$sourceIndex] ?? '')
                    : '';
                $sliderServiceIndex++;
            }
            $sliderServiceRequest['inputHiddenSliderListIds'] = implode('|', $sliderServiceIds);

            Fifu_Slider_Meta_Service::save_slider_properties(
                (int) $post_id,
                $sliderServiceRequest
            );
            Fifu_Post_Attachment_Sync_Service::sync_featured_attachment($post_id);
            Fifu_Post_Attachment_Sync_Service::sync_gallery_attachments($post_id);
            Fifu_Post_Attachment_Sync_Service::sync_theme_property_images($post_id);

            if (!$image_url) {
                $first_slider_url = $sliderServiceIndex > 0
                    ? (string) ($sliderServiceRequest['fifu_slider_input_url_0'] ?? '')
                    : '';
                return self::quick_edit_success_response($first_slider_url, (int) $post_id, $is_ctgr);
            }
        }

        if (class_exists('\Distributor\Connections')) {
            wp_update_post(array('ID' => $post_id));
        }

        return self::quick_edit_success_response($image_url, (int) $post_id, $is_ctgr);
    }

    public static function handle_quick_edit_debug_data(WP_REST_Request $request) {
        if (!Fifu_Options_Utils::is_on('fifu_debug')) {
            return new WP_Error('fifu_debug_disabled', 'FIFU Debug is disabled.', ['status' => 403]);
        }

        $is_ctgr = self::normalize_quick_edit_debug_is_category($request->get_param('is_ctgr'));
        if ($is_ctgr) {
            $term_id = (int) $request->get_param('post_id');
            if ($term_id <= 0) {
                return new WP_Error('fifu_invalid_term_id', 'Invalid term_id.', ['status' => 400]);
            }

            $taxonomy = trim((string) $request->get_param('taxonomy'));
            $term = $taxonomy !== '' ? get_term($term_id, $taxonomy) : get_term($term_id);
            if (!$term || is_wp_error($term)) {
                return new WP_Error('fifu_invalid_term_id', 'Invalid term_id.', ['status' => 400]);
            }

            return new WP_REST_Response(self::build_quick_edit_debug_term_response($term_id, (string) $term->taxonomy), 200);
        }

        $post_id = (int) $request->get_param('post_id');
        if ($post_id <= 0 || !get_post($post_id)) {
            return new WP_Error('fifu_invalid_post_id', 'Invalid post_id.', ['status' => 400]);
        }

        $children = get_posts([
            'post_type' => 'product_variation',
            'post_parent' => $post_id,
            'post_status' => 'any',
            'numberposts' => -1,
            'fields' => 'ids',
        ]);

        $root_post = get_post($post_id);
        $post_type = $root_post ? (string) $root_post->post_type : '';

        if ($children) {
            $scope = 'product_context';
        } elseif ($post_type === 'product') {
            $scope = 'product';
        } else {
            $scope = 'post';
        }
        $variations = [];
        foreach ($children as $child_id) {
            $variations[] = self::build_quick_edit_debug_item((int) $child_id);
        }

        return new WP_REST_Response([
            'type' => 'quick_edit_debug_data',
            'scope' => $scope,
            'root_post_id' => $post_id,
            'root_item' => self::build_quick_edit_debug_item($post_id),
            'product_variations' => $variations,
        ], 200);
    }

    private static function quick_edit_error_response(string $code, string $message, int $status): WP_REST_Response {
        return new WP_REST_Response(
            array(
                'code' => $code,
                'message' => $message,
            ),
            $status
        );
    }

    private static function quick_edit_success_response(?string $thumbUrl, int $postId, $isCategory): WP_REST_Response {
        $data = ['thumb_url' => $thumbUrl];

        $canResolveFeaturedMediaType = !$isCategory
            && class_exists('Fifu_Post_Featured_Media_State_Resolver', false)
            && class_exists('Fifu_Post_Image_Url_Read_Service', false)
            && class_exists('Fifu_Post_Video_Read_Service', false)
            && class_exists('Fifu_Post_Custom_Video_Read_Service', false)
            && class_exists('Fifu_Post_Slider_Image_Url_Read_Service', false)
            && class_exists('Fifu_Post_Audio_Read_Service', false);

        if ($canResolveFeaturedMediaType) {
            $data['fifu_featured_media_type'] = Fifu_Post_Featured_Media_State_Resolver::resolve_editor_type($postId);
        }

        return new WP_REST_Response($data, 200);
    }

    private static function build_quick_edit_debug_item(int $post_id): array {
        $post = get_post($post_id);
        $postmeta = self::sanitize_quick_edit_debug_meta_array(get_post_meta($post_id));
        $legacy_postmeta = array_filter($postmeta, static function ($key) {
            return strpos((string) $key, 'fifu_') === 0;
        }, ARRAY_FILTER_USE_KEY);

        $raw_thumbnail_id_values = array_map('strval', (array) get_post_meta($post_id, '_thumbnail_id', false));
        $thumbnail_id = self::select_first_valid_attachment_id($raw_thumbnail_id_values);
        $thumbnail_post = $thumbnail_id > 0 ? get_post($thumbnail_id) : null;
        $manager = function_exists('fifu_db2_manager') ? fifu_db2_manager() : null;

        $fifu_db2_storage = [
            'image' => (is_object($manager) && method_exists($manager, 'getPostMappings')) ? (array) $manager->getPostMappings($post_id, 'image') : [],
            'slider' => (is_object($manager) && method_exists($manager, 'getPostMappings')) ? (array) $manager->getPostMappings($post_id, 'slider') : [],
            'video' => (is_object($manager) && method_exists($manager, 'getPostMappings')) ? (array) $manager->getPostMappings($post_id, 'video') : [],
            'custom_video' => (is_object($manager) && method_exists($manager, 'getPostMappings')) ? (array) $manager->getPostMappings($post_id, 'custom_video') : [],
            'audio' => (is_object($manager) && method_exists($manager, 'getPostMappings')) ? (array) $manager->getPostMappings($post_id, 'audio') : [],
        ];

        $resolved_image_url = Fifu_Post_Image_Url_Read_Service::get_image_url($post_id);
        $resolved_image_source = self::resolve_quick_edit_debug_image_source(
            $resolved_image_url,
            $fifu_db2_storage['image'],
            $legacy_postmeta,
            'fifu_legacy_postmeta'
        );

        return [
            'post' => self::sanitize_quick_edit_debug_post($post),
            'wordpress_postmeta' => $postmeta,
            'fifu_legacy_postmeta' => $legacy_postmeta,
            'wordpress_thumbnail_reference' => [
                'thumbnail_id_meta_values' => array_values($raw_thumbnail_id_values),
                'wordpress_thumbnail_id' => (int) get_post_thumbnail_id($post_id),
                'inspected_attachment_id' => $thumbnail_id,
            ],
            'wordpress_thumbnail_attachment' => [
                'post' => self::sanitize_quick_edit_debug_post($thumbnail_post),
                'postmeta' => $thumbnail_id > 0 ? self::sanitize_quick_edit_debug_meta_array(get_post_meta($thumbnail_id)) : [],
            ],
            'fifu_db2_storage' => $fifu_db2_storage,
            'fifu_video_oembed_storage' => self::get_quick_edit_debug_video_oembed_rows($postmeta, $fifu_db2_storage),
            'resolved_media' => [
                'featured_image' => [
                    'url' => $resolved_image_url,
                    'source' => $resolved_image_source,
                ],
            ],
        ];
    }

    private static function build_quick_edit_debug_term_response(int $term_id, string $taxonomy): array {
        $term = get_term($term_id, $taxonomy);
        if (!$term || is_wp_error($term)) {
            return [
                'type' => 'quick_edit_debug_data',
                'scope' => 'term',
                'root_term_id' => $term_id,
                'taxonomy' => $taxonomy,
                'term' => null,
                'wordpress_termmeta' => [],
                'fifu_legacy_termmeta' => [],
                'wordpress_thumbnail_reference' => [
                    'thumbnail_id_meta_values' => [],
                    'inspected_attachment_id' => 0,
                ],
                'wordpress_thumbnail_attachment' => [
                    'post' => null,
                    'postmeta' => [],
                ],
                'fifu_db2_storage' => [
                    'image' => [],
                    'video' => [],
                    'custom_video' => [],
                ],
                'fifu_video_oembed_storage' => [],
                'resolved_media' => [
                    'featured_image' => [
                        'url' => null,
                        'source' => null,
                    ],
                ],
            ];
        }

        $termmeta = self::sanitize_quick_edit_debug_meta_array(get_term_meta($term_id));
        $legacy_termmeta = array_filter($termmeta, static function ($key) {
            return strpos((string) $key, 'fifu_') === 0;
        }, ARRAY_FILTER_USE_KEY);

        $raw_thumbnail_id_values = array_map('strval', (array) get_term_meta($term_id, 'thumbnail_id', false));
        $selected_thumbnail_id = self::select_first_valid_attachment_id($raw_thumbnail_id_values);
        $thumbnail_post = $selected_thumbnail_id > 0 ? get_post($selected_thumbnail_id) : null;
        $manager = function_exists('fifu_db2_manager') ? fifu_db2_manager() : null;

        $fifu_db2_storage = [
            'image' => self::wrap_quick_edit_debug_term_mapping(is_object($manager) && method_exists($manager, 'getTermMapping') ? $manager->getTermMapping($term_id, 'image') : null),
            'video' => self::wrap_quick_edit_debug_term_mapping(is_object($manager) && method_exists($manager, 'getTermMapping') ? $manager->getTermMapping($term_id, 'video') : null),
            'custom_video' => self::wrap_quick_edit_debug_term_mapping(is_object($manager) && method_exists($manager, 'getTermMapping') ? $manager->getTermMapping($term_id, 'custom_video') : null),
        ];

        $resolved_image_url = Fifu_Term_Image_Url_Read_Service::get_image_url($term_id);
        $resolved_image_source = self::resolve_quick_edit_debug_image_source(
            $resolved_image_url,
            $fifu_db2_storage['image'],
            $legacy_termmeta,
            'fifu_legacy_termmeta'
        );

        return [
            'type' => 'quick_edit_debug_data',
            'scope' => 'term',
            'root_term_id' => $term_id,
            'taxonomy' => $term->taxonomy,
            'term' => (array) $term,
            'wordpress_termmeta' => $termmeta,
            'fifu_legacy_termmeta' => $legacy_termmeta,
            'wordpress_thumbnail_reference' => [
                'thumbnail_id_meta_values' => array_values($raw_thumbnail_id_values),
                'inspected_attachment_id' => $selected_thumbnail_id,
            ],
            'wordpress_thumbnail_attachment' => [
                'post' => self::sanitize_quick_edit_debug_post($thumbnail_post),
                'postmeta' => $selected_thumbnail_id > 0 ? self::sanitize_quick_edit_debug_meta_array(get_post_meta($selected_thumbnail_id)) : [],
            ],
            'fifu_db2_storage' => $fifu_db2_storage,
            'fifu_video_oembed_storage' => self::get_quick_edit_debug_video_oembed_rows($termmeta, $fifu_db2_storage),
            'resolved_media' => [
                'featured_image' => [
                    'url' => $resolved_image_url,
                    'source' => $resolved_image_source,
                ],
            ],
        ];
    }

    private static function sanitize_quick_edit_debug_meta_array(array $meta): array
    {
        $allow_list = [
            '_thumbnail_id',
            'thumbnail_id',
            '_product_image_gallery',
            '_wc_additional_variation_images',
            '_wp_attached_file',
            '_wp_attachment_metadata',
            '_wp_attachment_image_alt',
            'fifu_image_url',
            'fifu_image_alt',
            'fifu_image_url_0',
            'fifu_list_url',
        ];

        $redact_patterns = [
            'key',
            'secret',
            'token',
            'password',
            'license',
            'consumer_secret',
            'access_token',
        ];

        foreach ($meta as $key => &$values) {
            $key_string = (string) $key;

            if (!in_array($key_string, $allow_list, true)) {
                $keyLower = strtolower($key_string);
                $shouldRedact = false;

                foreach ($redact_patterns as $pattern) {
                    if (strpos($keyLower, $pattern) !== false) {
                        $shouldRedact = true;
                        break;
                    }
                }

                if ($shouldRedact) {
                    $values = array_fill(0, is_array($values) ? count($values) : 1, '[redacted]');
                }
            }

            if (!self::should_preserve_long_quick_edit_debug_field($key_string)) {
                $values = self::crop_quick_edit_debug_value($values);
            }
        }
        unset($values);

        return $meta;
    }

    private static function sanitize_quick_edit_debug_post($post): ?array
    {
        if (!$post) {
            return null;
        }

        $post_data = (array) $post;
        unset($post_data['post_password']);

        return $post_data;
    }

    private static function resolve_quick_edit_debug_image_source(
        ?string $resolved_url,
        array $db2_image_mappings,
        array $legacy_meta,
        string $legacy_source
    ): ?string {
        $resolved_url = $resolved_url !== null ? trim($resolved_url) : '';

        if ($resolved_url === '') {
            return null;
        }

        foreach ($db2_image_mappings as $mapping) {
            if (!is_array($mapping)) {
                continue;
            }

            $key_index = array_key_exists('key_index', $mapping) ? (int) $mapping['key_index'] : 0;
            if ($key_index !== 0) {
                continue;
            }

            $db2_url = trim((string) ($mapping['url'] ?? ''));
            if ($db2_url !== '' && $db2_url === $resolved_url) {
                return 'fifu_db2';
            }
        }

        foreach ((array) ($legacy_meta['fifu_image_url'] ?? []) as $legacy_url) {
            if (trim((string) $legacy_url) === $resolved_url) {
                return $legacy_source;
            }
        }

        return 'unknown';
    }

    private static function should_preserve_long_quick_edit_debug_field(string $key): bool
    {
        return strpos($key, 'fifu') === 0 || strpos($key, '_') === 0;
    }

    /**
     * @param mixed $value
     * @return mixed
     */
    private static function crop_quick_edit_debug_value($value)
    {
        if (is_array($value)) {
            foreach ($value as $index => $item) {
                $value[$index] = self::crop_quick_edit_debug_value($item);
            }

            return $value;
        }

        if (!is_string($value)) {
            return $value;
        }

        $length = function_exists('mb_strlen')
            ? mb_strlen($value, 'UTF-8')
            : strlen($value);

        if ($length <= self::QUICK_EDIT_DEBUG_MAX_FIELD_CHARS) {
            return $value;
        }

        $cropped = function_exists('mb_substr')
            ? mb_substr($value, 0, self::QUICK_EDIT_DEBUG_MAX_FIELD_CHARS, 'UTF-8')
            : substr($value, 0, self::QUICK_EDIT_DEBUG_MAX_FIELD_CHARS);

        return $cropped . '...[cropped from ' . $length . ' chars]';
    }

    private static function get_quick_edit_debug_video_oembed_rows(array $meta, array $fifu_db2_storage): array
    {
        $video_urls = self::collect_quick_edit_debug_video_urls($meta, $fifu_db2_storage);

        if ($video_urls === []) {
            return [];
        }

        global $wpdb;

        $table = $wpdb->prefix . 'fifu_video_oembed';
        $placeholders = implode(', ', array_fill(0, count($video_urls), '%s'));
        $query = "SELECT id, video_url, image_url, embed_url
              FROM {$table}
              WHERE video_url IN ({$placeholders})
              ORDER BY id ASC";

        $prepared = call_user_func_array([$wpdb, 'prepare'], array_merge([$query], $video_urls));
        $rows = $wpdb->get_results($prepared, ARRAY_A);

        if (!is_array($rows)) {
            return [];
        }

        return array_map(
            static function (array $row): array {
                return [
                    'id' => (int) ($row['id'] ?? 0),
                    'video_url' => (string) ($row['video_url'] ?? ''),
                    'image_url' => (string) ($row['image_url'] ?? ''),
                    'embed_url' => (string) ($row['embed_url'] ?? ''),
                ];
            },
            $rows
        );
    }

    private static function collect_quick_edit_debug_video_urls(array $meta, array $fifu_db2_storage): array
    {
        $urls = [];

        foreach ($meta as $key => $values) {
            $key_string = (string) $key;

            if (
                $key_string !== 'fifu_video_url'
                && $key_string !== 'fifu_custom_video_url'
                && $key_string !== 'fifu_list_video_url'
                && preg_match('/^fifu_video_url_\d+$/', $key_string) !== 1
            ) {
                continue;
            }

            foreach ((array) $values as $value) {
                foreach (self::split_quick_edit_debug_video_url_value($value) as $url) {
                    $urls[] = $url;
                }
            }
        }

        foreach (['video', 'custom_video'] as $key_type) {
            foreach ((array) ($fifu_db2_storage[$key_type] ?? []) as $mapping) {
                if (!is_array($mapping)) {
                    continue;
                }

                $url = trim((string) ($mapping['url'] ?? ''));
                if ($url !== '') {
                    $urls[] = $url;
                }
            }
        }

        $urls = array_values(array_unique(array_filter(
            array_map(
                static fn($url): string => trim((string) $url),
                $urls
            ),
            static fn(string $url): bool => $url !== ''
        )));

        return $urls;
    }

    /**
     * @param mixed $value
     * @return array<int,string>
     */
    private static function split_quick_edit_debug_video_url_value($value): array
    {
        if (!is_string($value)) {
            return [];
        }

        $value = trim($value);
        if ($value === '') {
            return [];
        }

        if (strpos($value, '|') === false) {
            return [$value];
        }

        return array_values(array_filter(
            array_map(
                static fn($item): string => trim((string) $item),
                explode('|', $value)
            ),
            static fn(string $item): bool => $item !== ''
        ));
    }

    private static function select_first_valid_attachment_id(array $values): int
    {
        foreach ($values as $value) {
            $attachment_id = (int) $value;
            if ($attachment_id <= 0) {
                continue;
            }

            $post = get_post($attachment_id);
            if ($post && ($post->post_type ?? '') === 'attachment') {
                return $attachment_id;
            }
        }

        return 0;
    }

    private static function wrap_quick_edit_debug_term_mapping($mapping): array
    {
        return is_array($mapping) ? [$mapping] : [];
    }

    private static function normalize_quick_edit_debug_is_category($value): bool
    {
        return $value === true || $value === '1' || $value === 'true' || $value === 1;
    }

    private static function has_non_empty_url_payload($urls): bool
    {
        if (!is_array($urls)) {
            return trim((string) $urls) !== '';
        }

        foreach ($urls as $url) {
            if (trim((string) $url) !== '') {
                return true;
            }
        }

        return false;
    }

    private static function save_quick_edit_image_gallery_item_to_db2(int $postId, int $db2Index, string $url, string $alt): bool
    {
        if (!function_exists('fifu_db2_write_service')) {
            return true;
        }

        $writeService = fifu_db2_write_service();
        if (!is_object($writeService) || !method_exists($writeService, 'save_post_image_at_index')) {
            return true;
        }

        if (!$writeService->save_post_image_at_index($postId, $db2Index, $url)) {
            return false;
        }

        if ($alt !== '' && method_exists($writeService, 'save_post_image_alt_at_index')) {
            return (bool) $writeService->save_post_image_alt_at_index($postId, $db2Index, $alt);
        }

        return true;
    }

    private static function cleanup_legacy_video_list_meta_after_db2_sync(
        int $postId,
        ?string $expectedVideos,
        bool $hasVideoGalleryPayload
    ): void {
        if (!$hasVideoGalleryPayload) {
            return;
        }

        $normalizedExpectedVideos = self::normalize_pipe_list($expectedVideos);
        $db2GalleryVideos = self::normalize_pipe_list(self::get_db2_video_gallery_list_url($postId));
        $db2Videos = self::normalize_pipe_list(
            class_exists('Fifu_Post_Video_List_Url_Read_Service', false)
                ? Fifu_Post_Video_List_Url_Read_Service::get_video_list_url($postId)
                : null
        );
        $matchesExpectedGallery = $db2GalleryVideos === $normalizedExpectedVideos;

        if ($matchesExpectedGallery) {
            delete_post_meta($postId, 'fifu_list_video_url');
        }
    }

    private static function clear_quick_edit_provider_video_meta(int $objectId, bool $isCategory): void
    {
        if ($isCategory) {
            fifu_update_or_delete_ctgr($objectId, 'fifu_video_url', '');
            return;
        }

        if (class_exists('FIFU_Post_Meta_Updater', false)) {
            FIFU_Post_Meta_Updater::instance()->update_or_delete($objectId, 'fifu_video_url', null);
            return;
        }

        fifu_update_or_delete($objectId, 'fifu_video_url', '');
    }

    private static function clear_quick_edit_custom_video_meta(int $objectId, bool $isCategory): void
    {
        if ($isCategory) {
            fifu_update_or_delete_ctgr($objectId, 'fifu_custom_video_url', '');
            return;
        }

        fifu_update_or_delete($objectId, 'fifu_custom_video_url', '');
    }

    private static function clear_quick_edit_slider_state(int $postId): void
    {
        $legacyIndexes = [];
        self::collect_indexed_meta_keys_from_post_meta($postId, [
            '/^fifu_slider_image_url_(\d+)$/',
            '/^fifu_slider_image_alt_(\d+)$/',
        ], $legacyIndexes);

        $legacyIndexes = array_merge($legacyIndexes, self::collect_legacy_indexes_from_pipe_list(
            get_post_meta($postId, 'fifu_slider_list_url', true),
            0
        ));

        if (function_exists('fifu_db2_manager') && class_exists('Fifu_Db2_Manager', false)) {
            $manager = fifu_db2_manager();
            if ($manager instanceof Fifu_Db2_Manager) {
                $legacyIndexes = array_merge(
                    $legacyIndexes,
                    self::collect_slider_legacy_indexes_from_db2($postId, $manager)
                );

                if (method_exists($manager, 'deletePostMappings')) {
                    $manager->deletePostMappings($postId, 'slider');
                }
                if (method_exists($manager, 'deletePostAltMappings')) {
                    $manager->deletePostAltMappings($postId, 'slider');
                }
            }
        }

        self::delete_legacy_post_meta_without_db2_sync($postId, 'fifu_slider_list_url');
        self::delete_legacy_post_meta_without_db2_sync($postId, 'fifu_slider_list_alt');

        $legacyIndexes = array_values(array_unique(array_map('intval', $legacyIndexes)));
        sort($legacyIndexes, SORT_NUMERIC);
        foreach ($legacyIndexes as $index) {
            fifu_delete_post_meta($postId, 'fifu_slider_image_url_' . $index);
            fifu_delete_post_meta($postId, 'fifu_slider_image_alt_' . $index);
        }
    }

    private static function clear_quick_edit_image_gallery_state(int $postId): void
    {
        $legacyIndexes = [];
        self::collect_indexed_meta_keys_from_post_meta($postId, [
            '/^fifu_image_url_(\d+)$/',
            '/^fifu_image_alt_(\d+)$/',
            '/^fifu_image_ifm_(\d+)$/',
        ], $legacyIndexes);

        $legacyIndexes = array_merge($legacyIndexes, self::collect_legacy_indexes_from_pipe_list(
            get_post_meta($postId, 'fifu_list_url', true),
            0
        ));

        if (function_exists('fifu_db2_manager') && class_exists('Fifu_Db2_Manager', false)) {
            $manager = fifu_db2_manager();
            if ($manager instanceof Fifu_Db2_Manager) {
                $legacyIndexes = array_merge(
                    $legacyIndexes,
                    self::collect_gallery_legacy_indexes_from_db2($postId, $manager)
                );

                $legacyGalleryIndexes = array_values(array_unique(array_filter(
                    array_map('intval', $legacyIndexes),
                    static fn(int $index): bool => $index >= 0
                )));
                sort($legacyGalleryIndexes, SORT_NUMERIC);
                foreach ($legacyGalleryIndexes as $index) {
                    $db2Index = $index + 1;
                    if (method_exists($manager, 'deletePostMappings')) {
                        $manager->deletePostMappings($postId, 'image', $db2Index);
                    }
                    if (method_exists($manager, 'deletePostAltMappings')) {
                        $manager->deletePostAltMappings($postId, 'image', $db2Index);
                    }
                }
            }
        }

        self::delete_legacy_post_meta_without_db2_sync($postId, 'fifu_list_url');
        self::delete_legacy_post_meta_without_db2_sync($postId, 'fifu_list_alt');

        $legacyIndexes = array_values(array_unique(array_map('intval', $legacyIndexes)));
        sort($legacyIndexes, SORT_NUMERIC);
        foreach ($legacyIndexes as $index) {
            fifu_delete_post_meta($postId, 'fifu_image_url_' . $index);
            fifu_delete_post_meta($postId, 'fifu_image_alt_' . $index);
            fifu_delete_post_meta($postId, 'fifu_image_ifm_' . $index);
        }

        delete_post_meta($postId, '_product_image_gallery');
    }

    /**
     * @param array<int, string> $patterns
     * @param array<int, int> $legacyIndexes
     */
    private static function collect_indexed_meta_keys_from_post_meta(int $postId, array $patterns, array &$legacyIndexes): void
    {
        foreach (array_keys(get_post_meta($postId)) as $metaKey) {
            $metaKey = (string) $metaKey;
            foreach ($patterns as $pattern) {
                if (preg_match($pattern, $metaKey, $matches)) {
                    $legacyIndexes[] = (int) $matches[1];
                    break;
                }
            }
        }
    }

    private static function delete_legacy_post_meta_without_db2_sync(int $postId, string $metaKey): void
    {
        delete_post_meta($postId, $metaKey);
        clean_post_cache($postId);
        wp_cache_delete($postId, 'post_meta');
    }

    /**
     * @param mixed $value
     * @return int[]
     */
    private static function collect_legacy_indexes_from_pipe_list($value, int $baseIndex): array
    {
        if (!is_string($value) || trim($value) === '') {
            return [];
        }

        $items = array_values(array_filter(array_map('trim', explode('|', $value)), static fn(string $item): bool => $item !== ''));
        $indexes = [];
        foreach ($items as $offset => $item) {
            $indexes[] = $baseIndex + $offset;
        }

        return $indexes;
    }

    /**
     * @return int[]
     */
    private static function collect_gallery_legacy_indexes_from_db2(int $postId, Fifu_Db2_Manager $manager): array
    {
        $indexes = [];
        if (method_exists($manager, 'getPostMappings')) {
            $mappings = $manager->getPostMappings($postId, 'image');
            if (is_array($mappings)) {
                foreach ($mappings as $mapping) {
                    $index = isset($mapping['key_index']) ? (int) $mapping['key_index'] : null;
                    if ($index !== null && $index > 0) {
                        $indexes[] = $index - 1;
                    }
                }
            }
        }

        if (method_exists($manager, 'getPostAltMappings')) {
            $altMappings = $manager->getPostAltMappings($postId, 'image');
            if (is_array($altMappings)) {
                foreach ($altMappings as $mapping) {
                    $index = isset($mapping['key_index']) ? (int) $mapping['key_index'] : null;
                    if ($index !== null && $index > 0) {
                        $indexes[] = $index - 1;
                    }
                }
            }
        }

        return $indexes;
    }

    /**
     * @return int[]
     */
    private static function collect_slider_legacy_indexes_from_db2(int $postId, Fifu_Db2_Manager $manager): array
    {
        $indexes = [];
        if (method_exists($manager, 'getPostMappings')) {
            $mappings = $manager->getPostMappings($postId, 'slider');
            if (is_array($mappings)) {
                foreach ($mappings as $mapping) {
                    $index = isset($mapping['key_index']) ? (int) $mapping['key_index'] : null;
                    if ($index !== null) {
                        $indexes[] = $index;
                    }
                }
            }
        }

        if (method_exists($manager, 'getPostAltMappings')) {
            $altMappings = $manager->getPostAltMappings($postId, 'slider');
            if (is_array($altMappings)) {
                foreach ($altMappings as $mapping) {
                    $index = isset($mapping['key_index']) ? (int) $mapping['key_index'] : null;
                    if ($index !== null) {
                        $indexes[] = $index;
                    }
                }
            }
        }

        return $indexes;
    }

    private static function cleanup_legacy_image_list_meta_after_db2_sync(
        int $postId,
        ?string $expectedUrls,
        ?string $expectedAlts,
        bool $hasGalleryPayload
    ): void {
        if (!$hasGalleryPayload) {
            return;
        }

        $normalizedExpectedUrls = self::normalize_pipe_list($expectedUrls);
        $db2GalleryUrls = self::normalize_pipe_list(self::get_db2_image_gallery_list_url($postId));
        if ($db2GalleryUrls !== $normalizedExpectedUrls) {
            return;
        }

        delete_post_meta($postId, 'fifu_list_url');

        $normalizedExpectedAlts = self::normalize_pipe_list($expectedAlts);
        $db2GalleryAlts = self::normalize_pipe_list(self::get_db2_image_gallery_alt_list($postId));
        if ($db2GalleryAlts === $normalizedExpectedAlts) {
            delete_post_meta($postId, 'fifu_list_alt');
        }

        $legacyMainAlt = trim((string) get_post_meta($postId, 'fifu_image_alt', true));
        if ($legacyMainAlt === '') {
            return;
        }

        $db2MainAlt = self::get_db2_main_image_alt($postId);
        if ($db2MainAlt !== null && trim($db2MainAlt) === $legacyMainAlt) {
            delete_post_meta($postId, 'fifu_image_alt');
        }
    }

    private static function cleanup_legacy_main_image_alt_after_db2_sync(int $postId): void
    {
        $legacyMainAlt = trim((string) get_post_meta($postId, 'fifu_image_alt', true));
        if ($legacyMainAlt === '') {
            return;
        }

        $db2MainAlt = self::get_db2_main_image_alt($postId);
        if ($db2MainAlt === null && self::save_legacy_main_image_alt_to_db2($postId, $legacyMainAlt)) {
            $db2MainAlt = self::get_db2_main_image_alt($postId);
        }
        if ($db2MainAlt !== null && trim($db2MainAlt) === $legacyMainAlt) {
            delete_post_meta($postId, 'fifu_image_alt');
        }
    }

    private static function save_legacy_main_image_alt_to_db2(int $postId, string $legacyMainAlt): bool
    {
        if (
            $legacyMainAlt === ''
            || !function_exists('fifu_db2_manager')
            || !class_exists('Fifu_Db2_Manager', false)
        ) {
            return false;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'savePostAlt')) {
            return false;
        }

        $saved = (bool) $manager->savePostAlt($postId, 'image', 0, $legacyMainAlt);
        return $saved;
    }

    private static function cleanup_legacy_category_image_meta_after_db2_sync(int $termId, ?string $expectedImageUrl): void
    {
        $db2ImageUrl = self::normalize_pipe_list(self::get_db2_term_image_url($termId));
        if ($db2ImageUrl === $expectedImageUrl) {
            delete_term_meta($termId, 'fifu_image_url');
        }

        $legacyImageAlt = trim((string) get_term_meta($termId, 'fifu_image_alt', true));
        if ($legacyImageAlt === '') {
            return;
        }

        $db2ImageAlt = self::get_db2_term_image_alt($termId);
        if ($db2ImageAlt === null && self::save_legacy_term_image_alt_to_db2($termId, $legacyImageAlt)) {
            $db2ImageAlt = self::get_db2_term_image_alt($termId);
        }

        if ($db2ImageAlt !== null && trim($db2ImageAlt) === $legacyImageAlt) {
            delete_term_meta($termId, 'fifu_image_alt');
        }
    }

    private static function cleanup_legacy_category_video_meta_after_db2_sync(int $termId, ?string $expectedVideoUrl): void
    {
        $db2VideoUrl = self::normalize_pipe_list(self::get_db2_term_video_url($termId));
        if ($db2VideoUrl === $expectedVideoUrl) {
            delete_term_meta($termId, 'fifu_video_url');
        }
    }

    private static function save_legacy_term_image_alt_to_db2(int $termId, string $legacyImageAlt): bool
    {
        if (
            $legacyImageAlt === ''
            || !function_exists('fifu_db2_manager')
            || !class_exists('Fifu_Db2_Manager', false)
        ) {
            return false;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'saveTermAlt')) {
            return false;
        }

        return (bool) $manager->saveTermAlt($termId, 'image', $legacyImageAlt);
    }

    private static function get_db2_video_gallery_list_url(int $postId): ?string {
        if (!class_exists('Fifu_Post_Video_Gallery_Read_Service', false)) {
            return null;
        }

        $items = [];
        for ($index = 0; ; $index++) {
            $url = Fifu_Post_Video_Gallery_Read_Service::get_video_url($postId, $index);
            if ($url === null || trim((string) $url) === '') {
                break;
            }

            $items[] = trim((string) $url);
        }

        if (!$items) {
            return null;
        }

        return implode('|', $items);
    }

    private static function get_db2_image_gallery_list_url(int $postId): ?string {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return null;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getPostMappings')) {
            return null;
        }

        $mappings = $manager->getPostMappings($postId, 'image');
        if (!is_array($mappings) || !$mappings) {
            return null;
        }

        usort(
            $mappings,
            static fn(array $a, array $b): int => ($a['key_index'] ?? 0) <=> ($b['key_index'] ?? 0)
        );

        $items = [];
        foreach ($mappings as $mapping) {
            $index = (int) ($mapping['key_index'] ?? 0);
            if ($index <= 0) {
                continue;
            }

            $url = trim((string) ($mapping['url'] ?? ''));
            if ($url === '') {
                continue;
            }

            $items[] = $url;
        }

        if (!$items) {
            return null;
        }

        return implode('|', $items);
    }

    private static function get_db2_image_gallery_alt_list(int $postId): ?string {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return null;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getPostAltMappings')) {
            return null;
        }

        $mappings = $manager->getPostAltMappings($postId, 'image');
        if (!is_array($mappings) || !$mappings) {
            return null;
        }

        usort(
            $mappings,
            static fn(array $a, array $b): int => ($a['key_index'] ?? 0) <=> ($b['key_index'] ?? 0)
        );

        $items = [];
        foreach ($mappings as $mapping) {
            $index = (int) ($mapping['key_index'] ?? 0);
            if ($index <= 0) {
                continue;
            }

            $alt = trim((string) ($mapping['alt'] ?? $mapping['value'] ?? ''));
            if ($alt === '') {
                continue;
            }

            $items[] = $alt;
        }

        if (!$items) {
            return null;
        }

        return implode('|', $items);
    }

    private static function get_db2_main_image_alt(int $postId): ?string {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return null;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getPostAltMapping')) {
            return null;
        }

        $mapping = $manager->getPostAltMapping($postId, 'image', 0);
        if (!is_array($mapping)) {
            return null;
        }

        $alt = trim((string) ($mapping['alt'] ?? $mapping['value'] ?? ''));
        return $alt === '' ? null : $alt;
    }

    private static function get_db2_term_image_url(int $termId): ?string {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return null;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getTermMapping')) {
            return null;
        }

        $mapping = $manager->getTermMapping($termId, 'image');
        if (!is_array($mapping)) {
            return null;
        }

        $url = trim((string) ($mapping['url'] ?? ''));
        return $url === '' ? null : $url;
    }

    private static function get_db2_term_video_url(int $termId): ?string {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return null;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getTermMapping')) {
            return null;
        }

        $mapping = $manager->getTermMapping($termId, 'video');
        if (!is_array($mapping)) {
            return null;
        }

        $url = trim((string) ($mapping['url'] ?? ''));
        return $url === '' ? null : $url;
    }

    private static function get_db2_term_image_alt(int $termId): ?string {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return null;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getTermAltMapping')) {
            return null;
        }

        $mapping = $manager->getTermAltMapping($termId, 'image');
        if (!is_array($mapping)) {
            return null;
        }

        $alt = trim((string) ($mapping['alt'] ?? $mapping['value'] ?? ''));
        return $alt === '' ? null : $alt;
    }

    private static function normalize_pipe_list(?string $value): ?string {
        if ($value === null) {
            return null;
        }

        $entries = array_values(
            array_filter(
                array_map('trim', explode('|', $value)),
                static fn(string $entry): bool => $entry !== ''
            )
        );

        if (!$entries) {
            return null;
        }

        return implode('|', $entries);
    }

}
