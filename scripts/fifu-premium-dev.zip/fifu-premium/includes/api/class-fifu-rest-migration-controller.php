<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

final class Fifu_Rest_Migration_Controller
{
    public static function register_routes(): void
    {
        $routes = [
            ['route' => '/metadata_counter_api/', 'callback' => [self::class, 'metadata_counter']],
            ['route' => '/content_counter_api/', 'callback' => [self::class, 'content_counter']],
            ['route' => '/enable_fake_api/', 'callback' => [self::class, 'enable_fake']],
            ['route' => '/disable_fake_api/', 'callback' => [self::class, 'disable_fake']],
            ['route' => '/data_clean_api/', 'callback' => [self::class, 'data_clean']],
            ['route' => '/update_all_api/', 'callback' => [self::class, 'update_all']],
            ['route' => '/run_delete_all_api/', 'callback' => [self::class, 'run_delete_all']],
            ['route' => '/pre_deactivate/', 'callback' => [self::class, 'pre_deactivate']],
            ['route' => '/metain_status_api/', 'callback' => [self::class, 'metain_status']],
            ['route' => '/metain_batch_api/', 'callback' => [self::class, 'metain_batch']],
            ['route' => '/metaout_status_api/', 'callback' => [self::class, 'metaout_status']],
            ['route' => '/metaout_batch_api/', 'callback' => [self::class, 'metaout_batch']],
        ];

        foreach ($routes as $route) {
            register_rest_route(
                'fifu-premium/v2',
                $route['route'],
                [
                    'methods' => 'POST',
                    'callback' => $route['callback'],
                    'permission_callback' => [Fifu_Rest_Permissions::class, 'private_data'],
                ]
            );
        }
    }

    public static function metadata_counter(\WP_REST_Request $request)
    {
        $use_transient = filter_var($request['transient'], FILTER_VALIDATE_BOOLEAN);
        $total = $use_transient ? Fifu_Transient_Manager::get('fifu_metadata_counter') : false;
        if (false === $total) {
            $stats = new Fifu_Migration_Stats();
            $total = $stats->count_metadata_operations();
            Fifu_Transient_Manager::set('fifu_metadata_counter', $total, 0);
        }

        return $total;
    }

    public static function content_counter(\WP_REST_Request $request)
    {
        $use_transient = filter_var($request['transient'], FILTER_VALIDATE_BOOLEAN);
        $total = $use_transient ? Fifu_Transient_Manager::get('fifu_content_counter') : false;
        if (false === $total) {
            $stats = new Fifu_Migration_Stats();
            $total = $stats->count_content_operations();
            Fifu_Transient_Manager::set('fifu_content_counter', $total, 0);
        }
        return $total;
    }

    public static function enable_fake(\WP_REST_Request $request)
    {
        update_option('fifu_fake_stop', false, 'no');
        Fifu_Meta_Maintenance_Controller::clear_meta_out();
        try {
            return new WP_REST_Response(Fifu_Manual_Metain_Service::start(), 200);
        } catch (Fifu_Manual_Metain_Busy_Exception $e) {
            return new WP_REST_Response([
                'success' => false,
                'code' => 'fifu_manual_metain_busy',
                'message' => 'Image Metadata is being processed by another request.',
            ], 409);
        }
    }

    public static function disable_fake(\WP_REST_Request $request)
    {
        update_option('fifu_fake_stop', true, 'no');
        return new WP_REST_Response(Fifu_Manual_Metain_Service::pause(), 200);
    }

    public static function metain_status(\WP_REST_Request $request)
    {
        return new WP_REST_Response(Fifu_Manual_Metain_Service::status(), 200);
    }

    public static function metain_batch(\WP_REST_Request $request)
    {
        try {
            return new WP_REST_Response(Fifu_Manual_Metain_Service::process_next_batch(), 200);
        } catch (Fifu_Manual_Metain_Busy_Exception $e) {
            return new WP_REST_Response([
                'success' => false,
                'code' => 'fifu_manual_metain_busy',
                'message' => 'Image Metadata is being processed by another request.',
            ], 409);
        }
    }

    public static function metaout_status(\WP_REST_Request $request)
    {
        try {
            return new WP_REST_Response(Fifu_Manual_Metaout_Service::status(), 200);
        } catch (Fifu_Manual_Metaout_Busy_Exception $e) {
            return self::metaout_busy_response();
        }
    }

    public static function metaout_batch(\WP_REST_Request $request)
    {
        try {
            return new WP_REST_Response(Fifu_Manual_Metaout_Service::process_next_batch(), 200);
        } catch (Fifu_Manual_Metaout_Busy_Exception $e) {
            return self::metaout_busy_response();
        }
    }

    public static function data_clean(\WP_REST_Request $request)
    {
        try {
            return new WP_REST_Response(Fifu_Manual_Metaout_Service::start(), 200);
        } catch (Fifu_Manual_Metaout_Busy_Exception $e) {
            return self::metaout_busy_response();
        }
    }

    public static function update_all(\WP_REST_Request $request)
    {
        Fifu_Generic_Cron_Service::run('content');
        return json_encode([]);
    }

    public static function run_delete_all(\WP_REST_Request $request)
    {
        $cleanup = new Fifu_Local_Media_Cleanup();
        $cleanup->delete_all_fifu_meta();
        update_option('fifu_run_delete_all', 'toggleoff', 'no');
        return json_encode([]);
    }

    public static function pre_deactivate(\WP_REST_Request $request)
    {
        Fifu_Meta_Maintenance_Controller::enable_clean();

        $stats = new Fifu_Migration_Stats();
        $total = $stats->count_metadata_operations();
        Fifu_Transient_Manager::set('fifu_metadata_counter', $total, 0);
        $max_attempts = self::pre_deactivate_max_wait_attempts();
        $attempt = 0;

        while ($total > 0 && $attempt < $max_attempts) {
            wp_cache_flush();
            $total = (int) Fifu_Transient_Manager::get('fifu_metadata_counter');
            if ($total <= 0) {
                break;
            }

            $attempt++;
            sleep(3);
        }

        deactivate_plugins('fifu-premium/fifu-premium.php');
        return json_encode([]);
    }

    private static function pre_deactivate_max_wait_attempts(): int
    {
        $attempts = 10;

        if (function_exists('apply_filters')) {
            $attempts = (int) apply_filters('fifu_pre_deactivate_max_wait_attempts', $attempts);
        }

        return max(0, $attempts);
    }

    private static function metaout_busy_response(): WP_REST_Response
    {
        return new WP_REST_Response([
            'success' => false,
            'code' => 'fifu_manual_metaout_busy',
            'message' => 'Clear Metadata is busy. Please try again after the current metadata operation finishes.',
        ], 409);
    }

}
