<?php

class Fifu_Execution_Time_Tester {

    /**
     * Migrates fifu_test_execution_time() into a dedicated execution timer for debugging.
     */
    public static function run(): string {
        $start_time = static::now();
        for ($i = 0; $i <= 120; $i++) {
            static::log($i);
            static::sleep_seconds(1);
        }
        static::log(static::format(static::now() - $start_time, 4));
        return static::encode(array());
    }

    protected static function now(): float {
        return microtime(true);
    }

    protected static function sleep_seconds(int $seconds): void {
        sleep($seconds);
    }

    protected static function log($message): void {
        error_log($message);
    }

    protected static function format(float $value, int $decimals): string {
        return number_format($value, $decimals);
    }

    protected static function encode($value): string {
        return json_encode($value);
    }
}
