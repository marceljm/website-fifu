<?php

declare(strict_types=1);

defined('ABSPATH') || exit;

class Fifu_Shortcodes {

    /**
     * Register all FIFU shortcodes.
     */
    public static function register(): void {
        add_shortcode('fifu', [self::class, 'render_main_image']);
        add_shortcode('fifu_slider', [self::class, 'render_slider']);
        add_shortcode('fifu_gallery', [self::class, 'render_gallery']);
        add_shortcode('fifu_taxonomy', [self::class, 'render_taxonomy']);
    }

    /**
     * Resolve the post ID for a shortcode.
     *
     * @param array $atts
     * @return int|null
     */
    private static function resolve_post_id(array $atts): ?int {
        if (array_key_exists('post_id', $atts)) {
            $post_id = filter_var($atts['post_id'], FILTER_VALIDATE_INT, [
                'options' => ['min_range' => 1],
            ]);

            return $post_id === false ? null : (int) $post_id;
        }

        global $post;
        if (!isset($post) || !is_object($post) || !isset($post->ID)) {
            return null;
        }

        $post_id = filter_var($post->ID, FILTER_VALIDATE_INT, [
            'options' => ['min_range' => 1],
        ]);

        return $post_id === false ? null : (int) $post_id;
    }

    /**
     * Resolve the term ID for a shortcode.
     *
     * @param array $atts
     * @return int|null
     */
    private static function resolve_term_id(array $atts): ?int {
        if (isset($atts['term_id'])) {
            return (int) $atts['term_id'];
        }

        return Fifu_Category_Social_Tags::get_term_id();
    }

    /**
     * Build src attribute for a main image shortcode.
     *
     * @param int $post_id
     * @return string
     */
    private static function build_attr_src(int $post_id): string {
        $src = Fifu_Post_Main_Image_Resolver::get_main_image_url($post_id, true);
        if (!$src) {
            return '';
        }

        $src = Fifu_Jetpack_Cdn_Service::get_cdn_url($src, get_post_thumbnail_id($post_id), null, null);
        Fifu_Local_Media_Renderer::register_post_thumbnail($post_id);
        $src = esc_url($src);

        return " src=\"{$src}\"";
    }

    /**
     * Build alt attribute for a main image shortcode.
     *
     * @param int $post_id
     * @return string
     */
    private static function build_attr_alt(int $post_id): string {
        $image_alt = Fifu_Post_Image_Alt_Read_Service::get_image_alt((int) $post_id);
        if (!$image_alt) {
            return '';
        }

        $image_alt = esc_attr(wp_strip_all_tags($image_alt));

        return " alt=\"{$image_alt}\"";
    }

    /**
     * Build width attribute for a shortcode.
     *
     * @param array $atts
     * @return string
     */
    private static function build_attr_width(array $atts): string {
        if (!isset($atts['width'])) {
            return '';
        }

        $width = esc_attr($atts['width']);

        return " width=\"{$width}\"";
    }

    /**
     * Build height attribute for a shortcode.
     *
     * @param array $atts
     * @return string
     */
    private static function build_attr_height(array $atts): string {
        if (!isset($atts['height'])) {
            return '';
        }

        $height = esc_attr($atts['height']);

        return " height=\"{$height}\"";
    }

    /**
     * Build style attribute for a shortcode.
     *
     * @param array $atts
     * @return string
     */
    private static function build_attr_style(array $atts): string {
        if (!isset($atts['style'])) {
            return '';
        }

        $style = esc_attr($atts['style']);

        return " style=\"{$style}\"";
    }

    /**
     * [fifu] main image shortcode renderer.
     *
     * @param array $atts
     * @return string
     */
    public static function render_main_image(array $atts): string {
        $post_id = self::resolve_post_id($atts);
        if (!$post_id) {
            return '';
        }

        $src_attr = self::build_attr_src($post_id);
        if (!$src_attr) {
            return '';
        }

        return '<img ' . $src_attr . self::build_attr_alt($post_id) . self::build_attr_width($atts) . self::build_attr_height($atts) . self::build_attr_style($atts) . '>';
    }

    /**
     * [fifu_slider] shortcode renderer.
     *
     * @param array $atts
     * @return string
     */
    public static function render_slider(array $atts): string {
        $post_id = self::resolve_post_id($atts);
        if (!$post_id) {
            return '';
        }

        $width = isset($atts['width']) ? (int) $atts['width'] : 0;
        $height = isset($atts['height']) ? (int) $atts['height'] : 0;

        Fifu_Frontend_Assets::enqueue_lightslider_assets(true);

        return Fifu_Slider_Renderer::render_slider($post_id, null, null, null, $width, $height);
    }

    /**
     * [fifu_gallery] shortcode renderer.
     *
     * @param array $atts
     * @return string
     */
    public static function render_gallery(array $atts): string {
        $post_id = self::resolve_post_id($atts);
        if (!$post_id) {
            return '';
        }

        Fifu_Frontend_Assets::enqueue_lightslider_assets(true);

        return Fifu_Woocommerce_Gallery_Renderer::render_product_gallery(
            $post_id,
            null,
            'fifu-woo-gallery',
            ''
        );
    }

    /**
     * [fifu_taxonomy] shortcode renderer.
     *
     * @param array $atts
     * @return string
     */
    public static function render_taxonomy(array $atts): string {
        if (!in_the_loop() || Fifu_Options_Utils::is_off('fifu_taxonomy')) {
            return '';
        }

        $post_id = get_the_ID();

        $slug = $atts['slug'] ?? '';
        if (empty($slug)) {
            return 'Taxonomy slug not specified.';
        }

        $terms = get_the_terms($post_id, $slug);
        if (!$terms || is_wp_error($terms)) {
            return 'No terms found for this taxonomy.';
        }

        $output = '';
        foreach ($terms as $term) {
            $term_id = $term->term_id;
            $url = trim((string) Fifu_Category_Social_Tags::get_image_url($term_id));
            if ($url === '') {
                continue;
            }

            if (Fifu_Options_Utils::is_on('fifu_photon') && isset($atts['width'])) {
                $width = (int) $atts['width'];
                $height = isset($atts['height']) && $atts['height'] !== '' ? (int) $atts['height'] : null;
                $url = Fifu_Image_Cdn_Resize_Service::resize_with_cdn($url, $width, $height, null, Fifu_Post_Meta_Utils::get_term_thumbnail_id($term_id), null);
            }

            $url = trim((string) $url);
            if ($url === '') {
                continue;
            }

            $alt = esc_attr((string) Fifu_Category_Social_Tags::get_alt($term_id));
            $src = str_replace('"', '&quot;', html_entity_decode(esc_url($url), ENT_QUOTES));
            $image_attributes = '<img ' .
                'src="' . $src . '" ' .
                'alt="' . $alt . '" ' .
                self::build_attr_width($atts) .
                self::build_attr_height($atts) .
                self::build_attr_style($atts) .
                '>';
            $output .= $image_attributes;
        }

        return $output;
    }
}
