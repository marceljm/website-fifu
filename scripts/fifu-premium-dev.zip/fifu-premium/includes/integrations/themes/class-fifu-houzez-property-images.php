<?php
declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

/**
 * Houzez theme helpers for FIFU property images.
 */
class Fifu_Houzez_Property_Images {

    private wpdb $wpdb;

    private string $postmeta_table;

    private string $fifu_map_table;

    private string $fifu_key_table;

    private string $fifu_url_table;

    public function __construct(?wpdb $wpdb = null) {
        $this->wpdb = $wpdb ?? $GLOBALS['wpdb'];
        $this->postmeta_table = $this->wpdb->postmeta;
        $prefix = $this->wpdb->prefix;
        $this->fifu_map_table = $prefix . 'fifu_map';
        $this->fifu_key_table = $prefix . 'fifu_key';
        $this->fifu_url_table = $prefix . 'fifu_url';
    }

    /**
     * Retrieves post IDs that have both 'fifu_slider_list_url'
     * and '_product_image_gallery'.
     *
     * Mirrors get_post_ids_for_houzez().
     *
     * @return int[] List of post IDs.
     */
    public function get_post_ids_with_slider_and_gallery(): array {
        if (!function_exists('fifu_db2_mode')) {
            return $this->get_post_ids_for_houzez_legacy();
        }

        $mode = fifu_db2_mode();

        if ($mode === Fifu_Db2_Mode::MODE_LEGACY) {
            return $this->get_post_ids_for_houzez_legacy();
        }

        $db2Rows = $this->get_post_ids_for_houzez_db2();

        if ($mode === Fifu_Db2_Mode::MODE_DB2) {
            if ($db2Rows !== null) {
                return $db2Rows;
            }
            return $this->get_post_ids_for_houzez_legacy();
        }

        $legacyRows = $this->get_post_ids_for_houzez_legacy();

        if ($db2Rows === null) {
            return $legacyRows;
        }

        return $this->merge_houzez_post_ids($db2Rows, $legacyRows);
    }

    /**
     * Legacy SQL path for Houzez post IDs.
     *
     * @return int[]
     */
    private function get_post_ids_for_houzez_legacy(): array {
        $sql = "
            SELECT a.post_id
            FROM {$this->postmeta_table} AS a
            WHERE a.meta_key = 'fifu_slider_list_url'
            AND EXISTS (
                SELECT 1
                FROM {$this->postmeta_table} AS b
                WHERE a.post_id = b.post_id
                AND b.meta_key = '_product_image_gallery'
            )
        ";

        $results = $this->wpdb->get_results($sql);
        $post_ids = wp_list_pluck($results, 'post_id');
        return array_map('intval', $post_ids);
    }

    /**
     * DB2 SQL path for Houzez post IDs.
     *
     * @return int[]|null
     */
    private function get_post_ids_for_houzez_db2(): ?array {
        if (!$this->is_db2_slider_ready()) {
            return null;
        }

        $sql = "
            SELECT DISTINCT m.post_id AS post_id
            FROM {$this->fifu_map_table} m
            INNER JOIN {$this->fifu_key_table} k ON k.key_id = m.key_id
            INNER JOIN {$this->fifu_url_table} u ON u.hash = m.hash
            WHERE k.key_type = 'slider'
              AND m.key_index IS NOT NULL
              AND EXISTS (
                  SELECT 1
                  FROM {$this->postmeta_table} pm
                  WHERE pm.post_id = m.post_id
                    AND pm.meta_key = '_product_image_gallery'
              )
        ";

        $results = $this->wpdb->get_results($sql);
        if ($results === false) {
            return null;
        }

        $post_ids = wp_list_pluck($results, 'post_id');
        return array_map('intval', $post_ids);
    }

    /**
     * Deduplicates post IDs keeping DB2 order.
     *
     * @param int[] $db2Ids
     * @param int[] $legacyIds
     * @return int[]
     */
    private function merge_houzez_post_ids(array $db2Ids, array $legacyIds): array {
        $seen = [];
        $merged = [];

        foreach ($db2Ids as $postId) {
            $normalized = (int) $postId;
            if ($normalized === 0 || isset($seen[$normalized])) {
                continue;
            }
            $seen[$normalized] = true;
            $merged[] = $normalized;
        }

        foreach ($legacyIds as $postId) {
            $normalized = (int) $postId;
            if ($normalized === 0 || isset($seen[$normalized])) {
                continue;
            }
            $seen[$normalized] = true;
            $merged[] = $normalized;
        }

        return $merged;
    }

    /**
     * Checks whether the DB2 tables necessary for slider Houzez queries are present.
     *
     * @return bool
     */
    private function is_db2_slider_ready(): bool {
        return $this->table_exists($this->fifu_map_table)
            && $this->table_exists($this->fifu_key_table)
            && $this->table_exists($this->fifu_url_table);
    }

    /**
     * Returns whether the given table exists in the database.
     *
     * @param string $table
     * @return bool
     */
    private function table_exists(string $table): bool {
        $sql = $this->wpdb->prepare("SHOW TABLES LIKE %s", $table);
        $result = $this->wpdb->get_var($sql);
        return $result !== null;
    }

    /**
     * Removes 'fave_property_images' entries for the provided posts.
     *
     * Mirrors delete_fave_property_images().
     *
     * @param int[] $post_ids
     * @return int Estimated number of rows affected (or 0 when not trackable).
     */
    public function delete_property_images(array $post_ids): int {
        $sanitized = array_map('intval', array_filter($post_ids, static function ($value) {
            return is_scalar($value) && (string) $value !== '';
        }));

        if (empty($sanitized)) {
            return 0;
        }

        $post_ids_str = implode(',', $sanitized);
        $query = "
            DELETE FROM {$this->postmeta_table}
            WHERE meta_key = 'fave_property_images'
            AND post_id IN ({$post_ids_str})
        ";

        return (int) $this->wpdb->query($query);
    }

    /**
     * Populates 'fave_property_images' meta based on '_product_image_gallery'
     * for the specified posts.
     *
     * Mirrors add_fave_property_images().
     *
     * @param int[] $post_ids
     * @return int Estimated number of rows inserted (or 0 when not tracked).
     */
    public function add_property_images(array $post_ids): int {
        $sanitized = array_map('intval', array_filter($post_ids, static function ($value) {
            return is_scalar($value) && (string) $value !== '';
        }));

        if (empty($sanitized)) {
            return 0;
        }

        $post_ids_str = implode(',', $sanitized);
        $results = $this->wpdb->get_results("
            SELECT post_id, meta_value
            FROM {$this->postmeta_table}
            WHERE meta_key = '_product_image_gallery'
            AND post_id IN ({$post_ids_str})
        ");

        $insert_values = [];
        foreach ($results as $row) {
            $post_id = (int) $row->post_id;
            $gallery_ids = array_filter(explode(',', (string) $row->meta_value), 'strlen');
            foreach ($gallery_ids as $att_id) {
                $insert_values[] = "({$post_id}, 'fave_property_images', " . (int) $att_id . ")";
            }
        }

        if (empty($insert_values)) {
            return 0;
        }

        $insert_query = "
            INSERT INTO {$this->postmeta_table} (post_id, meta_key, meta_value)
            VALUES " . implode(',', $insert_values);
        $this->wpdb->query($insert_query);
        return count($insert_values);
    }

    /**
     * Sync Houzez-specific property gallery meta after FIFU attachments change.
     *
     * @param int $postId
     * @return void
     */
    public static function sync_property_images(int $postId): void
    {
        if (!Fifu_Theme_Detector::is_houzez_active()) {
            return;
        }

        delete_post_meta($postId, 'fifu_houzez_urls');
        delete_post_meta($postId, 'fave_property_images');

        $gallery = get_post_meta($postId, '_product_image_gallery', true);
        if (!$gallery) {
            return;
        }

        foreach (explode(',', $gallery) as $attId) {
            $attId = trim($attId);
            if ($attId === '') {
                continue;
            }
            add_post_meta($postId, 'fave_property_images', (int) $attId, false);
        }
    }
}
