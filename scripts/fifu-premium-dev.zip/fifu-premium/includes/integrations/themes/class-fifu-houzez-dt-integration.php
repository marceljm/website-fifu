<?php

declare(strict_types=1);

/**
 * Integration layer for the Houzez theme DataTransport hooks.
 */
class Fifu_Houzez_Dt_Integration {

    private const DEBUG = false;
    private const DEBUG_LIST = 'https://picsum.photos/seed/houzez-1/2075/1383|https://picsum.photos/seed/houzez-2/2080/1387|https://picsum.photos/seed/houzez-3/2070/1380|https://picsum.photos/seed/houzez-4/2070/1380|https://picsum.photos/seed/houzez-5/1974/1316|https://picsum.photos/seed/houzez-6/2070/1380';

    /**
     * Register the DataTransport hooks only when the theme and option are active.
     */
    public static function register_hooks(): void {
        if (!class_exists('Fifu_Theme_Detector')) {
            return;
        }

        if (!Fifu_Theme_Detector::is_houzez_active()) {
            return;
        }

        if (!Fifu_Options_Utils::is_on('fifu_houzez_api')) {
            return;
        }

        add_action('dt_push_post_media', [self::class, 'push_post_media'], 10, 4);
        add_action('dt_before_set_meta', [self::class, 'before_set_meta'], 10, 2);
        add_action('dt_prepared_meta', [self::class, 'prepared_meta'], 10, 2);
    }

    /**
     * Hook that allows tweaks before DataTransport writes metadata.
     */
    public static function before_set_meta($meta, $postId): void {
        if (!is_array($meta)) {
            return;
        }
        $postId = is_numeric($postId) ? (int) $postId : 0;
        if ($postId <= 0) {
            return;
        }
        if (!isset($meta['fifu_houzez_urls'])) {
            return;
        }

        $urls = $meta['fifu_houzez_urls'];
        if (!is_array($urls)) {
            return;
        }
        $normalizedUrls = [];
        foreach ($urls as $url) {
            if ($url !== null && !is_scalar($url)) {
                return;
            }
            $normalizedUrls[] = (string) ($url ?? '');
        }
        $urlList = implode('|', $normalizedUrls);
        $urlList = self::DEBUG ? self::DEBUG_LIST : $urlList;
        $existingList = Fifu_Post_Slider_List_Url_Read_Service::get_slider_list_url($postId);
        if ($urlList === $existingList
            && Fifu_Post_Slider_Image_Url_Read_Service::get_slider_image_url(
                (int) $postId,
                0
            )
            && !self::DEBUG
        ) {
            return;
        }

        delete_post_meta($postId, 'fifu_houzez_urls');
        delete_post_meta($postId, 'fave_property_images');

        $altList = [];
        Fifu_Developer_Media_Service::set_slider(
            (int) $postId,
            (string) $urlList,
            is_array($altList) ? implode('|', $altList) : (string) $altList
        );
        wp_cache_flush();

        $galleryIds = get_post_meta($postId, '_product_image_gallery', true);
        if (!empty($galleryIds)) {
            foreach (explode(',', $galleryIds) as $attId) {
                if (!empty($attId)) {
                    add_post_meta($postId, 'fave_property_images', $attId, false);
                }
            }
        }
    }

    /**
     * Hook that adjusts metadata prepared by DataTransport.
     */
    public static function prepared_meta($prepared_meta, $postId) {
        if (!is_array($prepared_meta)) {
            return $prepared_meta;
        }
        if (isset($prepared_meta['_thumbnail_id']) || isset($prepared_meta['fave_property_images'])) {
            $prepared_meta['fifu_houzez_urls'] = [];
        }

        if (isset($prepared_meta['_thumbnail_id'])) {
            $thumbnailMeta = $prepared_meta['_thumbnail_id'];
            if (is_array($thumbnailMeta)) {
                $thumbnailId = $thumbnailMeta[0] ?? null;
            } else {
                $thumbnailId = null;
            }
            if ($thumbnailId) {
                $thumbnailUrl = wp_get_attachment_url($thumbnailId);
                if ($thumbnailUrl) {
                    $prepared_meta['fifu_houzez_urls'][] = $thumbnailUrl;
                }
            }
        }

        if (isset($prepared_meta['fave_property_images'])) {
            $gallery = $prepared_meta['fave_property_images'];
            if (is_iterable($gallery)) {
                foreach ($gallery as $imageId) {
                    $imageUrl = wp_get_attachment_url($imageId);
                    if ($imageUrl) {
                        $prepared_meta['fifu_houzez_urls'][] = $imageUrl;
                    }
                }
            }
        }

        return $prepared_meta;
    }

    /**
     * Hook that intercepts media pushing during cloning or imports.
     */
    public static function push_post_media($new_post_id, $post_media, $post_id, $args): bool {
        return false;
    }
}
