<?php
declare(strict_types=1);

defined('ABSPATH') || exit;

/**
 * Integration for WpResidence property gallery meta.
 */
class Fifu_WpResidence_Property_Images
{

    /**
     * Sync WpResidence property gallery meta based on FIFU attachments.
     *
     * @param int $postId
     */
    public static function sync_property_gallery(int $postId): void
    {
        $gallery = get_post_meta($postId, '_product_image_gallery', true);
        $thumbnailId = get_post_meta($postId, '_thumbnail_id', true);
        $ids = $thumbnailId
            ? array_merge([$thumbnailId], array_filter(explode(',', $gallery ?? ''), 'strlen'))
            : array_filter(explode(',', $gallery ?? ''), 'strlen');

        if (empty($ids)) {
            update_post_meta($postId, 'wpestate_property_gallery', []);
            return;
        }

        $mappedIds = array_combine(range(1, count($ids)), array_values(array_map('intval', $ids)));
        if ($mappedIds === false) {
            update_post_meta($postId, 'wpestate_property_gallery', []);
            return;
        }

        update_post_meta($postId, 'wpestate_property_gallery', $mappedIds);
    }
}
