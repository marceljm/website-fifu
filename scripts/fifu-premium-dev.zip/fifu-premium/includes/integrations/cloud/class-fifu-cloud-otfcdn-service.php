<?php
declare(strict_types=1);

final class Fifu_Cloud_Otfcdn_Service {

    public const OWN_DOMAIN_READINESS_HOOK = 'fifu_check_own_domain_readiness';

    /**
     * Toggle the OTF CDN feature remotely and return the remote response.
     */
    public static function toggle(bool $enabled) {
        $wasEnabled = Fifu_Options_Utils::is_on('fifu_otfcdn');

        if ($enabled && !$wasEnabled && Fifu_Options_Utils::is_on('fifu_own_domain')) {
            update_option('fifu_own_domain_ready', 'toggleoff');
        }

        $queryParams = http_build_query([
            'site' => Fifu_Image_Url_Utils::get_home_url_no_scheme(),
            'partial_key' => Fifu_Options_Utils::partial_key(),
            'enabled' => $enabled ? 'true' : 'false',
            'async_provisioning' => 'true',
        ]);

        $workerUrl = "https://fifu-otfcdn.fifu.workers.dev?" . $queryParams;
        $response = wp_remote_get($workerUrl);
        if (is_wp_error($response)) {
            return false;
        }

        $statusCode = wp_remote_retrieve_response_code($response);
        if ($statusCode < 200 || $statusCode >= 300) {
            return [
                'status_code' => $statusCode,
                'response_body' => wp_remote_retrieve_body($response),
            ];
        }

        if ($enabled && !$wasEnabled) {
            self::finalize_activation();
        } elseif (!$enabled) {
            update_option('fifu_otfcdn', 'toggleoff');
            update_option('fifu_own_domain_ready', 'toggleoff');
            wp_clear_scheduled_hook(self::OWN_DOMAIN_READINESS_HOOK);
        }

        return [
            'status_code' => $statusCode,
            'response_body' => wp_remote_retrieve_body($response),
        ];
    }

    private static function finalize_activation(): void
    {
        $domain = Fifu_Main_Domain_Sync_Service::get_current_site_host();
        if ('' === $domain) {
            return;
        }

        $url = add_query_arg(
            ['domain' => $domain],
            'https://i0.fifu.app/check-domain'
        );

        $response = wp_remote_get(
            $url,
            ['timeout' => 10]
        );

        if (is_wp_error($response)) {
            return;
        }

        if (200 !== wp_remote_retrieve_response_code($response)) {
            return;
        }

        update_option('fifu_otfcdn', 'toggleon');

        if (Fifu_Options_Utils::is_on('fifu_own_domain')) {
            self::refresh_own_domain_readiness();
        }
    }

    private static function refresh_own_domain_readiness(): void
    {
        $domain = Fifu_Main_Domain_Sync_Service::get_current_site_host();
        if ('' === $domain) {
            self::apply_own_domain_readiness(false);
            return;
        }

        $url = add_query_arg(
            [
                'domain' => $domain,
                'include_readiness' => 'true',
            ],
            'https://i0.fifu.app/check-domain'
        );

        $response = wp_remote_get(
            $url,
            ['timeout' => 10]
        );

        if (
            is_wp_error($response)
            || 200 !== wp_remote_retrieve_response_code($response)
        ) {
            self::apply_own_domain_readiness(false);
            return;
        }

        $data = json_decode(
            wp_remote_retrieve_body($response),
            true
        );

        if (
            is_array($data)
            && array_key_exists('own_domain_ready', $data)
            && true === $data['own_domain_ready']
        ) {
            self::apply_own_domain_readiness(true);
            return;
        }

        self::apply_own_domain_readiness(false);
    }

    private static function is_own_domain_readiness_active_fresh(): bool
    {
        global $wpdb;

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT option_name, option_value
                 FROM {$wpdb->options}
                 WHERE option_name IN (%s, %s)",
                'fifu_otfcdn',
                'fifu_own_domain'
            ),
            OBJECT_K
        );

        return isset(
            $rows['fifu_otfcdn'],
            $rows['fifu_own_domain']
        )
            && 'toggleon' === $rows['fifu_otfcdn']->option_value
            && 'toggleon' === $rows['fifu_own_domain']->option_value;
    }

    private static function apply_own_domain_readiness(bool $ready): void
    {
        if (!self::is_own_domain_readiness_active_fresh()) {
            update_option('fifu_own_domain_ready', 'toggleoff');
            wp_clear_scheduled_hook(self::OWN_DOMAIN_READINESS_HOOK);
            return;
        }

        update_option(
            'fifu_own_domain_ready',
            $ready ? 'toggleon' : 'toggleoff'
        );

        if (!$ready) {
            self::schedule_own_domain_readiness_check();
        }

        if (!self::is_own_domain_readiness_active_fresh()) {
            update_option('fifu_own_domain_ready', 'toggleoff');
            wp_clear_scheduled_hook(self::OWN_DOMAIN_READINESS_HOOK);
        }
    }

    public static function check_own_domain_readiness(): void
    {
        if (!self::is_own_domain_readiness_active_fresh()) {
            return;
        }

        self::refresh_own_domain_readiness();
    }

    public static function set_own_domain(bool $enabled): void
    {
        $wasEnabled = Fifu_Options_Utils::is_on('fifu_own_domain');

        if ($wasEnabled === $enabled) {
            return;
        }

        if ($enabled) {
            update_option('fifu_own_domain_ready', 'toggleoff');
        }

        update_option(
            'fifu_own_domain',
            $enabled ? 'toggleon' : 'toggleoff'
        );

        if ($enabled && Fifu_Options_Utils::is_on('fifu_otfcdn')) {
            self::check_own_domain_readiness();
            return;
        }

        if (!$enabled) {
            update_option('fifu_own_domain_ready', 'toggleoff');
            wp_clear_scheduled_hook(self::OWN_DOMAIN_READINESS_HOOK);
        }
    }

    private static function schedule_own_domain_readiness_check(): void
    {
        if (!self::is_own_domain_readiness_active_fresh()) {
            wp_clear_scheduled_hook(self::OWN_DOMAIN_READINESS_HOOK);
            return;
        }

        if (false !== wp_next_scheduled(self::OWN_DOMAIN_READINESS_HOOK)) {
            return;
        }

        wp_schedule_single_event(
            time() + 60,
            self::OWN_DOMAIN_READINESS_HOOK
        );

        if (!self::is_own_domain_readiness_active_fresh()) {
            wp_clear_scheduled_hook(self::OWN_DOMAIN_READINESS_HOOK);
        }
    }
}
