<?php
declare(strict_types=1);

final class Fifu_Cloud_Test_Service {

    /**
     * Test the connectivity with the external plugin server endpoint.
     */
    public static function test_plugin_server() {
        Fifu_Main_Domain_Sync_Service::ensure_current(true);
        delete_option('fifu_status_server');
        $url = "https://plugin.featuredimagefromurl.com/api/test/";
        $body = json_encode(array(
            'route' => get_rest_url(),
            'transient_key' => Fifu_Plugin_Info::get_version(),
        ));
        $headers = array(
            'Content-Type' => 'application/json',
        );
        wp_remote_post($url, array(
            'method' => 'POST',
            'body' => $body,
            'headers' => $headers,
            'blocking' => true,
            'timeout' => 1,
        ));
        return true;
    }

    /**
     * Mark the local plugin server as healthy.
     */
    public static function mark_plugin_server_healthy() {
        update_option('fifu_status_server', true, 'no');
    }
}
