<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

final class Fifu_Rest_Permissions {

    public static function private_data(\WP_REST_Request $request) {
        if (!current_user_can('manage_options')) {
            return new \WP_Error('rest_forbidden', __('Private'), array('status' => 401));
        }

        $nonce = (string) $request->get_header('X-WP-Nonce');
        if ($nonce !== '' && !wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('rest_forbidden', __('Private'), array('status' => 401));
        }

        return true;
    }

    public static function quick_edit_read(\WP_REST_Request $request) {
        if (!current_user_can('publish_posts')) {
            return new \WP_Error('rest_forbidden', __('Private'), array('status' => 401));
        }

        $nonce = (string) $request->get_header('X-WP-Nonce');
        if ($nonce !== '' && !wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('rest_forbidden', __('Private'), array('status' => 401));
        }

        return true;
    }

    public static function public_access(\WP_REST_Request $request): bool {
        return true;
    }
}
