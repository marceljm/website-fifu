<?php
declare(strict_types=1);

defined('ABSPATH') || exit;

final class Fifu_Post_Rest_Integration
{
    public static function register_hooks(): void
    {
        add_action('rest_api_init', [self::class, 'on_rest_api_init']);
    }

    public static function on_rest_api_init(): void
    {
        foreach (Fifu_Post_Type_Utils::get_post_types() as $postType) {
            $postType = sanitize_key($postType);
            if (!$postType) {
                continue;
            }

            add_filter("rest_prepare_{$postType}", [self::class, 'rest_prepare_post'], 10, 3);
            add_filter("rest_insert_{$postType}", [self::class, 'rest_insert_post'], 10, 3);
        }
    }

    /**
     * Filter REST response to include FIFU meta fields.
     *
     * @param WP_REST_Response $response
     * @param WP_Post          $post
     * @param WP_REST_Request  $request
     * @return WP_REST_Response
     */
    public static function rest_prepare_post($response, $post, $request)
    {
        $data = $response->get_data();

        $imageUrl = Fifu_Post_Image_Url_Read_Service::get_image_url((int) $post->ID);
        if ($imageUrl) {
            $data['fifu_image_url'] = $imageUrl;
        }

        $videoUrl = Fifu_Post_Video_Read_Service::get_video_url((int) $post->ID);
        if ($videoUrl) {
            $data['fifu_video_url'] = $videoUrl;
        }

        $i = 0;
        while (true) {
            $sliderUrl = Fifu_Post_Slider_Image_Url_Read_Service::get_slider_image_url(
                (int) $post->ID,
                (int) $i
            );
            if (!$sliderUrl) {
                break;
            }
            $data['fifu_slider_image_url_' . $i++] = $sliderUrl;
        }

        $alt = Fifu_Post_Image_Alt_Read_Service::get_image_alt((int) $post->ID);
        if ($alt) {
            $data['fifu_image_alt'] = $alt;
        }


        $asin = Fifu_Post_Identifier_Read_Service::get_asin((int) $post->ID);
        if ($asin) {
            $data['fifu_asin'] = $asin;
        }

        $finderUrl = Fifu_Post_Finder_Read_Service::get_finder_url((int) $post->ID);
        if ($finderUrl) {
            $data['fifu_finder_url'] = $finderUrl;
        }

        $redirectionUrl = Fifu_Post_Redirection_Read_Service::get_redirection_url((int) $post->ID);
        if ($redirectionUrl) {
            $data['fifu_redirection_url'] = $redirectionUrl;
        }

        $response->set_data($data);
        return $response;
    }

    /**
     * Handle REST insert/update to persist FIFU meta fields.
     *
     * @param WP_Post         $post
     * @param WP_REST_Request $request
     * @param bool            $creating
     */
    public static function rest_insert_post($post, $request, $creating): void
    {
        $params = [];
        if (method_exists($request, 'get_query_params')) {
            $params = array_merge($params, (array) $request->get_query_params());
        }
        if (method_exists($request, 'get_body_params')) {
            $params = array_merge($params, (array) $request->get_body_params());
        }
        if (method_exists($request, 'get_json_params')) {
            $params = array_merge($params, (array) $request->get_json_params());
        }
        if (method_exists($request, 'get_file_params')) {
            $params = array_merge($params, (array) $request->get_file_params());
        }
        $meta = is_array($params['meta'] ?? null) ? $params['meta'] : [];
        $imageUrl = self::get_top_level_or_makecom_param($params, $meta, 'fifu_image_url');
        $videoUrl = self::get_top_level_or_makecom_param($params, $meta, 'fifu_video_url');
        $sliderListUrl = self::get_top_level_or_makecom_param($params, $meta, 'fifu_slider_list_url');
        $sliderListAlt = self::get_top_level_or_makecom_param($params, $meta, 'fifu_slider_list_alt');
        $imageAlt = self::get_top_level_or_makecom_param($params, $meta, 'fifu_image_alt');
        $normalizedImageAlt = $imageAlt !== null
            ? self::normalize_rest_alt_value($imageAlt)
            : null;
        $hasImageAltPayload = array_key_exists('fifu_image_alt', $params) || array_key_exists('fifu_image_alt', $meta);
        $imageAltForPersistence = null;
        if ($hasImageAltPayload) {
            $imageAltForPersistence = $normalizedImageAlt ?? '';
        }
        $preferMakecomVideoWhenBoth = self::should_prefer_makecom_video_payload($params, $meta);
        $imageUrlForPersistence = null;
        $imageUrlAlreadyHandled = false;
        $customVideoPersistence = null;
        $canonicalImageNoop = false;

        if (!array_key_exists('fifu_video_url', $params) && $videoUrl !== null) {
            $params['fifu_video_url'] = $videoUrl;
        } elseif (array_key_exists('fifu_video_url', $params) && is_string($params['fifu_video_url'])) {
            $params['fifu_video_url'] = $videoUrl;
        }
        if (!array_key_exists('fifu_slider_list_url', $params) && $sliderListUrl !== null) {
            $params['fifu_slider_list_url'] = $sliderListUrl;
        }
        if (!array_key_exists('fifu_slider_list_alt', $params) && $sliderListAlt !== null) {
            $params['fifu_slider_list_alt'] = $sliderListAlt;
        }
        if (!array_key_exists('fifu_image_url', $params) && $imageUrl !== null) {
            $params['fifu_image_url'] = $imageUrl;
        } elseif (array_key_exists('fifu_image_url', $params) && is_string($params['fifu_image_url'])) {
            $params['fifu_image_url'] = $imageUrl;
        }
        if (!array_key_exists('fifu_image_alt', $params) && $normalizedImageAlt !== null) {
            $params['fifu_image_alt'] = $normalizedImageAlt;
        }
        if ($hasImageAltPayload && !array_key_exists('fifu_input_alt', $params)) {
            $params['fifu_input_alt'] = $normalizedImageAlt ?? '';
        }

        $trimmedImageUrl = trim((string) ($params['fifu_image_url'] ?? $imageUrl ?? ''));
        $trimmedVideoUrl = trim((string) ($params['fifu_video_url'] ?? $videoUrl ?? ''));
        $trimmedSliderListUrl = trim((string) ($params['fifu_slider_list_url'] ?? $sliderListUrl ?? ''));
        $hasImagePayload = array_key_exists('fifu_image_url', $params) || array_key_exists('fifu_image_url', $meta);
        $hasVideoPayload = array_key_exists('fifu_video_url', $params) || array_key_exists('fifu_video_url', $meta);
        $hasSliderPayload = array_key_exists('fifu_slider_list_url', $params) || array_key_exists('fifu_slider_list_url', $meta);
        $winner = self::resolve_rest_featured_media_winner(
            $hasImagePayload,
            $trimmedImageUrl,
            $hasVideoPayload,
            $trimmedVideoUrl,
            $hasSliderPayload,
            $trimmedSliderListUrl,
            $preferMakecomVideoWhenBoth
        );

        if ($winner === 'slider') {
            self::clear_competing_featured_media($post->ID, 'slider');
            unset($params['fifu_image_url'], $params['fifu_image_alt'], $params['fifu_video_url'], $params['fifu_custom_video_url']);
            $params['fifu_slider_list_url'] = $sliderListUrl;
            if ($sliderListAlt !== null) {
                $params['fifu_slider_list_alt'] = $sliderListAlt;
            }
            self::clear_existing_slider_list_state($post->ID);
            unset(
                $params['fifu_image_url'],
                $params['fifu_image_alt'],
                $params['fifu_input_url'],
                $params['fifu_input_alt'],
                $params['fifu_video_url'],
                $params['fifu_video_input_url'],
                $params['fifu_custom_video_url']
            );
            fifu_update_or_delete($post->ID, 'fifu_image_url', '');
            fifu_update_or_delete_value($post->ID, 'fifu_image_alt', '');
            fifu_update_or_delete($post->ID, 'fifu_video_url', '');
            fifu_update_or_delete($post->ID, 'fifu_custom_video_url', '');
            fifu_update_or_delete($post->ID, 'fifu_slider_list_url', $sliderListUrl);
            self::write_slider_list_entries($post->ID, (string) $sliderListUrl, $sliderListAlt);
        } elseif ($winner === 'image') {
            $imageUrlForPersistence = $trimmedImageUrl === '' ? '' : self::sanitize_rest_url_value($trimmedImageUrl);
            $canonicalImageNoop =
                !$creating
                && $hasImageAltPayload
                && $imageUrlForPersistence !== ''
                && !self::has_competing_rest_featured_media_payload($params, $meta)
                && self::is_exact_canonical_simple_rest_image_state(
                    (int) $post->ID,
                    $imageUrlForPersistence,
                    $imageAltForPersistence ?? ''
                );

            if (!$canonicalImageNoop) {
                self::clear_competing_featured_media($post->ID, 'image');
                self::clear_db2_image_gallery_state((int) $post->ID);
                fifu_update_or_delete($post->ID, 'fifu_image_url', $imageUrlForPersistence);
                self::clear_legacy_image_gallery_meta_state((int) $post->ID);
            }

            unset($params['fifu_video_url'], $params['fifu_custom_video_url'], $params['fifu_slider_list_url'], $params['fifu_slider_list_alt']);
            $imageUrlAlreadyHandled = true;
        } elseif ($winner === 'custom_video') {
            self::clear_competing_featured_media($post->ID, 'custom_video');
            $customVideoPersistence = self::split_custom_video_payload($trimmedVideoUrl);
            $params['fifu_video_url'] = $trimmedVideoUrl;
            unset($params['fifu_image_url'], $params['fifu_image_alt'], $params['fifu_video_input_url'], $params['fifu_input_url'], $params['fifu_slider_list_url'], $params['fifu_slider_list_alt']);
        } elseif ($winner === 'video') {
            self::clear_competing_featured_media($post->ID, 'video');
            $params['fifu_video_url'] = $trimmedVideoUrl;
            unset($params['fifu_image_url'], $params['fifu_image_alt'], $params['fifu_custom_video_url'], $params['fifu_slider_list_url'], $params['fifu_slider_list_alt']);
        } elseif ($winner === 'clear_video') {
            self::clear_competing_featured_media($post->ID, 'image');
            fifu_update_or_delete($post->ID, 'fifu_video_url', '');
            fifu_update_or_delete($post->ID, 'fifu_custom_video_url', '');
        } elseif ($winner === 'clear_image') {
            self::clear_competing_featured_media($post->ID, 'video');
            fifu_update_or_delete($post->ID, 'fifu_image_url', '');
            fifu_update_or_delete_value($post->ID, 'fifu_image_alt', '');
        } elseif ($winner === 'clear_slider') {
            self::clear_competing_featured_media($post->ID, 'image');
            fifu_update_or_delete($post->ID, 'fifu_slider_list_url', '');
            fifu_update_or_delete_value($post->ID, 'fifu_slider_list_alt', '');
        }

        if ($hasImageAltPayload && !array_key_exists('fifu_image_alt', $params)) {
            $imageAltForPersistence = '';
        }

        $asin = null;
        if (array_key_exists('fifu_asin', $params)) {
            $rawAsin = (string) $params['fifu_asin'];
            $asin = self::normalize_rest_asin_value($rawAsin);
            if ($asin !== '' && preg_match('/<[^>]+>/', $rawAsin) === 1) {
                $asin = str_replace('-', '', $asin);
            }
            $params['fifu_asin'] = $asin;
        } elseif (array_key_exists('fifu_asin', $meta) && is_string($meta['fifu_asin'])) {
            $rawAsin = $meta['fifu_asin'];
            $asin = self::normalize_rest_asin_value($rawAsin);
            if ($asin !== '' && preg_match('/<[^>]+>/', $rawAsin) === 1) {
                $asin = str_replace('-', '', $asin);
            }
            $params['fifu_asin'] = $asin;
        }

        $hasTopLevelFinder = array_key_exists('fifu_finder_url', $params);
        $hasMetaFinder = array_key_exists('fifu_finder_url', $meta);
        $finderUrl = null;
        if ($hasTopLevelFinder) {
            $finderUrl = $params['fifu_finder_url'];
        } elseif ($hasMetaFinder) {
            $finderUrl = $meta['fifu_finder_url'];
        }
        if ($hasTopLevelFinder || $hasMetaFinder) {
            if (is_string($finderUrl)) {
                $finderUrl = trim($finderUrl);
            } elseif ($finderUrl === null) {
                $finderUrl = '';
            } else {
                $finderUrl = trim((string) $finderUrl);
            }
            $params['fifu_finder_url'] = $finderUrl;
        }

        $hasRedirectionUrl = array_key_exists('fifu_redirection_url', $params);
        $redirectionUrl = $hasRedirectionUrl ? $params['fifu_redirection_url'] : null;

        if (!$hasRedirectionUrl) {
            if (is_array($meta) && array_key_exists('fifu_redirection_url', $meta)) {
                $hasRedirectionUrl = true;
                $redirectionUrl = $meta['fifu_redirection_url'];
            }
        }

        if ($hasRedirectionUrl) {
            $params['fifu_redirection_url'] = $redirectionUrl;
        }

        $previousPost = $_POST;
        $_POST = array_merge((array) $_POST, $params);
        if (!isset($_POST['fifu_input_url']) && $imageUrlForPersistence !== null) {
            $_POST['fifu_input_url'] = $imageUrlForPersistence;
        }
        try {
            Fifu_Post_Save_Service::save_from_editor($post->ID, $params, false);
        } finally {
            $_POST = $previousPost;
        }

        if (!$imageUrlAlreadyHandled && $sliderListUrl === null && array_key_exists('fifu_image_url', $params)) {
            $service = function_exists('fifu_db2_write_service') ? fifu_db2_write_service() : null;
            if ($service instanceof Fifu_Db2_Write_Service && is_string($params['fifu_image_url']) && trim($params['fifu_image_url']) !== '') {
                $service->save_post_image($post->ID, trim($params['fifu_image_url']));
            }
            fifu_update_or_delete($post->ID, 'fifu_image_url', $params['fifu_image_url']);
        }
        if (!$canonicalImageNoop && $sliderListUrl === null && $hasImageAltPayload) {
            fifu_update_or_delete_value(
                $post->ID,
                'fifu_image_alt',
                $imageAltForPersistence ?? ''
            );
        }
        if ($sliderListUrl === null && array_key_exists('fifu_video_url', $params)) {
            $normalizedVideoUrl = trim((string) $params['fifu_video_url']);
            fifu_update_or_delete(
                $post->ID,
                'fifu_video_url',
                $normalizedVideoUrl === '' ? '' : self::sanitize_rest_url_value($normalizedVideoUrl)
            );
        }
        if ($sliderListUrl === null && (array_key_exists('fifu_image_url', $params) || array_key_exists('fifu_video_url', $params))) {
            Fifu_Post_Attachment_Sync_Service::sync_featured_attachment($post->ID);
        }
        if ($winner === 'slider' && $sliderListUrl !== null && trim((string) $sliderListUrl) !== '') {
            Fifu_Post_Attachment_Sync_Service::sync_featured_attachment($post->ID);
        }
        if (!$canonicalImageNoop && $winner === 'image' && $imageUrlForPersistence !== '' && $hasImageAltPayload) {
            fifu_update_or_delete_value(
                $post->ID,
                'fifu_image_alt',
                $imageAltForPersistence ?? ''
            );
            Fifu_Post_Attachment_Sync_Service::sync_featured_attachment($post->ID);
        }
        if ($winner === 'image' && $imageUrlForPersistence !== '' && function_exists('fifu_db2_manager')) {
            $manager = fifu_db2_manager();
            if ($manager instanceof Fifu_Db2_Manager) {
                $manager->clearKeyCache();
            }
        }
        if ($winner === 'image' && trim((string) ($params['fifu_image_url'] ?? '')) === '') {
            fifu_update_or_delete_value($post->ID, 'fifu_image_alt', '');
        }

        if ($sliderListUrl === null && $customVideoPersistence !== null) {
            [$customVideoUrl, $posterUrl] = $customVideoPersistence;
            $customVideoUrl = $customVideoUrl !== '' ? self::sanitize_rest_url_value($customVideoUrl) : '';
            $posterUrl = $posterUrl !== '' ? self::sanitize_rest_url_value($posterUrl) : '';

            fifu_update_or_delete($post->ID, 'fifu_custom_video_url', $customVideoUrl);
            fifu_delete_post_meta($post->ID, 'fifu_video_url');
            Fifu_Post_Attachment_Sync_Service::sync_featured_attachment($post->ID);
        }

        if ($sliderListUrl === null) {
            $sliderIndex = 0;
            $wroteSlider = false;
            while (array_key_exists('fifu_slider_image_url_' . $sliderIndex, $params)) {
                $rawSliderImageUrl = trim((string) $params['fifu_slider_image_url_' . $sliderIndex]);
                if ($rawSliderImageUrl !== '') {
                    $sliderImageUrl = esc_url_raw($rawSliderImageUrl);
                    if ($sliderImageUrl !== '') {
                        fifu_update_or_delete($post->ID, 'fifu_slider_image_url_' . $sliderIndex, $sliderImageUrl);
                        if (array_key_exists('fifu_slider_image_alt_' . $sliderIndex, $params)) {
                            fifu_update_or_delete_value(
                                $post->ID,
                                'fifu_slider_image_alt_' . $sliderIndex,
                                self::normalize_slider_alt_value($params['fifu_slider_image_alt_' . $sliderIndex])
                            );
                        }
                        $wroteSlider = true;
                    }
                }
                $sliderIndex++;
            }
            if ($wroteSlider) {
                Fifu_Post_Attachment_Sync_Service::sync_featured_attachment($post->ID);
            }
        }

        if ($asin !== null) {
            fifu_update_or_delete_value($post->ID, 'fifu_asin', $asin);
        }
        if ($finderUrl || $finderUrl === '') {
            fifu_update_or_delete($post->ID, 'fifu_finder_url', $finderUrl);
        }
        if ($redirectionUrl || $redirectionUrl === '') {
            fifu_update_or_delete($post->ID, 'fifu_redirection_url', $redirectionUrl);
        }
    }

    /**
     * Check whether a top-level REST parameter is present, including empty strings.
     *
     * @param WP_REST_Request $request
     * @param string          $key
     * @return bool
     */
    private static function has_top_level_param($request, string $key): bool
    {
        if (is_object($request) && method_exists($request, 'offsetExists')) {
            return $request->offsetExists($key);
        }

        return array_key_exists($key, $request->get_params());
    }

    private static function get_top_level_or_makecom_param(array $params, array $meta, string $key): ?string
    {
        if (array_key_exists($key, $params)) {
            return is_string($params[$key]) ? trim($params[$key]) : null;
        }

        if (array_key_exists($key, $meta) && is_string($meta[$key])) {
            return trim($meta[$key]);
        }

        return null;
    }

    private static function should_prefer_makecom_video_payload(array $params, array $meta): bool
    {
        $hasTopLevelImage = array_key_exists('fifu_image_url', $params);
        $hasTopLevelVideo = array_key_exists('fifu_video_url', $params);

        if ($hasTopLevelImage || $hasTopLevelVideo) {
            return false;
        }

        if (!array_key_exists('fifu_image_url', $meta) || !array_key_exists('fifu_video_url', $meta)) {
            return false;
        }

        if (!is_string($meta['fifu_video_url'])) {
            return false;
        }

        return trim($meta['fifu_video_url']) !== '';
    }

    private static function normalize_rest_alt_value($value): string
    {
        if ($value === null) {
            return '';
        }

        $value = trim((string) $value);
        if ($value === '') {
            return '';
        }

        if (preg_match('/^(null|undefined|http:\/\/null|https:\/\/null)$/i', $value) === 1) {
            return '';
        }

        $value = sanitize_text_field($value);
        $value = trim($value);
        if ($value === '') {
            return '';
        }

        if (preg_match('/^(null|undefined|http:\/\/null|https:\/\/null)$/i', $value) === 1) {
            return '';
        }

        return $value;
    }

    private static function normalize_rest_asin_value($value): string
    {
        $value = trim((string) $value);

        if ($value === '') {
            return '';
        }

        if (function_exists('wp_strip_all_tags')) {
            $value = (string) wp_strip_all_tags($value);
        } else {
            $value = strip_tags($value);
        }

        $value = trim((string) $value);

        if ($value === '') {
            return '';
        }

        return $value;
    }

    private static function sanitize_rest_url_value(string $url): string
    {
        return esc_url_raw(sanitize_url(trim($url)));
    }

    private static function resolve_rest_featured_media_winner(
        bool $hasImagePayload,
        string $trimmedImageUrl,
        bool $hasVideoPayload,
        string $trimmedVideoUrl,
        bool $hasSliderPayload,
        string $trimmedSliderListUrl,
        bool $preferVideoWhenBoth = false
    ): ?string {
        if ($hasSliderPayload && $trimmedSliderListUrl !== '') {
            return 'slider';
        }

        $videoCandidate = null;
        if ($hasVideoPayload && $trimmedVideoUrl !== '') {
            $videoCandidate = self::is_explicit_custom_video_payload($trimmedVideoUrl) ? 'custom_video' : 'video';
        }

        $hasImage = $hasImagePayload && $trimmedImageUrl !== '';
        $hasVideo = $videoCandidate !== null;

        if ($hasImage && $hasVideo) {
            if ($preferVideoWhenBoth || self::is_videos_before_on()) {
                return $videoCandidate;
            }

            return 'image';
        }

        if ($hasVideo) {
            return $videoCandidate;
        }

        if ($hasImage) {
            return 'image';
        }

        if ($hasVideoPayload && $trimmedVideoUrl === '') {
            return 'clear_video';
        }

        if ($hasImagePayload && $trimmedImageUrl === '') {
            return 'clear_image';
        }

        if ($hasSliderPayload && $trimmedSliderListUrl === '') {
            return 'clear_slider';
        }

        return null;
    }

    private static function is_videos_before_on(): bool
    {
        if (!class_exists('Fifu_Options_Utils', false) || !method_exists('Fifu_Options_Utils', 'is_on')) {
            return false;
        }

        return (bool) Fifu_Options_Utils::is_on('fifu_videos_before');
    }

    /**
     * Split legacy custom video payloads in the form video\poster.
     *
     * @param string $rawValue
     * @return array{0:string,1:string}
     */
    private static function split_custom_video_payload(string $rawValue): array
    {
        $rawValue = trim($rawValue);
        if (strpos($rawValue, '\\') === false) {
            return [$rawValue, ''];
        }

        [$videoUrl, $posterUrl] = array_pad(explode('\\', $rawValue, 2), 2, '');

        return [
            trim((string) $videoUrl),
            trim((string) $posterUrl),
        ];
    }

    private static function is_explicit_custom_video_payload(string $rawValue): bool
    {
        if (strpos($rawValue, '\\') === false) {
            return false;
        }

        [$videoUrl, $posterUrl] = array_pad(explode('\\', $rawValue, 2), 2, '');
        return trim((string) $videoUrl) !== '' && trim((string) $posterUrl) !== '';
    }

    private static function has_competing_rest_featured_media_payload(array $params, array $meta): bool
    {
        $keys = array_unique(array_merge(array_keys($params), array_keys($meta)));
        $exactKeys = [
            'fifu_video_url',
            'fifu_custom_video_url',
            'fifu_slider_list_url',
            'fifu_slider_list_alt',
            'fifu_video_input_url',
            'fifu_video_captured_frame',
            'fifu_video_time_frame',
            'inputHiddenVideoLength',
            'inputHiddenVideoListIds',
            'inputHiddenSliderLength',
            'inputHiddenSliderListIds',
        ];
        $prefixes = [
            'fifu_video_',
            'fifu_slider_',
            'fifu_image_url_',
            'fifu_image_alt_',
            'fifu_image_ifm_',
            'fifu_input_url_',
            'fifu_input_alt_',
            'fifu_input_ifm_',
        ];

        foreach ($keys as $key) {
            if (!is_string($key)) {
                return true;
            }

            if (in_array($key, $exactKeys, true)) {
                return true;
            }

            foreach ($prefixes as $prefix) {
                if (strpos($key, $prefix) === 0) {
                    return true;
                }
            }
        }

        return false;
    }

    private static function is_exact_canonical_simple_rest_image_state(
        int $postId,
        string $expectedUrl,
        string $expectedAlt
    ): bool {
        $manager = function_exists('fifu_db2_manager')
            ? fifu_db2_manager()
            : null;
        if (
            !$manager instanceof Fifu_Db2_Manager
            || !method_exists($manager, 'getPostMappings')
            || !method_exists($manager, 'getPostAltMappings')
        ) {
            return false;
        }

        try {
            $imageMappings = $manager->getPostMappings($postId, 'image');
            if (!is_array($imageMappings) || count($imageMappings) !== 1) {
                return false;
            }

            $imageMapping = reset($imageMappings);
            if (
                !is_array($imageMapping)
                || (int) ($imageMapping['key_index'] ?? -1) !== 0
                || self::sanitize_rest_url_value((string) ($imageMapping['url'] ?? '')) !== $expectedUrl
            ) {
                return false;
            }

            $imageAltMappings = $manager->getPostAltMappings($postId, 'image');
            if (!is_array($imageAltMappings)) {
                return false;
            }

            if ($expectedAlt === '') {
                if ($imageAltMappings !== []) {
                    return false;
                }
            } else {
                if (count($imageAltMappings) !== 1) {
                    return false;
                }

                $imageAltMapping = reset($imageAltMappings);
                if (
                    !is_array($imageAltMapping)
                    || (int) ($imageAltMapping['key_index'] ?? -1) !== 0
                    || (string) ($imageAltMapping['alt'] ?? $imageAltMapping['value'] ?? '') !== $expectedAlt
                ) {
                    return false;
                }
            }

            foreach (['video', 'custom_video', 'slider'] as $keyType) {
                $mappings = $manager->getPostMappings($postId, $keyType);
                if (!is_array($mappings) || $mappings !== []) {
                    return false;
                }
            }
        } catch (\Throwable $e) {
            return false;
        }

        return !self::has_rest_image_legacy_cleanup_debt($postId);
    }

    private static function has_rest_image_legacy_cleanup_debt(int $postId): bool
    {
        $meta = get_post_meta($postId);
        if (!is_array($meta)) {
            return true;
        }

        $exactKeys = [
            'fifu_image_url',
            'fifu_image_alt',
            'fifu_video_url',
            'fifu_custom_video_url',
            'fifu_list_url',
            'fifu_list_alt',
            'fifu_list_video_url',
            'fifu_slider_list_url',
            'fifu_slider_list_alt',
        ];
        $prefixes = [
            'fifu_image_url_',
            'fifu_image_alt_',
            'fifu_image_ifm_',
            'fifu_video_url_',
            'fifu_slider_image_url_',
            'fifu_slider_image_alt_',
        ];

        foreach (array_keys($meta) as $key) {
            if (in_array($key, $exactKeys, true)) {
                return true;
            }

            foreach ($prefixes as $prefix) {
                if (strpos($key, $prefix) === 0) {
                    return true;
                }
            }
        }

        return false;
    }

    private static function clear_db2_image_gallery_state(int $postId): void
    {
        $manager = function_exists('fifu_db2_manager')
            ? fifu_db2_manager()
            : null;
        if (
            !$manager instanceof Fifu_Db2_Manager
            || !method_exists($manager, 'getPostMappings')
            || !method_exists($manager, 'getPostAltMappings')
            || !method_exists($manager, 'deletePostMappings')
            || !method_exists($manager, 'deletePostAltMappings')
        ) {
            return;
        }

        try {
            $mappings = $manager->getPostMappings($postId, 'image');
            if (is_array($mappings)) {
                foreach ($mappings as $mapping) {
                    if (!is_array($mapping) || !isset($mapping['key_index'])) {
                        continue;
                    }

                    $index = (int) $mapping['key_index'];
                    if ($index > 0) {
                        $manager->deletePostMappings($postId, 'image', $index);
                    }
                }
            }

            $altMappings = $manager->getPostAltMappings($postId, 'image');
            if (!is_array($altMappings)) {
                return;
            }

            foreach ($altMappings as $mapping) {
                if (!is_array($mapping) || !isset($mapping['key_index'])) {
                    continue;
                }

                $index = (int) $mapping['key_index'];
                if ($index > 0) {
                    $manager->deletePostAltMappings($postId, 'image', $index);
                }
            }
        } catch (\Throwable $e) {
            return;
        }
    }

    private static function clear_legacy_image_gallery_meta_state(int $postId): void
    {
        $meta = get_post_meta($postId);
        if (!is_array($meta)) {
            return;
        }

        foreach (array_keys($meta) as $metaKey) {
            if (
                !is_string($metaKey)
                || preg_match('/^fifu_image_(?:url|alt)_\d+$/', $metaKey) !== 1
            ) {
                continue;
            }

            delete_post_meta($postId, $metaKey);
        }
    }

    private static function clear_competing_featured_media(int $postId, string $keep): void
    {
        if ($keep !== 'image') {
            fifu_update_or_delete($postId, 'fifu_image_url', '');
            fifu_update_or_delete_value($postId, 'fifu_image_alt', '');
        }
        if ($keep !== 'video') {
            fifu_update_or_delete($postId, 'fifu_video_url', '');
        }
        if ($keep !== 'custom_video') {
            fifu_update_or_delete($postId, 'fifu_custom_video_url', '');
        }
        if ($keep !== 'slider') {
            fifu_update_or_delete($postId, 'fifu_slider_list_url', '');
            fifu_update_or_delete_value($postId, 'fifu_slider_list_alt', '');
            $index = 0;
            while (self::has_post_meta_key($postId, 'fifu_slider_image_url_' . $index) || self::has_post_meta_key($postId, 'fifu_slider_image_alt_' . $index)) {
                fifu_delete_post_meta($postId, 'fifu_slider_image_url_' . $index);
                fifu_delete_post_meta($postId, 'fifu_slider_image_alt_' . $index);
                $index++;
            }
        }
    }

    private static function has_post_meta_key(int $postId, string $key): bool
    {
        if (function_exists('metadata_exists')) {
            return metadata_exists('post', $postId, $key);
        }

        if (!function_exists('get_post_meta')) {
            return false;
        }

        return get_post_meta($postId, $key, true) !== '';
    }

    private static function write_slider_list_entries(int $postId, string $sliderListUrl, ?string $sliderListAlt = null): void
    {
        $altParts = $sliderListAlt !== null ? explode('|', $sliderListAlt) : [];
        $targetIndex = 0;

        foreach (explode('|', $sliderListUrl) as $sourceIndex => $part) {
            $url = trim((string) $part);
            if ($url === '') {
                continue;
            }

            fifu_update_or_delete(
                $postId,
                'fifu_slider_image_url_' . $targetIndex,
                self::sanitize_rest_url_value($url)
            );

            if ($sliderListAlt !== null) {
                fifu_update_or_delete_value(
                    $postId,
                    'fifu_slider_image_alt_' . $targetIndex,
                    self::normalize_slider_alt_value($altParts[$sourceIndex] ?? '')
                );
            }

            $targetIndex++;
        }

        self::clear_stale_slider_list_entries($postId, $targetIndex);
        fifu_update_or_delete_value($postId, 'fifu_slider_list_alt', $sliderListAlt === null ? '' : $sliderListAlt);
    }

    private static function clear_existing_slider_list_state(int $postId): void
    {
        fifu_update_or_delete_value($postId, 'fifu_slider_list_alt', '');
        self::clear_stale_slider_list_entries($postId, 0);
    }

    private static function clear_stale_slider_list_entries(int $postId, int $startIndex): void
    {
        $meta = get_post_meta($postId);
        if (!is_array($meta) || $meta === []) {
            return;
        }

        foreach (array_keys($meta) as $metaKey) {
            if (!is_string($metaKey)) {
                continue;
            }

            if (preg_match('/^fifu_slider_image_(?:url|alt)_(\d+)$/', $metaKey) !== 1) {
                continue;
            }

            $index = (int) preg_replace('/^.*_(\d+)$/', '$1', $metaKey);
            if ($index < $startIndex) {
                continue;
            }

            fifu_delete_post_meta($postId, 'fifu_slider_image_url_' . $index);
            fifu_delete_post_meta($postId, 'fifu_slider_image_alt_' . $index);
        }
    }

    /**
     * Normalize slider alt text so invalid sentinels are not persisted.
     *
     * @param mixed $value
     * @return string
     */
    private static function normalize_slider_alt_value($value): string
    {
        if ($value === null) {
            return '';
        }

        $raw = trim((string) $value);
        if ($raw === '') {
            return '';
        }

        $normalized = strtolower($raw);
        if (
            $normalized === 'null'
            || $normalized === 'undefined'
            || $normalized === 'http://null'
            || $normalized === 'https://null'
        ) {
            return '';
        }

        return wp_strip_all_tags((string) $value);
    }
}
