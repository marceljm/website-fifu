<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

final class Fifu_Woocommerce_Rest_Integration
{
    /** @var array<int,true> */
    private static array $pendingParentTmpGalleryCleanup = [];

    public static function register_hooks(): void
    {
        add_action(
            'woocommerce_rest_insert_product_object',
            [self::class, 'on_product_rest_save'],
            10,
            3
        );

        add_action(
            'woocommerce_rest_insert_product_variation_object',
            [self::class, 'on_product_rest_save'],
            10,
            3
        );

        add_action(
            'woocommerce_after_product_object_save',
            [self::class, 'on_after_product_object_save'],
            10,
            1
        );

        add_action(
            'woocommerce_rest_insert_product_cat',
            [self::class, 'on_product_cat_rest_save'],
            10,
            2
        );
    }

    /**
     * Handles WooCommerce REST product insert/update.
     * It will eventually replace fifu_save_product().
     *
     * @param WC_Product $product
     * @param WP_REST_Request $request
     * @param bool $creating
     */
    public static function on_product_rest_save(
        WC_Product $product,
        WP_REST_Request $request,
        bool $creating
    ): void {
        $postId = $product->get_id();
        $postType = (string) get_post_type($postId);
        $metaData = self::get_rest_meta_data_payload($request, $product);
        $presentFifuMetaKeys = [];
        $hasFeaturedImageUrl = false;
        $hasFeaturedVideoUrl = false;
        $hasImageListAlt = false;
        $hasSliderListAlt = false;
        $hasImageListUrl = false;
        $hasSliderListUrl = false;
        $hasVideoListUrl = false;
        $hasListUrlStructureChange = false;
        $hasListAltChange = false;
        $hasSliderListAltChange = false;
        $shouldSplitLists = false;
        $rawImageListAlt = null;
        $rawSliderListAlt = null;
        $rawImageListUrl = null;
        $rawSliderListUrl = null;
        $rawVideoUrls = null;
        $featuredImageUrlValue = null;
        $featuredImageDb2Synced = false;
        $oldImageListUrl = null;
        $oldImageListAlt = null;
        $hasFeaturedMediaChange = false;
        $hasListMediaChange = false;
        $hasAnyMediaChange = false;

        foreach ($metaData as $data) {
            $metaKey = null;
            $metaValue = null;

            if (is_array($data)) {
                $metaKey = isset($data['key']) ? (string) $data['key'] : null;
                $metaValue = $data['value'] ?? null;
            } elseif (is_object($data)) {
                $metaKey = isset($data->key) ? (string) $data->key : null;
                $metaValue = $data->value ?? null;
            }

            if ($metaKey === null) {
                continue;
            }

            if (self::should_ignore_product_rest_fifu_meta_key($postType, $metaKey)) {
                continue;
            }

            if (self::is_fifu_rest_meta_key($metaKey)) {
                $presentFifuMetaKeys[$metaKey] = true;
            }

            switch ($metaKey) {
                case 'fifu_image_url':
                    $hasFeaturedImageUrl = true;
                    $featuredImageUrlValue = is_string($metaValue) ? trim($metaValue) : null;
                    $featuredImageDb2Synced = FIFU_Post_Meta_Updater::instance()
                        ->update_or_delete_with_status($postId, $metaKey, $metaValue);
                    $hasFeaturedMediaChange = true;
                    $hasAnyMediaChange = true;
                    break;
                case 'fifu_video_url':
                    $hasFeaturedVideoUrl = true;
                    FIFU_Post_Meta_Updater::instance()->update_or_delete($postId, $metaKey, $metaValue);
                    self::mirror_rest_meta($postId, $metaKey, $metaValue);
                    $hasFeaturedMediaChange = true;
                    $hasAnyMediaChange = true;
                    break;
                case 'fifu_list_alt':
                    $hasImageListAlt = true;
                    $hasListAltChange = true;
                    $rawImageListAlt = self::normalize_slider_alt_pipe_list($metaValue);
                    $hasAnyMediaChange = true;
                    break;
                case 'fifu_slider_list_alt':
                    $hasSliderListAlt = true;
                    $hasSliderListAltChange = true;
                    $rawSliderListAlt = self::normalize_slider_alt_pipe_list($metaValue);
                    $hasAnyMediaChange = true;
                    break;
                case 'fifu_list_url':
                    $hasImageListUrl = true;
                    $hasListUrlStructureChange = true;
                    $rawImageListUrl = $metaValue;
                    $hasListMediaChange = true;
                    $shouldSplitLists = true;
                    $hasAnyMediaChange = true;
                    break;
                case 'fifu_slider_list_url':
                    $hasSliderListUrl = true;
                    $hasListUrlStructureChange = true;
                    $rawSliderListUrl = $metaValue;
                    $hasListMediaChange = true;
                    $shouldSplitLists = true;
                    $hasAnyMediaChange = true;
                    break;
                case 'fifu_list_video_url':
                    $hasVideoListUrl = true;
                    $hasListUrlStructureChange = true;
                    $rawVideoUrls = $metaValue;
                    $hasListMediaChange = true;
                    $shouldSplitLists = true;
                    $hasAnyMediaChange = true;
                    break;
                default:
                    break;
            }
        }

        if ($presentFifuMetaKeys === []) {
            $hasFeaturedMediaChange = false;
            $hasListMediaChange = false;
            $hasAnyMediaChange = false;
        }

        if ($hasImageListUrl || $hasImageListAlt) {
            if (class_exists('Fifu_Post_Image_List_Url_Read_Service', false)) {
                $oldImageListUrl = Fifu_Post_Image_List_Url_Read_Service::get_image_list_url($postId);
            }
            if (class_exists('Fifu_Post_Image_List_Alt_Read_Service', false)) {
                $oldImageListAlt = Fifu_Post_Image_List_Alt_Read_Service::get_image_list_alt($postId);
            }
        }

        if ($hasFeaturedImageUrl && self::has_non_empty_string($featuredImageUrlValue)) {
            self::clear_rest_media_state_for_featured_image_replacement($postId);
            $hasFeaturedVideoUrl = false;
            $hasImageListAlt = false;
            $hasSliderListAlt = false;
            $hasImageListUrl = false;
            $hasSliderListUrl = false;
            $hasVideoListUrl = false;
            $rawImageListAlt = null;
            $rawSliderListAlt = null;
            $rawImageListUrl = null;
            $rawSliderListUrl = null;
            $rawVideoUrls = null;
            $hasListMediaChange = true;
            $shouldSplitLists = true;
            $hasAnyMediaChange = true;
        }

        if (
            !$hasListUrlStructureChange
            && ($hasImageListAlt || $hasSliderListAlt)
        ) {
            $shouldSplitLists = false;
        }

        $effectiveListChannels = self::resolve_effective_list_channels(
            is_string($rawImageListUrl) ? $rawImageListUrl : null,
            is_string($rawImageListAlt) ? $rawImageListAlt : null,
            is_string($rawSliderListUrl) ? $rawSliderListUrl : null,
            is_string($rawSliderListAlt) ? $rawSliderListAlt : null
        );

        $effectiveImageListUrl = $effectiveListChannels['imageListUrl'];
        $effectiveImageListAlt = $effectiveListChannels['imageListAlt'];
        $effectiveSliderListUrl = $effectiveListChannels['sliderListUrl'];
        $effectiveSliderListAlt = $effectiveListChannels['sliderListAlt'];
        $isSlider = $effectiveListChannels['isSlider'];
        $imageListFieldsOverriddenBySlider = $isSlider && ($hasImageListUrl || $hasImageListAlt);
        $imageListAltOverriddenBySlider = $isSlider && $hasImageListAlt;

        if ($hasImageListUrl && $hasImageListAlt) {
            $effectiveImageListAlt = self::normalize_alt_pipe_list_for_url_list(
                $effectiveImageListAlt,
                $effectiveImageListUrl
            );
        }

        if ($hasSliderListUrl && $hasSliderListAlt) {
            $effectiveSliderListAlt = self::normalize_alt_pipe_list_for_url_list(
                $effectiveSliderListAlt,
                $effectiveSliderListUrl
            );
        }

        $imageListUrlDb2Confirmed = false;
        $imageListAltDb2Confirmed = false;
        $sliderListUrlDb2Confirmed = false;
        $sliderListAltDb2Confirmed = false;
        $videoListDb2Confirmed = false;
        $imageListAltOnlyDb2Confirmed = false;

        if ($hasImageListUrl) {
            $imageListUrlDb2Confirmed = self::persist_rest_list_meta($postId, 'fifu_list_url', $effectiveImageListUrl);
        }

        if ($hasSliderListUrl) {
            $sliderListUrlDb2Confirmed = self::persist_rest_list_meta($postId, 'fifu_slider_list_url', $effectiveSliderListUrl);
        }

        if ($hasSliderListAlt) {
            $sliderListAltDb2Confirmed = self::persist_rest_list_meta(
                $postId,
                'fifu_slider_list_alt',
                $effectiveSliderListAlt,
                true
            );
        }

        if ($hasVideoListUrl) {
            $videoListDb2Confirmed = self::persist_rest_video_list_meta(
                $postId,
                is_string($rawVideoUrls) ? $rawVideoUrls : null
            );
        }

        if (!$imageListFieldsOverriddenBySlider) {
            if ($postType === 'product' && $hasImageListUrl) {
                $imageListMappingSynced = self::sync_rest_product_image_list_mappings(
                    $postId,
                    is_string($effectiveImageListUrl) ? $effectiveImageListUrl : null,
                    is_string($effectiveImageListAlt) ? $effectiveImageListAlt : null
                );

                if ($hasImageListAlt && $imageListMappingSynced) {
                    $imageListAltDb2Confirmed = self::sync_rest_product_image_list_alts_for_existing_mappings(
                        $postId,
                        is_string($effectiveImageListAlt) ? $effectiveImageListAlt : null
                    ) || $imageListAltDb2Confirmed;
                }
            } elseif ($postType === 'product' && $hasImageListAlt) {
                $imageListAltDb2Confirmed = self::sync_rest_product_image_list_alts_for_existing_mappings(
                    $postId,
                    is_string($effectiveImageListAlt) ? $effectiveImageListAlt : null
                ) || $imageListAltDb2Confirmed;
            }
        }

        if ($hasImageListAlt) {
            $imageListAltBridgeConfirmed = self::persist_rest_list_meta(
                $postId,
                'fifu_list_alt',
                $effectiveImageListAlt,
                true
            );

            if ($imageListAltOverriddenBySlider) {
                $imageListAltDb2Confirmed = $imageListAltBridgeConfirmed;
            } else {
                $imageListAltDb2Confirmed = $imageListAltDb2Confirmed && $imageListAltBridgeConfirmed;
            }
        }
        $hasUnconfirmedImageListAlt = $hasImageListAlt
            && !$imageListAltOverriddenBySlider
            && !$imageListAltDb2Confirmed;

        if ($hasImageListUrl && !$hasImageListAlt) {
            $oldNormalized = self::normalize_pipe_list($oldImageListUrl);
            $newNormalized = self::normalize_pipe_list($effectiveImageListUrl);
            if ($oldImageListAlt !== null && $oldNormalized !== $newNormalized) {
                $cleared = self::persist_rest_list_meta($postId, 'fifu_list_alt', null, true);
                $imageListAltDb2Confirmed = $imageListAltDb2Confirmed || $cleared;
            }
        }

        if ($hasImageListUrl && $imageListUrlDb2Confirmed) {
            self::cleanup_legacy_image_list_meta_after_db2_sync(
                $postId,
                $effectiveImageListUrl,
                $imageListAltDb2Confirmed ? $effectiveImageListAlt : null
            );
        }
        if ($hasImageListAlt && !$hasImageListUrl) {
            self::cleanup_legacy_image_list_alt_after_db2_sync(
                $postId,
                $effectiveImageListAlt
            );
        }
        $imageListAltOnlyDb2Confirmed = $hasImageListAlt
            && !$hasImageListUrl
            && $imageListAltDb2Confirmed;
        if ($hasVideoListUrl && $postType === 'product' && $videoListDb2Confirmed) {
            self::cleanup_legacy_video_list_meta_after_db2_sync(
                $postId,
                is_string($rawVideoUrls) ? $rawVideoUrls : null
            );
        }
        if ($hasSliderListUrl || $hasSliderListAlt) {
            self::cleanup_legacy_slider_list_meta_after_db2_sync(
                $postId,
                $effectiveSliderListUrl,
                $effectiveSliderListAlt
            );
        }
        if ($hasSliderListUrl) {
            self::cleanup_legacy_image_list_helpers_after_slider_db2_sync($postId);
        }

        if ($postType === 'product') {
            self::cleanup_stale_product_legacy_meta_after_rest_replacement(
                $postId,
                $hasImageListUrl
                    && !$imageListFieldsOverriddenBySlider
                    && self::db2_raw_confirms_rest_list_value($postId, 'fifu_list_url', $effectiveImageListUrl),
                $hasImageListAlt
                    && !$imageListAltOverriddenBySlider
                    && $imageListAltDb2Confirmed
                    && self::db2_raw_confirms_rest_list_value($postId, 'fifu_list_alt', $effectiveImageListAlt, true),
                $hasVideoListUrl
                    && $videoListDb2Confirmed
                    && self::db2_raw_confirms_rest_list_value(
                        $postId,
                        'fifu_list_video_url',
                        is_string($rawVideoUrls) ? $rawVideoUrls : null
                    ),
                $hasSliderListUrl
                    && $sliderListUrlDb2Confirmed
                    && self::db2_raw_confirms_rest_list_value($postId, 'fifu_slider_list_url', $effectiveSliderListUrl),
                $hasSliderListAlt
                    && $sliderListAltDb2Confirmed
                    && self::db2_raw_confirms_rest_list_value($postId, 'fifu_slider_list_alt', $effectiveSliderListAlt, true)
            );

            self::cleanup_confirmed_product_legacy_media_meta(
                $postId,
                $hasUnconfirmedImageListAlt ? ['fifu_list_alt'] : [],
                !$hasVideoListUrl
            );
        }

        clean_post_cache($postId);
        $tmpProductImageGallerySnapshot = trim((string) get_post_meta($postId, 'fifu_tmp_product_image_gallery', true));
        $hasTmpProductImageGallerySnapshot = $tmpProductImageGallerySnapshot !== '';

        if ($postType === 'product') {
            if ($hasFeaturedMediaChange || $hasListMediaChange || $imageListAltOnlyDb2Confirmed) {
                clean_post_cache($postId);
                Fifu_Post_Attachment_Sync_Service::sync_featured_attachment($postId);
            }

            if ($shouldSplitLists && $hasListUrlStructureChange && !$hasUnconfirmedImageListAlt) {
                clean_post_cache($postId);
                $shouldSplitSliderList = !($hasSliderListUrl || $hasSliderListAlt);

                $waiRequestKeys = [
                    'fifu_wai_image_list_url',
                    'fifu_wai_image_list_alt',
                    'fifu_wai_video_list_url',
                ];

                $waiRequestSnapshot = [];
                foreach ($waiRequestKeys as $waiRequestKey) {
                    $waiRequestSnapshot[$waiRequestKey] = [
                        'exists' => array_key_exists($waiRequestKey, $_REQUEST),
                        'value' => $_REQUEST[$waiRequestKey] ?? null,
                    ];
                }

                if ($hasImageListUrl) {
                    $_REQUEST['fifu_wai_image_list_url'] = (string) ($effectiveImageListUrl ?? '');
                }

                if ($hasImageListAlt) {
                    $_REQUEST['fifu_wai_image_list_alt'] = (string) ($effectiveImageListAlt ?? '');
                }

                if ($hasVideoListUrl) {
                    $_REQUEST['fifu_wai_video_list_url'] = is_scalar($rawVideoUrls)
                        ? (string) $rawVideoUrls
                        : '';
                }

                try {
                    Fifu_Wai_Meta_Service::split_lists($postId, $shouldSplitSliderList);
                } finally {
                    foreach ($waiRequestSnapshot as $waiRequestKey => $snapshot) {
                        if (!empty($snapshot['exists'])) {
                            $_REQUEST[$waiRequestKey] = $snapshot['value'];
                        } else {
                            unset($_REQUEST[$waiRequestKey]);
                        }
                    }
                }
            } elseif ($hasUnconfirmedImageListAlt) {
                clean_post_cache($postId);
            } elseif ($hasListAltChange || $hasSliderListAltChange) {
                clean_post_cache($postId);
            }

            if (
                $hasImageListUrl
                || $hasSliderListUrl
                || $hasVideoListUrl
                || $hasFeaturedMediaChange
                || $imageListAltOnlyDb2Confirmed
            ) {
                clean_post_cache($postId);
                Fifu_Post_Attachment_Sync_Service::sync_gallery_attachments($postId);
                Fifu_Post_Attachment_Sync_Service::sync_theme_property_images($postId);
            } elseif ($hasTmpProductImageGallerySnapshot) {
                clean_post_cache($postId);
                Fifu_Post_Attachment_Sync_Service::sync_gallery_attachments($postId);
            }

            return;
        }

        $urlsArray = self::parse_pipe_list_to_array(
            $isSlider ? $effectiveSliderListUrl : $effectiveImageListUrl
        );
        $variationImageListAlt = $isSlider ? $effectiveSliderListAlt : $effectiveImageListAlt;
        $altsArray = self::parse_pipe_alt_list_preserving_indexes($variationImageListAlt);
        $videoUrlsArray = self::parse_pipe_list_to_array($rawVideoUrls);
        $hasTrailingUrlPlaceholders = is_string($rawImageListUrl) && trim($rawImageListUrl) !== '' && preg_match('/\|+\s*$/', trim($rawImageListUrl)) === 1;
        if ($urlsArray && !$hasTrailingUrlPlaceholders) {
            $altsArray = array_values(array_slice($altsArray, 0, count($urlsArray)));
        }

        if ($postType === 'product_variation' && $creating) {
            if ($presentFifuMetaKeys !== []) {
                Fifu_Woocommerce_Variation_Hooks::on_variation_insert(
                    $postId,
                    $urlsArray,
                    $altsArray,
                    $isSlider,
                    $videoUrlsArray
                );
            }
            self::schedule_parent_tmp_product_gallery_snapshot_cleanup($postId);
            return;
        }

        if ($postType === 'product_variation') {
            if ($presentFifuMetaKeys !== []) {
                Fifu_Woocommerce_Variation_Hooks::on_variation_update(
                    $postId,
                    $urlsArray,
                    $altsArray,
                    $isSlider,
                    $videoUrlsArray
                );
            }
            self::schedule_parent_tmp_product_gallery_snapshot_cleanup($postId);
        }
    }

    /**
     * @return array<int, array{key:?string,value:mixed}>|array<int, object>
     */
    private static function get_rest_meta_data_payload(
        WP_REST_Request $request,
        WC_Product $product
    ): array
    {
        $params = $request->get_params();
        if (array_key_exists('meta_data', $params) && is_array($params['meta_data'])) {
            return $params['meta_data'];
        }

        if (method_exists($product, 'get_meta_data')) {
            $productMetaData = $product->get_meta_data();
            if (is_array($productMetaData)) {
                return $productMetaData;
            }
        }

        return [];
    }

    private static function is_fifu_rest_meta_key(string $metaKey): bool
    {
        if (preg_match('/^fifu_image_url_\d+$/', $metaKey) === 1) {
            return true;
        }

        if (preg_match('/^fifu_image_alt_\d+$/', $metaKey) === 1) {
            return true;
        }

        if (preg_match('/^fifu_video_url_\d+$/', $metaKey) === 1) {
            return true;
        }

        if (preg_match('/^fifu_slider_image_url_\d+$/', $metaKey) === 1) {
            return true;
        }

        if (preg_match('/^fifu_slider_image_alt_\d+$/', $metaKey) === 1) {
            return true;
        }

        return in_array($metaKey, [
            'fifu_image_url',
            'fifu_image_alt',
            'fifu_video_url',
            'fifu_custom_video_url',
            'fifu_audio_url',
            'fifu_list_url',
            'fifu_list_alt',
            'fifu_list_video_url',
            'fifu_slider_list_url',
            'fifu_slider_list_alt',
        ], true);
    }

    private static function is_woocommerce_product_rest_post_type(string $postType): bool
    {
        return in_array($postType, ['product', 'product_variation'], true);
    }

    private static function is_supported_product_rest_fifu_meta_key(string $metaKey): bool
    {
        return in_array($metaKey, [
            'fifu_list_url',
            'fifu_list_alt',
            'fifu_list_video_url',
            'fifu_slider_list_url',
            'fifu_slider_list_alt',
        ], true);
    }

    private static function should_ignore_product_rest_fifu_meta_key(string $postType, string $metaKey): bool
    {
        if (!self::is_woocommerce_product_rest_post_type($postType)) {
            return false;
        }

        if (!self::is_fifu_rest_meta_key($metaKey)) {
            return false;
        }

        return !self::is_supported_product_rest_fifu_meta_key($metaKey);
    }

    private static function has_non_empty_string(?string $value): bool
    {
        return $value !== null && trim($value) !== '';
    }

    /**
     * @return array{
     *     imageListUrl:?string,
     *     imageListAlt:?string,
     *     sliderListUrl:?string,
     *     sliderListAlt:?string,
     *     isSlider:bool
     * }
     */
    private static function resolve_effective_list_channels(
        ?string $rawImageListUrl,
        ?string $rawImageListAlt,
        ?string $rawSliderListUrl,
        ?string $rawSliderListAlt
    ): array {
        $effectiveImageListUrl = $rawImageListUrl;
        $effectiveImageListAlt = $rawImageListAlt;
        $effectiveSliderListUrl = $rawSliderListUrl;
        $effectiveSliderListAlt = $rawSliderListAlt;

        if (self::has_non_empty_string($effectiveSliderListUrl)) {
            $effectiveImageListUrl = null;
            $effectiveImageListAlt = null;

            if (!self::has_non_empty_string($effectiveSliderListAlt)) {
                $effectiveSliderListAlt = null;
            }
        }

        return [
            'imageListUrl' => $effectiveImageListUrl,
            'imageListAlt' => $effectiveImageListAlt,
            'sliderListUrl' => $effectiveSliderListUrl,
            'sliderListAlt' => $effectiveSliderListAlt,
            'isSlider' => self::has_non_empty_string($effectiveSliderListUrl),
        ];
    }

    private static function persist_rest_list_meta(
        int $postId,
        string $metaKey,
        ?string $value,
        bool $isAlt = false
    ): bool {
        if (!function_exists('fifu_db2_legacy_write_bridge')) {
            if (!self::is_semantically_empty_rest_value($metaKey, $value, $isAlt)) {
                self::mirror_rest_meta($postId, $metaKey, $value);
            }
            return true;
        }

        $bridge = fifu_db2_legacy_write_bridge();
        if (!$bridge instanceof Fifu_Db2_Legacy_Write_Bridge) {
            if (!self::is_semantically_empty_rest_value($metaKey, $value, $isAlt)) {
                self::mirror_rest_meta($postId, $metaKey, $value);
            }
            return true;
        }

        $bridgeValue = self::resolve_rest_bridge_value($metaKey, $value, $isAlt);
        $isSemanticClear = $bridgeValue === null;

        if (!$isSemanticClear) {
            self::mirror_rest_meta($postId, $metaKey, $value);
        }

        $didSync = $bridge->handle_post_meta_change(
            $postId,
            $metaKey,
            $bridgeValue
        );

        if ($didSync !== true) {
            return false;
        }

        if ($isSemanticClear) {
            if (!self::db2_confirms_rest_list_clear($postId, $metaKey)) {
                return false;
            }

            self::mirror_rest_meta($postId, $metaKey, null);
            return true;
        }

        if (!self::db2_confirms_rest_list_value($postId, $metaKey, $value, $isAlt)) {
            return false;
        }

        self::mirror_rest_meta($postId, $metaKey, $value);
        return true;
    }

    /**
     * @param callable():void $callback
     */
    private static function run_preserving_db2_image_list_for_mixed_media_rest(int $postId, callable $callback): void
    {
        $key = (string) $postId;
        $context = $GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import'] ?? null;
        $hadOld = is_array($context) && array_key_exists($key, $context);
        $old = $hadOld ? $context[$key] : null;

        if (!is_array($context)) {
            $context = [];
        }

        $context[$key] = true;
        $GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import'] = $context;

        try {
            $callback();
        } finally {
            if ($hadOld) {
                $GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import'][$key] = $old;
            } else {
                unset($GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import'][$key]);
            }
        }
    }

    public static function on_after_product_object_save(WC_Product $product): void
    {
        $postId = $product->get_id();
        if ($postId <= 0 || !isset(self::$pendingParentTmpGalleryCleanup[$postId])) {
            return;
        }

        unset(self::$pendingParentTmpGalleryCleanup[$postId]);
        clean_post_cache($postId);
        $tmpProductImageGallerySnapshot = trim((string) get_post_meta($postId, 'fifu_tmp_product_image_gallery', true));
        if ($tmpProductImageGallerySnapshot === '') {
            return;
        }

        clean_post_cache($postId);
        Fifu_Post_Attachment_Sync_Service::sync_gallery_attachments($postId);
    }

    private static function schedule_parent_tmp_product_gallery_snapshot_cleanup(int $variationId): void
    {
        $parentId = (int) wp_get_post_parent_id($variationId);
        if ($parentId <= 0) {
            return;
        }

        self::$pendingParentTmpGalleryCleanup[$parentId] = true;
    }

    /**
     * @param mixed $value
     * @return array<int,string>
     */
    private static function parse_pipe_list_to_array($value): array
    {
        if (!is_string($value) || $value === '') {
            return [];
        }

        $items = array_map('trim', explode('|', $value));
        $items = array_filter(
            $items,
            static fn(string $item): bool => $item !== ''
        );

        return array_values($items);
    }

    /**
     * @param mixed $value
     */
    private static function normalize_slider_alt_segment($value): string
    {
        if ($value === null) {
            return '';
        }

        $normalized = trim((string) $value);
        $normalizedLower = strtolower($normalized);
        if (
            $normalizedLower === ''
            || $normalizedLower === 'null'
            || $normalizedLower === 'undefined'
            || $normalizedLower === 'http://null'
            || $normalizedLower === 'https://null'
        ) {
            return '';
        }

        return wp_strip_all_tags($normalized);
    }

    /**
     * @param mixed $value
     */
    private static function normalize_slider_alt_pipe_list($value): ?string
    {
        if ($value === null) {
            return null;
        }

        $segments = explode('|', (string) $value);
        $segments = array_map(
            static fn($segment): string => self::normalize_slider_alt_segment($segment),
            $segments
        );

        return implode('|', $segments);
    }

    private static function normalize_alt_pipe_list_for_url_list(?string $altList, ?string $urlList): ?string
    {
        if ($altList === null) {
            return null;
        }

        $urls = self::parse_pipe_list_to_array($urlList);
        if ($urls === []) {
            return null;
        }

        $alts = array_map(
            static fn($segment): string => self::normalize_slider_alt_segment($segment),
            explode('|', (string) $altList)
        );
        $alts = array_values(array_slice($alts, 0, count($urls)));
        while (count($alts) < count($urls)) {
            $alts[] = '';
        }

        return implode('|', $alts);
    }

    /**
     * @param mixed $value
     */
    private static function normalize_alt_pipe_list_for_expected_count($value, int $expectedCount): ?string
    {
        if ($value === null) {
            return null;
        }

        $alts = array_map(
            static fn($segment): string => self::normalize_slider_alt_segment($segment),
            explode('|', (string) $value)
        );
        $alts = array_values(array_slice($alts, 0, $expectedCount));
        while (count($alts) < $expectedCount) {
            $alts[] = '';
        }

        return implode('|', $alts);
    }

    private static function slider_alt_pipe_list_to_bridge_value(?string $value): ?string
    {
        if ($value === null) {
            return null;
        }

        foreach (explode('|', $value) as $segment) {
            if ($segment !== '') {
                return $value;
            }
        }

        return null;
    }

    /**
     * @param mixed $value
     * @return array<int,string>
     */
    private static function parse_pipe_alt_list_preserving_indexes($value): array
    {
        if ($value === null || $value === '') {
            return [];
        }

        return array_values(
            array_map(
                static fn($segment): string => self::normalize_slider_alt_segment($segment),
                explode('|', (string) $value)
            )
        );
    }

    private static function cleanup_legacy_image_list_meta_after_db2_sync(
        int $postId,
        ?string $expectedUrls,
        ?string $expectedAlts
    ): void {
        if (
            !self::db2_raw_confirms_rest_list_value(
                $postId,
                'fifu_list_url',
                $expectedUrls
            )
        ) {
            return;
        }

        delete_post_meta($postId, 'fifu_list_url');

        if (
            $expectedAlts !== null
            && self::db2_raw_confirms_rest_list_value(
                $postId,
                'fifu_list_alt',
                $expectedAlts,
                true
            )
        ) {
            delete_post_meta($postId, 'fifu_list_alt');
        }
    }

    private static function cleanup_legacy_image_list_alt_after_db2_sync(int $postId, ?string $expectedAlts): void
    {
        if (!class_exists('Fifu_Post_Image_List_Alt_Read_Service', false) || $expectedAlts === null) {
            return;
        }

        $normalizedAlts = self::normalize_alt_pipe_list_for_cleanup($expectedAlts);
        if ($normalizedAlts === null) {
            return;
        }

        $db2Alts = self::normalize_alt_pipe_list_for_cleanup(
            Fifu_Post_Image_List_Alt_Read_Service::get_image_list_alt($postId)
        );
        if ($db2Alts === $normalizedAlts) {
            delete_post_meta($postId, 'fifu_list_alt');
        }
    }

    private static function cleanup_legacy_video_list_meta_after_db2_sync(int $postId, ?string $expectedVideos): void
    {
        if ($expectedVideos === null) {
            return;
        }

        $normalizedVideos = self::normalize_pipe_list($expectedVideos);
        if ($normalizedVideos === null) {
            return;
        }

        if (!self::db2_video_list_matches_mixed($postId, $normalizedVideos, $expectedVideos)) {
            return;
        }

        delete_post_meta($postId, 'fifu_list_video_url');
    }

    private static function cleanup_legacy_slider_list_meta_after_db2_sync(
        int $postId,
        ?string $expectedUrls,
        ?string $expectedAlts
    ): void {
        if (
            $expectedUrls === null
            || !class_exists('Fifu_Post_Slider_List_Url_Read_Service', false)
        ) {
            return;
        }

        $normalizedUrls = self::normalize_pipe_list($expectedUrls);
        if ($normalizedUrls === null) {
            return;
        }

        $db2Urls = self::normalize_pipe_list(Fifu_Post_Slider_List_Url_Read_Service::get_slider_list_url($postId));
        if ($db2Urls !== $normalizedUrls) {
            return;
        }

        if ($expectedAlts === null || !class_exists('Fifu_Post_Slider_List_Alt_Read_Service', false)) {
            delete_post_meta($postId, 'fifu_slider_list_url');
            delete_post_meta($postId, 'fifu_slider_list_alt');
            self::delete_legacy_slider_image_alt_meta($postId);
            return;
        }

        $normalizedAlts = self::normalize_alt_pipe_list_for_cleanup($expectedAlts);
        if ($normalizedAlts === null) {
            return;
        }

        $db2Alts = self::normalize_alt_pipe_list_for_cleanup(Fifu_Post_Slider_List_Alt_Read_Service::get_slider_list_alt($postId));
        if ($db2Alts !== $normalizedAlts) {
            return;
        }

        delete_post_meta($postId, 'fifu_slider_list_url');
        delete_post_meta($postId, 'fifu_slider_list_alt');
        self::delete_legacy_slider_image_alt_meta($postId);
    }

    private static function cleanup_legacy_image_list_helpers_after_slider_db2_sync(int $postId): void
    {
        delete_post_meta($postId, 'fifu_list_url');
        delete_post_meta($postId, 'fifu_list_alt');
    }

    private static function cleanup_stale_product_legacy_meta_after_rest_replacement(
        int $postId,
        bool $imageListUrlConfirmed,
        bool $imageListAltConfirmed,
        bool $videoListConfirmed,
        bool $sliderListUrlConfirmed,
        bool $sliderListAltConfirmed
    ): void {
        if ($imageListUrlConfirmed) {
            self::delete_product_legacy_meta_by_keys_and_patterns(
                $postId,
                [
                    'fifu_image_url',
                    'fifu_list_url',
                ],
                [
                    '/^fifu_image_url_\d+$/',
                ]
            );
        }

        if ($imageListAltConfirmed) {
            self::delete_product_legacy_meta_by_keys_and_patterns(
                $postId,
                [
                    'fifu_image_alt',
                    'fifu_list_alt',
                ],
                [
                    '/^fifu_image_alt_\d+$/',
                ]
            );
        }

        if ($videoListConfirmed) {
            self::delete_product_legacy_meta_by_keys_and_patterns(
                $postId,
                [
                    'fifu_video_url',
                    'fifu_custom_video_url',
                    'fifu_list_video_url',
                ],
                [
                    '/^fifu_video_url_\d+$/',
                ]
            );
        }

        if ($sliderListUrlConfirmed) {
            self::delete_product_legacy_meta_by_keys_and_patterns(
                $postId,
                [
                    'fifu_slider_list_url',
                ],
                [
                    '/^fifu_slider_image_url_\d+$/',
                ]
            );
        }

        if ($sliderListAltConfirmed) {
            self::delete_product_legacy_meta_by_keys_and_patterns(
                $postId,
                [
                    'fifu_slider_list_alt',
                ],
                [
                    '/^fifu_slider_image_alt_\d+$/',
                ]
            );
        }
    }

    /**
     * @param array<int,string> $metaKeys
     * @param array<int,string> $patterns
     */
    private static function delete_product_legacy_meta_by_keys_and_patterns(
        int $postId,
        array $metaKeys,
        array $patterns
    ): void {
        foreach ($metaKeys as $metaKey) {
            $metaKey = trim((string) $metaKey);
            if ($metaKey !== '') {
                delete_post_meta($postId, $metaKey);
            }
        }

        if ($patterns === []) {
            return;
        }

        $meta = get_post_meta($postId);
        if (!is_array($meta) || $meta === []) {
            return;
        }

        foreach (array_keys($meta) as $metaKey) {
            if (!is_string($metaKey) || $metaKey === '') {
                continue;
            }

            foreach ($patterns as $pattern) {
                if (preg_match($pattern, $metaKey) !== 1) {
                    continue;
                }

                delete_post_meta($postId, $metaKey);
                break;
            }
        }
    }

    /**
     * @param array<int,string> $skipImageMetaKeys
     */
    private static function cleanup_confirmed_product_legacy_media_meta(
        int $postId,
        array $skipImageMetaKeys = [],
        bool $indexedVideoMetaStartsAtZero = false
    ): void
    {
        if (!class_exists('Fifu_Legacy_Media_Meta_Cleanup_Service', false)) {
            $cleanupServicePath = __DIR__ . '/../../meta/class-fifu-legacy-media-meta-cleanup-service.php';
            if (is_readable($cleanupServicePath)) {
                require_once $cleanupServicePath;
            }
        }

        if (!class_exists('Fifu_Legacy_Media_Meta_Cleanup_Service', false)) {
            return;
        }

        Fifu_Legacy_Media_Meta_Cleanup_Service::cleanup_post_image_meta_after_db2_sync($postId, $skipImageMetaKeys);
        Fifu_Legacy_Media_Meta_Cleanup_Service::cleanup_post_video_meta_after_db2_sync(
            $postId,
            $indexedVideoMetaStartsAtZero
        );
        Fifu_Legacy_Media_Meta_Cleanup_Service::cleanup_post_slider_meta_after_db2_sync($postId);
    }

    private static function delete_legacy_slider_image_alt_meta(int $postId): void
    {
        $meta = get_post_meta($postId);
        if (!is_array($meta) || $meta === []) {
            return;
        }

        foreach (array_keys($meta) as $metaKey) {
            if (!is_string($metaKey)) {
                continue;
            }

            if (preg_match('/^fifu_slider_image_alt_\d+$/', $metaKey) !== 1) {
                continue;
            }

            delete_post_meta($postId, $metaKey);
        }
    }

    private static function resolve_rest_bridge_value(string $metaKey, ?string $value, bool $isAlt = false): ?string
    {
        if (
            $isAlt
            || $metaKey === 'fifu_list_alt'
            || $metaKey === 'fifu_slider_list_alt'
        ) {
            return self::slider_alt_pipe_list_to_bridge_value(
                self::normalize_slider_alt_pipe_list($value)
            );
        }

        return self::normalize_pipe_list($value) === null ? null : $value;
    }

    private static function is_semantically_empty_rest_value(string $metaKey, ?string $value, bool $isAlt = false): bool
    {
        return self::resolve_rest_bridge_value($metaKey, $value, $isAlt) === null;
    }

    private static function db2_confirms_rest_list_clear(int $postId, string $metaKey): bool
    {
        $rawMappings = self::get_db2_raw_list_mappings($postId, $metaKey);
        if (is_array($rawMappings)) {
            return $rawMappings === [];
        }

        switch ($metaKey) {
            case 'fifu_list_url':
                return self::normalize_pipe_list(
                    Fifu_Post_Image_List_Url_Read_Service::get_image_list_url($postId)
                ) === null;
            case 'fifu_list_alt':
                return self::normalize_alt_pipe_list_for_cleanup(
                    Fifu_Post_Image_List_Alt_Read_Service::get_image_list_alt($postId)
                ) === null;
            case 'fifu_list_video_url':
                return self::db2_video_list_matches($postId, []);
            case 'fifu_slider_list_url':
                return self::normalize_pipe_list(
                    Fifu_Post_Slider_List_Url_Read_Service::get_slider_list_url($postId)
                ) === null;
            case 'fifu_slider_list_alt':
                return self::normalize_alt_pipe_list_for_cleanup(
                    Fifu_Post_Slider_List_Alt_Read_Service::get_slider_list_alt($postId)
                ) === null;
            default:
                return false;
        }
    }

    private static function db2_raw_confirms_rest_list_clear(int $postId, string $metaKey): bool
    {
        $rawMappings = self::get_db2_raw_list_mappings($postId, $metaKey);
        if (!is_array($rawMappings)) {
            return false;
        }

        return $rawMappings === [];
    }

    private static function db2_confirms_rest_list_value(
        int $postId,
        string $metaKey,
        ?string $expectedValue,
        bool $isAlt = false
    ): bool {
        $isAltList = $isAlt || $metaKey === 'fifu_list_alt' || $metaKey === 'fifu_slider_list_alt';

        if ($isAltList) {
            $normalizedExpected = self::normalize_slider_alt_pipe_list($expectedValue);
            if ($normalizedExpected === null) {
                return false;
            }

            if (!self::db2_alt_list_matches_expected_mappings($postId, $normalizedExpected, $metaKey)) {
                return false;
            }
        } else {
            $normalizedExpected = self::normalize_pipe_list($expectedValue);
            if ($normalizedExpected === null) {
                return false;
            }
        }

        $rawMappings = self::get_db2_raw_list_mappings($postId, $metaKey);
        if (is_array($rawMappings) && !$isAltList) {
            return self::normalize_db2_raw_list_mappings($rawMappings, $metaKey) === $normalizedExpected;
        }

        switch ($metaKey) {
            case 'fifu_list_url':
                $actual = self::normalize_pipe_list(
                    Fifu_Post_Image_List_Url_Read_Service::get_image_list_url($postId)
                );
                break;
            case 'fifu_list_alt':
                $actual = self::normalize_alt_pipe_list_for_cleanup(
                    Fifu_Post_Image_List_Alt_Read_Service::get_image_list_alt($postId)
                );
                break;
            case 'fifu_list_video_url':
                return self::db2_video_list_matches($postId, $normalizedExpected);
            case 'fifu_slider_list_url':
                $actual = self::normalize_pipe_list(
                    Fifu_Post_Slider_List_Url_Read_Service::get_slider_list_url($postId)
                );
                break;
            case 'fifu_slider_list_alt':
                $actual = self::normalize_alt_pipe_list_for_cleanup(
                    Fifu_Post_Slider_List_Alt_Read_Service::get_slider_list_alt($postId)
                );
                break;
            default:
                return false;
        }

        if ($isAltList) {
            return $actual === self::normalize_alt_pipe_list_for_cleanup($normalizedExpected);
        }

        return $actual === $normalizedExpected;
    }

    private static function db2_raw_confirms_rest_list_value(
        int $postId,
        string $metaKey,
        ?string $expectedValue,
        bool $isAlt = false
    ): bool {
        $normalizedExpected = $isAlt || $metaKey === 'fifu_list_alt' || $metaKey === 'fifu_slider_list_alt'
            ? self::normalize_alt_pipe_list_for_cleanup($expectedValue)
            : self::normalize_pipe_list($expectedValue);

        if ($normalizedExpected === null) {
            return false;
        }

        $rawMappings = self::get_db2_raw_list_mappings($postId, $metaKey);
        if (!is_array($rawMappings)) {
            return false;
        }

        return self::normalize_db2_raw_list_mappings($rawMappings, $metaKey) === $normalizedExpected;
    }

    /**
     * @return array<int, array<string,mixed>>|null
     */
    private static function get_db2_raw_list_mappings(int $postId, string $metaKey): ?array
    {
        if (!function_exists('fifu_db2_manager')) {
            return null;
        }

        $manager = fifu_db2_manager();
        if (!($manager instanceof Fifu_Db2_Manager)) {
            return null;
        }

        switch ($metaKey) {
            case 'fifu_list_url':
                return $manager->getPostMappings($postId, 'image');
            case 'fifu_list_alt':
                return $manager->getPostAltMappings($postId, 'image');
            case 'fifu_list_video_url':
                $mappings = $manager->getPostMappings($postId, 'video');
                if ($mappings !== []) {
                    return $mappings;
                }

                $singleMappings = [];
                for ($index = 0; $index < 100; $index++) {
                    $mapping = $manager->getPostMapping($postId, 'video', $index);
                    if (!is_array($mapping)) {
                        break;
                    }

                    $mapping['key_index'] = $mapping['key_index'] ?? $index;
                    $singleMappings[] = $mapping;
                }

                return $singleMappings;
            case 'fifu_slider_list_url':
                return $manager->getPostMappings($postId, 'slider');
            case 'fifu_slider_list_alt':
                return $manager->getPostAltMappings($postId, 'slider');
            default:
                return null;
        }
    }

    /**
     * @param array<int, array<string,mixed>> $rawMappings
     */
    private static function normalize_db2_raw_list_mappings(array $rawMappings, string $metaKey): ?string
    {
        if (!$rawMappings) {
            return null;
        }

        usort(
            $rawMappings,
            static fn(array $a, array $b): int => (int) ($a['key_index'] ?? 0) <=> (int) ($b['key_index'] ?? 0)
        );

        $values = [];
        foreach ($rawMappings as $mapping) {
            if ($metaKey === 'fifu_list_alt' || $metaKey === 'fifu_slider_list_alt') {
                $normalized = trim((string) ($mapping['alt'] ?? $mapping['value'] ?? ''));
                if ($normalized !== '') {
                    $values[] = $normalized;
                }
                continue;
            }

            $normalized = trim((string) ($mapping['url'] ?? ''));
            if ($normalized !== '') {
                $values[] = $normalized;
            }
        }

        return $values ? implode('|', $values) : null;
    }

    /**
     * @param string|string[] $expectedVideos
     */
    private static function db2_video_list_matches(int $postId, $expectedVideos): bool
    {
        if (!function_exists('fifu_db2_manager')) {
            return false;
        }

        $manager = fifu_db2_manager();
        if (!($manager instanceof Fifu_Db2_Manager)) {
            return false;
        }

        $rows = $manager->getPostMappings($postId, 'video');
        if (!is_array($rows)) {
            return false;
        }

        $actual = self::normalize_db2_video_rows($rows);

        $expected = [];
        $normalizedExpected = is_string($expectedVideos)
            ? self::normalize_pipe_list($expectedVideos)
            : (is_array($expectedVideos) ? implode('|', array_map('strval', $expectedVideos)) : null);
        if ($normalizedExpected === null || $normalizedExpected === '') {
            return $actual === [];
        }

        foreach (explode('|', $normalizedExpected) as $url) {
            $url = trim((string) $url);
            if ($url === '') {
                continue;
            }

            $expected[] = $url;
        }

        return $actual === $expected;
    }

    private static function persist_rest_video_list_meta(int $postId, ?string $rawVideoUrls): bool
    {
        if ($rawVideoUrls === null) {
            return self::persist_rest_list_meta($postId, 'fifu_list_video_url', null);
        }

        $normalizedVideos = self::normalize_pipe_list($rawVideoUrls);
        if ($normalizedVideos === null) {
            return self::persist_rest_list_meta($postId, 'fifu_list_video_url', null);
        }

        $parsed = self::parse_video_list_entries($rawVideoUrls);
        $normalVideos = $parsed['video'];
        $customVideos = $parsed['custom_video'];

        if (!function_exists('fifu_db2_manager')) {
            self::mirror_rest_meta($postId, 'fifu_list_video_url', $rawVideoUrls);
            return self::persist_rest_list_meta($postId, 'fifu_list_video_url', $rawVideoUrls);
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            self::mirror_rest_meta($postId, 'fifu_list_video_url', $rawVideoUrls);
            return self::persist_rest_list_meta($postId, 'fifu_list_video_url', $rawVideoUrls);
        }

        self::mirror_rest_meta($postId, 'fifu_list_video_url', $rawVideoUrls);

        if (function_exists('fifu_db2_legacy_write_bridge')) {
            $bridge = fifu_db2_legacy_write_bridge();
            if ($bridge instanceof Fifu_Db2_Legacy_Write_Bridge) {
                try {
                    if (!$bridge->handle_post_meta_change($postId, 'fifu_list_video_url', $rawVideoUrls)) {
                        return false;
                    }
                } catch (\Throwable $exception) {
                    return false;
                }
            }
        }

        if (method_exists($manager, 'deletePostMappings') && method_exists($manager, 'savePostUrl')) {
            try {
                $manager->deletePostMappings($postId, 'video');
                $manager->deletePostMappings($postId, 'custom_video');
            } catch (\Throwable $exception) {
                return false;
            }

            foreach (array_values($normalVideos) as $index => $url) {
                if (!$manager->savePostUrl($postId, 'video', $index, $url)) {
                    return false;
                }
            }

            foreach (array_values($customVideos) as $index => $customVideo) {
                if (!$manager->savePostUrl($postId, 'custom_video', $index, $customVideo['video'])) {
                    return false;
                }

                if (($customVideo['poster'] ?? '') !== '' && class_exists('Fifu_Video_Oembed_Service', false)) {
                    if (!Fifu_Video_Oembed_Service::instance()->upsert_oembed($customVideo['video'], $customVideo['poster'], $customVideo['video'])) {
                        return false;
                    }
                }
            }
        }

        return self::db2_video_list_matches_mixed($postId, $normalizedVideos, $rawVideoUrls);
    }

    /**
     * @return array{video:array<int,string>,custom_video:array<int,array{video:string,poster:string}>}
     */
    private static function parse_video_list_entries(string $rawValue): array
    {
        $video = [];
        $customVideo = [];

        foreach (self::parse_pipe_list_to_array($rawValue) as $entry) {
            [$videoUrl, $posterUrl, $hasCustomPoster] = self::split_custom_video_entry($entry);
            $videoUrl = trim((string) $videoUrl);
            $posterUrl = trim((string) $posterUrl);

            if ($hasCustomPoster && $posterUrl !== '') {
                $customVideo[] = [
                    'video' => $videoUrl,
                    'poster' => $posterUrl,
                ];
                continue;
            }

            if ($videoUrl !== '') {
                $video[] = $videoUrl;
            }
        }

        return [
            'video' => $video,
            'custom_video' => $customVideo,
        ];
    }

    /**
     * @return array{0:string,1:string,2:bool}
     */
    private static function split_custom_video_entry(string $value): array
    {
        $value = trim($value);
        if ($value === '') {
            return ['', '', false];
        }

        if (strpos($value, '\\') !== false) {
            [$videoUrl, $posterUrl] = array_pad(explode('\\', $value, 2), 2, '');
            $videoUrl = trim((string) $videoUrl);
            $posterUrl = ltrim(trim((string) $posterUrl), '\\');
            return [$videoUrl, $posterUrl, $videoUrl !== '' && $posterUrl !== ''];
        }

        return [$value, '', false];
    }

    /**
     * @param array<int,array<string,mixed>> $rows
     * @return array<int,string>
     */
    private static function normalize_db2_video_rows(array $rows): array
    {
        $actual = [];

        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }

            $index = isset($row['key_index']) ? (int) $row['key_index'] : count($actual);
            $url = trim((string) ($row['url'] ?? ''));
            if ($url === '') {
                continue;
            }

            $actual[$index] = $url;
        }

        ksort($actual);

        return array_values($actual);
    }

    private static function db2_video_list_matches_mixed(int $postId, string $expectedNormalizedVideos, ?string $rawExpectedVideos): bool
    {
        if (!function_exists('fifu_db2_manager')) {
            return false;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return false;
        }

        $parsed = self::parse_video_list_entries($rawExpectedVideos ?? $expectedNormalizedVideos);
        $actualNormal = self::normalize_db2_video_rows((array) $manager->getPostMappings($postId, 'video'));
        $actualCustom = self::normalize_db2_video_rows((array) $manager->getPostMappings($postId, 'custom_video'));

        return $actualNormal === $parsed['video'] && $actualCustom === array_map(
            static fn(array $row): string => $row['video'],
            $parsed['custom_video']
        );
    }

    private static function normalize_pipe_list(?string $value): ?string
    {
        if ($value === null) {
            return null;
        }

        $entries = array_values(
            array_filter(
                array_map('trim', explode('|', $value)),
                static fn(string $entry): bool => $entry !== ''
            )
        );

        if (!$entries) {
            return null;
        }

        return implode('|', $entries);
    }

    private static function normalize_alt_pipe_list_for_cleanup(?string $value): ?string
    {
        if ($value === null) {
            return null;
        }

        $segments = array_map(
            static fn($segment): string => self::normalize_slider_alt_segment($segment),
            explode('|', $value)
        );

        while ($segments !== [] && end($segments) === '') {
            array_pop($segments);
        }

        if ($segments === [] || implode('', $segments) === '') {
            return null;
        }

        return implode('|', $segments);
    }

    private static function sync_rest_product_image_list_mappings(
        int $postId,
        ?string $urlList,
        ?string $altList
    ): bool {
        if (!function_exists('fifu_db2_manager')) {
            return false;
        }

        $manager = fifu_db2_manager();
        if (!($manager instanceof Fifu_Db2_Manager)) {
            return false;
        }

        if (method_exists($manager, 'deletePostMappings')) {
            $manager->deletePostMappings($postId, 'image', null);
        }

        $urls = [];
        foreach (explode('|', (string) $urlList) as $rawUrl) {
            $normalizedUrl = esc_url_raw(rtrim(trim((string) $rawUrl), '|'));
            if ($normalizedUrl === '') {
                continue;
            }

            $urls[] = $normalizedUrl;
        }

        if ($urls === []) {
            if (method_exists($manager, 'clearKeyCache')) {
                $manager->clearKeyCache();
            }
            return true;
        }

        foreach ($urls as $index => $url) {
            if (!method_exists($manager, 'savePostUrl') || !$manager->savePostUrl($postId, 'image', (int) $index, $url)) {
                return false;
            }
        }

        if (method_exists($manager, 'clearKeyCache')) {
            $manager->clearKeyCache();
        }

        $actualUrls = self::normalize_pipe_list(Fifu_Post_Image_List_Url_Read_Service::get_image_list_url($postId));
        $expectedUrls = self::normalize_pipe_list(implode('|', $urls));
        return $actualUrls === $expectedUrls;
    }

    private static function sync_rest_product_image_list_alts_for_existing_mappings(
        int $postId,
        ?string $altList
    ): bool {
        if ($altList === null || !function_exists('fifu_db2_manager')) {
            return false;
        }

        $manager = fifu_db2_manager();
        if (!($manager instanceof Fifu_Db2_Manager)) {
            return false;
        }

        $mappings = method_exists($manager, 'getPostMappings')
            ? $manager->getPostMappings($postId, 'image')
            : [];

        if (!is_array($mappings) || $mappings === []) {
            return false;
        }

        usort(
            $mappings,
            static fn(array $a, array $b): int => (int) ($a['key_index'] ?? 0) <=> (int) ($b['key_index'] ?? 0)
        );

        $indexes = [];
        foreach ($mappings as $mapping) {
            if (!is_array($mapping)) {
                continue;
            }

            $index = (int) ($mapping['key_index'] ?? -1);
            $url = trim((string) ($mapping['url'] ?? ''));
            if ($index < 0 || $url === '') {
                continue;
            }

            $indexes[] = $index;
        }

        if ($indexes === []) {
            return false;
        }

        $normalizedAltList = self::normalize_alt_pipe_list_for_expected_count($altList, count($indexes));
        if ($normalizedAltList === null) {
            return false;
        }

        $alts = explode('|', $normalizedAltList);

        $writeService = function_exists('fifu_db2_write_service') ? fifu_db2_write_service() : null;
        $hasWriteService = $writeService instanceof Fifu_Db2_Write_Service;

        if ($hasWriteService && method_exists($writeService, 'delete_post_image_alt')) {
            $writeService->delete_post_image_alt($postId, null);
        }

        foreach ($indexes as $position => $index) {
            $alt = isset($alts[$position]) ? self::normalize_slider_alt_segment($alts[$position]) : '';

            if ($alt === '') {
                if ($hasWriteService && method_exists($writeService, 'delete_post_image_alt')) {
                    $writeService->delete_post_image_alt($postId, (int) $index);
                } elseif (method_exists($manager, 'deletePostAltMappings')) {
                    $manager->deletePostAltMappings($postId, 'image', (int) $index);
                }
                continue;
            }

            if ($hasWriteService && method_exists($writeService, 'save_post_image_alt_at_index')) {
                if (!$writeService->save_post_image_alt_at_index($postId, (int) $index, $alt)) {
                    return false;
                }
                continue;
            }

            if (!method_exists($manager, 'savePostAlt') || !$manager->savePostAlt($postId, 'image', (int) $index, $alt)) {
                return false;
            }
        }

        if (method_exists($manager, 'clearKeyCache')) {
            $manager->clearKeyCache();
        }

        return self::db2_alt_list_matches_expected_mappings($postId, $normalizedAltList, 'fifu_list_alt');
    }

    private static function db2_alt_list_matches_expected_mappings(int $postId, string $expectedValue, string $metaKey): bool
    {
        if (!function_exists('fifu_db2_manager')) {
            return false;
        }

        $manager = fifu_db2_manager();
        if (!($manager instanceof Fifu_Db2_Manager)) {
            return false;
        }

        $keyType = $metaKey === 'fifu_slider_list_alt' ? 'slider' : 'image';
        $mappings = $manager->getPostAltMappings($postId, $keyType);
        if (!is_array($mappings)) {
            return false;
        }

        $expectedSegments = explode('|', $expectedValue);
        foreach ($expectedSegments as $index => $expectedAlt) {
            $expectedAlt = trim((string) $expectedAlt);
            $mapping = $manager->getPostAltMapping($postId, $keyType, (int) $index);
            $actualAlt = is_array($mapping) ? trim((string) ($mapping['alt'] ?? '')) : '';

            if ($expectedAlt === '') {
                if ($actualAlt !== '') {
                    return false;
                }
                continue;
            }

            if ($actualAlt !== $expectedAlt) {
                return false;
            }
        }

        foreach ($mappings as $mapping) {
            if (!is_array($mapping)) {
                continue;
            }

            $index = (int) ($mapping['key_index'] ?? -1);
            $actualAlt = trim((string) ($mapping['alt'] ?? $mapping['value'] ?? ''));
            if ($index >= count($expectedSegments) && $actualAlt !== '') {
                return false;
            }
        }

        return true;
    }

    /**
     * @param mixed $value
     */
    private static function mirror_rest_meta(int $postId, string $key, $value): void
    {
        if ($value === null || $value === '') {
            delete_post_meta($postId, $key);
            return;
        }

        $raw = (string) $value;
        $stored = function_exists('wp_slash') ? wp_slash($raw) : addslashes($raw);
        update_post_meta($postId, $key, $stored);
    }

    /**
     * Handles WooCommerce REST product category insert/update.
     * It will eventually replace fifu_save_product_category().
     *
     * @param WP_Term $term
     * @param WP_REST_Request $request
     */
    public static function on_product_cat_rest_save(
        WP_Term $term,
        WP_REST_Request $request
    ): void {
        $params = $request->get_params();
        if (empty($params) || !array_key_exists('meta_data', $params) || !is_array($params['meta_data'])) {
            return;
        }

        $termId = $term->term_id;
        $termMetaUpdater = FIFU_Term_Meta_Updater::instance();
        $imageUrl = null;
        $imageAlt = null;
        $videoUrl = null;
        $winningMediaKey = null;

        foreach ($params['meta_data'] as $meta) {
            if (!is_array($meta) || !array_key_exists('key', $meta)) {
                continue;
            }

            switch ($meta['key']) {
                case 'fifu_image_url':
                    $imageUrl = $meta['value'] ?? null;
                    $winningMediaKey = 'fifu_image_url';
                    break;
                case 'fifu_image_alt':
                    $imageAlt = $meta['value'] ?? null;
                    break;
                case 'fifu_video_url':
                    $videoUrl = $meta['value'] ?? null;
                    $winningMediaKey = 'fifu_video_url';
                    break;
                default:
                    break;
            }
        }

        if ($winningMediaKey === 'fifu_video_url') {
            $termMetaUpdater->update_or_delete_term($termId, 'fifu_video_url', $videoUrl);
            $termMetaUpdater->update_or_delete_term($termId, 'fifu_image_url', '');
            $termMetaUpdater->update_or_delete_term($termId, 'fifu_image_alt', '');
        } elseif ($winningMediaKey === 'fifu_image_url') {
            $termMetaUpdater->update_or_delete_term($termId, 'fifu_image_url', $imageUrl);
            $termMetaUpdater->update_or_delete_term($termId, 'fifu_video_url', '');
            $termMetaUpdater->update_or_delete_term($termId, 'fifu_custom_video_url', '');
            if ($imageUrl !== null && trim((string) $imageUrl) !== '' && $imageAlt !== null) {
                $termMetaUpdater->update_or_delete_term($termId, 'fifu_image_alt', $imageAlt);
            } else {
                $termMetaUpdater->update_or_delete_term($termId, 'fifu_image_alt', '');
            }
        } elseif (array_key_exists('fifu_image_url', $params['meta_data'][0] ?? []) || $videoUrl !== null) {
            if ($videoUrl !== null && trim((string) $videoUrl) !== '') {
                $termMetaUpdater->update_or_delete_term($termId, 'fifu_video_url', $videoUrl);
                $termMetaUpdater->update_or_delete_term($termId, 'fifu_image_url', '');
                $termMetaUpdater->update_or_delete_term($termId, 'fifu_image_alt', '');
            } elseif ($imageUrl !== null) {
                $termMetaUpdater->update_or_delete_term($termId, 'fifu_image_url', $imageUrl);
                if ($imageAlt !== null) {
                    $termMetaUpdater->update_or_delete_term($termId, 'fifu_image_alt', $imageAlt);
                }
            }
        } elseif ($videoUrl !== null) {
            $termMetaUpdater->update_or_delete_term($termId, 'fifu_video_url', $videoUrl);
            if ($videoUrl !== null && trim((string) $videoUrl) !== '') {
                $termMetaUpdater->update_or_delete_term($termId, 'fifu_image_url', '');
                $termMetaUpdater->update_or_delete_term($termId, 'fifu_image_alt', '');
            }
        }

        if (function_exists('fifu_db2_manager')) {
            $manager = fifu_db2_manager();
            if ($manager instanceof Fifu_Db2_Manager) {
                $manager->clearKeyCache();
            }
        }

        Fifu_Post_Attachment_Sync_Service::sync_category_attachment($termId);
    }
}
