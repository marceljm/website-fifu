<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

add_action('init', static function (): void {
    // Register WooCommerce-specific REST routing.
    Fifu_Woocommerce_Rest_Integration::register_hooks();
    // Register the FIFU REST routing integration so all controllers are registered centrally.
    Fifu_Rest_Routing_Integration::register_hooks();
});
