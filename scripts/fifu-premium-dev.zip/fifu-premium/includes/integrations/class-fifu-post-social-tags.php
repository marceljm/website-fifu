<?php

defined('ABSPATH') || exit;

/**
 * Renders FIFU social meta tags for posts and video posts.
 */
class Fifu_Post_Social_Tags {

    /**
     * Outputs og/twitter image tags for the current post.
     */
    public static function render_post_image_tags(): void {
        if (is_front_page() || is_home() || is_tax() || !is_singular()) {
            return;
        }

        $post_id = (int) get_queried_object_id();
        if ($post_id <= 0) {
            return;
        }
        $title = str_replace("'", "&#39;", strip_tags(get_the_title($post_id)));
        $description = str_replace("'", "&#39;", wp_strip_all_tags(get_post_field('post_excerpt', $post_id)));

        $arr = self::fifu_get_post_image_urls_db2_first((int) $post_id);

        if (empty($arr)) {
            return;
        }

        foreach ($arr as $url) {
            if (!$url) {
                continue;
            }
            if (Fifu_Speedup_Url_Service::is_speedup_url($url)) {
                $url = Fifu_Speedup_Url_Service::get_signed_url($url, 1280, 672, null, null, false);
            } elseif (Fifu_Options_Utils::is_on('fifu_photon')) {
                $url = Fifu_Jetpack_Cdn_Service::build_photon_url($url, null, get_post_thumbnail_id($post_id));
            }
            include FIFU_INCLUDES_DIR . '/html/og-image.html';
        }

        foreach ($arr as $url) {
            if (!$url) {
                continue;
            }
            if (Fifu_Speedup_Url_Service::is_speedup_url($url)) {
                $url = Fifu_Speedup_Url_Service::get_signed_url($url, 1280, 672, null, null, false);
            } elseif (Fifu_Options_Utils::is_on('fifu_photon')) {
                $url = Fifu_Jetpack_Cdn_Service::build_photon_url($url, null, get_post_thumbnail_id($post_id));
            }
            include FIFU_INCLUDES_DIR . '/html/twitter-image.html';
        }
    }

    /**
     * Outputs video meta tags for posts that have a video URL.
     */
    public static function render_post_video_tags(): void {
        if (is_front_page() || is_home() || is_tax() || !is_singular()) {
            return;
        }

        $post_id = (int) get_queried_object_id();
        if ($post_id <= 0) {
            return;
        }
        $url = Fifu_Post_Video_Read_Service::get_video_url((int) $post_id);
        if (!$url) {
            return;
        }

        $title = str_replace("'", "&#39;", strip_tags(get_the_title($post_id)));
        $description = str_replace("'", "&#39;", str_replace('"', '&#34;', wp_strip_all_tags(get_post_field('post_excerpt', $post_id))));
        $video_id = Fifu_Video_Helper::get_video_id($url);

        $video_src = Fifu_Video_Helper::get_embed_url($url);
        $video_img = Fifu_Video_Helper::get_social_image($url);

        $video_url = $video_id === null ? $url : Fifu_Video_Helper::get_social_url($video_id);

        if (Fifu_Speedup_Url_Service::is_speedup_url($video_img)) {
            $video_img = Fifu_Speedup_Url_Service::get_signed_url($video_img, 1280, 672, null, null, true);
        }
        include FIFU_INCLUDES_DIR . '/html/social-video.html';
    }

    /**
     * Collects image URLs for the post, preferring DB2 sources with a legacy fallback.
     *
     * @param int $post_id
     * @return string[]
     */
    private static function fifu_get_post_image_urls_db2_first(int $post_id): array {
        $urls = [];
        $seen = [];

        $primary = Fifu_Post_Image_Url_Read_Service::get_image_url((int) $post_id);
        if ($primary) {
            self::fifu_append_unique_image_url($primary, $urls, $seen);
        }

        if (function_exists('fifu_db2_manager')) {
            $manager = fifu_db2_manager();
            if ($manager instanceof Fifu_Db2_Manager) {
                foreach (['image', 'slider'] as $key_type) {
                    $mappings = $manager->getPostMappings($post_id, $key_type);
                    if (!$mappings) {
                        continue;
                    }

                    usort(
                        $mappings,
                        static fn(array $a, array $b): int => ($a['key_index'] ?? 0) <=> ($b['key_index'] ?? 0)
                    );

                    foreach ($mappings as $mapping) {
                        $mapping_url = self::fifu_extract_url_from_mapping_row($manager, $mapping);
                        if ($mapping_url === null) {
                            continue;
                        }

                        self::fifu_append_unique_image_url($mapping_url, $urls, $seen);
                    }
                }
            }
        }

        if ($urls) {
            return $urls;
        }

        global $wpdb;
        $legacy = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT meta_value FROM $wpdb->postmeta WHERE post_id = %d AND meta_key LIKE %s",
                $post_id,
                'fifu_%image_url%'
            )
        );

        return $legacy ?: [];
    }

    /**
     * Append a URL to the list if it has not been seen yet.
     *
     * @param string   $url
     * @param string[] $urls
     * @param array    $seen
     * @return void
     */
    private static function fifu_append_unique_image_url(string $url, array &$urls, array &$seen): void {
        if ($url === '' || isset($seen[$url])) {
            return;
        }

        $seen[$url] = true;
        $urls[] = $url;
    }

    /**
     * Extracts a valid URL from a DB2 mapping row.
     *
     * @param Fifu_Db2_Manager $manager
     * @param array            $row
     * @return string|null
     */
    private static function fifu_extract_url_from_mapping_row(Fifu_Db2_Manager $manager, array $row): ?string {
        $url = trim((string) ($row['url'] ?? ''));
        if ($url !== '') {
            return $url;
        }

        $hash = $row['hash'] ?? '';
        if ($hash === '') {
            return null;
        }

        $details = $manager->getUrlDetails((string) $hash);
        if (!is_array($details)) {
            return null;
        }

        $resolved = trim((string) ($details['url'] ?? ''));
        return $resolved === '' ? null : $resolved;
    }
}
