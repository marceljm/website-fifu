<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

final class Fifu_Wp_All_Export_Integration
{
    private const ADDON_SLUG = 'fifu';

    private const FIELD_NAMES = [
        'meta:fifu_image_url',
        'meta:fifu_image_alt',
        'meta:fifu_video_url',
        'meta:fifu_list_url',
        'meta:fifu_list_alt',
        'meta:fifu_list_video_url',
        'meta:fifu_slider_list_url',
        'meta:fifu_slider_list_alt',
    ];

    private const DIRECT_IMAGE_FIELDS = [
        'meta:fifu_image_url',
        'meta:fifu_image_alt',
    ];

    private const PRODUCT_IMAGE_FIELDS = [
        'meta:fifu_list_url',
        'meta:fifu_list_alt',
    ];

    private const DIRECT_VIDEO_FIELDS = [
        'meta:fifu_video_url',
    ];

    private const PRODUCT_VIDEO_FIELDS = [
        'meta:fifu_list_video_url',
    ];

    private const SLIDER_FIELDS = [
        'meta:fifu_slider_list_url',
        'meta:fifu_slider_list_alt',
    ];

    private const PRODUCT_POST_TYPES = [
        'product',
        'product_variation',
    ];

    private const ORDER_POST_TYPES = [
        'shop_order',
        'shop_order_refund',
    ];

    public static function register_hooks(): void
    {
        add_filter('pmxe_addons', [self::class, 'register_addon'], 20, 1);
        add_filter('wp_all_export_init_fields', [self::class, 'add_init_fields'], 20, 1);
        add_filter('wp_all_export_default_fields', [self::class, 'add_default_fields'], 20, 1);
        add_action('pmxe_before_export', [self::class, 'retrofit_saved_export_fields'], 20, 1);
        add_filter('pmxe_fifu_addon_export_field', [self::class, 'export_field'], 10, 11);
    }

    public static function register_addon($addons)
    {
        if (!is_array($addons)) {
            return $addons;
        }

        if (!in_array(self::ADDON_SLUG, $addons, true)) {
            $addons[] = self::ADDON_SLUG;
        }

        return $addons;
    }

    public static function add_default_fields($fields)
    {
        if (!is_array($fields)) {
            return $fields;
        }
        return self::append_available_fields($fields);
    }

    /**
     * Adds FIFU fields to the initial field collection rendered by the new
     * export wizard.
     *
     * @param mixed $fields WP All Export initial fields.
     * @return mixed
     */
    public static function add_init_fields($fields)
    {
        if (!is_array($fields)) {
            return $fields;
        }

        return self::append_available_fields($fields);
    }

    /**
     * @param array<int, mixed> $fields
     * @return array<int, mixed>
     */
    private static function append_available_fields(array $fields): array
    {
        $names = [];

        foreach ($fields as $field) {
            if (is_array($field) && isset($field['name'])) {
                $names[] = $field['name'];
            }
        }

        foreach (self::enabled_default_fields() as $field) {
            if (in_array($field['name'], $names, true)) {
                continue;
            }

            $fields[] = $field;
            $names[] = $field['name'];
        }

        return $fields;
    }

    /**
     * Adds FIFU's currently enabled fields to the active saved export before
     * WP All Export traverses its cc_* arrays.
     *
     * @param mixed $exportId WP All Export export ID.
     */
    public static function retrofit_saved_export_fields($exportId): void
    {
        $record = self::get_active_export_record();
        $loadedById = false;

        if (!$record && is_numeric($exportId) && (int) $exportId > 0 && class_exists('PMXE_Export_Record')) {
            $candidate = new \PMXE_Export_Record();
            if (method_exists($candidate, 'getById') && method_exists($candidate, 'isEmpty')
                && !$candidate->getById((int) $exportId)->isEmpty()) {
                $record = $candidate;
                $loadedById = true;
            }
        }

        if (!$record && class_exists('XmlExportEngine') && property_exists('XmlExportEngine', 'exportOptions')
            && is_array(\XmlExportEngine::$exportOptions)) {
            $options = \XmlExportEngine::$exportOptions;
            $effectiveOptions = self::append_missing_fifu_fields($options);
            if ($effectiveOptions !== $options) {
                \XmlExportEngine::$exportOptions = $effectiveOptions;
            }
            return;
        }

        if (!$record || !isset($record->options) || !is_array($record->options)
            || !method_exists($record, 'set') || !method_exists($record, 'save')) {
            return;
        }

        $options = $record->options;
        $postTypes = self::get_record_post_types($options);
        $effectiveOptions = self::append_missing_fifu_fields($options, $postTypes);
        if ($effectiveOptions === $options) {
            return;
        }

        $record->set('options', $effectiveOptions)->save();

        // Keep the active engine synchronized during PMXE_Export_Record::execute().
        // In the controller path the saved record is authoritative for the later
        // AJAX request, so no global engine state is required.
        if (!$loadedById && class_exists('XmlExportEngine')
            && property_exists('XmlExportEngine', 'exportOptions')) {
            \XmlExportEngine::$exportOptions = $effectiveOptions;
        }
    }

    /**
     * Returns the record already bound by WP All Export, if it is usable.
     *
     * @return object|null
     */
    private static function get_active_export_record(): ?object
    {
        if (!class_exists('XmlExportEngine') || !property_exists('XmlExportEngine', 'exportRecord')) {
            return null;
        }

        $record = \XmlExportEngine::$exportRecord;

        return is_object($record) && isset($record->options) && is_array($record->options)
            && method_exists($record, 'set') && method_exists($record, 'save') ? $record : null;
    }

    /**
     * @param array<string, mixed> $options WP All Export options.
     * @return array<string, mixed>
     */
    private static function append_missing_fifu_fields(array $options, ?array $postTypes = null): array
    {
        $requiredArrays = [
            'ids',
            'cc_label',
            'cc_php',
            'cc_code',
            'cc_sql',
            'cc_type',
            'cc_options',
            'cc_value',
            'cc_name',
        ];

        foreach ($requiredArrays as $key) {
            if (!isset($options[$key]) || !is_array($options[$key])) {
                return $options;
            }
        }

        $expectedKeys = array_keys($options['ids']);
        foreach (array_slice($requiredArrays, 1) as $key) {
            if (array_keys($options[$key]) !== $expectedKeys) {
                return $options;
            }
        }

        if (isset($options['cc_settings']) && (!is_array($options['cc_settings'])
            || array_keys($options['cc_settings']) !== $expectedKeys)) {
            return $options;
        }

        if (!isset($options['cc_settings'])) {
            $options['cc_settings'] = array_fill_keys($expectedKeys, '');
        }

        $existingNames = $options['cc_name'];
        foreach (self::enabled_default_fields($postTypes) as $field) {
            if (in_array($field['name'], $existingNames, true)) {
                continue;
            }

            $options['ids'][] = 1;
            $options['cc_label'][] = $field['label'];
            $options['cc_php'][] = 0;
            $options['cc_code'][] = '';
            $options['cc_sql'][] = '';
            $options['cc_settings'][] = '';
            $options['cc_type'][] = $field['type'];
            $options['cc_options'][] = '';
            $options['cc_value'][] = $field['label'];
            $options['cc_name'][] = $field['name'];
            $existingNames[] = $field['name'];
        }

        return $options;
    }

    /**
     * @return array<int, array{label:string,name:string,type:string,auto:true}>
     */
    private static function enabled_default_fields(?array $postTypes = null): array
    {
        $fields = [];
        foreach (self::enabled_default_field_names($postTypes) as $name) {
            $fields[] = [
                'label' => $name,
                'name' => $name,
                'type' => self::ADDON_SLUG,
                'auto' => true,
            ];
        }

        return $fields;
    }

    /**
     * @return string[]
     */
    private static function enabled_default_field_names(?array $postTypes = null): array
    {
        $postTypes = $postTypes ?? self::get_export_post_types();

        /*
         * WP All Export normally populates XmlExportEngine::$post_types
         * before requesting the available/default fields.
         *
         * Treat an unavailable/empty context as a regular post-like export
         * rather than falling back to the old site-wide WooCommerce check.
         */
        $hasProductExport = false;
        $hasDirectPostExport = empty($postTypes);

        foreach ($postTypes as $postType) {
            if (in_array($postType, self::ORDER_POST_TYPES, true)) {
                continue;
            }

            if (in_array($postType, self::PRODUCT_POST_TYPES, true)) {
                $hasProductExport = true;
                continue;
            }

            $hasDirectPostExport = true;
        }

        $names = [];

        if ($hasDirectPostExport) {
            $names = array_merge($names, self::DIRECT_IMAGE_FIELDS);
        }

        if ($hasProductExport) {
            $names = array_merge($names, self::PRODUCT_IMAGE_FIELDS);
        }

        if (get_option('fifu_video', 'toggleoff') === 'toggleon') {
            if ($hasDirectPostExport) {
                $names = array_merge($names, self::DIRECT_VIDEO_FIELDS);
            }

            if ($hasProductExport) {
                $names = array_merge($names, self::PRODUCT_VIDEO_FIELDS);
            }
        }

        if (($hasDirectPostExport || $hasProductExport)
            && get_option('fifu_slider', 'toggleoff') === 'toggleon') {
            $names = array_merge($names, self::SLIDER_FIELDS);
        }

        return array_values(array_unique($names));
    }

    /**
     * Resolves the content types selected by WP All Export.
     *
     * XmlExportEngine::$post_types is the primary source.
     * exportOptions['cpt'] is retained as a defensive fallback for lifecycle
     * points where WP All Export has the export options but has not yet copied
     * them into $post_types.
     *
     * @return string[]
     */
    private static function get_export_post_types(): array
    {
        if (!class_exists('XmlExportEngine')) {
            return [];
        }

        $postTypes = [];

        if (property_exists('XmlExportEngine', 'post_types')) {
            $rawPostTypes = \XmlExportEngine::$post_types;

            if (is_array($rawPostTypes)) {
                $postTypes = $rawPostTypes;
            } elseif (is_string($rawPostTypes) && $rawPostTypes !== '') {
                $postTypes = [$rawPostTypes];
            }
        }

        if (!$postTypes && property_exists('XmlExportEngine', 'exportOptions')) {
            $exportOptions = \XmlExportEngine::$exportOptions;

            if (is_array($exportOptions)) {
                $cpt = $exportOptions['cpt'] ?? [];

                if (is_string($cpt) && $cpt !== '') {
                    $postTypes = [$cpt];
                } elseif (is_array($cpt)) {
                    $postTypes = $cpt;
                }
            }
        }

        $normalized = [];

        foreach ($postTypes as $postType) {
            if (!is_string($postType) && !is_numeric($postType)) {
                continue;
            }

            $postType = trim((string) $postType);

            if ($postType === '') {
                continue;
            }

            $normalized[] = $postType;
        }

        return array_values(array_unique($normalized));
    }

    /**
     * Resolve post types from persisted export options before falling back to
     * engine state that may not be populated during the wizard controller hook.
     *
     * @param array<string, mixed> $options
     * @return string[]
     */
    private static function get_record_post_types(array $options): array
    {
        $cpt = $options['cpt'] ?? null;
        $postTypes = is_string($cpt) && $cpt !== '' ? [$cpt] : (is_array($cpt) ? $cpt : []);
        $normalized = [];

        foreach ($postTypes as $postType) {
            if (!is_string($postType) && !is_numeric($postType)) {
                continue;
            }

            $postType = trim((string) $postType);
            if ($postType !== '') {
                $normalized[] = $postType;
            }
        }

        return $normalized ? array_values(array_unique($normalized)) : self::get_export_post_types();
    }

    public static function export_field(
        $article,
        $fieldData,
        $exportOptions,
        $fieldIndex,
        $entry,
        $entryId,
        $xmlWriter,
        $elementName,
        $elementNameNs,
        $phpFunction,
        $preview
    ) {
        unset($fieldData, $exportOptions, $fieldIndex, $xmlWriter, $elementNameNs, $phpFunction, $preview);

        if (!is_array($article)) {
            return $article;
        }

        if (!is_string($elementName)) {
            return $article;
        }

        $name = $elementName;

        if (!in_array($name, self::FIELD_NAMES, true)) {
            return $article;
        }

        $postId = is_numeric($entryId) ? (int) $entryId : 0;

        if ($postId <= 0 && is_object($entry) && isset($entry->ID)) {
            if (!is_numeric($entry->ID)) {
                return $article;
            }

            $postId = (int) $entry->ID;
        }

        $value = self::resolve_export_value($name, $postId);
        self::write_article($article, $name, $value);

        return $article;
    }

    private static function write_article(array &$article, string &$elementName, $value): void
    {
        if (!array_key_exists($elementName, $article)) {
            $article[$elementName] = $value;
            return;
        }

        $baseName = $elementName;
        $index = 0;

        do {
            $elementName = $baseName . '_' . md5((string) $index);
            $index++;
        } while (array_key_exists($elementName, $article));

        $article[$elementName] = $value;
    }

    public static function resolve_export_value(string $fieldName, int $postId): string
    {
        if ($postId <= 0) {
            return '';
        }

        switch ($fieldName) {
            case 'meta:fifu_image_url':
                return (string) (Fifu_Post_Image_Url_Read_Service::get_image_url($postId) ?? '');

            case 'meta:fifu_image_alt':
                return (string) (Fifu_Post_Image_Alt_Read_Service::get_image_alt($postId) ?? '');

            case 'meta:fifu_video_url':
                return (string) (Fifu_Post_Video_Read_Service::get_video_url($postId) ?? '');

            case 'meta:fifu_list_url':
                return (string) (Fifu_Post_Image_List_Url_Read_Service::get_image_list_url($postId) ?? '');

            case 'meta:fifu_list_alt':
                return (string) (Fifu_Post_Image_List_Alt_Read_Service::get_image_list_alt($postId) ?? '');

            case 'meta:fifu_list_video_url':
                return (string) (Fifu_Post_Video_List_Url_Read_Service::get_video_list_url($postId) ?? '');

            case 'meta:fifu_slider_list_url':
                return (string) (Fifu_Post_Slider_List_Url_Read_Service::get_slider_list_url($postId) ?? '');

            case 'meta:fifu_slider_list_alt':
                return (string) (Fifu_Post_Slider_List_Alt_Read_Service::get_slider_list_alt($postId) ?? '');

            default:
                return '';
        }
    }
}
