<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/vendor/class-rapid-addon-fifu.php';

final class Fifu_Wai_Addon_Integration
{
    private const LOCAL_IMPORT_BATCH_SIZE = 50;
    private static ?RapidAddonFifu $addon = null;
    private static bool $importInProgress = false;
    private static bool $wpAllImportRequestActive = false;
    /** @var array<int, string> */
    private static array $cachedTermImageUrls = [];
    /** @var array<int, bool> */
    private static array $remoteDb2ImageListFastPathPostIds = [];
    private static ?int $currentWpAllImportPostId = null;
    /** @var array<int, bool> */
    private static array $wpAllImportProductPostIds = [];
    /**
     * @var array<string, array<int, bool>>
     */
    private static array $staged_import_queue = [
        'post' => [],
        'term' => [],
    ];

    public static function register_hooks(): void
    {
        // Comments must be in English.
        add_action('init', [self::class, 'run_addon'], 0);
        add_action('pmxi_before_xml_import', [self::class, 'handle_before_xml_import'], 10, 1);
        add_action('pmxi_saved_post', [self::class, 'handle_pmxi_saved_post'], 20, 3);
        add_action('pmxi_after_post_import', [self::class, 'handle_after_post_import'], PHP_INT_MAX, 1);
        add_action('pmxi_after_xml_import', [self::class, 'handle_after_xml_import'], 10, 1);
        add_action('shutdown', [self::class, 'clear_import_context_on_shutdown'], PHP_INT_MAX);
        add_filter('pmxi_delete_images', [self::class, 'filter_pmxi_delete_images'], PHP_INT_MAX, 3);
        add_filter('pmxi_is_images_to_update', [self::class, 'filter_pmxi_is_images_to_update'], PHP_INT_MAX, 4);
    }

    public static function run_addon(): void
    {
        if (self::$addon !== null) {
            self::$addon->run();
            return;
        }

        self::$addon = new RapidAddonFifu(
            '<div style="color:#777"><span class="dashicons dashicons-camera" style="font-size:30px;padding-right:10px"></span> FIFU</div>',
            'fifu_wai_addon'
        );

        $fifu = Fifu_Wai_Strings::get_strings();
        self::add_field('fifu_image_url', $fifu['title']['image'](), null);
        self::add_field('fifu_image_alt', $fifu['title']['title'](), $fifu['info']['alt']());
        self::add_field('fifu_video_url', $fifu['title']['video'](), null);
        self::add_field('fifu_list_url', $fifu['title']['images'](), $fifu['info']['delimited']());
        self::add_field('fifu_list_alt', $fifu['title']['titles'](), $fifu['info']['alts']());
        self::add_field('fifu_list_video_url', $fifu['title']['videos'](), $fifu['info']['delimited']());
        self::add_field('fifu_slider_list_url', $fifu['title']['slider'](), $fifu['info']['delimited']());
        self::add_field('fifu_slider_list_alt', $fifu['title']['titles'](), $fifu['info']['alts']());
        self::add_field('fifu_delimiter', $fifu['title']['delimiter'](), $fifu['info']['default']());
        self::add_field('fifu_asin', $fifu['title']['asin'](), null);
        self::add_field('fifu_finder_url', $fifu['title']['finder'](), $fifu['info']['finder']());
        self::add_field('fifu_redirection_url', $fifu['title']['redirection'](), null);

        self::$addon->set_import_function([self::class, 'handle_import']);
        self::$addon->run();
    }

    private static function sanitize_external_import_payload(array $data): array
    {
        $scalarFields = [
            'fifu_image_url',
            'fifu_image_alt',
            'fifu_video_url',
            'fifu_list_url',
            'fifu_list_alt',
            'fifu_list_video_url',
            'fifu_slider_list_url',
            'fifu_slider_list_alt',
            'fifu_delimiter',
            'fifu_asin',
            'fifu_finder_url',
            'fifu_redirection_url',
            'fifu_list_iframe_url',
        ];

        foreach ($scalarFields as $field) {
            if (!array_key_exists($field, $data)) {
                continue;
            }

            $value = $data[$field];

            if ($value !== null && !is_scalar($value)) {
                unset($data[$field]);
            }
        }

        return $data;
    }

    public static function handle_import(
        $post_id,
        $data,
        $import_options,
        $article
    ): void {
        $post_id = is_numeric($post_id) ? (int) $post_id : 0;

        if ($post_id <= 0 || !is_array($data) || !is_array($article)) {
            return;
        }

        $postTypeValue = $article['post_type'] ?? '';

        if ($postTypeValue !== null && !is_scalar($postTypeValue)) {
            return;
        }

        $article['post_type'] = (string) ($postTypeValue ?? '');
        $data = self::sanitize_external_import_payload($data);

        $postType = (string) ($article['post_type'] ?? '');
        $isProductImport = $postType === 'product';
        $is_ctgr = $postType === 'taxonomies';
        $isInsertImport = self::is_wai_insert_import($post_id, $import_options, $article);

        self::set_import_in_progress(true);
        try {
            $effectiveData = $data;
            // ISBN import support was removed. Ignore stale fields from old WP All Import templates.
            unset($data['fifu_isbn'], $effectiveData['fifu_isbn']);
            if (self::is_product_import($article, $is_ctgr)) {
                $effectiveData = self::apply_product_media_priority($effectiveData);
            }
            $useGalleryOnlyDb2Rebuild = false;
            $useVideoGalleryOnlyDb2Rebuild = false;
            $productListDb2Confirmed = false;
            $productListUrlsDb2Confirmed = false;
            $productListAltDb2Confirmed = false;
            $productListDb2UrlFailed = false;
            $fastProductImageListUrlsConfirmed = false;
            $fastProductImageListAltsConfirmed = false;
            $fastInsertFeaturedImageAltUrlConfirmed = false;
            $fastInsertFeaturedImageAltConfirmed = false;
            $waiVideoPriority = self::resolve_wai_video_priority($effectiveData, $article);
            $importCustomVideoSource = (string) ($data['fifu_video_url'] ?? '');
            $shouldGuardPostCustomFeaturedVideoLegacy = false;
            $postCustomFeaturedVideoLegacySnapshot = [];
            $preserveLegacyMeta = false;
            $previousPreserveLegacyMeta = null;
            if (
                self::should_skip_unchanged_featured_image_alt_update_without_snapshot(
                    $post_id,
                    $effectiveData,
                    $isInsertImport,
                    $is_ctgr,
                    $isProductImport
                )
            ) {
                return;
            }
            $legacyImageListSnapshot = self::snapshot_legacy_image_list_meta($post_id);
            $shouldGuardPostCustomFeaturedVideoLegacy =
                !$is_ctgr
                && !$isProductImport
                && $importCustomVideoSource !== ''
                && self::is_custom_featured_video_payload($importCustomVideoSource);
            if ($shouldGuardPostCustomFeaturedVideoLegacy) {
                $postCustomFeaturedVideoLegacySnapshot = [
                    'fifu_video_url' => get_post_meta($post_id, 'fifu_video_url', true),
                    'fifu_custom_video_url' => get_post_meta($post_id, 'fifu_custom_video_url', true),
                ];
            }
            if (self::$addon === null) {
                return;
            }

            if (
                $isProductImport
                && trim((string) ($data['fifu_video_url'] ?? '')) !== ''
                && trim((string) ($data['fifu_image_url'] ?? '')) === ''
                && trim((string) ($data['fifu_image_alt'] ?? '')) === ''
                && trim((string) ($data['fifu_list_url'] ?? '')) === ''
                && trim((string) ($data['fifu_list_alt'] ?? '')) === ''
                && trim((string) ($data['fifu_list_video_url'] ?? '')) === ''
                && trim((string) ($data['fifu_slider_list_url'] ?? '')) === ''
                && trim((string) ($data['fifu_slider_list_alt'] ?? '')) === ''
                && !array_key_exists('fifu_finder_url', $data)
                && !array_key_exists('fifu_redirection_url', $data)
            ) {
                self::queue_import_and_start_cron_if_needed($post_id, $is_ctgr);
                return;
            }

            if (
                $isProductImport
                && trim((string) ($effectiveData['fifu_list_url'] ?? '')) === ''
                && trim((string) ($effectiveData['fifu_slider_list_url'] ?? '')) === ''
                && trim((string) ($effectiveData['fifu_list_video_url'] ?? '')) === ''
                && trim((string) ($effectiveData['fifu_list_alt'] ?? '')) === ''
                && !array_key_exists('fifu_asin', $data)
                && !array_key_exists('fifu_finder_url', $data)
                && !array_key_exists('fifu_redirection_url', $data)
            ) {
                return;
            }

            $delimiter = (string) ($data['fifu_delimiter'] ?? '');
            $delimiter = $delimiter === '' ? '|' : $delimiter;
            $hasImageListImportPayload = self::has_wai_image_list_import_payload($data, $effectiveData, $import_options);
            $hasVideoListImportPayload = self::has_wai_video_list_import_payload($data, $effectiveData, $import_options);
            $hasSliderListImportPayload = self::has_wai_slider_list_import_payload($data, $effectiveData, $import_options);
            $hasProductSliderListPayload = $isProductImport && !empty($effectiveData['fifu_slider_list_url'] ?? '');
            $isCategoryImport = $is_ctgr;
            $hasPostSliderListPayload = !$isProductImport
                && !$isCategoryImport
                && isset($effectiveData['fifu_slider_list_url'])
                && trim((string) $effectiveData['fifu_slider_list_url']) !== '';

            $fields = [];
            $productUsesListOnlyMediaFields = $isProductImport && !$is_ctgr;
            $hasFifuPayload = self::has_any_fifu_payload($data);
            $hasSupportedFields = false;
            $hasIgnoredProductDirectMediaPayload =
                $productUsesListOnlyMediaFields
                && self::has_ignored_product_direct_featured_media_payload($data);
            $queueIgnoredProductPayload = false;
            $shouldQueueImportAfterFastInsertFeaturedImage = false;
            $productListUrl = trim((string) ($effectiveData['fifu_list_url'] ?? ''));
            $productListAlt = trim((string) ($effectiveData['fifu_list_alt'] ?? ''));
            $productImageUrl = trim((string) ($effectiveData['fifu_image_url'] ?? ''));
            $productImageAlt = trim((string) ($effectiveData['fifu_image_alt'] ?? ''));
            $ignored_product_image_payload =
                $productUsesListOnlyMediaFields
                && $productListUrl === ''
                && (
                    $productImageUrl !== ''
                    || $productImageAlt !== ''
                    || $productListAlt !== ''
                );
            $hasProductImageAltOnlyPayload =
                $productUsesListOnlyMediaFields
                && $productListAlt !== ''
                && $productListUrl === ''
                && trim((string) ($effectiveData['fifu_slider_list_url'] ?? '')) === ''
                && trim((string) ($effectiveData['fifu_list_video_url'] ?? '')) === '';
            $hasStandaloneFeaturedImageTitle =
                !$productUsesListOnlyMediaFields
                && !empty($effectiveData['fifu_image_alt'] ?? '')
                && empty($effectiveData['fifu_image_url'] ?? '')
                && empty($effectiveData['fifu_list_url'] ?? '')
                && empty($effectiveData['fifu_video_url'] ?? '')
                && empty($effectiveData['fifu_list_video_url'] ?? '')
                && empty($effectiveData['fifu_slider_list_url'] ?? '')
                && empty($effectiveData['fifu_list_alt'] ?? '')
                && empty($effectiveData['fifu_slider_list_alt'] ?? '');
            $hasFeaturedImagePayload = !$productUsesListOnlyMediaFields && !empty($effectiveData['fifu_image_url'] ?? '');
            $hasFeaturedAltPayload = !$productUsesListOnlyMediaFields && !empty($effectiveData['fifu_image_alt'] ?? '');
            $hasFeaturedVideoPayload = !$productUsesListOnlyMediaFields && !empty($effectiveData['fifu_video_url'] ?? '');
            $featuredImageUrlPayload = $productUsesListOnlyMediaFields ? '' : $productImageUrl;
            $featuredImageAltPayload = $productUsesListOnlyMediaFields ? '' : $productImageAlt;
            $fastPostSliderListResult = [];
            if (
                self::should_skip_unchanged_featured_image_alt_update(
                    $post_id,
                    $effectiveData,
                    $isInsertImport,
                    $is_ctgr,
                    $isProductImport,
                    $productUsesListOnlyMediaFields,
                    $legacyImageListSnapshot
                )
            ) {
                return;
            }
            $canUseFastInsertFeaturedImageAltPath = self::can_use_fast_insert_featured_image_alt_path(
                $post_id,
                $effectiveData,
                $isInsertImport,
                $is_ctgr,
                $isProductImport,
                $productUsesListOnlyMediaFields
            );
            if ($canUseFastInsertFeaturedImageAltPath) {
                $fastInsertFeaturedImageAltResult = self::persist_fast_insert_featured_image_alt(
                    $post_id,
                    $featuredImageUrlPayload,
                    $featuredImageAltPayload
                );
                $fastInsertFeaturedImageAltConfirmed =
                    !empty($fastInsertFeaturedImageAltResult['url_confirmed'])
                    && !empty($fastInsertFeaturedImageAltResult['alt_confirmed']);
                $fastInsertFeaturedImageAltUrlConfirmed = !empty($fastInsertFeaturedImageAltResult['url_confirmed']);

                if ($fastInsertFeaturedImageAltUrlConfirmed) {
                    $update = true;
                    $shouldQueueImportAfterFastInsertFeaturedImage = true;
                    $fields = array_values(array_filter(
                        $fields,
                        static function (string $field): bool {
                            return !in_array($field, ['fifu_image_url', 'fifu_image_alt'], true);
                        }
                    ));
                }
            }
            $requiresFeaturedImageAltPairConfirmation =
                !$is_ctgr
                && !$productUsesListOnlyMediaFields
                && !$fastInsertFeaturedImageAltUrlConfirmed
                && $featuredImageUrlPayload !== ''
                && $featuredImageAltPayload !== '';
            $hasNormalFeaturedVideoPayload = $hasFeaturedVideoPayload
                && (
                    !class_exists('Fifu_Video_Helper', false)
                    || !Fifu_Video_Helper::is_custom_video((string) $effectiveData['fifu_video_url'])
                );

            $hasSliderList = !empty($effectiveData['fifu_slider_list_url'] ?? '');
            $hasImageList = $productListUrl !== '';
            $hasVideoList = !empty($effectiveData['fifu_list_video_url'] ?? '');

            if ($hasSliderList) {
                $fields[] = 'fifu_slider_list_url';
                if (!empty($effectiveData['fifu_slider_list_alt'] ?? '')) {
                    $fields[] = 'fifu_slider_list_alt';
                }
                $hasSupportedFields = true;
            } elseif ($isProductImport) {
                if ($productListUrl !== '') {
                    $fields[] = 'fifu_list_url';
                    if ($productListAlt !== '') {
                        $fields[] = 'fifu_list_alt';
                    }
                    $hasSupportedFields = true;
                }
            } elseif ($hasImageList) {
                $fields[] = 'fifu_list_url';

                if (!empty($effectiveData['fifu_list_alt'] ?? '')) {
                    $fields[] = 'fifu_list_alt';
                }
                $hasSupportedFields = true;
            } elseif ($hasProductImageAltOnlyPayload) {
                $fields[] = 'fifu_list_alt';
                $hasSupportedFields = true;
            } elseif ($hasVideoList) {
                $fields[] = 'fifu_list_video_url';
                $hasSupportedFields = true;
            } elseif (
                !$productUsesListOnlyMediaFields
                && !$fastInsertFeaturedImageAltUrlConfirmed
                && !empty($effectiveData['fifu_image_url'] ?? '')
                && empty($effectiveData['fifu_video_url'] ?? '')
            ) {
                $fields[] = 'fifu_image_url';

                if (!empty($effectiveData['fifu_image_alt'] ?? '')) {
                    $fields[] = 'fifu_image_alt';
                }
                $hasSupportedFields = true;
            }

            if (empty($effectiveData['fifu_list_video_url'] ?? '')) {
                if (!$productUsesListOnlyMediaFields && !empty($effectiveData['fifu_video_url'] ?? '') && !$hasSliderList) {
                    $fields[] = 'fifu_video_url';
                }
            } else {
                if (!$productUsesListOnlyMediaFields && $isProductImport && $hasNormalFeaturedVideoPayload) {
                    $fields[] = 'fifu_video_url';
                }
            }


            if (self::has_wai_effective_scalar_import_payload('fifu_asin', $data, $effectiveData, $import_options)) {
                $fields[] = 'fifu_asin';
            }

            if (self::has_wai_effective_scalar_import_payload('fifu_finder_url', $data, $effectiveData, $import_options)) {
                $fields[] = 'fifu_finder_url';
            }

            if (self::has_wai_effective_scalar_import_payload('fifu_redirection_url', $data, $effectiveData, $import_options)) {
                $fields[] = 'fifu_redirection_url';
                $hasSupportedFields = true;
            }

            $fields = array_values(array_unique($fields));
            $queueIgnoredProductPayload = $isProductImport && $hasIgnoredProductDirectMediaPayload && empty($fields);

            $useGalleryOnlyDb2Rebuild = !$productUsesListOnlyMediaFields && self::should_use_gallery_only_db2_rebuild_for_product($post_id, $effectiveData, $article);
            $hasImageList = trim((string) ($effectiveData['fifu_list_url'] ?? '')) !== '';
            $hasVideoList = trim((string) ($effectiveData['fifu_list_video_url'] ?? '')) !== '';
            $shouldPreserveMixedMediaImageList = !$is_ctgr && $hasImageList && $hasVideoList;
            if ($is_ctgr) {
                // Category/term image imports still need the DB2 key to exist.
                self::ensure_image_key_exists();
            }
            if ($useGalleryOnlyDb2Rebuild) {
                self::set_gallery_only_db2_rebuild_context($post_id, 'fifu_list_url', true);
                self::set_gallery_only_db2_rebuild_context($post_id, 'fifu_list_alt', true);
            }
            $useVideoGalleryOnlyDb2Rebuild = self::should_use_video_gallery_only_db2_rebuild_for_product($post_id, $effectiveData, $article);
            if ($useVideoGalleryOnlyDb2Rebuild) {
                self::set_video_gallery_only_db2_rebuild_context($post_id, 'fifu_list_video_url', true);
            }
            if ($shouldPreserveMixedMediaImageList) {
                if (!isset($GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import']) || !is_array($GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import'])) {
                    $GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import'] = [];
                }
                $GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import'][(string) $post_id] = true;
            }
            $preserveLegacyMeta = false;
            $previousPreserveLegacyMeta = null;
            $shouldPreserveTermFeaturedImageLegacyMeta = $is_ctgr
                && $featuredImageUrlPayload !== ''
                && $featuredImageAltPayload !== '';
            if (
                (
                    !$is_ctgr
                    && !empty($effectiveData['fifu_video_url'] ?? '')
                    && class_exists('Fifu_Video_Helper', false)
                    && Fifu_Video_Helper::is_custom_video((string) $effectiveData['fifu_video_url'])
                )
            ) {
                $preserveLegacyMeta = true;
                $previousPreserveLegacyMeta = $_REQUEST['fifu_preserve_legacy_meta_until_db2_confirmation'] ?? null;
                $_REQUEST['fifu_preserve_legacy_meta_until_db2_confirmation'] = 1;
            }
            if ($shouldPreserveTermFeaturedImageLegacyMeta) {
                $preserveLegacyMeta = true;
                $previousPreserveLegacyMeta = $_REQUEST['fifu_preserve_legacy_meta_until_db2_confirmation'] ?? null;
                $_REQUEST['fifu_preserve_legacy_meta_until_db2_confirmation'] = 1;
            }

            if (empty($fields) && !$queueIgnoredProductPayload) {
                if ($shouldQueueImportAfterFastInsertFeaturedImage) {
                    self::queue_import_and_start_cron_if_needed($post_id, $is_ctgr);
                    return;
                }

                if (Fifu_Options_Utils::is_off('fifu_enable_default_url')) {
                    return;
                }
            }

            try {
                $update = false;
                foreach ($fields as $field) {
                    $incoming = $effectiveData[$field] ?? '';
                    $normalized = self::fifu_normalize_wai_field_value($field, $incoming, $delimiter);

                    if (
                        $hasPostSliderListPayload
                        && in_array($field, ['fifu_slider_list_url', 'fifu_slider_list_alt'], true)
                    ) {
                        continue;
                    }

                    if (
                        $isProductImport
                        && in_array($field, ['fifu_list_url', 'fifu_list_alt', 'fifu_slider_list_url', 'fifu_slider_list_alt'], true)
                    ) {
                        continue;
                    }

                    if (
                        $field === 'fifu_video_url'
                        && self::is_custom_featured_video_payload((string) $incoming)
                    ) {
                        $rawCustomVideo = (string) ($effectiveData['fifu_video_url'] ?? '');
                        self::persist_wai_custom_featured_video($post_id, $rawCustomVideo, $is_ctgr);
                        continue;
                    }

                    if (
                        $isInsertImport
                        && !$is_ctgr
                        && !$productUsesListOnlyMediaFields
                        && in_array($field, ['fifu_image_url', 'fifu_image_alt'], true)
                    ) {
                        $update = true;
                        {
                                if ($is_ctgr) {
                                    fifu_update_or_delete_ctgr($post_id, $field, $normalized);
                                } elseif ($field === 'fifu_image_url') {
                                    self::update_post_meta_with_db2_status($post_id, $field, $normalized);
                                } elseif ($field === 'fifu_image_alt') {
                                    self::update_post_meta_with_db2_status($post_id, $field, $normalized);
                                } else {
                                    fifu_update_or_delete($post_id, $field, $normalized);
                                }
                        }
                        continue;
                    }

                    $current_value = self::get_current_value_db2_first($post_id, $field, $is_ctgr);
                    $shouldPersist = $current_value !== $normalized;
                    if (
                        !$shouldPersist
                        && $normalized === ''
                        && in_array($field, ['fifu_asin', 'fifu_finder_url', 'fifu_redirection_url'], true)
                        && self::is_wai_field_explicitly_mapped($field, $import_options)
                    ) {
                        $shouldPersist = true;
                    }
                    if (
                        $is_ctgr
                        && in_array($field, ['fifu_image_url', 'fifu_image_alt'], true)
                        && $normalized !== ''
                    ) {
                        $shouldPersist = true;
                    } elseif (!$shouldPersist) {
                        $shouldPersist = self::should_force_db2_write_for_import_field(
                            $post_id,
                            $field,
                            $normalized,
                            $is_ctgr
                        );
                    }
                    if ($shouldPersist) {
                        $update = true;
                        {
                                if ($is_ctgr && $field === 'fifu_image_url' && $normalized !== '') {
                                    self::cache_term_image_url($post_id, $normalized);
                                }
                                if ($is_ctgr) {
                                    fifu_update_or_delete_ctgr($post_id, $field, $normalized);
                                } elseif ($field === 'fifu_asin') {
                                    self::persist_wai_asin($post_id, $normalized);
                                } elseif ($field === 'fifu_finder_url') {
                                    self::persist_wai_finder_url($post_id, $normalized);
                                } elseif ($field === 'fifu_redirection_url') {
                                    self::persist_wai_redirection_url($post_id, $normalized);
                                } elseif (!$isProductImport && !$is_ctgr && $field === 'fifu_image_url') {
                                    $db2Snapshot = self::snapshot_post_featured_image_db2_state($post_id);
                                    $ok = self::update_post_meta_with_db2_status($post_id, $field, $normalized);
                                    if (!$ok && $normalized !== '') {
                                        self::restore_post_featured_image_db2_state_after_failure($post_id, $db2Snapshot, $normalized);
                                        self::set_raw_post_meta($post_id, 'fifu_image_url', $normalized);
                                        clean_post_cache($post_id);
                                        wp_cache_delete($post_id, 'post_meta');
                                    }
                                } else {
                                    fifu_update_or_delete($post_id, $field, $normalized);
                                }
                        }
                    }
                }
            } finally {
                if ($preserveLegacyMeta && !$shouldPreserveTermFeaturedImageLegacyMeta && !$shouldGuardPostCustomFeaturedVideoLegacy) {
                    if ($previousPreserveLegacyMeta === null) {
                        unset($_REQUEST['fifu_preserve_legacy_meta_until_db2_confirmation']);
                    } else {
                        $_REQUEST['fifu_preserve_legacy_meta_until_db2_confirmation'] = $previousPreserveLegacyMeta;
                    }
                }
                if (!empty($useVideoGalleryOnlyDb2Rebuild)) {
                    self::clear_video_gallery_only_db2_rebuild_context($post_id, 'fifu_list_video_url');
                    unset($_REQUEST['fifu_wai_gallery_only_video_list_url']);
                }
            }

            $normalized_import_options = self::normalize_import_options($import_options);
            if (!$update && !$queueIgnoredProductPayload && !self::$addon->can_update_image($normalized_import_options)) {
                if ($isProductImport && !empty($effectiveData['fifu_list_url'] ?? '')) {
                    if (self::product_image_list_db2_state_matches_payload($post_id, $effectiveData, $delimiter)) {
                        self::cleanup_legacy_image_url_fields_after_db2_url_confirmation($post_id);
                        self::cleanup_legacy_image_alt_fields_after_db2_alt_confirmation($post_id);
                        self::clear_gallery_only_db2_rebuild_context($post_id, 'fifu_list_url');
                        self::clear_gallery_only_db2_rebuild_context($post_id, 'fifu_list_alt');
                        return;
                    }

                    self::preserve_product_legacy_image_url_fields_after_db2_url_failure(
                        $post_id,
                        $effectiveData,
                        $legacyImageListSnapshot
                    );
                }
                return;
            }

            if ($queueIgnoredProductPayload && empty($fields)) {
                self::queue_import_and_start_cron_if_needed($post_id, $is_ctgr);
                return;
            }

            $previousGalleryOnlyImageListUrl = $_REQUEST['fifu_wai_gallery_only_image_list_url'] ?? null;
            $previousGalleryOnlyImageListAlt = $_REQUEST['fifu_wai_gallery_only_image_list_alt'] ?? null;
            $previousImageListUrl = $_REQUEST['fifu_wai_image_list_url'] ?? null;
            $previousImageListAlt = $_REQUEST['fifu_wai_image_list_alt'] ?? null;
            $previousVideoGalleryOnlyListUrl = $_REQUEST['fifu_wai_gallery_only_video_list_url'] ?? null;
            $previousVideoListUrl = $_REQUEST['fifu_wai_video_list_url'] ?? null;
                $previousSliderGalleryOnlyListAlt = $_REQUEST['fifu_wai_gallery_only_slider_list_alt'] ?? null;
                $previousSliderGalleryOnlyListUrl = $_REQUEST['fifu_wai_gallery_only_slider_list_url'] ?? null;
                $previousCustomVideoSource = $_REQUEST['fifu_wai_custom_video_source'] ?? null;
                $fastProductSliderListResult = [];
                $preexistingDb2ImageMappings = self::has_preexisting_db2_image_mappings($post_id, $legacyImageListSnapshot);

            if ($productListUrl !== '') {
                $_REQUEST['fifu_wai_image_list_url'] = self::fifu_normalize_wai_field_value(
                    'fifu_list_url',
                    $productListUrl,
                    $delimiter
                );
            } else {
                unset($_REQUEST['fifu_wai_image_list_url']);
            }

            if ($productListAlt !== '') {
                $_REQUEST['fifu_wai_image_list_alt'] = self::fifu_normalize_wai_field_value(
                    'fifu_list_alt',
                    $productListAlt,
                    $delimiter
                );
            } else {
                unset($_REQUEST['fifu_wai_image_list_alt']);
            }

            if ($useGalleryOnlyDb2Rebuild) {
                $_REQUEST['fifu_wai_gallery_only_image_list_url'] = self::fifu_normalize_wai_field_value(
                    'fifu_list_url',
                    (string) ($effectiveData['fifu_list_url'] ?? ''),
                    $delimiter
                );
                $_REQUEST['fifu_wai_gallery_only_image_list_alt'] = self::fifu_normalize_wai_field_value(
                    'fifu_list_alt',
                    (string) ($effectiveData['fifu_list_alt'] ?? ''),
                    $delimiter
                );
            } else {
                unset($_REQUEST['fifu_wai_gallery_only_image_list_url'], $_REQUEST['fifu_wai_gallery_only_image_list_alt']);
            }

            if ($useVideoGalleryOnlyDb2Rebuild) {
                $_REQUEST['fifu_wai_gallery_only_video_list_url'] = self::fifu_normalize_wai_field_value(
                    'fifu_list_video_url',
                    (string) ($effectiveData['fifu_list_video_url'] ?? ''),
                    $delimiter
                );
            } else {
                unset($_REQUEST['fifu_wai_gallery_only_video_list_url']);
            }

            $hasProductVideoListPayload =
                array_key_exists('fifu_list_video_url', $effectiveData)
                && trim((string) ($effectiveData['fifu_list_video_url'] ?? '')) !== '';

            if ($hasProductVideoListPayload) {
                $_REQUEST['fifu_wai_video_list_url'] = self::fifu_normalize_wai_field_value(
                    'fifu_list_video_url',
                    (string) ($effectiveData['fifu_list_video_url'] ?? ''),
                    $delimiter
                );
            } else {
                if ($previousVideoListUrl === null) {
                    unset($_REQUEST['fifu_wai_video_list_url']);
                } else {
                    $_REQUEST['fifu_wai_video_list_url'] = $previousVideoListUrl;
                }
            }

            if (!empty($effectiveData['fifu_slider_list_alt'] ?? '')) {
                $_REQUEST['fifu_wai_gallery_only_slider_list_alt'] = self::fifu_normalize_wai_field_value(
                    'fifu_slider_list_alt',
                    (string) ($effectiveData['fifu_slider_list_alt'] ?? ''),
                    $delimiter
                );
            } else {
                unset($_REQUEST['fifu_wai_gallery_only_slider_list_alt']);
            }

            if (!empty($effectiveData['fifu_slider_list_url'] ?? '')) {
                $_REQUEST['fifu_wai_gallery_only_slider_list_url'] = self::fifu_normalize_wai_field_value(
                    'fifu_slider_list_url',
                    (string) ($effectiveData['fifu_slider_list_url'] ?? ''),
                    $delimiter
                );
            } else {
                unset($_REQUEST['fifu_wai_gallery_only_slider_list_url']);
            }

            if (
                !$productUsesListOnlyMediaFields
                && $importCustomVideoSource !== ''
                && self::is_custom_featured_video_payload($importCustomVideoSource)
            ) {
                $_REQUEST['fifu_wai_custom_video_source'] = $importCustomVideoSource;
            } else {
                unset($_REQUEST['fifu_wai_custom_video_source']);
            }

            try {
                self::clear_wai_media_request_keys();
                if ($productListUrl !== '') {
                    $_REQUEST['fifu_wai_image_list_url'] = self::fifu_normalize_wai_field_value('fifu_list_url', $productListUrl, $delimiter);
                }
                if ($productListAlt !== '') {
                    $_REQUEST['fifu_wai_image_list_alt'] = self::fifu_normalize_wai_field_value('fifu_list_alt', $productListAlt, $delimiter);
                }
                if ($hasProductVideoListPayload) {
                    $_REQUEST['fifu_wai_video_list_url'] = self::fifu_normalize_wai_field_value('fifu_list_video_url', (string) ($effectiveData['fifu_list_video_url'] ?? ''), $delimiter);
                }
                if (!empty($effectiveData['fifu_slider_list_url'] ?? '')) {
                    $_REQUEST['fifu_wai_gallery_only_slider_list_url'] = self::fifu_normalize_wai_field_value('fifu_slider_list_url', (string) ($effectiveData['fifu_slider_list_url'] ?? ''), $delimiter);
                }
                if (!empty($effectiveData['fifu_slider_list_alt'] ?? '')) {
                    $_REQUEST['fifu_wai_gallery_only_slider_list_alt'] = self::fifu_normalize_wai_field_value('fifu_slider_list_alt', (string) ($effectiveData['fifu_slider_list_alt'] ?? ''), $delimiter);
                }
                if ($isProductImport) {
                    $hasProductSliderList = $hasProductSliderListPayload;
                    $hasProductImageList = $productListUrl !== '' || $productListAlt !== '';
                    $handledProductListPayload = false;
                    $fastProductSliderListResult = [];

                    if ($hasProductSliderList) {
                        $fastProductSliderListResult = Fifu_Wai_Meta_Service::save_product_slider_list_fast_from_import_payload(
                            $post_id,
                            (string) ($_REQUEST['fifu_wai_gallery_only_slider_list_url'] ?? ''),
                            (string) ($_REQUEST['fifu_wai_gallery_only_slider_list_alt'] ?? ''),
                            true
                        );
                        $handledProductListPayload = true;
                    } elseif (!$queueIgnoredProductPayload) {
                        if ($hasProductImageList) {
                            if (
                                self::should_skip_unchanged_product_image_list_update(
                                    $post_id,
                                    $effectiveData,
                                    $delimiter,
                                    $isInsertImport,
                                    $is_ctgr,
                                    $isProductImport,
                                    $legacyImageListSnapshot
                                )
                            ) {
                                return;
                            }

                            $fastProductImageListHandled = false;

                            if (
                                !$hasProductVideoListPayload
                                && method_exists(Fifu_Wai_Meta_Service::class, 'save_product_image_list_fast_from_import_payload')
                            ) {
                                $fastProductImageListResult = Fifu_Wai_Meta_Service::save_product_image_list_fast_from_import_payload(
                                    $post_id,
                                    (string) ($_REQUEST['fifu_wai_image_list_url'] ?? ''),
                                    (string) ($_REQUEST['fifu_wai_image_list_alt'] ?? ''),
                                    (bool) $waiVideoPriority
                                );

                            if (is_array($fastProductImageListResult)) {
                                $fastProductImageListUrlsConfirmed = !empty($fastProductImageListResult['urls_confirmed']);
                                $fastProductImageListAltsConfirmed = !empty($fastProductImageListResult['alts_confirmed']);

                                    if ($fastProductImageListUrlsConfirmed) {
                                        $fastProductImageListHandled = true;
                                        self::mark_remote_db2_image_list_fast_path_post($post_id);
                                        if (class_exists('Fifu_Post_Attachment_Sync_Service', false)) {
                                            Fifu_Post_Attachment_Sync_Service::sync_featured_attachment($post_id, true);
                                            if (method_exists('Fifu_Post_Attachment_Sync_Service', 'sync_product_gallery_attachments_from_db2_image_list')) {
                                                Fifu_Post_Attachment_Sync_Service::sync_product_gallery_attachments_from_db2_image_list($post_id);
                                            }
                                        }
                                    }
                                }
                            }

                            if (!$fastProductImageListHandled) {
                                Fifu_Wai_Meta_Service::save_image_list($post_id, $is_ctgr, $waiVideoPriority);
                            }
                            $handledProductListPayload = true;
                        }

                        if ($hasProductVideoListPayload) {
                            Fifu_Wai_Meta_Service::save_video_list($post_id, $is_ctgr, $waiVideoPriority);
                            $handledProductListPayload = true;
                        }

                        if (! $handledProductListPayload) {
                            Fifu_Wai_Meta_Service::save_image_list($post_id, $is_ctgr, $waiVideoPriority);
                            Fifu_Wai_Meta_Service::save_video_list($post_id, $is_ctgr, $waiVideoPriority);
                            Fifu_Wai_Meta_Service::save_slider_list($post_id);
                        }
                    }

                } else {
                    $preserveLegacyCategoryBehavior = $is_ctgr;

                    if ($preserveLegacyCategoryBehavior || $hasImageListImportPayload) {
                        Fifu_Wai_Meta_Service::save_image_list($post_id, $is_ctgr, $waiVideoPriority);
                    }

                    if ($preserveLegacyCategoryBehavior || $hasVideoListImportPayload) {
                        Fifu_Wai_Meta_Service::save_video_list($post_id, $is_ctgr, $waiVideoPriority);
                    }

                    if ($preserveLegacyCategoryBehavior || $hasSliderListImportPayload) {
                        if ($hasPostSliderListPayload) {
                            if (
                                self::should_skip_unchanged_post_slider_list_update(
                                    $post_id,
                                    $effectiveData,
                                    $isInsertImport,
                                    $is_ctgr,
                                    $isProductImport
                                )
                            ) {
                                if (
                                    self::should_queue_unchanged_property_slider_metadata_repair(
                                        $post_id,
                                        $effectiveData,
                                        $postType
                                    )
                                ) {
                                    self::queue_import_and_start_cron_if_needed($post_id, false);
                                }

                                return;
                            }

                            $rawPostSliderListUrl = (string) ($effectiveData['fifu_slider_list_url'] ?? '');
                            $rawPostSliderListAlt = (string) ($effectiveData['fifu_slider_list_alt'] ?? '');
                            self::update_raw_post_meta($post_id, 'fifu_slider_list_url', $rawPostSliderListUrl);
                            if (trim($rawPostSliderListAlt) !== '') {
                                self::update_raw_post_meta($post_id, 'fifu_slider_list_alt', $rawPostSliderListAlt);
                            } else {
                                self::delete_raw_post_meta($post_id, 'fifu_slider_list_alt');
                            }
                            $fastPostSliderListResult = Fifu_Wai_Meta_Service::save_slider_list_fast_from_import_payload(
                                $post_id,
                                (string) ($_REQUEST['fifu_wai_gallery_only_slider_list_url'] ?? ''),
                                (string) ($_REQUEST['fifu_wai_gallery_only_slider_list_alt'] ?? ''),
                                true
                            );
                        } else {
                            Fifu_Wai_Meta_Service::save_slider_list($post_id);
                        }
                    }
                }
                if (
                    !$is_ctgr
                    && (!empty($effectiveData['fifu_slider_list_url'] ?? '') || !empty($effectiveData['fifu_slider_list_alt'] ?? ''))
                ) {
                    if ($hasPostSliderListPayload) {
                        self::cleanup_slider_legacy_postmeta_after_db2_confirmation(
                            $post_id,
                            $effectiveData,
                            $delimiter,
                            $fastPostSliderListResult
                        );
                    } else {
                        self::cleanup_slider_legacy_postmeta_after_db2_confirmation(
                            $post_id,
                            $effectiveData,
                            $delimiter,
                            $fastProductSliderListResult
                        );
                    }
                }
                if ($shouldGuardPostCustomFeaturedVideoLegacy) {
                    self::restore_post_custom_featured_video_legacy_source_if_not_confirmed(
                        $post_id,
                        $importCustomVideoSource,
                        $postCustomFeaturedVideoLegacySnapshot
                    );
                    self::ensure_post_custom_featured_video_db2_mapping(
                        $post_id,
                        $importCustomVideoSource
                    );
                }
                if (
                    $isInsertImport
                    && !$fastInsertFeaturedImageAltUrlConfirmed
                    && $featuredImageUrlPayload !== ''
                    && $featuredImageAltPayload !== ''
                ) {
                    $expectedUrl = self::normalize_wai_featured_image_url_for_db2_confirmation($featuredImageUrlPayload);
                    $expectedAlt = self::normalize_wai_featured_image_alt_for_db2_confirmation($featuredImageAltPayload);
                    if ($expectedUrl !== '' && $expectedAlt !== '') {
                        self::is_post_featured_image_and_alt_confirmed_in_db2($post_id, $expectedUrl, $expectedAlt);
                    }
                } elseif ($requiresFeaturedImageAltPairConfirmation) {
                    $expectedUrl = self::normalize_wai_featured_image_url_for_db2_confirmation($featuredImageUrlPayload);
                    $expectedAlt = self::normalize_wai_featured_image_alt_for_db2_confirmation($featuredImageAltPayload);

                    if ($expectedUrl !== '' && $expectedAlt !== '') {
                        $previousFeaturedPreserveLegacyMeta = $_REQUEST['fifu_preserve_legacy_meta_until_db2_confirmation'] ?? null;
                        $_REQUEST['fifu_preserve_legacy_meta_until_db2_confirmation'] = '1';

                        try {
                            $expectedUrl = self::normalize_wai_featured_image_url_for_db2_confirmation($featuredImageUrlPayload);
                            $expectedAlt = self::normalize_wai_featured_image_alt_for_db2_confirmation($featuredImageAltPayload);
                            if ($expectedUrl !== '' && $expectedAlt !== '') {
                                update_post_meta($post_id, 'fifu_image_url', wp_slash($expectedUrl));
                                update_post_meta($post_id, 'fifu_image_alt', wp_slash($expectedAlt));
                                fifu_update_or_delete($post_id, 'fifu_image_url', $expectedUrl);
                                fifu_update_or_delete($post_id, 'fifu_image_alt', $expectedAlt);
                                self::cleanup_post_featured_image_and_alt_legacy_after_db2_confirmation($post_id, $expectedUrl, $expectedAlt);
                            }
                        } finally {
                            if ($previousFeaturedPreserveLegacyMeta === null) {
                                unset($_REQUEST['fifu_preserve_legacy_meta_until_db2_confirmation']);
                            } else {
                                $_REQUEST['fifu_preserve_legacy_meta_until_db2_confirmation'] = $previousFeaturedPreserveLegacyMeta;
                            }
                        }
                    }
                }
                if (
                    $isProductImport
                    && class_exists('Fifu_Legacy_Media_Meta_Cleanup_Service', false)
                ) {
                    $manager = function_exists('fifu_db2_manager') ? fifu_db2_manager() : null;
                    $db2Confirmed = $manager instanceof Fifu_Db2_Manager;

                    if ($db2Confirmed && !empty($effectiveData['fifu_list_url'] ?? '')) {
                        $expectedGalleryUrls = self::split_normalized_wai_list(
                            self::fifu_normalize_wai_field_value(
                                'fifu_list_url',
                                (string) ($effectiveData['fifu_list_url'] ?? ''),
                                $delimiter
                            )
                        );
                        $expectedGalleryAlts = self::split_normalized_wai_alt_list_preserve_empty_slots(
                            self::fifu_normalize_wai_field_value(
                                'fifu_list_alt',
                                (string) ($effectiveData['fifu_list_alt'] ?? ''),
                                $delimiter
                            )
                        );

                        if ($fastProductImageListUrlsConfirmed) {
                            $urlsConfirmed = true;
                        } else {
                            $urlsConfirmed = true;
                            foreach ($expectedGalleryUrls as $index => $expectedGalleryUrl) {
                                $mapping = $manager->getPostMapping($post_id, 'image', $index);
                                if (!is_array($mapping) || (string) ($mapping['url'] ?? '') !== $expectedGalleryUrl) {
                                    $urlsConfirmed = false;
                                    break;
                                }
                            }
                        }

                        if ($fastProductImageListAltsConfirmed) {
                            $altsConfirmed = true;
                        } else {
                            $altsConfirmed = true;
                            foreach ($expectedGalleryUrls as $index => $_expectedGalleryUrl) {
                                $expectedGalleryAlt = trim((string) ($expectedGalleryAlts[$index] ?? ''));
                                $mapping = $manager->getPostAltMapping($post_id, 'image', $index);

                                if ($expectedGalleryAlt === '') {
                                    if (is_array($mapping) && trim((string) ($mapping['alt'] ?? '')) !== '') {
                                        $altsConfirmed = false;
                                        break;
                                    }
                                    continue;
                                }

                                if (!is_array($mapping) || (string) ($mapping['alt'] ?? '') !== $expectedGalleryAlt) {
                                    $altsConfirmed = false;
                                    break;
                                }
                            }
                        }

                        if ($urlsConfirmed) {
                            $productListUrlsDb2Confirmed = true;
                            if ($altsConfirmed) {
                                $productListAltDb2Confirmed = true;
                                if (method_exists(Fifu_Wai_Meta_Service::class, 'was_last_image_list_db2_urls_confirmed')
                                    && Fifu_Wai_Meta_Service::was_last_image_list_db2_urls_confirmed()
                                    && self::db2_key_type_exists('image')) {
                                    self::cleanup_legacy_image_url_fields_after_db2_url_confirmation($post_id);
                                    self::cleanup_legacy_image_alt_fields_after_db2_alt_confirmation($post_id);
                                    $productListDb2Confirmed = true;
                                }
                                if (
                                    !empty($effectiveData['fifu_list_url'] ?? '')
                                    && array_key_exists('fifu_list_alt', $effectiveData)
                                    && array_key_exists('fifu_list_alt', $legacyImageListSnapshot)
                                ) {
                                    self::set_raw_post_meta(
                                        $post_id,
                                        'fifu_list_alt',
                                        (string) ($effectiveData['fifu_list_alt'] ?? '')
                                    );
                                }
                            } else {
                                $productListAltDb2Confirmed = false;
                                self::preserve_product_legacy_image_alt_fields_after_db2_alt_failure(
                                    $post_id,
                                    $effectiveData,
                                    $legacyImageListSnapshot,
                                    $preexistingDb2ImageMappings
                                );
                            }
                        } else {
                            $productListUrlsDb2Confirmed = false;
                            $productListDb2UrlFailed = true;
                            self::preserve_product_legacy_image_url_fields_after_db2_url_failure(
                                $post_id,
                                $effectiveData,
                                $legacyImageListSnapshot
                            );
                        }
                    }
                }
                if ($is_ctgr) {
                    self::confirm_term_image_db2_write($post_id, (string) ($effectiveData['fifu_image_url'] ?? ''));
                    if ($shouldPreserveTermFeaturedImageLegacyMeta) {
                        self::cleanup_term_featured_image_and_alt_legacy_after_db2_confirmation(
                            $post_id,
                            self::normalize_wai_featured_image_url_for_db2_confirmation($featuredImageUrlPayload),
                            self::normalize_wai_featured_image_alt_for_db2_confirmation($featuredImageAltPayload)
                        );
                    }
                }
            } finally {
                if ($shouldPreserveMixedMediaImageList && isset($GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import']) && is_array($GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import'])) {
                    unset($GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import'][(string) $post_id]);
                    if (empty($GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import'])) {
                        unset($GLOBALS['__fifu_preserve_db2_image_list_for_mixed_media_import']);
                    }
                }
                if ($previousGalleryOnlyImageListUrl === null) {
                    unset($_REQUEST['fifu_wai_gallery_only_image_list_url']);
                } else {
                    $_REQUEST['fifu_wai_gallery_only_image_list_url'] = $previousGalleryOnlyImageListUrl;
                }

                if ($previousGalleryOnlyImageListAlt === null) {
                    unset($_REQUEST['fifu_wai_gallery_only_image_list_alt']);
                } else {
                    $_REQUEST['fifu_wai_gallery_only_image_list_alt'] = $previousGalleryOnlyImageListAlt;
                }

                if ($previousImageListUrl === null) {
                    unset($_REQUEST['fifu_wai_image_list_url']);
                } else {
                    $_REQUEST['fifu_wai_image_list_url'] = $previousImageListUrl;
                }

                if ($previousImageListAlt === null) {
                    unset($_REQUEST['fifu_wai_image_list_alt']);
                } else {
                    $_REQUEST['fifu_wai_image_list_alt'] = $previousImageListAlt;
                }

                if ($previousVideoGalleryOnlyListUrl === null) {
                    unset($_REQUEST['fifu_wai_gallery_only_video_list_url']);
                } else {
                    $_REQUEST['fifu_wai_gallery_only_video_list_url'] = $previousVideoGalleryOnlyListUrl;
                }

                unset($_REQUEST['fifu_wai_video_list_url']);

                if ($previousSliderGalleryOnlyListAlt === null) {
                    unset($_REQUEST['fifu_wai_gallery_only_slider_list_alt']);
                } else {
                    $_REQUEST['fifu_wai_gallery_only_slider_list_alt'] = $previousSliderGalleryOnlyListAlt;
                }

                if ($previousSliderGalleryOnlyListUrl === null) {
                    unset($_REQUEST['fifu_wai_gallery_only_slider_list_url']);
                } else {
                    $_REQUEST['fifu_wai_gallery_only_slider_list_url'] = $previousSliderGalleryOnlyListUrl;
                }

                if ($previousCustomVideoSource === null) {
                    unset($_REQUEST['fifu_wai_custom_video_source']);
                } else {
                    $_REQUEST['fifu_wai_custom_video_source'] = $previousCustomVideoSource;
                }
            }

            if ($isProductImport && $useGalleryOnlyDb2Rebuild) {
                if (!empty($effectiveData['fifu_image_url'] ?? '')) {
                    fifu_update_or_delete($post_id, 'fifu_image_url', (string) $effectiveData['fifu_image_url']);
                }

                if (!empty($effectiveData['fifu_image_alt'] ?? '')) {
                    fifu_update_or_delete($post_id, 'fifu_image_alt', (string) $effectiveData['fifu_image_alt']);
                }
            }

            if ($hasStandaloneFeaturedImageTitle) {
                return;
            }

            if (self::should_skip_product_import_queue_for_orphan_image_titles($effectiveData, $preexistingDb2ImageMappings)) {
                self::cleanup_product_legacy_image_alt_fields_only($post_id);
                clean_post_cache($post_id);
                wp_cache_delete($post_id, 'post_meta');
                return;
            }

            self::queue_import_and_start_cron_if_needed($post_id, $is_ctgr);
            if (
                $isProductImport
                && self::should_restore_legacy_image_rows_after_wai_import(
                    $post_id,
                    $legacyImageListSnapshot,
                    $productListDb2Confirmed,
                    $productListUrlsDb2Confirmed,
                    $productListAltDb2Confirmed,
                    $productListDb2UrlFailed
                )
            ) {
                foreach ($legacyImageListSnapshot as $metaKey => $metaValue) {
                    if (preg_match('/^(fifu_image_(?:url|alt)(?:_\\d+)?|fifu_list_(?:url|alt))$/', (string) $metaKey) !== 1) {
                        continue;
                    }

                    if ($metaValue === null) {
                        continue;
                    }

                    self::set_raw_post_meta($post_id, (string) $metaKey, (string) $metaValue);
                }
            }
            if ($isProductImport && !empty($effectiveData['fifu_list_url'] ?? '') && !$productListUrlsDb2Confirmed) {
                self::preserve_product_legacy_image_url_fields_after_db2_url_failure($post_id, $effectiveData, $legacyImageListSnapshot);
            } elseif ($isProductImport && !empty($effectiveData['fifu_list_url'] ?? '') && $productListUrlsDb2Confirmed && !$productListAltDb2Confirmed) {
                self::preserve_product_legacy_image_alt_fields_after_db2_alt_failure(
                    $post_id,
                    $effectiveData,
                    $legacyImageListSnapshot
                );
            }

        } finally {
            if (!empty($useGalleryOnlyDb2Rebuild)) {
                self::clear_gallery_only_db2_rebuild_context($post_id, 'fifu_list_url');
                self::clear_gallery_only_db2_rebuild_context($post_id, 'fifu_list_alt');
                unset($_REQUEST['fifu_wai_gallery_only_image_list_url'], $_REQUEST['fifu_wai_gallery_only_image_list_alt']);
            }
            if ($shouldGuardPostCustomFeaturedVideoLegacy && $preserveLegacyMeta) {
                if ($previousPreserveLegacyMeta === null) {
                    unset($_REQUEST['fifu_preserve_legacy_meta_until_db2_confirmation']);
                } else {
                    $_REQUEST['fifu_preserve_legacy_meta_until_db2_confirmation'] = $previousPreserveLegacyMeta;
                }
            }
            self::set_import_in_progress(false);
        }

        if ($isProductImport && !empty($effectiveData['fifu_list_url'] ?? '') && !$productListUrlsDb2Confirmed) {
            Fifu_Wai_Meta_Service::restore_product_legacy_image_list_helper_meta(
                $post_id,
                $effectiveData,
                $legacyImageListSnapshot,
                true
            );
        }

        if ($isProductImport && !empty($effectiveData['fifu_list_url'] ?? '') && $productListUrlsDb2Confirmed && !$productListAltDb2Confirmed) {
            self::cleanup_legacy_image_url_fields_after_db2_url_confirmation($post_id);
            self::preserve_product_legacy_image_alt_fields_after_db2_alt_failure(
                $post_id,
                $effectiveData,
                $legacyImageListSnapshot
            );
        }
    }

    public static function set_import_in_progress(bool $inProgress): void {
        self::$importInProgress = $inProgress;
    }

    public static function is_import_in_progress(): bool {
        return self::$importInProgress;
    }

    public static function handle_before_xml_import($import_id = null): void
    {
        unset($import_id);

        self::$wpAllImportRequestActive = true;
        self::$remoteDb2ImageListFastPathPostIds = [];
        self::$currentWpAllImportPostId = null;
        self::$wpAllImportProductPostIds = [];
        self::$staged_import_queue = [
            'post' => [],
            'term' => [],
        ];
    }

    public static function handle_after_xml_import($import_id = null): void
    {
        unset($import_id);

        self::flush_staged_import_queue();
        foreach (array_keys(self::$wpAllImportProductPostIds) as $postId) {
            self::reconcile_product_image_list_if_needed((int) $postId);
        }
        self::$currentWpAllImportPostId = null;
        self::$wpAllImportProductPostIds = [];
        self::$wpAllImportRequestActive = false;
        self::$remoteDb2ImageListFastPathPostIds = [];
        self::set_import_in_progress(false);
    }

    public static function clear_import_context_on_shutdown(): void
    {
        self::flush_staged_import_queue();

        $postIds = array_map('intval', array_keys(self::$wpAllImportProductPostIds));
        if (self::$currentWpAllImportPostId !== null) {
            $postIds[] = self::$currentWpAllImportPostId;
        }
        foreach (array_values(array_unique($postIds)) as $postId) {
            self::reconcile_product_image_list_if_needed((int) $postId);
        }
        self::$currentWpAllImportPostId = null;
        self::$wpAllImportProductPostIds = [];

        self::$wpAllImportRequestActive = false;
        self::$remoteDb2ImageListFastPathPostIds = [];
        self::set_import_in_progress(false);
    }

    public static function is_wp_all_import_request_active(): bool
    {
        return self::$wpAllImportRequestActive
            || self::is_import_in_progress()
            || self::is_wp_all_import_process_request();
    }

    private static function is_wp_all_import_process_request(): bool
    {
        $page = self::request_scalar('page');
        $action = self::request_scalar('action');

        return $page === 'pmxi-admin-import' && $action === 'process';
    }

    private static function request_scalar(string $key): string
    {
        if (!isset($_REQUEST[$key]) || !is_scalar($_REQUEST[$key])) {
            return '';
        }

        $value = (string) $_REQUEST[$key];

        if (function_exists('wp_unslash')) {
            $value = (string) wp_unslash($value);
        }

        if (function_exists('sanitize_key')) {
            return sanitize_key($value);
        }

        return strtolower((string) preg_replace('/[^a-z0-9_\-]/i', '', $value));
    }

    public static function should_suppress_generic_post_save_media_sync(int $post_id): bool
    {
        if ($post_id <= 0) {
            return false;
        }

        if (!self::is_wp_all_import_request_active()) {
            return false;
        }

        $effectivePostId = $post_id;

        if (function_exists('wp_is_post_revision')) {
            $revisionParentId = wp_is_post_revision($post_id);
            if ($revisionParentId) {
                $effectivePostId = (int) $revisionParentId;
            }
        }

        if ($effectivePostId <= 0) {
            return false;
        }

        /*
         * WP All Import fires generic wp_insert_post/save_post hooks before
         * pmxi_saved_post and before WAI media payload is necessarily visible as
         * postmeta. During the import request, WAI/PMXI owns import-time media
         * persistence, so generic FIFU media sync must not resolve DB2 media state.
         */
        return true;
    }

    /**
     * @return array<int, array{key_index:int,url:string}>
     */
    private static function get_authoritative_product_image_mappings(int $postId): array
    {
        if ($postId <= 0 || !function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return [];
        }

        if (method_exists('Fifu_Db2_Manager', 'clearRequestCache')) {
            Fifu_Db2_Manager::clearRequestCache();
        }

        $manager = function_exists('fifu_db2_manager') ? fifu_db2_manager() : null;
        if (!$manager instanceof Fifu_Db2_Manager) {
            return [];
        }

        $mappings = [];
        foreach ($manager->getPostMappings($postId, 'image') as $mapping) {
            if (!is_array($mapping)) {
                continue;
            }

            $url = trim((string) ($mapping['url'] ?? ''));
            if ($url === '') {
                continue;
            }

            $mappings[] = [
                'key_index' => (int) ($mapping['key_index'] ?? 0),
                'url' => $url,
            ];
        }

        usort($mappings, static fn(array $a, array $b): int => $a['key_index'] <=> $b['key_index']);

        return $mappings;
    }

    private static function product_image_list_derived_state_needs_reconciliation(int $postId): bool
    {
        if ($postId <= 0 || !function_exists('get_post_type') || (string) get_post_type($postId) !== 'product') {
            return false;
        }

        $mappings = self::get_authoritative_product_image_mappings($postId);
        if ($mappings === []) {
            return false;
        }

        global $wpdb;
        $thumbnailId = (int) ($wpdb->get_var($wpdb->prepare("SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_thumbnail_id' LIMIT 1", $postId)) ?? 0);
        $attachmentState = static function (int $id) use ($wpdb): ?array {
            if ($id <= 0) return null;
            $row = $wpdb->get_row($wpdb->prepare("SELECT post_type, post_parent FROM {$wpdb->posts} WHERE ID = %d LIMIT 1", $id), ARRAY_A);
            if (!is_array($row)) return null;
            $url = $wpdb->get_var($wpdb->prepare("SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_wp_attached_file' LIMIT 1", $id));
            return ['post_type' => (string) ($row['post_type'] ?? ''), 'post_parent' => (int) ($row['post_parent'] ?? 0), 'url' => (string) ($url ?? '')];
        };
        $featured = $attachmentState($thumbnailId);
        if ($featured === null || $featured['post_type'] !== 'attachment' || $featured['post_parent'] !== $postId || $featured['url'] !== (string) $mappings[0]['url']) return true;
        $expected = array_values(array_filter($mappings, static fn(array $m): bool => (int) ($m['key_index'] ?? 0) > 0));
        $gallery = self::normalize_positive_integer_meta_ids((string) ($wpdb->get_var($wpdb->prepare("SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_product_image_gallery' LIMIT 1", $postId)) ?? ''));
        if (count($gallery) !== count($expected) || in_array($thumbnailId, $gallery, true)) return true;
        foreach ($expected as $index => $mapping) {
            $state = $attachmentState((int) ($gallery[$index] ?? 0));
            if ($state === null || $state['post_type'] !== 'attachment' || $state['post_parent'] !== $postId || $state['url'] !== (string) $mapping['url']) return true;
        }
        return false;
    }

    private static function reconcile_product_image_list_if_needed(int $postId): void
    {
        if (!self::product_image_list_derived_state_needs_reconciliation($postId)) return;
        if (!class_exists('Fifu_Post_Attachment_Sync_Service', false)) {
            $path = dirname(__DIR__, 2) . '/meta/class-fifu-post-attachment-sync-service.php';
            if (is_readable($path)) require_once $path;
        }
        if (!class_exists('Fifu_Post_Attachment_Sync_Service', false) || !method_exists('Fifu_Post_Attachment_Sync_Service', 'sync_product_gallery_attachments_from_db2_image_list')) return;
        if (function_exists('clean_post_cache')) clean_post_cache($postId);
        if (function_exists('wp_cache_delete')) wp_cache_delete($postId, 'post_meta');
        Fifu_Post_Attachment_Sync_Service::sync_product_gallery_attachments_from_db2_image_list($postId);
        if (function_exists('clean_post_cache')) clean_post_cache($postId);
        if (function_exists('wp_cache_delete')) wp_cache_delete($postId, 'post_meta');
    }

    private static function wp_all_import_existing_product_has_fifu_db2_images($articleData, int $explicitPostId = 0): bool
    {
        if (!is_array($articleData)) {
            return false;
        }

        $articlePostId = isset($articleData['ID']) && is_numeric($articleData['ID'])
            ? (int) $articleData['ID']
            : 0;
        if ($articlePostId <= 0) {
            return false;
        }

        $postId = $explicitPostId > 0 ? $explicitPostId : $articlePostId;
        if ($postId <= 0 || ($explicitPostId > 0 && $explicitPostId !== $articlePostId)) {
            return false;
        }

        $articlePostType = isset($articleData['post_type']) && is_scalar($articleData['post_type'])
            ? (string) $articleData['post_type']
            : '';
        $actualPostType = function_exists('get_post_type') ? (string) get_post_type($postId) : '';
        if ($articlePostType !== 'product' && $actualPostType !== 'product') {
            return false;
        }

        return self::get_authoritative_product_image_mappings($postId) !== [];
    }

    public static function filter_pmxi_delete_images($shouldDelete, $articleData, $currentXmlNode): bool
    {
        unset($currentXmlNode);
        if (!$shouldDelete) {
            return false;
        }

        if (self::wp_all_import_existing_product_has_fifu_db2_images($articleData)) {
            return false;
        }

        return (bool) $shouldDelete;
    }

    public static function filter_pmxi_is_images_to_update($shouldUpdate, $articleData, $currentXmlNode, $postId): bool
    {
        unset($currentXmlNode);
        if (!$shouldUpdate) {
            return false;
        }

        $postId = is_numeric($postId) ? (int) $postId : 0;
        if (self::wp_all_import_existing_product_has_fifu_db2_images($articleData, $postId)) {
            return false;
        }

        return (bool) $shouldUpdate;
    }

    public static function handle_pmxi_saved_post($post_id, $xml_node, $is_update): void
    {
        unset($xml_node, $is_update);

        $post_id = is_numeric($post_id) ? (int) $post_id : 0;

        if ($post_id <= 0) {
            return;
        }

        if (function_exists('get_post_type') && (string) get_post_type($post_id) === 'product') {
            self::$currentWpAllImportPostId = $post_id;
            self::$wpAllImportProductPostIds[$post_id] = true;
        }

        self::reconcile_product_image_list_if_needed($post_id);

        self::handle_post_saved($post_id, null, null);
    }

    public static function handle_after_post_import($import_id = null): void
    {
        unset($import_id);
        $postId = self::$currentWpAllImportPostId;
        self::$currentWpAllImportPostId = null;
        if ($postId !== null) {
            self::reconcile_product_image_list_if_needed($postId);
        }
    }

    private static function should_repair_missing_featured_attachment(
        int $postId
    ): bool {
        if ($postId <= 0) {
            return false;
        }

        $thumbnailId =
            (int) get_post_meta(
                $postId,
                '_thumbnail_id',
                true
            );

        if ($thumbnailId > 0) {
            if (
                !function_exists('get_post')
                || get_post($thumbnailId)
            ) {
                return false;
            }
        }

        if (
            !function_exists('fifu_db2_manager')
            || !class_exists(
                'Fifu_Db2_Manager',
                false
            )
        ) {
            return false;
        }

        $manager = fifu_db2_manager();

        if (
            !$manager
            instanceof Fifu_Db2_Manager
        ) {
            return false;
        }

        foreach (
            [
                'slider',
                'image',
                'custom_video',
                'video',
            ]
            as $keyType
        ) {
            $mapping =
                $manager->getPostMapping(
                    $postId,
                    $keyType,
                    0
                );

            if (
                is_array($mapping)
                && trim(
                    (string) (
                        $mapping['url']
                        ?? ''
                    )
                ) !== ''
            ) {
                return true;
            }
        }

        return false;
    }

    private static function should_repair_incomplete_product_gallery(
        int $postId
    ): bool {
        if (
            $postId <= 0
            || !function_exists('get_post_type')
            || (string) get_post_type($postId) !== 'product'
        ) {
            return false;
        }

        if (
            !function_exists('fifu_db2_manager')
            || !class_exists(
                'Fifu_Db2_Manager',
                false
            )
        ) {
            return false;
        }

        $manager = fifu_db2_manager();

        if (
            !$manager
            instanceof Fifu_Db2_Manager
        ) {
            return false;
        }

        $expectedGalleryCount = 0;

        foreach (
            [
                'image',
                'video',
                'slider',
            ]
            as $keyType
        ) {
            foreach (
                $manager->getPostMappings(
                    $postId,
                    $keyType
                )
                as $mapping
            ) {
                if (
                    (int) (
                        $mapping['key_index']
                        ?? 0
                    ) <= 0
                ) {
                    continue;
                }

                if (
                    trim(
                        (string) (
                            $mapping['url']
                            ?? ''
                        )
                    ) === ''
                ) {
                    continue;
                }

                $expectedGalleryCount++;
            }
        }

        if ($expectedGalleryCount === 0) {
            return false;
        }

        global $wpdb;

        if (
            !isset($wpdb)
            || !isset($wpdb->postmeta)
            || !isset($wpdb->posts)
        ) {
            return false;
        }

        $galleryMeta = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT meta_value
                 FROM {$wpdb->postmeta}
                 WHERE post_id = %d
                   AND meta_key = %s
                 ORDER BY meta_id ASC
                 LIMIT 1",
                $postId,
                '_product_image_gallery'
            )
        );

        $galleryIds =
            self::normalize_positive_integer_meta_ids(
                $galleryMeta
            );

        if (
            count($galleryIds)
            < $expectedGalleryCount
        ) {
            return true;
        }

        $placeholders = implode(
            ',',
            array_fill(0, count($galleryIds), '%d')
        );

        $attachments = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT ID, post_type, post_parent
                 FROM {$wpdb->posts}
                 WHERE ID IN ({$placeholders})",
                ...$galleryIds
            )
        );

        $attachmentsById = [];
        foreach ($attachments as $attachment) {
            $attachmentsById[(int) $attachment->ID] =
                $attachment;
        }

        foreach ($galleryIds as $galleryId) {
            $attachment = $attachmentsById[$galleryId] ?? null;

            if (
                !$attachment
                || (string) (
                    $attachment->post_type
                    ?? ''
                ) !== 'attachment'
                || (int) (
                    $attachment->post_parent
                    ?? 0
                ) !== $postId
            ) {
                return true;
            }
        }

        return false;
    }

    public static function handle_post_saved(int $post_id, $import, $logger): void
    {
        unset($import, $logger);

        if ($post_id <= 0) {
            return;
        }

            $postType = function_exists('get_post_type') ? (string) get_post_type($post_id) : '';

            if ($postType === 'property') {
                $sliderUrls = self::get_current_post_slider_urls_for_noop_confirmation($post_id);

                if (
                    self::should_repair_missing_featured_attachment($post_id)
                    || (
                        $sliderUrls !== []
                        && self::is_property_slider_metadata_incomplete($post_id, $sliderUrls)
                    )
                ) {
                    self::queue_import_and_start_cron_if_needed($post_id, false);
                }

                return;
            }

            if (
                self::should_repair_missing_featured_attachment($post_id)
                || self::should_repair_incomplete_product_gallery($post_id)
            ) {
                self::queue_import_and_start_cron_if_needed($post_id, false);
            }

            if (!in_array($postType, ['product', 'product_variation'], true)) {
                return;
            }

            if (self::was_remote_db2_image_list_fast_path_post($post_id)) {
                return;
            }

            if (!function_exists('fifu_db2_speed_up_repository')) {
                return;
            }

            $repository = fifu_db2_speed_up_repository();
            if (!$repository instanceof Fifu_Db2_Speed_Up_Repository) {
                return;
            }

            $repository->backfill_missing_attached_file_for_gallery_post($post_id);
    }

    public static function cache_term_image_url(int $termId, string $url): void {
        self::$cachedTermImageUrls[$termId] = $url;
    }

    private static function mark_remote_db2_image_list_fast_path_post(int $post_id): void
    {
        if ($post_id <= 0) {
            return;
        }

        self::$remoteDb2ImageListFastPathPostIds[$post_id] = true;
    }

    private static function was_remote_db2_image_list_fast_path_post(int $post_id): bool
    {
        return $post_id > 0 && !empty(self::$remoteDb2ImageListFastPathPostIds[$post_id]);
    }

    public static function consume_cached_term_image_url(int $termId): ?string {
        if (!isset(self::$cachedTermImageUrls[$termId])) {
            return null;
        }

        $url = self::$cachedTermImageUrls[$termId];
        unset(self::$cachedTermImageUrls[$termId]);
        return $url;
    }

    public static function reset_cached_term_image_urls(): void {
        self::$cachedTermImageUrls = [];
    }

    private static function is_product_import(array $article, bool $is_ctgr): bool
    {
        return !$is_ctgr && (string) ($article['post_type'] ?? '') === 'product';
    }

    private static function is_wai_insert_import(int $post_id, $import_options, array $articleData): bool
    {
        unset($post_id, $import_options);

        return empty($articleData['ID']);
    }

    private static function has_non_empty_wai_value(array $data, string $field): bool
    {
        return trim((string) ($data[$field] ?? '')) !== '';
    }

    private static function has_ignored_product_direct_featured_media_payload(array $data): bool
    {
        return trim((string) ($data['fifu_image_url'] ?? '')) !== ''
            || trim((string) ($data['fifu_image_alt'] ?? '')) !== ''
            || trim((string) ($data['fifu_video_url'] ?? '')) !== '';
    }

    private static function can_use_fast_insert_featured_image_alt_path(
        int $postId,
        array $effectiveData,
        bool $isInsertImport,
        bool $isCategory,
        bool $isProductImport,
        bool $productUsesListOnlyMediaFields
    ): bool {
        unset($postId);

        if (
            !$isInsertImport
            || $isCategory
            || $isProductImport
            || $productUsesListOnlyMediaFields
            || trim((string) ($effectiveData['fifu_image_url'] ?? '')) === ''
            || trim((string) ($effectiveData['fifu_image_alt'] ?? '')) === ''
        ) {
            return false;
        }

        foreach ([
            'fifu_video_url',
            'fifu_list_url',
            'fifu_list_alt',
            'fifu_list_video_url',
            'fifu_slider_list_url',
            'fifu_slider_list_alt',
        ] as $field) {
            if (trim((string) ($effectiveData[$field] ?? '')) !== '') {
                return false;
            }
        }

        return function_exists('fifu_db2_write_service')
            && function_exists('fifu_db2_manager')
            && fifu_db2_write_service() !== null
            && fifu_db2_manager() instanceof Fifu_Db2_Manager;
    }

    /**
     * @return array{url_confirmed: bool, alt_confirmed: bool}
     */
    private static function persist_fast_insert_featured_image_alt(
        int $postId,
        string $imageUrl,
        string $imageAlt
    ): array {
        $expectedUrl = self::normalize_wai_featured_image_url_for_db2_confirmation($imageUrl);
        $expectedAlt = self::normalize_wai_featured_image_alt_for_db2_confirmation($imageAlt);
        $expectedUrlHash = md5($expectedUrl);
        $expectedAltHash = md5($expectedAlt);
        if ($expectedUrl === '' || $expectedAlt === '') {
            return ['url_confirmed' => false, 'alt_confirmed' => false];
        }

        $writeService = fifu_db2_write_service();
        $manager = fifu_db2_manager();
        $usedFastInsertHelper = $manager instanceof Fifu_Db2_Manager
            && method_exists($manager, 'savePostImageAndAltFastInsert');
        if (!is_object($writeService)) {
            return ['url_confirmed' => false, 'alt_confirmed' => false];
        }

        $urlSaved = false;
        $altSaved = false;
        try {
            if ($usedFastInsertHelper) {
                $urlSaved = (bool) $manager->savePostImageFastInsert($postId, $expectedUrl, 0);
            } elseif (method_exists($writeService, 'save_post_image')) {
                $urlSaved = (bool) $writeService->save_post_image($postId, $expectedUrl, 0);
            }
            if ($urlSaved && $usedFastInsertHelper) {
                $altSaved = (bool) $manager->savePostImageAltFastInsert($postId, $expectedAlt, 0);
            } elseif ($urlSaved && method_exists($writeService, 'save_post_image_alt')) {
                $altSaved = (bool) $writeService->save_post_image_alt($postId, $expectedAlt, 0);
            }
        } catch (Throwable $throwable) {
            return ['url_confirmed' => false, 'alt_confirmed' => false];
        }

        if (!$urlSaved) {
            return ['url_confirmed' => false, 'alt_confirmed' => false];
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return ['url_confirmed' => false, 'alt_confirmed' => false];
        }

        $urlConfirmed = $manager->getPostMappingHash($postId, 'image', 0) === $expectedUrlHash;
        $altConfirmed = $altSaved && $manager->getPostAltMappingHash($postId, 'image', 0) === $expectedAltHash;

        if (!$urlConfirmed) {
            return ['url_confirmed' => false, 'alt_confirmed' => false];
        }

        if (!$altConfirmed) {
            if (method_exists($manager, 'deletePostAltMappings')) {
                $manager->deletePostAltMappings($postId, 'image', 0);
            }
            return ['url_confirmed' => true, 'alt_confirmed' => false];
        }

        if (get_post_meta($postId, 'fifu_image_url', true) !== '') {
            delete_post_meta($postId, 'fifu_image_url');
        }
        if (get_post_meta($postId, 'fifu_image_alt', true) !== '') {
            delete_post_meta($postId, 'fifu_image_alt');
        }
        clean_post_cache($postId);
        wp_cache_delete($postId, 'post_meta');

        return ['url_confirmed' => true, 'alt_confirmed' => true];
    }

    private static function has_any_fifu_payload(array $data): bool
    {
        foreach ([
            'fifu_image_url',
            'fifu_image_alt',
            'fifu_video_url',
            'fifu_list_url',
            'fifu_list_alt',
            'fifu_list_video_url',
            'fifu_slider_list_url',
            'fifu_slider_list_alt',
            'fifu_asin',
            'fifu_finder_url',
            'fifu_redirection_url',
        ] as $field) {
            if (trim((string) ($data[$field] ?? '')) !== '') {
                return true;
            }
        }

        return false;
    }

    private static function has_wai_effective_import_payload(string $field, array $data, array $effectiveData, $importOptions): bool
    {
        if (!array_key_exists($field, $data)) {
            return false;
        }

        $value = self::fifu_normalize_wai_field_value($field, (string) $data[$field], (string) ($data['fifu_delimiter'] ?? '|'));
        if ($value !== '') {
            return true;
        }

        // Blank values may be explicit clears when the field is truly mapped.
        return self::is_wai_field_explicitly_mapped($field, $importOptions);
    }

    private static function has_wai_effective_scalar_import_payload(
        string $field,
        array $data,
        array $effectiveData,
        $importOptions
    ): bool {
        if (!array_key_exists($field, $data)) {
            return false;
        }

        $normalized = self::fifu_normalize_wai_field_value($field, (string) $data[$field], (string) ($data['fifu_delimiter'] ?? '|'));
        if ($normalized !== '') {
            return true;
        }

        return self::is_wai_field_explicitly_mapped($field, $importOptions);
    }

    private static function has_wai_image_list_import_payload(array $data, array $effectiveData, $importOptions): bool
    {
        return self::has_wai_effective_import_payload('fifu_list_url', $data, $effectiveData, $importOptions)
            || self::has_wai_effective_import_payload('fifu_list_alt', $data, $effectiveData, $importOptions);
    }

    private static function has_wai_video_list_import_payload(array $data, array $effectiveData, $importOptions): bool
    {
        return self::has_wai_effective_import_payload('fifu_list_video_url', $data, $effectiveData, $importOptions);
    }

    private static function has_wai_slider_list_import_payload(array $data, array $effectiveData, $importOptions): bool
    {
        return self::has_wai_effective_import_payload('fifu_slider_list_url', $data, $effectiveData, $importOptions)
            || self::has_wai_effective_import_payload('fifu_slider_list_alt', $data, $effectiveData, $importOptions);
    }

    private static function is_wai_field_explicitly_mapped(string $field, $importOptions): bool
    {
        $normalized = self::normalize_import_options($importOptions);
        $options = $normalized['options'] ?? $normalized;
        if (!is_array($options)) {
            return false;
        }

        $mapping = $options['mapping'] ?? [];
        if (!is_array($mapping) || !array_key_exists($field, $mapping)) {
            return false;
        }

        $value = $mapping[$field];
        if (is_string($value)) {
            return trim($value) !== '';
        }

        return !empty($value);
    }

    private static function queue_import_and_start_cron_if_needed(int $post_id, bool $is_ctgr): void
    {
        $service = fifu_db2_import_service();
        $service->queue_import($post_id, $is_ctgr);

        if (self::is_wp_all_import_request_active()) {
            self::stage_import_queue_item($post_id, $is_ctgr);
            return;
        }

        self::process_local_import_batch([$post_id], $is_ctgr);
    }

    private static function stage_import_queue_item(int $object_id, bool $is_term): void
    {
        if ($object_id <= 0) {
            return;
        }

        $bucket = $is_term ? 'term' : 'post';

        if (!isset(self::$staged_import_queue[$bucket]) || !is_array(self::$staged_import_queue[$bucket])) {
            self::$staged_import_queue[$bucket] = [];
        }

        self::$staged_import_queue[$bucket][$object_id] = true;

    }

    private static function flush_staged_import_queue(): void
    {
        self::flush_staged_import_bucket('post');
        self::flush_staged_import_bucket('term');
    }

    private static function flush_staged_import_bucket(string $bucket): void
    {
        if ($bucket !== 'post' && $bucket !== 'term') {
            return;
        }

        $object_ids = array_keys(self::$staged_import_queue[$bucket] ?? []);
        if (empty($object_ids)) {
            return;
        }

        self::$staged_import_queue[$bucket] = [];

        foreach (
            array_chunk(
                $object_ids,
                self::LOCAL_IMPORT_BATCH_SIZE
            )
            as $chunk
        ) {
            self::process_local_import_batch(
                $chunk,
                $bucket === 'term'
            );
        }
    }

    /**
     * @param array<int, int> $object_ids
     */
    private static function process_local_import_batch(array $object_ids, bool $is_ctgr): void
    {
        $object_ids = array_values(array_unique(array_filter(array_map('intval', $object_ids), static function (int $object_id): bool {
            return $object_id > 0;
        })));

        if (empty($object_ids)) {
            return;
        }

        try {
            Fifu_Metadata_Import_Service::run_local_import($object_ids, $is_ctgr);
        } catch (Throwable $throwable) {
            if (class_exists('Fifu_File_Logger', false)) {
                Fifu_File_Logger::plugin([
                    'local_import_error' => [
                        'ids' => $object_ids,
                        'ctgr' => $is_ctgr,
                        'message' => $throwable->getMessage(),
                    ],
                ]);
            }
        }
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private static function apply_product_media_priority(array $data): array
    {
        $hasSliderList = self::has_non_empty_wai_value($data, 'fifu_slider_list_url');

        if ($hasSliderList) {
            unset(
                $data['fifu_list_url'],
                $data['fifu_list_alt'],
                $data['fifu_list_video_url'],
                $data['fifu_image_url'],
                $data['fifu_image_alt'],
                $data['fifu_video_url']
            );
            return $data;
        }

        unset(
            $data['fifu_slider_list_url'],
            $data['fifu_slider_list_alt'],
            $data['fifu_image_url'],
            $data['fifu_image_alt'],
            $data['fifu_video_url']
        );

        return $data;
    }

    private static function clear_wai_media_request_keys(): void
    {
        foreach ([
            'fifu_wai_image_list_url',
            'fifu_wai_image_list_alt',
            'fifu_wai_gallery_only_image_list_url',
            'fifu_wai_gallery_only_image_list_alt',
            'fifu_wai_gallery_only_video_list_url',
            'fifu_wai_video_list_url',
            'fifu_wai_gallery_only_slider_list_url',
            'fifu_wai_gallery_only_slider_list_alt',
            'fifu_wai_custom_video_source',
        ] as $key) {
            unset($_REQUEST[$key]);
        }
    }

    private static function set_raw_post_meta(int $post_id, string $meta_key, string $meta_value): void
    {
        global $wpdb;

        if (!isset($wpdb) || !is_object($wpdb) || !property_exists($wpdb, 'postmeta')) {
            return;
        }

        $table = $wpdb->postmeta;
        $existing_id = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT meta_id FROM {$table} WHERE post_id = %d AND meta_key = %s LIMIT 1",
                $post_id,
                $meta_key
            )
        );

        if ($existing_id) {
            $wpdb->update(
                $table,
                ['meta_value' => $meta_value],
                ['meta_id' => (int) $existing_id],
                ['%s'],
                ['%d']
            );
        } else {
            $wpdb->insert(
                $table,
                [
                    'post_id' => $post_id,
                    'meta_key' => $meta_key,
                    'meta_value' => $meta_value,
                ],
                ['%d', '%s', '%s']
            );
        }

        clean_post_cache($post_id);
        wp_cache_delete($post_id, 'post_meta');
    }

    private static function ensure_image_key_exists(): void
    {
        global $wpdb;

        $table = $wpdb->prefix . 'fifu_key';
        $wpdb->query(
            $wpdb->prepare(
                "INSERT IGNORE INTO {$table} (key_type) VALUES (%s)",
                'image'
            )
        );
    }

    private static function add_field(string $cf, string $title, ?string $info): void
    {
        if (self::$addon === null) {
            return;
        }

        self::$addon->add_field($cf, "<div title=\"{$cf}\">{$title}</div>", 'text', null, $info, false, null);
    }

    /**
     * @return array{0:string,1:string,2:bool}
     */
    private static function split_custom_video_entry(string $value): array
    {
        if (strpos($value, '\\') !== false) {
            $parts = explode('\\', $value, 2);
            $posterUrl = trim((string) ($parts[1] ?? ''));

            return [
                trim((string) ($parts[0] ?? '')),
                $posterUrl,
                $posterUrl !== '',
            ];
        }

        if (preg_match('/https?:\\/\\//i', $value, $matches, PREG_OFFSET_CAPTURE) === 1) {
            $firstOffset = (int) ($matches[0][1] ?? -1);
            if ($firstOffset >= 0) {
                $secondMatchOffset = null;
                if (preg_match('/https?:\\/\\//i', $value, $secondMatch, PREG_OFFSET_CAPTURE, $firstOffset + 1) === 1) {
                    $secondMatchOffset = (int) ($secondMatch[0][1] ?? -1);
                }

                if ($secondMatchOffset !== null && $secondMatchOffset > $firstOffset) {
                    return [
                        trim(substr($value, 0, $secondMatchOffset)),
                        trim(substr($value, $secondMatchOffset)),
                        true,
                    ];
                }
            }
        }

        return [trim($value), '', false];
    }

    private static function is_custom_featured_video_payload(string $value): bool
    {
        if ($value === '' || strpos($value, '\\') === false) {
            return false;
        }

        [$videoUrl, $posterUrl, $hasPoster] = self::split_custom_video_entry($value);

        return trim((string) $videoUrl) !== '' && $hasPoster && trim((string) $posterUrl) !== '';
    }

    private static function persist_wai_custom_featured_video(int $objectId, string $rawValue, bool $isTerm): void
    {
        [$videoUrl, $posterUrl, $hasPoster] = self::split_custom_video_entry($rawValue);

        if ($videoUrl === '') {
            return;
        }

        $legacyVideoUrl = $isTerm
            ? (string) get_term_meta($objectId, 'fifu_video_url', true)
            : (string) get_post_meta($objectId, 'fifu_video_url', true);
        $legacyCustomVideoUrl = $isTerm
            ? (string) get_term_meta($objectId, 'fifu_custom_video_url', true)
            : (string) get_post_meta($objectId, 'fifu_custom_video_url', true);

        $savedToDb2 = false;
        if (function_exists('fifu_db2_manager')) {
            $manager = fifu_db2_manager();
            if ($manager instanceof Fifu_Db2_Manager) {
        if ($isTerm && method_exists($manager, 'saveTermUrl')) {
            $savedToDb2 = (bool) $manager->saveTermUrl($objectId, 'custom_video', $videoUrl);
        } elseif (!$isTerm && method_exists($manager, 'savePostUrl')) {
            $savedToDb2 = (bool) $manager->savePostUrl($objectId, 'custom_video', 0, $videoUrl);
        }
            }
        }

        $posterSaved = ! $hasPoster;
        if ($hasPoster && $posterUrl !== '' && class_exists('Fifu_Video_Oembed_Service', false)) {
            try {
                $posterSaved = Fifu_Video_Oembed_Service::instance()->upsert_oembed($videoUrl, $posterUrl, $videoUrl)
                    && self::custom_video_poster_matches_oembed($videoUrl, $posterUrl);
            } catch (Throwable $throwable) {
                $posterSaved = false;
            }
        }

        $canCleanup = $isTerm
            ? self::can_cleanup_term_custom_video_source_meta($objectId, $rawValue)
            : self::can_cleanup_post_custom_video_source_meta($objectId, $rawValue);

        if ($savedToDb2 && $canCleanup && $posterSaved) {
            if ($isTerm) {
                delete_term_meta($objectId, 'fifu_video_url');
                delete_term_meta($objectId, 'fifu_custom_video_url');
            } else {
                delete_post_meta($objectId, 'fifu_video_url');
                delete_post_meta($objectId, 'fifu_custom_video_url');
            }
            return;
        }

        return;
    }

    private static function custom_video_poster_matches_oembed(string $videoUrl, string $expectedPosterUrl): bool
    {
        if ($expectedPosterUrl === '') {
            return true;
        }

        if (!class_exists('Fifu_Video_Oembed_Service', false)) {
            return false;
        }

        $service = Fifu_Video_Oembed_Service::instance();
        if (!method_exists($service, 'get_repository')) {
            return false;
        }

        $repository = $service->get_repository();
        if (!method_exists($repository, 'get_image_url_by_video_url')) {
            return false;
        }

        return (string) $repository->get_image_url_by_video_url($videoUrl) === $expectedPosterUrl;
    }

    /**
     * Normalize PMXI import options to an array structure.
     *
     * @param mixed $import_options
     * @return array
     */
    private static function normalize_import_options($import_options): array
    {
        if (is_array($import_options)) {
            return $import_options;
        }

        if (is_object($import_options)) {
            if (property_exists($import_options, 'options')) {
                return ['options' => (array) $import_options->options];
            }

            return (array) $import_options;
        }

        return [];
    }

    private static function fifu_normalize_wai_field_value(string $field, string $value, string $delimiter): string
    {

        if ($field === 'fifu_asin') {
            return self::normalize_wai_asin_value($value);
        }

        if ($field === 'fifu_finder_url') {
            return trim($value);
        }

        if (in_array($field, ['fifu_list_url', 'fifu_list_alt', 'fifu_list_video_url', 'fifu_slider_list_url', 'fifu_slider_list_alt'], true)) {
            $value = str_replace($delimiter, '|', $value);
            $value = trim($value);
            $value = rtrim($value, '|');

            if ($field === 'fifu_list_url' && $value !== '') {
                $value = implode(
                    '|',
                    array_map(
                        static fn(string $url): string =>
                            self::normalize_wai_import_image_url($url),
                        explode('|', $value)
                    )
                );
            }
        }

        return $value;
    }

    private static function normalize_wai_import_image_url(string $url): string
    {
        $url = trim($url);

        if ($url === '') {
            return '';
        }

        $parts = parse_url($url);

        if (
            !is_array($parts)
            || !isset($parts['host'])
            || (
                !isset($parts['scheme'])
                && strpos($url, '//') !== 0
            )
        ) {
            return str_replace(' ', '%20', $url);
        }

        $path = str_replace(
            ' ',
            '%20',
            (string) ($parts['path'] ?? '')
        );

        $encodedPath = preg_replace_callback(
            '/[^\x00-\x7F]+/u',
            static fn(array $matches): string =>
                rawurlencode((string) $matches[0]),
            $path
        );

        if (!is_string($encodedPath)) {
            return str_replace(' ', '%20', $url);
        }

        $normalized = '';

        if (isset($parts['scheme'])) {
            $normalized .= (string) $parts['scheme'] . '://';
        } else {
            $normalized .= '//';
        }

        if (isset($parts['user'])) {
            $normalized .= (string) $parts['user'];

            if (isset($parts['pass'])) {
                $normalized .= ':' . (string) $parts['pass'];
            }

            $normalized .= '@';
        }

        $normalized .= (string) $parts['host'];

        if (isset($parts['port'])) {
            $normalized .= ':' . (string) $parts['port'];
        }

        $normalized .= $encodedPath;

        if (array_key_exists('query', $parts)) {
            $normalized .= '?' . str_replace(
                ' ',
                '%20',
                (string) $parts['query']
            );
        }

        if (array_key_exists('fragment', $parts)) {
            $normalized .= '#' . str_replace(
                ' ',
                '%20',
                (string) $parts['fragment']
            );
        }

        return $normalized;
    }

    private static function normalize_wai_asin_value(string $value): string
    {
        $value = trim($value);

        if ($value === '') {
            return '';
        }

        if (preg_match('/^(invalid|not-found)\s*:\s*(.*)$/i', $value, $matches) === 1) {
            $prefix = strtolower($matches[1]) . ':';
            $identifier = trim((string) $matches[2]);

            if ($identifier === '') {
                return '';
            }

            return $prefix . $identifier;
        }

        return $value;
    }

    private static function persist_wai_asin(int $postId, string $asin): void
    {
        $ok = self::update_post_meta_with_db2_status($postId, 'fifu_asin', $asin);

        if ($ok) {
            return;
        }

        if ($asin === '') {
            return;
        }

        self::delete_wai_identifier_db2_state($postId, 'asin');
        self::update_wai_identifier_legacy_only($postId, 'fifu_asin', $asin);
    }

    private static function persist_wai_finder_url(int $postId, string $finderUrl): void
    {
        if ($finderUrl === '') {
            delete_post_meta($postId, 'fifu_finder_url');
            if (function_exists('fifu_db2_write_service')) {
                $service = fifu_db2_write_service();
                if (is_object($service) && method_exists($service, 'delete_post_finder')) {
                    try {
                        $service->delete_post_finder($postId, 0);
                    } catch (Throwable $throwable) {
                        // Best-effort cleanup only.
                    }
                }
            }
            if (function_exists('fifu_db2_manager')) {
                $manager = fifu_db2_manager();
                if ($manager instanceof Fifu_Db2_Manager && method_exists($manager, 'deletePostMappings')) {
                    $manager->deletePostMappings($postId, 'finder', 0);
                }
            }
            return;
        }

        self::set_raw_post_meta($postId, 'fifu_finder_url', $finderUrl);
        $ok = false;
        if (function_exists('fifu_db2_write_service')) {
            $service = fifu_db2_write_service();
            if (is_object($service) && method_exists($service, 'save_post_finder')) {
                try {
                    $ok = (bool) $service->save_post_finder($postId, $finderUrl);
                } catch (Throwable $throwable) {
                    $ok = false;
                }
            }
        }

        if (!$ok) {
            self::set_raw_post_meta($postId, 'fifu_finder_url', $finderUrl);
            if (function_exists('fifu_db2_write_service')) {
                $service = fifu_db2_write_service();
                if (is_object($service) && method_exists($service, 'delete_post_finder')) {
                    try {
                        $service->delete_post_finder($postId, 0);
                    } catch (Throwable $throwable) {
                        // Best-effort cleanup only.
                    }
                }
            }
            return;
        }

        if ((string) Fifu_Post_Finder_Read_Service::get_finder_url($postId) !== $finderUrl) {
            self::set_raw_post_meta($postId, 'fifu_finder_url', $finderUrl);
        } else {
            delete_post_meta($postId, 'fifu_finder_url');
        }
    }

    private static function persist_wai_redirection_url(int $postId, string $redirectionUrl): void
    {
        $updater = FIFU_Post_Meta_Updater::instance();
        $ok = $updater->update_or_delete_with_status($postId, 'fifu_redirection_url', $redirectionUrl);

        if ($ok) {
            return;
        }

        if ($redirectionUrl === '') {
            self::delete_wai_redirection_db2_state($postId);
            delete_post_meta($postId, 'fifu_redirection_url');
            return;
        }

        self::delete_wai_redirection_db2_state($postId);
        self::set_raw_post_meta($postId, 'fifu_redirection_url', $redirectionUrl);
    }

    private static function delete_wai_identifier_db2_state(int $postId, string $typeKey): void
    {
        if (!function_exists('fifu_db2_identifier_repository')) {
            return;
        }

        $repository = fifu_db2_identifier_repository();
        if (!$repository instanceof Fifu_Db2_Identifier_Repository) {
            return;
        }

        try {
            $repository->delete_post_identifier($postId, $typeKey);
        } catch (Throwable $throwable) {
            // Best-effort cleanup only. The legacy fallback below must still be preserved.
        }
    }

    private static function delete_wai_redirection_db2_state(int $postId): void
    {
        if (!function_exists('fifu_db2_write_service')) {
            return;
        }

        $service = fifu_db2_write_service();

        if (!is_object($service) || !method_exists($service, 'delete_post_redirect')) {
            return;
        }

        try {
            $service->delete_post_redirect($postId, 0);
        } catch (Throwable $throwable) {
            // Best-effort cleanup only. Legacy fallback must still be preserved.
        }

        if (function_exists('fifu_db2_manager')) {
            $manager = fifu_db2_manager();
            if ($manager instanceof Fifu_Db2_Manager && method_exists($manager, 'deletePostMappings')) {
                $manager->deletePostMappings($postId, 'redirect', 0);
            }
        }
    }

    private static function update_post_meta_with_db2_status(int $postId, string $field, string $value): bool
    {
        if (
            class_exists('FIFU_Post_Meta_Updater', false)
            && method_exists('FIFU_Post_Meta_Updater', 'instance')
        ) {
            $updater = FIFU_Post_Meta_Updater::instance();

            if (is_object($updater) && method_exists($updater, 'update_or_delete_with_status')) {
                return (bool) $updater->update_or_delete_with_status($postId, $field, $value);
            }
        }

        if (function_exists('fifu_update_or_delete')) {
            fifu_update_or_delete($postId, $field, $value);
            return true;
        }

        if ($value === '') {
            if (function_exists('delete_post_meta')) {
                delete_post_meta($postId, $field);
                return true;
            }

            return false;
        }

        if (function_exists('update_post_meta')) {
            update_post_meta($postId, $field, $value);
            return true;
        }

        return false;
    }

    private static function update_wai_identifier_legacy_only(int $postId, string $metaKey, string $value): void
    {
        $hadPreviousFlag = array_key_exists('__fifu_skip_db2_identifier_replication', $GLOBALS);
        $previousFlag = $hadPreviousFlag ? $GLOBALS['__fifu_skip_db2_identifier_replication'] : null;

        $GLOBALS['__fifu_skip_db2_identifier_replication'] = true;

        try {
            update_post_meta($postId, $metaKey, $value);
        } finally {
            if ($hadPreviousFlag) {
                $GLOBALS['__fifu_skip_db2_identifier_replication'] = $previousFlag;
            } else {
                unset($GLOBALS['__fifu_skip_db2_identifier_replication']);
            }
        }
    }

    private static function normalize_wai_featured_image_url_for_db2_confirmation(string $url): string
    {
        $url = trim($url);
        if ($url === '') {
            return '';
        }

        return function_exists('fifu_convert') ? fifu_convert($url) : $url;
    }

    private static function normalize_wai_featured_image_alt_for_db2_confirmation(string $alt): string
    {
        $alt = trim($alt);

        if ($alt === '' || preg_match('/^(null|undefined)$/i', $alt) === 1) {
            return '';
        }

        if (function_exists('wp_strip_all_tags')) {
            $alt = (string) wp_strip_all_tags($alt);
        } else {
            $alt = strip_tags($alt);
        }

        $alt = trim($alt);

        if ($alt === '' || preg_match('/^(null|undefined)$/i', $alt) === 1) {
            return '';
        }

        return $alt;
    }

    /**
     * @param array<string, mixed> $effectiveData
     * @param array<string, string|null> $legacyImageListSnapshot
     */
    private static function should_skip_unchanged_featured_image_alt_update(
        int $postId,
        array $effectiveData,
        bool $isInsertImport,
        bool $isCategoryImport,
        bool $isProductImport,
        bool $productUsesListOnlyMediaFields,
        array $legacyImageListSnapshot
    ): bool {
        if (
            $isInsertImport
            || $isCategoryImport
            || $isProductImport
            || $productUsesListOnlyMediaFields
        ) {
            return false;
        }

        $rawUrl = trim((string) ($effectiveData['fifu_image_url'] ?? ''));
        $rawAlt = trim((string) ($effectiveData['fifu_image_alt'] ?? ''));

        if ($rawUrl === '' || $rawAlt === '') {
            return false;
        }

        // If any legacy image/list residue exists, the normal path must still run so cleanup can happen.
        if (!empty($legacyImageListSnapshot)) {
            return false;
        }

        $conflictingFields = [
            'fifu_list_url',
            'fifu_list_alt',
            'fifu_video_url',
            'fifu_list_video_url',
            'fifu_slider_list_url',
            'fifu_slider_list_alt',
            'fifu_asin',
            'fifu_finder_url',
            'fifu_redirection_url',
        ];

        foreach ($conflictingFields as $field) {
            if (trim((string) ($effectiveData[$field] ?? '')) !== '') {
                return false;
            }
        }

        $expectedUrl = self::normalize_wai_featured_image_url_for_db2_confirmation($rawUrl);
        $expectedAlt = self::normalize_wai_featured_image_alt_for_db2_confirmation($rawAlt);

        if ($expectedUrl === '' || $expectedAlt === '') {
            return false;
        }

        return self::is_post_featured_image_and_alt_confirmed_in_db2(
            $postId,
            $expectedUrl,
            $expectedAlt
        );
    }

    /**
     * @param array<string, mixed> $effectiveData
     */
    private static function should_skip_unchanged_featured_image_alt_update_without_snapshot(
        int $postId,
        array $effectiveData,
        bool $isInsertImport,
        bool $isCategoryImport,
        bool $isProductImport
    ): bool {
        if ($isInsertImport || $isCategoryImport || $isProductImport) {
            return false;
        }

        $rawUrl = trim((string) ($effectiveData['fifu_image_url'] ?? ''));
        $rawAlt = trim((string) ($effectiveData['fifu_image_alt'] ?? ''));

        if ($rawUrl === '' || $rawAlt === '') {
            return false;
        }

        if (self::has_conflicting_media_payload_for_featured_image_alt_noop($effectiveData)) {
            return false;
        }

        if (self::has_legacy_image_list_residue_without_full_snapshot($postId)) {
            return false;
        }

        $expectedUrl = self::normalize_wai_featured_image_url_for_db2_confirmation($rawUrl);
        $expectedAlt = self::normalize_wai_featured_image_alt_for_db2_confirmation($rawAlt);

        if ($expectedUrl === '' || $expectedAlt === '') {
            return false;
        }

        return self::is_post_featured_image_and_alt_confirmed_in_db2(
            $postId,
            $expectedUrl,
            $expectedAlt
        );
    }

    /**
     * @param array<string, mixed> $effectiveData
     */
    private static function should_skip_unchanged_post_slider_list_update(
        int $postId,
        array $effectiveData,
        bool $isInsertImport,
        bool $isCategoryImport,
        bool $isProductImport
    ): bool {
        if ($isInsertImport || $isCategoryImport || $isProductImport) {
            return false;
        }

        $rawSliderList = trim((string) ($effectiveData['fifu_slider_list_url'] ?? ''));
        if ($rawSliderList === '') {
            return false;
        }

        if (trim((string) ($effectiveData['fifu_slider_list_alt'] ?? '')) !== '') {
            return false;
        }

        if (self::has_conflicting_media_payload_for_slider_noop($effectiveData)) {
            return false;
        }

        if (self::has_legacy_slider_residue_without_full_snapshot($postId)) {
            return false;
        }

        $incomingUrls = self::normalize_wai_slider_url_list_for_noop_confirmation($rawSliderList, $effectiveData);
        if ($incomingUrls === []) {
            return false;
        }

        $currentUrls = self::get_current_post_slider_urls_for_noop_confirmation($postId);
        if ($currentUrls === []) {
            return false;
        }

        return $incomingUrls === $currentUrls;
    }

    /**
     * Determine whether an unchanged property slider still requires derived
     * WordPress/Houzez attachment metadata to be regenerated.
     *
     * The DB2 slider is already confirmed by
     * should_skip_unchanged_post_slider_list_update(). This method must inspect
     * only the derived attachment state and must not modify DB2 or postmeta.
     *
     * @param array<string, mixed> $effectiveData
     */
    private static function should_queue_unchanged_property_slider_metadata_repair(
        int $postId,
        array $effectiveData,
        string $postType
    ): bool {
        if ($postType !== 'property') {
            return false;
        }

        $rawSliderList = trim((string) ($effectiveData['fifu_slider_list_url'] ?? ''));
        if ($rawSliderList === '') {
            return false;
        }

        $incomingUrls = self::normalize_wai_slider_url_list_for_noop_confirmation(
            $rawSliderList,
            $effectiveData
        );

        if ($incomingUrls === []) {
            return false;
        }

        return self::is_property_slider_metadata_incomplete($postId, $incomingUrls);
    }

    /**
     * @param array<int, string> $sliderUrls
     */
    private static function is_property_slider_metadata_incomplete(int $postId, array $sliderUrls): bool
    {
        if ($sliderUrls === []) {
            return false;
        }

        $thumbnailId = (int) get_post_meta($postId, '_thumbnail_id', true);
        if ($thumbnailId <= 0) {
            return true;
        }

        /*
         * Slider index 0 is the featured attachment. Remaining entries must be
         * represented by both the standard gallery metadata and Houzez property
         * image metadata.
         */
        $expectedGalleryCount = max(0, count($sliderUrls) - 1);
        if ($expectedGalleryCount === 0) {
            return false;
        }

        $galleryIds = self::normalize_positive_integer_meta_ids(
            get_post_meta($postId, '_product_image_gallery', true)
        );

        if (count($galleryIds) < $expectedGalleryCount) {
            return true;
        }

        if (
            !class_exists('Fifu_Theme_Detector', false)
            || !Fifu_Theme_Detector::is_houzez_active()
        ) {
            return false;
        }

        $propertyImageIds = self::normalize_positive_integer_meta_ids(
            get_post_meta($postId, 'fave_property_images', false)
        );

        return count($propertyImageIds) < $expectedGalleryCount;
    }

    /**
     * Normalize IDs stored as CSV values, repeated postmeta rows, or nested arrays.
     *
     * @param mixed $values
     * @return array<int, int>
     */
    private static function normalize_positive_integer_meta_ids($values): array
    {
        $pending = is_array($values) ? array_values($values) : [$values];
        $ids = [];

        while ($pending !== []) {
            $value = array_shift($pending);

            if (is_array($value)) {
                foreach ($value as $nestedValue) {
                    $pending[] = $nestedValue;
                }

                continue;
            }

            $parts = preg_split(
                '/[\s,]+/',
                trim((string) $value),
                -1,
                PREG_SPLIT_NO_EMPTY
            );

            if (!is_array($parts)) {
                continue;
            }

            foreach ($parts as $part) {
                $id = (int) $part;

                if ($id > 0) {
                    $ids[$id] = $id;
                }
            }
        }

        return array_values($ids);
    }

    /**
     * @param array<string, mixed> $effectiveData
     */
    private static function has_conflicting_media_payload_for_slider_noop(array $effectiveData): bool
    {
        $conflictingFields = [
            'fifu_image_url',
            'fifu_image_alt',
            'fifu_list_url',
            'fifu_list_alt',
            'fifu_video_url',
            'fifu_list_video_url',
            'fifu_asin',
            'fifu_finder_url',
            'fifu_redirection_url',
        ];

        foreach ($conflictingFields as $field) {
            if (trim((string) ($effectiveData[$field] ?? '')) !== '') {
                return true;
            }
        }

        return false;
    }

    private static function has_legacy_slider_residue_without_full_snapshot(int $postId): bool
    {
        global $wpdb;

        if (!isset($wpdb) || !is_object($wpdb) || !method_exists($wpdb, 'prepare') || !method_exists($wpdb, 'get_var')) {
            return true;
        }

        $postmetaTable = isset($wpdb->postmeta) && is_string($wpdb->postmeta) && $wpdb->postmeta !== ''
            ? $wpdb->postmeta
            : $wpdb->prefix . 'postmeta';

        $query = $wpdb->prepare(
            "
            SELECT meta_id
            FROM {$postmetaTable}
            WHERE post_id = %d
              AND (
                  meta_key IN ('fifu_slider_list_url', 'fifu_slider_list_alt')
                  OR meta_key REGEXP '^fifu_slider_image_(url|alt)_[0-9]+$'
              )
            LIMIT 1
            ",
            $postId
        );

        return $wpdb->get_var($query) !== null;
    }

    /**
     * @param array<string, mixed> $effectiveData
     * @return array<int, string>
     */
    private static function normalize_wai_slider_url_list_for_noop_confirmation(string $rawSliderList, array $effectiveData): array
    {
        $delimiter = (string) ($effectiveData['fifu_delimiter'] ?? '|');
        if ($delimiter === '') {
            $delimiter = '|';
        }

        $parts = array_map('trim', explode($delimiter, $rawSliderList));
        $urls = [];

        foreach ($parts as $url) {
            if ($url === '') {
                continue;
            }

            $normalizedUrl = function_exists('fifu_convert') ? fifu_convert($url) : $url;
            $normalizedUrl = trim((string) $normalizedUrl);

            if ($normalizedUrl !== '') {
                $urls[] = $normalizedUrl;
            }
        }

        return $urls;
    }

    /**
     * @return array<int, string>
     */
    private static function get_current_post_slider_urls_for_noop_confirmation(int $postId): array
    {
        if (!class_exists('Fifu_Post_Slider_List_Url_Read_Service', false)) {
            return [];
        }

        if (!method_exists('Fifu_Post_Slider_List_Url_Read_Service', 'get_slider_list_urls')) {
            return [];
        }

        $current = Fifu_Post_Slider_List_Url_Read_Service::get_slider_list_urls($postId);
        if (!is_array($current)) {
            return [];
        }

        $urls = [];

        foreach ($current as $url) {
            $normalizedUrl = function_exists('fifu_convert') ? fifu_convert((string) $url) : (string) $url;
            $normalizedUrl = trim($normalizedUrl);

            if ($normalizedUrl !== '') {
                $urls[] = $normalizedUrl;
            }
        }

        return $urls;
    }

    /**
     * @param array<string, mixed> $effectiveData
     */
    private static function has_conflicting_media_payload_for_featured_image_alt_noop(array $effectiveData): bool
    {
        $conflictingFields = [
            'fifu_list_url',
            'fifu_list_alt',
            'fifu_video_url',
            'fifu_list_video_url',
            'fifu_slider_list_url',
            'fifu_slider_list_alt',
            'fifu_asin',
            'fifu_finder_url',
            'fifu_redirection_url',
        ];

        foreach ($conflictingFields as $field) {
            if (trim((string) ($effectiveData[$field] ?? '')) !== '') {
                return true;
            }
        }

        return false;
    }

    private static function has_legacy_image_list_residue_without_full_snapshot(int $postId): bool
    {
        global $wpdb;

        if (!isset($wpdb) || !is_object($wpdb) || !method_exists($wpdb, 'prepare') || !method_exists($wpdb, 'get_var')) {
            return true;
        }

        $postmetaTable = isset($wpdb->postmeta) && is_string($wpdb->postmeta) && $wpdb->postmeta !== ''
            ? $wpdb->postmeta
            : $wpdb->prefix . 'postmeta';

        $query = $wpdb->prepare(
            "
            SELECT meta_id
            FROM {$postmetaTable}
            WHERE post_id = %d
              AND (
                  meta_key IN ('fifu_list_url', 'fifu_list_alt', 'fifu_image_url', 'fifu_image_alt')
                  OR meta_key REGEXP '^fifu_image_(url|alt)_[0-9]+$'
              )
            LIMIT 1
            ",
            $postId
        );

        return $wpdb->get_var($query) !== null;
    }

    /**
     * @param array<string, mixed> $effectiveData
     * @param array<string, string|null> $legacyImageListSnapshot
     */
    private static function should_skip_unchanged_product_image_list_update(
        int $postId,
        array $effectiveData,
        string $delimiter,
        bool $isInsertImport,
        bool $isCategoryImport,
        bool $isProductImport,
        array $legacyImageListSnapshot
    ): bool {
        if ($isInsertImport || $isCategoryImport || !$isProductImport) {
            return false;
        }

        $rawListUrl = trim((string) ($effectiveData['fifu_list_url'] ?? ''));
        $rawListAlt = trim((string) ($effectiveData['fifu_list_alt'] ?? ''));

        if ($rawListUrl === '' || $rawListAlt === '') {
            return false;
        }

        // If any legacy image-list residue exists, the normal path must still run so cleanup can happen.
        if (!empty($legacyImageListSnapshot)) {
            return false;
        }

        if (self::has_conflicting_media_payload_for_product_image_list_noop($effectiveData)) {
            return false;
        }

        $incomingUrls = self::normalize_wai_product_image_url_list_for_noop_confirmation(
            $rawListUrl,
            $delimiter
        );

        if ($incomingUrls === []) {
            return false;
        }

        $incomingAlts = self::normalize_wai_product_image_alt_list_for_noop_confirmation(
            $rawListAlt,
            $delimiter,
            count($incomingUrls)
        );

        if ($incomingAlts === []) {
            return false;
        }

        return self::product_image_list_db2_state_matches_payload($postId, $effectiveData, $delimiter);
    }

    /**
     * @param array<string, mixed> $effectiveData
     */
    private static function has_conflicting_media_payload_for_product_image_list_noop(array $effectiveData): bool
    {
        $conflictingFields = [
            'fifu_image_url',
            'fifu_image_alt',
            'fifu_video_url',
            'fifu_list_video_url',
            'fifu_slider_list_url',
            'fifu_slider_list_alt',
            'fifu_asin',
            'fifu_finder_url',
            'fifu_redirection_url',
        ];

        foreach ($conflictingFields as $field) {
            if (trim((string) ($effectiveData[$field] ?? '')) !== '') {
                return true;
            }
        }

        return false;
    }

    /**
     * @return array<int, string>
     */
    private static function normalize_wai_product_image_url_list_for_noop_confirmation(string $rawListUrl, string $delimiter): array
    {
        $delimiter = $delimiter === '' ? '|' : $delimiter;
        $normalized = self::fifu_normalize_wai_field_value('fifu_list_url', $rawListUrl, $delimiter);
        $urls = self::split_normalized_wai_list($normalized);

        $result = [];

        foreach ($urls as $url) {
            $url = trim((string) $url);
            $url = function_exists('fifu_convert') ? fifu_convert($url) : $url;
            $url = trim((string) $url);

            if ($url !== '') {
                $result[] = $url;
            }
        }

        return $result;
    }

    /**
     * @return array<int, string>
     */
    private static function normalize_wai_product_image_alt_list_for_noop_confirmation(
        string $rawListAlt,
        string $delimiter,
        int $urlCount
    ): array {
        $delimiter = $delimiter === '' ? '|' : $delimiter;
        $normalized = self::fifu_normalize_wai_field_value('fifu_list_alt', $rawListAlt, $delimiter);
        $alts = self::split_normalized_wai_alt_list_preserve_empty_slots($normalized);

        return self::normalize_product_image_alt_slots_for_noop_confirmation($alts, $urlCount);
    }

    /**
     * @param array<int, string> $alts
     * @return array<int, string>
     */
    private static function normalize_product_image_alt_slots_for_noop_confirmation(array $alts, int $urlCount): array
    {
        $result = [];

        for ($index = 0; $index < $urlCount; $index++) {
            $alt = trim((string) ($alts[$index] ?? ''));

            if ($alt !== '') {
                $alt = self::normalize_wai_featured_image_alt_for_db2_confirmation($alt);
            }

            $result[$index] = $alt;
        }

        return $result;
    }

    private static function is_post_featured_image_and_alt_confirmed_in_db2(
        int $postId,
        string $expectedUrl,
        string $expectedAlt
    ): bool {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return false;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return false;
        }

        if (method_exists($manager, 'getPostImageAndAltMapping')) {
            $mapping = $manager->getPostImageAndAltMapping($postId, 'image', 0);

            return is_array($mapping)
                && (string) ($mapping['url'] ?? '') === $expectedUrl
                && (string) ($mapping['alt'] ?? '') === $expectedAlt;
        }

        $imageMapping = $manager->getPostMapping($postId, 'image', 0);
        if (
            !is_array($imageMapping)
            || (string) ($imageMapping['url'] ?? '') !== $expectedUrl
        ) {
            return false;
        }

        $altMapping = $manager->getPostAltMapping($postId, 'image', 0);
        if (
            !is_array($altMapping)
            || (string) ($altMapping['alt'] ?? '') !== $expectedAlt
        ) {
            return false;
        }

        return true;
    }

    private static function cleanup_post_featured_image_and_alt_legacy_after_db2_confirmation(
        int $postId,
        string $expectedUrl,
        string $expectedAlt
    ): void {
        if (
            $expectedUrl === ''
            || $expectedAlt === ''
            || !self::is_post_featured_image_and_alt_confirmed_in_db2($postId, $expectedUrl, $expectedAlt)
        ) {
            return;
        }

        delete_post_meta($postId, 'fifu_image_url');
        delete_post_meta($postId, 'fifu_image_alt');

        clean_post_cache($postId);
        wp_cache_delete($postId, 'post_meta');
    }

    private static function should_use_gallery_only_db2_rebuild_for_product(int $post_id, array $data, array $article): bool
    {
        if (($article['post_type'] ?? '') !== 'product') {
            return false;
        }
        return false;
    }

    private static function should_use_video_gallery_only_db2_rebuild_for_product(int $post_id, array $data, array $article): bool
    {
        if (($article['post_type'] ?? '') !== 'product') {
            return false;
        }

        if (empty($data['fifu_list_video_url'] ?? '')) {
            return false;
        }

        $featuredVideoPayload = trim((string) ($data['fifu_video_url'] ?? ''));
        if (
            $featuredVideoPayload !== ''
            && (
                !class_exists('Fifu_Video_Helper', false)
                || !Fifu_Video_Helper::is_custom_video($featuredVideoPayload)
            )
        ) {
            return true;
        }

        if (trim((string) get_post_meta($post_id, 'fifu_video_url', true)) !== '') {
            return true;
        }

        if (trim((string) get_post_meta($post_id, 'fifu_custom_video_url', true)) !== '') {
            return false;
        }

        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return false;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return false;
        }

        $mapping = $manager->getPostMapping($post_id, 'video', 0);
        return is_array($mapping) && !empty($mapping['url']);
    }

    private static function resolve_wai_video_priority(array $data, array $article): ?bool
    {
        $hasImageList = trim((string) ($data['fifu_list_url'] ?? '')) !== '';
        $hasVideoList = trim((string) ($data['fifu_list_video_url'] ?? '')) !== '';
        $hasFeaturedVideo = trim((string) ($data['fifu_video_url'] ?? '')) !== '';
        $isCategory = ($article['post_type'] ?? '') === 'taxonomies';

        if ($isCategory) {
            return null;
        }

        if ($hasFeaturedVideo && !$hasVideoList) {
            return true;
        }

        if ($hasVideoList && !$hasImageList) {
            return true;
        }

        if ($hasImageList && !$hasVideoList) {
            return false;
        }

        if ($hasImageList && $hasVideoList) {
            return class_exists('Fifu_Options_Utils', false)
                && Fifu_Options_Utils::is_on('fifu_videos_before');
        }

        return null;
    }

    private static function cleanup_slider_legacy_postmeta_after_db2_confirmation(int $post_id, array $data, string $delimiter, array $fastProductSliderListResult = []): void
    {
        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return;
        }

        $legacySnapshot = self::snapshot_slider_legacy_postmeta($post_id);

        $expectedUrls = self::split_normalized_wai_list(
            self::fifu_normalize_wai_field_value(
                'fifu_slider_list_url',
                (string) ($data['fifu_slider_list_url'] ?? ''),
                $delimiter
            )
        );
        $urlsConfirmed = !empty($fastProductSliderListResult['urls_confirmed']);
        if (!$urlsConfirmed) {
            $urlsConfirmed = self::db2_slider_urls_confirmed($post_id, $manager, $expectedUrls);
        }
        if (!$urlsConfirmed) {
            self::restore_slider_legacy_postmeta($post_id, $legacySnapshot);
            return;
        }

        $expectedAlts = self::split_normalized_wai_alt_list_preserve_empty_slots(
            self::fifu_normalize_wai_field_value(
                'fifu_slider_list_alt',
                (string) ($data['fifu_slider_list_alt'] ?? ''),
                $delimiter
            )
        );
        $altsConfirmed = !empty($fastProductSliderListResult['alts_confirmed']);
        if (!$altsConfirmed) {
            $altsConfirmed = self::db2_slider_alts_confirmed($post_id, $manager, $expectedUrls, $expectedAlts);
        }
        if (!$altsConfirmed) {
            self::delete_raw_post_meta($post_id, 'fifu_slider_list_url');
            self::delete_indexed_post_meta_by_pattern($post_id, '/^fifu_slider_image_url_\d+$/');
            self::restore_slider_legacy_postmeta_from_snapshot_by_pattern(
                $post_id,
                $legacySnapshot,
                '/^(fifu_slider_list_alt|fifu_slider_image_alt_\d+)$/'
            );
            return;
        }

        self::delete_raw_post_meta($post_id, 'fifu_slider_list_url');
        self::delete_indexed_post_meta_by_pattern($post_id, '/^fifu_slider_image_url_\d+$/');
        self::delete_raw_post_meta($post_id, 'fifu_slider_list_alt');
        self::delete_indexed_post_meta_by_pattern($post_id, '/^fifu_slider_image_alt_\d+$/');
    }

    /**
     * @return array<string, string|null>
     */
    private static function snapshot_slider_legacy_postmeta(int $post_id): array
    {
        $snapshot = [];
        $meta = get_post_meta($post_id);
        if (!is_array($meta)) {
            return $snapshot;
        }

        foreach (array_keys($meta) as $metaKey) {
            if (preg_match('/^(fifu_slider_list_url|fifu_slider_list_alt|fifu_slider_image_url_\d+|fifu_slider_image_alt_\d+)$/', (string) $metaKey) !== 1) {
                continue;
            }

            $snapshot[(string) $metaKey] = get_post_meta($post_id, (string) $metaKey, true);
        }

        return $snapshot;
    }

    /**
     * @param array<string, string|null> $snapshot
     */
    private static function restore_slider_legacy_postmeta(int $post_id, array $snapshot): void
    {
        $meta = get_post_meta($post_id);
        if (is_array($meta)) {
            foreach (array_keys($meta) as $metaKey) {
                if (preg_match('/^(fifu_slider_list_url|fifu_slider_list_alt|fifu_slider_image_url_\d+|fifu_slider_image_alt_\d+)$/', (string) $metaKey) !== 1) {
                    continue;
                }

                delete_post_meta($post_id, (string) $metaKey);
            }
        }

        foreach ($snapshot as $metaKey => $metaValue) {
            if ($metaValue === null) {
                continue;
            }

            self::set_raw_post_meta($post_id, $metaKey, (string) $metaValue);
        }

        clean_post_cache($post_id);
        wp_cache_delete($post_id, 'post_meta');
    }

    /**
     * @param array<string, string|null> $snapshot
     */
    private static function restore_slider_legacy_postmeta_from_snapshot_by_pattern(int $post_id, array $snapshot, string $pattern): void
    {
        foreach ($snapshot as $metaKey => $metaValue) {
            if ($metaValue === null) {
                continue;
            }

            if (preg_match($pattern, (string) $metaKey) !== 1) {
                continue;
            }

            self::set_raw_post_meta($post_id, (string) $metaKey, (string) $metaValue);
        }

        clean_post_cache($post_id);
        wp_cache_delete($post_id, 'post_meta');
    }

    private static function restore_slider_alt_legacy_postmeta_from_payload(int $post_id, string $rawAltList, string $delimiter): void
    {
        $rawAltList = trim($rawAltList);
        if ($rawAltList === '') {
            return;
        }

        $normalizedAltList = self::fifu_normalize_wai_field_value('fifu_slider_list_alt', $rawAltList, $delimiter);
        $alts = self::split_normalized_wai_alt_list_preserve_empty_slots($normalizedAltList);
        foreach ($alts as $index => $alt) {
            $alt = trim((string) $alt);
            if ($alt === '') {
                continue;
            }

            self::set_raw_post_meta($post_id, 'fifu_slider_image_alt_' . $index, $alt);
        }

        clean_post_cache($post_id);
        wp_cache_delete($post_id, 'post_meta');
    }

    /**
     * @param array<int, string> $expectedUrls
     */
    private static function db2_slider_urls_confirmed(int $post_id, Fifu_Db2_Manager $manager, array $expectedUrls): bool
    {
        if ($expectedUrls === []) {
            return false;
        }

        foreach ($expectedUrls as $index => $expectedUrl) {
            $mapping = $manager->getPostMapping($post_id, 'slider', (int) $index);
            if (!is_array($mapping) || (string) ($mapping['url'] ?? '') !== $expectedUrl) {
                return false;
            }
        }

        return true;
    }

    /**
     * @param array<int, string> $expectedUrls
     * @param array<int, string> $expectedAlts
     */
    private static function db2_slider_alts_confirmed(int $post_id, Fifu_Db2_Manager $manager, array $expectedUrls, array $expectedAlts): bool
    {
        if ($expectedAlts === []) {
            return true;
        }

        $altIndexesToCheck = $expectedUrls !== [] ? array_keys($expectedUrls) : array_keys($expectedAlts);
        foreach ($altIndexesToCheck as $index) {
            $expectedAlt = trim((string) ($expectedAlts[$index] ?? ''));
            if ($expectedAlt === '') {
                continue;
            }

            $mapping = $manager->getPostAltMapping($post_id, 'slider', (int) $index);
            if (!is_array($mapping) || trim((string) ($mapping['alt'] ?? '')) !== $expectedAlt) {
                return false;
            }
        }

        return true;
    }

    private static function delete_indexed_post_meta_by_pattern(int $post_id, string $pattern): void
    {
        $meta = get_post_meta($post_id);
        if (!is_array($meta)) {
            return;
        }

        foreach (array_keys($meta) as $metaKey) {
            if (is_string($metaKey) && preg_match($pattern, $metaKey) === 1) {
                self::delete_raw_post_meta($post_id, $metaKey);
            }
        }
    }

    private static function delete_raw_post_meta(int $post_id, string $meta_key): void
    {
        global $wpdb;

        if (isset($wpdb) && is_object($wpdb) && property_exists($wpdb, 'postmeta')) {
            $wpdb->delete(
                $wpdb->postmeta,
                [
                    'post_id' => $post_id,
                    'meta_key' => $meta_key,
                ],
                [
                    '%d',
                    '%s',
                ]
            );

            clean_post_cache($post_id);
            wp_cache_delete($post_id, 'post_meta');
            return;
        }

        delete_post_meta($post_id, $meta_key);
    }

    private static function update_raw_post_meta(int $post_id, string $meta_key, string $meta_value): void
    {
        global $wpdb;

        if ($post_id <= 0 || $meta_key === '') {
            return;
        }

        if ($meta_value === '') {
            self::delete_raw_post_meta($post_id, $meta_key);
            return;
        }

        $existing_meta_id = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT meta_id FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = %s ORDER BY meta_id ASC LIMIT 1",
                $post_id,
                $meta_key
            )
        );

        if ($existing_meta_id !== null) {
            $wpdb->update(
                $wpdb->postmeta,
                ['meta_value' => $meta_value],
                ['meta_id' => (int) $existing_meta_id],
                ['%s'],
                ['%d']
            );

            $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = %s AND meta_id <> %d",
                    $post_id,
                    $meta_key,
                    (int) $existing_meta_id
                )
            );
        } else {
            $wpdb->insert(
                $wpdb->postmeta,
                [
                    'post_id' => $post_id,
                    'meta_key' => $meta_key,
                    'meta_value' => $meta_value,
                ],
                [
                    '%d',
                    '%s',
                    '%s',
                ]
            );
        }

        wp_cache_delete($post_id, 'post_meta');
    }

    private static function cleanup_product_legacy_derived_image_meta(int $post_id): void
    {
        $metaKeys = get_post_meta($post_id);
        if (!is_array($metaKeys)) {
            return;
        }

        foreach (array_keys($metaKeys) as $metaKey) {
            if (preg_match('/^fifu_image_(?:url|alt)_(\d+)$/', (string) $metaKey) === 1) {
                delete_post_meta($post_id, (string) $metaKey);
            }
        }

        clean_post_cache($post_id);
        wp_cache_delete($post_id, 'post_meta');
    }

    /**
     * @return array<string, string|null>
     */
    private static function snapshot_legacy_image_list_meta(int $post_id): array
    {
        $snapshot = [];
        $meta = get_post_meta($post_id);
        if (!is_array($meta)) {
            return $snapshot;
        }

        foreach (array_keys($meta) as $metaKey) {
            if (preg_match('/^(fifu_list_(?:url|alt)|fifu_image_(?:url|alt)(?:_\\d+)?)$/', (string) $metaKey) !== 1) {
                continue;
            }

            $snapshot[(string) $metaKey] = get_post_meta($post_id, (string) $metaKey, true);
        }

        return $snapshot;
    }

    /**
     * @param array<string, string|null> $snapshot
     */
    private static function cleanup_legacy_image_url_fields_after_db2_url_confirmation(int $post_id): void
    {
        self::delete_legacy_image_fields_by_type($post_id, true);
        delete_post_meta($post_id, 'fifu_list_url');

        clean_post_cache($post_id);
        wp_cache_delete($post_id, 'post_meta');
    }

    private static function cleanup_legacy_image_alt_fields_after_db2_alt_confirmation(int $post_id): void
    {
        $meta = get_post_meta($post_id);
        if (is_array($meta)) {
            foreach (array_keys($meta) as $metaKey) {
                if (preg_match('/^fifu_image_alt(?:_\d+)?$/', (string) $metaKey) !== 1) {
                    continue;
                }

                delete_post_meta($post_id, (string) $metaKey);
            }
        }

        clean_post_cache($post_id);
        wp_cache_delete($post_id, 'post_meta');
    }

    /**
     * @param array<string, string|null> $snapshot
     */
    private static function preserve_product_legacy_image_url_fields_after_db2_url_failure(
        int $post_id,
        array $data,
        array $snapshot
    ): void {
        self::restore_legacy_image_fields_by_type($post_id, $snapshot, true);
        self::restore_legacy_image_fields_by_type($post_id, $snapshot, false);

        if (array_key_exists('fifu_list_url', $snapshot)) {
            $value = $snapshot['fifu_list_url'];
            if ($value === null) {
                delete_post_meta($post_id, 'fifu_list_url');
            } else {
                self::set_raw_post_meta($post_id, 'fifu_list_url', (string) $value);
            }
        } elseif (array_key_exists('fifu_list_url', $data)) {
            self::set_raw_post_meta($post_id, 'fifu_list_url', (string) ($data['fifu_list_url'] ?? ''));
        }

        if (array_key_exists('fifu_list_alt', $snapshot)) {
            $value = $snapshot['fifu_list_alt'];
            if ($value === null) {
                delete_post_meta($post_id, 'fifu_list_alt');
            } else {
                self::set_raw_post_meta($post_id, 'fifu_list_alt', (string) $value);
            }
        } elseif (array_key_exists('fifu_list_alt', $data)) {
            self::set_raw_post_meta($post_id, 'fifu_list_alt', (string) ($data['fifu_list_alt'] ?? ''));
        }

        clean_post_cache($post_id);
        wp_cache_delete($post_id, 'post_meta');
    }

    /**
     * @param array<string, string|null> $snapshot
     */
    private static function preserve_product_legacy_image_list_on_db2_failure(
        int $post_id,
        array $data,
        array $snapshot
    ): void {
        self::preserve_product_legacy_image_url_fields_after_db2_url_failure($post_id, $data, $snapshot);
        Fifu_Wai_Meta_Service::restore_product_legacy_image_list_helper_meta($post_id, $data, $snapshot);
    }

    /**
     * @param array<string, string|null> $snapshot
     */
    private static function preserve_product_legacy_image_alt_fields_after_db2_alt_failure(
        int $post_id,
        array $data,
        array $snapshot
    ): void {
        if (array_key_exists('fifu_image_alt', $snapshot)) {
            $value = $snapshot['fifu_image_alt'];
            if ($value === null) {
                delete_post_meta($post_id, 'fifu_image_alt');
            } else {
                self::set_raw_post_meta($post_id, 'fifu_image_alt', (string) $value);
            }
        }

        foreach (array_keys($snapshot) as $metaKey) {
            if (preg_match('/^fifu_image_alt(?:_\\d+)?$/', (string) $metaKey) !== 1) {
                continue;
            }

            $value = $snapshot[(string) $metaKey];
            if ($value === null) {
                delete_post_meta($post_id, (string) $metaKey);
            } else {
                self::set_raw_post_meta($post_id, (string) $metaKey, (string) $value);
            }
        }

        if (array_key_exists('fifu_list_alt', $snapshot)) {
            $value = $snapshot['fifu_list_alt'];
            if ($value === null) {
                delete_post_meta($post_id, 'fifu_list_alt');
            } else {
                self::set_raw_post_meta($post_id, 'fifu_list_alt', (string) $value);
            }
        } elseif (array_key_exists('fifu_list_alt', $data)) {
            self::set_raw_post_meta($post_id, 'fifu_list_alt', (string) ($data['fifu_list_alt'] ?? ''));
        }

        clean_post_cache($post_id);
        wp_cache_delete($post_id, 'post_meta');
    }

    private static function cleanup_legacy_image_alt_derived_fields(int $post_id): void
    {
        global $wpdb;

        if (!isset($wpdb->postmeta)) {
            return;
        }

        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$wpdb->postmeta} WHERE post_id = %d AND (meta_key = %s OR meta_key REGEXP %s)",
                $post_id,
                'fifu_image_alt',
                '^fifu_image_alt(?:_[0-9]+)?$'
            )
        );

        clean_post_cache($post_id);
        wp_cache_delete($post_id, 'post_meta');
    }

    /**
     * @param array<string, string|null> $snapshot
     */
    private static function restore_legacy_image_fields_by_type(int $post_id, array $snapshot, bool $restoreUrls): void
    {
        $prefixPattern = $restoreUrls ? '/^(fifu_image_url(?:_\\d+)?)$/' : '/^(fifu_image_alt(?:_\\d+)?)$/';
        $meta = get_post_meta($post_id);
        $currentKeys = is_array($meta) ? array_keys($meta) : [];

        foreach ($currentKeys as $metaKey) {
            if (preg_match($prefixPattern, (string) $metaKey) !== 1) {
                continue;
            }

            if (!array_key_exists((string) $metaKey, $snapshot)) {
                delete_post_meta($post_id, (string) $metaKey);
            }
        }

        foreach ($snapshot as $metaKey => $metaValue) {
            if ($metaValue === null) {
                continue;
            }

            if ($restoreUrls) {
                if (preg_match('/^(fifu_image_url(?:_\\d+)?)$/', (string) $metaKey) !== 1) {
                    continue;
                }
            } else {
                if (preg_match('/^(fifu_image_alt(?:_\\d+)?)$/', (string) $metaKey) !== 1) {
                    continue;
                }
            }

            update_post_meta($post_id, $metaKey, $metaValue);
        }

        clean_post_cache($post_id);
        wp_cache_delete($post_id, 'post_meta');
    }

    private static function delete_legacy_image_fields_by_type(int $post_id, bool $deleteUrls): void
    {
        $meta = get_post_meta($post_id);
        if (!is_array($meta)) {
            return;
        }

        $pattern = $deleteUrls
            ? '/^(fifu_image_url(?:_\\d+)?|fifu_list_url)$/'
            : '/^(fifu_image_alt(?:_\\d+)?|fifu_list_alt)$/';
        foreach (array_keys($meta) as $metaKey) {
            if (preg_match($pattern, (string) $metaKey) !== 1) {
                continue;
            }

            delete_post_meta($post_id, (string) $metaKey);
        }

        clean_post_cache($post_id);
        wp_cache_delete($post_id, 'post_meta');
    }

    /**
     * @param array<string, string|null> $snapshot
     */
    private static function has_preexisting_db2_image_mappings(int $post_id, array $snapshot): bool
    {
        if (!function_exists('fifu_db2_manager')) {
            return false;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return false;
        }

        $currentMappings = $manager->getPostMappings($post_id, 'image');
        if (is_array($currentMappings) && !empty($currentMappings)) {
            return true;
        }

        $indices = [];
        foreach (array_keys($snapshot) as $metaKey) {
            if (preg_match('/^fifu_image_url_(\d+)$/', (string) $metaKey, $matches) === 1) {
                $indices[(int) $matches[1]] = true;
            }
        }

        foreach (array_keys($indices) as $index) {
            $mapping = $manager->getPostMapping($post_id, 'image', $index);
            if (is_array($mapping) && !empty($mapping)) {
                return true;
            }
        }

        return false;
    }

    private static function db2_key_type_exists(string $keyType): bool
    {
        global $wpdb;

        if (!isset($wpdb) || !is_object($wpdb) || !property_exists($wpdb, 'prefix')) {
            return false;
        }

        $table = $wpdb->prefix . 'fifu_key';
        $sql = $wpdb->prepare("SELECT 1 FROM {$table} WHERE key_type = %s LIMIT 1", $keyType);
        return (int) $wpdb->get_var($sql) === 1;
    }

    /**
     * Restore legacy image rows only when DB2 did not fully confirm the migrated list.
     *
     * @param array<string, string|null> $snapshot
     */
    private static function should_restore_legacy_image_rows_after_wai_import(
        int $post_id,
        array $snapshot,
        bool $productListDb2Confirmed,
        bool $productListUrlsDb2Confirmed,
        bool $productListAltDb2Confirmed,
        bool $productListDb2UrlFailed
    ): bool
    {
        if ($productListDb2Confirmed || ($productListUrlsDb2Confirmed && $productListAltDb2Confirmed)) {
            return false;
        }

        return $productListDb2UrlFailed || (!$productListUrlsDb2Confirmed && !$productListAltDb2Confirmed);
    }

    /**
     * @return string[]
     */
    private static function split_normalized_wai_list(string $value): array
    {
        $value = trim(rtrim($value, '|'));
        if ($value === '') {
            return [];
        }

        $parts = array_map(
            static fn(string $segment): string => trim($segment),
            explode('|', $value)
        );

        return array_values(array_filter($parts, static fn(string $segment): bool => $segment !== ''));
    }

    private static function split_normalized_wai_alt_list_preserve_empty_slots(string $value): array
    {
        $value = trim(rtrim($value, '|'));
        if ($value === '') {
            return [];
        }

        return array_map(
            static function (string $segment): string {
                $segment = trim($segment);
                if ($segment === '') {
                    return '';
                }

                if (function_exists('wp_strip_all_tags')) {
                    $segment = (string) wp_strip_all_tags($segment);
                } else {
                    $segment = strip_tags($segment);
                }

                return trim($segment);
            },
            explode('|', $value)
        );
    }

    private static function parse_wai_list_preserve_empty_slots(string $value): array
    {
        $value = trim($value);
        if ($value === '') {
            return [];
        }

        $delimiter = strpos($value, PHP_EOL) !== false && strpos($value, '|') === false ? PHP_EOL : '|';
        $value = rtrim($value, $delimiter);
        if ($value === '') {
            return [];
        }

        return array_map('trim', explode($delimiter, $value));
    }

    private static function normalize_wai_alt_list_for_url_count(string $rawAltValue, int $urlCount): array
    {
        $entries = self::parse_wai_list_preserve_empty_slots($rawAltValue);
        if ($urlCount <= 0 || $entries === []) {
            return [];
        }

        $entries = array_slice($entries, 0, $urlCount);
        $lastNonEmpty = -1;
        foreach ($entries as $index => $entry) {
            $entry = trim((string) $entry);
            $entries[$index] = $entry;
            if ($entry !== '') {
                $lastNonEmpty = $index;
            }
        }

        if ($lastNonEmpty < 0) {
            return [];
        }

        return array_values(array_slice($entries, 0, $lastNonEmpty + 1, true));
    }

    private static function product_image_list_db2_state_matches_payload(int $post_id, array $effectiveData, string $delimiter): bool
    {
        $normalizedUrlsRaw = self::fifu_normalize_wai_field_value('fifu_list_url', (string) ($effectiveData['fifu_list_url'] ?? ''), $delimiter);
        $expectedUrls = self::split_normalized_wai_list($normalizedUrlsRaw);
        if ($expectedUrls === []) {
            return false;
        }

        $expectedUrls = array_values(array_filter(
            array_map(
                static function (string $url): string {
                    $url = trim($url);

                    return function_exists('fifu_convert') ? trim((string) fifu_convert($url)) : $url;
                },
                $expectedUrls
            ),
            static fn(string $url): bool => $url !== ''
        ));

        if (!function_exists('fifu_db2_manager')) {
            return false;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'getPostMappings')) {
            return false;
        }

        $mappings = $manager->getPostMappings($post_id, 'image');
        if (!is_array($mappings) || count($mappings) !== count($expectedUrls)) {
            return false;
        }

        foreach (array_values($mappings) as $index => $mapping) {
            if (!is_array($mapping) || (int) ($mapping['key_index'] ?? -1) !== $index) {
                return false;
            }

            if (trim((string) ($mapping['url'] ?? '')) !== (string) $expectedUrls[$index]) {
                return false;
            }
        }

        $rawAlts = trim((string) ($effectiveData['fifu_list_alt'] ?? ''));
        if ($rawAlts === '') {
            return true;
        }

        if (!method_exists($manager, 'getPostAltMappings')) {
            return false;
        }

        $expectedAlts = self::split_normalized_wai_alt_list_preserve_empty_slots(
            self::fifu_normalize_wai_field_value('fifu_list_alt', $rawAlts, $delimiter)
        );
        $altMappings = $manager->getPostAltMappings($post_id, 'image');
        if (!is_array($altMappings)) {
            return false;
        }

        foreach ($expectedUrls as $index => $_expectedUrl) {
            $expectedAlt = trim((string) ($expectedAlts[$index] ?? ''));
            $actualAlt = '';
            foreach ($altMappings as $altMapping) {
                if (!is_array($altMapping) || (int) ($altMapping['key_index'] ?? -1) !== $index) {
                    continue;
                }

                $actualAlt = trim((string) ($altMapping['alt'] ?? ''));
                break;
            }

            if ($expectedAlt === '') {
                if ($actualAlt !== '') {
                    return false;
                }
                continue;
            }

            if ($actualAlt !== $expectedAlt) {
                return false;
            }
        }

        foreach ($altMappings as $altMapping) {
            if (!is_array($altMapping)) {
                continue;
            }

            if ((int) ($altMapping['key_index'] ?? -1) >= count($expectedUrls) && trim((string) ($altMapping['alt'] ?? '')) !== '') {
                return false;
            }
        }

        return true;
    }

    private static function should_skip_product_import_queue_for_orphan_image_titles(array $effectiveData, bool $preexistingDb2ImageMappings): bool
    {
        return trim((string) ($effectiveData['fifu_list_alt'] ?? '')) !== ''
            && trim((string) ($effectiveData['fifu_list_url'] ?? '')) === ''
            && trim((string) ($effectiveData['fifu_slider_list_url'] ?? '')) === ''
            && trim((string) ($effectiveData['fifu_list_video_url'] ?? '')) === ''
            && trim((string) ($effectiveData['fifu_video_url'] ?? '')) === ''
            && !$preexistingDb2ImageMappings;
    }

    private static function cleanup_product_legacy_image_alt_fields_only(int $post_id): void
    {
        $meta = get_post_meta($post_id);
        if (!is_array($meta)) {
            return;
        }

        foreach (array_keys($meta) as $metaKey) {
            if (preg_match('/^(fifu_list_alt|fifu_image_alt(?:_\d+)?)$/', (string) $metaKey) === 1) {
                delete_post_meta($post_id, (string) $metaKey);
            }
        }
    }

    private static function set_gallery_only_db2_rebuild_context(int $post_id, string $meta_key, bool $enabled): void
    {
        $context_key = $post_id . ':' . $meta_key;

        if (!isset($GLOBALS['__fifu_dev_gallery_only_db2_rebuild']) || !is_array($GLOBALS['__fifu_dev_gallery_only_db2_rebuild'])) {
            $GLOBALS['__fifu_dev_gallery_only_db2_rebuild'] = [];
        }

        if ($enabled) {
            $GLOBALS['__fifu_dev_gallery_only_db2_rebuild'][$context_key] = true;
            return;
        }

        unset($GLOBALS['__fifu_dev_gallery_only_db2_rebuild'][$context_key]);

        if (empty($GLOBALS['__fifu_dev_gallery_only_db2_rebuild'])) {
            unset($GLOBALS['__fifu_dev_gallery_only_db2_rebuild']);
        }
    }

    private static function clear_gallery_only_db2_rebuild_context(int $post_id, string $meta_key): void
    {
        self::set_gallery_only_db2_rebuild_context($post_id, $meta_key, false);
    }

    private static function set_video_gallery_only_db2_rebuild_context(int $post_id, string $meta_key, bool $enabled): void
    {
        $context_key = $post_id . ':' . $meta_key;

        if (!isset($GLOBALS['__fifu_dev_video_gallery_only_db2_rebuild']) || !is_array($GLOBALS['__fifu_dev_video_gallery_only_db2_rebuild'])) {
            $GLOBALS['__fifu_dev_video_gallery_only_db2_rebuild'] = [];
        }

        if ($enabled) {
            $GLOBALS['__fifu_dev_video_gallery_only_db2_rebuild'][$context_key] = true;
            return;
        }

        unset($GLOBALS['__fifu_dev_video_gallery_only_db2_rebuild'][$context_key]);

        if (empty($GLOBALS['__fifu_dev_video_gallery_only_db2_rebuild'])) {
            unset($GLOBALS['__fifu_dev_video_gallery_only_db2_rebuild']);
        }
    }

    private static function clear_video_gallery_only_db2_rebuild_context(int $post_id, string $meta_key): void
    {
        self::set_video_gallery_only_db2_rebuild_context($post_id, $meta_key, false);
    }

    private static function can_cleanup_post_custom_video_source_meta(int $postId, string $sourceValue): bool
    {
        if (!function_exists('fifu_db2_manager')) {
            return false;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return false;
        }

        [$expectedCustomVideoUrl, $expectedPosterUrl, $hasPoster] = self::split_custom_video_entry($sourceValue);

        if ($expectedCustomVideoUrl === '') {
            return false;
        }

        global $wpdb;
        $keyTable = $wpdb->prefix . 'fifu_key';
        $customVideoKeyExists = (bool) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT 1 FROM {$keyTable} WHERE key_type = %s LIMIT 1",
                'custom_video'
            )
        );
        if (!$customVideoKeyExists) {
            return false;
        }

        $customVideoMapping = $manager->getPostMapping($postId, 'custom_video', 0);
        if (
            !is_array($customVideoMapping) ||
            empty($customVideoMapping['url']) ||
            (string) $customVideoMapping['url'] !== $expectedCustomVideoUrl
        ) {
            return false;
        }

        global $wpdb;
        $keyTable = $wpdb->prefix . 'fifu_key';
        if (0 === (int) $wpdb->get_var($wpdb->prepare("SELECT 1 FROM {$keyTable} WHERE key_type = %s LIMIT 1", 'image'))) {
            return false;
        }

        if (!$hasPoster || $expectedPosterUrl === '') {
            return true;
        }

        return self::custom_video_poster_matches_oembed($expectedCustomVideoUrl, $expectedPosterUrl);
    }

    /**
     * @param array<string, mixed> $snapshot
     */
    private static function restore_post_custom_featured_video_legacy_source_if_not_confirmed(
        int $postId,
        string $sourceValue,
        array $snapshot
    ): void {
        $sourceValue = trim($sourceValue);
        if ($sourceValue === '' || !self::is_custom_featured_video_payload($sourceValue)) {
            return;
        }

        if (self::can_cleanup_post_custom_video_source_meta($postId, $sourceValue)) {
            return;
        }

        update_post_meta($postId, 'fifu_video_url', $sourceValue);

        if (array_key_exists('fifu_custom_video_url', $snapshot)) {
            $previousCustom = trim((string) $snapshot['fifu_custom_video_url']);
            if ($previousCustom !== '') {
                update_post_meta($postId, 'fifu_custom_video_url', $previousCustom);
            }
        }

        clean_post_cache($postId);
        wp_cache_delete($postId, 'post_meta');
    }

    private static function ensure_post_custom_featured_video_db2_mapping(int $postId, string $sourceValue): void
    {
        $sourceValue = trim($sourceValue);
        if ($sourceValue === '' || !self::is_custom_featured_video_payload($sourceValue)) {
            return;
        }

        [$videoUrl, $posterUrl, $hasPoster] = self::split_custom_video_entry($sourceValue);
        $videoUrl = trim((string) $videoUrl);
        $posterUrl = trim((string) $posterUrl);

        if ($videoUrl === '' || !function_exists('fifu_db2_manager')) {
            return;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'savePostUrl')) {
            return;
        }

        $manager->savePostUrl($postId, 'custom_video', 0, $videoUrl);
        if (method_exists($manager, 'deletePostMappings')) {
            $manager->deletePostMappings($postId, 'image', 0);
        }
    }

    private static function can_cleanup_term_custom_video_source_meta(int $termId, string $sourceValue): bool
    {
        if (!function_exists('fifu_db2_manager')) {
            return false;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return false;
        }

        [$expectedCustomVideoUrl, $expectedPosterUrl, $hasPoster] = self::split_custom_video_entry($sourceValue);

        if ($expectedCustomVideoUrl === '') {
            return false;
        }

        $customVideoMapping = $manager->getTermMapping($termId, 'custom_video');
        if (!is_array($customVideoMapping) || (string) ($customVideoMapping['url'] ?? '') !== $expectedCustomVideoUrl) {
            return false;
        }

        global $wpdb;
        $keyTable = $wpdb->prefix . 'fifu_key';
        if (0 === (int) $wpdb->get_var($wpdb->prepare("SELECT 1 FROM {$keyTable} WHERE key_type = %s LIMIT 1", 'image'))) {
            return false;
        }

        if (!$hasPoster || $expectedPosterUrl === '') {
            return true;
        }

        return self::custom_video_poster_matches_oembed($expectedCustomVideoUrl, $expectedPosterUrl);
    }

    /**
     * Returns the current meta value using DB2-first logic with legacy fallback.
     *
     * @param int    $object_id
     * @param string $field
     * @param bool   $is_term
     * @return string
     */
    private static function get_current_value_db2_first(int $object_id, string $field, bool $is_term): string
    {
        if ($is_term) {
            switch ($field) {
                case 'fifu_image_url':
                    $value = Fifu_Term_Image_Url_Read_Service::get_image_url($object_id);
                    break;
                case 'fifu_image_alt':
                    $value = Fifu_Term_Image_Alt_Read_Service::get_image_alt($object_id);
                    break;
                case 'fifu_video_url':
                    $value = Fifu_Term_Video_Read_Service::get_video_url($object_id);
                    break;
                default:
                    $value = get_term_meta($object_id, $field, true);
            }
            return $value === null ? '' : (string) $value;
        }

        switch ($field) {
            case 'fifu_image_url':
                $value = Fifu_Post_Image_Url_Read_Service::get_image_url($object_id);
                break;
            case 'fifu_image_alt':
                $value = Fifu_Post_Image_Alt_Read_Service::get_image_alt($object_id);
                break;
            case 'fifu_video_url':
                $value = Fifu_Post_Video_Read_Service::get_video_url($object_id);
                break;
            case 'fifu_list_url':
                $value = Fifu_Post_Image_List_Url_Read_Service::get_image_list_url($object_id);
                break;
            case 'fifu_list_alt':
                $value = Fifu_Post_Image_List_Alt_Read_Service::get_image_list_alt($object_id);
                break;
            case 'fifu_list_video_url':
                $value = Fifu_Post_Video_List_Url_Read_Service::get_video_list_url($object_id);
                break;
            case 'fifu_slider_list_url':
                $value = Fifu_Post_Slider_List_Url_Read_Service::get_slider_list_url($object_id);
                break;
            case 'fifu_slider_list_alt':
                $value = Fifu_Post_Slider_List_Alt_Read_Service::get_slider_list_alt($object_id);
                break;
            case 'fifu_asin':
                $value = Fifu_Post_Identifier_Read_Service::get_asin($object_id);
                break;
            case 'fifu_finder_url':
                $value = Fifu_Post_Finder_Read_Service::get_finder_url($object_id);
                break;
            default:
                $value = get_post_meta($object_id, $field, true);
        }

        return $value === null ? '' : (string) $value;
    }

    private static function should_force_db2_write_for_import_field(
        int $object_id,
        string $field,
        string $normalizedValue,
        bool $is_term
    ): bool {
        if ($normalizedValue === '') {
            return false;
        }

        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return false;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return false;
        }

        if ($is_term) {
            if ($field === 'fifu_image_url') {
                $mapping = $manager->getTermMapping($object_id, 'image');
                return !is_array($mapping) || (string) ($mapping['url'] ?? '') !== $normalizedValue;
            }

            if ($field === 'fifu_image_alt') {
                $mapping = $manager->getTermAltMapping($object_id, 'image');
                return !is_array($mapping) || (string) ($mapping['alt'] ?? '') !== $normalizedValue;
            }

            return false;
        }

        if ($field === 'fifu_image_url') {
            $mapping = $manager->getPostMapping($object_id, 'image', 0);
            return !is_array($mapping) || (string) ($mapping['url'] ?? '') !== $normalizedValue;
        }

        if ($field === 'fifu_image_alt') {
            $mapping = $manager->getPostAltMapping($object_id, 'image', 0);
            return !is_array($mapping) || (string) ($mapping['alt'] ?? '') !== $normalizedValue;
        }

        if ($field === 'fifu_slider_list_url') {
            $expectedUrls = array_values(array_filter(array_map(
                static function ($url): string {
                    return trim((string) $url);
                },
                explode('|', $normalizedValue)
            ), static function (string $url): bool {
                return $url !== '';
            }));

            $index = 0;
            foreach ($expectedUrls as $expectedUrl) {
                $mapping = $manager->getPostMapping($object_id, 'slider', $index);
                if (!is_array($mapping) || (string) ($mapping['url'] ?? '') !== $expectedUrl) {
                    return true;
                }
                $index++;
            }

            $extraMapping = $manager->getPostMapping($object_id, 'slider', $index);
            if (is_array($extraMapping) && trim((string) ($extraMapping['url'] ?? '')) !== '') {
                return true;
            }

            return false;
        }

        return false;
    }

    private static function confirm_term_image_db2_write(int $termId, string $url): void
    {
        $url = trim($url);
        if ($url === '') {
            return;
        }

        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return;
        }

        $mapping = $manager->getTermMapping($termId, 'image');
        if (is_array($mapping) && (string) ($mapping['url'] ?? '') === $url) {
            return;
        }

        fifu_update_or_delete_ctgr($termId, 'fifu_image_url', $url);
    }

    private static function cleanup_term_featured_image_and_alt_legacy_after_db2_confirmation(
        int $termId,
        string $expectedUrl,
        string $expectedAlt
    ): void {
        $deletedAny = false;

        if (function_exists('fifu_db2_manager') && class_exists('Fifu_Db2_Manager', false)) {
            $manager = fifu_db2_manager();
            if ($manager instanceof Fifu_Db2_Manager) {
                if ($expectedUrl !== '') {
                    $mapping = $manager->getTermMapping($termId, 'image');
                    if (is_array($mapping) && (string) ($mapping['url'] ?? '') === $expectedUrl) {
                        delete_term_meta($termId, 'fifu_image_url');
                        $deletedAny = true;
                    }
                }

                if ($expectedAlt !== '') {
                    $mapping = $manager->getTermAltMapping($termId, 'image');
                    if (is_array($mapping) && (string) ($mapping['alt'] ?? '') === $expectedAlt) {
                        delete_term_meta($termId, 'fifu_image_alt');
                        $deletedAny = true;
                    }
                }
            }
        }

        if (!$deletedAny) {
            return;
        }

        clean_term_cache($termId);
        wp_cache_delete($termId, 'term_meta');
    }

    /**
     * @return array{image: array<string, mixed>|null, alt: array<string, mixed>|null}
     */
    private static function snapshot_post_featured_image_db2_state(int $post_id): array
    {
        $snapshot = [
            'image' => null,
            'alt' => null,
        ];

        if (!function_exists('fifu_db2_manager') || !class_exists('Fifu_Db2_Manager', false)) {
            return $snapshot;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return $snapshot;
        }

        $imageMapping = $manager->getPostMapping($post_id, 'image', 0);
        if (is_array($imageMapping) && !empty($imageMapping)) {
            $snapshot['image'] = $imageMapping;
        }

        $altMapping = $manager->getPostAltMapping($post_id, 'image', 0);
        if (is_array($altMapping) && !empty($altMapping)) {
            $snapshot['alt'] = $altMapping;
        }

        return $snapshot;
    }

    /**
     * @param array{image: array<string, mixed>|null, alt: array<string, mixed>|null} $snapshot
     */
    private static function restore_post_featured_image_db2_state_after_failure(int $post_id, array $snapshot, string $expected_url): void
    {
        $expected_url = self::normalize_wai_featured_image_url_for_db2_confirmation($expected_url);
        $restoreImage = is_array($snapshot['image']) && !empty($snapshot['image']);
        $restoreAlt = is_array($snapshot['alt']) && !empty($snapshot['alt']);

        if (function_exists('fifu_db2_manager') && class_exists('Fifu_Db2_Manager', false)) {
            $manager = fifu_db2_manager();
            if ($manager instanceof Fifu_Db2_Manager) {
                if (method_exists($manager, 'deletePostMappings')) {
                    $manager->deletePostMappings($post_id, 'image', 0);
                }
                if (method_exists($manager, 'deletePostAltMappings')) {
                    $manager->deletePostAltMappings($post_id, 'image', 0);
                }
                if ($restoreImage && method_exists($manager, 'savePostUrl')) {
                    $imageUrl = (string) ($snapshot['image']['url'] ?? '');
                    if ($imageUrl !== '') {
                        $manager->savePostUrl($post_id, 'image', 0, $imageUrl);
                    }
                }
                if ($restoreAlt && method_exists($manager, 'savePostAlt')) {
                    $imageAlt = (string) ($snapshot['alt']['alt'] ?? '');
                    if ($imageAlt !== '') {
                        $manager->savePostAlt($post_id, 'image', 0, $imageAlt);
                    }
                }
                if (method_exists($manager, 'clearKeyCache')) {
                    $manager->clearKeyCache();
                }
            }
        }

        global $wpdb;
        if (isset($wpdb) && is_object($wpdb) && property_exists($wpdb, 'prefix')) {
            $mapTable = $wpdb->prefix . 'fifu_map';
            $altMapTable = $wpdb->prefix . 'fifu_alt_map';
            $keyTable = $wpdb->prefix . 'fifu_key';

            $wpdb->query(
                $wpdb->prepare(
                    "DELETE m
                     FROM {$mapTable} m
                     LEFT JOIN {$keyTable} k ON k.key_id = m.key_id
                     WHERE m.post_id = %d
                       AND m.key_index = 0
                       AND (k.key_type = 'image' OR k.key_id IS NULL)",
                    $post_id
                )
            );

            $wpdb->query(
                $wpdb->prepare(
                    "DELETE am
                     FROM {$altMapTable} am
                     LEFT JOIN {$keyTable} k ON k.key_id = am.key_id
                     WHERE am.post_id = %d
                       AND am.key_index = 0
                       AND (k.key_type = 'image' OR k.key_id IS NULL)",
                    $post_id
                )
            );
        }
    }

    private static function tmp_gallery_db2_mapping_count(int $post_id): int
    {
        if (!function_exists('fifu_db2_manager')) {
            return 0;
        }

        $manager = fifu_db2_manager();
        if (!$manager || !method_exists($manager, 'getPostMappings')) {
            return 0;
        }

        $mappings = $manager->getPostMappings($post_id, 'image');
        return is_array($mappings) ? count($mappings) : 0;
    }

}
