<?php
declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

/**
 * AAWP repository helpers for FIFU Premium.
 */
class Fifu_Aawp_Repository {

    private wpdb $wpdb;

    private string $table_lists;

    private string $table_products;

    public function __construct(?wpdb $wpdb = null) {
        $this->wpdb = $wpdb ?? $GLOBALS['wpdb'];
        $this->table_lists = $this->wpdb->prefix . 'aawp_lists';
        $this->table_products = $this->wpdb->prefix . 'aawp_products';
    }

    /**
     * Returns the product_asins field for an AAWP list.
     *
     * Mirrors get_aawp_asins().
     */
    public function get_asins(string $type, string $keywords): ?string {
        $result = $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT product_asins FROM {$this->table_lists} WHERE type = %s AND keywords = %s",
                $type,
                $keywords
            )
        );
        return $result ? (string) $result->product_asins : null;
    }

    /**
     * Returns the image_ids field for an AAWP product.
     *
     * Mirrors get_aawp_image_ids().
     */
    public function get_image_ids(string $asin): ?string {
        $result = $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT image_ids FROM {$this->table_products} WHERE asin = %s",
                $asin
            )
        );
        return $result ? (string) $result->image_ids : null;
    }
}
