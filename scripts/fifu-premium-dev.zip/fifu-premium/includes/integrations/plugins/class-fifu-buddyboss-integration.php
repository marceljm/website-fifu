<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

final class Fifu_BuddyBoss_Integration
{
    public static function register_hooks(): void
    {
        if (!Fifu_Options_Utils::is_on('fifu_bbpress_fields')) {
            return;
        }

        if (!Fifu_Plugin_Detector::is_buddyboss_platform_active()) {
            return;
        }

        add_filter('bp_activity_allowed_tags', [self::class, 'allow_image_tags'], 10, 1);
        add_action('bp_activity_before_save', [self::class, 'handle_activity_before_save']);
        add_filter('bp_get_activity_content', [self::class, 'convert_image_urls_to_img'], PHP_INT_MAX);
        add_filter('bp_get_activity_content_body', [self::class, 'convert_image_urls_to_img'], PHP_INT_MAX);
        add_filter('bp_get_activity_comment_content', [self::class, 'convert_image_urls_to_img'], PHP_INT_MAX);
        add_action('wp_enqueue_scripts', [self::class, 'enqueue_assets'], 20);
    }

    public static function convert_image_urls_to_img($html)
    {
        if (!is_string($html)) {
            return $html;
        }

        if ($html === '') {
            return $html;
        }

        $html = preg_replace_callback(
            '~<div\b[^>]*class="[^"]*\bfifu-img-wrap\b[^"]*"[^>]*>(.*?)</div>~is',
            static function ($m) {
                if (preg_match('~<img\b[^>]*>~i', $m[1], $img)) {
                    return $img[0];
                }
                return $m[1];
            },
            $html
        );

        $html = preg_replace('~<button\b[^>]*class="[^"]*\bfifu-img-remove\b[^"]*"[^>]*>.*?</button>~is', '', $html);
        $html = preg_replace('~<span\b[^>]*class="[^"]*\bdashicons-no-alt\b[^"]*"[^>]*>.*?</span>~is', '', $html);

        $html = preg_replace_callback(
            '~<a\b[^>]*href=(["\'])(.*?)\1[^>]*>.*?</a>~is',
            static function ($matches) {
                $url = self::normalize_image_url_for_compare($matches[2]);

                if (!self::is_image_url($url)) {
                    return $matches[0];
                }

                return '<img src="' . esc_url($url) . '" alt="" loading="lazy" />';
            },
            $html
        );

        $protected = [];
        $html = preg_replace_callback(
            '~<[^>]+>~',
            static function ($matches) use (&$protected) {
                $key = '%%FIFU_HTML_TAG_' . count($protected) . '%%';
                $protected[$key] = $matches[0];
                return $key;
            },
            $html
        );

        $html = preg_replace_callback(
            '~https?://[^\s<>"\']+\.(?:png|jpe?g|gif|webp|avif)(?:\?[^\s<>"\']*)?~i',
            static function ($matches) {
                $url = self::normalize_image_url_for_compare($matches[0]);

                if (!self::is_image_url($url)) {
                    return $matches[0];
                }

                return '<img src="' . esc_url($url) . '" alt="" loading="lazy" />';
            },
            $html
        );

        if ($protected !== []) {
            $html = strtr($html, $protected);
        }

        return self::dedupe_images_and_links($html);
    }

    public static function dedupe_images_and_links(string $html): string
    {
        $seen = [];

        $html = preg_replace_callback(
            '~<img\b[^>]*\bsrc=(["\'])(.*?)\1[^>]*>~i',
            static function ($matches) use (&$seen) {
                $key = self::normalize_image_url_for_compare($matches[2]);

                if (isset($seen[$key])) {
                    return '';
                }

                $seen[$key] = true;
                return $matches[0];
            },
            $html
        );

        $html = preg_replace_callback(
            '~<a\b[^>]*href=(["\'])(.*?)\1[^>]*>.*?</a>~is',
            static function ($matches) use (&$seen) {
                $key = self::normalize_image_url_for_compare($matches[2]);

                if (isset($seen[$key])) {
                    return '';
                }

                return $matches[0];
            },
            $html
        );

        $protected = [];
        $html = preg_replace_callback(
            '~<[^>]+>~',
            static function ($matches) use (&$protected) {
                $key = '%%FIFU_HTML_TAG_' . count($protected) . '%%';
                $protected[$key] = $matches[0];
                return $key;
            },
            $html
        );

        $html = preg_replace_callback(
            '~https?://[^\s<>"\']+\.(?:png|jpe?g|gif|webp|avif)(?:\?[^\s<>"\']*)?~i',
            static function ($matches) use (&$seen) {
                $key = self::normalize_image_url_for_compare($matches[0]);

                return isset($seen[$key]) ? '' : $matches[0];
            }
            ,
            $html
        );

        if ($protected !== []) {
            $html = strtr($html, $protected);
        }

        return preg_replace("~\s{2,}~", ' ', trim($html));
    }

    public static function allow_image_tags($tags)
    {
        if (!is_array($tags)) {
            return $tags;
        }

        $tags['img'] = [
            'src' => true, 'alt' => true, 'title' => true, 'width' => true, 'height' => true,
            'class' => true, 'loading' => true, 'decoding' => true, 'referrerpolicy' => true, 'style' => true,
            'data-src' => true, 'data-lazy-src' => true, 'data-original' => true, 'srcset' => true,
        ];
        return $tags;
    }

    public static function handle_activity_before_save($activity): void
    {
        if (!is_object($activity) || !isset($activity->content) || !is_string($activity->content) || $activity->content === '') {
            return;
        }

        $activity->content = self::convert_image_urls_to_img($activity->content);
    }

    private static function normalize_image_url_for_compare(string $url): string
    {
        return html_entity_decode(trim($url), ENT_QUOTES);
    }

    private static function is_image_url(string $url): bool
    {
        $normalized = self::normalize_image_url_for_compare($url);
        $path = parse_url($normalized, PHP_URL_PATH);

        if (!is_string($path) || $path === '') {
            return false;
        }

        return preg_match('/\.(?:png|jpe?g|gif|webp|avif)$/i', $path) === 1;
    }

    public static function enqueue_assets(): void
    {
        if (is_admin()) {
            return;
        }

        if (!Fifu_Plugin_Detector::is_buddyboss_platform_active()) {
            return;
        }

        if (function_exists('bp_is_active') && !bp_is_active('activity')) {
            return;
        }

        wp_enqueue_style(
            'fifu-buddyboss-css',
            plugins_url('/html/css/buddyboss.css', FIFU_PLUGIN_FILE),
            [],
            Fifu_Plugin_Info::get_enqueue_version()
        );

        wp_enqueue_script(
            'fifu-buddyboss',
            plugins_url('/html/js/buddyboss.js', FIFU_PLUGIN_FILE),
            ['jquery'],
            Fifu_Plugin_Info::get_enqueue_version(),
            true
        );
    }
}
