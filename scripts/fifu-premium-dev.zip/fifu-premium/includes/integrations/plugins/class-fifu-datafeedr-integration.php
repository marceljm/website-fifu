<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

final class Fifu_Datafeedr_Integration
{
    public static function register_hooks(): void
    {
        add_filter(
            'dfrps_do_import_product_thumbnail/do_import',
            [self::class, 'on_do_import_thumbnail'],
            10,
            3
        );
    }

    /**
     * Filter callback for dfrps_do_import_product_thumbnail/do_import.
     * It will eventually replace the legacy anonymous function.
     *
     * @param bool $doImport
     * @param WP_Post $post
     * @param array $product
     * @return bool
     */
    public static function on_do_import_thumbnail($doImport, $post, $product) {
        if (!$post instanceof WP_Post || !is_array($product)) {
            return $doImport;
        }

        $postId = is_numeric($post->ID ?? null) ? (int) $post->ID : 0;
        if ($postId <= 0) {
            return $doImport;
        }

        $imageValue = $product['image'] ?? null;
        if ($imageValue === null || !is_scalar($imageValue) || empty($imageValue)) {
            return $doImport;
        }

        $urls = [];
        $fields = [
            'image',
            'alternateimage',
            'alternateimagefour',
            'alternateimagethree',
            'alternateimagetwo',
        ];

        foreach ($fields as $field) {
            $value = $product[$field] ?? null;
            if ($value !== null && is_scalar($value) && !empty($value)) {
                $urls[] = (string) $value;
            }
        }

        Fifu_Developer_Media_Service::set_image_list(
            $postId,
            implode('|', $urls)
        );

        return false;
    }
}
