<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Handles bbPress-powered notices and media rendering in bbPress templates.
 */
final class Fifu_Bbpress_Integration
{
    /**
     * Registers the bbPress hooks that bridge the legacy functions.
     */
    public static function register_hooks(): void
    {
        add_action('bbp_theme_before_forum_title', [self::class, 'render_title_image']);
        add_action('bbp_theme_before_topic_title', [self::class, 'render_title_image']);
        add_action('bbp_theme_after_reply_content', [self::class, 'render_content_image']);
        add_action('bbp_theme_after_topic_content', [self::class, 'render_content_image']);
        add_action('bbp_theme_before_reply_form_tags', [self::class, 'render_form_field']);
        add_action('bbp_theme_before_topic_form_tags', [self::class, 'render_form_field']);
    }

    /**
     * Outputs the bbPress title image next to the forum/topic title.
     */
    public static function render_title_image(): void
    {
        if (Fifu_Options_Utils::is_off('fifu_bbpress_fields')) {
            return;
        }

        global $post;
        if (!isset($post) || !isset($post->ID)) {
            return;
        }

        $url = self::get_local_image_url((int) $post->ID);
        if (!$url) {
            $url = Fifu_Post_Main_Image_Resolver::get_main_image_url($post->ID, true);
        }
        if (!$url) {
            return;
        }

        $img_tag = '<img src="' . esc_url($url) . '" style="height:100px;width:100px;object-fit:cover" class="fifu-bbpress-img">';

        if (Fifu_Video_Helper::is_video_thumb($url)) {
            $video_url = Fifu_Post_Video_Read_Service::get_video_url((int) $post->ID);
            if (!empty($video_url)) {
                $icon = '<span style="position:absolute;bottom:0px;left:0;text-decoration:none;background-color:black;color:white;" class="dashicons dashicons-external"></span>';
                echo '<a href="' . esc_url($video_url) . '" target="_blank"><div class="alignleft" style="float:left;position:relative;padding-right:5px">' . $icon . $img_tag . '</div></a>';
                return;
            }

            echo '<div class="alignleft" style="float:left;position:relative;padding-right:5px">' . $img_tag . '</div>';
            return;
        }

        echo '<div class="alignleft" style="float:left;position:relative;padding-right:5px">' . $img_tag . '</div>';
    }

    /**
     * Renders the image after the forum/topic/reply content.
     */
    public static function render_content_image(): void
    {
        if (Fifu_Options_Utils::is_off('fifu_bbpress_fields')) {
            return;
        }

        $post_id = bbp_get_reply_id();
        $post_id = $post_id ?: bbp_get_topic_id();

        $url = self::get_local_image_url((int) $post_id);
        if (!$url) {
            $url = Fifu_Post_Main_Image_Resolver::get_main_image_url($post_id, true);
        }
        if (!$url) {
            return;
        }

        $img_tag = '<img src="' . esc_url($url) . '" style="width:100%;max-height:90vh;object-fit:contain" class="fifu-bbpress-img">';
        echo '<div style="width:100%">' . $img_tag . '</div>';
    }

    /**
     * Adds the bbPress topic/reply form field for injecting a FIFU image URL.
     */
    public static function render_form_field(): void
    {
        if (Fifu_Options_Utils::is_off('fifu_bbpress_fields')) {
            return;
        }

        $fifu = Fifu_Meta_Box_Php_Strings::get_strings();
        $post_id = self::get_form_entity_id();
        $image_url = '';
        if ($post_id > 0) {
            $image_url = self::get_local_image_url($post_id) ?? '';
            if ($image_url === '') {
                $image_url = Fifu_Post_Image_Url_Read_Service::get_image_url($post_id) ?? '';
            }
        }
        $placeholder = $fifu['common']['image']();

        echo "<input type='text' name='fifu_input_url' size='40' value='" . esc_attr($image_url) . "' placeholder='" . esc_attr($placeholder) . "'><br>";
    }

    private static function get_form_entity_id(): int
    {
        $current_filter = function_exists('current_filter') ? (string) current_filter() : '';

        if (function_exists('bbp_is_reply_edit') && bbp_is_reply_edit()) {
            return function_exists('bbp_get_reply_id') ? (int) bbp_get_reply_id() : 0;
        }

        if ($current_filter === 'bbp_theme_before_topic_form_tags') {
            return function_exists('bbp_get_topic_id') ? (int) bbp_get_topic_id() : 0;
        }

        if (function_exists('bbp_is_topic_edit') && bbp_is_topic_edit()) {
            return function_exists('bbp_get_topic_id') ? (int) bbp_get_topic_id() : 0;
        }

        return 0;
    }

    private static function get_local_image_url(int $post_id): string
    {
        if ($post_id <= 0) {
            return '';
        }

        if (!function_exists('get_post_meta')) {
            return '';
        }

        $url = (string) get_post_meta($post_id, 'fifu_image_url', true);
        return trim($url);
    }
}
