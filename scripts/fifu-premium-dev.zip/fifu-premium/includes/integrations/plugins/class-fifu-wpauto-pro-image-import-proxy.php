<?php

declare(strict_types=1);

if (!class_exists('WPAuto_Image_Import', false)) {
    return;
}

/**
 * Temporarily suppresses WPAuto downloads claimed by FIFU.
 */
final class Fifu_Wpauto_Pro_Image_Import_Proxy extends WPAuto_Image_Import
{
    /** @var object */
    private $original_importer;

    /** @var callable */
    private $should_suppress;

    public function __construct($originalImporter, callable $shouldSuppress)
    {
        $this->original_importer = $originalImporter;
        $this->should_suppress = $shouldSuppress;
    }

    public function fetch_remote_file($url, $post_date, $post_title = '')
    {
        try {
            if (call_user_func($this->should_suppress, $url)) {
                return new WP_Error(
                    'fifu_wpauto_remote_image'
                );
            }
        } catch (Throwable $exception) {
            unset($exception);
        }

        return $this->original_importer->fetch_remote_file(
            $url,
            $post_date,
            $post_title
        );
    }
}
