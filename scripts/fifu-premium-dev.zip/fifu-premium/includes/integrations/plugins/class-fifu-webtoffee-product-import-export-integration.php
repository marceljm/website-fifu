<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Bridges FIFU DB2 media with WebToffee WooCommerce product imports/exports.
 */
final class Fifu_Webtoffee_Product_Import_Export_Integration
{
    private const LIST_URL_COLUMN = 'meta:fifu_list_url';
    private const LIST_ALT_COLUMN = 'meta:fifu_list_alt';
    private const VIDEO_LIST_COLUMN = 'meta:fifu_list_video_url';

    public static function register_hooks(): void
    {
        add_filter(
            'wt_iew_product_post_columns',
            [self::class, 'add_product_post_columns'],
            10,
            1
        );

        add_filter(
            'wt_batch_product_export_row_data',
            [self::class, 'populate_export_row_data'],
            10,
            2
        );

        add_filter(
            'wt_iew_woocommerce_csv_product_bulk_product_columns',
            [self::class, 'add_bulk_product_columns'],
            10,
            1
        );

        add_filter(
            'wt_iew_product_bulk_export_csv_data',
            [self::class, 'populate_bulk_export_csv_data'],
            10,
            3
        );

        add_filter(
            'wt_iew_importer_alter_mapping_fields_basic',
            [self::class, 'add_import_mapping_fields'],
            20,
            3
        );

        add_filter(
            'wt_iew_importer_alter_meta_mapping_fields',
            [self::class, 'add_import_meta_mapping_fields'],
            20,
            3
        );

        add_action(
            'wt_woocommerce_product_import_inserted_product_object',
            [self::class, 'handle_inserted_product_object'],
            10,
            2
        );
    }

    /**
     * @param mixed $columns
     * @return array<mixed>
     */
    public static function add_product_post_columns($columns)
    {
        if (!is_array($columns)) {
            return $columns;
        }

        $columns[self::LIST_URL_COLUMN] = self::LIST_URL_COLUMN;
        $columns[self::LIST_ALT_COLUMN] = self::LIST_ALT_COLUMN;
        $columns[self::VIDEO_LIST_COLUMN] = self::VIDEO_LIST_COLUMN;

        return $columns;
    }

    /**
     * @param mixed $columns
     * @return array<mixed>
     */
    public static function add_bulk_product_columns($columns)
    {
        return self::add_product_post_columns($columns);
    }

    /**
     * Adds FIFU custom fields to WebToffee's product import mapping screen.
     *
     * @param mixed $fields
     * @param mixed $base
     * @param mixed $stepPageFormData
     * @return array<mixed>
     */
    public static function add_import_mapping_fields(
        $fields,
        $base,
        $stepPageFormData
    ) {
        if (!is_array($fields)) {
            return $fields;
        }

        if ($base !== null && !is_scalar($base)) {
            return $fields;
        }

        if ((string) ($base ?? '') !== 'product') {
            return $fields;
        }

        $fields[self::LIST_URL_COLUMN] = [
            'title' => self::LIST_URL_COLUMN,
            'description' => 'FIFU image URL list',
        ];

        $fields[self::LIST_ALT_COLUMN] = [
            'title' => self::LIST_ALT_COLUMN,
            'description' => 'FIFU image alt-text list',
        ];

        if (Fifu_Options_Utils::is_on('fifu_video')) {
            $fields[self::VIDEO_LIST_COLUMN] = [
                'title' => self::VIDEO_LIST_COLUMN,
                'description' => 'FIFU video URL list',
            ];
        }

        $fields['meta:fifu_image_url'] = [
            'title' => 'meta:fifu_image_url',
            'description' => 'FIFU legacy featured image URL',
        ];

        return $fields;
    }

    /**
     * Adds FIFU custom fields to WebToffee Pro's product meta mapping screen.
     *
     * @param mixed $fields
     * @param mixed $base
     * @param mixed $stepPageFormData
     * @return array<mixed>
     */
    public static function add_import_meta_mapping_fields(
        $fields,
        $base,
        $stepPageFormData
    ) {
        if (!is_array($fields)) {
            return $fields;
        }

        if ($base !== null && !is_scalar($base)) {
            return $fields;
        }

        if ((string) ($base ?? '') !== 'product') {
            return $fields;
        }

        if (
            !isset($fields['meta'])
            || !is_array($fields['meta'])
            || !isset($fields['meta']['fields'])
            || !is_array($fields['meta']['fields'])
        ) {
            return $fields;
        }

        $metaFields = [
            self::LIST_URL_COLUMN => [
                'title' => __(
                    'FIFU - Featured image + gallery URLs',
                    FIFU_SLUG
                ),
                'description' => __(
                    'Remote image URLs. The first URL is the featured image and remaining URLs are gallery images. Separate multiple URLs with |.',
                    FIFU_SLUG
                ),
            ],
            self::LIST_ALT_COLUMN => [
                'title' => __(
                    'FIFU - Image alt texts',
                    FIFU_SLUG
                ),
                'description' => __(
                    'Alt text values for the FIFU image list, in matching order. Separate multiple values with |.',
                    FIFU_SLUG
                ),
            ],
        ];

        if (Fifu_Options_Utils::is_on('fifu_video')) {
            $metaFields[self::VIDEO_LIST_COLUMN] = [
                'title' => __(
                    'FIFU - Video URLs',
                    FIFU_SLUG
                ),
                'description' => __(
                    'Remote video URLs handled by FIFU.',
                    FIFU_SLUG
                ),
            ];
        }

        foreach ($metaFields as $key => $field) {
            if (!array_key_exists($key, $fields['meta']['fields'])) {
                $fields['meta']['fields'][$key] = $field;
            }
        }

        return $fields;
    }

    /**
     * Populates only FIFU fields already selected in the associative row.
     *
     * @param mixed $row
     * @param mixed $product
     * @return array<mixed>
     */
    public static function populate_export_row_data(
        $row,
        $product
    ) {
        if (!is_array($row)) {
            return $row;
        }

        $postId = self::resolve_product_id($product);

        if ($postId <= 0) {
            return $row;
        }

        if (array_key_exists(self::LIST_URL_COLUMN, $row)) {
            $row[self::LIST_URL_COLUMN] =
                Fifu_Post_Image_List_Url_Read_Service::get_image_list_url(
                    $postId
                ) ?? '';
        }

        if (array_key_exists(self::LIST_ALT_COLUMN, $row)) {
            $row[self::LIST_ALT_COLUMN] =
                Fifu_Post_Image_List_Alt_Read_Service::get_image_list_alt(
                    $postId
                ) ?? '';
        }

        if (array_key_exists(self::VIDEO_LIST_COLUMN, $row)) {
            $row[self::VIDEO_LIST_COLUMN] =
                Fifu_Post_Video_List_Url_Read_Service::get_video_list_url(
                    $postId
                ) ?? '';
        }

        return $row;
    }

    /**
     * Populates FIFU values in WebToffee's indexed bulk-export row.
     *
     * @param mixed $row
     * @param mixed $productId
     * @param mixed $headerRow
     * @return array<mixed>
     */
    public static function populate_bulk_export_csv_data(
        $row,
        $productId,
        $headerRow
    ) {
        if (!is_array($row)) {
            return $row;
        }

        if (!is_array($headerRow)) {
            return $row;
        }

        $postId = is_numeric($productId) ? (int) $productId : 0;

        if ($postId <= 0 || !$headerRow) {
            return $row;
        }

        $values = self::get_export_values($postId);

        foreach ($headerRow as $index => $header) {
            $normalizedHeader = self::normalize_bulk_header($header);

            if (!array_key_exists($normalizedHeader, $values)) {
                continue;
            }

            $row[$index] = $values[$normalizedHeader];
        }

        return $row;
    }

    /**
     * Applies WebToffee custom-field imports to FIFU's DB2 services.
     *
     * @param mixed $product
     * @param mixed $data
     */
    public static function handle_inserted_product_object(
        $product,
        $data
    ): void {
        $postId = self::resolve_product_id($product);

        if ($postId <= 0 || !is_array($data)) {
            return;
        }

        $meta = self::extract_import_meta($data);

        $hasListUrl = array_key_exists('fifu_list_url', $meta);
        $hasLegacyImageUrl = array_key_exists('fifu_image_url', $meta);

        if ($hasListUrl || $hasLegacyImageUrl) {
            $imageUrls = $hasListUrl
                ? $meta['fifu_list_url']
                : $meta['fifu_image_url'];

            $imageAlts = array_key_exists('fifu_list_alt', $meta)
                ? $meta['fifu_list_alt']
                : null;

            Fifu_Developer_Media_Service::set_image_list(
                $postId,
                $imageUrls,
                $imageAlts
            );
        }

        if (array_key_exists('fifu_list_video_url', $meta)) {
            Fifu_Developer_Media_Service::set_video_list(
                $postId,
                $meta['fifu_list_video_url']
            );
        }
    }

    /**
     * @return array<string,string>
     */
    private static function get_export_values(int $postId): array
    {
        return [
            self::LIST_URL_COLUMN =>
                Fifu_Post_Image_List_Url_Read_Service::get_image_list_url(
                    $postId
                ) ?? '',

            self::LIST_ALT_COLUMN =>
                Fifu_Post_Image_List_Alt_Read_Service::get_image_list_alt(
                    $postId
                ) ?? '',

            self::VIDEO_LIST_COLUMN =>
                Fifu_Post_Video_List_Url_Read_Service::get_video_list_url(
                    $postId
                ) ?? '',
        ];
    }

    /**
     * WebToffee bulk headers may already be wrapped in CSV quotes.
     *
     * @param mixed $header
     */
    private static function normalize_bulk_header($header): string
    {
        if ($header !== null && !is_scalar($header)) {
            return '';
        }

        $header = trim((string) ($header ?? ''));

        if (
            strlen($header) >= 2
            && $header[0] === '"'
            && substr($header, -1) === '"'
        ) {
            $header = substr($header, 1, -1);
            $header = str_replace('""', '"', $header);
        }

        return trim($header);
    }

    /**
     * @param mixed $product
     */
    private static function resolve_product_id($product): int
    {
        if (
            is_object($product)
            && is_callable([$product, 'get_id'])
        ) {
            $id = $product->get_id();

            return is_numeric($id) ? max(0, (int) $id) : 0;
        }

        if (
            is_object($product)
            && isset($product->ID)
        ) {
            return is_numeric($product->ID) ? max(0, (int) $product->ID) : 0;
        }

        if (is_numeric($product)) {
            return max(0, (int) $product);
        }

        return 0;
    }

    /**
     * @param array<mixed> $data
     * @return array<string,string>
     */
    private static function extract_import_meta(array $data): array
    {
        $metaRows = $data['meta_data'] ?? null;

        if (!is_array($metaRows)) {
            return [];
        }

        $supportedKeys = [
            'fifu_list_url' => true,
            'fifu_list_alt' => true,
            'fifu_list_video_url' => true,
            'fifu_image_url' => true,
        ];

        $meta = [];

        foreach ($metaRows as $row) {
            if (!is_array($row)) {
                continue;
            }

            $keyValue = $row['key'] ?? '';

            if ($keyValue !== null && !is_scalar($keyValue)) {
                continue;
            }

            $key = trim((string) ($keyValue ?? ''));

            if (strpos($key, 'meta:') === 0) {
                $key = substr($key, 5);
            }

            if (
                $key === ''
                || !isset($supportedKeys[$key])
            ) {
                continue;
            }

            $value = $row['value'] ?? '';

            if (
                !is_scalar($value)
                && $value !== null
            ) {
                continue;
            }

            $meta[$key] = $value === null
                ? ''
                : (string) $value;
        }

        return $meta;
    }
}
