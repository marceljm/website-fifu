<?php
declare(strict_types=1);

defined('ABSPATH') || exit;

final class Fifu_Wp_Automatic_Integration
{

    public static function register_hooks(): void
    {
        add_action('added_post_meta', [self::class, 'handle_added_post_meta'], 10, 4);
    }

    public static function handle_added_post_meta($metaId, $postId, $metaKey, $metaValue): void
    {
        unset($metaId);

        if (!is_string($metaKey) || $metaKey !== 'fifu_list_url') {
            return;
        }

        if (!isset($_REQUEST['wp_automatic'])) {
            return;
        }

        $postId = is_numeric($postId) ? (int) $postId : 0;

        if ($postId <= 0 || !is_string($metaValue)) {
            return;
        }

        Fifu_Developer_Media_Service::set_image_list(
            $postId,
            str_replace(',', '|', $metaValue)
        );
    }
}
