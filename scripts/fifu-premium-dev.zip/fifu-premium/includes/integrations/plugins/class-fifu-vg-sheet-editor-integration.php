<?php

declare(strict_types=1);

/**
 * Encapsulates the VG Sheet Editor integration previously in admin/sheet-editor.php.
 */
class Fifu_VG_Sheet_Editor_Integration {

    /**
     * Register the VG Sheet Editor actions and filters.
     */
    public static function register_hooks(): void {
        add_action('vg_sheet_editor/editor/register_columns', [self::class, 'register_columns'], 20, 1);
        add_filter('vg_sheet_editor/columns/blacklisted_columns', [self::class, 'blacklist_columns'], 20, 2);
        add_action('plugins_loaded', [self::class, 'detach_legacy_wpse_columns'], 20);
    }

    /**
     * Register FIFU-specific columns with the sheet editor.
     */
    public static function register_columns($editor): void {
        if (!is_object($editor)) {
            return;
        }
        $args = $editor->args ?? null;
        if (!is_array($args)) {
            return;
        }
        $post_types = $args['enabled_post_types'] ?? null;
        $columns = $args['columns'] ?? null;
        if (!is_array($post_types) || !is_object($columns) || !method_exists($columns, 'register_item')) {
            return;
        }
        foreach ($post_types as $post_type) {
            if (!is_string($post_type) || !post_type_exists($post_type)) {
                return;
            }

            if ($post_type === 'product' && class_exists('WooCommerce')) {
                $columns->register_item(
                    'fifu_list_url',
                    $post_type,
                    [
                        'data_type' => 'meta_data',
                        'column_width' => 170,
                        'title' => 'fifu_list_url',
                        'type' => '',
                        'supports_formulas' => true,
                        'allow_to_hide' => true,
                        'allow_to_rename' => true,
                        'supports_sql_formulas' => true,
                        'save_value_callback' => [self::class, 'save_product_gallery_images'],
                    ]
                );
            } else {
                $columns->register_item(
                    'fifu_image_url',
                    $post_type,
                    [
                        'data_type' => 'meta_data',
                        'column_width' => 170,
                        'title' => 'fifu_image_url',
                        'type' => '',
                        'supports_formulas' => true,
                        'allow_to_hide' => true,
                        'allow_to_rename' => true,
                        'supports_sql_formulas' => true,
                        'save_value_callback' => [self::class, 'save_image_url'],
                    ]
                );

                $columns->register_item(
                    'fifu_image_alt',
                    $post_type,
                    [
                        'data_type' => 'meta_data',
                        'column_width' => 170,
                        'title' => 'fifu_image_alt',
                        'type' => '',
                        'supports_formulas' => true,
                        'allow_to_hide' => true,
                        'allow_to_rename' => true,
                        'supports_sql_formulas' => true,
                    ]
                );
            }
        }
    }

    /**
     * Prevent undesired columns from appearing in the sheet editor.
     */
    public static function blacklist_columns($columns, $post_type) {
        if (!is_array($columns) || !is_string($post_type)) {
            return $columns;
        }
        if ($post_type === 'product' && class_exists('WooCommerce')) {
            $columns[] = 'fifu_image_url';
            $columns[] = 'fifu_image_alt';
        } else {
            $columns[] = 'fifu_audio_url';
            $columns[] = 'fifu_video_url';
            $columns[] = 'fifu_redirection_url';
            $columns[] = 'fifu_search_proxy';
            $columns[] = 'fifu_custom_video_url';
        }

        return $columns;
    }

    /**
     * Persist the featured image URL submitted from the sheet editor.
     */
    public static function save_image_url($post_id, $cell_key, $url, $post_type, $cell_args, $spreadsheet_columns): void {
        $post_id = is_numeric($post_id) ? (int) $post_id : 0;
        if ($post_id <= 0 || ($url !== null && !is_scalar($url))) {
            return;
        }
        Fifu_Developer_Media_Service::set_image(
            $post_id,
            (string) ($url ?? '')
        );
    }

    /**
     * Persist the product gallery images submitted from the sheet editor.
     */
    public static function save_product_gallery_images($post_id, $cell_key, $urls, $post_type, $cell_args, $spreadsheet_columns): void {
        $post_id = is_numeric($post_id) ? (int) $post_id : 0;
        if ($post_id <= 0 || ($urls !== null && !is_scalar($urls))) {
            return;
        }
        Fifu_Developer_Media_Service::set_image_list(
            $post_id,
            self::normalize_urls((string) ($urls ?? ''))
        );
    }

    /**
     * Normalize the gallery URL list provided by the sheet editor.
     */
    private static function normalize_urls(string $urls): string {
        $cleaned = str_replace(["\r\n", "\r"], "\n", $urls);
        $cleaned = str_replace(' ', '', $cleaned);

        preg_match_all('/\bhttp/i', $cleaned, $matches, PREG_OFFSET_CAPTURE);
        $delimiter_counts = [',' => 0, '|' => 0, "\n" => 0];

        foreach ($matches[0] as $index => $match) {
            if ($index === 0) {
                continue;
            }

            $pos = $match[1];
            if ($pos === 0) {
                continue;
            }

            $prev_char = $cleaned[$pos - 1];
            if (isset($delimiter_counts[$prev_char])) {
                $delimiter_counts[$prev_char]++;
            }
        }

        arsort($delimiter_counts);
        $detected_delimiter = array_key_first($delimiter_counts);

        $split_regex = '/(?=' . preg_quote($detected_delimiter, '/') . '?http)/i';
        $url_list = preg_split($split_regex, $cleaned, -1, PREG_SPLIT_NO_EMPTY);

        $url_list = array_map(function ($url) use ($detected_delimiter) {
            return ltrim($url, $detected_delimiter);
        }, $url_list);

        return implode('|', $url_list);
    }

    /**
     * Detach the legacy WPSE register_columns hook from the free plugin.
     */
    public static function detach_legacy_wpse_columns(): void {
        if (!class_exists('WPSE_Featured_Image_From_Url')) {
            return;
        }

        $originalInstance = WPSE_Featured_Image_From_Url_Obj();

        remove_action(
            'vg_sheet_editor/editor/register_columns',
            [$originalInstance, 'register_columns'],
            10
        );
    }
}
