<?php

declare(strict_types=1);

defined('ABSPATH') || exit;

/**
 * Integrates WPAuto Pro media with FIFU's developer media services.
 */
final class Fifu_Wpauto_Pro_Integration
{
    /** @var array<int,string> */
    private static array $pending_images = [];

    /** @var array<int,string> */
    private static array $handled_videos = [];

    /** @var array<int,bool> */
    private static array $finalizing_posts = [];

    /** @var array<string,int[]> URL to queued owning post IDs. */
    private static array $suppressed_downloads = [];

    /** @var array<int,array<string,bool>> */
    private static array $suppression_posts = [];

    /** @var object|null */
    private static $original_image_importer = null;

    private static bool $download_proxy_installed = false;

    public static function register_hooks(): void
    {
        if (!class_exists('Fifu_Plugin_Detector') || !Fifu_Plugin_Detector::is_wpauto_pro_active()) {
            return;
        }

        add_filter(
            'wpauto_extracted_img_args',
            [self::class, 'capture_image_args'],
            10,
            1
        );

        add_filter(
            'wpauto_extracted_content',
            [self::class, 'finalize_content'],
            10,
            1
        );

        add_action(
            'added_post_meta',
            [self::class, 'handle_video_meta'],
            10,
            4
        );

        add_action(
            'updated_post_meta',
            [self::class, 'handle_video_meta'],
            10,
            4
        );
    }

    /**
     * Capture WPAuto Pro's original featured-image URL before local processing.
     *
     * @param mixed $imgArgs WPAuto image arguments.
     * @return mixed The unchanged WPAuto image arguments.
     */
    public static function capture_image_args($imgArgs)
    {
        if (!is_array($imgArgs)) {
            return $imgArgs;
        }

        $postId = self::positive_id($imgArgs['post_id'] ?? 0);
        if ($postId <= 0 || !array_key_exists('src', $imgArgs)) {
            return $imgArgs;
        }

        $options = self::get_wpauto_options();
        if (
            self::is_ai_generated_image_option($options)
            || !empty($options['strip_featured_image'])
        ) {
            return $imgArgs;
        }

        $url = self::eligible_remote_url($imgArgs['src']);
        if ($url === null || isset(self::$pending_images[$postId])) {
            return $imgArgs;
        }

        self::$pending_images[$postId] = $url;
        self::register_suppression_claim($postId, $url);

        $single = self::get_runtime_single();
        self::register_gallery_suppression_claims($postId, $single, $options, $url);
        self::install_download_proxy();

        return $imgArgs;
    }

    /**
     * Finalize captured WPAuto media after WPAuto's own image processing.
     *
     * @param mixed $content WPAuto post content.
     * @return mixed The unchanged post content.
     */
    public static function finalize_content($content)
    {
        $single = self::get_runtime_single();
        $postId = self::positive_id(is_object($single) ? ($single->process_post_id ?? 0) : 0);
        if ($postId <= 0 || isset(self::$finalizing_posts[$postId])) {
            return $content;
        }

        self::$finalizing_posts[$postId] = true;

        try {
            $base = self::get_runtime_base();
            $options = self::get_wpauto_options($base);

            if (self::is_ai_generated_image_option($options) || !empty($options['strip_featured_image'])) {
                return $content;
            }

            $urls = self::get_effective_image_urls(
                $single,
                $options,
                self::$pending_images[$postId] ?? null
            );

            if ($urls !== []) {
                self::save_image_state($postId, $urls);
            }
        } finally {
            self::clear_suppression_claims($postId);
            self::restore_download_proxy();
            unset(self::$pending_images[$postId], self::$finalizing_posts[$postId]);
        }

        return $content;
    }

    /**
     * Pass WPAuto Pro's selected YouTube URL to FIFU.
     *
     * @param mixed $metaId Meta ID.
     * @param mixed $postId Post ID.
     * @param mixed $metaKey Meta key.
     * @param mixed $metaValue Meta value.
     */
    public static function handle_video_meta(
        $metaId,
        $postId,
        $metaKey,
        $metaValue
    ): void {
        unset($metaId);

        if (!is_string($metaKey) || $metaKey !== 'wpauto_youtube_video_url') {
            return;
        }

        $postId = self::positive_id($postId);
        if ($postId <= 0) {
            return;
        }

        $url = self::eligible_remote_url($metaValue);
        if ($url === null || isset(self::$handled_videos[$postId]) && self::$handled_videos[$postId] === $url) {
            return;
        }

        self::$handled_videos[$postId] = $url;
        Fifu_Developer_Media_Service::set_video($postId, $url);
    }

    /**
     * Save one canonical image operation for the finalized post.
     *
     * @param int $postId Post ID.
     * @param array<int,string> $urls Ordered eligible image URLs.
     */
    private static function save_image_state(int $postId, array $urls): void
    {
        if (count($urls) >= 2) {
            Fifu_Developer_Media_Service::set_image_list($postId, implode('|', $urls));
            return;
        }

        if (isset($urls[0])) {
            Fifu_Developer_Media_Service::set_image($postId, $urls[0]);
        }
    }

    private static function is_gallery_enabled($single, array $options): bool
    {
        if (!is_object($single)) {
            return false;
        }

        if (!empty($options['image_from_amazon'])) {
            return true;
        }

        return ($single->post_type ?? '') === 'product' && !empty($options['gallery_image_opt']);
    }

    /**
     * Return the same ordered eligible image state used by finalization.
     *
     * @param mixed $single WPAuto campaign singleton.
     * @param array<string,mixed> $options WPAuto options.
     * @param mixed $capturedUrl Captured featured URL.
     * @return string[]
     */
    private static function get_effective_image_urls($single, array $options, $capturedUrl): array
    {
        if (self::is_ai_generated_image_option($options) || !empty($options['strip_featured_image'])) {
            return [];
        }

        $featuredUrl = self::eligible_remote_url($capturedUrl);
        $preData = is_object($single) ? ($single->pre_data ?? null) : null;
        $images = is_array($preData) && isset($preData['images']) && is_array($preData['images'])
            ? $preData['images']
            : [];

        if ($images !== []) {
            if ($featuredUrl === null) {
                $featuredUrl = self::eligible_remote_url($images[0] ?? null);
            }

            if ($featuredUrl === null) {
                return [];
            }

            $rawGallery = array_values($images);
            array_shift($rawGallery);

            $galleryEnabled = empty($options['no_gallery_images']) && self::is_gallery_enabled($single, $options);
            if ($galleryEnabled) {
                $limit = self::gallery_limit($options);
                if ($limit === 0) {
                    $rawGallery = [];
                } elseif ($limit > 0) {
                    $rawGallery = array_slice($rawGallery, 0, $limit);
                }
            } else {
                $rawGallery = [];
            }

            $urls = [$featuredUrl];
            $seen = [$featuredUrl => true];
            foreach ($rawGallery as $image) {
                $url = self::eligible_remote_url($image);
                if ($url === null || isset($seen[$url])) {
                    continue;
                }

                $seen[$url] = true;
                $urls[] = $url;
            }

            return $urls;
        }

        if ($featuredUrl === null && is_object($single)) {
            $featuredUrl = self::eligible_remote_url($single->featured_image ?? null);
        }

        return $featuredUrl === null ? [] : [$featuredUrl];
    }

    private static function register_gallery_suppression_claims($postId, $single, array $options, string $featuredUrl): void
    {
        if (
            !is_object($single)
            || !empty($options['no_gallery_images'])
            || !empty($options['image_from_amazon'])
            || ($single->post_type ?? '') !== 'product'
            || empty($options['gallery_image_opt'])
        ) {
            return;
        }

        $urls = self::get_effective_image_urls($single, $options, $featuredUrl);
        foreach (array_slice($urls, 1) as $url) {
            self::register_suppression_claim($postId, $url);
        }
    }

    private static function register_suppression_claim(int $postId, string $url): void
    {
        if (isset(self::$suppression_posts[$postId][$url])) {
            return;
        }

        self::$suppression_posts[$postId][$url] = true;
        self::$suppressed_downloads[$url] ??= [];
        self::$suppressed_downloads[$url][] = $postId;
    }

    private static function consume_download_claim($value): bool
    {
        $url = self::normalize_claim_url($value);
        if ($url === null || empty(self::$suppressed_downloads[$url])) {
            return false;
        }

        $ownerPostId = array_shift(self::$suppressed_downloads[$url]);
        if (self::$suppressed_downloads[$url] === []) {
            unset(self::$suppressed_downloads[$url]);
        }

        if (is_int($ownerPostId) && isset(self::$suppression_posts[$ownerPostId][$url])) {
            unset(self::$suppression_posts[$ownerPostId][$url]);
            if (self::$suppression_posts[$ownerPostId] === []) {
                unset(self::$suppression_posts[$ownerPostId]);
            }
        }

        if (self::$suppressed_downloads === []) {
            self::restore_download_proxy();
        }

        return true;
    }

    private static function normalize_claim_url($value): ?string
    {
        if (!(is_string($value) || is_int($value) || is_float($value))) {
            return null;
        }

        $url = trim((string) $value);
        return $url === '' ? null : $url;
    }

    private static function clear_suppression_claims(int $postId): void
    {
        foreach (array_keys(self::$suppression_posts[$postId] ?? []) as $url) {
            if (isset(self::$suppressed_downloads[$url])) {
                self::$suppressed_downloads[$url] = array_values(array_filter(
                    self::$suppressed_downloads[$url],
                    static fn ($ownerPostId): bool => (int) $ownerPostId !== $postId
                ));
                if (self::$suppressed_downloads[$url] === []) {
                    unset(self::$suppressed_downloads[$url]);
                }
            }
        }

        unset(self::$suppression_posts[$postId]);
    }

    private static function install_download_proxy(): void
    {
        if (self::$download_proxy_installed) {
            return;
        }

        if (
            !class_exists('WPAuto_Image_Import', false)
            || !property_exists('WPAuto_Image_Import', 'instance')
        ) {
            return;
        }

        try {
            $original = WPAuto_Image_Import::$instance;
            if (!is_object($original) && method_exists('WPAuto_Image_Import', 'instance')) {
                $original = WPAuto_Image_Import::instance();
            }

            if (!is_object($original) || !method_exists($original, 'fetch_remote_file')) {
                return;
            }

            $proxyFile = __DIR__ . '/class-fifu-wpauto-pro-image-import-proxy.php';
            if (!class_exists('Fifu_Wpauto_Pro_Image_Import_Proxy', false) && is_file($proxyFile)) {
                require_once $proxyFile;
            }

            if (!class_exists('Fifu_Wpauto_Pro_Image_Import_Proxy', false)) {
                return;
            }

            self::$original_image_importer = $original;
            WPAuto_Image_Import::$instance = new Fifu_Wpauto_Pro_Image_Import_Proxy(
                $original,
                static function ($url): bool {
                    return self::consume_download_claim($url);
                }
            );
            self::$download_proxy_installed = true;
        } catch (Throwable $exception) {
            unset($exception);
            self::$original_image_importer = null;
            self::$download_proxy_installed = false;
        }
    }

    private static function restore_download_proxy(): void
    {
        if (self::$suppressed_downloads !== []) {
            return;
        }

        if (self::$download_proxy_installed && class_exists('WPAuto_Image_Import', false)) {
            try {
                WPAuto_Image_Import::$instance = self::$original_image_importer;
            } catch (Throwable $exception) {
                unset($exception);
            }
        }

        self::$original_image_importer = null;
        self::$download_proxy_installed = false;
    }

    private static function gallery_limit(array $options): int
    {
        if (!array_key_exists('limit_gallery_images', $options)) {
            return -1;
        }

        $limit = (int) $options['limit_gallery_images'];
        return $limit < 0 ? -1 : $limit;
    }

    /**
     * Normalize and validate a remote URL for image or video use.
     *
     * @param mixed $value Candidate URL.
     * @return string|null Normalized eligible URL, or null.
     */
    private static function eligible_remote_url($value): ?string
    {
        if (!(is_string($value) || is_int($value) || is_float($value))) {
            return null;
        }

        $url = trim((string) $value);
        if ($url === '' || preg_match('/^(?:data|blob):/i', $url) === 1) {
            return null;
        }

        $parts = parse_url($url);
        $scheme = is_array($parts) ? strtolower((string) ($parts['scheme'] ?? '')) : '';
        if (!in_array($scheme, ['http', 'https'], true) || filter_var($url, FILTER_VALIDATE_URL) === false) {
            return null;
        }

        if (function_exists('attachment_url_to_postid')) {
            try {
                if ((int) attachment_url_to_postid($url) > 0) {
                    return null;
                }
            } catch (Throwable $exception) {
                unset($exception);
            }
        }

        if (function_exists('wp_upload_dir')) {
            try {
                $uploadDir = wp_upload_dir();
                if (is_array($uploadDir) && self::is_under_upload_base($url, $uploadDir['baseurl'] ?? null)) {
                    return null;
                }
            } catch (Throwable $exception) {
                unset($exception);
            }
        }

        return $url;
    }

    private static function is_under_upload_base(string $url, $baseUrl): bool
    {
        if (!is_string($baseUrl) || trim($baseUrl) === '') {
            return false;
        }

        $urlParts = parse_url($url);
        $baseParts = parse_url(trim($baseUrl));
        if (!is_array($urlParts) || !is_array($baseParts)) {
            return false;
        }

        $urlHost = strtolower((string) ($urlParts['host'] ?? ''));
        $baseHost = strtolower((string) ($baseParts['host'] ?? ''));
        if ($urlHost === '' || $baseHost === '' || $urlHost !== $baseHost) {
            return false;
        }

        $urlPath = rtrim((string) ($urlParts['path'] ?? ''), '/');
        $basePath = rtrim((string) ($baseParts['path'] ?? ''), '/');
        return $basePath !== '' && ($urlPath === $basePath || strpos($urlPath, $basePath . '/') === 0);
    }

    private static function is_ai_generated_image_option(array $options): bool
    {
        return ($options['image_option'] ?? null) === 'dall-e'
            || ($options['multiple_image_option'] ?? null) === 'dall-e-multi';
    }

    private static function get_wpauto_options($base = null): array
    {
        if ($base === null) {
            $base = self::get_runtime_base();
        }

        if (!is_object($base) || !isset($base->wpauto_options) || !is_array($base->wpauto_options)) {
            return [];
        }

        return $base->wpauto_options;
    }

    private static function get_runtime_single()
    {
        if (!function_exists('wpauto_campaign_single_call')) {
            return null;
        }

        try {
            return wpauto_campaign_single_call();
        } catch (Throwable $exception) {
            unset($exception);
            return null;
        }
    }

    private static function get_runtime_base()
    {
        if (!function_exists('wpauto_campaign_base_call')) {
            return null;
        }

        try {
            return wpauto_campaign_base_call();
        } catch (Throwable $exception) {
            unset($exception);
            return null;
        }
    }

    private static function positive_id($value): int
    {
        if (!(is_int($value) || is_float($value) || (is_string($value) && is_numeric($value)))) {
            return 0;
        }

        $value = (int) $value;
        return $value > 0 ? $value : 0;
    }
}
