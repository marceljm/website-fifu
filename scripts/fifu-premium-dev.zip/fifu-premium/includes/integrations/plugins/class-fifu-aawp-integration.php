<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Handles AAWP-related data retrieval.
 */
final class Fifu_Aawp_Integration
{
    /**
     * Returns an image URL for a random bestseller ASIN found in the post content.
     *
     * @param int $post_id
     *
     * @return string|null
     */
    public static function get_random_bestseller_image_url(int $post_id): ?string
    {
        $post_content = get_post_field('post_content', $post_id);
        if (strpos($post_content, '[amazon bestseller="') !== false) {
            $matches = array();
            preg_match('/\[amazon bestseller=[^\]]+\]/', $post_content, $matches);
            $shortcode = $matches[0] ?? '';
            if ($shortcode) {
                $text = explode('"', $shortcode)[1] ?? '';
                $aawp = new Fifu_Aawp_Repository();
                $asins = $aawp->get_asins('bestseller', $text);
                if ($asins) {
                    $asins = explode(',', $asins);
                    $asin = $asins[array_rand($asins)];
                    $image_ids = $aawp->get_image_ids($asin);
                    if ($image_ids) {
                        $image_id = explode(',', $image_ids)[0];
                        return "https://m.media-amazon.com/images/I/{$image_id}.jpg";
                    }
                }
            }
        }
        return null;
    }

    /**
     * Register hooks related to AAWP integration.
     */
    public static function register_hooks(): void
    {
        add_action(
            'aawp_post_insert_product',
            [self::class, 'handle_post_insert_product'],
            10,
            2
        );
    }

    /**
     * Handle AAWP product insert to set a remote featured image when appropriate.
     *
     * @param int   $aawpId
     * @param array $data
     */
    public static function handle_post_insert_product($aawpId, $data): void
    {
        unset($aawpId, $data);

        global $post;
        $postId = isset($post->ID) ? (int) $post->ID : 0;

        if (!$postId) {
            return;
        }

        if (!class_exists('Fifu_Plugin_Detector') || !Fifu_Plugin_Detector::is_aawp_active()) {
            return;
        }

        if (Fifu_Post_Meta_Utils::has_local_featured_image($postId)) {
            return;
        }

        $url = self::get_random_bestseller_image_url($postId);
        if (!$url) {
            return;
        }

        FIFU_Post_Meta_Updater::instance()->update_or_delete($postId, 'fifu_image_url', $url);
        Fifu_Post_Attachment_Sync_Service::sync_featured_attachment($postId);
    }
}
