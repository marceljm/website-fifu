<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}


final class Fifu_Wp_All_Import_Integration
{
    public static function register_hooks(): void
    {
        add_action('pmxi_after_xml_import', [self::class, 'handle_after_xml_import'], 10, 1);
        add_action('pmxi_saved_post', [self::class, 'handle_saved_post'], 10, 3);
    }

    public static function handle_after_xml_import($import_id): void
    {
        unset($import_id);

        if (get_option('fifu_auto_category_waiting')) {
            update_option('fifu_auto_category', 'toggleon');
            Fifu_Auto_Category_Image_Service::run();
            update_option('fifu_auto_category_created', true, 'no');
            delete_option('fifu_auto_category_waiting');
        }
    }

    public static function handle_saved_post($post_id, $xml_node, $is_update): void
    {
        unset($is_update);

        $post_id = is_numeric($post_id) ? (int) $post_id : 0;

        if ($post_id <= 0) {
            return;
        }

        $__fifuWaiPostType = function_exists('get_post_type') ? (string) get_post_type($post_id) : '';
        if (!class_exists('WooCommerce')) {
                return;
            }

            if (!in_array($__fifuWaiPostType, ['product', 'product_variation'], true)) {
                return;
            }

            $record = json_decode(json_encode((array) $xml_node), true);
            if (!is_array($record)) {
                return;
            }

            self::sync_existing_db2_featured_image_thumbnail_if_missing($post_id);

            if ($__fifuWaiPostType === 'product') {
                self::sync_same_row_variation_db2_featured_image_thumbnail_if_missing($post_id, $record);
            }

            $variants = self::find_variants_from_xml($record);
            $shouldAttemptSameRowVariationImageFallback =
                !$variants
                && $__fifuWaiPostType === 'product'
                && self::should_attempt_same_row_variation_image_fallback($post_id, $record);

        if (!$variants && !$shouldAttemptSameRowVariationImageFallback) {
                return;
            }

            $product = wc_get_product($post_id);
            if (!$product || !$product->is_type('variable')) {
                return;
            }

            foreach ($variants as $variant) {
                $sku = $variant['sku'] ?? null;
                if (!$sku) {
                    continue;
                }

                $product_id = wc_get_product_id_by_sku($sku);
                if (!$product_id) {
                    continue;
                }

                $url_entries = self::normalize_variation_url_entries((string) ($variant['fifu_list_url'] ?? ''));
                if (!$url_entries) {
                    continue;
                }

                $fifu_list_url = implode('|', $url_entries);
                $fifu_list_alt = array_key_exists('fifu_list_alt', $variant)
                    ? self::normalize_variation_alt_list_value((string) $variant['fifu_list_alt'], count($url_entries))
                    : null;

                $ok = Fifu_Developer_Media_Service::set_image_list((int) $product_id, $fifu_list_url, $fifu_list_alt);
                if (!$ok) {
                    continue;
                }

                self::sync_db2_image_list_gallery_if_available((int) $product_id);
            }

        if ($shouldAttemptSameRowVariationImageFallback) {
                self::copy_parent_featured_image_to_same_row_variation($post_id, $record);
        }
    }

    private static function find_variants_from_xml(array $record): array
    {
        $variants = [];

        $walk = static function ($node, bool $isRoot = false) use (&$walk, &$variants): void {
            if (!is_array($node)) {
                return;
            }

            if (
                !$isRoot
                && array_key_exists('sku', $node)
                && array_key_exists('fifu_list_url', $node)
            ) {
                $variants[] = $node;
            }

            foreach ($node as $child) {
                if (is_array($child)) {
                    $walk($child, false);
                }
            }
        };

        $walk($record, true);

        return $variants;
    }

    private static function should_attempt_same_row_variation_image_fallback(int $parent_id, array $record): bool
    {
        $parent_image_url = self::get_direct_featured_image_url($parent_id);
        if ($parent_image_url === '') {
            return false;
        }

        foreach (self::resolve_same_row_variation_ids($parent_id, $record) as $variation_id) {
            if (!self::variation_has_own_image($variation_id, $parent_id)) {
                return true;
            }
        }

        return false;
    }

    private static function copy_parent_featured_image_to_same_row_variation(int $parent_id, array $record): void
    {
        $parent_image_url = self::get_direct_featured_image_url($parent_id);
        if ($parent_image_url === '') {
            return;
        }

        foreach (self::resolve_same_row_variation_ids($parent_id, $record) as $variation_id) {
            if (self::variation_has_own_image($variation_id, $parent_id)) {
                continue;
            }

            self::detach_copied_parent_thumbnail_from_variation($parent_id, $variation_id);

            Fifu_Developer_Media_Service::set_image((int) $variation_id, $parent_image_url, true);
        }
    }

    private static function sync_same_row_variation_db2_featured_image_thumbnail_if_missing(int $parent_id, array $record): void
    {
        if ($parent_id <= 0) {
            return;
        }

        foreach (self::resolve_same_row_variation_ids($parent_id, $record) as $variation_id) {
            self::sync_existing_db2_featured_image_thumbnail_if_missing((int) $variation_id);
        }
    }

    /**
     * @return array<int, int>
     */
    private static function resolve_same_row_variation_ids(int $parent_id, array $record): array
    {
        $first_variation_id = (int) get_post_meta($parent_id, '__first_variation_id', true);
        if (self::is_valid_same_row_variation_candidate($parent_id, $first_variation_id)) {
            return [$first_variation_id];
        }

        $sku_values = self::find_sku_values_from_record($record);
        if (count($sku_values) === 1 && function_exists('wc_get_product_id_by_sku')) {
            $sku_variation_id = (int) wc_get_product_id_by_sku($sku_values[0]);
            if (self::is_valid_same_row_variation_candidate($parent_id, $sku_variation_id)) {
                return [$sku_variation_id];
            }
        }

        if (function_exists('get_posts')) {
            $children = get_posts([
                'post_type' => 'product_variation',
                'post_parent' => $parent_id,
                'post_status' => 'any',
                'fields' => 'ids',
                'numberposts' => 2,
                'orderby' => 'ID',
                'order' => 'ASC',
            ]);

            if (is_array($children) && count($children) === 1) {
                $child_id = (int) $children[0];
                if (self::is_valid_same_row_variation_candidate($parent_id, $child_id)) {
                    return [$child_id];
                }
            }
        }

        return [];
    }

    private static function is_valid_same_row_variation_candidate(int $parent_id, int $variation_id): bool
    {
        if ($parent_id <= 0 || $variation_id <= 0 || $variation_id === $parent_id) {
            return false;
        }

        if (!function_exists('get_post')) {
            return false;
        }

        $post = get_post($variation_id);
        if (!$post) {
            return false;
        }

        return (string) $post->post_type === 'product_variation'
            && (int) $post->post_parent === $parent_id;
    }

    /**
     * @return array<int, string>
     */
    private static function find_sku_values_from_record(array $record): array
    {
        $skus = [];

        $walk = static function ($node) use (&$walk, &$skus): void {
            if (!is_array($node)) {
                return;
            }

            foreach ($node as $key => $value) {
                if (is_scalar($value) && strtolower((string) $key) === 'sku') {
                    $sku = trim((string) $value);
                    if ($sku !== '') {
                        $skus[$sku] = true;
                    }
                    continue;
                }

                if (is_array($value)) {
                    $walk($value);
                }
            }
        };

        $walk($record);

        return array_keys($skus);
    }

    private static function sync_existing_db2_featured_image_thumbnail_if_missing(int $post_id): void
    {
        if ($post_id <= 0) {
            return;
        }

        if (!self::can_sync_existing_db2_featured_image_thumbnail()) {
            return;
        }

        if (self::has_usable_thumbnail($post_id)) {
            return;
        }

        $image_url = self::get_direct_featured_image_url($post_id);
        if ($image_url === '') {
            return;
        }

        Fifu_Developer_Media_Service::set_image($post_id, $image_url, true);

        self::sync_db2_image_list_gallery_if_available($post_id);
    }

    private static function sync_db2_image_list_gallery_if_available(int $post_id): void
    {
        if ($post_id <= 0) {
            return;
        }

        if (!class_exists('Fifu_Post_Attachment_Sync_Service', false)) {
            $path = dirname(__DIR__, 2) . '/meta/class-fifu-post-attachment-sync-service.php';
            if (is_readable($path)) {
                require_once $path;
            }
        }

        if (
            class_exists('Fifu_Post_Attachment_Sync_Service', false)
            && method_exists('Fifu_Post_Attachment_Sync_Service', 'sync_product_gallery_attachments_from_db2_image_list')
        ) {
            Fifu_Post_Attachment_Sync_Service::sync_product_gallery_attachments_from_db2_image_list($post_id);
        }
    }

    private static function tmp_gallery_db2_mapping_count(int $post_id): int
    {
        if (!function_exists('fifu_db2_manager')) {
            return 0;
        }

        $manager = fifu_db2_manager();
        if (!$manager || !method_exists($manager, 'getPostMappings')) {
            return 0;
        }

        $mappings = $manager->getPostMappings($post_id, 'image');
        return is_array($mappings) ? count($mappings) : 0;
    }

    private static function can_sync_existing_db2_featured_image_thumbnail(): bool
    {
        return function_exists('get_post_thumbnail_id')
            && function_exists('get_post')
            && function_exists('get_post_meta')
            && class_exists('Fifu_Developer_Media_Service');
    }

    private static function has_usable_thumbnail(int $post_id): bool
    {
        if (!function_exists('get_post_thumbnail_id')) {
            return false;
        }

        $thumbnail_id = (int) get_post_thumbnail_id($post_id);
        if ($thumbnail_id <= 0) {
            return false;
        }

        if (!function_exists('get_post')) {
            return true;
        }

        $attachment = get_post($thumbnail_id);
        if (!$attachment || (string) $attachment->post_type !== 'attachment') {
            return false;
        }

        return true;
    }

    private static function variation_has_own_image(int $variation_id, int $parent_id = 0): bool
    {
        if (
            self::has_usable_thumbnail($variation_id)
            && !self::variation_thumbnail_is_copied_parent_fifu_thumbnail($variation_id, $parent_id)
        ) {
            return true;
        }

        foreach (['fifu_image_url', 'fifu_image_url_0', 'fifu_list_url'] as $meta_key) {
            if (trim((string) get_post_meta($variation_id, $meta_key, true)) !== '') {
                return true;
            }
        }

        return self::get_direct_featured_image_url($variation_id) !== '';
    }

    private static function variation_thumbnail_is_copied_parent_fifu_thumbnail(int $variation_id, int $parent_id): bool
    {
        if ($variation_id <= 0 || $parent_id <= 0) {
            return false;
        }

        $variation_thumbnail_id = (int) get_post_thumbnail_id($variation_id);
        $parent_thumbnail_id = (int) get_post_thumbnail_id($parent_id);

        if ($variation_thumbnail_id <= 0 || $parent_thumbnail_id <= 0) {
            return false;
        }

        if ($variation_thumbnail_id !== $parent_thumbnail_id) {
            return false;
        }

        $attachment = get_post($variation_thumbnail_id);
        if (!$attachment || (string) $attachment->post_type !== 'attachment') {
            return false;
        }

        if ((int) $attachment->post_parent !== $parent_id) {
            return false;
        }

        return self::is_fifu_managed_attachment_id($variation_thumbnail_id);
    }

    private static function detach_copied_parent_thumbnail_from_variation(int $parent_id, int $variation_id): void
    {
        if (!self::variation_thumbnail_is_copied_parent_fifu_thumbnail($variation_id, $parent_id)) {
            return;
        }

        delete_post_meta($variation_id, '_thumbnail_id');
        clean_post_cache($variation_id);
        wp_cache_delete($variation_id, 'post_meta');
    }

    private static function is_fifu_managed_attachment_id(int $attachment_id): bool
    {
        if ($attachment_id <= 0) {
            return false;
        }

        if (
            class_exists('Fifu_Attachment_Update_Service', false)
            && method_exists('Fifu_Attachment_Update_Service', 'is_fifu_owned')
        ) {
            return (bool) Fifu_Attachment_Update_Service::is_fifu_owned($attachment_id);
        }

        $attachment = get_post($attachment_id);
        if (!$attachment || (string) $attachment->post_type !== 'attachment') {
            return false;
        }

        if (class_exists('Fifu_Options_Utils', false) && method_exists('Fifu_Options_Utils', 'get_author')) {
            return (int) $attachment->post_author === (int) Fifu_Options_Utils::get_author();
        }

        return false;
    }

    private static function get_direct_featured_image_url(int $post_id): string
    {
        if ($post_id <= 0) {
            return '';
        }

        $manager = function_exists('fifu_db2_manager') ? fifu_db2_manager() : null;
        if ($manager instanceof Fifu_Db2_Manager && method_exists($manager, 'getPostMapping')) {
            $mapping = $manager->getPostMapping($post_id, 'image', 0);
            if (is_array($mapping)) {
                $url = trim((string) ($mapping['url'] ?? ''));
                if ($url !== '') {
                    return $url;
                }
            }
        }

        if (function_exists('get_post_meta')) {
            foreach (['fifu_image_url', 'fifu_image_url_0'] as $meta_key) {
                $url = trim((string) get_post_meta($post_id, $meta_key, true));
                if ($url !== '') {
                    return $url;
                }
            }
        }

        return '';
    }

    private static function split_variation_list_value(string $value): array
    {
        $value = trim($value);
        if ($value === '') {
            return [];
        }

        $entries = preg_split('/\r\n|\r|\n|\|/', $value);
        if (!is_array($entries)) {
            return [];
        }

        return array_map('trim', $entries);
    }

    private static function normalize_variation_url_entries(string $value): array
    {
        return array_values(array_filter(
            self::split_variation_list_value($value),
            static fn(string $entry): bool => $entry !== ''
        ));
    }

    private static function normalize_variation_alt_list_value(string $value, int $url_count): ?string
    {
        if ($url_count <= 0) {
            return null;
        }

        $entries = self::split_variation_list_value($value);
        if (!$entries) {
            return null;
        }

        $slot_count = min($url_count, count($entries));
        if ($slot_count <= 0) {
            return null;
        }

        $normalized = [];
        $has_non_empty_alt = false;

        for ($index = 0; $index < $slot_count; $index++) {
            $alt = trim((string) ($entries[$index] ?? ''));
            $normalized[$index] = $alt;

            if ($alt !== '') {
                $has_non_empty_alt = true;
            }
        }

        return $has_non_empty_alt ? implode('|', $normalized) : null;
    }
}
