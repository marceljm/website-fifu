<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

final class Fifu_Polylang_Integration
{
    private static function get_author_id(): int
    {
        if ( function_exists( 'fifu_get_author' ) ) {
            $author = (int) fifu_get_author();
            if ( $author > 0 ) {
                return $author;
            }
        }

        if ( class_exists( 'Fifu_Options_Utils', false ) && method_exists( 'Fifu_Options_Utils', 'get_author' ) ) {
            $author = (int) Fifu_Options_Utils::get_author();
            if ( $author > 0 ) {
                return $author;
            }
        }

        if ( defined( 'FIFU_AUTHOR' ) ) {
            $author = (int) FIFU_AUTHOR;
            if ( $author > 0 ) {
                return $author;
            }
        }

        return 7777777777;
    }

    public static function register_hooks(): void
    {
        add_filter(
            'pll_copy_post_metas',
            [self::class, 'on_copy_post_metas'],
            10,
            5
        );
    }

    /**
     * Filter callback for pll_copy_post_metas.
     * It will eventually replace fifu_pll_copy_post_metas().
     *
     * @param mixed $metas
     * @param mixed $sync
     * @param mixed $from
     * @param mixed $to
     * @param mixed $lang
     * @return mixed
     */
    public static function on_copy_post_metas(
        $metas,
        $sync,
        $from,
        $to,
        $lang
    ) {
        if (!is_array($metas)) {
            return $metas;
        }

        if (is_bool($sync)) {
            // Already normalized.
        } elseif (in_array($sync, [1, '1'], true)) {
            $sync = true;
        } elseif (in_array($sync, [0, '0'], true)) {
            $sync = false;
        } else {
            return $metas;
        }

        if ($sync) {
            $to = is_numeric($to) ? (int) $to : 0;

            if ($to <= 0) {
                return $metas;
            }

            if (self::meta_list_contains($metas, '_thumbnail_id')) {
                $thumbnailId = (int) get_post_thumbnail_id($to);
                if (self::is_fifu_managed_attachment($thumbnailId)) {
                    unset($metas['_thumbnail_id'], $metas['_product_image_gallery']);
                }
            }

            if (self::meta_list_contains($metas, '_product_image_gallery')) {
                $galleryIds = self::get_meta_gallery_ids($metas);
                foreach ($galleryIds as $galleryId) {
                    if (self::is_fifu_managed_attachment($galleryId)) {
                        unset($metas['_product_image_gallery']);
                        break;
                    }
                }
            }

            return $metas;
        }

        if (self::meta_list_contains($metas, 'fifu_list_url')) {
            $from = is_numeric($from) ? (int) $from : 0;
            $to = is_numeric($to) ? (int) $to : 0;

            if ($from <= 0 || $to <= 0) {
                return $metas;
            }

            $metas = self::remove_meta_entries($metas, ['_thumbnail_id', '_product_image_gallery']);
            $listValue = self::get_source_image_list($from);
            Fifu_Developer_Media_Service::set_image_list($to, $listValue);
        }

        return $metas;
    }

    /**
     * @return int[]
     */
    private static function get_meta_gallery_ids(array $metas): array
    {
        $value = $metas['_product_image_gallery'] ?? null;
        if (is_array($value)) {
            $value = reset($value);
        }

        $csv = is_scalar($value) ? (string) $value : '';
        if ($csv === '') {
            return [];
        }

        $ids = [];
        foreach (explode(',', $csv) as $part) {
            $id = (int) trim($part);
            if ($id > 0) {
                $ids[] = $id;
            }
        }

        return $ids;
    }

    private static function is_fifu_managed_attachment(int $attachment_id): bool
    {
        if ($attachment_id <= 0) {
            return false;
        }

        if (class_exists('Fifu_Attachment_Update_Service', false) && method_exists('Fifu_Attachment_Update_Service', 'is_fifu_owned')) {
            return Fifu_Attachment_Update_Service::is_fifu_owned($attachment_id);
        }

        if (function_exists('fifu_is_fifu_attachment')) {
            return fifu_is_fifu_attachment($attachment_id);
        }

        $author = (int) get_post_field('post_author', $attachment_id);
        if ($author <= 0) {
            return false;
        }

        $authors = [self::get_author_id()];
        if (defined('FIFU_AUTHOR')) {
            $constAuthor = (int) FIFU_AUTHOR;
            if ($constAuthor > 0) {
                $authors[] = $constAuthor;
            }
        }
        $authors[] = 7777777777;
        $authors[] = 77777;

        $authors = array_values(array_unique(array_filter(array_map('intval', $authors), static fn(int $candidate): bool => $candidate > 0)));

        return in_array($author, $authors, true);
    }

    private static function meta_list_contains(array $metas, string $key): bool
    {
        foreach ($metas as $metaKey => $value) {
            if ((string) $metaKey === $key) {
                return true;
            }

            if ($value === $key) {
                return true;
            }

            if (is_array($value) && in_array($key, $value, true)) {
                return true;
            }
        }

        return false;
    }

    private static function remove_meta_entries(array $metas, array $keysOrSubstrings): array
    {
        $filtered = [];

        foreach ($metas as $metaKey => $value) {
            $remove = false;
            foreach ($keysOrSubstrings as $needle) {
                $needle = (string) $needle;
                if ($needle === '') {
                    continue;
                }

                if ((string) $metaKey === $needle || (is_string($value) && $value === $needle) || (is_array($value) && in_array($needle, $value, true))) {
                    $remove = true;
                    break;
                }
            }

            if (!$remove) {
                $filtered[$metaKey] = $value;
            }
        }

        return $filtered;
    }

    private static function get_source_image_list(int $from): string
    {
        $list = Fifu_Post_Image_List_Url_Read_Service::get_image_list_url($from);
        if (!is_string($list)) {
            return '';
        }

        $list = trim($list);
        $list = preg_replace('/\s*\|\s*/', '|', $list) ?? $list;
        $list = trim($list, "|\t\n\r\0\x0B ");

        return $list;
    }
}
