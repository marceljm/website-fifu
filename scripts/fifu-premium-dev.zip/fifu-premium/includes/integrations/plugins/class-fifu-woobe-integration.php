<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

final class Fifu_Woobe_Integration
{
    public static function register_hooks(): void
    {
        add_filter(
            'woobe_before_update_product_field',
            [self::class, 'on_before_update_product_field'],
            10,
            3
        );
    }

    /**
     * Filter callback for woobe_before_update_product_field.
     * It will eventually replace fifu_woobe_bulk_finished().
     *
     * @param mixed $value
     * @param int $productId
     * @param string $fieldKey
     * @return mixed
     */
    public static function on_before_update_product_field($value, $productId, $fieldKey)
    {
        if (!is_string($fieldKey) || !in_array($fieldKey, ['fifu_image_url', 'fifu_video_url', 'fifu_list_url'], true)) {
            return $value;
        }

        $productId = is_numeric($productId) ? (int) $productId : 0;
        if ($productId <= 0) {
            return $value;
        }

        if ($value !== null && !is_scalar($value)) {
            return $value;
        }

        $normalizedValue = (string) ($value ?? '');

        if ($fieldKey === 'fifu_image_url') {
            Fifu_Developer_Media_Service::set_image($productId, $normalizedValue);
        } elseif ($fieldKey === 'fifu_video_url') {
            Fifu_Developer_Media_Service::set_video($productId, $normalizedValue);
        } elseif ($fieldKey === 'fifu_list_url') {
            Fifu_Developer_Media_Service::set_image_list($productId, $normalizedValue);
        }

        return $value;
    }
}
