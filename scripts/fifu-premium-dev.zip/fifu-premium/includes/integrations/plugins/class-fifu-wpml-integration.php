<?php
declare(strict_types=1);

defined('ABSPATH') || exit;

final class Fifu_WPML_Integration
{
    /** @var array<int,string> */
    private static array $deferred_image_sync = [];
    private static bool $shutdown_hook_registered = false;
    /** @var array<int,string> */
    private static array $featured_image_sync_failures = [];

    public static function register_hooks(): void
    {
        add_action('wcml_after_duplicate_product_post_meta', [self::class, 'after_duplicate_product_post_meta'], 10, 3);
        add_action('wcml_after_sync_product_data', [self::class, 'after_sync_product_data'], 10, 3);
        add_action('wcml_synchronize_product_variation_translations', [self::class, 'synchronize_product_variation_translations'], 10, 3);
        add_action('icl_make_duplicate', [self::class, 'on_make_duplicate'], 10, 4);
        add_action('wpml_after_copy_custom_field', [self::class, 'after_copy_custom_field'], PHP_INT_MAX, 3);
    }

    public static function after_copy_custom_field($from_id, $to_id, $meta_key): void
    {
        if (!is_string($meta_key) || 'fifu_image_url' !== $meta_key) {
            return;
        }

        $to_id = is_numeric($to_id) ? (int) $to_id : 0;

        if ($to_id <= 0) {
            return;
        }

        $postType = get_post_type($to_id);
        if ($postType && in_array($postType, ['product', 'product_variation'], true) && Fifu_Plugin_Detector::is_wcml_active()) {
            return;
        }

        $url = get_post_meta($to_id, 'fifu_image_url', true);
        if (is_array($url)) {
            $url = reset($url);
        }

        $url = is_string($url) ? trim($url) : '';
        if ($url === '') {
            return;
        }

        self::$deferred_image_sync[$to_id] = $url;

        if (!self::$shutdown_hook_registered) {
            add_action('shutdown', [self::class, 'flush_deferred_image_sync'], PHP_INT_MAX);
            self::$shutdown_hook_registered = true;
        }
    }

    public static function flush_deferred_image_sync(): void
    {
        if (empty(self::$deferred_image_sync)) {
            return;
        }

        foreach (self::$deferred_image_sync as $postId => $url) {
            Fifu_Developer_Media_Service::set_image((int) $postId, (string) $url);
        }

        self::$deferred_image_sync = [];
    }

    public static function after_duplicate_product_post_meta($originalId, $translatedId, $data): void
    {
        $originalId = is_numeric($originalId) ? (int) $originalId : 0;
        $translatedId = is_numeric($translatedId) ? (int) $translatedId : 0;

        if ($originalId <= 0 || $translatedId <= 0) {
            return;
        }

        self::copy_prefixed_post_meta($originalId, $translatedId);
        self::sync_variation_fifu_meta($originalId, $translatedId, null);
    }

    public static function after_sync_product_data($originalId, $translatedId, $language): void
    {
        $originalId = is_numeric($originalId) ? (int) $originalId : 0;
        $translatedId = is_numeric($translatedId) ? (int) $translatedId : 0;

        if ($originalId <= 0 || $translatedId <= 0) {
            return;
        }

        self::copy_prefixed_post_meta($originalId, $translatedId);
        self::sync_variation_fifu_meta($originalId, $translatedId, self::normalize_language_code($language));
    }

    public static function synchronize_product_variation_translations($originalVariation, $variationTranslations, $translationLanguages): void
    {
        if (!is_array($variationTranslations) || empty($variationTranslations)) {
            return;
        }

        $sourceValue = is_object($originalVariation) ? ($originalVariation->ID ?? null) : $originalVariation;
        $sourceId = is_numeric($sourceValue) ? (int) $sourceValue : 0;

        if ($sourceId <= 0) {
            return;
        }

        foreach ($variationTranslations as $translationId) {
            $translationId = is_numeric($translationId) ? (int) $translationId : 0;
            if ($translationId <= 0 || $translationId === $sourceId) {
                continue;
            }

            self::copy_prefixed_post_meta($sourceId, $translationId);
        }
    }

    public static function on_make_duplicate($sourceId, $lang, $postArray, $duplicateId): void
    {
        $sourceId = is_numeric($sourceId) ? (int) $sourceId : 0;
        $duplicateId = is_numeric($duplicateId) ? (int) $duplicateId : 0;

        if ($sourceId <= 0 || $duplicateId <= 0) {
            return;
        }

        $postType = get_post_type($sourceId);
        if (!$postType) {
            return;
        }

        if (in_array($postType, ['product', 'product_variation'], true) && Fifu_Plugin_Detector::is_wcml_active()) {
            return;
        }

        self::copy_prefixed_post_meta($sourceId, $duplicateId);
    }

    private static function copy_prefixed_post_meta(int $sourceId, int $targetId): void
    {
        if (!$sourceId || !$targetId || $sourceId === $targetId) {
            return;
        }

        $sourceMeta = get_post_meta($sourceId);
        $postType = get_post_type($sourceId);

        $listValue = self::get_effective_image_list_value($sourceId, $sourceMeta, $postType);
        $featuredValue = self::get_effective_featured_image_value($sourceId, $sourceMeta);

        if ($listValue !== null && $listValue !== '') {
            self::copy_effective_fifu_image_list_state($targetId, $listValue);
            return;
        }

        if ($featuredValue !== null && $featuredValue !== '') {
            self::copy_effective_fifu_image_state($targetId, $featuredValue);
        }
    }

    private static function copy_effective_fifu_image_list_state(int $targetId, string $listValue): void
    {
        delete_post_meta($targetId, '_product_image_gallery');
        delete_post_meta($targetId, '_thumbnail_id');
        clean_post_cache($targetId);

        $synced = Fifu_Developer_Media_Service::set_image_list($targetId, $listValue);
        if ($synced && self::db2_image_list_matches($targetId, $listValue)) {
            return;
        }

        self::persist_db2_image_list_fallback($targetId, $listValue);
    }

    private static function copy_effective_fifu_image_state(int $targetId, string $featuredValue): void
    {
        unset(self::$featured_image_sync_failures[$targetId]);
        $synced = Fifu_Developer_Media_Service::set_image($targetId, $featuredValue);
        if ($synced && self::db2_featured_image_matches($targetId, $featuredValue, null)) {
            return;
        }

        if (!self::persist_db2_featured_image_fallback($targetId, $featuredValue)) {
            if (!isset(self::$featured_image_sync_failures[$targetId])) {
                self::$featured_image_sync_failures[$targetId] = 'Featured image fallback persistence failed.';
            }
        }
    }

    private static function db2_featured_image_matches(int $postId, string $expectedUrl, ?string $expectedAlt): bool
    {
        $manager = function_exists('fifu_db2_manager') ? fifu_db2_manager() : null;
        if (!$manager instanceof Fifu_Db2_Manager) {
            return false;
        }

        $mapping = method_exists($manager, 'getPostMapping')
            ? $manager->getPostMapping($postId, 'image', 0)
            : null;
        if (!is_array($mapping) || trim((string) ($mapping['url'] ?? '')) !== $expectedUrl) {
            return false;
        }

        $altMapping = method_exists($manager, 'getPostAltMapping')
            ? $manager->getPostAltMapping($postId, 'image', 0)
            : null;
        if ($expectedAlt === null) {
            return true;
        }

        $actualAlt = is_array($altMapping) ? trim((string) ($altMapping['alt'] ?? $altMapping['value'] ?? '')) : '';

        return $actualAlt === trim($expectedAlt);
    }

    private static function db2_image_list_matches(int $postId, string $expectedList): bool
    {
        $expected = self::normalize_pipe_list_value($expectedList);
        $actual = Fifu_Post_Image_List_Url_Read_Service::get_image_list_url($postId);

        return is_string($actual) && self::normalize_pipe_list_value($actual) === $expected;
    }

    private static function persist_db2_image_list_fallback(int $postId, string $listValue): void
    {
        $manager = function_exists('fifu_db2_manager') ? fifu_db2_manager() : null;
        if (!$manager instanceof Fifu_Db2_Manager) {
            return;
        }

        $urls = array_values(array_filter(array_map('trim', preg_split('/\s*\|\s*/', $listValue) ?: []), static fn(string $url): bool => $url !== ''));
        if (empty($urls)) {
            return;
        }

        if (method_exists($manager, 'deletePostMappings')) {
            foreach ($urls as $index => $_) {
                $manager->deletePostMappings($postId, 'image', (int) $index);
            }
        }

        foreach ($urls as $index => $url) {
            $manager->savePostUrl($postId, 'image', $index, $url);
        }

        clean_post_cache($postId);
    }

    private static function persist_db2_featured_image_fallback(int $postId, string $featuredValue): bool
    {
        unset(self::$featured_image_sync_failures[$postId]);
        $manager = function_exists('fifu_db2_manager') ? fifu_db2_manager() : null;
        if (!$manager instanceof Fifu_Db2_Manager || !method_exists($manager, 'savePostUrl')) {
            self::$featured_image_sync_failures[$postId] = 'DB2 featured image persistence is unavailable.';
            return false;
        }

        $previousMapping = method_exists($manager, 'getPostMapping')
            ? $manager->getPostMapping($postId, 'image', 0)
            : null;
        $previousUrl = is_array($previousMapping) ? trim((string) ($previousMapping['url'] ?? '')) : '';
        $previousAltMapping = method_exists($manager, 'getPostAltMapping')
            ? $manager->getPostAltMapping($postId, 'image', 0)
            : null;
        $previousAlt = is_array($previousAltMapping)
            ? trim((string) ($previousAltMapping['alt'] ?? $previousAltMapping['value'] ?? ''))
            : '';

        if (!$manager->savePostUrl($postId, 'image', 0, $featuredValue)) {
            self::$featured_image_sync_failures[$postId] = 'Replacement featured image write failed.';
            return false;
        }

        if (!self::db2_featured_image_matches($postId, $featuredValue, null)) {
            self::$featured_image_sync_failures[$postId] = 'Replacement featured image confirmation failed.';
            if ($previousUrl !== '' && (!$manager->savePostUrl($postId, 'image', 0, $previousUrl)
                || !self::db2_featured_image_matches($postId, $previousUrl, null))) {
                self::$featured_image_sync_failures[$postId] = 'Replacement confirmation failed and restoration of the previous featured image URL also failed.';
            }
            return false;
        }

        if ($previousUrl !== '' && $previousUrl !== $featuredValue && method_exists($manager, 'deletePostAltMappings')) {
            $manager->deletePostAltMappings($postId, 'image', 0);
            $altMapping = method_exists($manager, 'getPostAltMapping')
                ? $manager->getPostAltMapping($postId, 'image', 0)
                : null;
            $wpdb = method_exists($manager, 'getWpdb') ? $manager->getWpdb() : null;
            $altReadFailed = $wpdb instanceof wpdb && $wpdb->last_error !== '';
            if ($altReadFailed) {
                self::$featured_image_sync_failures[$postId] = 'Obsolete featured image ALT removal could not be verified.';
                $restored = $previousUrl === '' || (
                    $manager->savePostUrl($postId, 'image', 0, $previousUrl)
                    && self::db2_featured_image_matches($postId, $previousUrl, null)
                );
                if ($restored && $previousAlt !== '') {
                    $restored = method_exists($manager, 'savePostAlt')
                        && $manager->savePostAlt($postId, 'image', 0, $previousAlt);
                    $restoredAltMapping = method_exists($manager, 'getPostAltMapping')
                        ? $manager->getPostAltMapping($postId, 'image', 0)
                        : null;
                    $restoredAlt = is_array($restoredAltMapping)
                        ? trim((string) ($restoredAltMapping['alt'] ?? $restoredAltMapping['value'] ?? ''))
                        : '';
                    $restored = $restored && $restoredAlt === $previousAlt;
                }
                if (!$restored) {
                    self::$featured_image_sync_failures[$postId] = 'ALT removal verification failed and restoration of the previous featured image state also failed.';
                }
                return false;
            }
            if (is_array($altMapping) && trim((string) ($altMapping['alt'] ?? $altMapping['value'] ?? '')) !== '') {
                self::$featured_image_sync_failures[$postId] = 'Obsolete featured image ALT removal failed.';
                if ($previousUrl !== '' && (!$manager->savePostUrl($postId, 'image', 0, $previousUrl)
                    || !self::db2_featured_image_matches($postId, $previousUrl, null))) {
                    self::$featured_image_sync_failures[$postId] = 'Obsolete ALT removal failed and restoration of the previous featured image URL also failed.';
                }
                return false;
            }
        }

        foreach (['video', 'custom_video', 'slider'] as $keyType) {
            if (method_exists($manager, 'deletePostMappings')) {
                $manager->deletePostMappings($postId, $keyType, 0);
            }
        }

        clean_post_cache($postId);
        return true;
    }

    private static function get_effective_image_list_value(int $sourceId, array $sourceMeta, ?string $postType): ?string
    {
        $legacyList = self::first_scalar_meta_value($sourceMeta['fifu_list_url'] ?? null);
        $legacyList = self::normalize_pipe_list_value($legacyList);
        if ($legacyList !== '') {
            return $legacyList;
        }

        $readList = Fifu_Post_Image_List_Url_Read_Service::get_image_list_url($sourceId);
        $readList = self::normalize_pipe_list_value(is_string($readList) ? $readList : '');
        if ($readList !== '') {
            return $readList;
        }

        if (!in_array($postType, ['product', 'product_variation'], true)) {
            return null;
        }

        $entries = [];
        $hasIndexedImageUrl = false;
        foreach ($sourceMeta as $metaKey => $values) {
            if (!preg_match('/^fifu_image_url(?:_(\\d+))?$/', (string) $metaKey, $matches)) {
                continue;
            }

            $firstValue = self::first_scalar_meta_value($values);
            if ($firstValue === '') {
                continue;
            }

            $isIndexed = isset($matches[1]);
            if ($isIndexed) {
                $hasIndexedImageUrl = true;
            }

            $index = $isIndexed ? (int) $matches[1] : 0;
            $entries[] = ['index' => $index, 'value' => $firstValue];
        }

        if (empty($entries)) {
            return null;
        }

        if (!$hasIndexedImageUrl && count($entries) === 1) {
            return $entries[0]['value'];
        }

        usort($entries, static function (array $a, array $b): int {
            if ($a['index'] === $b['index']) {
                return 0;
            }

            return $a['index'] <=> $b['index'];
        });

        $ordered = [];
        $seen = [];
        foreach ($entries as $entry) {
            if (isset($seen[$entry['value']])) {
                continue;
            }

            $seen[$entry['value']] = true;
            $ordered[] = $entry['value'];
        }

        return $ordered ? implode('|', $ordered) : null;
    }

    private static function get_effective_featured_image_value(int $sourceId, array $sourceMeta): ?string
    {
        $readUrl = Fifu_Post_Image_Url_Read_Service::get_image_url($sourceId);
        $readUrl = is_string($readUrl) ? trim($readUrl) : '';
        if ($readUrl !== '') {
            return $readUrl;
        }

        $value = self::first_scalar_meta_value($sourceMeta['fifu_image_url'] ?? null);

        return $value !== '' ? $value : null;
    }

    private static function first_scalar_meta_value($value): string
    {
        if (is_array($value)) {
            foreach ($value as $item) {
                if (is_array($item)) {
                    $nested = self::first_scalar_meta_value($item);
                    if ($nested !== '') {
                        return $nested;
                    }
                    continue;
                }

                if (is_scalar($item)) {
                    $item = trim((string) $item);
                    if ($item !== '') {
                        return $item;
                    }
                }
            }

            return '';
        }

        if (!is_scalar($value)) {
            return '';
        }

        return trim((string) $value);
    }

    private static function normalize_pipe_list_value(string $value): string
    {
        $value = trim($value);
        if ($value === '') {
            return '';
        }

        $parts = preg_split('/\s*\|\s*|\r\n|\r|\n/', $value) ?: [];
        $parts = array_values(array_filter(array_map('trim', $parts), static fn(string $part): bool => $part !== ''));
        $parts = array_values(array_unique($parts));

        return implode('|', $parts);
    }

    private static function sync_variation_fifu_meta(int $originalProductId, int $translatedProductId, ?string $lang): void
    {
        if (!$originalProductId || !$translatedProductId) {
            return;
        }

        $variationIds = get_posts([
            'post_type' => 'product_variation',
            'post_parent' => $originalProductId,
            'fields' => 'ids',
            'posts_per_page' => -1,
            'post_status' => 'any',
            'orderby' => 'ID',
            'order' => 'ASC',
            'suppress_filters' => true,
        ]);

        if (empty($variationIds)) {
            return;
        }

        $lang = self::normalize_language_code($lang);

        if (!$lang) {
            $details = apply_filters('wpml_post_language_details', null, $translatedProductId);
            $lang = self::normalize_language_code($details);
        }

        if (!$lang) {
            return;
        }

        foreach ($variationIds as $variationId) {
            $variationId = (int) $variationId;
            if ($variationId <= 0) {
                continue;
            }

            $translatedVariationId = apply_filters('wpml_object_id', $variationId, 'product_variation', false, $lang);
            $translatedVariationId = (int) $translatedVariationId;

            if (!self::is_valid_translated_variation($translatedVariationId, $variationId, $translatedProductId)) {
                continue;
            }

            self::copy_prefixed_post_meta($variationId, $translatedVariationId);
        }
    }

    private static function is_valid_translated_variation(int $translatedVariationId, int $variationId, int $translatedProductId): bool
    {
        if ($translatedVariationId <= 0 || $translatedVariationId === $variationId) {
            return false;
        }

        if ($translatedProductId > 0 && function_exists('wp_get_post_parent_id')) {
            $parentId = (int) wp_get_post_parent_id($translatedVariationId);

            if ($parentId > 0 && $parentId !== $translatedProductId) {
                return false;
            }
        }

        return true;
    }

    /**
     * @param mixed $language
     */
    private static function normalize_language_code($language): ?string
    {
        if (is_string($language) || is_numeric($language)) {
            $language = trim((string) $language);

            return $language !== '' ? $language : null;
        }

        if (is_array($language)) {
            foreach (['language_code', 'code', 'lang'] as $key) {
                if (isset($language[$key]) && is_scalar($language[$key])) {
                    $value = trim((string) $language[$key]);
                    if ($value !== '') {
                        return $value;
                    }
                }
            }

            return null;
        }

        if (is_object($language)) {
            foreach (['language_code', 'code', 'lang'] as $key) {
                if (isset($language->{$key}) && is_scalar($language->{$key})) {
                    $value = trim((string) $language->{$key});
                    if ($value !== '') {
                        return $value;
                    }
                }
            }
        }

        return null;
    }
}
