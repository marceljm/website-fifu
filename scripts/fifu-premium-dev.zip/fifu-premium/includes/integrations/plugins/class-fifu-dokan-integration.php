<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Provides Dokan-specific form fields and asset management.
 */
final class Fifu_Dokan_Integration
{
    /**
     * Registers Dokan hooks that previously lived in admin/meta-box.php.
     */
    public static function register_hooks(): void
    {
        add_action(
            'dokan_new_product_after_product_tags',
            [self::class, 'render_new_product_image_field'],
            10
        );
        add_action(
            'dokan_product_edit_after_product_tags',
            [self::class, 'render_edit_product_image_field'],
            99,
            2
        );
        add_action(
            'dokan_new_product_added',
            [self::class, 'on_product_save'],
            10,
            2
        );
        add_action(
            'dokan_product_updated',
            [self::class, 'on_product_save'],
            10,
            2
        );
    }

    /**
     * Enqueues assets shared with both Dokan hooks.
     */
    private static function enqueue_assets(): void
    {
        wp_enqueue_script('jquery-block-ui', 'https://cdnjs.cloudflare.com/ajax/libs/jquery.blockUI/2.70/jquery.blockUI.min.js');
        wp_enqueue_style('fancy-box-css', 'https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.css');
        wp_enqueue_script('fancy-box-js', 'https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js');

        wp_register_style('jquery-sortablejs-css', plugins_url('/html/css/sortable.css', FIFU_PLUGIN_FILE), array(), Fifu_Plugin_Info::get_enqueue_version());
        wp_enqueue_style('jquery-sortablejs-css');

        wp_enqueue_script('fifu-convert-url-js', plugins_url('/html/js/convert-url.js', FIFU_PLUGIN_FILE), array('jquery'), Fifu_Plugin_Info::get_enqueue_version());

        wp_localize_script('fifu-convert-url-js', 'fifuConvertUrlVars', [
            'restUrl' => esc_url_raw(rest_url()),
            'homeUrl' => esc_url_raw(home_url()),
            'nonce' => wp_create_nonce('wp_rest'),
            'partialKey' => Fifu_Options_Utils::partial_key(),
        ]);
    }

    /**
     * Outputs the image field for the new Dokan product screen.
     */
    public static function render_new_product_image_field(): void
    {
        $fifu = Fifu_Dokan_Strings::get_strings();
        ?>

        <div class="dokan-form-group">
            <label for="fifu_input_url" class="form-label"><span class="dashicons dashicons-camera" style="font-size:20px"></span> <?php $fifu['title']['product']['image'](); ?></label>
            <input type="text" class="dokan-form-control" name="fifu_input_url" placeholder="<?php $fifu['placeholder']['product']['image'](); ?>">
        </div>

        <?php
        self::enqueue_assets();

        Fifu_Admin_Meta_Box_Renderer::render_wc_elements(get_post());
    }

    /**
     * Outputs the image field for editing an existing Dokan product.
     *
     * @param mixed $post
     * @param int $post_id
     */
    public static function render_edit_product_image_field($post, $post_id): void
    {
        $post_id = is_numeric($post_id) ? (int) $post_id : 0;
        if ($post_id <= 0) {
            return;
        }
        $fifu = Fifu_Dokan_Strings::get_strings();
        $url = esc_url(Fifu_Post_Image_Url_Read_Service::get_image_url((int) $post_id) ?? '');
        ?>

        <div class="dokan-form-group">
            <label for="fifu_input_url" class="form-label"><span class="dashicons dashicons-camera" style="font-size:20px"></span> <?php $fifu['title']['product']['image'](); ?></label>
            <input type="text" class="dokan-form-control" name="fifu_input_url" value="<?php echo $url; ?>" placeholder="<?php $fifu['placeholder']['product']['image'](); ?>">
        </div>

        <?php
        self::enqueue_assets();

        Fifu_Admin_Meta_Box_Renderer::render_wc_elements($post);
    }

    /**
     * Handles Dokan product creation/update.
     * It will eventually replace fifu_dokan_save_meta().
     *
     * @param int $postId
     * @param array $data
     */
    public static function on_product_save($postId, $data): void
    {
        $postId = is_numeric($postId) ? (int) $postId : 0;
        if ($postId <= 0 || !is_array($data)) {
            return;
        }
        if (!function_exists('dokan_is_user_seller') || !dokan_is_user_seller(get_current_user_id())) {
            return;
        }

        $postMetaUpdater = FIFU_Post_Meta_Updater::instance();
        $rawUrl = $data['fifu_input_url'] ?? '';
        if ($rawUrl !== null && !is_scalar($rawUrl)) {
            return;
        }
        $url = esc_url_raw(rtrim((string) ($rawUrl ?? '')));
        $postMetaUpdater->update_or_delete($postId, 'fifu_image_url', $url);

        $lengthValue = $data['inputHiddenImageLength'] ?? 0;
        $length = is_numeric($lengthValue) ? max(0, (int) $lengthValue) : 0;
        for ($i = 0; $i < $length; $i++) {
            $postMetaUpdater->delete($postId, 'fifu_image_url_' . $i);
            $postMetaUpdater->delete($postId, 'fifu_image_alt_' . $i);
            $postMetaUpdater->delete($postId, 'fifu_image_ifm_' . $i);
        }

        $listValue = $data['inputHiddenImageListIds'] ?? '';
        $list = ($listValue === null || is_scalar($listValue)) ? (string) ($listValue ?? '') : '';
        if ($list !== '') {
            $indexes = explode('|', $list);
            $metaIndex = 0;
            foreach ($indexes as $index) {
                if ($index === '') {
                    continue;
                }

                $inputUrlKey = 'fifu_input_url_' . $index;
                $inputAltKey = 'fifu_input_alt_' . $index;
                $inputIfmKey = 'fifu_input_ifm_' . $index;

                if (!isset($data[$inputUrlKey]) || !isset($data[$inputAltKey])) {
                    continue;
                }

                $rawEntryUrl = $data[$inputUrlKey];
                $rawEntryAlt = $data[$inputAltKey];
                $rawEntryIfm = $data[$inputIfmKey] ?? '';
                if ($rawEntryUrl !== null && !is_scalar($rawEntryUrl)) {
                    continue;
                }
                $entryUrl = esc_url_raw(rtrim((string) ($rawEntryUrl ?? '')));
                $entryAlt = ($rawEntryAlt === null || is_scalar($rawEntryAlt))
                    ? wp_strip_all_tags((string) ($rawEntryAlt ?? ''))
                    : '';
                $entryIfm = ($rawEntryIfm === null || is_scalar($rawEntryIfm))
                    ? trim((string) ($rawEntryIfm ?? ''))
                    : '';
                $entryIfm = in_array(strtolower($entryIfm), ['null', 'undefined', 'http://null', 'https://null'], true)
                    ? ''
                    : esc_url_raw($entryIfm);

                $postMetaUpdater->update_or_delete($postId, 'fifu_image_url_' . $metaIndex, $entryUrl);
                $postMetaUpdater->update_or_delete_value($postId, 'fifu_image_alt_' . $metaIndex, $entryAlt);
                $postMetaUpdater->update_or_delete_value($postId, 'fifu_image_ifm_' . $metaIndex, $entryIfm);
                $metaIndex++;
            }
        }

        Fifu_Post_Attachment_Sync_Service::sync_featured_attachment($postId);
        Fifu_Post_Attachment_Sync_Service::sync_gallery_attachments($postId);
        Fifu_Post_Attachment_Sync_Service::sync_theme_property_images($postId);
    }
}
