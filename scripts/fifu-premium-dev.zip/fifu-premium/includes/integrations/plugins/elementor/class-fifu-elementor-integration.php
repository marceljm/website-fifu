<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

class Fifu_Elementor_Integration {

    public static function register_hooks(): void {
        if (!self::is_active()) {
            return;
        }

        add_action('init', [self::class, 'i18n']);
        add_action('elementor/widgets/register', [self::class, 'on_widgets_register']);
        add_action('elementor/controls/register', [self::class, 'on_controls_register']);
        add_action('elementor/frontend/after_enqueue_scripts', [self::class, 'enqueue_widget_scripts']);
        add_action(
            'elementor/editor/after_save',
            [self::class, 'image_after_save_elementor_data'],
            10,
            2
        );
    }

    private static function is_active(): bool {
        $detector_active = class_exists('Fifu_Plugin_Detector')
            && Fifu_Plugin_Detector::is_elementor_active();

        return $detector_active
            || did_action('elementor/loaded') > 0
            || class_exists('\Elementor\Plugin');
    }

    public static function i18n(): void {
        load_plugin_textdomain(FIFU_SLUG);
    }

    public static function on_widgets_register($widgets_manager): void {
        if (!$widgets_manager instanceof \Elementor\Widgets_Manager) {
            return;
        }
        require_once __DIR__ . '/widgets/class-elementor-fifu-image-widget.php';
        $widgets_manager->register(new \Elementor_FIFU_Widget());

        if (Fifu_Options_Utils::is_on('fifu_video')) {
            require_once __DIR__ . '/widgets/class-elementor-fifu-video-widget.php';
            $widgets_manager->register(new \Elementor_FIFU_Video_Widget());
        }
    }

    public static function on_controls_register($controls_manager): void {
        // Custom controls are not registered for this extension.
    }

    public static function enqueue_widget_scripts(): void {
        // Frontend assets are not enqueued via this integration.
    }

    public static function image_after_save_elementor_data($post_id, $editor_data): void {
        $post_id = is_numeric($post_id) ? (int) $post_id : 0;
        if ($post_id <= 0 || !is_array($editor_data)) {
            return;
        }

        $candidates = self::collect_fifu_elementor_media_candidates($editor_data);
        $action = self::resolve_final_elementor_media_action($candidates);
        if ($action === null) {
            $has_custom_video = false;
            $has_image = false;
            foreach ($candidates as $candidate) {
                if (!is_array($candidate)) {
                    continue;
                }
                if (($candidate['type'] ?? '') === 'video' && !empty($candidate['is_custom'])) {
                    $has_custom_video = true;
                } elseif (($candidate['type'] ?? '') === 'image') {
                    $has_image = true;
                }
            }

            if ($has_custom_video && !$has_image) {
                Fifu_Developer_Media_Service::set_custom_video($post_id, '');
            }
            return;
        }
        self::apply_final_elementor_media_action($post_id, $action);
    }

    private static function collect_fifu_elementor_media_candidates(array $elements, int $depth = 0): array {
        $candidates = [];
        foreach ($elements as $el) {
            if (!is_array($el)) {
                continue;
            }

            if (isset($el['elType'], $el['widgetType']) && $el['elType'] === 'widget') {
                $settings = $el['settings'] ?? [];

                if ($el['widgetType'] === 'fifu-elementor') {
                    if (!is_array($settings)) {
                        continue;
                    }
                    if (!array_key_exists('fifu_input_url', $settings)) {
                        continue;
                    }

                    $raw_url = $settings['fifu_input_url'];
                    if ($raw_url !== null && !is_scalar($raw_url)) {
                        continue;
                    }
                    $trimmed_url = trim((string) $raw_url);
                    if ($trimmed_url === '') {
                        $candidates[] = ['type' => 'image_clear'];
                        continue;
                    }

                    $image_url = self::normalize_elementor_image_url($raw_url);
                    if ($image_url === null) {
                        continue;
                    }

                    $raw_alt = $settings['fifu_input_alt'] ?? null;
                    $alt = ($raw_alt === null || is_scalar($raw_alt))
                        ? self::normalize_elementor_alt_value($raw_alt)
                        : null;
                    $candidates[] = [
                        'type' => 'image',
                        'url' => $image_url,
                        'alt' => $alt,
                        'depth' => $depth,
                    ];
                    continue;
                }

                if ($el['widgetType'] === 'fifu-video-elementor') {
                    if (!is_array($settings)) {
                        continue;
                    }
                    if (!Fifu_Options_Utils::is_on('fifu_video')) {
                        continue;
                    }
                    if (!array_key_exists('fifu_video_input_url', $settings)) {
                        continue;
                    }

                    $raw_url = $settings['fifu_video_input_url'];
                    if ($raw_url !== null && !is_scalar($raw_url)) {
                        continue;
                    }
                    $trimmed_url = trim((string) $raw_url);
                    if ($trimmed_url === '') {
                        $candidates[] = ['type' => 'video_clear'];
                        continue;
                    }

                    $video_part = self::extract_custom_video_part($trimmed_url);
                    if (filter_var($video_part, FILTER_VALIDATE_URL) === false) {
                        continue;
                    }

                    $is_custom = self::is_custom_video_input($trimmed_url);
                    $poster_url = $is_custom ? self::extract_custom_video_poster_url($trimmed_url) : null;

                    $candidates[] = [
                        'type' => 'video',
                        'url' => $trimmed_url,
                        'is_custom' => $is_custom,
                        'custom_poster_url' => $poster_url,
                        'depth' => $depth,
                    ];
                }
            }

            if (!empty($el['elements']) && is_array($el['elements'])) {
                $candidates = array_merge($candidates, self::collect_fifu_elementor_media_candidates($el['elements'], $depth + 1));
            }
        }

        return $candidates;
    }

    private static function resolve_final_elementor_media_action(array $candidates): ?array {
        if (empty($candidates)) {
            return null;
        }

        $last_image = null;
        $last_video = null;
        $last_custom_video = null;
        $last_effective = null;
        $nested_image_for_video = null;

        foreach ($candidates as $index => $candidate) {
            if (!is_array($candidate) || !isset($candidate['type'])) {
                continue;
            }

            $candidate['index'] = $index;
            if ($candidate['type'] === 'image') {
                $last_image = $candidate;
                $last_effective = $candidate;
                continue;
            }

            if ($candidate['type'] === 'video') {
                $last_video = $candidate;
                $last_effective = $candidate;
                if (!empty($candidate['is_custom'])) {
                    $last_custom_video = $candidate;
                } elseif ($last_image !== null && (($last_image['depth'] ?? 0) > 0 || ($candidate['depth'] ?? 0) > 0)) {
                    $nested_image_for_video = $last_image;
                }
                continue;
            }

            if ($candidate['type'] === 'image_clear' || $candidate['type'] === 'video_clear') {
                $last_effective = $candidate;
            }
        }

        if ($last_custom_video !== null) {
            if (!empty($last_custom_video['custom_poster_url'])) {
                return [
                    'action' => 'set_custom_video',
                    'video_url' => $last_custom_video['url'],
                ];
            }

            if ($last_image !== null) {
                return [
                    'action' => 'set_custom_video_with_poster',
                    'video_url' => $last_custom_video['url'],
                    'image_url' => $last_image['url'],
                    'alt' => $last_image['alt'] ?? null,
                ];
            }
            return null;
        }

        if ($last_effective === null) {
            return null;
        }

        if ($last_effective['type'] === 'image') {
            return [
                'action' => 'set_image',
                'url' => $last_effective['url'],
                'alt' => $last_effective['alt'] ?? null,
            ];
        }

        if ($last_effective['type'] === 'video') {
            if ($nested_image_for_video !== null) {
                return [
                    'action' => 'set_video_after_image',
                    'image_url' => $nested_image_for_video['url'],
                    'image_alt' => $nested_image_for_video['alt'] ?? null,
                    'video_url' => $last_effective['url'],
                ];
            }
            return [
                'action' => 'set_video',
                'url' => $last_effective['url'],
            ];
        }

        if ($last_effective['type'] === 'image_clear') {
            for ($i = $last_effective['index'] + 1; $i < count($candidates); $i++) {
                $candidate = $candidates[$i];
                if (is_array($candidate) && in_array($candidate['type'] ?? '', ['image', 'video'], true)) {
                    return null;
                }
            }

            return ['action' => 'clear_image'];
        }

        if ($last_effective['type'] === 'video_clear') {
            return ['action' => 'clear_video'];
        }

        return null;
    }

    private static function apply_final_elementor_media_action(int $post_id, ?array $action): void {
        if ($action === null || !isset($action['action'])) {
            return;
        }

        if ($action['action'] === 'set_image') {
            Fifu_Developer_Media_Service::set_image($post_id, $action['url']);
            if (
                array_key_exists('alt', $action)
                && $action['alt'] !== null
                && self::image_alt_needs_write($post_id, (string) $action['alt'])
            ) {
                self::write_image_alt($post_id, (string) $action['alt'], false);
            }
            if (function_exists('get_post_thumbnail_id')) {
                $att_id = get_post_thumbnail_id($post_id);
            } else {
                $att_id = 0;
            }
            if (
                $att_id
                && function_exists('getimagesize')
                && !self::attachment_has_valid_dimensions((int) $att_id)
            ) {
                $image_sizes = @getimagesize($action['url']);
                if ($image_sizes && isset($image_sizes[0], $image_sizes[1])) {
                    Fifu_Attachment_Dimensions_Service::update_dimensions($att_id, (int) $image_sizes[0], (int) $image_sizes[1]);
                }
            }
            return;
        }

        if ($action['action'] === 'clear_image') {
            Fifu_Developer_Media_Service::set_image($post_id, '');
            return;
        }

        if ($action['action'] === 'set_video') {
            Fifu_Developer_Media_Service::set_video($post_id, $action['url']);
            return;
        }

        if ($action['action'] === 'set_video_after_image') {
            Fifu_Developer_Media_Service::set_image($post_id, $action['image_url']);
            if (array_key_exists('image_alt', $action) && $action['image_alt'] !== null) {
                self::write_image_alt($post_id, (string) $action['image_alt'], false);
            }
            Fifu_Developer_Media_Service::set_video($post_id, $action['video_url']);
            return;
        }

        if ($action['action'] === 'clear_video') {
            Fifu_Developer_Media_Service::set_video($post_id, '');
            return;
        }

        if ($action['action'] === 'set_custom_video') {
            Fifu_Developer_Media_Service::set_custom_video($post_id, $action['video_url']);
            return;
        }

        if ($action['action'] === 'set_custom_video_with_poster') {
            Fifu_Developer_Media_Service::set_custom_video_with_poster(
                $post_id,
                $action['video_url'],
                $action['image_url'],
                array_key_exists('alt', $action) ? $action['alt'] : null
            );
        }
    }

    private static function normalize_elementor_image_url($image_url): ?string {
        $image_url = trim((string) $image_url);
        if ($image_url === '') {
            return null;
        }

        if (filter_var($image_url, FILTER_VALIDATE_URL) === false) {
            return null;
        }

        $validated_url = function_exists('wp_http_validate_url') ? wp_http_validate_url($image_url) : $image_url;
        if ($validated_url === false) {
            if (function_exists('wp_http_validate_url')) {
                wp_http_validate_url($image_url);
            }
            return null;
        }

        return (string) $validated_url;
    }

    private static function extract_custom_video_part(string $video_url): string {
        $parts = explode('\\', $video_url, 2);
        return trim((string) $parts[0]);
    }

    private static function extract_custom_video_poster_url(string $video_url): ?string {
        if (strpos($video_url, '\\') === false) {
            return null;
        }

        $parts = explode('\\', $video_url, 2);
        if (!array_key_exists(1, $parts)) {
            return null;
        }

        $poster_part = trim((string) $parts[1]);
        if ($poster_part === '') {
            return null;
        }

        return self::normalize_elementor_image_url($poster_part);
    }

    private static function is_custom_video_input(string $video_url): bool {
        if ($video_url === '') {
            return false;
        }

        if (strpos($video_url, '\\') !== false) {
            return true;
        }

        return class_exists('Fifu_Video_Helper', false) && \Fifu_Video_Helper::is_custom_video($video_url);
    }

    private static function image_alt_needs_write(int $post_id, string $alt_value): bool {
        $stripped_alt = function_exists('wp_strip_all_tags')
            ? (string) wp_strip_all_tags($alt_value)
            : strip_tags($alt_value);
        $expected_alt = self::normalize_elementor_alt_value($stripped_alt);
        if ($expected_alt === null) {
            return true;
        }

        if (!function_exists('fifu_db2_manager')) {
            return true;
        }

        try {
            $manager = fifu_db2_manager();
            if (
                !$manager instanceof Fifu_Db2_Manager
                || !method_exists($manager, 'getPostAltMapping')
            ) {
                return true;
            }

            $mapping = $manager->getPostAltMapping($post_id, 'image', 0);
            if (!is_array($mapping) || !array_key_exists('alt', $mapping)) {
                return true;
            }

            return self::normalize_elementor_alt_value((string) $mapping['alt']) !== $expected_alt;
        } catch (\Throwable $e) {
            return true;
        }
    }

    private static function attachment_has_valid_dimensions(int $attachment_id): bool {
        if ($attachment_id <= 0 || !function_exists('wp_get_attachment_metadata')) {
            return false;
        }

        $metadata = wp_get_attachment_metadata($attachment_id);
        return is_array($metadata)
            && (int) ($metadata['width'] ?? 0) > 0
            && (int) ($metadata['height'] ?? 0) > 0;
    }

    private static function write_image_alt(int $post_id, string $alt_value, bool $force_delete_first): void {
        $stripped_alt = function_exists('wp_strip_all_tags')
            ? (string) wp_strip_all_tags($alt_value)
            : strip_tags($alt_value);
        $value = self::normalize_elementor_alt_value($stripped_alt);

        if (class_exists('FIFU_Post_Meta_Updater')) {
            FIFU_Post_Meta_Updater::instance()->update_or_delete_with_status($post_id, 'fifu_image_alt', $value);
            return;
        }

        if (function_exists('fifu_update_or_delete')) {
            fifu_update_or_delete($post_id, 'fifu_image_alt', $value ?? '');
            return;
        }

        if ($force_delete_first && function_exists('delete_post_meta')) {
            delete_post_meta($post_id, 'fifu_image_alt');
        }
        if ($value !== null && function_exists('update_post_meta')) {
            update_post_meta($post_id, 'fifu_image_alt', $value);
        }
    }

    private static function normalize_elementor_alt_value($value): ?string {
        $trimmed = trim((string) $value);
        if ($trimmed === '' || preg_match('/^(null|undefined)$/i', $trimmed) === 1) {
            return null;
        }

        return $trimmed;
    }
}
