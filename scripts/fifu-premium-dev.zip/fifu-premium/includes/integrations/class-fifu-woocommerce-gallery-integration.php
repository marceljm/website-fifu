<?php

defined( 'ABSPATH' ) || exit;

/**
 * Handles WooCommerce gallery filters for FIFU remote images.
 */
class Fifu_Woocommerce_Gallery_Integration {

    /**
     * Filters the HTML output for a single product image.
     *
     * @param string $html        Original image HTML.
     * @param mixed  $product     Product object.
     * @param string $woosize     WooCommerce image size.
     * @param array  $attr        HTML attributes for the image.
     * @param string $placeholder Placeholder HTML when no image.
     * @return string
     */
    public static function filter_product_image( $html, $product, $woosize, $attr, $placeholder ) {
        if ( empty($product) || !is_object($product) || !method_exists($product, 'get_id') ) {
            return $html;
        }

        return Fifu_Featured_Image_Filter::filter_post_thumbnail_html( $html, $product->get_id(), null, null, null );
    }

    /**
     * Overrides WooCommerce template loading when FIFU provides alternatives.
     *
     * @param string $template Path to the original template.
     * @param string $slug     Template slug being loaded.
     * @return string
     */
    public static function filter_template( $template, $slug ) {
        if (!is_string($template) || !is_string($slug)) {
            return $template;
        }

        global $post;

        $product_page = array( 'single-product/product-image.php' );
        $is_elementor_editor = class_exists( 'Fifu_Plugin_Detector' ) && Fifu_Plugin_Detector::is_elementor_editor();

        if ( Fifu_Options_Utils::is_on( 'fifu_gallery' ) && $post && class_exists( 'WooCommerce' ) && is_product() && ! $is_elementor_editor ) {
            if ( in_array( $slug, $product_page, true ) ) {
                echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', '', $post->ID );
                return FIFU_INCLUDES_DIR . '/html/woocommerce-gallery-template.php';
            }
        }

        return $template;
    }

    /**
     * Normalizes a native WooCommerce product duplicate into independent
     * FIFU featured-image state.
     *
     * @param mixed $duplicate Duplicated WooCommerce product object.
     * @param mixed $source    Source WooCommerce product object.
     * @return void
     */
    public static function on_product_duplicate(
        $duplicate,
        $source
    ): void {
        if (
            !is_object($duplicate)
            || !method_exists($duplicate, 'get_id')
            || !is_object($source)
            || !method_exists($source, 'get_id')
        ) {
            return;
        }

        $duplicate_post_id = $duplicate->get_id();
        $duplicate_post_id = is_numeric($duplicate_post_id)
            ? (int) $duplicate_post_id
            : 0;

        $source_post_id = $source->get_id();
        $source_post_id = is_numeric($source_post_id)
            ? (int) $source_post_id
            : 0;

        if (
            $duplicate_post_id <= 0
            || $source_post_id <= 0
            || $duplicate_post_id === $source_post_id
        ) {
            return;
        }

        if (
            !class_exists(
                'Fifu_Post_Featured_Media_State_Resolver',
                false
            )
        ) {
            require_once
                FIFU_INCLUDES_DIR
                . '/meta/class-fifu-post-featured-media-state-resolver.php';
        }

        $featured_state =
            Fifu_Post_Featured_Media_State_Resolver::resolve(
                $source_post_id
            );

        if (
            is_array($featured_state)
            && ($featured_state['type'] ?? '') === 'video'
        ) {
            $video_url =
                Fifu_Post_Video_Read_Service::get_video_url(
                    $source_post_id
                );

            if (
                $video_url === null
                || trim($video_url) === ''
            ) {
                return;
            }

            delete_post_meta(
                $duplicate_post_id,
                '_thumbnail_id'
            );

            if (
                !Fifu_Developer_Media_Service::set_video(
                    $duplicate_post_id,
                    $video_url,
                    true
                )
            ) {
                return;
            }

            delete_post_meta(
                $duplicate_post_id,
                'fifu_video_url'
            );

            Fifu_Product_Gallery_Duplication_Service::duplicate(
                $source_post_id,
                $duplicate_post_id
            );

            return;
        }

        if (
            is_array($featured_state)
            && ($featured_state['type'] ?? '') === 'custom_video'
        ) {
            $custom_video_url =
                Fifu_Post_Custom_Video_Read_Service::get_custom_video_url(
                    $source_post_id
                );

            if (
                $custom_video_url === null
                || trim($custom_video_url) === ''
            ) {
                return;
            }

            $poster_url = null;

            if (
                class_exists(
                    'Fifu_Video_Oembed_Service'
                )
            ) {
                $poster_url =
                    Fifu_Video_Oembed_Service::instance()
                        ->get_repository()
                        ->get_image_url_by_video_url(
                            $custom_video_url
                        );
            }

            if (
                $poster_url === null
                || trim($poster_url) === ''
            ) {
                return;
            }

            delete_post_meta(
                $duplicate_post_id,
                '_thumbnail_id'
            );

            if (
                !Fifu_Developer_Media_Service::set_custom_video_with_poster(
                    $duplicate_post_id,
                    $custom_video_url,
                    $poster_url
                )
            ) {
                return;
            }

            delete_post_meta(
                $duplicate_post_id,
                'fifu_custom_video_url'
            );

            Fifu_Product_Gallery_Duplication_Service::duplicate(
                $source_post_id,
                $duplicate_post_id
            );

            return;
        }

        if (
            is_array($featured_state)
            && ($featured_state['type'] ?? '') === 'slider'
        ) {
            $slider_url_list =
                Fifu_Post_Slider_List_Url_Read_Service::get_slider_list_url(
                    $source_post_id
                );

            if (
                $slider_url_list === null
                || trim($slider_url_list) === ''
            ) {
                return;
            }

            $slider_alt_list =
                Fifu_Post_Slider_List_Alt_Read_Service::get_slider_list_alt(
                    $source_post_id
                ) ?? '';

            delete_post_meta(
                $duplicate_post_id,
                '_thumbnail_id'
            );

            if (
                !Fifu_Developer_Media_Service::set_slider(
                    $duplicate_post_id,
                    $slider_url_list,
                    $slider_alt_list,
                    true
                )
            ) {
                return;
            }

            return;
        }

        $url = Fifu_Post_Image_Url_Read_Service::get_image_url(
            $source_post_id
        );

        if (
            $url === null
            || trim($url) === ''
        ) {
            Fifu_Product_Gallery_Duplication_Service::duplicate(
                $source_post_id,
                $duplicate_post_id
            );

            return;
        }

        $alt = Fifu_Post_Image_Alt_Read_Service::get_image_alt(
            $source_post_id
        );

        /*
         * WooCommerce may have copied the source FIFU attachment ID.
         * Remove only the duplicate's inherited reference.
         */
        delete_post_meta(
            $duplicate_post_id,
            '_thumbnail_id'
        );

        if (
            !Fifu_Developer_Media_Service::set_image(
                $duplicate_post_id,
                $url,
                true
            )
        ) {
            return;
        }

        $alt_persisted = false;

        if (
            $alt !== null
            && trim($alt) !== ''
            && function_exists('fifu_db2_manager')
        ) {
            $manager = fifu_db2_manager();

            if (
                $manager instanceof Fifu_Db2_Manager
                && method_exists(
                    $manager,
                    'savePostAlt'
                )
            ) {
                $alt_persisted =
                    $manager->savePostAlt(
                        $duplicate_post_id,
                        'image',
                        0,
                        $alt
                    );
            }
        }

        /*
         * Normalize copied legacy FIFU metadata into canonical DB2 state.
         */
        delete_post_meta(
            $duplicate_post_id,
            'fifu_image_url'
        );

        if (
            $alt === null
            || trim($alt) === ''
            || $alt_persisted
        ) {
            delete_post_meta(
                $duplicate_post_id,
                'fifu_image_alt'
            );
        }

        Fifu_Product_Gallery_Duplication_Service::duplicate(
            $source_post_id,
            $duplicate_post_id
        );
    }

    /**
     * Indicates if an attachment is part of a product gallery.
     *
     * @param int $att_id Attachment ID to check.
     * @return bool
     */
    public static function is_in_gallery( int $att_id ): bool {
        $att_post = get_post( $att_id );
        $post_parent = get_post( $att_post->post_parent ?? null );
        if ( ! isset( $post_parent->ID ) ) {
            return false;
        }

        $gallery_ids = get_post_meta( $post_parent->ID, '_product_image_gallery', true );
        if ( $gallery_ids ) {
            $gallery_ids = array_filter( explode( ',', $gallery_ids ) );
        }

        if ( is_array( $gallery_ids ) ) {
            return in_array( $att_id, $gallery_ids, true );
        }

        return false;
    }
}
