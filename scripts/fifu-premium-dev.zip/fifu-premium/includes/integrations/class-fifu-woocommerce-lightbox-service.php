<?php

defined( 'ABSPATH' ) || exit;

/**
 * Provides data and media URLs for the WooCommerce FIFU lightbox.
 */
class Fifu_Woocommerce_Lightbox_Service {

    /**
     * Retrieves the prepared product data for the lightbox.
     *
     * @param int $post_id
     * @return array
     */
    public static function get_product_data( int $post_id ): array {
        $product = wc_get_product( $post_id );

        if ( ! $product ) {
            return array();
        }

        $data = array();
        $data['post_id'] = $post_id;
        $data['title'] = $product->get_name();
        $data['description'] = $product->get_description();

        $cf = get_option( 'fifu_buy_cf' );
        $data['cf'] = $cf ? get_post_meta( $post_id, $cf, true ) : null;

        $data['type'] = $product->get_type();
        $urls = self::get_media_urls( $product );
        $data['urls'] = $urls['images'];
        $data['video_srcs'] = $urls['videos'];
        $data['permalink'] = $product->get_permalink();
        $data['out_of_stock'] = __( 'Out of stock', 'woocommerce' );
        $data['in_stock'] = __( 'In stock', 'woocommerce' );
        $data['currency'] = get_woocommerce_currency_symbol();

        $button_text = $product->get_data()['button_text'] ?? null;
        $button_text = $button_text ? $button_text : get_option( 'fifu_buy_text' );
        $button_text = $button_text ? $button_text : 'Buy now';
        $data['button_text'] = $button_text;

        $data['key_lightgallery'] = get_option( 'fifu_key_lightgallery' );

        $disclaimer = get_option( 'fifu_buy_disclaimer' );
        $disclaimer = $disclaimer ? '<div class="fifu-disclaimer">' . $disclaimer . '</div>' : '';

        $button = '<a id="fifu-add-to-cart-link"><div id="fifu-add-to-cart"><span style="top:7px;position:relative;padding-right:25px" class="dashicons dashicons-yes-alt"></span>' . __( $button_text, 'woocommerce' ) . '</div></a>';

        if ( $product->is_type( 'simple' ) || $product->is_type( 'external' ) ) {
            $data['sale_price'] = $product->get_sale_price();
            $data['regular_price'] = $product->get_regular_price();
            $data['price'] = $data['sale_price'] ? wc_price( $data['sale_price'] ) : wc_price( $data['regular_price'] );
            $data['stock_status'] = $product->get_data()['stock_status'] ?? '';
            $data['stock_quantity'] = $product->get_data()['stock_quantity'] ?? '';
            $data['product_url'] = $product->get_data()['product_url'] ?? null;

            $price = '
                <tr>
                    <td class="label" style="width:30%">                    
                        <label for="fifu-price">' . __( 'Price', 'woocommerce' ) . '</label>
                    </td>
                    <td class="value" style="height:35px;width:70%">' .
                    ( $data['sale_price'] ? '<div style="color:#B12704;text-decoration:line-through;opacity:0.5;float:left">' . wc_price( $data['regular_price'] ) . '</div>' : '' ) . '
                        <div style="color:#B12704;text-decoration:none;float:left">&nbsp;' . $data['price'] . '</div>' .
                    ( $data['stock_status'] == 'instock' ? '<div id="fifu-in-stock">' . $data['stock_quantity'] . ' ' . $data['in_stock'] . '</div>' : '<div id="fifu-out-of-stock">' . $data['out_of_stock'] . '</div>' ) . '
                    </td>
                </tr>
            ';
            $table = '';
            $quantity = '
                <tr>
                    <td class="label">
                        <label for="fifu-quantity">' . __( 'Quantity', 'woocommerce' ) . '</label>
                    </td>
                    <td class="value">
                        <input id="fifu-quantity" type="number" step="1" min="1" max="' . $data['stock_quantity'] . '" name="quantity" value="1" title="Qty" size="4" placeholder="" inputmode="numeric" style="width:100%;height:30px;background-color:#f1f1f1;float:left">
                    </td>
                </tr>
            ';

            if ( ! $data['regular_price'] ) {
                $price = '';
                $quantity = '';
            }

            $data['table'] = $button . $disclaimer . $price . $table . $quantity;
            return $data;
        } elseif ( $product->is_type( 'variable' ) ) {
            $data['min_sale_price'] = $product->get_variation_sale_price( 'min', true );
            $data['max_sale_price'] = $product->get_variation_sale_price( 'max', true );
            $data['min_regular_price'] = $product->get_variation_regular_price( 'min', true );
            $data['max_regular_price'] = $product->get_variation_regular_price( 'max', true );
            $data['price'] = wc_price( $data['min_sale_price'] ) . ' – ' . wc_price( $data['max_sale_price'] );

            $available_variations = $product->get_available_variations();
            $data['variations_html'] = htmlspecialchars( json_encode( $available_variations ) );
            for ( $i = 0; $i < sizeof( $available_variations ); $i++ ) {
                $available_variations[ $i ]['urls'] = self::get_variation_image_urls( $available_variations[ $i ] );
                $price_html = $available_variations[ $i ]['price_html'] ?? '';
                if ( ! $price_html ) {
                    $available_variations[ $i ]['price_html'] = $product->get_price_html();
                }
            }
            $data['variations_json'] = json_encode( $available_variations );
            $data['unavailable'] = empty( $product->get_available_variations() ) ? '<div><span class="dashicons dashicons-dismiss"></span> ' . __( 'This product is currently out of stock and unavailable.', 'woocommerce' ) . '</div>' : '';
            $data['variations'] = array();

            $available = array();
            foreach ( $available_variations as $i => $variation ) {
                foreach ( ( $variation['attributes'] ?? [] ) as $name => $val ) {
                    $available[ $name ] = $available[ $name ] ?? array();
                    if ( ! in_array( $val, $available[ $name ] ) && $val ) {
                        array_push( $available[ $name ], $val );
                    }
                }
                array_push( $data['variations'], $variation['attributes'] ?? [] );
            }
            $data['available'] = $available;

            $price = '
                <tr>
                    <td class="label" style="width:30%">
                        <label for="fifu-price">' . __( 'Price', 'woocommerce' ) . '</label>
                    </td>
                    <td class="value" style="height:35px;width:70%">
                        <div id="fifu-price" style="color:#B12704;text-decoration:none">' . ( $data['unavailable'] ? $data['unavailable'] : $data['price'] ) . '</div>
                    </td>
                </tr>
            ';
            $table = '';
            foreach ( $product->get_attributes() as $attribute_name => $options ) {
                $option_value = '';
                $attribute_data = $options->get_data();
                $attribute_slug = self::normalize_attribute_slug( $attribute_name, $attribute_data['name'] ?? null );
                $atr_name = 'attribute_' . $attribute_slug;
                $is_taxonomy = $attribute_data['is_taxonomy'] ?? false;
                foreach ( ( $attribute_data['options'] ?? [] ) as $val ) {
                    if ( $is_taxonomy ) {
                        $term = get_term( $val );
                        if ( $term && ! is_wp_error( $term ) ) {
                            $value_slug = $term->slug;
                            $value_str = $term->name;
                        } else {
                            $value_slug = (string) $val;
                            $value_str = ucfirst( (string) $val );
                        }
                    } else {
                        $value_slug = $val;
                        $value_str = $val;
                    }
                    if ( in_array( $value_slug, $available[ $atr_name ] ?? [] ) ) {
                        $option_value .= '<option value="' . $value_slug . '" class="attached enabled">' . $value_str . '</option>';
                    }
                }

                $label_text = $attribute_name !== $attribute_slug ? $attribute_name : ( $attribute_data['name'] ?? $attribute_name );
                $table .= '
                    <tr>
                        <td class="label">
                            <label for="' . $attribute_slug . '">' . wc_attribute_label( $label_text ) . '</label>
                        </td>
                        <td class="value">
                            <select id="' . $attribute_slug . '" class="" name="' . $atr_name . '" data-attribute_name="' . $atr_name . '" data-show_option_none="yes" style="width:100%;height:35px;font-size:13px">
                                <option value="">' . __( 'Choose an option', 'woocommerce' ) . '</option>' .
                        $option_value . '                        
                            </select>
                        </td>
                    </tr>
                ';
            }
            $quantity = '
                <tr>
                    <td class="label">
                        <label for="fifu-quantity">' . __( 'Quantity', 'woocommerce' ) . '</label>
                    </td>
                    <td class="value">
                        <input id="fifu-quantity" type="number" step="1" min="1" max="" name="quantity" value="1" title="Qty" size="4" placeholder="" inputmode="numeric" style="width:100%;height:30px;background-color:#f1f1f1">
                    </td>
                </tr>
            ';
            $data['table'] = $button . $disclaimer . $price . $table . $quantity;
            return $data;
        }

        return $data;
    }

    /**
     * Retrieves the media URLs used by the lightbox for a single product.
     *
     * @param \WC_Product $product
     * @return array
     */
    public static function get_media_urls( \WC_Product $product ): array {
        $postId = (int) $product->get_id();
        $db2_urls = self::get_db2_image_urls( $postId );
        if ( self::should_use_db2_media_urls_first( $product, $db2_urls ) ) {
            return self::build_media_urls_from_url_list( $db2_urls, $postId );
        }

        $arr_image_url = array();
        $arr_video_src = array();
        $seen_urls = array();
        $videoOrdinal = 0;

        foreach ( self::get_product_attachment_ids( $product ) as $att_id ) {
            $url = Fifu_Image_Url_Utils::get_full_image_url( (int) $att_id );
            self::add_media_url( (string) $url, $postId, $videoOrdinal, $arr_image_url, $arr_video_src, $seen_urls );
        }

        if ( $arr_image_url !== array() ) {
            return array( 'images' => $arr_image_url, 'videos' => $arr_video_src );
        }

        if ( $db2_urls !== array() ) {
            return self::build_media_urls_from_url_list( $db2_urls, $postId );
        }

        return array( 'images' => $arr_image_url, 'videos' => $arr_video_src );
    }

    /**
     * @param \WC_Product $product
     * @return int[]
     */
    private static function get_product_attachment_ids( \WC_Product $product ): array {
        $ids = array();

        $image_id = (int) $product->get_image_id();
        if ( $image_id > 0 ) {
            $ids[] = $image_id;
        }

        foreach ( $product->get_gallery_image_ids() as $gallery_id ) {
            $gallery_id = (int) $gallery_id;
            if ( $gallery_id > 0 ) {
                $ids[] = $gallery_id;
            }
        }

        return array_values( array_unique( $ids ) );
    }

    /**
     * @param int $attachment_id
     * @return bool
     */
    private static function is_fifu_attachment( int $attachment_id ): bool {
        if ( $attachment_id <= 0 ) {
            return false;
        }

        if ( function_exists( 'fifu_is_fifu_attachment' ) ) {
            return (bool) fifu_is_fifu_attachment( $attachment_id );
        }

        $post = get_post( $attachment_id );
        if ( ! $post || ! isset( $post->post_author ) ) {
            return false;
        }

        if ( function_exists( 'fifu_get_fifu_author_candidates' ) ) {
            return in_array( (int) $post->post_author, array_map( 'intval', fifu_get_fifu_author_candidates() ), true );
        }

        $authors = array();
        if ( defined( 'FIFU_AUTHOR' ) ) {
            $authors[] = (int) FIFU_AUTHOR;
        }
        $authors[] = 77777;
        $authors[] = 7777777777;

        return in_array( (int) $post->post_author, array_unique( $authors ), true );
    }

    /**
     * @param \WC_Product $product
     * @param string[] $db2_urls
     * @return bool
     */
    private static function should_use_db2_media_urls_first( \WC_Product $product, array $db2_urls ): bool {
        if ( $db2_urls === array() ) {
            return false;
        }

        $attachment_ids = self::get_product_attachment_ids( $product );
        if ( $attachment_ids === array() ) {
            return true;
        }

        foreach ( $attachment_ids as $attachment_id ) {
            if ( ! self::is_fifu_attachment( (int) $attachment_id ) ) {
                return false;
            }
        }

        return true;
    }

    /**
     * @param int $postId
     * @return string[]
     */
    private static function get_db2_image_urls( int $postId ): array {
        $urls = array();
        if ( ! function_exists( 'fifu_db2_manager' ) ) {
            return $urls;
        }

        $manager = fifu_db2_manager();
        if ( ! $manager instanceof Fifu_Db2_Manager ) {
            return $urls;
        }

        for ( $index = 0; ; $index++ ) {
            $mapping = $manager->getPostMapping( $postId, 'image', $index );
            $url = is_array( $mapping ) ? trim( (string) ( $mapping['url'] ?? '' ) ) : '';
            if ( $url === '' ) {
                break;
            }
            if ( ! in_array( $url, $urls, true ) ) {
                $urls[] = $url;
            }
        }

        return $urls;
    }

    /**
     * @param string[] $urls
     * @param int $postId
     * @return array{images:string[],videos:array<string,string>}
     */
    private static function build_media_urls_from_url_list( array $urls, int $postId ): array {
        $arr_image_url = array();
        $arr_video_src = array();
        $seen_urls = array();
        $videoOrdinal = 0;

        foreach ( $urls as $url ) {
            self::add_media_url( (string) $url, $postId, $videoOrdinal, $arr_image_url, $arr_video_src, $seen_urls );
        }

        return array( 'images' => $arr_image_url, 'videos' => $arr_video_src );
    }

    /**
     * @param string $url
     * @param int $postId
     * @param int $videoOrdinal
     * @param string[] $images
     * @param array<string,string> $videos
     * @param string[] $seen
     */
    private static function add_media_url( string $url, int $postId, int &$videoOrdinal, array &$images, array &$videos, array &$seen ): void {
        $url = trim( $url );
        if ( $url === '' || in_array( $url, $seen, true ) ) {
            return;
        }

        $seen[] = $url;
        $images[] = $url;

        if ( Fifu_Video_Helper::is_video_thumb( $url ) ) {
            $videoSrc = self::resolve_video_src_for_thumb( $postId, $url, $videoOrdinal );
            if ( $videoSrc ) {
                $videos[ $url ] = $videoSrc;
            }
            $videoOrdinal++;
        }
    }

    private static function resolve_video_src_for_thumb( int $postId, string $thumbUrl, int $videoOrdinal ): ?string {
        $embed = Fifu_Video_Helper::get_embed_url_by_image( $thumbUrl );
        if ( $embed ) {
            return Fifu_Video_Helper::apply_privacy_enhanced_mode_to_embed_url( $embed );
        }

        $videoUrl = self::get_db2_video_url_by_ordinal( $postId, $videoOrdinal );
        if ( ! $videoUrl ) {
            return null;
        }

        $embed = Fifu_Video_Helper::get_embed_url( $videoUrl ) ?: $videoUrl;
        return Fifu_Video_Helper::apply_privacy_enhanced_mode_to_embed_url( $embed );
    }

    private static function get_db2_video_url_by_ordinal( int $postId, int $videoOrdinal ): ?string {
        if ( $videoOrdinal < 0 || ! function_exists( 'fifu_db2_manager' ) ) {
            return null;
        }

        $manager = fifu_db2_manager();
        if ( ! $manager instanceof Fifu_Db2_Manager ) {
            return null;
        }

        $mapping = $manager->getPostMapping( $postId, 'video', $videoOrdinal );
        $url = is_array( $mapping ) ? trim( (string) ( $mapping['url'] ?? '' ) ) : '';
        return $url !== '' ? $url : null;
    }

    /**
     * Retrieves variation-specific image URLs that mirror the legacy behavior.
     *
     * @param array $variation
     * @return array
     */
    public static function get_variation_image_urls( array $variation ): array {
        $arr = array();
        $cpt = 'fifu_image_url';
        if ( isset( $variation[ $cpt ] ) && $variation[ $cpt ] ) {
            array_push( $arr, $variation[ $cpt ] );
        } else {
            return $arr;
        }

        $i = 0;
        while ( true ) {
            $cpt = 'fifu_image_url_' . $i++;
            if ( isset( $variation[ $cpt ] ) && $variation[ $cpt ] ) {
                array_push( $arr, $variation[ $cpt ] );
            } else {
                return $arr;
            }
        }
    }

    private static function normalize_attribute_slug( string $attribute_name, ?string $display_name ): string {
        $source = trim( (string) ( $display_name ?: $attribute_name ) );
        $slug = strtolower( str_replace( ' ', '-', $source ) );
        $slug = preg_replace( '/[^a-z0-9_-]/', '', $slug ) ?? '';
        $slug = trim( $slug, '-_' );
        if ( $slug === '' ) {
            $fallback = strtolower( trim( (string) $attribute_name ) );
            $slug = str_replace( ' ', '-', $fallback );
            $slug = preg_replace( '/[^a-z0-9_-]/', '', $slug ) ?? '';
            $slug = trim( $slug, '-_' );
        }
        if ( $slug === '' ) {
            $slug = 'attribute';
        }
        return $slug;
    }
}
