<?php

defined( 'ABSPATH' ) || exit;

/**
 * Prepares future integration points for the WooCommerce product importer.
 */
class Fifu_Woocommerce_Product_Importer_Integration {

    /**
     * Future: update formatting callbacks for the WooCommerce importer.
     *
     * @param array $callbacks
     * @param mixed $importer
     * @return array
     */
    public static function filter_formatting_callbacks($callbacks, $importer) {
        if (!is_array($callbacks)) {
            return $callbacks;
        }

        if (!is_object($importer) || !is_callable([$importer, 'get_raw_keys'])) {
            return $callbacks;
        }

        $raw_keys = $importer->get_raw_keys();

        if (!is_iterable($raw_keys)) {
            return $callbacks;
        }

        foreach ($raw_keys as $keyIndex => $key) {
            if (!is_string($key)) {
                continue;
            }

            if (strpos($key, 'fifu') === 0 && strpos($key, 'url') !== false) {
                if (isset($callbacks[$keyIndex]) && $callbacks[$keyIndex] === 'wp_kses_post') {
                    $callbacks[$keyIndex] = [self::class, 'no_op_callback'];
                }
            }
        }

        return $callbacks;
    }

    /**
     * Future: no-op callback that returns the incoming value unchanged.
     */
    public static function no_op_callback($value) {
        return $value;
    }
}
