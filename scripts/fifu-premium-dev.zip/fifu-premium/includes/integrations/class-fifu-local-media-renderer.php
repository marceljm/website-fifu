<?php

defined( 'ABSPATH' ) || exit;

/**
 * Handles the FIFU local media session registration and output buffering.
 */
class Fifu_Local_Media_Renderer {

    /**
     * Registers a local image so the renderer can enrich it later.
     *
     * @param string $url
     * @param int    $att_id
     * @return void
     */
    public static function register_image( string $url, int $att_id ): void {
        global $FIFU_SESSION;

        $url = self::get_main_url( $url );
        if ( ! $url ) {
            return;
        }

        if ( isset( $FIFU_SESSION[ $url ] ) ) {
            return;
        }

        $post_id = get_the_ID();
        if ( ! $post_id ) {
            return;
        }

        if ( Fifu_Options_Utils::is_on( 'fifu_redirection' ) ) {
            $redirection_url = Fifu_Post_Redirection_Read_Service::get_redirection_url((int) $post_id);
            if ( $redirection_url ) {
                $FIFU_SESSION['fifu-redirection'][ $url ] = $redirection_url;
            }
        }

        $post_thumbnail_id = get_post_thumbnail_id( $post_id );

        $is_category = false;
        if ( ! $post_thumbnail_id ) {
            $post_thumbnail_id = get_term_meta( $post_id, 'thumbnail_id', true );
            if ( $post_thumbnail_id ) {
                $is_category = true;
            }
        }

        $featured = $post_thumbnail_id == $att_id ? 1 : 0;
        $gallery = ! $featured && Fifu_Woocommerce_Gallery_Integration::is_in_gallery( $att_id );

        if ( ! $featured && ! $gallery ) {
            return;
        }

        $parameters = array();
        $parameters['att_id'] = $att_id;
        $parameters['post_id'] = $post_id;
        $parameters['featured'] = $featured;
        $parameters['gallery'] = $gallery;
        $parameters['category'] = $is_category;
        $parameters['local'] = true;

        $FIFU_SESSION[ $url ] = $parameters;

        if (
            class_exists( 'WooCommerce' )
            && function_exists( 'is_product' )
            && function_exists( 'is_shop' )
            && function_exists( 'is_product_category' )
            && ! is_product()
            && ( is_shop() || is_product_category() )
        ) {
            if ( Fifu_Options_Utils::is_on( 'fifu_buy' ) ) {
                if ( ! isset( $FIFU_SESSION['fifulocal-lightbox'][ $post_id ] ) ) {
                    $data = Fifu_Woocommerce_Lightbox_Service::get_product_data( $post_id );
                    $FIFU_SESSION['fifulocal-lightbox'][ $post_id ] = $data;
                    wp_enqueue_script( 'fifu-lightbox-js', plugins_url( '/html/js/lightbox.js', __FILE__ ), array( 'jquery' ), Fifu_Plugin_Info::get_enqueue_version() );
                    wp_add_inline_script(
                        'fifu-lightbox-js',
                        'var fifuLightboxVar' . $post_id . ' = ' . wp_json_encode( $data ) . ';',
                        'before'
                    );
                }
            }
        }
    }

    /**
     * Enriches a FIFU attachment URL with session parameters and metadata.
     *
     * This will eventually replace fifu_add_url_parameters and keep all session/$FIFU_SESSION
     * enrichment in one place before the legacy logic is migrated away.
     *
     * @param string     $url
     * @param int        $attachment_id
     * @param mixed|null $size
     * @return string
     */
    public static function enrich_attachment_url( string $url, int $attachment_id, $size = null ): string {
        global $FIFU_SESSION;

        if (
            class_exists( 'Fifu_Wai_Addon_Integration', false )
            && method_exists( 'Fifu_Wai_Addon_Integration', 'is_wp_all_import_request_active' )
            && Fifu_Wai_Addon_Integration::is_wp_all_import_request_active()
        ) {
            return $url;
        }

        if ( isset( $FIFU_SESSION[ $url ] ) ) {
            return $url;
        }

        $post = get_post( $attachment_id );
        $post_id = $post ? $post->post_parent : null;

        if ( ! $post_id ) {
            return $url;
        }

        if (
            function_exists( 'get_current_screen' )
            && isset( get_current_screen()->parent_file )
            && get_current_screen()->parent_file === 'edit.php?post_type=product'
            && get_current_screen()->id === 'edit-product_cat'
        ) {
            return Fifu_Cdn_Thumbnail_Resolver::get_optimized_thumbnail_url( $url, $attachment_id );
        }

        if ( Fifu_Options_Utils::is_on( 'fifu_video' ) ) {
            $video_url = Fifu_Post_Custom_Video_Read_Service::get_custom_video_url( (int) $post_id );
            if ( $video_url ) {
                $FIFU_SESSION['fifu-custom-video'][ $url ] = $video_url;
                $FIFU_SESSION['fifu-permalink'][ $url ] = get_permalink( $post_id );
            }

            $embed_url = self::resolve_video_embed_for_thumbnail( $url, (int) $post_id );
            $is_video_thumb = $embed_url
                || Fifu_Video_Helper::is_video_thumb( $url )
                || Fifu_Video_Helper::is_suvideo_thumbnail( $url );

            if ( $is_video_thumb && ! isset( $FIFU_SESSION['fifu-video'][ $url ] ) ) {
                $FIFU_SESSION['fifu-video'][ $url ] = $embed_url;
                $FIFU_SESSION['fifu-permalink'][ $url ] = get_permalink( $post_id );
            }
        }

        if ( Fifu_Options_Utils::is_on( 'fifu_video' ) ) {
            $audio_url = Fifu_Post_Audio_Read_Service::get_audio_url( (int) $post_id );
            if ( $audio_url && ! isset( $FIFU_SESSION['fifu-audio'][ $url ] ) ) {
                $FIFU_SESSION['fifu-audio'][ $url ] = $audio_url;
            }
        }

        if ( Fifu_Options_Utils::is_on( 'fifu_popup' ) && ! isset( $FIFU_SESSION['fifu-popup'][ $post_id ] ) ) {
            $html = get_post_meta( $post_id, 'fifu_popup_html', true );
            if ( $html ) {
                $FIFU_SESSION['fifu-popup'][ $post_id ] = $html;
                $fifu_popup_handle = 'fifu-popup-js';
                if ( ! wp_script_is( $fifu_popup_handle, 'enqueued' ) ) {
                    wp_enqueue_script( $fifu_popup_handle, plugins_url( '/includes/html/js/popup.js', FIFU_PLUGIN_FILE ), array( 'jquery' ), Fifu_Plugin_Info::get_enqueue_version() );
                }
                $json = wp_json_encode( [ 'html' => $FIFU_SESSION['fifu-popup'] ], JSON_UNESCAPED_SLASHES );
                wp_add_inline_script( $fifu_popup_handle, "var fifuPopupVars = {$json};", 'before' );
                wp_add_inline_script( $fifu_popup_handle, '/* ' . $html . ' */', 'before' );

                if (
                    Fifu_Options_Utils::is_on( 'fifu_video' )
                    || Fifu_Options_Utils::is_on( 'fifu_redirection' )
                    || Fifu_Options_Utils::is_on( 'fifu_otfcdn' )
                ) {
                    if ( ! wp_script_is( 'popup-js', 'enqueued' ) ) {
                        wp_enqueue_script( 'popup-js', plugins_url( '/includes/html/js/popup.js', FIFU_PLUGIN_FILE ), array( 'jquery' ), Fifu_Plugin_Info::get_enqueue_version() );
                    }
                    wp_add_inline_script( 'popup-js', "var fifuPopupVars = {$json};", 'before' );
                    wp_add_inline_script( 'popup-js', '/* ' . $html . ' */', 'before' );
                }
            }
        }

        if ( Fifu_Options_Utils::is_on( 'fifu_redirection' ) ) {
            $redirection_url = Fifu_Post_Redirection_Read_Service::get_redirection_url((int) $post_id);
            if ( $redirection_url ) {
                $FIFU_SESSION['fifu-redirection'][ $url ] = $redirection_url;
                if ( Fifu_Options_Utils::is_on( 'fifu_otfcdn' ) ) {
                    $FIFU_SESSION['fifu-redirection'][ Fifu_Image_Url_Utils::base64( $url ) ] = $redirection_url;
                }
            }
        }

        $post_thumbnail_id = get_post_thumbnail_id( $post_id );

        $is_category = false;
        if ( ! $post_thumbnail_id ) {
            $post_thumbnail_id = get_term_meta( $post_id, 'thumbnail_id', true );
            if ( $post_thumbnail_id ) {
                $is_category = true;
            }
        }

        $featured = $post_thumbnail_id == $attachment_id ? 1 : 0;
        $gallery = ! $featured && Fifu_Woocommerce_Gallery_Integration::is_in_gallery( $attachment_id );

        if ( ! $featured && ! $gallery ) {
            return $url;
        }

        $parameters = array();
        $parameters['att_id'] = $attachment_id;
        $parameters['post_id'] = $post_id;
        $parameters['featured'] = $featured;
        $parameters['gallery'] = $gallery;
        $parameters['category'] = $is_category;
        $parameters['local'] = false;

        $type = null;
        if ( $size ) {
            $size_details = Fifu_Image_Size_Usage_Tracker::get_image_size_details( $size );
            if ( ( $size_details['width'] ?? false ) && ( $size_details['height'] ?? false ) ) {
                $parameters['theme-width'] = $size_details['width'];
                $parameters['theme-height'] = $size_details['height'];
                $parameters['theme-crop'] = $size_details['crop'] ?? false;
            }
        }

        $slider_url = Fifu_Post_Slider_Image_Url_Read_Service::get_slider_image_url(
            (int) $post_id,
            0
        );
        $parameters['type'] = ( Fifu_Options_Utils::is_on( 'fifu_slider' ) && Fifu_Slider_Policy::should_show_slider_image( $post_id, $slider_url ) ) ? 'slider' : $type;

        $FIFU_SESSION[ $url ] = $parameters;

        if ( Fifu_Speedup_Url_Service::is_speedup_url( $url ) ) {
            $FIFU_SESSION['fifu-cloud'][ $url ] = Fifu_Speedup_Url_Service::get_srcset( $url );
            wp_enqueue_script( 'fifu-cloud', plugins_url( '/includes/html/js/cloud.js', FIFU_PLUGIN_FILE ), array( 'jquery' ), Fifu_Plugin_Info::get_enqueue_version() );
            $json = wp_json_encode( [ 'srcsets' => $FIFU_SESSION['fifu-cloud'] ] );
            wp_add_inline_script( 'fifu-cloud', "var fifuCloudVars = {$json};", 'before' );
        }

        if (
            class_exists( 'WooCommerce' )
            && function_exists( 'is_product' )
            && function_exists( 'is_shop' )
            && function_exists( 'is_product_category' )
            && ! is_product()
            && ( is_shop() || is_product_category() )
        ) {
            if ( Fifu_Options_Utils::is_on( 'fifu_buy' ) ) {
                if ( ! isset( $FIFU_SESSION['fifu-lightbox'][ $post_id ] ) ) {
                    $data = Fifu_Woocommerce_Lightbox_Service::get_product_data( $post_id );
                    $FIFU_SESSION['fifu-lightbox'][ $post_id ] = $data;
                    wp_enqueue_script( 'fifu-lightbox-js', plugins_url( '/html/js/lightbox.js', __FILE__ ), array( 'jquery' ), Fifu_Plugin_Info::get_enqueue_version() );
                    $json = wp_json_encode( $data );
                    wp_add_inline_script( 'fifu-lightbox-js', "var fifuLightboxVar{$post_id} = {$json};", 'before' );
                }
            }
        }

        return $url;
    }

    /**
     * Resolves a video embed URL for a thumbnail using cache-friendly lookups.
     *
     * @param string $url
     * @param int $post_id
     * @return string|null
     */
    private static function resolve_video_embed_for_thumbnail( string $url, int $post_id ): ?string {
        $original_image_url = Fifu_Jetpack_Cdn_Service::get_original_image_url( $url );
        $is_known_video_thumb = Fifu_Video_Helper::is_video_thumb( $url )
            || Fifu_Video_Helper::is_suvideo_thumbnail( $url )
            || Fifu_Video_Helper::is_suvideo_thumbnail( $original_image_url );

        if ( $is_known_video_thumb ) {
            $provider = Fifu_Video_Provider_Registry::instance()->get_provider_for_url( $original_image_url );
            if ( $provider instanceof Fifu_Suvideo_Video_Provider ) {
                $embed_url = $provider->get_embed_url( $original_image_url );
                if ( $embed_url ) {
                    return $embed_url;
                }
            }

            if ( $original_image_url !== $url ) {
                $embed_url = Fifu_Video_Helper::get_embed_url_by_image( $original_image_url );
                if ( $embed_url ) {
                    return $embed_url;
                }
            }

            $legacy_video_url = Fifu_Post_Video_Read_Service::get_video_url( (int) $post_id );
            if ( $legacy_video_url ) {
                $embed_url = Fifu_Video_Helper::get_embed_url( $legacy_video_url );
                if ( $embed_url ) {
                    return $embed_url;
                }
            }
            $embed_url = Fifu_Video_Helper::get_embed_url_by_image( $url );
            if ( $embed_url ) {
                return $embed_url;
            }

            if ( $original_image_url !== $url ) {
                $embed_url = Fifu_Video_Helper::get_embed_url_by_image( $original_image_url );
                if ( $embed_url ) {
                    return $embed_url;
                }
            }

            return null;
        }

        return null;
    }

    /**
     * Registers a single post thumbnail with the FIFU session.
     *
     * This is the future replacement for fifu_add_parameters_single_post.
     *
     * @param int $post_id
     * @return void
     */
    public static function register_post_thumbnail( int $post_id ): void {
        $attachment_id = get_post_thumbnail_id( $post_id );
        if ( ! $attachment_id ) {
            return;
        }

        $url = get_post_meta( $attachment_id, '_wp_attached_file', true );
        if ( $url ) {
            self::enrich_attachment_url( $url, $attachment_id, null );
        }
    }

    /**
     * Registers thumbnails when posts_results is filtered to keep FIFU session data in sync.
     *
     * WordPress and third-party plugins can short-circuit queries before posts are populated.
     * Keep the original value unchanged when posts_results receives null or another non-array value.
     *
     * @param array|null $posts
     * @param \WP_Query  $query
     * @return array|null
     */
    public static function register_posts_results( $posts, $query ) {
        if ( ! is_array( $posts ) || empty( $posts ) ) {
            return $posts;
        }

        if (!$query instanceof \WP_Query) {
            return $posts;
        }

        if ( ! is_admin() && $query->is_main_query() && is_paged() ) {
            foreach ( $posts as $post ) {
                if ( isset( $post->ID ) ) {
                    self::register_post_thumbnail( (int) $post->ID );
                }
            }
        }

        return $posts;
    }

    /**
     * Starts output buffering for local media processing.
     */
    public static function start_buffer(): void {
        ob_start( array( self::class, 'filter_buffer' ) );
    }

    /**
     * Filters the buffer in order to enrich local FIFU images and backgrounds.
     *
     * @param string $buffer
     * @return string
     */
    public static function filter_buffer( string $buffer ): string {
        global $FIFU_SESSION;

        if ( empty( $buffer ) ) {
            return $buffer;
        }

        if ( isset( $_REQUEST['ct_builder'] ) || isset( $_REQUEST['bricks'] ) || isset( $_REQUEST['fb-edit'] ) ) {
            return $buffer;
        }

        $srcType = 'src';
        $imgList = array();
        preg_match_all( '/<img[^>]*>/', $buffer, $imgList );

        foreach ( ( $imgList[0] ?? [] ) as $imgItem ) {
            preg_match( '/(' . $srcType . ')([^\\\'"]*[\\\'"]){2}/', $imgItem, $src );
            if ( ! $src ) {
                continue;
            }
            $del = substr( $src[0] ?? '', -1 );
            $url = Fifu_Html_Attribute_Utils::normalize( explode( $del, $src[0] ?? '' )[1] ?? '' );

            $url = self::get_main_url( $url );
            if ( ! $url ) {
                continue;
            }

            if ( isset( $FIFU_SESSION[ $url ] ) ) {
                $data = $FIFU_SESSION[ $url ];
            } else {
                continue;
            }

            if ( strpos( $imgItem, 'fifulocal-replaced' ) !== false ) {
                continue;
            }

            if ( ! ( $data['local'] ?? false ) ) {
                continue;
            }

            $post_id = $data['post_id'] ?? null;
            $att_id = $data['att_id'] ?? null;
            $featured = $data['featured'] ?? null;
            $is_category = $data['category'] ?? false;

            if ( $featured ) {
                $newImgItem = str_replace( '<img ', '<img fifulocal-featured="' . $featured . '" ', $imgItem );

                if ( $is_category ) {
                    $newImgItem = str_replace( '<img ', '<img fifu-category="1" ', $newImgItem );
                }

                if ( get_post_type( $post_id ) == 'product' ) {
                    $newImgItem = str_replace( '<img ', '<img product-id="' . $post_id . '" ', $newImgItem );
                } else {
                    $newImgItem = str_replace( '<img ', '<img post-id="' . $post_id . '" ', $newImgItem );
                }

                $buffer = str_replace( $imgItem, Fifu_Featured_Image_Filter::filter_post_thumbnail_html( $newImgItem, $post_id, null, null, null ), $buffer );
            }
        }

        $imgList = array();
        preg_match_all( '/<[^>]*background-image[^>]*>/', $buffer, $imgList );
        foreach ( ( $imgList[0] ?? [] ) as $imgItem ) {
            if ( strpos( $imgItem, 'style=' ) === false || strpos( $imgItem, 'url(' ) === false ) {
                continue;
            }

            $mainDelimiter = substr( explode( 'style=', str_replace( '\\', '', $imgItem ) )[1] ?? '', 0, 1 );
            $subDelimiter = substr( explode( 'url(', str_replace( '\\', '', $imgItem ) )[1] ?? '', 0, 1 );
            if ( in_array( $subDelimiter, array( '"', "'", ' ' ) ) ) {
                $url = preg_split( '/[\'" ]{1}\)/', preg_split( '/url\([\'" ]{1}/', $imgItem, -1 )[1] ?? '', -1 )[0] ?? '';
            } else {
                $url = preg_split( '/\)/', preg_split( '/url\(/', $imgItem, -1 )[1] ?? '', -1 )[0] ?? '';
                $subDelimiter = '';
            }

            $newImgItem = $imgItem;

            $url = Fifu_Html_Attribute_Utils::normalize( $url );
            $url = self::get_main_url( $url );
            if ( ! $url ) {
                continue;
            }

            if ( isset( $FIFU_SESSION[ $url ] ) ) {
                $data = $FIFU_SESSION[ $url ];

                if ( strpos( $imgItem, 'fifulocal-replaced' ) !== false ) {
                    continue;
                }

                if ( ! ( $data['local'] ?? false ) ) {
                    continue;
                }

                $post_id = $data['post_id'] ?? null;
                $newImgItem = str_replace( '>', ' ' . 'post-id="' . $post_id . '">', $newImgItem );
            }

            if ( $newImgItem != $imgItem ) {
                $buffer = str_replace( $imgItem, $newImgItem, $buffer );
            }
        }

        return $buffer;
    }

    /**
     * Normalizes a URL so duplicate size suffixes are removed.
     *
     * @param string $url
     * @return string|null
     */
    private static function get_main_url( string $url ): ?string {
        if ( ! $url ) {
            return null;
        }

        $aux = explode( '.', $url );
        if ( ! $aux || sizeof( $aux ) <= 1 ) {
            return null;
        }

        $extension = $aux[ sizeof( $aux ) - 1 ] ?? '';
        if ( ! $extension ) {
            return null;
        }

        return preg_replace( '/-[0-9]+x[0-9]+.[a-z]{1,4}$/', '.' . $extension, $url );
    }
}
