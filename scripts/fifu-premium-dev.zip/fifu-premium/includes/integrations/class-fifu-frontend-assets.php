<?php

defined('ABSPATH') || exit;

/**
 * Enqueues FIFU frontend assets that previously depended on legacy hooks.
 */
class Fifu_Frontend_Assets {

    /**
     * Adds the head assets and resource hints that modern FIFU builds expect.
     */
    public static function add_head_assets(): void {
        if (Fifu_Amp_Integration::is_amp_request()) {
            return;
        }

        if (Fifu_Admin_Menu::is_su_sign_up_complete()) {
            echo '<link rel="preconnect" href="https://cloud.fifu.app">';
            echo '<link rel="preconnect" href="https://cdn.fifu.app">';
        }

        if (Fifu_Options_Utils::is_on('fifu_photon')) {
            if (Fifu_Options_Utils::is_on('fifu_otfcdn')) {
                $prefix = Fifu_Options_Utils::is_own_domain_effective() ? "//img." : "//i0.fifu.app/";
                $href = str_replace("//", $prefix, get_home_url());
                echo "<link rel='dns-prefetch' href='{$href}'>";
                echo "<link rel='preconnect' href='{$href}'>";
            }

            echo "<link rel='dns-prefetch' href='https://wp.fifu.app/'>";
            echo "<link rel='preconnect' href='https://wp.fifu.app/' crossorigin>";
        }

        if (Fifu_Options_Utils::is_on('fifu_slider') || (Fifu_Options_Utils::is_on('fifu_gallery') && class_exists('WooCommerce') && is_product())) {
            wp_register_style('fifu-slider-style', plugins_url('/includes/html/css/slider.css', FIFU_PLUGIN_FILE), array(), Fifu_Plugin_Info::get_enqueue_version());
            wp_enqueue_style('fifu-slider-style');
            if (get_option('fifu_slider_left') || get_option('fifu_slider_right')) {
                wp_register_style('fifu-slider-custom-arrows', plugins_url('/includes/html/css/slider-custom-arrows.css', FIFU_PLUGIN_FILE), array(), Fifu_Plugin_Info::get_enqueue_version());
                wp_enqueue_style('fifu-slider-custom-arrows');
            }
        }

        if (class_exists('WooCommerce')) {
            wp_register_style('fifu-woo', plugins_url('/includes/html/css/woo.css', FIFU_PLUGIN_FILE), array(), Fifu_Plugin_Info::get_enqueue_version());
            wp_enqueue_style('fifu-woo');
            wp_add_inline_style('fifu-woo', 'img.zoomImg {display:' . Fifu_Woocommerce_Display_Configuration::get_zoom_display_mode() . ' !important}');
        }

        if (
            Fifu_Options_Utils::is_on('fifu_mouse_video') ||
            Fifu_Options_Utils::is_on('fifu_video_play_button') ||
            Fifu_Options_Utils::is_on('fifu_autoplay') ||
            Fifu_Options_Utils::is_on('fifu_autoplay_front') ||
            Fifu_Options_Utils::is_on('fifu_autoplay_elsewhere')
        ) {
            wp_enqueue_script('youtube', 'https://www.youtube.com/iframe_api');
            wp_enqueue_script('fifu-vimeo-player', 'https://player.vimeo.com/api/player.js');
        }

        if (Fifu_Options_Utils::is_on('fifu_video')) {
            wp_enqueue_style('dashicons');
        }

        if (Fifu_Options_Utils::is_on('fifu_buy') && class_exists('WooCommerce') && (is_shop() || is_product_category()) && !is_cart()) {
            wp_enqueue_style('fancy-box-css', 'https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.css');
            wp_enqueue_script('fancy-box-js', 'https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js');
            if (!wp_script_is('lightgallery')) {
                wp_enqueue_style('lightgallery-style', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.8.3/css/lightgallery.min.css');
                wp_enqueue_script('lightgallery', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.8.3/lightgallery.min.js');
                wp_enqueue_style('lightgallery-thumb-style', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.8.3/css/lg-thumbnail.min.css');
                wp_enqueue_script('lightgallery-thumb', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.8.3/plugins/thumbnail/lg-thumbnail.min.js');
                wp_enqueue_style('lightgallery-zoom-style', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.8.3/css/lg-zoom.min.css');
                wp_enqueue_script('lightgallery-zoom', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.8.3/plugins/zoom/lg-zoom.min.js');
                wp_enqueue_style('lightgallery-video-style', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.8.3/css/lg-video.min.css');
                wp_enqueue_script('lightgallery-video', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.8.3/plugins/video/lg-video.min.js');
            }
            wp_register_style('fifu-lightbox-style', plugins_url('/includes/html/css/lightbox.css', FIFU_PLUGIN_FILE), array(), Fifu_Plugin_Info::get_enqueue_version());
            wp_enqueue_style('fifu-lightbox-style');
            wp_enqueue_script('fifu-lightbox-js', plugins_url('/includes/html/js/lightbox.js', FIFU_PLUGIN_FILE), array('jquery'), Fifu_Plugin_Info::get_enqueue_version());
            wp_localize_script('fifu-lightbox-js', 'fifuLgVars', [
                'fifu_key_lightgallery' => get_option('fifu_key_lightgallery'),
            ]);
            if (!wp_style_is('dashicons')) {
                wp_enqueue_style('dashicons');
            }
        }

        $main_image_url = Fifu_Post_Main_Image_Resolver::get_main_image_url(get_queried_object_id(), true);
        $base64_main_image_url = $main_image_url && Fifu_Options_Utils::is_on('fifu_otfcdn') ? Fifu_Image_Url_Utils::base64($main_image_url) : null;

        if (Fifu_Options_Utils::is_on('fifu_slider') || get_option('fifu_error_url') || Fifu_Theme_Detector::is_flatsome_active() || Fifu_Options_Utils::is_on('fifu_block') || Fifu_Options_Utils::is_on('fifu_redirection') || ((Fifu_Options_Utils::is_on('fifu_gallery') || !Fifu_Woocommerce_Display_Configuration::is_lightbox_enabled()) && class_exists('WooCommerce') && is_product())) {
            wp_enqueue_script('fifu-image-js', plugins_url('/includes/html/js/image.js', FIFU_PLUGIN_FILE), array('jquery'), Fifu_Plugin_Info::get_enqueue_version());
            wp_localize_script('fifu-image-js', 'fifuImageVars', [
                'fifu_slider' => Fifu_Options_Utils::is_on('fifu_slider') || (Fifu_Options_Utils::is_on('fifu_gallery') && class_exists('WooCommerce') && is_product()),
                'fifu_slider_vertical' => Fifu_Options_Utils::is_on('fifu_slider_vertical'),
                'fifu_is_front_page' => is_front_page() || is_home(),
                'fifu_woo_lbox_enabled' => Fifu_Woocommerce_Display_Configuration::is_lightbox_enabled(),
                'fifu_error_url' => get_option('fifu_error_url'),
                'fifu_is_flatsome_active' => Fifu_Theme_Detector::is_flatsome_active(),
                'fifu_block' => Fifu_Options_Utils::is_on('fifu_block'),
                'fifu_redirection' => Fifu_Options_Utils::is_on('fifu_redirection'),
                'fifu_forwarding_url' => Fifu_Post_Redirection_Read_Service::get_redirection_url((int) get_queried_object_id()),
                'fifu_main_image_url' => $main_image_url,
                'base64_main_image_url' => $base64_main_image_url,
                'fifu_local_image_url' => get_the_post_thumbnail_url(get_the_ID(), 'full'),
            ]);
        }

        if (class_exists('WooCommerce') && is_product() && Fifu_Options_Utils::is_off('fifu_gallery')) {
            wp_enqueue_script('fifu-photoswipe-fix', plugins_url('/includes/html/js/photoswipe-fix.js', FIFU_PLUGIN_FILE), array('jquery'), Fifu_Plugin_Info::get_enqueue_version());
            wp_localize_script('fifu-photoswipe-fix', 'fifuSwipeVars', [
                'theme' => get_option('template'),
            ]);
        }

        if (Fifu_Options_Utils::is_on('fifu_popup')) {
            wp_register_style('fifu-popup-css', plugins_url('/includes/html/css/popup.css', FIFU_PLUGIN_FILE), array(), Fifu_Plugin_Info::get_enqueue_version());
            wp_enqueue_style('fifu-popup-css');
            wp_enqueue_script('fifu-popup-js', plugins_url('/includes/html/js/popup.js', FIFU_PLUGIN_FILE), array('jquery'), Fifu_Plugin_Info::get_enqueue_version());
            if (!wp_script_is('fancy-box-js')) {
                wp_enqueue_style('fancy-box-css', 'https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.css');
                wp_enqueue_script('fancy-box-js', 'https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js');
            }
        }
    }

    /**
     * Enqueues Lightslider assets and localization data for sliders.
     *
     * @param bool $is_shortcode Whether the call originates from a shortcode.
     */
    public static function enqueue_lightslider_assets(bool $is_shortcode = false): void {
        $is_product = class_exists('WooCommerce') && is_product();
        if (Fifu_Theme_Detector::is_houzez_active() || Fifu_Theme_Detector::is_wpresidence_active()) {
            return;
        }

        if (Fifu_Options_Utils::is_on('fifu_slider') || ($is_product && Fifu_Options_Utils::is_on('fifu_gallery')) || $is_shortcode) {
            wp_enqueue_script('fifu-lightslider', plugins_url('/includes/html/js/lightslider.js', FIFU_PLUGIN_FILE), array('jquery'), Fifu_Plugin_Info::get_enqueue_version());
            wp_localize_script('fifu-lightslider', 'fifuMainSliderVars', [
                'fifu_error_url' => get_option('fifu_error_url'),
                'fifu_slider_crop' => Fifu_Options_Utils::is_on('fifu_slider_crop'),
                'fifu_slider_vertical' => Fifu_Options_Utils::is_on('fifu_slider_vertical'),
                'fifu_is_product' => $is_product,
                'fifu_is_front_page' => is_front_page(),
                'fifu_adaptive_height' => Fifu_Options_Utils::is_on('fifu_adaptive_height'),
            ]);
            wp_enqueue_script('jquery-zoom', 'https://cdnjs.cloudflare.com/ajax/libs/jquery-zoom/1.7.21/jquery.zoom.min.js', array('jquery'));
            wp_enqueue_style('lightslider-style', 'https://cdnjs.cloudflare.com/ajax/libs/lightslider/1.1.6/css/lightslider.min.css');
            wp_enqueue_script('fifu-slider-js', plugins_url('/includes/html/js/lightsliderConfig.js', FIFU_PLUGIN_FILE), array('jquery', 'fifu-lightslider', 'jquery-zoom'), Fifu_Plugin_Info::get_enqueue_version());
            wp_localize_script('fifu-slider-js', 'fifuSliderVars', [
                'fifu_slider_speed' => get_option('fifu_slider_speed'),
                'fifu_slider_auto' => Fifu_Options_Utils::is_on('fifu_slider_auto'),
                'fifu_slider_pause' => get_option('fifu_slider_pause'),
                'fifu_slider_ctrl' => Fifu_Options_Utils::is_on('fifu_slider_ctrl'),
                'fifu_slider_stop' => Fifu_Options_Utils::is_on('fifu_slider_stop'),
                'fifu_slider_gallery' => Fifu_Options_Utils::is_on('fifu_slider_gallery') || ($is_product && Fifu_Woocommerce_Display_Configuration::is_lightbox_enabled()),
                'fifu_slider_thumb' => Fifu_Options_Utils::is_on('fifu_slider_thumb'),
                'fifu_slider_counter' => Fifu_Options_Utils::is_on('fifu_slider_counter'),
                'fifu_slider_crop' => Fifu_Options_Utils::is_on('fifu_slider_crop'),
                'fifu_slider_vertical' => Fifu_Options_Utils::is_on('fifu_slider_vertical'),
                'fifu_slider_left' => get_option('fifu_slider_left'),
                'fifu_slider_right' => get_option('fifu_slider_right'),
                'fifu_is_product' => $is_product,
                'fifu_adaptive_height' => Fifu_Options_Utils::is_on('fifu_adaptive_height'),
                'fifu_url' => Fifu_Post_Main_Image_Resolver::get_main_image_url(get_the_ID(), true),
                'fifu_error_url' => get_option('fifu_error_url'),
                'fifu_video' => Fifu_Options_Utils::is_on('fifu_video'),
                'fifu_is_mobile' => wp_is_mobile(),
                'fifu_wc_zoom' => Fifu_Options_Utils::is_on('fifu_wc_zoom'),
                'fifu_key_lightgallery' => get_option('fifu_key_lightgallery'),
                'pager' => Fifu_Options_Utils::is_on('fifu_slider_thumb') || (Fifu_Options_Utils::is_off('fifu_slider_thumb') && $is_product),
            ]);
            Fifu_Lightgallery_Integration::enqueue_assets($is_product);
        }
    }

    /**
     * Enqueues FIFU video assets and localization strings for the video feature set.
     */
    public static function enqueue_video_assets(): void {
        $strings = Fifu_Video_Strings::get_strings();
        $plugin_detector_exists = class_exists('Fifu_Plugin_Detector');
        $theme_detector_exists = class_exists('Fifu_Theme_Detector');

        if (Fifu_Options_Utils::is_on('fifu_video')) {
            wp_register_style('fifu-video-css', plugins_url('/includes/html/css/video.css', FIFU_PLUGIN_FILE), array(), Fifu_Plugin_Info::get_enqueue_version());
            wp_enqueue_style('fifu-video-css');

            if (Fifu_Woocommerce_Context::is_shop() && Fifu_Theme_Detector::is_avada_active()) {
                $inline_style1 = '.fifu_play {width: 100%; height: inherit; position: absolute; display: contents;}';
            } else {
                $inline_style1 = '.fifu_play {position: relative; width: 100%; z-index:' . get_option('fifu_video_zindex') . '; /* no zoom */}';
            }
            $inline_style2 = '.fifu_play .fifubtn:hover {background-color: ' . get_option('fifu_video_color') . '; opacity: 0.9;}';
            $inline_style3 = '.fifu_play_bg:hover {background-color: ' . get_option('fifu_video_color') . '; opacity: 0.9;}';
            $play_button_size = get_option('fifu_video_size');
            $inline_style4 = '.fifu_play .fifubtn {font-size: ' . $play_button_size . 'px; padding: ' . Fifu_Video_Configuration::get_play_button_padding($play_button_size) . '}';
            wp_add_inline_style('fifu-video-css', $inline_style1);
            wp_add_inline_style('fifu-video-css', $inline_style2);
            wp_add_inline_style('fifu-video-css', $inline_style3);
            wp_add_inline_style('fifu-video-css', $inline_style4);

            $side_button_position = Fifu_Options_Utils::is_on('fifu_video_later_left') ? 'left' : 'right';
            wp_add_inline_style('fifu-video-css', ".fifu_play .icon {opacity: 0.7; color: white; background-color: transparent; position: absolute; top: 5px; {$side_button_position}: 5px; font-size: 32px;}");

            if (get_option('fifu_play_type') == 'lightbox') {
                wp_enqueue_style('fancy-box-css', 'https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.css');
                wp_enqueue_script('fancy-box-js', 'https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js');
            }

            wp_enqueue_script('fifu-video-js', plugins_url('/includes/html/js/video.js', FIFU_PLUGIN_FILE), array('jquery'), Fifu_Plugin_Info::get_enqueue_version());
            wp_localize_script('fifu-video-js', 'fifuVideoVars', [
                'fifu_is_flatsome_active' => $theme_detector_exists && Fifu_Theme_Detector::is_flatsome_active(),
                'fifu_is_photolio_active' => $theme_detector_exists && Fifu_Theme_Detector::is_photolio_active(),
                'fifu_is_content_views_pro_active' => $plugin_detector_exists && Fifu_Plugin_Detector::is_content_views_pro_active(),
                'fifu_is_home' => (is_home() || (class_exists('WooCommerce') && is_shop()) || is_archive() || is_search()),
                'fifu_is_shop' => Fifu_Woocommerce_Context::is_shop(),
                'fifu_is_product_category' => class_exists('WooCommerce') && is_product_category(),
                'fifu_is_page' => is_page(),
                'fifu_is_post' => is_singular('post'),
                'fifu_video_thumb_display_home' => Fifu_Video_Thumbnail_Policy::should_display_on_home_context(),
                'fifu_video_thumb_display_page' => Fifu_Video_Thumbnail_Policy::should_display_on_page(),
                'fifu_video_thumb_display_post' => Fifu_Video_Thumbnail_Policy::should_display_on_post(),
                'fifu_video_thumb_display_cpt' => Fifu_Video_Thumbnail_Policy::should_display_on_cpt(),
                'fifu_video_min_width' => get_option('fifu_video_min_width'),
                'fifu_is_home_or_shop' => Fifu_Woocommerce_Context::is_home_or_shop(),
                'fifu_is_front_page' => is_front_page(),
                'fifu_video_controls' => Fifu_Options_Utils::is_on('fifu_video_controls'),
                'fifu_mouse_video_enabled' => Fifu_Video_Configuration::is_mouse_enabled(),
                'fifu_loop_enabled' => Fifu_Video_Configuration::is_loop_enabled(),
                'fifu_autoplay_enabled' => Fifu_Video_Configuration::is_autoplay_enabled(),
                'fifu_autoplay_front_enabled' => Fifu_Video_Configuration::is_autoplay_front_enabled(),
                'fifu_autoplay_front_all_enabled' => Fifu_Video_Configuration::is_autoplay_front_all_enabled(),
                'fifu_autoplay_elsewhere_enabled' => Fifu_Video_Configuration::is_autoplay_elsewhere_enabled(),
                'fifu_video_mute_enabled' => Fifu_Video_Configuration::is_muted(),
                'fifu_video_mute_mobile_enabled' => Fifu_Video_Configuration::is_muted_on_mobile(),
                'fifu_video_background_enabled' => Fifu_Video_Configuration::is_background_enabled(),
                'fifu_video_background_single_enabled' => Fifu_Options_Utils::is_on('fifu_video_background_single'),
                'fifu_video_gallery_icon_enabled' => Fifu_Options_Utils::is_on('fifu_video_gallery_icon'),
                'fifu_is_elementor_active' => $plugin_detector_exists && Fifu_Plugin_Detector::is_elementor_active(),
                'fifu_woocommerce' => class_exists('WooCommerce'),
                'fifu_is_divi_active' => Fifu_Theme_Detector::is_divi_active(),
                'fifu_essential_grid_active' => $plugin_detector_exists && Fifu_Plugin_Detector::is_essential_grid_active(),
                'fifu_is_product' => class_exists('WooCommerce') && is_product(),
                'fifu_adaptive_height' => Fifu_Options_Utils::is_on('fifu_adaptive_height'),
                'fifu_play_button_enabled' => Fifu_Options_Utils::is_on('fifu_video_play_button'),
                'fifu_play_hide_grid' => Fifu_Options_Utils::is_on('fifu_video_play_hide_grid'),
                'fifu_play_hide_grid_wc' => Fifu_Options_Utils::is_on('fifu_video_play_hide_grid_wc'),
                'fifu_url' => Fifu_Post_Main_Image_Resolver::get_main_image_url((int) get_queried_object_id(), true),
                'fifu_is_play_type_inline' => get_option('fifu_play_type') == 'inline',
                'fifu_is_play_type_lightbox' => get_option('fifu_play_type') == 'lightbox',
                'fifu_video_color' => get_option('fifu_video_color'),
                'fifu_video_zindex' => get_option('fifu_video_zindex'),
                'fifu_should_hide' => Fifu_Image_Display_Policy::should_hide_featured_media(),
                'fifu_should_wait_ajax' => Fifu_Yith_Wishlist_Integration::should_wait_for_ajax(),
                'fifu_is_mobile' => wp_is_mobile(),
                'fifu_privacy_enabled' => Fifu_Options_Utils::is_on('fifu_video_privacy'),
                'fifu_later_enabled' => Fifu_Options_Utils::is_on('fifu_video_later'),
                'fifu_woo_lbox_enabled' => Fifu_Woocommerce_Display_Configuration::is_lightbox_enabled(),
                'text_later' => $strings['button']['later'](),
                'text_queue' => $strings['button']['queue'](),
                'restUrl' => esc_url_raw(rest_url()),
                'session' => md5(session_id()),
                'uploadDir' => Fifu_Upload_Dir_Utils::get_upload_dir(),
                'otfcdn' => Fifu_Options_Utils::is_on('fifu_otfcdn'),
            ]);
        }

        if (Fifu_Options_Utils::is_on('fifu_video_later')) {
            wp_enqueue_script('fifu-cookie', 'https://cdnjs.cloudflare.com/ajax/libs/js-cookie/latest/js.cookie.min.js');
            wp_enqueue_script('fifu-watch-later-js', plugins_url('/includes/html/js/watch-later.js', FIFU_PLUGIN_FILE), array('jquery', 'fifu-cookie'), Fifu_Plugin_Info::get_enqueue_version());
            wp_localize_script('fifu-watch-later-js', 'fifuLgVars', [
                'fifu_key_lightgallery' => get_option('fifu_key_lightgallery'),
            ]);
            if (!wp_script_is('fancy-box-js')) {
                wp_enqueue_style('fancy-box-css', 'https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.css');
                wp_enqueue_script('fancy-box-js', 'https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js');
            }
            Fifu_Lightgallery_Integration::enqueue_assets(false);
        }
    }
}
