<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

final class Fifu_Remote_Media_Renderer
{
    /**
     * Starts buffering remote media replacements.
     */
    public static function start_buffer(): void
    {
        ob_start([self::class, 'filter_buffer']);
    }

    /**
     * Filters the output buffer for remote media tags.
     */
    public static function filter_buffer(string $buffer): string
    {
        global $FIFU_SESSION;

        
            if (empty($buffer))
                return $buffer;
        
            /* plugins: Oxygen, Bricks */
            if (isset($_REQUEST['ct_builder']) || isset($_REQUEST['bricks']) || isset($_REQUEST['fb-edit']))
                return $buffer;
        
            /* img */
        
            $buffer = Fifu_Social_Meta_Filter::filter_og_images($buffer);
        
            $srcType = "src";
            $imgList = array();
            $queried_object_id = (int) get_queried_object_id();
            $current_featured_preload_url = null;
            $current_featured_image_has_high_priority = false;

            preg_match_all('/<img[^>]*>/', $buffer, $imgList);
        
            foreach (($imgList[0] ?? []) as $imgItem) {
                preg_match('/(' . $srcType . ')([^\'\"]*[\'\"]){2}/', $imgItem, $src);
                if (!$src)
                    continue;
                $del = substr($src[0] ?? '', - 1);
                $url = Fifu_Html_Attribute_Utils::normalize(explode($del, $src[0] ?? '')[1] ?? '');
                $post_id = null;

                // get parameters
                $data = null;
                $prev_url = Fifu_Video_Helper::resolve_original_video_thumb_url($url);

                if (isset($FIFU_SESSION[$url])) {
                    $data = $FIFU_SESSION[$url];
                } elseif ($prev_url && isset($FIFU_SESSION[$prev_url])) {
                    $data = $FIFU_SESSION[$prev_url];
                }
        
                if (!$data)
                    continue;

                $is_replaced = strpos($imgItem, 'fifu-replaced') !== false;
        
                if ($data['local'] ?? false)
                    continue;
        
                $post_id = $data['post_id'] ?? null;
                $att_id = $data['att_id'] ?? null;
                $type = $data['type'] ?? null;
                $featured = $data['featured'] ?? null;
                $gallery = $data['gallery'] ?? null;
                $is_category = $data['category'] ?? false;
                $theme_width = $data['theme-width'] ?? null;
                $theme_height = $data['theme-height'] ?? null;
                $post_id_int = $post_id ? (int) $post_id : 0;

                $is_current_featured_image =
                    $featured
                    && is_single()
                    && $post_id_int > 0
                    && $post_id_int === $queried_object_id;

                if ($is_current_featured_image) {
                    $has_high_fetchpriority =
                        preg_match(
                            '/\bfetchpriority\s*=\s*(["\'])high\1/i',
                            $imgItem
                        ) === 1;

                    if ($has_high_fetchpriority) {
                        $current_featured_image_has_high_priority = true;
                        $current_featured_preload_url = null;
                    } elseif (
                        !$current_featured_image_has_high_priority
                        && $current_featured_preload_url === null
                    ) {
                        $current_featured_preload_url = $url;
                    }
                }

                if ($is_replaced)
                    continue;

                $has_video_thumb =
                    Fifu_Video_Helper::is_video_thumb($url)
                    || Fifu_Video_Helper::is_suvideo_thumbnail($url)
                    || Fifu_Video_Helper::is_video_thumb($prev_url)
                    || Fifu_Video_Helper::is_video_thumb(Fifu_Pubcdn_Url_Service::decode_pubcdn_url($url));
                $custom_video_url = $post_id_int ? Fifu_Post_Custom_Video_Read_Service::get_custom_video_url($post_id_int) : null;
                $audio_url = ($post_id_int && $featured) ? Fifu_Post_Audio_Read_Service::get_audio_url($post_id_int) : null;
                $should_mark_as_video =
                    ($has_video_thumb || $custom_video_url || $audio_url)
                    && Fifu_Options_Utils::is_on('fifu_video');

                // video
                if ($should_mark_as_video) {
                        // add video class
                        if (strpos($imgItem, 'class=') !== false)
                            $newImgItem = str_replace(' class=' . $del, ' class=' . $del . 'fifu-video ', $imgItem);
                        else
                            $newImgItem = str_replace('<img ', '<img class=' . $del . 'fifu-video' . $del . ' ', $imgItem);
        
                        // add featured
                        if ($featured)
                            $newImgItem = str_replace('<img ', '<img fifu-featured="1" ', $newImgItem);
        
                        // add status
                        $newImgItem = str_replace('<img ', '<img fifu-replaced="1" ', $newImgItem);
        
                        // speed up
                        if (Fifu_Speedup_Url_Service::is_speedup_url($url)) {
                            $newImgItem = str_replace('<img ', '<img srcset="' . Fifu_Speedup_Url_Service::get_srcset($url) . '" ', $newImgItem);
                            $newImgItem = str_replace('<img ', '<img sizes="(max-width:' . $theme_width . 'px) 100vw, ' . $theme_width . 'px" ', $newImgItem);
                        }
        
                        // submit
                        $buffer = str_replace($imgItem, $newImgItem, $buffer);
                } else {
                    // slider
                    if ($type == 'slider') {
                        if (
                            (Fifu_Theme_Detector::is_houzez_active() || Fifu_Theme_Detector::is_wpresidence_active())
                            && Fifu_Options_Utils::is_on('fifu_photon')
                        ) {
                            $photon_url = Fifu_Jetpack_Cdn_Service::build_photon_url($url, null, $att_id);
                            $srcset = Fifu_Jetpack_Cdn_Service::build_srcset($photon_url, true);
                            $newImgItem = str_replace('<img ', '<img srcset="' . $srcset . '" ', $imgItem);
                            $buffer = str_replace($imgItem, Fifu_Featured_Image_Filter::filter_post_thumbnail_html($newImgItem, $post_id, null, null, null), $buffer);
                            continue;
                        } else {
                            if (strpos($imgItem, 'fifu-grid-img') !== false)
                                continue;
        
                            if (is_singular('product') && $featured)
                                continue;
        
                            $slider_url = Fifu_Post_Slider_Image_Url_Read_Service::get_slider_image_url(
                                (int) $post_id,
                                0
                            );
                            if (Fifu_Jetpack_Cdn_Service::is_jetpack_cdn_url($url)) {
                                $aux = explode('//', $slider_url)[1] ?? '';
                                if (strpos($url, $aux) === false)
                                    continue;
                            } elseif ($url != $slider_url)
                                continue;
                        }
                    }
        
                    if ($featured) {
                        // add featured
                        $newImgItem = str_replace('<img ', '<img fifu-featured="' . $featured . '" ', $imgItem);
        
                        // add category
                        if ($is_category)
                            $newImgItem = str_replace('<img ', '<img fifu-category="1" ', $newImgItem);
        
                        // add post_id
                        if (get_post_type($post_id) == 'product')
                            $newImgItem = str_replace('<img ', '<img product-id="' . $post_id . '" ', $newImgItem);
                        else
                            $newImgItem = str_replace('<img ', '<img post-id="' . $post_id . '" ', $newImgItem);
        
                        // add theme sizes
                        if ($theme_width && $theme_height) {
                            $newImgItem = str_replace('<img ', '<img theme-width="' . $theme_width . '" ', $newImgItem);
                            $newImgItem = str_replace('<img ', '<img theme-height="' . $theme_height . '" ', $newImgItem);
                        }
        
                        // speed up (doesn't work with ajax calls)
                        if (Fifu_Speedup_Url_Service::is_speedup_url($url)) {
                            $newImgItem = str_replace('<img ', '<img srcset="' . Fifu_Speedup_Url_Service::get_srcset($url) . '" ', $newImgItem);
                            $newImgItem = str_replace('<img ', '<img sizes="(max-width:' . $theme_width . 'px) 100vw, ' . $theme_width . 'px" ', $newImgItem);
                        }
        
                        $buffer = str_replace($imgItem, Fifu_Featured_Image_Filter::filter_post_thumbnail_html($newImgItem, $post_id, null, null, null), $buffer);
                    }
                }
            }

            if (
                !$current_featured_image_has_high_priority
                && $current_featured_preload_url !== null
            ) {
                $preload = sprintf(
                    '<link rel="preload" as="image" href="%s" fetchpriority="high">',
                    esc_url($current_featured_preload_url)
                );

                $buffer = str_replace(
                    '</head>',
                    $preload . "</head>\n",
                    $buffer
                );
            }
        
            /* background-image */
        
            $imgList = array();
            preg_match_all('/<[^>]*background-image[^>]*>/', $buffer, $imgList);
            foreach (($imgList[0] ?? []) as $imgItem) {
                if (strpos($imgItem, 'style=') === false || strpos($imgItem, 'url(') === false)
                    continue;
        
                $mainDelimiter = substr(explode('style=', str_replace('\\', '', $imgItem))[1] ?? '', 0, 1);
                $subDelimiter = substr(explode('url(', str_replace('\\', '', $imgItem))[1] ?? '', 0, 1);
                if (in_array($subDelimiter, array('"', "'", ' ')))
                    $url = preg_split('/[\'\" ]{1}\)/', preg_split('/url\([\'\" ]{1}/', $imgItem, -1)[1] ?? '', -1)[0] ?? '';
                else {
                    $url = preg_split('/\)/', preg_split('/url\(/', $imgItem, -1)[1] ?? '', -1)[0] ?? '';
                    $subDelimiter = '';
                }
        
                $newImgItem = $imgItem;
        
                $url = Fifu_Html_Attribute_Utils::normalize($url);
                if (isset($FIFU_SESSION[$url])) {
                    $data = $FIFU_SESSION[$url];
        
                    if (strpos($imgItem, 'fifu-replaced') !== false)
                        continue;
        
                    if ($data['local'] ?? false)
                        continue;
        
                    $att_id = $data['att_id'] ?? null;
        
                    $post_id = $data['post_id'] ?? null;
                    $newImgItem = str_replace('>', ' ' . 'post-id="' . $post_id . '">', $newImgItem);
                }
        
                if ($newImgItem != $imgItem)
                    $buffer = str_replace($imgItem, $newImgItem, $buffer);
            }
        
            return $buffer;
    }

}
