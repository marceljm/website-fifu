<?php

defined( 'ABSPATH' ) || exit;

/**
 * Injects FIFU media variables into the frontend footer scripts.
 */
class Fifu_Frontend_Media_Export {

    private static bool $testFooterOutputEnabled = false;

    public static function set_test_footer_output_enabled(bool $enabled): void
    {
        self::$testFooterOutputEnabled = $enabled;
    }

    /**
     * Outputs the FIFU media configuration in the footer.
     */
    public static function inject_footer_json(): void {
        global $FIFU_SESSION;
        $should_output_scripts = self::should_output_footer_scripts();
        $thumbs = self::build_lookup_map( isset( $FIFU_SESSION['fifu-video'] ) && is_array( $FIFU_SESSION['fifu-video'] ) ? $FIFU_SESSION['fifu-video'] : array() );
        $audios = self::build_lookup_map( isset( $FIFU_SESSION['fifu-audio'] ) && is_array( $FIFU_SESSION['fifu-audio'] ) ? $FIFU_SESSION['fifu-audio'] : array() );
        $cdn_map = self::build_cdn_map( isset( $FIFU_SESSION['cdn-new-old'] ) && is_array( $FIFU_SESSION['cdn-new-old'] ) ? $FIFU_SESSION['cdn-new-old'] : array() );
        $custom_videos = self::build_lookup_map( isset( $FIFU_SESSION['fifu-custom-video'] ) && is_array( $FIFU_SESSION['fifu-custom-video'] ) ? $FIFU_SESSION['fifu-custom-video'] : array() );
        $permalinks = self::build_lookup_map( isset( $FIFU_SESSION['fifu-permalink'] ) && is_array( $FIFU_SESSION['fifu-permalink'] ) ? $FIFU_SESSION['fifu-permalink'] : array() );

        if ( $should_output_scripts && isset( $FIFU_SESSION['fifu-video'] ) ) {
            $arr = json_encode( $thumbs );
            echo "<script>var fifuVideoThumbVarsFooter = {$arr};</script>";
        }

        if ( $should_output_scripts && isset( $FIFU_SESSION['fifu-audio'] ) ) {
            $arr = json_encode( $FIFU_SESSION['fifu-audio'] );
            echo "<script>var fifuAudioVarsFooter = {$arr};</script>";
        }

        if ( $should_output_scripts && isset( $FIFU_SESSION['fifu-redirection'] ) ) {
            $arr = json_encode( $FIFU_SESSION['fifu-redirection'] );
            echo "<script>var fifuRedirectionVarsFooter = {$arr};</script>";
        }

        if ( Fifu_Options_Utils::is_on( 'fifu_video' ) ) {
            wp_enqueue_script( 'fifu-video-thumb-js', plugins_url( '/includes/html/js/thumb-video.js', FIFU_PLUGIN_FILE ), array( 'jquery' ), Fifu_Plugin_Info::get_enqueue_version() );
            wp_localize_script( 'fifu-video-thumb-js', 'fifuVideoThumbVars', array(
                'thumbs' => $thumbs,
                'audios' => $audios,
                'cdn' => $cdn_map,
                'customvideos' => $custom_videos,
                'permalinks' => $permalinks,
                'fifu_photon' => Fifu_Options_Utils::is_on( 'fifu_photon' ),
            ) );
        }
    }

    /**
     * Adds canonical lookup aliases for thumbnail-related maps.
     *
     * @param array<string,mixed> $map
     * @return array<string,mixed>
     */
    private static function build_lookup_map( array $map ): array
    {
        $normalized = $map;
        foreach ( $map as $key => $value ) {
            if ( ! is_string( $key ) ) {
                continue;
            }

            $canonical_key = Fifu_Video_Helper::canonicalize_video_thumb_lookup_url( $key );
            if ( is_string( $canonical_key ) && $canonical_key !== '' && ! array_key_exists( $canonical_key, $normalized ) ) {
                $normalized[ $canonical_key ] = $value;
            }
        }

        return $normalized;
    }

    /**
     * Canonicalizes the original target of Cloud/CDN mappings before export.
     *
     * @param array<string,string> $map
     * @return array<string,string>
     */
    private static function build_cdn_map( array $map ): array
    {
        $normalized = array();
        foreach ( $map as $new_url => $old_url ) {
            if ( ! is_string( $new_url ) || ! is_string( $old_url ) ) {
                continue;
            }

            $normalized[ $new_url ] = Fifu_Video_Helper::canonicalize_video_thumb_lookup_url( $old_url ) ?? $old_url;
        }

        return $normalized;
    }

    private static function should_output_footer_scripts(): bool
    {
        if ( ! defined( 'PHPUNIT_RUNNING' ) || ! PHPUNIT_RUNNING ) {
            return true;
        }

        return self::$testFooterOutputEnabled;
    }
}
