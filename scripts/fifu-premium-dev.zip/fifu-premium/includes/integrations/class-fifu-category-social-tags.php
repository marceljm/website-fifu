<?php

defined( 'ABSPATH' ) || exit;

/**
 * Prepares future social tag rendering for term archives.
 */
class Fifu_Category_Social_Tags {

    /**
     * Future: renders social image tags for a category archive.
     */
    public static function render_category_social_tags(): void {
        $url   = self::get_image_url();
        $title = single_cat_title( '', false );

        $term_id = self::get_term_id();
        if ( $term_id ) {
            $description = wp_strip_all_tags( category_description( $term_id ) );
        }
    }

    /**
     * Future: renders social video tags for a category archive.
     */
    public static function render_video_category_social_tags(): void {
        if ( Fifu_Options_Utils::is_off( 'fifu_video' ) ) {
            return;
        }

        $url   = self::get_video_url();
        $title = single_cat_title( '', false );

        $term_id = self::get_term_id();
        if ( $term_id ) {
            $description = wp_strip_all_tags( category_description( $term_id ) );
        }

        if ( empty( $url ) ) {
            return;
        }

        $video_id  = Fifu_Video_Helper::get_video_id( $url );
        $video_src = Fifu_Video_Helper::get_embed_url( $url );
        $video_img = Fifu_Video_Helper::get_thumbnail_large( $url );
        $video_url = $url;

        include FIFU_INCLUDES_DIR . '/html/social-video.html';
    }

    /**
     * Future: obtains the current category term ID.
     */
    public static function get_term_id(): ?int {
        global $wp_query;
        if ( ! isset( $wp_query ) ) {
            return null;
        }
        return $wp_query->get_queried_object_id() ?? null;
    }

    /**
     * Future: returns the category image URL.
     */
    public static function get_image_url( ?int $term_id = null ): ?string {
        $term_id = $term_id ?: self::get_term_id();
        if ( ! $term_id ) {
            return null;
        }
        return Fifu_Term_Image_Url_Read_Service::get_image_url((int) $term_id);
    }

    /**
     * Future: returns the category video URL.
     */
    public static function get_video_url( ?int $term_id = null ): ?string {
        $term_id = $term_id ?: self::get_term_id();
        if ( ! $term_id ) {
            return null;
        }
        return Fifu_Term_Video_Read_Service::get_video_url((int) $term_id);
    }

    /**
     * Future: returns the category image alt text.
     */
    public static function get_alt( ?int $term_id = null ): ?string {
        $term_id = $term_id ?: self::get_term_id();
        if ( ! $term_id ) {
            return null;
        }
        return Fifu_Term_Image_Alt_Read_Service::get_image_alt((int) $term_id);
    }
}
