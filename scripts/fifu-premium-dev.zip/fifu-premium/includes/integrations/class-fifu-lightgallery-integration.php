<?php

defined( 'ABSPATH' ) || exit;

/**
 * Integrates LightGallery assets with FIFU products.
 */
class Fifu_Lightgallery_Integration {

    /**
     * Enqueues LightGallery assets when needed.
     *
     * @param bool $is_product Whether the context is a product page.
     * @return void
     */
    public static function enqueue_assets( bool $is_product = false ): void {
        if ( wp_script_is( 'lightgallery', 'enqueued' ) || wp_script_is( 'lightgallery', 'done' ) ) {
            return;
        }

        wp_enqueue_style( 'lightgallery-thumb-style', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.8.3/css/lg-thumbnail.min.css' );
        wp_enqueue_script( 'lightgallery-thumb', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.8.3/plugins/thumbnail/lg-thumbnail.min.js' );
        if ( $is_product ) {
            wp_enqueue_style( 'lightgallery-zoom-style', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.8.3/css/lg-zoom.min.css' );
            wp_enqueue_script( 'lightgallery-zoom', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.8.3/plugins/zoom/lg-zoom.min.js' );
        }
        wp_enqueue_style( 'lightgallery-video-style', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.8.3/css/lg-video.min.css' );
        wp_enqueue_script( 'lightgallery-video', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.8.3/plugins/video/lg-video.min.js' );
        wp_enqueue_style( 'lightgallery-style', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.8.3/css/lightgallery.min.css' );
        wp_enqueue_script( 'lightgallery', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.8.3/lightgallery.min.js' );
    }
}
