<?php
declare(strict_types=1);

defined('ABSPATH') || exit;

final class Fifu_Taxonomy_Archive_Image_Filter
{
    public static function register_hooks(): void
    {
        add_filter('get_the_archive_description', [self::class, 'filter_archive_description']);
    }

    /**
     * Prepend an image to archive description for non-product_cat taxonomies.
     *
     * @param string $description
     * @return string
     */
    public static function filter_archive_description($description)
    {
        if (!is_string($description)) {
            return $description;
        }

        if (is_tax('product_cat')) {
            return $description;
        }

        $imageUrl = Fifu_Category_Social_Tags::get_image_url();
        if (empty($imageUrl)) {
            return $description;
        }

        $imageHtml = '<img src="' . esc_url($imageUrl) . '" alt="" style="max-width:100%; height:auto;">';

        return $imageHtml . $description;
    }
}
