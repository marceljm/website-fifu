<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('Fifu_Attachment_Update_Service', false)) {
    require_once __DIR__ . '/../../meta/class-fifu-attachment-update-service.php';
}

final class Fifu_Woocommerce_Variation_Attachment_Service {

    /**
     * Rebuilds all attachments and related meta for a WooCommerce product variation
     * based on external image and video URLs.
     *
     * @param int   $variation_id Variation post ID.
     * @param array $urls         List of image/video URLs.
     * @param array $alts         Optional list of alt texts.
     * @param bool  $is_slider    Whether this variation uses slider-specific meta keys.
     * @param array $video_urls   Optional list of video URLs to append/merge.
     *
     * @return void
     */
    public static function rebuild_variation_attachments(
        int $variation_id,
        array $urls,
        array $alts = [],
        bool $is_slider = false,
        array $video_urls = []
    ): void {
        $postMetaUpdater = FIFU_Post_Meta_Updater::instance();

        $variation_id = (int) $variation_id;
        $attachment_factory = new Fifu_Attachment_Factory();
        $attachment_repository = self::get_attachment_repository();
        $previous_attachment_ids = self::get_variation_attachment_ids($variation_id);

        $filtered_urls = array_values($urls);
        $filtered_alts = array_values($alts);
        $has_images = (bool) $filtered_urls;
        $video_urls = array_values($video_urls);

        if (empty($filtered_urls) && empty($video_urls)) {
            self::clear_variation_media_state($variation_id);
            self::delete_obsolete_variation_attachments($previous_attachment_ids, $variation_id);
            return;
        }

        $all_urls = $filtered_urls;
        foreach ($video_urls as $video_url) {
            $all_urls[] = $video_url;
        }

        $prepared = [];
        $i = 0;
        $video_i = $has_images ? 1 : 0;
        $featured_attachment_id = 0;
        $gallery_attachment_ids = [];
        $image_index = 0;

        foreach ($all_urls as $url) {
            $url = esc_url_raw(trim((string) $url));
            $alt = ($filtered_alts && count($filtered_alts) > $i)
                ? self::normalize_slider_alt_value($filtered_alts[$i])
                : '';

            $is_video_url = Fifu_Video_Helper::is_video($url);
            $image_url = $is_video_url ? Fifu_Video_Helper::get_thumbnail_large($url) : $url;

            $att_id = self::find_or_create_initialized_variation_attachment(
                $attachment_repository,
                $attachment_factory,
                $variation_id,
                $image_url,
                $alt
            );
            if ($att_id === null) {
                // Keep the currently published state intact until every requested
                // replacement has a valid remote file record.
                return;
            }

            $prepared[] = [
                'id' => $att_id,
                'url' => $url,
                'alt' => $alt,
                'is_video' => $is_video_url,
                'is_slider' => $is_slider,
                'index' => $i,
                'video_index' => $video_i,
            ];

            if (!$is_video_url && $image_index === 0) {
                $featured_attachment_id = $att_id;
            } elseif (!$is_video_url) {
                $gallery_attachment_ids[] = $att_id;
            } elseif ($has_images) {
                $gallery_attachment_ids[] = $att_id;
            }

            $i++;
            if ($is_video_url) {
                $video_i++;
            } else {
                $image_index++;
            }
        }

        // Replacement preparation succeeded. Publish the complete new state,
        // then remove obsolete attachments after references point at the new IDs.
        self::clear_variation_plugin_meta($variation_id);
        if (function_exists('fifu_db2_write_service')) {
            $write_service = fifu_db2_write_service();
            if ($write_service instanceof Fifu_Db2_Write_Service) {
                $write_service->delete_post_all_mappings($variation_id);
            }
        }

        foreach ($prepared as $item) {
            $url = (string) $item['url'];
            $alt = (string) $item['alt'];
            $index = (int) $item['index'];
            $video_index = (int) $item['video_index'];
            $is_video_url = (bool) $item['is_video'];

            if ($is_slider) {
                $meta_key_url = "fifu_slider_image_url_{$index}";
                $meta_key_alt = "fifu_slider_image_alt_{$index}";
            } elseif ($is_video_url) {
                $meta_key_url = 'fifu_video_url' . ($video_index === 0 ? '' : '_' . ($video_index - 1));
                $meta_key_alt = null;
            } else {
                $meta_key_url = 'fifu_image_url' . ($index === 0 ? '' : '_' . ($index - 1));
                $meta_key_alt = 'fifu_image_alt' . ($index === 0 ? '' : '_' . ($index - 1));
            }
            $postMetaUpdater->update_or_delete($variation_id, $meta_key_url, $url);
            if ($meta_key_alt !== null) {
                $postMetaUpdater->update_or_delete_value($variation_id, $meta_key_alt, $alt);
            }
        }

        if ($featured_attachment_id > 0) {
            update_post_meta($variation_id, '_thumbnail_id', $featured_attachment_id);
        } else {
            delete_post_meta($variation_id, '_thumbnail_id');
        }
        self::persist_gallery_meta($variation_id, $gallery_attachment_ids);
        self::delete_obsolete_variation_attachments($previous_attachment_ids, $variation_id);
    }

    /**
     * Persist gallery metadata for a variation while keeping attachment order stable.
     *
     * @param int   $variation_id  Variation post ID.
     * @param array $attachment_ids Attachment IDs to persist.
     *
     * @return void
     */
    private static function persist_gallery_meta(int $variation_id, array $attachment_ids): void
    {
        $thumbnail_id = (int) get_post_meta($variation_id, '_thumbnail_id', true);
        $attachment_ids = array_values(array_unique(array_filter(
            array_map('intval', $attachment_ids),
            static fn (int $id): bool => $id > 0 && $id !== $thumbnail_id
        )));

        if ($attachment_ids !== []) {
            $csv = implode(',', $attachment_ids);
            update_post_meta($variation_id, '_product_image_gallery', $csv);
            update_post_meta($variation_id, '_wc_additional_variation_images', $csv);
            return;
        }

        delete_post_meta($variation_id, '_product_image_gallery');
        delete_post_meta($variation_id, '_wc_additional_variation_images');
    }

    /**
     * @param mixed $value
     */
    private static function normalize_slider_alt_value($value): string
    {
        if ($value === null) {
            return '';
        }

        $normalized = trim((string) $value);
        $normalizedLower = strtolower($normalized);
        if (
            $normalizedLower === ''
            || $normalizedLower === 'null'
            || $normalizedLower === 'undefined'
            || $normalizedLower === 'http://null'
            || $normalizedLower === 'https://null'
        ) {
            return '';
        }

        return wp_strip_all_tags($normalized);
    }


    /**
     * Synchronizes _wc_additional_variation_images based on the
     * _product_image_gallery meta for all variation products of a given parent product.
     *
     * @param int $product_id Parent product ID.
     *
     * @return void
     */
    public static function sync_additional_variation_images($product_id): void {
        $product_id = is_numeric($product_id) ? (int) $product_id : 0;

        if ($product_id <= 0) {
            return;
        }

        wp_cache_flush();

        $attachment_repository = self::get_attachment_repository();
        foreach ($attachment_repository->get_variation_products($product_id) as $variation) {
            $gallery_ids = get_post_meta($variation->id, '_product_image_gallery', true);
            if ($gallery_ids) {
                update_post_meta($variation->id, '_wc_additional_variation_images', $gallery_ids);
                continue;
            }

            $additional_ids = get_post_meta($variation->id, '_wc_additional_variation_images');
            if (!$additional_ids) {
                continue;
            }

            $item_ids = array_values(array_filter(array_map(
                static function ($id): int {
                    return (int) trim((string) $id);
                },
                explode(',', (string) $additional_ids[0])
            ), static fn (int $id): bool => $id > 0));

            $valid_ids = [];
            foreach ($item_ids as $id) {
                if (get_post($id) === null) {
                    continue;
                }
                $valid_ids[] = $id;
            }

            if ($valid_ids === []) {
                delete_post_meta($variation->id, '_wc_additional_variation_images');
                continue;
            }

            update_post_meta($variation->id, '_wc_additional_variation_images', implode(',', $valid_ids));
        }
    }

    /**
     * Creates real attachments for products that have external gallery URLs
     * but no corresponding local media, and rebuilds gallery meta fields.
     *
     * @return void
     */
    public static function backfill_external_galleries(): void {
        $meta_gap_repository = self::get_meta_gap_repository();
        $gallery_repository = self::get_product_gallery_repository();
        $attachment_factory = new Fifu_Attachment_Factory();
        $attachment_repository = self::get_attachment_repository();

        foreach ($meta_gap_repository->get_posts_with_external_gallery_without_meta() as $res) {
            $post_id = (int) $res->post_id;
            $attachment_ids = [];
            $failed = false;

            foreach ($gallery_repository->get_gallery_urls($post_id) as $gallery_record) {
                $url = (string) ($gallery_record->url ?? $gallery_record->meta_value ?? '');
                $url = Fifu_Video_Helper::is_video($url) ? Fifu_Video_Helper::get_thumbnail_large($url) : $url;
                $url = trim(htmlspecialchars_decode($url));
                $att_id = self::find_or_create_initialized_variation_attachment(
                    $attachment_repository,
                    $attachment_factory,
                    $post_id,
                    $url,
                    ''
                );
                if ($att_id === null) {
                    $failed = true;
                    break;
                }
                $attachment_ids[] = $att_id;
            }

            if ($failed) {
                continue;
            }

            $attachment_ids = array_values(array_filter(
                array_unique(array_map('intval', $attachment_ids)),
                static fn (int $attachment_id): bool => $attachment_id > 0
            ));
            if ($attachment_ids === []) {
                continue;
            }

            $ids = implode(',', $attachment_ids);
            update_post_meta($post_id, '_product_image_gallery', $ids);
            if (get_post_type($post_id) === 'product_variation') {
                update_post_meta($post_id, '_wc_additional_variation_images', $ids);
            }
        }
    }

    /**
     * Remove existing FIFU attachments and metadata for the variation.
     *
     * @param int $variation_id Variation post ID.
     *
     * @return void
     */
    private static function clean_variation_attachments(int $variation_id): void {
        $attachment_ids = self::get_variation_attachment_ids($variation_id);
        self::clear_variation_media_state($variation_id);
        self::delete_obsolete_variation_attachments($attachment_ids, $variation_id);
    }

    private static function clear_variation_media_state(int $variation_id): void
    {
        delete_post_meta($variation_id, '_product_image_gallery');
        delete_post_meta($variation_id, '_wc_additional_variation_images');
        delete_post_meta($variation_id, '_thumbnail_id');
        self::clear_variation_plugin_meta($variation_id);

        if (function_exists('fifu_db2_write_service')) {
            $write_service = fifu_db2_write_service();
            if ($write_service instanceof Fifu_Db2_Write_Service) {
                $write_service->delete_post_all_mappings($variation_id);
            }
        }

        clean_post_cache($variation_id);
        wp_cache_delete($variation_id, 'post_meta');
    }

    private static function clear_variation_plugin_meta(int $variation_id): void
    {
        global $wpdb;
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key LIKE %s",
            $variation_id,
            'fifu_%'
        ));
        clean_post_cache($variation_id);
        wp_cache_delete($variation_id, 'post_meta');
    }

    private static function find_or_create_initialized_variation_attachment(
        Fifu_Attachment_Repository $repository,
        Fifu_Attachment_Factory $factory,
        int $variation_id,
        string $url,
        string $alt
    ): ?int {
        $url = trim(htmlspecialchars_decode($url));
        if ($url === '' || !Fifu_Attachment_Update_Service::is_valid_remote_attachment_url($url)) {
            return null;
        }

        $attachment_id = $repository->find_attachment_id($variation_id, $url, false);
        if ($attachment_id <= 0) {
            $attachment_id = $repository->find_incomplete_attachment_id($variation_id, $url, false) ?? 0;
        }
        if ($attachment_id <= 0) {
            $attachment_id = $factory->create_attachment_for_url($url, $alt, $variation_id);
        }

        $attachment = get_post($attachment_id);
        if (
            $attachment_id <= 0
            || !$attachment
            || $attachment->post_type !== 'attachment'
            || (int) $attachment->post_parent !== $variation_id
            || !Fifu_Attachment_Update_Service::is_fifu_owned($attachment_id)
            || strpos((string) $attachment->post_name, 'fifu-category-') === 0
        ) {
            return null;
        }

        $attached_file = trim(htmlspecialchars_decode((string) get_post_meta($attachment_id, '_wp_attached_file', true)));
        $content_filtered = trim(htmlspecialchars_decode((string) $attachment->post_content_filtered));
        if (
            ($attached_file !== '' && (
                !Fifu_Attachment_Update_Service::is_valid_remote_attachment_url($attached_file)
                || $attached_file !== $url
            ))
            || ($content_filtered !== '' && (
                !Fifu_Attachment_Update_Service::is_valid_remote_attachment_url($content_filtered)
                || $content_filtered !== $url
            ))
        ) {
            return null;
        }

        if (!Fifu_Attachment_Update_Service::can_initialize_remote_attachment($attachment_id, $url)) {
            return null;
        }

        Fifu_Attachment_Update_Service::initialize_remote_attachment($attachment_id, $url, $alt, null, null, true);
        if (!Fifu_Attachment_Update_Service::has_remote_file_metadata($attachment_id, $url)) {
            return null;
        }

        return $attachment_id;
    }

    private static function delete_obsolete_variation_attachments(array $attachment_ids, int $variation_id): void
    {
        $attachment_ids = array_values(array_unique(array_filter(array_map('intval', $attachment_ids))));
        if ($attachment_ids === []) {
            return;
        }

        $repository = self::get_attachment_repository();
        $referenced_ids = $repository->get_referenced_attachment_ids($attachment_ids);
        $default_attachment_id = (int) get_option('fifu_default_attach_id');
        $blank_virtual_ids = [];
        $cleanup = new Fifu_Local_Media_Cleanup();

        foreach ($attachment_ids as $attachment_id) {
            $attachment = get_post($attachment_id);
            if (
                $attachment_id === $default_attachment_id
                || in_array($attachment_id, $referenced_ids, true)
                || !$attachment
                || $attachment->post_type !== 'attachment'
                || (int) $attachment->post_parent !== $variation_id
                || !Fifu_Attachment_Update_Service::is_fifu_owned($attachment_id)
            ) {
                continue;
            }

            $attached_file = trim(htmlspecialchars_decode((string) get_post_meta($attachment_id, '_wp_attached_file', true)));
            $content_filtered = trim(htmlspecialchars_decode((string) $attachment->post_content_filtered));
            if ($attached_file === '' && $content_filtered === '') {
                $blank_virtual_ids[] = $attachment_id;
                continue;
            }

            if (Fifu_Attachment_Update_Service::is_safe_to_delete_remote_attachment($attachment_id)) {
                $cleanup->delete_attachments_and_meta([$attachment_id]);
            }
        }

        if ($blank_virtual_ids !== []) {
            $cleanup->delete_blank_virtual_attachments($blank_virtual_ids);
        }
    }

    /**
     * @return int[]
     */
    private static function get_variation_attachment_ids(int $variation_id): array {
        $ids = [];

        $thumbnail_id = absint((string) get_post_meta($variation_id, '_thumbnail_id', true));
        if ($thumbnail_id > 0) {
            $ids[] = $thumbnail_id;
        }

        foreach (['_product_image_gallery', '_wc_additional_variation_images'] as $meta_key) {
            $raw_value = trim((string) get_post_meta($variation_id, $meta_key, true));
            if ($raw_value === '') {
                continue;
            }

            foreach (explode(',', $raw_value) as $candidate) {
                $candidate_id = absint(trim((string) $candidate));
                if ($candidate_id > 0) {
                    $ids[] = $candidate_id;
                }
            }
        }

        return array_values(array_unique($ids));
    }

    /**
     * @return Fifu_Attachment_Repository
     */
    private static function get_attachment_repository(): Fifu_Attachment_Repository {
        return new Fifu_Attachment_Repository();
    }

    /**
     * @return Fifu_Meta_Gap_Repository
     */
    private static function get_meta_gap_repository(): Fifu_Meta_Gap_Repository {
        return new Fifu_Meta_Gap_Repository();
    }

    /**
     * @return Fifu_Product_Gallery_Repository
     */
    private static function get_product_gallery_repository(): Fifu_Product_Gallery_Repository {
        return new Fifu_Product_Gallery_Repository();
    }
}
