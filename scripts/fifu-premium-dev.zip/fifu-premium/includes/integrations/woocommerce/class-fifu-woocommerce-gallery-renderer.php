<?php

declare(strict_types=1);

defined('ABSPATH') || exit;

class Fifu_Woocommerce_Gallery_Renderer {

    /**
     * Future replacement for the legacy fifu_gallery_get_html() function.
     *
     * @param int         $post_id
     * @param string|null $original_class
     * @param string      $gallery_class
     * @param string|null $gallery_css
     * @param bool        $prioritize_first_image
     *
     * @return string
     */
    public static function render_product_gallery(
        int $post_id,
        ?string $original_class,
        string $gallery_class,
        ?string $gallery_css,
        bool $prioritize_first_image = false
    ): string {
        global $FIFU_SESSION;

        $provider_registry = Fifu_Video_Provider_Registry::instance();
        $amazon_provider = $provider_registry->get_provider_by_class( Fifu_Amazon_Video_Provider::class );
        $odysee_provider = $provider_registry->get_provider_by_class( Fifu_Odysee_Video_Provider::class );

        $gallery_repo = new Fifu_Product_Gallery_Repository();

        /* theme: Furnicom */
        if ( isset( $_GET['variation'] ) && is_scalar( $_GET['variation'] ) ) {
            $variation_id = absint( wp_unslash( $_GET['variation'] ) );

            if ( $variation_id > 0 ) {
                $post_id = $variation_id;
            }
        }

        $ratio = get_post_meta($post_id, 'fifu_slider_ratio', true);
        $ratio = $ratio ? 'fifu-ratio="' . $ratio . '"' : '';

        $class = "fifu " . $original_class;

        $attribute_map = array();
        $url_map = array();
        $source_url_map = array();
        $srcset_map = array();

        // variable products
        $variation_repo = new Fifu_Product_Variation_Meta_Repository();
        $attributes = $variation_repo->get_variation_attributes((int) $post_id);
        if ($attributes) {
            foreach ($attributes as $attribute) {
                if (!isset($attribute_map[$attribute->meta_key])) {
                    $attribute_map[$attribute->meta_key] = array();
                }
                if (!isset($attribute_map[$attribute->meta_key][$attribute->meta_value])) {
                    $attribute_map[$attribute->meta_key][$attribute->meta_value] = array();
                }
                array_push($attribute_map[$attribute->meta_key][$attribute->meta_value], $attribute->post_id);

                if (!isset($url_map[$attribute->post_id])) {
                    $variation_urls = self::get_variation_display_urls((int) $attribute->post_id, $gallery_repo);
                    if ($variation_urls) {
                        $url_map[$attribute->post_id] = $variation_urls;
                        $source_url_map[$attribute->post_id] = self::get_source_urls($variation_urls);
                    }
                }
            }
        }

        $gallery_css = $gallery_css ? 'style="' . $gallery_css . '"' : '';

        $html = sprintf('<div class="fifu-slider %s" id="fifu-slider-%s" %s %s>', $gallery_class, $post_id, $ratio, $gallery_css);
        if (Fifu_Options_Utils::is_on('fifu_slider_counter')) {
            $html = $html . '<div style="font-size:12px; padding:2px 5px 2px 5px; background:rgba(0, 0, 0, 0.3); z-index:50; position:absolute; color:white" id="counter-slider"></div>';
        }
        $initial_visibility_class = $prioritize_first_image
            ? 'fifu-product-gallery-initial-visible'
            : 'cS-hidden';

        $html .= sprintf(
            '<ul id="image-gallery" class="gallery list-unstyled %s fifu-product-gallery">',
            esc_attr($initial_visibility_class)
        );

        $att_id = get_post_meta($post_id, '_thumbnail_id', true);
        $original = Fifu_Image_Url_Utils::get_full_image_url($att_id);
        $url = $original;
        $url = Fifu_Jetpack_Cdn_Service::get_cdn_url($url, $att_id, null, null);
        $urls = $url ? array($url) : array();
        $image_urls = array();
        $video_urls = array();

        if ( $original && Fifu_Video_Helper::is_video_thumb( $original ) ) {
            $embed_url = Fifu_Video_Helper::get_embed_url_by_image( $original );
            if ( $embed_url ) {
                $FIFU_SESSION['fifu-video'][ $original ] = $embed_url;
                if ( $url && $url !== $original ) {
                    $FIFU_SESSION['fifu-video'][ $url ] = $embed_url;
                }
            }
        }

        $alt = Fifu_Post_Image_Alt_Read_Service::get_image_alt((int) $post_id);
        if (!$alt) {
            $alt = strip_tags(get_the_title($post_id));
        }

        $effectiveFeaturedMediaType = self::get_effective_featured_media_type((int) $post_id);

        // Resolve authoritative FIFU gallery records to the URLs represented by WooCommerce attachments.
        $authoritative_media_types = array();
        $authoritative_video_urls = array();
        foreach ($gallery_repo->get_gallery_urls((int) $post_id) as $gallery_item) {
            if (!is_object($gallery_item)) {
                continue;
            }

            $gallery_item_type = (string) ($gallery_item->type ?? $gallery_item->scope ?? '');
            $gallery_item_url = trim((string) ($gallery_item->url ?? $gallery_item->meta_value ?? ''));
            if ($gallery_item_url === '' || !in_array($gallery_item_type, ['image', 'video'], true)) {
                continue;
            }

            $rendered_url = $gallery_item_type === 'video'
                ? Fifu_Video_Helper::get_thumbnail_large($gallery_item_url)
                : $gallery_item_url;
            if (is_string($rendered_url) && $rendered_url !== '') {
                $authoritative_media_types[$rendered_url] = $gallery_item_type;
                if ($gallery_item_type === 'video') {
                    $authoritative_video_urls[$rendered_url] = $gallery_item_url;
                }
            }
        }

        $att_ids = get_post_meta($post_id, '_product_image_gallery', true);
        if ($att_ids) {
            $att_ids = array_filter(explode(',', $att_ids));
            foreach ($att_ids as $att_id) {
                $original = Fifu_Image_Url_Utils::get_full_image_url($att_id);
                $url = $original;
                $url = Fifu_Jetpack_Cdn_Service::get_cdn_url($url, $att_id, null, null);
                $authoritative_type = $authoritative_media_types[$original] ?? null;
                $is_video_thumbnail = $authoritative_type === 'video'
                    || ($authoritative_type === null && Fifu_Video_Helper::is_video_thumb($original));
                if ($is_video_thumbnail) {
                    if ( $url ) {
                        array_push($video_urls, $url);
                    }
                    $embed_url = Fifu_Video_Helper::get_embed_url_by_image($original);
                    if ( $embed_url ) {
                        $FIFU_SESSION['fifu-video'][$original] = $embed_url;
                        if ( $url && $url !== $original ) {
                            $FIFU_SESSION['fifu-video'][$url] = $embed_url;
                        }
                    }
                } else {
                    if ( $url ) {
                        array_push($image_urls, $url);
                    }
                }
            }
        }

        if ($effectiveFeaturedMediaType === 'image') {
            $urls = array_merge($urls, $image_urls, $video_urls);
        } elseif (in_array($effectiveFeaturedMediaType, ['video', 'custom_video'], true)) {
            $urls = array_merge($urls, $video_urls, $image_urls);
        } elseif (Fifu_Options_Utils::is_on("fifu_videos_before")) {
            $urls = array_merge($urls, $video_urls);
            $urls = array_merge($urls, $image_urls);
        } else {
            $urls = array_merge($urls, $image_urls);
        $urls = array_merge($urls, $video_urls);
        }

        // Keep DB2/legacy FIFU gallery types available after URLs are flattened for rendering.
        // Retain the thumbnail associations resolved before attachment URLs were flattened.
        foreach ($gallery_repo->get_gallery_urls((int) $post_id) as $gallery_item) {
            $gallery_item_url = is_object($gallery_item)
                ? (string) ($gallery_item->url ?? $gallery_item->meta_value ?? '')
                : '';
            $gallery_item_type = is_object($gallery_item)
                ? (string) ($gallery_item->type ?? $gallery_item->scope ?? '')
                : '';
            if ($gallery_item_url !== '' && in_array($gallery_item_type, ['image', 'video'], true)) {
                $authoritative_media_types[$gallery_item_url] = $gallery_item_type;
            }
        }

        // urls of parent product
        $url_map[$post_id] = $urls;
        $source_url_map[$post_id] = self::get_source_urls($urls);

        // js
        wp_enqueue_script('fifu-variable-js', plugins_url('/includes/html/js/variable.js', FIFU_PLUGIN_FILE), array('jquery'), Fifu_Plugin_Info::get_enqueue_version());
        wp_localize_script('fifu-variable-js', 'fifuVariableVars', array(
            'attribute_map' => $attribute_map,
            'url_map' => $url_map,
            'source_url_map' => $source_url_map,
            'srcset_map' => $srcset_map,
            'post_id' => $post_id,
            'fifu_video' => Fifu_Options_Utils::is_on('fifu_video'),
            'fifu_variations_merge' => Fifu_Options_Utils::is_on('fifu_variations_merge'),
        ));

        $urls = Fifu_Woocommerce_Product_Meta_Service::get_filtered_urls_by_selected_variations((int) $post_id, $url_map, $attribute_map);

        $i = -1;
        $video_sequence_started = false;
        $gallery_video_index = 0;
        $i_slider = 0;
        $video_url = null;
        foreach ($urls as $url) {
            $i++;
            $error_url = get_option('fifu_error_url');
            $original = $FIFU_SESSION['cdn-new-old'][$url] ?? $url;
            $authoritative_type = $authoritative_media_types[$original]
                ?? $authoritative_media_types[$url]
                ?? null;
            $authoritative_video_url = $authoritative_video_urls[$original]
                ?? $authoritative_video_urls[$url]
                ?? null;
            $legacy_video_thumbnail = $authoritative_type === null
                && (Fifu_Video_Helper::is_video_thumb($original) || Fifu_Video_Helper::is_video_thumb($url));
            $media_type = $authoritative_type ?? ($legacy_video_thumbnail ? 'video' : 'image');
            $media_type_attribute = 'data-fifu-media-type="' . esc_attr($media_type) . '"';

            // get video URL
            if ($authoritative_type === 'video' || $legacy_video_thumbnail) {
                $originalThumb = Fifu_Video_Helper::resolve_original_video_thumb_url($original) ?: $original;
                $embedByThumb = Fifu_Video_Helper::get_embed_url_by_image($originalThumb);
                if ($embedByThumb) {
                    $video_url = $embedByThumb;
                    $FIFU_SESSION['fifu-video'][$originalThumb] = $embedByThumb;
                    if ($url && $url !== $originalThumb) {
                        $FIFU_SESSION['fifu-video'][$url] = $embedByThumb;
                    }
                } else {
                $video_url = $authoritative_video_url;

                if (!$video_url && !$video_sequence_started) {
                    $featured_video_url = Fifu_Post_Video_Read_Service::get_video_url((int) $post_id);

                    if ($featured_video_url) {
                        $video_url = $featured_video_url;
                    } else {
                        do {
                            $video_url = Fifu_Post_Video_Gallery_Read_Service::get_video_url(
                                (int) $post_id,
                                $gallery_video_index++
                            );
                        } while ($video_url && !Fifu_Video_Helper::is_video($video_url));
                    }

                    $video_sequence_started = true;
                } elseif (!$video_url) {
                    do {
                        $video_url = Fifu_Post_Video_Gallery_Read_Service::get_video_url(
                            (int) $post_id,
                            $gallery_video_index++
                        );
                    } while ($video_url && !Fifu_Video_Helper::is_video($video_url));
                }

                if (!$video_url && Fifu_Options_Utils::is_on('fifu_slider')) {
                    do {
                        $slider_image = Fifu_Post_Slider_Image_Url_Read_Service::get_slider_image_url(
                            (int) $post_id,
                            (int) ($i_slider++)
                        );
                        if ($slider_image && strpos($slider_image, $original) !== false && strpos($slider_image, '#http') !== false) {
                            $aux = explode('#http', $slider_image);
                            $video_url = $aux[0] ?? null;
                        }
                    } while (!$video_url && $slider_image);
                }
                }
            }

            if ($url) {
                if (Fifu_Speedup_Url_Service::is_speedup_url($url)) {
                    $signed_url = Fifu_Speedup_Url_Service::get_signed_url($url, 128, 128, null, null, false);
                    $set = Fifu_Speedup_Url_Service::get_srcset($url);
                    $sizes = Fifu_Speedup_Url_Service::parse_sizes($url);

                    if (Fifu_Video_Helper::is_video($url)) {
                        $fetchpriority_attribute =
                            self::consume_first_image_fetchpriority_attribute(
                                $prioritize_first_image
                            );
                        $html = $html . sprintf(
                                        '<li %s data-thumb="%s" data-src="%s" data-srcset="%s" data-poster="%s"><img%s src="%s" class="%s" onerror="%s" alt="%s"/></li>',
                                        $media_type_attribute,
                                        esc_url($signed_url),
                                        esc_url($video_url),
                                        esc_attr($set),
                                        esc_url($url),
                                        $fetchpriority_attribute,
                                        esc_url(Fifu_Speedup_Url_Service::get_signed_url($url, $sizes[0] ?? 0, $sizes[1] ?? 0, null, null, $sizes[2] ?? false)),
                                        esc_attr($original_class),
                                        "jQuery(this).hide();",
                                        esc_attr($alt)
                                );
                        continue;
                    }

                    $fetchpriority_attribute =
                        self::consume_first_image_fetchpriority_attribute(
                            $prioritize_first_image
                        );
                    $html = $html . sprintf(
                                    '<li %s data-thumb="%s" data-src="%s" data-srcset="%s"><img%s src="%s" class="%s" onerror="%s" alt="%s"/></li>',
                                    $media_type_attribute,
                                    esc_url($signed_url),
                                    esc_url(Fifu_Media_Placeholders::TRANSPARENT_1PX_GIF),
                                    esc_attr($set),
                                    $fetchpriority_attribute,
                                    esc_url(Fifu_Speedup_Url_Service::get_signed_url($url, $sizes[0] ?? 0, $sizes[1] ?? 0, null, null, false)),
                                    esc_attr("fifu {$original_class}"),
                                    "jQuery(this).hide();",
                                    esc_attr($alt)
                            );
                    continue;
                }

                if ($i == 0) {
                    $custom_video_url = Fifu_Options_Utils::is_on('fifu_video')
                        ? Fifu_Post_Custom_Video_Read_Service::get_custom_video_url((int) $post_id)
                        : null;
                    $audio_url = null;
                    $iframe_url = "";

                    if ($custom_video_url) {
                        $video_url = $custom_video_url;
                    } elseif (!$video_url && Fifu_Options_Utils::is_on('fifu_video')) {
                        $candidate_audio_url = Fifu_Post_Audio_Read_Service::get_audio_url((int) $post_id);
                        if ($candidate_audio_url) {
                            $audio_url = $candidate_audio_url;
                            $video_url = $candidate_audio_url;
                        }
                    }
                } else {
                    $custom_video_url = null;
                    $audio_url = null;
                    $iframe_url = Fifu_Post_Image_Ifm_Read_Service::get_image_ifm_url(
                        (int) $post_id,
                        (int) ($i - 1)
                    );
                }

                $has_video_source = is_string($video_url) && $video_url !== '';
                $is_audio_source = !empty($audio_url);
                if (((($authoritative_type === 'video') || ($authoritative_type === null && Fifu_Video_Helper::is_video_thumb($original))) && $has_video_source) || $custom_video_url || $is_audio_source) {
                    $type = 'data-src';
                    $data_video = '';

                    // for video files
                    $is_amazon_video = $amazon_provider && $has_video_source ? $amazon_provider->supports($video_url) : false;
                    $is_local_video = $has_video_source ? Fifu_Video_Helper::is_local_video($video_url) : false;
                    $is_wpcom_video = $has_video_source ? Fifu_Video_Helper::is_wpcom_video($video_url) : false;
                    if ($is_local_video || $is_amazon_video || $is_wpcom_video || $custom_video_url || $is_audio_source) {
                        $type = 'data-video';
                        $poster = '';
                        if ($is_local_video) {
                            $extension = pathinfo($video_url, PATHINFO_EXTENSION);
                            $file_type = "video/{$extension}";
                        } else {
                            if ($is_audio_source) {
                                $file_type = self::get_audio_mime_type($video_url);
                                $poster = ", \"poster\":\"{$url}\", \"style\": \"object-fit:cover\"";
                            } else {
                                $file_type = $is_amazon_video || $is_wpcom_video || $custom_video_url ? 'video/mp4' : 'video';
                            }
                        }
                        $data_video = '{"source": [{"src":"' . $video_url . '", "type":"' . $file_type . '"}], "attributes": {"preload": false, "controls": true' . $poster . '}}';
                    }

                    $render_video_url = $video_url;
                    if ($type !== 'data-video') {
                        $render_video_url = Fifu_Video_Helper::get_embed_url($render_video_url) ?: $render_video_url;
                        $render_video_url = Fifu_Video_Helper::apply_privacy_enhanced_mode_to_embed_url($render_video_url);
                    }

                    $resolved_embed = $has_video_source ? Fifu_Video_Helper::get_embed_url($video_url) : null;
                    if ($resolved_embed) {
                        $video_url = $resolved_embed;
                    }

                    $aux = $url;
                    if (isset($FIFU_SESSION['cdn-new-old'][$url])) {
                        if ($url && $odysee_provider && $odysee_provider->is_thumbnail($url)) {
                            $parts = explode('/plain/', $FIFU_SESSION['cdn-new-old'][$url]);
                            $aux = $parts[1] ?? $aux;
                        } else {
                            $aux = $FIFU_SESSION['cdn-new-old'][$url];
                        }
                    }
                    $FIFU_SESSION['fifu-video'][$aux] = $video_url ? Fifu_Video_Helper::get_embed_url($video_url) : null;

                    $image_url = $video_url ? Fifu_Video_Oembed_Service::instance()->get_repository()->get_image_url_by_video_url($video_url) : null;
                    if ( ! $image_url ) {
                        $image_url = Fifu_Video_Helper::is_video_thumb( $original ) ? $original : null;
                    }
                    $att_id = null;
                    $data_lg_size = '';
                    if ($image_url) {
                        $att_id = fifu_attachment_repository()->find_attachment_id($post_id, $image_url, false);
                        if ($att_id) {
                            $metadata = wp_get_attachment_metadata($att_id);
                            if ($metadata) {
                                $width = $metadata['width'] ?? 0;
                                $height = $metadata['height'] ?? 0;
                                $data_lg_size = "data-lg-size=\"{$width}-{$height}\"";
                            }
                        }
                    }

                    $fetchpriority_attribute =
                        self::consume_first_image_fetchpriority_attribute(
                            $prioritize_first_image
                        );
                    $html = $html . sprintf(
                                    '<li %s %s data-thumb="%s" %s=\'%s\' data-poster="%s"><img%s src="%s" class="img-responsive%s" onerror="%s" alt="%s"/></li>',
                                    $media_type_attribute,
                                    $data_lg_size,
                                    esc_url($url),
                                    $type,
                                    esc_attr($type == 'data-video' ? $data_video : $render_video_url),
                                    esc_url($is_audio_source ? '' : $url),
                                    $fetchpriority_attribute,
                                    esc_url($url),
                                    $class ? ' ' . esc_attr($class) : '',
                                    $error_url ? sprintf("this.src='%s'", esc_url($error_url)) : "",
                                    esc_attr($alt)
                            );
                } else {
                    $url_thumb = null;
                    if (get_option('fifu_square_mobile') || get_option('fifu_square_desktop')) {
                        $url_thumb = Fifu_Jetpack_Cdn_Service::get_cdn_url($url, $att_id, 150, 1);
                        $url = Fifu_Jetpack_Cdn_Service::get_cdn_url($url, $att_id, 1920, 0);
                    }

                    $fetchpriority_attribute =
                        self::consume_first_image_fetchpriority_attribute(
                            $prioritize_first_image
                        );
                    $html = $html . sprintf(
                                    '<li %s data-thumb="%s" data-src="%s" %s><img%s src="%s" class="%s" onerror="%s" alt="%s"/></li>',
                                    $media_type_attribute,
                                    esc_url($url_thumb ? $url_thumb : $url),
                                    esc_url($iframe_url ? $iframe_url : $url),
                                    $iframe_url ? 'data-iframe="true"' : '',
                                    $fetchpriority_attribute,
                                    esc_url($url),
                                    esc_attr($class),
                                    $error_url ? sprintf("this.src='%s'", esc_url($error_url)) : "",
                                    esc_attr($alt)
                            );
                }
            }
        }
        // add status
        $html = str_replace('<img ', '<img fifu-replaced="1" ', $html);
        return $html . '</ul></div>';
    }

    private static function consume_first_image_fetchpriority_attribute(
        bool &$prioritize_first_image
    ): string {
        if (!$prioritize_first_image) {
            return '';
        }

        $prioritize_first_image = false;

        return ' fetchpriority="high"';
    }

    private static function get_variation_display_urls(int $variation_id, Fifu_Product_Gallery_Repository $gallery_repo): array {
        $remote_urls = self::get_remote_variation_display_urls($variation_id, $gallery_repo);
        if ($remote_urls !== array()) {
            return $remote_urls;
        }

        return self::get_local_variation_display_urls($variation_id);
    }

    private static function get_source_urls(array $display_urls): array
    {
        global $FIFU_SESSION;

        $cdn_source_map = isset($FIFU_SESSION['cdn-new-old'])
            && is_array($FIFU_SESSION['cdn-new-old'])
            ? $FIFU_SESSION['cdn-new-old']
            : array();

        $source_urls = array();

        foreach ($display_urls as $display_url) {
            if (!is_string($display_url) || $display_url === '') {
                $source_urls[] = $display_url;
                continue;
            }

            $source_url = $cdn_source_map[$display_url] ?? $display_url;

            $source_urls[] = is_string($source_url) && $source_url !== ''
                ? $source_url
                : $display_url;
        }

        return $source_urls;
    }

    private static function get_remote_variation_display_urls(int $variation_id, Fifu_Product_Gallery_Repository $gallery_repo): array {
        $urls = $gallery_repo->get_featured_and_gallery_urls_concat($variation_id);
        if (!is_string($urls) || trim($urls) === '') {
            return array();
        }

        $variation_thumbnail_id = get_post_thumbnail_id($variation_id);
        $parsed_urls = array();

        foreach (explode('|', $urls) as $url) {
            $url = trim($url);
            if ($url === '') {
                continue;
            }

            $cdn_url = Fifu_Jetpack_Cdn_Service::get_cdn_url($url, $variation_thumbnail_id, null, null);
            if ($cdn_url === '' || in_array($cdn_url, $parsed_urls, true)) {
                continue;
            }

            $parsed_urls[] = $cdn_url;
        }

        return $parsed_urls;
    }

    private static function get_local_variation_display_urls(int $variation_id): array {
        $attachment_ids = array();

        $thumbnail_id = (int) get_post_meta($variation_id, '_thumbnail_id', true);
        if ($thumbnail_id > 0) {
            $attachment_ids[] = $thumbnail_id;
        }

        $attachment_ids = array_merge(
            $attachment_ids,
            self::parse_variation_attachment_ids_csv((string) get_post_meta($variation_id, '_product_image_gallery', true)),
            self::parse_variation_attachment_ids_csv((string) get_post_meta($variation_id, '_wc_additional_variation_images', true))
        );

        $attachment_ids = array_values(array_unique(array_filter($attachment_ids, static function ($attachment_id) {
            return $attachment_id > 0;
        })));

        $urls = array();
        foreach ($attachment_ids as $attachment_id) {
            $url = Fifu_Image_Url_Utils::get_full_image_url($attachment_id);
            if (!$url) {
                continue;
            }

            $cdn_url = Fifu_Jetpack_Cdn_Service::get_cdn_url($url, $attachment_id, null, null);
            if ($cdn_url === '' || in_array($cdn_url, $urls, true)) {
                continue;
            }

            $urls[] = $cdn_url;
        }

        return $urls;
    }

    private static function parse_variation_attachment_ids_csv(string $csv): array {
        if (trim($csv) === '') {
            return array();
        }

        $attachment_ids = array();
        foreach (explode(',', $csv) as $token) {
            $attachment_id = (int) trim($token);
            if ($attachment_id > 0) {
                $attachment_ids[] = $attachment_id;
            }
        }

        return $attachment_ids;
    }

    private static function get_effective_featured_media_type(int $post_id): ?string
    {
        if (!class_exists('Fifu_Post_Featured_Media_State_Resolver', false)) {
            $resolver_file = dirname(__DIR__, 2)
                . '/meta/class-fifu-post-featured-media-state-resolver.php';
            if (is_file($resolver_file)) {
                require_once $resolver_file;
            }
        }

        if (!class_exists('Fifu_Post_Featured_Media_State_Resolver', false)) {
            return null;
        }

        $state = Fifu_Post_Featured_Media_State_Resolver::resolve_effective($post_id);
        if (!is_array($state)) {
            return null;
        }

        $type = (string) ($state['type'] ?? '');
        return in_array($type, ['image', 'video', 'custom_video'], true) ? $type : null;
    }

    private static function get_audio_mime_type(string $url): string
    {
        $path = parse_url($url, PHP_URL_PATH);
        $extension = strtolower(pathinfo($path ?: $url, PATHINFO_EXTENSION));

        if ($extension === 'ogg') {
            return 'audio/ogg';
        }

        return 'audio/mpeg';
    }
}
