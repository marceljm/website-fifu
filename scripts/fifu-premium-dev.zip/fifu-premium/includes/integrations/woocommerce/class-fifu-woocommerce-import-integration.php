<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

final class Fifu_Woocommerce_Import_Integration
{
    private const LOCAL_IMPORT_BATCH_SIZE = 50;

    /** @var array<int, bool> */
    private static array $stagedImportPostIds = [];

    public static function register_hooks(): void
    {
        // Comments must be in English.
        add_action(
            'woocommerce_product_import_inserted_product_object',
            [self::class, 'handle_product_imported'],
            10,
            2
        );
        add_action(
            'shutdown',
            [self::class, 'flush_staged_import_queue'],
            PHP_INT_MAX
        );
    }

    /**
     * Handle WooCommerce product import for FIFU metadata.
     */
    public static function handle_product_imported($object, $data = null): void
    {
        if (!($object instanceof \WC_Product)) {
            return;
        }

        $video_priority = Fifu_Woocommerce_Product_Meta_Service::has_video_list_priority($object);

        $post_id = $object->get_id();
        $importPayloadMeta = self::extract_import_payload_meta($data);
        $hasPayloadImageList = array_key_exists('fifu_list_url', $importPayloadMeta);
        $payloadImageList = $hasPayloadImageList
            ? self::normalize_pipe_list((string) $importPayloadMeta['fifu_list_url'])
            : null;
        $hasExplicitEmptyPayloadImageList = $hasPayloadImageList
            && $payloadImageList === null;
        $hasPayloadImageAlt = array_key_exists('fifu_list_alt', $importPayloadMeta);
        $hasPayloadVideoList = array_key_exists('fifu_list_video_url', $importPayloadMeta);
        $payloadVideoListRaw = $hasPayloadVideoList
            ? (string) $importPayloadMeta['fifu_list_video_url']
            : null;
        $payloadVideoList = $hasPayloadVideoList
            ? self::normalize_pipe_list($payloadVideoListRaw)
            : null;
        $hasPayloadSliderList = array_key_exists('fifu_slider_list_url', $importPayloadMeta);
        $payloadSliderList = $hasPayloadSliderList
            ? self::normalize_pipe_list((string) $importPayloadMeta['fifu_slider_list_url'])
            : null;
        $hasExplicitEmptyPayloadSliderList =
            $hasPayloadSliderList
            && $payloadSliderList === null;
        $hasPayloadSliderAlt = array_key_exists('fifu_slider_list_alt', $importPayloadMeta);
        $payloadSliderAltRaw = $hasPayloadSliderAlt
            ? (string) $importPayloadMeta['fifu_slider_list_alt']
            : null;
        $hasAuthoritativeSliderPayload = $hasPayloadSliderList
            && $payloadSliderList !== null;
        $hasPayloadIframeList = array_key_exists('fifu_list_iframe_url', $importPayloadMeta);
        $payloadIframeListRaw = $hasPayloadIframeList
            ? (string) $importPayloadMeta['fifu_list_iframe_url']
            : null;
        $hasSliderListHelper = !$hasExplicitEmptyPayloadSliderList
            && (
                $hasAuthoritativeSliderPayload
                || self::has_import_payload_meta($object, $post_id, 'fifu_slider_list_url')
            );
        $hasExplicitSliderPayload = !$hasExplicitEmptyPayloadSliderList
            && (
                $hasAuthoritativeSliderPayload
                || self::product_has_meta_key($object, 'fifu_slider_list_url')
            );
        $hasImageListImportPayload = $hasPayloadImageList
            || self::has_import_payload_meta($object, $post_id, 'fifu_list_url');
        $hasVideoListImportPayload = $hasPayloadVideoList
            || self::has_import_payload_meta($object, $post_id, 'fifu_list_video_url');
        $hasIframeListImportPayload = $hasPayloadIframeList
            || self::has_import_payload_meta($object, $post_id, 'fifu_list_iframe_url');
        $legacyAltSnapshot = $hasImageListImportPayload
            ? self::capture_legacy_alt_meta_snapshot($post_id)
            : [];
        $expectedImageList = $hasImageListImportPayload
            ? (
                $hasPayloadImageList
                    ? $payloadImageList
                    : self::get_expected_image_list_url($post_id)
            )
            : null;
        $expectedImageAltList = $hasImageListImportPayload
            ? (
                $hasPayloadImageList
                    ? (
                        $hasPayloadImageAlt
                            ? self::normalize_image_alt_list_preserving_positions(
                                (string) $importPayloadMeta['fifu_list_alt'],
                                $expectedImageList,
                                $post_id
                            )
                            : null
                    )
                    : self::get_expected_image_list_alt($post_id, $expectedImageList)
            )
            : null;
        $expectedVideoList = $hasVideoListImportPayload
            ? (
                $hasPayloadVideoList
                    ? $payloadVideoList
                    : self::get_expected_video_list_url($post_id)
            )
            : null;
        $expectedSliderList = $hasSliderListHelper
            ? (
                $hasAuthoritativeSliderPayload
                    ? $payloadSliderList
                    : self::get_expected_slider_list_url($post_id)
            )
            : null;
        $expectedSliderAltList = $hasSliderListHelper
            ? (
                $hasAuthoritativeSliderPayload
                    ? (
                        $hasPayloadSliderAlt
                            ? self::normalize_slider_alt_list_preserving_positions_for_url_count(
                                trim((string) ($payloadSliderAltRaw ?? '')),
                                count(explode('|', (string) $payloadSliderList))
                            )
                            : null
                    )
                    : self::get_expected_slider_list_alt($post_id, $expectedSliderList)
            )
            : null;
        $expectedIframeList = $hasIframeListImportPayload
            && !$hasPayloadIframeList
            ? self::get_normalized_legacy_list($post_id, 'fifu_list_iframe_url')
            : null;
        $imageUrlSnapshot = [];
        $imageAltSnapshot = [];
        $videoSnapshot = [];
        $sliderUrlSnapshot = [];
        $sliderAltSnapshot = [];
        $iframeSnapshot = [];

        if ($hasImageListImportPayload) {
            $imageUrlSnapshot = self::capture_db2_list_snapshot($post_id, 'image', false);
            $imageAltSnapshot = self::capture_db2_list_snapshot($post_id, 'image', true);
        }

        if ($hasVideoListImportPayload) {
            $videoSnapshot = self::capture_db2_list_snapshot($post_id, 'video', false);
        }

        if ($hasSliderListHelper && !$hasExplicitSliderPayload) {
            $sliderUrlSnapshot = self::capture_db2_list_snapshot($post_id, 'slider', false);
            $sliderAltSnapshot = self::capture_db2_list_snapshot($post_id, 'slider', true);
        }

        if ($hasIframeListImportPayload) {
            $iframeSnapshot = self::capture_db2_list_snapshot($post_id, 'iframe', false);
        }

        $deferTmpProductGallerySnapshotSync = false;

        if ($hasExplicitEmptyPayloadImageList) {
            self::clear_db2_list_channel($post_id, 'image', false);
            self::clear_db2_list_channel($post_id, 'image', true);

            delete_post_meta($post_id, 'fifu_list_url');
            delete_post_meta($post_id, 'fifu_list_alt');
            self::delete_legacy_image_url_derived_fields($post_id);
            self::delete_legacy_image_alt_derived_fields($post_id);

            delete_post_meta($post_id, 'fifu_tmp_product_image_gallery');
            $deferTmpProductGallerySnapshotSync = true;

            // The explicit empty payload has already been fully handled.
            // Prevent stale postmeta from entering the regular image-list fallback.
            $hasImageListImportPayload = false;
        }

        if ($hasExplicitEmptyPayloadSliderList) {
            Fifu_Slider_Meta_Service::clear_slider_state_only($post_id);
        }

        if ($hasExplicitSliderPayload) {
            $sliderListHandledByFastPath = false;
            $fastSliderListResult = null;
            $sliderUrlsConfirmedByFastPath = false;
            $sliderAltsConfirmedByFastPath = false;
            if (method_exists(Fifu_Wai_Meta_Service::class, 'save_product_slider_list_fast_from_import_payload')) {
                $fastSliderListResult = Fifu_Wai_Meta_Service::save_product_slider_list_fast_from_import_payload(
                    $post_id,
                    (string) ($expectedSliderList ?? ''),
                    (string) ($expectedSliderAltList ?? ''),
                    true,
                    false
                );

                $sliderUrlsConfirmedByFastPath = is_array($fastSliderListResult)
                    && !empty($fastSliderListResult['urls_confirmed']);
                $sliderAltsConfirmedByFastPath = is_array($fastSliderListResult)
                    && !empty($fastSliderListResult['alts_confirmed']);
                $sliderListHandledByFastPath = $sliderUrlsConfirmedByFastPath;
            }

            if (!$sliderListHandledByFastPath) {
                Fifu_Wai_Meta_Service::save_slider_list($post_id, true, true);
            }

            if ($hasImageListImportPayload) {
                self::cleanup_legacy_image_list_meta_after_db2_sync(
                    $post_id,
                    $expectedImageList,
                    $expectedImageAltList,
                    $imageUrlSnapshot,
                    $imageAltSnapshot,
                    $legacyAltSnapshot
                );
                delete_post_meta($post_id, 'fifu_list_alt');
                self::delete_legacy_image_alt_derived_fields($post_id);
            }
            if ($hasVideoListImportPayload) {
                self::cleanup_legacy_video_list_meta_after_db2_sync($post_id, $expectedVideoList, $videoSnapshot);
            }
            if (
                !(
                    $sliderListHandledByFastPath
                    && $sliderUrlsConfirmedByFastPath
                    && $sliderAltsConfirmedByFastPath
                )
                && $hasSliderListHelper
                && $sliderUrlSnapshot === []
                && $sliderAltSnapshot === []
            ) {
                $sliderUrlSnapshot = self::capture_db2_list_snapshot($post_id, 'slider', false);
                $sliderAltSnapshot = self::capture_db2_list_snapshot($post_id, 'slider', true);
            }
            if (
                $sliderListHandledByFastPath
                && $sliderUrlsConfirmedByFastPath
                && $sliderAltsConfirmedByFastPath
            ) {
                delete_post_meta($post_id, 'fifu_slider_list_url');
                delete_post_meta($post_id, 'fifu_slider_list_alt');
                self::delete_indexed_post_meta_by_pattern($post_id, '/^fifu_slider_image_url_\d+$/');
                self::delete_indexed_post_meta_by_pattern($post_id, '/^fifu_slider_image_alt_\d+$/');

                $sliderUrlConfirmed = true;

            } else {
                $sliderUrlConfirmed = self::cleanup_legacy_slider_list_meta_after_db2_sync(
                    $post_id,
                    $expectedSliderList,
                    $expectedSliderAltList,
                    $sliderUrlSnapshot,
                    $sliderAltSnapshot
                );
            }

            if ($sliderUrlConfirmed) {
                self::cleanup_import_list_meta_overridden_by_slider(
                    $post_id,
                    $hasImageListImportPayload,
                    $hasVideoListImportPayload
                );
            }
        } else {
            $imageListHandledByFastPath = false;

            if (
                $hasImageListImportPayload
                && method_exists(Fifu_Wai_Meta_Service::class, 'save_product_image_list_fast_from_import_payload')
            ) {
                $fastImageListResult = Fifu_Wai_Meta_Service::save_product_image_list_fast_from_import_payload(
                    $post_id,
                    (string) ($expectedImageList ?? ''),
                    (string) ($expectedImageAltList ?? ''),
                    (bool) $video_priority
                );

                $imageListHandledByFastPath = is_array($fastImageListResult)
                    && !empty($fastImageListResult['urls_confirmed']);
            }

            if (!$imageListHandledByFastPath && !$hasExplicitEmptyPayloadImageList) {
                Fifu_Wai_Meta_Service::save_image_list($post_id, null, $video_priority);
            }
            if ($hasVideoListImportPayload) {
                self::save_video_list_with_import_payload_context(
                    $post_id,
                    $video_priority,
                    $hasPayloadVideoList,
                    $payloadVideoListRaw,
                    $hasPayloadImageList && $payloadImageList !== null
                        ? $payloadImageList
                        : null
                );
            }
            if ($hasImageListImportPayload) {
                $imageListCleanupConfirmed = self::cleanup_legacy_image_list_meta_after_db2_sync(
                    $post_id,
                    $expectedImageList,
                    $expectedImageAltList,
                    $imageUrlSnapshot,
                    $imageAltSnapshot,
                    $legacyAltSnapshot
                );

                if (
                    $imageListHandledByFastPath
                    && $imageListCleanupConfirmed
                    && get_post_type($post_id) !== 'product_variation'
                ) {
                    $deferTmpProductGallerySnapshotSync = true;
                    delete_post_meta($post_id, 'fifu_tmp_product_image_gallery');
                }
            }
            if ($hasVideoListImportPayload) {
                self::cleanup_legacy_video_list_meta_after_db2_sync($post_id, $expectedVideoList, $videoSnapshot);
            }

            if ($hasSliderListHelper) {
                Fifu_Wai_Meta_Service::save_slider_list($post_id, true, false);
                $sliderUrlConfirmed = self::cleanup_legacy_slider_list_meta_after_db2_sync(
                    $post_id,
                    $expectedSliderList,
                    $expectedSliderAltList,
                    $sliderUrlSnapshot,
                    $sliderAltSnapshot
                );

                if ($sliderUrlConfirmed) {
                    self::cleanup_import_list_meta_overridden_by_slider(
                        $post_id,
                        $hasImageListImportPayload,
                        $hasVideoListImportPayload
                    );
                }
            }
        }
        if ($hasIframeListImportPayload) {
            if ($hasPayloadIframeList) {
                $expectedIframeList = Fifu_Wai_Meta_Service::save_iframe_list_from_import_payload(
                    $post_id,
                    (string) ($payloadIframeListRaw ?? '')
                );

                if (
                    trim((string) ($payloadIframeListRaw ?? '')) === ''
                    && $expectedIframeList === null
                ) {
                    self::cleanup_explicit_empty_iframe_payload_after_db2_sync(
                        $post_id,
                        $iframeSnapshot
                    );
                } else {
                    self::cleanup_legacy_iframe_list_meta_after_split(
                        $post_id,
                        $expectedIframeList,
                        $iframeSnapshot
                    );
                }
            } else {
                Fifu_Wai_Meta_Service::save_iframe_list($post_id);
                self::cleanup_legacy_iframe_list_meta_after_split(
                    $post_id,
                    $expectedIframeList,
                    $iframeSnapshot
                );
            }
        }
        if (!$deferTmpProductGallerySnapshotSync) {
            self::consume_tmp_product_gallery_snapshot_after_import($post_id);
        }

        fifu_db2_import_service()->queue_import($post_id, false);
        self::stage_import_post_id($post_id);
    }

    private static function stage_import_post_id(int $postId): void
    {
        if ($postId <= 0) {
            return;
        }

        self::$stagedImportPostIds[$postId] = true;

        if (count(self::$stagedImportPostIds) < self::LOCAL_IMPORT_BATCH_SIZE) {
            return;
        }

        self::flush_staged_import_queue();
    }

    public static function flush_staged_import_queue(): void
    {
        if (self::$stagedImportPostIds === []) {
            return;
        }

        $postIds = array_values(
            array_unique(
                array_filter(
                    array_map('intval', array_keys(self::$stagedImportPostIds)),
                    static function (int $postId): bool {
                        return $postId > 0;
                    }
                )
            )
        );

        self::$stagedImportPostIds = [];

        foreach (array_chunk($postIds, self::LOCAL_IMPORT_BATCH_SIZE) as $chunk) {
            self::process_local_import_batch($chunk);
        }
    }

    /**
     * @param array<int, int> $postIds
     */
    private static function process_local_import_batch(array $postIds): void
    {
        $postIds = array_values(
            array_unique(
                array_filter(
                    array_map('intval', $postIds),
                    static function (int $postId): bool {
                        return $postId > 0;
                    }
                )
            )
        );

        if ($postIds === []) {
            return;
        }

        try {
            Fifu_Metadata_Import_Service::run_local_import($postIds, false);
        } catch (Throwable $throwable) {
            foreach ($postIds as $postId) {
                self::$stagedImportPostIds[$postId] = true;
            }

            if (class_exists('Fifu_File_Logger', false)) {
                Fifu_File_Logger::plugin([
                    'local_import_error' => [
                        'ids' => $postIds,
                        'ctgr' => false,
                        'message' => $throwable->getMessage(),
                    ],
                ]);
            }
        }
    }

    private static function cleanup_legacy_image_list_meta_after_db2_sync(
        int $postId,
        ?string $expectedUrls,
        ?string $expectedAlts,
        array $urlSnapshot,
        array $altSnapshot,
        array $legacyAltSnapshot
    ): bool {
        $legacyUrlsNormalized = self::normalize_pipe_list($expectedUrls);
        $legacyAltsNormalized = self::normalize_pipe_list($expectedAlts);
        $hasExpectedUrls = $legacyUrlsNormalized !== null;
        $hasExpectedAlts = $legacyAltsNormalized !== null;
        $hasDb2ImageTargets = self::get_db2_normalized_pipe_list($postId, 'image', false) !== null;
        $shouldDropOrphanAlts = !$hasExpectedUrls && $hasExpectedAlts && !$hasDb2ImageTargets;
        $canCleanupUrls = false;

        $urlBridgeFailed = self::legacy_write_bridge_failed_for_meta_key('fifu_list_url');
        $altBridgeFailed = self::legacy_write_bridge_failed_for_meta_key('fifu_list_alt');

        if ($urlBridgeFailed) {
            self::clear_db2_list_channel($postId, 'image', false);
        }

        if ($altBridgeFailed) {
            self::clear_db2_list_channel($postId, 'image', true);
        }

        $urlMatches = self::db2_list_round_trip_matches($postId, 'image', false, $legacyUrlsNormalized);
        $altMatches = $legacyAltsNormalized === null
            || self::db2_list_round_trip_matches($postId, 'image', true, $legacyAltsNormalized)
            || self::legacy_image_alt_meta_is_fully_confirmed_in_db2($postId, $legacyAltsNormalized);

        $canCleanupUrls = $legacyUrlsNormalized !== null && $urlMatches && !$urlBridgeFailed;
        $canCleanupAlts = $legacyAltsNormalized !== null && $altMatches && !$altBridgeFailed;
        $shouldDropStaleAltsBecauseUrlsWereReplacedWithoutAlts = $canCleanupUrls && !$hasExpectedAlts;

        if (!$urlMatches && $legacyUrlsNormalized !== null) {
            self::clear_db2_list_channel($postId, 'image', false);
        }

        if ($legacyAltsNormalized !== null && !$altMatches) {
            self::clear_db2_list_channel($postId, 'image', true);
        }

        if ($canCleanupUrls) {
            delete_post_meta($postId, 'fifu_list_url');
            self::delete_legacy_image_url_derived_fields($postId);
        }

        if ($canCleanupAlts) {
            delete_post_meta($postId, 'fifu_list_alt');
            self::delete_legacy_image_alt_derived_fields($postId);
        } elseif ($shouldDropOrphanAlts || $shouldDropStaleAltsBecauseUrlsWereReplacedWithoutAlts) {
            self::clear_db2_list_channel($postId, 'image', true);
            delete_post_meta($postId, 'fifu_list_alt');
            self::delete_legacy_image_alt_derived_fields($postId);
        } else {
            self::restore_legacy_alt_meta_snapshot($postId, $legacyAltSnapshot);
        }

        // WooCommerce CSV import already queues DB2 metadata restoration after this cleanup.
        // Avoid synchronously creating fake gallery attachments for every imported product.
        return $canCleanupUrls || $canCleanupAlts;
    }

    private static function cleanup_legacy_video_list_meta_after_db2_sync(
        int $postId,
        ?string $expectedVideos,
        array $snapshot
    ): void {
        $legacyVideosNormalized = self::normalize_pipe_list($expectedVideos);
        if ($legacyVideosNormalized === null) {
            return;
        }

        if (self::legacy_write_bridge_failed_for_meta_key('fifu_list_video_url')) {
            self::clear_db2_list_channel($postId, 'video', false);
            return;
        }

        if (self::db2_list_round_trip_matches($postId, 'video', false, $legacyVideosNormalized)) {
            delete_post_meta($postId, 'fifu_list_video_url');
            self::delete_legacy_video_url_derived_fields($postId);
            return;
        }

        self::restore_db2_list_snapshot($postId, 'video', false, $snapshot);
    }

    private static function cleanup_legacy_slider_list_meta_after_db2_sync(
        int $postId,
        ?string $expectedUrls,
        ?string $expectedAlts,
        array $urlSnapshot,
        array $altSnapshot
    ): bool {
        $urlBridgeFailed = null;
        $altBridgeFailed = null;
        $urlMatches = null;
        $altMatches = null;

        $legacyUrlsNormalized = self::normalize_pipe_list($expectedUrls);
        if ($legacyUrlsNormalized === null) {
            return false;
        }

        $legacyAltsNormalized = self::normalize_pipe_list($expectedAlts);
        $urlBridgeFailed = self::legacy_write_bridge_failed_for_meta_key('fifu_slider_list_url');
        $altBridgeFailed = self::legacy_write_bridge_failed_for_meta_key('fifu_slider_list_alt');

        if ($urlBridgeFailed) {
            self::clear_db2_list_channel($postId, 'slider', false);
            if ($altBridgeFailed) {
                self::clear_db2_list_channel($postId, 'slider', true);
            }
            return false;
        }

        $urlMatches = self::db2_list_round_trip_matches($postId, 'slider', false, $legacyUrlsNormalized);
        if (!$urlMatches) {
            self::clear_db2_list_channel($postId, 'slider', false);
            if ($altBridgeFailed) {
                self::clear_db2_list_channel($postId, 'slider', true);
            }
            return false;
        }

        delete_post_meta($postId, 'fifu_slider_list_url');
        self::delete_indexed_post_meta_by_pattern($postId, '/^fifu_slider_image_url_\d+$/');

        if ($altBridgeFailed) {
            self::clear_db2_list_channel($postId, 'slider', true);
            return true;
        }

        $altMatches = $legacyAltsNormalized === null || self::db2_list_round_trip_matches($postId, 'slider', true, $legacyAltsNormalized);

        if (!$altMatches) {
            self::clear_db2_list_channel($postId, 'slider', true);
            return true;
        }

        if ($legacyAltsNormalized !== null) {
            delete_post_meta($postId, 'fifu_slider_list_alt');
            self::delete_indexed_post_meta_by_pattern($postId, '/^fifu_slider_image_alt_\d+$/');
        }

        return true;
    }

    private static function cleanup_explicit_empty_iframe_payload_after_db2_sync(int $postId, array $snapshot): bool
    {
        if (
            self::get_db2_manager() === null
            || self::get_db2_normalized_pipe_list($postId, 'iframe', false) !== null
        ) {
            self::restore_db2_list_snapshot($postId, 'iframe', false, $snapshot);
            return false;
        }

        delete_post_meta($postId, 'fifu_list_iframe_url');
        self::delete_legacy_iframe_derived_fields($postId);

        return true;
    }

    private static function cleanup_legacy_iframe_list_meta_after_split(int $postId, ?string $expectedIframes, array $snapshot): void
    {
        $legacyIframesNormalized = self::normalize_pipe_list($expectedIframes);
        if ($legacyIframesNormalized === null) {
            return;
        }

        if (!self::db2_list_round_trip_matches($postId, 'iframe', false, $legacyIframesNormalized)) {
            self::restore_db2_list_snapshot($postId, 'iframe', false, $snapshot);
            return;
        }

        delete_post_meta($postId, 'fifu_list_iframe_url');
        self::delete_legacy_iframe_derived_fields($postId);
    }

    private static function delete_legacy_iframe_derived_fields(int $postId): void
    {
        self::delete_legacy_meta_fields_by_pattern($postId, '/^fifu_image_ifm_\\d+$/');
    }

    private static function get_normalized_legacy_list(int $postId, string $metaKey): ?string
    {
        return self::normalize_pipe_list((string) get_post_meta($postId, $metaKey, true));
    }

    private static function get_db2_manager(): ?Fifu_Db2_Manager
    {
        if (!function_exists('fifu_db2_manager')) {
            return null;
        }

        $manager = fifu_db2_manager();
        if (!$manager instanceof Fifu_Db2_Manager) {
            return null;
        }

        return $manager;
    }

    private static function capture_db2_list_snapshot(int $postId, string $keyType, bool $isAlt): array
    {
        $manager = self::get_db2_manager();
        if ($manager === null) {
            return [];
        }

        try {
            $rows = $isAlt
                ? $manager->getPostAltMappings($postId, $keyType)
                : $manager->getPostMappings($postId, $keyType);
        } catch (\Throwable $exception) {
            return [];
        }

        return is_array($rows) ? array_values($rows) : [];
    }

    private static function get_expected_image_list_url(int $postId): ?string
    {
        $list = self::get_normalized_legacy_list($postId, 'fifu_list_url');
        if ($list !== null) {
            return $list;
        }

        return self::get_preferred_derived_pipe_list($postId, [
            'fifu_image_url',
            'fifu_image_url_0',
            'fifu_image_url_1',
        ]);
    }

    private static function get_expected_image_list_alt(int $postId, ?string $expectedImageUrls): ?string
    {
        $raw = (string) get_post_meta($postId, 'fifu_list_alt', true);
        $normalizedAltList = self::normalize_image_alt_list_preserving_positions($raw, $expectedImageUrls, $postId);
        if ($normalizedAltList !== null) {
            return $normalizedAltList;
        }

        return null;
    }

    private static function get_expected_video_list_url(int $postId): ?string
    {
        return self::get_normalized_legacy_list($postId, 'fifu_list_video_url');
    }

    private static function get_expected_slider_list_url(int $postId): ?string
    {
        return self::get_normalized_legacy_list($postId, 'fifu_slider_list_url');
    }

    private static function get_expected_slider_list_alt(int $postId, ?string $expectedSliderUrls): ?string
    {
        $raw = trim((string) get_post_meta($postId, 'fifu_slider_list_alt', true));
        if ($raw === '') {
            return null;
        }

        $urlCount = 0;
        $normalizedUrls = self::normalize_pipe_list($expectedSliderUrls);
        if ($normalizedUrls !== null) {
            $urlCount = count(explode('|', $normalizedUrls));
        }

        if ($urlCount <= 0) {
            return self::normalize_slider_alt_list_preserving_positions_for_url_count($raw, 0);
        }

        return self::normalize_slider_alt_list_preserving_positions_for_url_count($raw, $urlCount);
    }

    private static function normalize_slider_alt_list_preserving_positions_for_url_count(string $rawAlts, int $urlCount): ?string
    {
        if ($rawAlts === '' || $urlCount <= 0) {
            return null;
        }

        $parts = explode('|', $rawAlts);
        $normalized = [];

        for ($i = 0; $i < $urlCount; $i++) {
            $segment = array_key_exists($i, $parts) ? (string) $parts[$i] : '';

            if (function_exists('wp_specialchars_decode')) {
                $segment = (string) wp_specialchars_decode($segment, ENT_QUOTES);
            } else {
                $segment = html_entity_decode($segment, ENT_QUOTES);
            }

            if (function_exists('wp_strip_all_tags')) {
                $segment = (string) wp_strip_all_tags($segment);
            } else {
                $segment = strip_tags($segment);
            }

            $segment = trim($segment);

            if ($segment === '' || preg_match('/^(null|undefined)$/i', $segment) === 1) {
                $normalized[$i] = '';
                continue;
            }

            $normalized[$i] = $segment;
        }

        for ($i = count($normalized) - 1; $i >= 0; $i--) {
            if (($normalized[$i] ?? '') !== '') {
                break;
            }

            unset($normalized[$i]);
        }

        if ($normalized === []) {
            return null;
        }

        return implode('|', $normalized);
    }

    private static function cleanup_import_list_meta_overridden_by_slider(
        int $postId,
        bool $hasImageListImportPayload,
        bool $hasVideoListImportPayload
    ): void {
        if ($hasImageListImportPayload) {
            delete_post_meta($postId, 'fifu_list_url');
            delete_post_meta($postId, 'fifu_list_alt');
            self::delete_legacy_image_url_derived_fields($postId);
            self::delete_legacy_image_alt_derived_fields($postId);
        }

        if ($hasVideoListImportPayload) {
            delete_post_meta($postId, 'fifu_list_video_url');
            self::delete_legacy_video_url_derived_fields($postId);
        }
    }

    /**
     * @param string[] $metaKeys
     */
    private static function get_preferred_derived_pipe_list(int $postId, array $metaKeys): ?string
    {
        $values = [];

        foreach ($metaKeys as $metaKey) {
            if (!is_string($metaKey) || !metadata_exists('post', $postId, $metaKey)) {
                continue;
            }

            $normalized = self::normalize_pipe_list((string) get_post_meta($postId, $metaKey, true));
            if ($normalized === null) {
                continue;
            }

            $values[] = $normalized;
        }

        if (!$values) {
            return null;
        }

        return self::normalize_pipe_list(implode('|', $values));
    }

    /**
     * Extract the WooCommerce CSV metadata fields used by this atomic image-list path.
     *
     * @return array<string,string>
     */
    private static function save_video_list_with_import_payload_context(
        int $postId,
        $videoPriority,
        bool $hasPayloadVideoList,
        ?string $payloadVideoListRaw,
        ?string $payloadImageList
    ): void {
        $videoRequestKey = 'fifu_wai_video_list_url';
        $imageRequestKey = 'fifu_wai_image_list_url';

        $hadVideoRequest = array_key_exists($videoRequestKey, $_REQUEST);
        $previousVideoRequest = $hadVideoRequest
            ? $_REQUEST[$videoRequestKey]
            : null;

        $hadImageRequest = array_key_exists($imageRequestKey, $_REQUEST);
        $previousImageRequest = $hadImageRequest
            ? $_REQUEST[$imageRequestKey]
            : null;

        try {
            if ($hasPayloadVideoList) {
                $_REQUEST[$videoRequestKey] = (string) ($payloadVideoListRaw ?? '');
            }

            if ($payloadImageList !== null) {
                $_REQUEST[$imageRequestKey] = $payloadImageList;
            }

            Fifu_Wai_Meta_Service::save_video_list(
                $postId,
                null,
                $videoPriority
            );
        } finally {
            if ($hadVideoRequest) {
                $_REQUEST[$videoRequestKey] = $previousVideoRequest;
            } else {
                unset($_REQUEST[$videoRequestKey]);
            }

            if ($hadImageRequest) {
                $_REQUEST[$imageRequestKey] = $previousImageRequest;
            } else {
                unset($_REQUEST[$imageRequestKey]);
            }
        }
    }

    private static function extract_import_payload_meta($data): array
    {
        if (
            !is_array($data)
            || !isset($data['meta_data'])
            || !is_iterable($data['meta_data'])
        ) {
            return [];
        }

        $result = [];

        foreach ($data['meta_data'] as $meta) {
            if (!is_array($meta)) {
                continue;
            }

            $key = $meta['key'] ?? null;
            if (!is_scalar($key)) {
                continue;
            }

            $key = (string) $key;
            if (
                $key !== 'fifu_list_url'
                && $key !== 'fifu_list_alt'
                && $key !== 'fifu_list_video_url'
                && $key !== 'fifu_slider_list_url'
                && $key !== 'fifu_slider_list_alt'
                && $key !== 'fifu_list_iframe_url'
            ) {
                continue;
            }

            $value = $meta['value'] ?? '';
            if ($value !== null && !is_scalar($value)) {
                continue;
            }

            $result[$key] = (string) ($value ?? '');
        }

        return $result;
    }

    private static function has_import_payload_meta(\WC_Product $object, int $postId, string $metaKey): bool
    {
        if (metadata_exists('post', $postId, $metaKey)) {
            return true;
        }

        if (!method_exists($object, 'get_meta_data')) {
            return false;
        }

        foreach ((array) $object->get_meta_data() as $metaData) {
            $key = self::get_product_meta_key($metaData);
            if ($key !== $metaKey) {
                continue;
            }

            $value = self::get_product_meta_value($metaData);

            return trim((string) $value) !== '';
        }

        return false;
    }

    private static function product_has_meta_key(\WC_Product $object, string $metaKey): bool
    {
        if (!method_exists($object, 'get_meta_data')) {
            return false;
        }

        foreach ((array) $object->get_meta_data() as $metaData) {
            $key = self::get_product_meta_key($metaData);
            if ($key === $metaKey) {
                return true;
            }
        }

        return false;
    }

    private static function get_product_meta_key($meta): ?string
    {
        if (is_array($meta)) {
            $key = $meta['key'] ?? null;
            return is_scalar($key) ? (string) $key : null;
        }

        if (is_object($meta)) {
            if (isset($meta->key) && is_scalar($meta->key)) {
                return (string) $meta->key;
            }

            if (method_exists($meta, 'get_key')) {
                $key = $meta->get_key();
                return is_scalar($key) ? (string) $key : null;
            }

            if (method_exists($meta, 'get_data')) {
                $data = $meta->get_data();
                if (is_array($data)) {
                    $key = $data['key'] ?? null;
                    return is_scalar($key) ? (string) $key : null;
                }
            }
        }

        return null;
    }

    private static function get_product_meta_value($meta)
    {
        if (is_array($meta)) {
            return $meta['value'] ?? null;
        }

        if (is_object($meta)) {
            if (isset($meta->value)) {
                return $meta->value;
            }

            if (method_exists($meta, 'get_value')) {
                return $meta->get_value();
            }

            if (method_exists($meta, 'get_data')) {
                $data = $meta->get_data();
                if (is_array($data)) {
                    return $data['value'] ?? null;
                }
            }
        }

        return null;
    }

    private static function normalize_image_alt_list_preserving_positions(string $rawAlts, ?string $expectedImageUrls, int $postId): ?string
    {
        $rawAlts = trim($rawAlts);
        if ($rawAlts === '') {
            return null;
        }

        $slots = self::parse_pipe_list_preserve_empty_slots($rawAlts);
        if ($slots === []) {
            return null;
        }

        $urlCount = 0;
        if ($expectedImageUrls !== null) {
            $normalizedUrls = self::normalize_pipe_list($expectedImageUrls);
            if ($normalizedUrls !== null) {
                $urlCount = count(explode('|', $normalizedUrls));
            }
        }

        if ($urlCount <= 0) {
            $db2Urls = self::get_db2_normalized_pipe_list($postId, 'image', false);
            if ($db2Urls !== null) {
                $urlCount = count(explode('|', $db2Urls));
            }
        }

        if ($urlCount > 0) {
            return self::normalize_image_alt_list_preserving_positions_for_url_count($rawAlts, $urlCount);
        }

        $normalized = [];
        foreach ($slots as $slot) {
            $normalized[] = self::normalize_image_alt_segment_preserving_position((string) $slot);
        }

        while ($normalized !== [] && end($normalized) === '') {
            array_pop($normalized);
        }

        if ($normalized === []) {
            return null;
        }

        return implode('|', $normalized);
    }

    /**
     * @return array<int,string>
     */
    private static function parse_pipe_list_preserve_empty_slots(string $value): array
    {
        $value = trim($value);
        if ($value === '') {
            return [];
        }

        $delimiter = strpos($value, PHP_EOL) !== false && strpos($value, '|') === false ? PHP_EOL : '|';
        return array_map('trim', explode($delimiter, $value));
    }

    private static function normalize_image_alt_segment_preserving_position(string $segment): string
    {
        $segment = html_entity_decode((string) $segment, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $segment = str_replace("\xc2\xa0", ' ', $segment);

        if (function_exists('wp_strip_all_tags')) {
            $segment = (string) wp_strip_all_tags($segment);
        } else {
            $segment = strip_tags($segment);
        }

        $segment = trim($segment);
        $lower = strtolower($segment);

        if ($lower === 'null' || $lower === 'undefined') {
            return '';
        }

        return $segment;
    }

    private static function normalize_image_alt_slot(string $alt): string
    {
        return self::normalize_image_alt_segment_preserving_position($alt);
    }

    private static function normalize_image_alt_list_preserving_positions_for_url_count(string $rawAlts, int $urlCount): ?string
    {
        if ($urlCount <= 0) {
            return null;
        }

        $slots = self::parse_pipe_list_preserve_empty_slots($rawAlts);
        if ($slots === []) {
            return null;
        }

        $normalized = [];
        for ($index = 0; $index < $urlCount; $index++) {
            $normalized[$index] = self::normalize_image_alt_segment_preserving_position((string) ($slots[$index] ?? ''));
        }

        while ($normalized !== [] && end($normalized) === '') {
            array_pop($normalized);
        }

        if ($normalized === []) {
            return null;
        }

        return implode('|', $normalized);
    }

    private static function restore_db2_list_snapshot(int $postId, string $keyType, bool $isAlt, array $snapshot): void
    {
        $manager = self::get_db2_manager();
        if ($manager === null) {
            return;
        }

        try {
            if ($isAlt) {
                $manager->deletePostAltMappings($postId, $keyType);
            } else {
                $manager->deletePostMappings($postId, $keyType);
            }
        } catch (\Throwable $exception) {
            return;
        }

        foreach ($snapshot as $row) {
            $index = (int) ($row['key_index'] ?? 0);
            if ($isAlt) {
                $alt = trim((string) ($row['alt'] ?? $row['value'] ?? ''));
                if ($alt === '') {
                    continue;
                }

                $manager->savePostAlt($postId, $keyType, $index, $alt);
                continue;
            }

            $url = trim((string) ($row['url'] ?? ''));
            if ($url === '') {
                continue;
            }

            $manager->savePostUrl(
                $postId,
                $keyType,
                $index,
                $url,
                isset($row['width']) ? (int) $row['width'] : null,
                isset($row['height']) ? (int) $row['height'] : null
            );
        }
    }

    private static function clear_db2_list_channel(int $postId, string $keyType, bool $isAlt): void
    {
        $manager = self::get_db2_manager();
        if ($manager === null) {
            return;
        }

        try {
            if ($isAlt) {
                $manager->deletePostAltMappings($postId, $keyType);
                return;
            }

            $manager->deletePostMappings($postId, $keyType);
        } catch (\Throwable $exception) {
            // Best-effort cleanup only.
        }
    }

    private static function db2_list_round_trip_matches(int $postId, string $keyType, bool $isAlt, ?string $expected): bool
    {
        $expectedNormalized = self::normalize_pipe_list($expected);
        $db2Normalized = self::get_db2_normalized_pipe_list($postId, $keyType, $isAlt);

        if ($expectedNormalized === null || $db2Normalized === null) {
            return false;
        }

        return $expectedNormalized === $db2Normalized;
    }

    private static function legacy_write_bridge_failed_for_meta_key(string $metaKey): bool
    {
        if (!function_exists('fifu_db2_legacy_write_bridge')) {
            return false;
        }

        $bridge = fifu_db2_legacy_write_bridge();
        if (!is_object($bridge) || !property_exists($bridge, 'forcedFailuresByMetaKey')) {
            return false;
        }

        try {
            $reflection = new \ReflectionProperty($bridge, 'forcedFailuresByMetaKey');
            $forcedFailures = $reflection->getValue($bridge);
        } catch (\Throwable $exception) {
            return false;
        }

        return is_array($forcedFailures) && !empty($forcedFailures[$metaKey]);
    }

    private static function normalize_pipe_list(?string $value): ?string
    {
        if ($value === null) {
            return null;
        }

        $entries = array_values(
            array_filter(
                array_map('trim', explode('|', $value)),
                static fn(string $entry): bool => $entry !== ''
            )
        );

        if (!$entries) {
            return null;
        }

        return implode('|', $entries);
    }

    private static function read_normalized_pipe_list(int $postId, string $readerServiceClass, string $readerMethod): ?string
    {
        if (!class_exists($readerServiceClass, false) || !method_exists($readerServiceClass, $readerMethod)) {
            return null;
        }

        try {
            $value = call_user_func([$readerServiceClass, $readerMethod], $postId);
        } catch (\Throwable $exception) {
            return null;
        }

        return self::normalize_pipe_list(is_string($value) ? $value : (string) $value);
    }

    private static function delete_legacy_image_url_derived_fields(int $postId): void
    {
        self::delete_legacy_meta_fields_by_pattern($postId, '/^fifu_image_url(?:_?\d+)?$/');
    }

    private static function delete_legacy_image_alt_derived_fields(int $postId): void
    {
        self::delete_legacy_meta_fields_by_pattern($postId, '/^fifu_image_alt(?:_?\d+)?$/');
    }

    private static function delete_legacy_video_url_derived_fields(int $postId): void
    {
        self::delete_legacy_meta_fields_by_pattern(
            $postId,
            '/^fifu_(?:video_url(?:_\\d+)?|custom_video_url)$/'
        );
    }

    /**
     * @return array<string,string|null>
     */
    private static function capture_legacy_alt_meta_snapshot(int $postId): array
    {
        $snapshot = [];

        foreach (array_keys((array) get_post_meta($postId, '')) as $metaKey) {
            if (!is_string($metaKey) || !preg_match('/^fifu_(?:list_alt|image_alt(?:_?\d+)?)$/', $metaKey)) {
                continue;
            }

            $snapshot[$metaKey] = get_post_meta($postId, $metaKey, true);
        }

        return $snapshot;
    }

    /**
     * @param array<string,string|null> $snapshot
     */
    private static function restore_legacy_alt_meta_snapshot(int $postId, array $snapshot): void
    {
        foreach ($snapshot as $metaKey => $value) {
            if (!is_string($metaKey)) {
                continue;
            }

            if ($value === null) {
                delete_post_meta($postId, $metaKey);
                continue;
            }

            update_post_meta($postId, $metaKey, $value);
        }
    }

    private static function delete_indexed_post_meta_by_pattern(int $postId, string $pattern): void
    {
        foreach (array_keys((array) get_post_meta($postId, '')) as $metaKey) {
            if (!is_string($metaKey) || preg_match($pattern, $metaKey) !== 1) {
                continue;
            }

            delete_post_meta($postId, $metaKey);
        }
    }

    /**
     * @param string[] $metaKeys
     */
    private static function delete_legacy_meta_fields(int $postId, array $metaKeys): void
    {
        foreach ($metaKeys as $metaKey) {
            if (!is_string($metaKey) || !metadata_exists('post', $postId, $metaKey)) {
                continue;
            }

            delete_post_meta($postId, $metaKey);
        }
    }

    private static function delete_legacy_meta_fields_by_pattern(int $postId, string $pattern): void
    {
        foreach (array_keys((array) get_post_meta($postId, '')) as $metaKey) {
            if (!is_string($metaKey) || !preg_match($pattern, $metaKey)) {
                continue;
            }

            delete_post_meta($postId, $metaKey);
        }
    }

    private static function legacy_image_alt_meta_is_fully_confirmed_in_db2(int $postId, string $legacyAltsNormalized): bool
    {
        $legacyAlts = array_values(
            array_filter(
                array_map('trim', explode('|', $legacyAltsNormalized)),
                static fn(string $entry): bool => $entry !== ''
            )
        );

        if (!$legacyAlts) {
            return false;
        }

        $legacyAltMeta = self::collect_legacy_image_alt_meta($postId);
        if (!$legacyAltMeta) {
            return false;
        }

        $expectedByIndex = self::map_legacy_image_alt_values_to_db2_indexes($legacyAlts);
        if ($expectedByIndex === []) {
            return false;
        }

        foreach ($legacyAltMeta as $metaKey => $value) {
            $index = self::legacy_image_alt_meta_key_to_db2_index($metaKey);
            if ($index === null || !array_key_exists($index, $expectedByIndex)) {
                return false;
            }

            if ($expectedByIndex[$index] !== $value) {
                return false;
            }
        }

        $manager = self::get_db2_manager();
        if ($manager === null || !method_exists($manager, 'getPostAltMapping')) {
            return false;
        }

        foreach ($expectedByIndex as $index => $expectedValue) {
            try {
                $mapping = $manager->getPostAltMapping($postId, 'image', $index);
            } catch (\Throwable $exception) {
                return false;
            }

            $db2Alt = trim((string) ($mapping['alt'] ?? ''));
            if ($db2Alt === '' || $db2Alt !== $expectedValue) {
                return false;
            }
        }

        return true;
    }

    /**
     * @return array<string,string>
     */
    private static function collect_legacy_image_alt_meta(int $postId): array
    {
        $values = [];
        foreach (array_keys((array) get_post_meta($postId, '')) as $metaKey) {
            if (!is_string($metaKey) || !preg_match('/^fifu_image_alt(?:_?\d+)?$/', $metaKey)) {
                continue;
            }

            $value = trim((string) get_post_meta($postId, $metaKey, true));
            if ($value === '') {
                continue;
            }

            $values[$metaKey] = $value;
        }

        return $values;
    }

    /**
     * @param string[] $legacyAlts
     * @return array<int,string>
     */
    private static function map_legacy_image_alt_values_to_db2_indexes(array $legacyAlts): array
    {
        $expectedByIndex = [];
        foreach ($legacyAlts as $index => $alt) {
            $expectedByIndex[$index] = $alt;
        }

        return $expectedByIndex;
    }

    private static function legacy_image_alt_meta_key_to_db2_index(string $metaKey): ?int
    {
        if ($metaKey === 'fifu_image_alt') {
            return 0;
        }

        if (preg_match('/^fifu_image_alt_?(\d+)$/', $metaKey, $matches)) {
            return ((int) $matches[1]) + 1;
        }

        return null;
    }

    private static function get_db2_normalized_pipe_list(int $postId, string $keyType, bool $isAlt): ?string
    {
        $manager = self::get_db2_manager();
        if ($manager === null) {
            return null;
        }

        try {
            $rows = $isAlt
                ? $manager->getPostAltMappings($postId, $keyType)
                : $manager->getPostMappings($postId, $keyType);
        } catch (\Throwable $exception) {
            return null;
        }

        if (!is_array($rows) || !$rows) {
            return null;
        }

        usort(
            $rows,
            static fn(array $a, array $b): int => (int) ($a['key_index'] ?? 0) <=> (int) ($b['key_index'] ?? 0)
        );

        $values = [];
        foreach ($rows as $row) {
            $value = $isAlt ? trim((string) ($row['alt'] ?? $row['value'] ?? '')) : trim((string) ($row['url'] ?? ''));
            if ($value === '') {
                return null;
            }

            $values[] = $value;
        }

        return $values ? implode('|', $values) : null;
    }

    private static function consume_tmp_product_gallery_snapshot_after_import(int $postId): void
    {
        if (!class_exists('Fifu_Post_Attachment_Sync_Service', false)) {
            return;
        }

        foreach (self::get_tmp_product_gallery_snapshot_owner_ids($postId) as $ownerId) {
            clean_post_cache($ownerId);
            $tmpSnapshot = trim((string) get_post_meta($ownerId, 'fifu_tmp_product_image_gallery', true));
            if ($tmpSnapshot === '') {
                continue;
            }

            Fifu_Post_Attachment_Sync_Service::sync_gallery_attachments($ownerId);
        }
    }

    /**
     * @return int[]
     */
    private static function get_tmp_product_gallery_snapshot_owner_ids(int $postId): array
    {
        $ownerIds = [$postId];

        if (get_post_type($postId) === 'product_variation') {
            $parentId = (int) wp_get_post_parent_id($postId);
            if ($parentId > 0) {
                $ownerIds[] = $parentId;
            }
        }

        return array_values(array_unique(array_filter($ownerIds, static fn(int $ownerId): bool => $ownerId > 0)));
    }
}
