<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Provides centralized hooks for variation gallery insert/update behavior.
 */
final class Fifu_Woocommerce_Variation_Hooks
{
    /**
     * Registers WooCommerce hooks that coordinate variation galleries.
     */
    public static function register_hooks(): void
    {
        add_action(
            'woocommerce_ajax_save_product_variations',
            [Fifu_Woocommerce_Variation_Attachment_Service::class, 'sync_additional_variation_images'],
            10,
            1
        );
    }

    /**
     * Handles variation insert events to rebuild attachments or apply default images.
     */
    public static function on_variation_insert(
        int $postId,
        array $urls,
        array $alts,
        bool $isSlider,
        array $videoUrls
    ): void {
        if ($urls) {
            $alts = array_values(array_slice($alts, 0, count($urls)));
        }

        if ($urls || $videoUrls) {
            Fifu_Woocommerce_Variation_Attachment_Service::rebuild_variation_attachments(
                $postId,
                $urls,
                $alts,
                $isSlider,
                $videoUrls
            );
            return;
        }

        Fifu_Default_Image_Service::add_default_image_to_post($postId);
    }

    /**
     * Handles variation update events to rebuild attachments or fall back to the default image.
     */
    public static function on_variation_update(
        int $postId,
        array $urls,
        array $alts,
        bool $isSlider,
        array $videoUrls
    ): void {
        if ($urls) {
            $alts = array_values(array_slice($alts, 0, count($urls)));
        }

        if (isset($urls[0]) && $urls[0]) {
            Fifu_Woocommerce_Variation_Attachment_Service::rebuild_variation_attachments(
                $postId,
                $urls,
                $alts,
                $isSlider,
                $videoUrls
            );
            return;
        }

        Fifu_Default_Image_Service::add_default_image_to_post($postId);
    }
}
